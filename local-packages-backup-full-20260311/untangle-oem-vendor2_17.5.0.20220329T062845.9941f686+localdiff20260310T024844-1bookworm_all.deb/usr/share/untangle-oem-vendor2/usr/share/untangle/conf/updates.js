{
	"distribution": "vendor2-beta"
}
