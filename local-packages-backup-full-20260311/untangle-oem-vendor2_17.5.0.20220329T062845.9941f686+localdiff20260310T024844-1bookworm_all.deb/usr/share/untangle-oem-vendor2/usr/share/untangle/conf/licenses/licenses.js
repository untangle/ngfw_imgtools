{
    "isRestricted": true,
    "javaClass": "com.untangle.app.license.LicenseSettings",
    "licenses": {
        "javaClass": "java.util.LinkedList",
        "list": [
        ]
    },
    "settingsVersion": 1
}
