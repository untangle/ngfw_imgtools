WALLPAPER=/usr/share/untangle-linux-config/utsplash.png
COLOR_NORMAL=black/black
COLOR_HIGHLIGHT=black/black
