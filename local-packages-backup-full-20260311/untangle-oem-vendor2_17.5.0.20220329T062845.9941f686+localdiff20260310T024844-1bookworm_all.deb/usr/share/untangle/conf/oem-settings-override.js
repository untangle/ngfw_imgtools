{
  "NetworkSettings": {
    "update":
      { "hostName": "BR1000", "domainName": "routerlogin.com", "publicUrlAddress": "BR1000.routerlogin.com" },
    "interfaces": {
      "list": [{
        "find":
          { "systemDev": "eth0" },
        "change":
          { "name": "WAN1" }
        },{
        "find":
          { "systemDev": "eth1" },
        "change":
          {
            "name": "LAN1",
            "v4StaticAddress": "192.168.1.1",
            "dhcpRangeStart": "192.168.1.10",
            "dhcpRangeEnd": "192.168.1.250",
            "dhcpLeaseDuration": 3600,
            "dhcpEnabled": true
          }
        },{
        "find":
          { "systemDev": "eth2" },
        "change":
          { 
            "name": "LAN2",
            "configType": "BRIDGED",
            "bridgedTo": 2,
            "v4ConfigType": "STATIC",
            "v6ConfigType": "STATIC"
          }
        },{
        "find":
          { "systemDev": "eth3" },
        "change":
          { 
            "name": "WAN2_LAN3",
	    "configType": "BRIDGED",
            "bridgedTo": 2,
            "v4ConfigType": "STATIC",
            "v6ConfigType": "STATIC"
	  }
      }]
    },
    "dnsSettings": {
      "staticEntries": {
        "insert": {
          "list": [
            { "address": "192.168.1.1", "javaClass": "com.untangle.uvm.network.DnsStaticEntry", "name": "routerlogin.com" },
            { "address": "192.168.1.1", "javaClass": "com.untangle.uvm.network.DnsStaticEntry", "name": "routerlogin.net" }
          ]
        }
      }
    }
  },
  "AdminSettings": {
    "users": {
      "list": [{
      "find":
        { "username": "admin" },
      "change":
        { "password": "password" }
      }]
    }
  },
  "ReportsSettings": {
    "update":
      { "dbRetention": 1, "dbRetentionHourly": 0 }
  }
}
