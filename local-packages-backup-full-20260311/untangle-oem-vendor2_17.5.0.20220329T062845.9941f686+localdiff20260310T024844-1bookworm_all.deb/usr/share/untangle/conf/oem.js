{
    "javaClass": "com.untangle.uvm.OemSettings",
    "oemName": "NETGEAR BR1000",
    "oemShortName": "NETGEAR",
    "oemProductName": "BR1000 Business Router",
    "oemUrl": "http://www.netgear.com",
    "licenseAgreementUrl": "https://www.netgear.com/about/terms-and-conditions",
    "useLocalEula": true
}
