#include <linux/init.h>
#include <linux/module.h>
#include <linux/gpio/driver.h>
#include <linux/gpio.h>
#include <linux/module.h>

#include <linux/input-event-codes.h>

#include "version.h"
#include "platform_device.h"

struct gpio_keys_button {
  /* Configuration parameters */
  int code;  /* input event code (KEY_*, SW_*) */
  int gpio;
  int active_low;
  char *desc;
  int type;  /* input event type (EV_KEY, EV_SW) */
  int wakeup;  /* configure the button as a wake-up source */
  int debounce_interval; /* debounce ticks interval in msecs */
  bool can_disable;
 };

struct gpio_keys_platform_data {
  struct gpio_keys_button *buttons;
  int nbuttons;
  unsigned int poll_interval; /* polling interval in msecs -
         for polling driver only */
  unsigned int rep:1;  /* enable input subsystem auto repeat */
  int (*enable)(struct device *dev);
  void (*disable)(struct device *dev);
 };

// GPIO identifier
#define RSTBTN_GPIO 292

static struct gpio_keys_button buttons_table[] = {
        {
                .code           = KEY_RESTART,
                .gpio           = RSTBTN_GPIO,
                .desc           = "BR1000_RSTBTN_GPIO-L",
                .active_low     = 1,
                .wakeup         = 0,
                .debounce_interval = 100,
        },
};

static struct gpio_keys_platform_data button_data = {
        .buttons        = buttons_table,
        .nbuttons       = ARRAY_SIZE(buttons_table),
};

static struct platform_device gpio_keys_pdata = {
        // Apparently this is a special name that maps button to /dev/input/event.
        // Any other name loads and gpio can work through that subsystem, but an event
        // will not be created.
        .name           = "gpio-keys",
        .id             = -1,
        .dev            = {
                .platform_data  = &button_data,
        },
};

static int mod_init (void){
        platform_device_register(&gpio_keys_pdata);
        return 0;
}
module_init(mod_init);
MODULE_LICENSE("GPL v2");
MODULE_DESCRIPTION("BR1000 RESET BUTTON GPIO");
MODULE_AUTHOR("Chris Blaise <cblaise@untangle.com>");
MODULE_VERSION(BR1000_VERSION);
MODULE_INFO(intree, "Y");
