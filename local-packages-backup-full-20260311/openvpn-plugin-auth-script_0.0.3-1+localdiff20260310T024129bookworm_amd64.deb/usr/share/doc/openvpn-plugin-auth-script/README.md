# OpenVPN Auth Script Plugin

This is based on two sources:

https://github.com/fac/auth-script-openvpn
This is the original source code for the plugin.

https://github.com/troyready/auth-script-openvpn
This has the Debian build infrastructure.  
HOWEVER, it was never updated to the latest plugin source code.
This is critical because the latest plugin souce code contains support for multiple arguments which we use for our call.

The original source has not been updated for five years at the time of this update.
I suspect any further work will just be us extending via patches.
