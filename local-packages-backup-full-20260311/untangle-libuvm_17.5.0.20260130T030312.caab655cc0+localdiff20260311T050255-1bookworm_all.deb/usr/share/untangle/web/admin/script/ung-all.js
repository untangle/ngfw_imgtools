Ext.define('EXTJS_23846.Element', {
    override: 'Ext.dom.Element'
}, function(Element) {
    var supports = Ext.supports,
        proto = Element.prototype,
        eventMap = proto.eventMap,
        additiveEvents = proto.additiveEvents;

    if (Ext.os.is.Desktop && supports.TouchEvents && !supports.PointerEvents) {
        eventMap.touchstart = 'mousedown';
        eventMap.touchmove = 'mousemove';
        eventMap.touchend = 'mouseup';
        eventMap.touchcancel = 'mouseup';

        additiveEvents.mousedown = 'mousedown';
        additiveEvents.mousemove = 'mousemove';
        additiveEvents.mouseup = 'mouseup';
        additiveEvents.touchstart = 'touchstart';
        additiveEvents.touchmove = 'touchmove';
        additiveEvents.touchend = 'touchend';
        additiveEvents.touchcancel = 'touchcancel';

        additiveEvents.pointerdown = 'mousedown';
        additiveEvents.pointermove = 'mousemove';
        additiveEvents.pointerup = 'mouseup';
        additiveEvents.pointercancel = 'mouseup';
    }
});

Ext.define('EXTJS_23846.Gesture', {
    override: 'Ext.event.publisher.Gesture'
}, function(Gesture) {
    var me = Gesture.instance;

    if (Ext.supports.TouchEvents && !Ext.isWebKit && Ext.os.is.Desktop) {
        me.handledDomEvents.push('mousedown', 'mousemove', 'mouseup');
        me.registerEvents();
    }
});
Ext.define('Ung.overrides.LoadMask', {
    override: 'Ext.LoadMask',

    msg: '',

    renderTpl: [
        '<div id="{id}-msgWrapEl" data-ref="msgWrapEl" class="{[values.$comp.msgWrapCls]}" role="presentation">',
        '<div id="{id}-msgEl" data-ref="msgEl" class="{[values.$comp.msgCls]} ',
        Ext.baseCSSPrefix, 'mask-msg-inner {childElCls}" role="presentation">',
        '<i class="fa fa-spinner fa-spin fa-2x fa-fw"></i>',
        '<div id="{id}-msgTextEl" data-ref="msgTextEl" class="',
        Ext.baseCSSPrefix, 'mask-msg-text',
        '{childElCls}" role="presentation">{msg}</div>',
        '</div>',
        '</div>'
    ],


});
Ext.define('Ung.overrides.String', {
    override: 'Ext.String',

    /**
     * Convert an array of strings to a single camel-case string.
     *
     * Example:
     * Ext.String.camelCase(['get','wanStatus'])
     * getWanStatus 
     */
    camelCase: function(stringArray){
        return stringArray.join(' ').replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, function(match, index) {
            if (+match === 0){ 
                return "";
            } // or if (/\s+/.test(match)) for white spaces
            return index == 0 ? match.toLowerCase() : match.toUpperCase();
        });
    }
});Ext.define('Ung.overrides.container.Container', {
    override: 'Ext.container.Container',

    /**
     * @protected
     * Used by {@link Ext.ComponentQuery ComponentQuery}, {@link #child} and {@link #down} to retrieve all of the items
     * which can potentially be considered a child of this Container.
     *
     * This may be overriden by Components which have ownership of Components
     * that are not contained in the {@link #property-items} collection.
     *
     * NOTE: IMPORTANT note for maintainers:
     * Items are returned in tree traversal order. Each item is appended to the result array
     * followed by the results of that child's getRefItems call.
     * Floating child items are appended after internal child items.
     */
    getRefItems: function(deep) {
        var me = this,
            items = me.items.items,
            len = items.length,
            i = 0,
            item,
            result = [];
        for (; i < len; i++) {
            item = items[i];
            result[result.length] = item;
            if (deep && item.getRefItems && item.items) {
                result.push.apply(result, item.getRefItems(true));
            }
        }
        // Append floating items to the list.
        if (me.floatingItems) {
            items = me.floatingItems.items;
            len = items.length;
            for (i = 0; i < len; i++) {
                item = items[i];
                result[result.length] = item;
                if (deep && item.getRefItems) {
                    result.push.apply(result, item.getRefItems(true));
                }
            }
        }
        return result;
    },

});Ext.define('Ung.overrides.data.SortTypes', {
    override: 'Ext.data.SortTypes',

    asTimestamp: function(value) {
        if( value &&
            ( typeof( value ) == 'object' ) &&
            value.time ){
            value = value.time;
        }
        return value;
    },

    // Ip address sorting. may contain netmask.
    asIp: function(value){
        if(Ext.isEmpty(value)) {
            return null;
        }
        var i,
            len,
            parts = ( "" + value ).replace(/\//g,".").split('.');
        for(i = 0, len = parts.length; i < len; i++){
            parts[i] = Ext.String.leftPad(parts[i], 3, '0');
        }
        return parts.join('.');
    },

    // Ext string sorter by default considers null characters as as highest precidence
    // so if you sort ascending, you see empty values first (e.g.,null, a, b, c)
    //
    // However, we almost never want to see empty values first as
    // they're effectively meaningless.  We'd rather see those values
    // considered at lowest precidence (e.g., x, y, z, null).
    asUnString: function(s) {
        return ( ( s != null ) && !Ext.isEmpty(s) ) ? String(s).toUpperCase() : '~';
    },

    // combines the IP and String sorting
    asHostname: function (s) {
        if (!s) { return '\u0000'; }
        if (/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(s)) {
            var i, len, parts = ( "" + s ).replace(/\//g,".").split('.');
            for (i = 0, len = parts.length; i < len; i++) {
                parts[i] = Ext.String.leftPad(parts[i], 3, '0');
            }
            return parts.join('.');
        }
        return String(s).toUpperCase();
    }

});
Ext.define('Ung.overrides.data.Store', {
    override: 'Ext.data.Store',

    loadRecords: function(records, options) {
        var me     = this,
            length = records.length,
            data   = me.getData(),
            addRecords, i, skipSort;

        if (options) {
            addRecords = options.addRecords;
        }

        if (!me.getRemoteSort() && !me.getSortOnLoad()) {
            skipSort = true;
            data.setAutoSort(false);
        }

        if (!addRecords) {
            me.clearData(true);
        }

        // Clear the flag AFTER the stores collection has been cleared down so that
        // observers of that collection know that it was due to a load, and a refresh is imminent.
        me.loading = false;

        me.ignoreCollectionAdd = true;
        me.callObservers('BeforePopulate');
        data.add(records);
        me.ignoreCollectionAdd = false;

        if (skipSort) {
            data.setAutoSort(true);
        }

        for (i = 0; i < length; i++) {
            records[i].join(me);
        }

        ++me.loadCount;
        me.complete = true;

        if (me.hasListeners.datachanged) {
            me.fireEvent('datachanged', me);
        }

        if (me.hasListeners.refresh) {
            me.fireEvent('refresh', me);
        }

        me.callObservers('AfterPopulate');

        me.commitChanges();
    }
});
Ext.define('Ung.overrides.form.CheckboxGroup', {
    override: 'Ext.form.CheckboxGroup',

    setValue: function(value) {
        if(this.useParentDefinition) {
            return this.callParent(arguments);
        }
        var me    = this,
            boxes = me.getBoxes(),
            b,
            bLen  = boxes.length,
            box,
            cbValue;

        me.batchChanges(function() {
            Ext.suspendLayouts();
            for (b = 0; b < bLen; b++) {
                box = boxes[b];
                cbValue = false;

                if (value) {
                    var arr_val = value;
                    if(!Ext.isArray(value)){
                        arr_val = value.split(',');
                    }
                    if (Ext.isArray(arr_val)) {
                        cbValue = Ext.Array.contains(arr_val, box.inputValue);
                    } else {
                        // single value, let the checkbox's own setValue handle conversion
                        cbValue = arr_val;
                    }
                }
                box.setValue(cbValue);
            }
            Ext.resumeLayouts(true);
        });
        return me;
    },

    getValue: function() {
        if(this.useParentDefinition) {
            return this.callParent(arguments);
        }
        var values = [],
            boxes  = this.getBoxes(),
            b,
            bLen   = boxes.length,
            box, name, inputValue, bucket;

        for (b = 0; b < bLen; b++) {
            box        = boxes[b];
            name       = box.getName();
            inputValue = box.inputValue;

            if (box.getValue()) {
                if (values.hasOwnProperty(name)) {
                    bucket = values[name];
                    if (!Ext.isArray(bucket)) {
                        bucket = values[name] = [bucket];
                    }
                    bucket.push(inputValue);
                } else {
                    values.push(inputValue);
                }
            }
        }

        return values.join(',');
    },

});
Ext.define('Ung.overrides.form.field.Date', {
    override: 'Ext.form.field.Date',

    config: {
        format: ''
    }

});
Ext.define('Ung.overrides.form.field.VTypes', {
    override: 'Ext.form.field.VTypes',

    // init: function() {
    //     this.initBundleLoader();
    // },

    mask: {
        macAddrMaskRe: /^[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}:[a-fA-F0-9]{2}$/,
        ip4AddrMaskRe: /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
        ip6AddrMaskRe: /^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/,
        email: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9\*]+\.)+[a-zA-Z]{2,}))$/,
        ipAddrRange: /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)-(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
        cidrRange: /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\/([0-2]?[0-9]|3[0-2])$/,
        ipNetmask: /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\/(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
        openvpnName: /^[A-Za-z0-9]([-.0-9A-Za-z]*[0-9A-Za-z])?$/,
        positiveInteger: /^[0-9]+$/,
        domainNameRe: /^[a-zA-Z0-9\-_.]+$/,
        urlAddrRe: /^(([^:\/?#]+:)?(?:\/\/((?:([^\/?#:]*):([^\/?#:]*)@)?([^\/?#:]*)(?::([^\/?#:]*))?)))?([^?#]*)(\?[^#]*)?(#.*)?$/,
        cidrAddrRe: /^([0-9]{1,3}\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[1-9])(\/([0-9]|[1-2][0-9]|3[0-2]))?$/,
        cidrBlockRe: /^([0-9]{1,3}\.){3}[0-9]{1,3}(\/([0-9]|[1-2][0-9]|3[0-2]))$/,
        cidrBlockOnlyRangeRe: /^([0-9]{1,3}\.){3}[0-9]{1,3}(\/([0-9]|[1-2][0-9]|3[0-1]))$/,
        hostNameRe: /^[a-zA-Z0-9\-_.]+$/
    },

    isSinglePortValid: function(val) {
        if (typeof val === "string")
            val = val.trim();
        /* check for values between 0 and 65536 */
        if (val < 1 || val > 65535) { return false; }
        /* verify its an integer (not a float) */
        if (!/^\d{1,5}$/.test(val)) { return false; }
        return true;
    },
    isSinglePortValidText: 'Invalid port (number between 0 and 65536)'.t(),

    isPortRangeValid: function(val) {
        var portRange = val.split('-');
        if (portRange.length !== 2) { return false; }
        return this.isSinglePortValid(portRange[0]) && this.isSinglePortValid(portRange[1]);
    },
    isPortListValid: function(val) {
        var portList = val.split(','),
            retVal = true, i;
        for (i = 0; i < portList.length; i++) {
            if (portList[i].indexOf('-') !== -1) {
                retVal = retVal && this.isPortRangeValid(portList[i]);
            } else {
                retVal = retVal && this.isSinglePortValid(portList[i]);
            }
            if (!retVal) {
                return false;
            }
        }
        return true;
    },
    isSingleIpValid: function(val) {
        return this.mask.ip4AddrMaskRe.test(val);
    },
    isSingleIpValidText: 'Invalid IP address.'.t(),

    isSingleIpValidOrEmpty: function(val){
        if(val == ''){
            return true;
        }
        return this.mask.ip4AddrMaskRe.test(val);
    },
    isSingleIpValidOrEmptyText: 'Valut must either empty or IP address'.t(),


    isIpRangeValid: function(val) {
        var ipRangeArr = val.split('-');
        if (ipRangeArr.length != 2) {
            // invalid range
            return false;
        }
        if (Util.convertIPIntoDecimal(ipRangeArr[0]) > Util.convertIPIntoDecimal(ipRangeArr[1])) {
            // min IP in the range is grater than max IP
            return false;
        }
        return this.mask.ipAddrRange.test(val);
    },
    isCIDRValid: function(val) {
        return this.mask.cidrRange.test(val);
    },
    isIpNetmaskValid:function(val) {
        return this.mask.ipNetmask.test(val);
    },
    isIpListValid: function(val) {
        var ipList = val.split(','),
            retVal = true, i;
        for (i = 0; i < ipList.length; i += 1) {
            if (ipList[i].indexOf('-') !== -1) {
                retVal = retVal && this.isIpRangeValid(ipList[i]);
            } else {
                if (ipList[i].indexOf('/') !== -1) {
                    retVal = retVal && ( this.isCIDRValid(ipList[i]) || this.isIpNetmaskValid(ipList[i]));
                } else {
                    retVal = retVal && this.isSingleIpValid(ipList[i]);
                }
            }
            if (!retVal) {
                return false;
            }
        }
        return true;
    },


    // matchers
    email: function (v) {
        return this.mask.email.test(v);
    },
    emailText: 'You must provide a valid login name or email address.'.t(),

    // matchers
    emailwildcard: function (v) {
        return v == '*' || this.mask.email.test(v);
    },
    emailwildcardText: 'You must provide an email address or wildcard.'.t(),
    
    /**
     * The ipOrUrl VType can validate IP addresses and also URLs
     * 
     * @param {string} val - the input URL or  IP Address
     */
    ipOrUrl: function(val) {
        return this.ip4Address(val) || this.ip6Address(val) || this.url(val);
    },
    ipOrUrlText: 'Not a valid IP or URL'.t(),

    /**
     * 
     * the url VType can validate URL addresses with or without http/https
     * 
     * @param {string} val - the input url 
     */
    url: function(val) {
        return this.mask.urlAddrRe.test(val);
    },
    urlText: 'Not a valid URL'.t(),

    ipMatcher: function(val) {
        if (val.indexOf('/') === -1 && val.indexOf(',') === -1 && val.indexOf('-') === -1) {
            switch (val) {
            case 'any':
                return true;
            default:
                return this.isSingleIpValid(val);
            }
        }
        if (val.indexOf(',') !== -1) {
            return this.isIpListValid(val);
        } else {
            if (val.indexOf('-') !== -1) {
                return this.isIpRangeValid(val);
            }
            if (val.indexOf('/') !== -1) {
                var cidrValid = this.isCIDRValid(val);
                var ipNetmaskValid = this.isIpNetmaskValid(val);
                return cidrValid || ipNetmaskValid;
            }
            console.log('Unhandled case while handling vtype for ipAddr:', val, ' returning true !');
            return true;
        }
    },
    ipMatcherText: 'Invalid IP address range, must be in ascending order.'.t(),

    ip4Address: function (val) {
        return this.mask.ip4AddrMaskRe.test(val);
    },
    ip4AddressText: 'Invalid IPv4 Address.'.t(),

    ip4AddExcldDflt: function (val) {
        return this.ip4Address(val) && (val != '0.0.0.0');
    },
    ip4AddExcldDfltText: 'Invalid IPv4 Address, Default route not allowed'.t(),

    ip4AddressList:  function (v) {
        var addr = v.split(','), i;
        for (i = 0 ; i < addr.length ; i += 1) {
            if (!this.mask.ip4AddrMaskRe.test(addr[i])) {
                return false;
            }
        }
        return true;
    },
    ip4AddressListText: 'Invalid IPv4 Address(es).'.t(),

    dhcpAddress:  function (val) {
        return this.mask.ip4AddrMaskRe.test(val);
    },
    dhcpAddressText: 'Invalid DHCP Address(es).'.t(),

    ip6Address: function (val) {
        return this.mask.ip6AddrMaskRe.test(val);
    },
    ip6AddressText: 'Invalid IPv6 Address.'.t(),

    ipAddress: function (val) {
        return this.mask.ip4AddrMaskRe.test(val) || this.mask.ip6AddrMaskRe.test(val);
    },
    ipAddressText: 'Invalid IP Address.'.t(),

    macAddress: function (val) {
        return this.mask.macAddrMaskRe.test(val);
    },
    macAddressText: 'Invalid Mac Address.'.t(),

    openvpnName: function (val) {
        return this.mask.openvpnName.test(val);

    },
    openvpnNameText: 'A name should only contains numbers, letters, dashes and periods.  Spaces are not allowed.'.t(),

    cidrBlockOnlyRanges: function(v) {
        return (this.mask.cidrBlockOnlyRangeRe.test(v));
    },

    cidrBlockOnlyRangesText: 'Must be a network in CIDR format, excluding /32 addresses.'.t() + ' (192.168.123.0/24)',

    domainName: function(value) {
        if (value.charAt(0) === '.') {
            return(false);
        }
        return this.mask.domainNameRe.test(value);
    },
    domainNameText: 'A domain can only contain numbers, letters, dashes and periods, and must not start with a period.'.t(),

    cidrBlock:  function (v) {
        return (this.mask.cidrBlockRe.test(v));
    },
    cidrBlockText: 'Must be a network in CIDR format.'.t() + ' ' + '(192.168.123.0/24)',

    cidrBlockList: function (v) {
        var blocks = v.split(','), i;
        for (i = 0 ; i < blocks.length; i += 1) {
            if (!(this.mask.cidrBlockRe.test(blocks[i]))) {
                return false;
            }
        }
        return true;
    },
    cidrBlockListText: 'Must be a comma seperated list of networks in CIDR format.'.t() + ' ' + '(192.168.123.0/24,1.2.3.4/24)',

    cidrBlockArea:  function (v) {
        var blocks = v.split('\n'), i;
        for (i = 0 ; i < blocks.length; i += 1) {
            if (!(this.mask.cidrBlockRe.test(blocks[i]))) {
                return false;
            }
        }
        return true;
    },
    cidrBlockAreaText: 'Must be a one-per-line list of networks in CIDR format.'.t() + ' ' + '(192.168.123.0/24)',

    cidrAddr:  function (v) {
        return (this.mask.cidrAddrRe.test(v));
    },
    cidrAddrText: 'Must be an address in CIDR format where the last octet is not zero.'.t() + ' ' + '(192.168.123.1/24)',

    portMatcher: function (val) {
        switch (val) {
        case 'any':
            return true;
        default:
            if (val.indexOf('>=') !== -1 && val.indexOf(',') === -1) {
                return this.isSinglePortValid( val.substring( val.indexOf('>=') + 2 ));
            }
            if (val.indexOf('<=') !== -1 && val.indexOf(',') === -1) {
                return this.isSinglePortValid( val.substring( val.indexOf('<=') + 2 ));
            }
            if (val.indexOf('>') !== -1 && val.indexOf(',') === -1) {
                return this.isSinglePortValid( /^(\s*)$/.test( val.substring( val.indexOf('>') + 1 ) ) ? 0 : Number( val.substring( val.indexOf('>') + 1 ) ) + 1 );
            }
            if (val.indexOf('<') !== -1 && val.indexOf(',') === -1) {
                return this.isSinglePortValid( val.substring( val.indexOf('<') + 1 ) -1 );
            }
            if (val.indexOf('-') === -1 && val.indexOf(',') === -1) {
                return this.isSinglePortValid(val);
            }
            if (val.indexOf('-') !== -1 && val.indexOf(',') === -1) {
                return this.isPortRangeValid(val);
            }
            return this.isPortListValid(val);
        }
    },
    portMatcherText: Ext.String.format('The port must be an integer number between {0} and {1}.'.t(), 1, 65535),

    port: function (val) {
        var minValue = 1,
            maxValue = 65535;
        return (minValue <= val && val <= maxValue);
    },
    portText: Ext.String.format('The port must be an integer number between {0} and {1} or one of the following values: any, all, n/a, none.'.t(), 1, 65535),

    x500attributes: function(val){
        if(val == ''){
            return false;
        }
        var valid = true;
        val.split(',').forEach(function(attribute){
            /*
             * Various LDAP implementations may have attribute keys beyond
             * what's defined in RFC 2253.  Instead of hunting them all
             * down, verify they are of a <key>=<value> format.
             */
            if(attribute.split('=').length != 2 ){
                valid = false;
            }
        });
        return valid;
    },
    x500attributesText: 'Invalid x500 attribute found'.t(),

    // BPP/OSPF router id
    routerId: function(value){
        return this.mask.ip4AddrMaskRe.test(value);
    },
    routerIdText: 'Invalid Router ID'.t(),

    // OSPF area id
    routerArea: function(value){
        return this.mask.ip4AddrMaskRe.test(value);
    },
    routerAreaText: 'Invalid Area'.t(),

    // BPP/OSPF router AS
    routerAs: function(value){
        if(isNaN(value) || ( this.mask.positiveInteger.test(value) == false ) ){
            return false;
        }
        var number = parseInt(value, 10);
        return (number > 0) && (number <= 4294967295);
    },
    routerAsText: 'Invalid Router AS'.t(),

    metric: function(value){
        if(isNaN(value) || ( this.mask.positiveInteger.test(value) == false ) ){
            return false;
        }
        var number = parseInt(value, 10);
        return (number >= 0) && (number <= 16777214);
    },
    metricText: 'Invalid metric number'.t(),

    routerInterval: function(value){
        if(isNaN(value) || ( this.mask.positiveInteger.test(value) == false ) ){
            return false;
        }
        var number = parseInt(value, 10);
        return (number > 0) && (number <= 65535);
    },
    routerIntervalText: 'Invalid interval'.t(),

    routerPriority: function(value){
        if(isNaN(value) || ( this.mask.positiveInteger.test(value) == false ) ){
            return false;
        }
        var number = parseInt(value, 10);
        return (number >= 0) && (number <= 65535);
    },
    routerPriorityText: 'Invalid router priority'.t(),

    routerAutoCost: function(value){
        if(isNaN(value) || ( this.mask.positiveInteger.test(value) == false ) ){
            return false;
        }
        var number = parseInt(value, 10);
        return (number >= 0) && (number <= 4294967);
    },
    routerAutoCostText: 'Invalid auto cost reference bandwidth'.t(),

    mtu: function(value){
        if(isNaN(value) || ( this.mask.positiveInteger.test(value) == false ) ){
            return false;
        }
        var number = parseInt(value, 10);
        return (number == 0 || number >= 68);
    },
    mtuText: 'Invalid value (integer above 68, 0 for default)'.t(),

    keepalive: function(value) {
        if(isNaN(value) || ( this.mask.positiveInteger.test(value) == false ) ){
            return false;
        }
        return true;
    },
    keepaliveText: 'Keepalive must be a number or 0 to disable.'.t(),

    wireguardPublicKey: function(value){
        return (value.length == 44) ? true : false;
    },
    wireguardPublicKeyText: 'Public key must be 44 characters long.'.t(),

    hostName: function(value) {
        if (value.charAt(0) === '.') {
            return false;
        }
        return this.mask.hostNameRe.test(value);
    },
    hostNameText: 'A hostname can only contain numbers, letters, dashes and periods and cannot begin with a period'.t(),
});
Ext.define('Ung.overrides.grid.RowContext', {
    override: 'Ext.grid.RowContext',

    free: function () {
        var viewModel = this.viewModel;
        if (viewModel && viewModel.destroyed) {
            this.viewModel = null;
        }

        return this.callParent(arguments);
    }
});
Ext.define('Ung.overrides.panel.Panel', {
    override: 'Ext.panel.Panel',
    listeners:{
        afterlayout: function(){
            if(Ext.String.startsWith(this.$className, 'Ung.config') ||
               Ext.String.startsWith(this.$className, 'Ung.apps') ||
               Ext.String.startsWith(this.$className, 'Ung.view.extra')){
                var me = this;
                if(!me.scrollableTaskRan){
                    if(!me.scrollableTask){
                        me.scrollableTask = new Ext.util.DelayedTask( Ext.bind(function(){
                            if(Util.isDestroyed(me)){
                                return;
                            }
                            if(this.container && this.container.dom){
                                me.setScrollable('y');
                            }
                            me.scrollableTaskRan = true;
                        }, me) );
                    }
                    me.scrollableTask.delay( 100 );
                }
            }
        }
    }
});Ext.define('Ung.overrides.picker.Date', {
    override: 'Ext.picker.Date',
    beforeRender: function() {
        /*
         * days array for looping through 6 full weeks (6 weeks * 7 days)
         * Note that we explicitly force the size here so the template creates
         * all the appropriate cells.
         */
        var me = this,
            encode = Ext.String.htmlEncode,
            days = new Array(me.numDays),
            offset = (new Date().getTimezoneOffset() * 60000) + Rpc.directData('rpc.timeZoneOffset'),
            todayDate = new Date();
        todayDate.setTime( todayDate.getTime() + offset);
        var today = Ext.Date.format(todayDate, me.format);
        if (me.padding && !me.width) {
            me.cacheWidth();
        }
        me.monthBtn = new Ext.button.Split({
            ownerCt: me,
            ownerLayout: me.getComponentLayout(),
            text: '',
            tooltip: me.monthYearText,
            tabIndex: -1,
            ariaRole: 'presentation',
            listeners: {
                click: me.doShowMonthPicker,
                arrowclick: me.doShowMonthPicker,
                scope: me
            }
        });
        if (me.showToday) {
            me.todayBtn = new Ext.button.Button({
                ui: me.footerButtonUI,
                ownerCt: me,
                ownerLayout: me.getComponentLayout(),
                text: Ext.String.format(me.todayText, today),
                tooltip: Ext.String.format(me.todayTip, today),
                tooltipType: 'title',
                tabIndex: -1,
                ariaRole: 'presentation',
                handler: me.selectToday,
                scope: me
            });
        }
        me.callParent();
        Ext.applyIf(me, {
            renderData: {}
        });
        Ext.apply(me.renderData, {
            dayNames: me.dayNames,
            showToday: me.showToday,
            prevText: encode(me.prevText),
            nextText: encode(me.nextText),
            todayText: encode(me.todayText),
            ariaMinText: encode(me.ariaMinText),
            ariaMaxText: encode(me.ariaMaxText),
            ariaDisabledDaysText: encode(me.ariaDisabledDaysText),
            ariaDisabledDatesText: encode(me.ariaDisabledDatesText),
            days: days
        });
        me.protoEl.unselectable();
    }
});Ext.define ('Ung.model.AppMetric', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'displayName', type: 'string' },
        { name: 'name', type: 'string' },
        { name: 'value', type: 'int' },
        { name: 'javaClass', type: 'string', defaultValue: 'com.untangle.uvm.app.AppMetric' }
    ],
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
            //rootProperty: 'list'
        }
    }
});
Ext.define ('Ung.model.AppProperty', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'autoLoad', type: 'bool' },
        { name: 'autoStart', type: 'bool' },
        { name: 'displayName', type: 'string' },
        { name: 'hasPowerButton', type: 'bool' },
        { name: 'invisible', type: 'bool' },
        { name: 'name', type: 'string' },
        { name: 'appBase', type: 'string' },
        { name: 'parents', type: 'auto' },
        { name: 'supportedArchitectures', type: 'auto' },
        { name: 'type', type: 'string' },
        { name: 'viewPosition', type: 'int' },
        { name: 'className', type: 'string' },
        { name: 'javaClass', type: 'string', defaultValue: 'com.untangle.uvm.app.AppProperties' }
    ]
});
Ext.define ('Ung.model.AppState', {
    extend: 'Ext.data.Model' ,
    fields: [{
        name: 'on',
        type: 'boolean',
        defaultValue: false
    }, {
        name: 'inconsistent',
        type: 'boolean',
        defaultValue: false
    }, {
        name: 'expired',
        type: 'boolean',
        defaultValue: false
    },{
        name: 'power',
        type: 'boolean',
        defaultValue: false
    }, {
        name: 'colorCls',
        type: 'string',
        calculate: function(data){
            if(data.inconsistent || data.expired){
                return 'fa-red';
            }else if(data.power){
                return 'fa-orange';
            }else if(data.on){
                return 'fa-green';
            }else{
                return 'fa-gray';
            }
        }
    }, {
        name: 'status',
        type: 'string',
        calculate: function(data){
            if(data.on){
                if(data.power){
                    return 'Powering on'.t();
                }else if(data.inconsistent){
                    return 'Enabled but is not active'.t();
                }else{
                    return 'Enabled'.t();
                }
            }else{
                if(data.power){
                    return 'Powering off'.t();
                }else if(data.expired){
                    return 'Disabled, license is invalid or expired'.t();
                }else if(data.inconsistent){
                    return 'Disabled but active'.t();
                }else{
                    return 'Disabled'.t();
                }
            }
        }
    }],
    detect: function(){
        var on = false;
        var inconsistent = false;
        var licenseExpired = false;
        if( ( this.vm && !Util.isDestroyed(this.vm) ) || 
            ( this.instance && !Util.isDestroyed(this.instance)) ){
            var targetState = this.vm ? this.vm.get('instance.targetState') : this.instance.targetState;

            var runState = this.app ? this.app.getRunState() : ( this.vm ? this.vm.get('runState') : this.instance.runState );

            on = ( runState == 'RUNNING' );
            var daemonRunning = (on && this.vm && this.vm.get('props.daemon') != null) ? Rpc.directData('rpc.UvmContext.daemonManager.isRunning', this.vm.get('props.daemon') ) : true;

            inconsistent = (targetState != runState) || (runState == 'RUNNING' && !daemonRunning);

            var appName = "";
            if (this.vm != null ) {
                appName = this.vm.get('app.name') ? this.vm.get('app.name'): this.vm.get('urlName');
                licenseExpired = !Rpc.directData('rpc.UvmContext.licenseManager.isLicenseValid', appName); 
            }
        }
        this.set({
            'expired': licenseExpired,
            'on': on,
            'inconsistent': inconsistent,
            'power': false
        });
    },
    vm: null,
    instance: null,
    app: null,
    constructor: function( args, session){
        if(args['vm']){
            this.vm = args['vm'];            
        }else if( args['instance'] ){
            this.instance = args['instance'];
        }
        if(args.app){
            this.app = args['app'];
        }
        this.callParent([{}], session);
        this.detect();
    },
});
Ext.define ('Ung.model.Condition', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'javaClass', type: 'string'},
        { name: 'conditionType', type: 'string' },
        { name: 'invert', type: 'boolean', defaultValue: false },
        { name: 'value', type: 'auto', defaultValue: '' }
    ],
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});
Ext.define ('Ung.model.GenericRule', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'name', type: 'string', defaultValue: null },
        { name: 'string', type: 'string', defaultValue: '' },
        { name: 'blocked', type: 'boolean', defaultValue: true },
        { name: 'flagged', type: 'boolean', defaultValue: true },
        { name: 'category', type: 'string', defaultValue: null },
        { name: 'description', type: 'string', defaultValue: '' },
        { name: 'enabled', type: 'boolean', defaultValue: true },
        { name: 'id', defaultValue: null },
        { name: 'readOnly', type: 'boolean', defaultValue: null },
        { name: 'javaClass', type: 'string', defaultValue: 'com.untangle.uvm.app.GenericRule' }
    ],
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
            //rootProperty: 'list'
        }
    }
});
Ext.define ('Ung.model.Interface', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'addressed', type: 'boolean', defaultValue: true },
        { name: 'bridged', type: 'boolean', defaultValue: false },
        { name: 'bridgedTo', type: 'auto', defaultValue: null },
        { name: 'configType', type: 'string' },

        { name: 'dhcpDnsOverride', type: 'string' },
        { name: 'dhcpType', type: 'string', defaultValue: "DISABLED" },
        { name: 'dhcpGatewayOverride', type: 'auto', defaultValue: null },
        { name: 'dhcpLeaseDuration', type: 'number', defaultValue: null },
        { name: 'dhcpNetmaskDuration', type: 'auto', defaultValue: null },
        { name: 'dhcpOptions', type: 'auto', defaultValue: { javaClass: 'java.util.LinkedList', list: [] } }, // collection
        { name: 'dhcpPrefixOverride', type: 'auto', defaultValue: null },
        { name: 'dhcpRangeEnd', type: 'string', defaultValue: null },
        { name: 'dhcpRangeStart', type: 'string', defaultValue: null },

        { name: 'disabled', type: 'boolean', defaultValue: false },
        { name: 'downloadBandwidthKbps', type: 'number' },
        { name: 'hidden', type: 'boolean', defaultValue: null },
        { name: 'imqDev', type: 'string' },
        { name: 'interfaceId', type: 'number', defaultValue: -1 },

        { name: 'isVlanInterface', type: 'boolean' },
        { name: 'isWan', type: 'boolean' },
        { name: 'isWirelessInterface', type: 'boolean' },

        { name: 'javaClass', type: 'string', defaultValue: 'com.untangle.uvm.network.InterfaceSettings' },
        { name: 'name', type: 'string', defaultValue: '' },
        { name: 'physicalDev', type: 'string' },
        { name: 'reEnabled', type: 'boolean', defaultValue: false },
        { name: 'supportedConfigTypes', type: 'auto', defaultValue: null },
        { name: 'symbolicDev', type: 'string' },
        { name: 'systemDev', type: 'string' },
        { name: 'uploadBandwidthKbps', type: 'number' },

        { name: 'v4Aliases', type: 'auto', defaultValue: { javaClass: 'java.util.LinkedList', list: [] } }, // collection
        { name: 'v4AutoAddressOverride', type: 'string', defaultValue: null },
        { name: 'v4AutoDns1Override', type: 'string', defaultValue: null },
        { name: 'v4AutoDns2Override', type: 'string', defaultValue: null },
        { name: 'v4AutoGatewayOverride', type: 'string', defaultValue: null },
        { name: 'v4AutoNetmaskOverride', type: 'string', defaultValue: null },
        { name: 'v4AutoPrefixOverride', type: 'string', defaultValue: null },
        { name: 'v4ConfigType', type: 'string' },
        { name: 'v4NatEgressTraffic', type: 'boolean', defaultValue: true },
        { name: 'v4NatIngressTraffic', type: 'boolean', defaultValue: false },
        { name: 'v4PPPoEDns1', type: 'string', defaultValue: null },
        { name: 'v4PPPoEDns2', type: 'string', defaultValue: null },
        { name: 'v4PPPoEPassword', type: 'string', defaultValue: '' },
        { name: 'v4PPPoERootDev', type: 'string', defaultValue: null },
        { name: 'v4PPPoEUsePeerDns', type: 'boolean', defaultValue: false },
        { name: 'v4PPPoEUsername', type: 'string', defaultValue: '' },
        { name: 'v4StaticAddress', type: 'string', defaultValue: null },
        { name: 'v4StaticDns1', type: 'string', defaultValue: null },
        { name: 'v4StaticDns2', type: 'string', defaultValue: null },
        { name: 'v4StaticGateway', type: 'string', defaultValue: null },
        { name: 'v4StaticNetmask', type: 'string', defaultValue: null },
        { name: 'v4StaticPrefix', type: 'string', defaultValue: null },

        { name: 'v6Aliases', type: 'auto', defaultValue: { javaClass: 'java.util.LinkedList', list: [] } }, // collection
        { name: 'v6ConfigType', type: 'string' },
        { name: 'v6StaticAddress', type: 'string', defaultValue: null },
        { name: 'v6StaticDns1', type: 'string', defaultValue: null },
        { name: 'v6StaticDns2', type: 'string', defaultValue: null },
        { name: 'v6StaticGateway', type: 'string', defaultValue: null },
        { name: 'v6StaticPrefixLength', type: 'string', defaultValue: null },

        { name: 'vlanParent', type: 'number', defaultValue: null },
        { name: 'vlanTag', type: 'number', defaultValue: null },

        { name: 'vrrpAliases', type: 'auto', defaultValue: { javaClass: 'java.util.LinkedList', list: [] } }, // collection
        { name: 'vrrpEnabled', type: 'boolean', defaultValue: false },
        { name: 'vrrpId', type: 'auto', defaultValue: null },
        { name: 'vrrpPriority', type: 'auto', defaultValue: null },

        { name: 'wirelessChannel', type: 'auto', defaultValue: null },
        { name: 'wirelessEncryption', type: 'auto', defaultValue: null },
        { name: 'wirelessPassword', type: 'string', defaultValue: '' },
        { name: 'wirelessSsid', type: 'string', defaultValue: '' },
        { name: 'wirelessLogLevel', type: 'number', defaultValue: 2 },

        // status fields
        { name: 'v4Address', type: 'string', defaultValue: null },
        { name: 'v4Dns1', type: 'string', defaultValue: null },
        { name: 'v4Dns2', type: 'string', defaultValue: null },
        { name: 'v4Gateway', type: 'string', defaultValue: null },
        { name: 'v4Netmask', type: 'string', defaultValue: null },
        { name: 'v4PrefixLength', type: 'string', defaultValue: null },
        { name: 'v6Address', type: 'string', defaultValue: null },
        { name: 'v6Gateway', type: 'string', defaultValue: null },
        { name: 'v6PrefixLength', type: 'string', defaultValue: null },

        // device fields
        { name: 'connected', type: 'string', defaultValue: null },
        { name: 'deviceName', type: 'string', defaultValue: null },
        { name: 'duplex', type: 'string' },
        { name: 'macAddress', type: 'string', defaultValue: null },
        { name: 'mbit', type: 'number', defaultValue: null },
        { name: 'vendor', type: 'string', defaultValue: null },
    ],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});
Ext.define('Ung.model.LocalDirectoryUser', {
    extend: 'Ext.data.Model' ,

    alias: 'model.local-directoryuser',

    fields: [
        { name: 'username' },
        { name: 'expirationTime' },
        { name: 'lastName' },
        { name: 'markedForDelete', defaultValue: false },
        { name: 'markedForNew', defaultValue: false },
        { name: 'test', defaultValue: 'sometest' },
        { name: 'dt', type: 'string', claculate: function (data) {
            return data.lastName + ' ';
        },
            depends : ['lastName']
        },
    ],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});
Ext.define ('Ung.model.Policy', {
    extend: 'Ext.data.Model' ,
    fields: [
        {name: 'policyId', type: 'int'},
        {name: 'displayName', type: 'string', convert: function (value, record) {
            return 'Policy ' + record.get('policyId');
        }}
    ],
    hasMany: {
        model: 'Ung.model.AppProperty',
        name: 'appProperties'
    },
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});
Ext.define ('Ung.model.Action', {
    extend: 'Ext.data.Model' ,
    alias: 'model.action',
    fields: [{
        name: 'actionType', type: 'string'
    }, {
        name: 'priority', type: 'int'
    }]
    // proxy: {
    //     // autoLoad: true,
    //     type: 'memory',
    //     reader: {
    //         type: 'json',
    //         // rootProperty: 'list'
    //     }
    // }
});

Ext.define ('Ung.model.Rule', {
    extend: 'Ext.data.Model' ,

    alias: 'model.rule',


    fields: [
        // { name: 'ruleId', type: 'auto', defaultValue: null },
        // { name: 'description', type: 'string', defaultValue: '' },
        // { name: 'enabled', type: 'boolean', defaultValue: true },
        // { name: 'conditions', type: 'auto' },

        { name: 'markedForDelete', defaultValue: false },
        { name: 'markedForNew', defaultValue: false },
        // { name: 'action', reference: 'action'}
        { name: 'actionType', mapping: 'action.actionType' },
        { name: 'priority', mapping: 'action.priority' },

        // { name: 'conditionsMap', mapping: function (data) {
        //     return data.conditions.list;
        // }},
        // { name: 'conditionsList', calculate: function(data) {
        //     //console.log(data);
        //     var conds = data.conditions;
        //     var resp = '', i, cond;
        //     for (i = 0; i < conds.list.length; i += 1) {
        //         cond = conds.list[i];
        //         resp += cond.conditionType + (cond.invert ? ' &ne; ' : ' = ') + cond.value + '<br/>';
        //     }
        //     //console.log(val);
        //     return resp;
        // } },

        // { name: 'markedForDelete', defaultValue: false },
        // { name: 'newDestination' },
        // { name: 'newPort' }
        // { name: 'string', type: 'string', defaultValue: '' },
        // { name: 'blocked', type: 'boolean', defaultValue: true },
        // { name: 'flagged', type: 'boolean', defaultValue: true },
        // { name: 'category', type: 'string', defaultValue: null },
        // { name: 'id', defaultValue: null },
        // { name: 'readOnly', type: 'boolean', defaultValue: null },
        // { name: 'javaClass', type: 'string', defaultValue: 'com.untangle.app.bandwidth_control.BandwidthControlRule' },

        // { name: 'action', type: 'auto'},
        // { name: 'actionType', type: 'string', mapping: 'action.actionType', defaultValue: 'SET_PRIORITY' },
        // { name: 'actionPriority', type: 'int', mapping: 'action.priority', defaultValue: 1 },
        // { name: 'actionPenaltyTime', type: 'int', mapping: 'action.penaltyTime', defaultValue: 0 },
        // { name: 'actionQuotaBytes', type: 'int', mapping: 'action.quotaBytes', defaultValue: 1 },
        // { name: 'actionQuotaTime', type: 'int', mapping: 'action.quotaTime', defaultValue: -1 }
    ],
    // hasMany: 'Ung.model.Condition',
    proxy: {
        // autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json',
            // rootProperty: 'list'
        }
    }
});
Ext.define ('Ung.model.Session', {
    extend: 'Ext.data.Model',
    fields: [
        { name: 'bypassed', type: 'boolean' },
        { name: 'clientCountry', type: 'string' },
        { name: 'clientIntf', type: 'auto' },
        { name: 'clientBps', type: 'number' },
        { name: 'clientLatitude', type: 'number' },
        { name: 'clientLongitude', type: 'number' },
        { name: 'creationTime', type: 'auto' },
        { name: 'hostname', type: 'string' },
        { name: 'localAddr', type: 'auto' },
        { name: 'natted', type: 'boolean' },
        { name: 'pipeline', type: 'auto' },
        { name: 'policy', type: 'auto' },
        { name: 'portForwarded', type: 'boolean' },
        { name: 'postNatClient', type: 'string' },
        { name: 'postNatClientPort', type: 'number' },
        { name: 'postNatServer', type: 'string' },
        { name: 'postNatServerPort', type: 'number' },
        { name: 'preNatClient', type: 'string' },
        { name: 'preNatClientPort', type: 'number' },
        { name: 'preNatServer', type: 'string' },
        { name: 'preNatServerPort', type: 'number' },
        { name: 'priority', type: 'number' },
        { name: 'protocol', type: 'string' },
        { name: 'qosPriority', type: 'number' },
        { name: 'remoteAddr', type: 'auto' },
        { name: 'serverCountry', type: 'string' },
        { name: 'serverIntf', type: 'auto' },
        { name: 'serverBps', type: 'number' },
        { name: 'serverLatitude', type: 'number' },
        { name: 'serverLongitude', type: 'number' },
        { name: 'sessionId', type: 'number' },
        { name: 'state', type: 'auto' },
        { name: 'tags', type: 'auto' },
        { name: 'tagsString', type: 'string' },
        { name: 'totalBps', type: 'number' },
    ],
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
            // rootProperty: 'list'
        }
    }
});
Ext.define ('Ung.model.Stat', {
    extend: 'Ext.data.Model' ,
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    },
    fields: ['numCpus', 'cpuModel', 'MemFree', 'MemTotal', 'SwapFree', 'SwapTotal', 'freeDiskSpace', 'totalDiskSpace', 'uptime',
        {
            name: 'hostname',
            calculate: function () {
                return Rpc.directData('rpc.hostname');
            }
        }, {
            name: 'version',
            calculate: function () {
                return Rpc.directData('rpc.fullVersion');
            }
        }, {
            name: 'appliance',
            calculate: function() {
                var applianceModel = Rpc.directData('rpc.applianceModel');
                return (applianceModel === undefined || applianceModel === null || applianceModel === '' ? 'custom'.t() : applianceModel);
            }
        }, {
            name: 'totalMemory',
            calculate: function (data) {
                return Util.formatBytes(data.MemTotal, 2);
            }
        }, {
            name: 'freeMemory',
            calculate: function (data) {
                return Util.formatBytes(data.MemFree, 2);
            }
        }, {
            name: 'freeMemoryPercent',
            calculate: function (data) {
                // return (Math.random() * 100).toFixed(2);
                return (data.MemFree / data.MemTotal * 100).toFixed(1);
            }
        }, {
            name: 'usedMemory',
            calculate: function (data) {
                return Util.formatBytes(data.MemTotal - data.MemFree, 2);
            }
        }, {
            name: 'usedMemoryPercent',
            calculate: function (data) {
                return ((1 - data.MemFree / data.MemTotal) * 100).toFixed(1);
            }
        }, {
            name: 'totalSwap',
            calculate: function (data) {
                if (data.SwapTotal) {
                    return Util.formatBytes(data.SwapTotal, 2);
                }
                return 0;
            }
        }, {
            name: 'freeSwap',
            calculate: function (data) {
                if (data.SwapTotal) {
                    return Util.formatBytes(data.SwapFree, 2);
                }
                return 0;
            }
        }, {
            name: 'freeSwapPercent',
            calculate: function (data) {
                if (data.SwapTotal) {
                    return (data.SwapFree / data.SwapTotal * 100).toFixed(1);
                }
                return 0;
            }
        }, {
            name: 'usedSwap',
            calculate: function (data) {
                if (data.SwapTotal) {
                    return Util.formatBytes(data.SwapTotal - data.SwapFree, 2);
                }
                return 0;
            }
        }, {
            name: 'usedSwapPercent',
            calculate: function (data) {
                if (data.SwapTotal) {
                    return ((1 - data.SwapFree / data.SwapTotal) * 100).toFixed(1);
                }
                return 0;
            }
        }, {
            name: 'totalDisk',
            calculate: function (data) {
                return Util.formatBytes(data.totalDiskSpace, 2);
            }
        }, {
            name: 'freeDisk',
            calculate: function (data) {
                return Util.formatBytes(data.freeDiskSpace, 2);
            }
        }, {
            name: 'freeDiskPercent',
            calculate: function (data) {
                // return (Math.random() * 100).toFixed(2);
                return (data.freeDiskSpace / data.totalDiskSpace * 100).toFixed(1);
            }
        }, {
            name: 'usedDisk',
            calculate: function (data) {
                return Util.formatBytes(data.totalDiskSpace - data.freeDiskSpace, 2);
            }
        }, {
            name: 'usedDiskPercent',
            calculate: function (data) {
                return ((1 - data.freeDiskSpace / data.totalDiskSpace) * 100).toFixed(1);
            }
        }, {
            name: 'uptimeFormatted',
            calculate: function (data) {
                var numyears = Math.floor(data.uptime / 31536000),
                    numdays = Math.floor((data.uptime % 31536000) / 86400),
                    numhours = Math.floor(((data.uptime % 31536000) % 86400) / 3600),
                    numminutes = Math.floor((((data.uptime % 31536000) % 86400) % 3600) / 60),
                    uptime = '';

                if (numyears > 0) {
                    uptime += numyears + 'y ';
                }
                if (numdays > 0) {
                    uptime += numdays + 'd ';
                }
                if (numhours > 0) {
                    uptime += numhours + 'h ';
                }
                if (numminutes > 0) {
                    uptime += numminutes + 'm';
                }
                return uptime;
            }
        }]
});
Ext.define ('Ung.model.Widget', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'displayColumns', type: 'auto', defaultValue: null },
        { name: 'enabled', type: 'auto', defaultValue: true },
        { name: 'entryId', type: 'auto', defaultValue: null },
        { name: 'javaClass', type: 'string', defaultValue: 'com.untangle.uvm.DashboardWidgetSettings' },
        { name: 'refreshIntervalSec', type: 'auto', defaultValue: null },
        { name: 'timeframe', type: 'auto', defaultValue: null },
        { name: 'type', type: 'string' },
        { name: 'itemId', calculate: function () {
            return 'widget-' + Ext.Number.randomInt(100000, 999999);
        } }
    ],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json',
            // rootProperty: 'list'
        }
    }
});
Ext.define('Ung.store.Conditions', {
    extend: 'Ext.data.Store',
    storeId: 'conditions',
    fields: ['name', 'displayName', 'type'],
    data: [
        {name:'DST_ADDR', displayName: 'Destination Address'.t(), editorType: 'textfield', vtype:'ipall', visible: true },
        {name:'DST_PORT',displayName: 'Destination Port'.t(), editorType: 'textfield', vtype:'port', visible: true },
        {name:'DST_INTF',displayName: 'Destination Interface'.t(), editorType: 'checkboxgroup', /*values: Util.getInterfaceList(true, false),*/ visible: true},
        {name:'SRC_ADDR',displayName: 'Source Address'.t(), editorType: 'textfield', visible: true, vtype:'ipall'},
        {name:'SRC_PORT',displayName: 'Source Port'.t(), editorType: 'textfield', vtype:'portMatcher', visible: Rpc.directData('rpc.isExpertMode')},
        {name:'SRC_INTF',displayName: 'Source Interface'.t(), editorType: 'checkboxgroup', /*values: Util.getInterfaceList(true, false),*/ visible: true},
        {name:'PROTOCOL',displayName: 'Protocol'.t(), editorType: 'checkboxgroup', values: [['TCP','TCP'],['UDP','UDP'],['any','any']], visible: true},
        {name:'USERNAME',displayName: 'Username'.t(), editorType: 'userselection', /*editor: Ext.create('Ung.UserEditorWindow',{}),*/ visible: true},
        {name:'TAGGED',displayName: 'Tagged'.t(), editorType: 'textfield', visible: true},
        {name:'HOST_HOSTNAME',displayName: 'Host Hostname'.t(), editorType: 'textfield', visible: true},
        {name:'CLIENT_HOSTNAME',displayName: 'Client Hostname'.t(), editorType: 'textfield', visible: false},
        {name:'SERVER_HOSTNAME',displayName: 'Server Hostname'.t(), editorType: 'textfield', visible: false},
        {name:'HOST_MAC', displayName: 'Host MAC Address'.t(), editorType: 'textfield', visible: true },
        {name:'SRC_MAC', displayName: 'Client MAC Address'.t(), editorType: 'textfield', visible: true },
        {name:'DST_MAC', displayName: 'Server MAC Address'.t(), editorType: 'textfield', visible: true },
        {name:'HOST_MAC_VENDOR',displayName: 'Host MAC Vendor'.t(), editorType: 'textfield', visible: true},
        {name:'CLIENT_MAC_VENDOR',displayName: 'Client MAC Vendor'.t(), editorType: 'textfield', visible: false},
        {name:'SERVER_MAC_VENDOR',displayName: 'Server MAC Vendor'.t(), editorType: 'textfield', visible: false},
        {name:'HOST_IN_PENALTY_BOX',displayName: 'Host in Penalty Box'.t(), editorType: 'boolean', visible: false},
        {name:'CLIENT_IN_PENALTY_BOX',displayName: 'Client in Penalty Box'.t(), editorType: 'boolean', visible: false},
        {name:'SERVER_IN_PENALTY_BOX',displayName: 'Server in Penalty Box'.t(), editorType: 'boolean', visible: false},
        {name:'HOST_HAS_NO_QUOTA',displayName: 'Host has no Quota'.t(), editorType: 'boolean', visible: true},
        {name:'USER_HAS_NO_QUOTA',displayName: 'User has no Quota'.t(), editorType: 'boolean', visible: true},
        {name:'CLIENT_HAS_NO_QUOTA',displayName: 'Client has no Quota'.t(), editorType: 'boolean', visible: false},
        {name:'SERVER_HAS_NO_QUOTA',displayName: 'Server has no Quota'.t(), editorType: 'boolean', visible: false},
        {name:'HOST_QUOTA_EXCEEDED',displayName: 'Host has exceeded Quota'.t(), editorType: 'boolean', visible: true},
        {name:'USER_QUOTA_EXCEEDED',displayName: 'User has exceeded Quota'.t(), editorType: 'boolean', visible: true},
        {name:'CLIENT_QUOTA_EXCEEDED',displayName: 'Client has exceeded Quota'.t(), editorType: 'boolean', visible: false},
        {name:'SERVER_QUOTA_EXCEEDED',displayName: 'Server has exceeded Quota'.t(), editorType: 'boolean', visible: false},
        {name:'HOST_QUOTA_ATTAINMENT',displayName: 'Host Quota Attainment'.t(), editorType: 'textfield', visible: true},
        {name:'USER_QUOTA_ATTAINMENT',displayName: 'User Quota Attainment'.t(), editorType: 'textfield', visible: true},
        {name:'CLIENT_QUOTA_ATTAINMENT',displayName: 'Client Quota Attainment'.t(), editorType: 'textfield', visible: false},
        {name:'SERVER_QUOTA_ATTAINMENT',displayName: 'Server Quota Attainment'.t(), editorType: 'textfield', visible: false},
        {name:'HTTP_HOST',displayName: 'HTTP: Hostname'.t(), editorType: 'textfield', visible: true},
        {name:'HTTP_REFERER',displayName: 'HTTP: Referrer'.t(), editorType: 'textfield', visible: true},
        {name:'HTTP_URI',displayName: 'HTTP: URI'.t(), editorType: 'textfield', visible: true},
        {name:'HTTP_URL',displayName: 'HTTP: URL'.t(), editorType: 'textfield', visible: true},
        {name:'HTTP_CONTENT_TYPE',displayName: 'HTTP: Content Type'.t(), editorType: 'textfield', visible: true},
        {name:'HTTP_CONTENT_LENGTH',displayName: 'HTTP: Content Length'.t(), editorType: 'textfield', visible: true},
        {name:"HTTP_REQUEST_METHOD",displayName: 'HTTP: Request Method'.t(), type: 'textfield', visible: true},
        {name:"WEB_FILTER_REQUEST_METHOD",displayName: 'HTTP: Request Method'.t(), type: 'textfield', visible: false},
        {name:"HTTP_REQUEST_FILE_PATH",displayName: 'HTTP: Request File Path', type: 'textfield', visible: true},
        {name:"WEB_FILTER_REQUEST_FILE_PATH",displayName: 'HTTP: Request File Path'.t(), type: 'textfield', visible: false},
        {name:"HTTP_REQUEST_FILE_NAME",displayName: 'HTTP: Request File Name'.t(), type: 'textfield', visible: true},
        {name:"WEB_FILTER_REQUEST_FILE_NAME",displayName: 'HTTP: Request File Name'.t(), type: 'textfield', visible: false},
        {name:"HTTP_REQUEST_FILE_EXTENSION",displayName: 'HTTP: Request File Extension'.t(), type: 'textfield', visible: true},
        {name:"WEB_FILTER_REQUEST_FILE_EXTENSION",displayName: 'HTTP: Request File Extension'.t(), type: 'textfield', visible: false},
        {name:"HTTP_CONTENT_TYPE",displayName: 'HTTP: Content Type'.t(), type: 'textfield', visible: true},
        {name:"WEB_FILTER_RESPONSE_CONTENT_TYPE",displayName: 'HTTP: Content Type'.t(), type: 'textfield', visible: false},
        {name:"HTTP_RESPONSE_FILE_NAME",displayName: 'HTTP: Response File Name'.t(), type: 'textfield', visible: true},
        {name:"WEB_FILTER_RESPONSE_FILE_NAME",displayName: 'HTTP: Response File Name'.t(), type: 'textfield', visible: false},
        {name:"HTTP_RESPONSE_FILE_EXTENSION",displayName: 'HTTP: Response File Extension'.t(), type: 'textfield', visible: true},
        {name:"WEB_FILTER_RESPONSE_FILE_EXTENSION",displayName: 'HTTP: Response File Extension'.t(), type: 'textfield', visible: false},
        {name:'HTTP_USER_AGENT',displayName: 'HTTP: Client User Agent'.t(), editorType: 'textfield', visible: true},
        {name:'HTTP_USER_AGENT_OS',displayName: 'HTTP: Client User OS'.t(), editorType: 'textfield', visible: false},
        {name:'APPLICATION_CONTROL_APPLICATION',displayName: 'Application Control: Application'.t(), editorType: 'textfield', visible: true},
        {name:'APPLICATION_CONTROL_CATEGORY',displayName: 'Application Control: Application Category'.t(), editorType: 'textfield', visible: true},
        {name:'APPLICATION_CONTROL_PROTOCHAIN',displayName: 'Application Control: Protochain'.t(), editorType: 'textfield', visible: true},
        {name:'APPLICATION_CONTROL_DETAIL',displayName: 'Application Control: Detail'.t(), editorType: 'textfield', visible: true},
        {name:'APPLICATION_CONTROL_CONFIDENCE',displayName: 'Application Control: Confidence'.t(), editorType: 'textfield', visible: true},
        {name:'APPLICATION_CONTROL_PRODUCTIVITY',displayName: 'Application Control: Productivity'.t(), editorType: 'textfield', visible: true},
        {name:'APPLICATION_CONTROL_RISK',displayName: 'Application Control: Risk'.t(), editorType: 'textfield', visible: true},
        {name:'PROTOCOL_CONTROL_SIGNATURE',displayName: 'Application Control Lite: Signature'.t(), editorType: 'textfield', visible: true},
        {name:'PROTOCOL_CONTROL_CATEGORY',displayName: 'Application Control Lite: Category'.t(), editorType: 'textfield', visible: true},
        {name:'PROTOCOL_CONTROL_DESCRIPTION',displayName: 'Application Control Lite: Description'.t(), editorType: 'textfield', visible: true},
        {name:'WEB_FILTER_CATEGORY',displayName: 'Web Filter: Category'.t(), editorType: 'textfield', visible: true},
        {name:'WEB_FILTER_CATEGORY_DESCRIPTION',displayName: 'Web Filter: Category Description'.t(), editorType: 'textfield', visible: true},
        {name:'WEB_FILTER_FLAGGED',displayName: 'Web Filter: Website is Flagged'.t(), editorType: 'boolean', visible: true},
        {name:'DIRECTORY_CONNECTOR_DOMAIN',displayName: 'Directory Connector: User in Domain'.t(), type: 'directorydomainfield', visible: true},
        {name:'DIRECTORY_CONNECTOR_GROUP',displayName: 'Directory Connector: User in Group'.t(), type: 'editor', /*editor: Ext.create('Ung.GroupEditorWindow',{}),*/ visible: true},
        {name:'REMOTE_HOST_COUNTRY',displayName: 'Remote Host Country'.t(), editorType: 'countryselector', /*editor: Ext.create('Ung.CountryEditorWindow',{}),*/ visible: true},
        {name:'CLIENT_COUNTRY',displayName: 'Client Country'.t(), editorType: 'countryselector', /*editor: Ext.create('Ung.CountryEditorWindow',{}),*/ visible: true},
        {name:'SERVER_COUNTRY',displayName: 'Server Country'.t(), editorType: 'countryselector', /*editor: Ext.create('Ung.CountryEditorWindow',{}),*/ visible: true}
    ]


});
Ext.define('Ung.store.Countries', {
    extend: 'Ext.data.Store',
    alias: 'store.countries',
    storeId: 'countries',
    data: [
        { code: 'XU', name: 'Unknown'.t() },
        { code: 'XL', name: 'Local'.t() },
        { code: 'AF', name: 'Afghanistan'.t() },
        { code: 'AX', name: 'Aland Islands'.t() },
        { code: 'AL', name: 'Albania'.t() },
        { code: 'DZ', name: 'Algeria'.t() },
        { code: 'AS', name: 'American Samoa'.t() },
        { code: 'AD', name: 'Andorra'.t() },
        { code: 'AO', name: 'Angola'.t() },
        { code: 'AI', name: 'Anguilla'.t() },
        { code: 'AQ', name: 'Antarctica'.t() },
        { code: 'AG', name: 'Antigua and Barbuda'.t() },
        { code: 'AR', name: 'Argentina'.t() },
        { code: 'AM', name: 'Armenia'.t() },
        { code: 'AW', name: 'Aruba'.t() },
        { code: 'AU', name: 'Australia'.t() },
        { code: 'AT', name: 'Austria'.t() },
        { code: 'AZ', name: 'Azerbaijan'.t() },
        { code: 'BS', name: 'Bahamas'.t() },
        { code: 'BH', name: 'Bahrain'.t() },
        { code: 'BD', name: 'Bangladesh'.t() },
        { code: 'BB', name: 'Barbados'.t() },
        { code: 'BY', name: 'Belarus'.t() },
        { code: 'BE', name: 'Belgium'.t() },
        { code: 'BZ', name: 'Belize'.t() },
        { code: 'BJ', name: 'Benin'.t() },
        { code: 'BM', name: 'Bermuda'.t() },
        { code: 'BT', name: 'Bhutan'.t() },
        { code: 'BO', name: 'Bolivia, Plurinational State of'.t() },
        { code: 'BQ', name: 'Bonaire, Sint Eustatius and Saba'.t() },
        { code: 'BA', name: 'Bosnia and Herzegovina'.t() },
        { code: 'BW', name: 'Botswana'.t() },
        { code: 'BV', name: 'Bouvet Island'.t() },
        { code: 'BR', name: 'Brazil'.t() },
        { code: 'IO', name: 'British Indian Ocean Territory'.t() },
        { code: 'BN', name: 'Brunei Darussalam'.t() },
        { code: 'BG', name: 'Bulgaria'.t() },
        { code: 'BF', name: 'Burkina Faso'.t() },
        { code: 'BI', name: 'Burundi'.t() },
        { code: 'KH', name: 'Cambodia'.t() },
        { code: 'CM', name: 'Cameroon'.t() },
        { code: 'CA', name: 'Canada'.t() },
        { code: 'CV', name: 'Cape Verde'.t() },
        { code: 'KY', name: 'Cayman Islands'.t() },
        { code: 'CF', name: 'Central African Republic'.t() },
        { code: 'TD', name: 'Chad'.t() },
        { code: 'CL', name: 'Chile'.t() },
        { code: 'CN', name: 'China'.t() },
        { code: 'CX', name: 'Christmas Island'.t() },
        { code: 'CC', name: 'Cocos (Keeling) Islands'.t() },
        { code: 'CO', name: 'Colombia'.t() },
        { code: 'KM', name: 'Comoros'.t() },
        { code: 'CG', name: 'Congo'.t() },
        { code: 'CD', name: 'Congo, the Democratic Republic of the'.t() },
        { code: 'CK', name: 'Cook Islands'.t() },
        { code: 'CR', name: 'Costa Rica'.t() },
        { code: 'CI', name: 'Cote d\'Ivoire'.t() },
        { code: 'HR', name: 'Croatia'.t() },
        { code: 'CU', name: 'Cuba'.t() },
        { code: 'CW', name: 'Curacao'.t() },
        { code: 'CY', name: 'Cyprus'.t() },
        { code: 'CZ', name: 'Czech Republic'.t() },
        { code: 'DK', name: 'Denmark'.t() },
        { code: 'DJ', name: 'Djibouti'.t() },
        { code: 'DM', name: 'Dominica'.t() },
        { code: 'DO', name: 'Dominican Republic'.t() },
        { code: 'EC', name: 'Ecuador'.t() },
        { code: 'EG', name: 'Egypt'.t() },
        { code: 'SV', name: 'El Salvador'.t() },
        { code: 'GQ', name: 'Equatorial Guinea'.t() },
        { code: 'ER', name: 'Eritrea'.t() },
        { code: 'EE', name: 'Estonia'.t() },
        { code: 'ET', name: 'Ethiopia'.t() },
        { code: 'FK', name: 'Falkland Islands (Malvinas)'.t() },
        { code: 'FO', name: 'Faroe Islands'.t() },
        { code: 'FJ', name: 'Fiji'.t() },
        { code: 'FI', name: 'Finland'.t() },
        { code: 'FR', name: 'France'.t() },
        { code: 'GF', name: 'French Guiana'.t() },
        { code: 'PF', name: 'French Polynesia'.t() },
        { code: 'TF', name: 'French Southern Territories'.t() },
        { code: 'GA', name: 'Gabon'.t() },
        { code: 'GM', name: 'Gambia'.t() },
        { code: 'GE', name: 'Georgia'.t() },
        { code: 'DE', name: 'Germany'.t() },
        { code: 'GH', name: 'Ghana'.t() },
        { code: 'GI', name: 'Gibraltar'.t() },
        { code: 'GR', name: 'Greece'.t() },
        { code: 'GL', name: 'Greenland'.t() },
        { code: 'GD', name: 'Grenada'.t() },
        { code: 'GP', name: 'Guadeloupe'.t() },
        { code: 'GU', name: 'Guam'.t() },
        { code: 'GT', name: 'Guatemala'.t() },
        { code: 'GG', name: 'Guernsey'.t() },
        { code: 'GN', name: 'Guinea'.t() },
        { code: 'GW', name: 'Guinea-Bissau'.t() },
        { code: 'GY', name: 'Guyana'.t() },
        { code: 'HT', name: 'Haiti'.t() },
        { code: 'HM', name: 'Heard Island and McDonald Islands'.t() },
        { code: 'VA', name: 'Holy See (Vatican City State)'.t() },
        { code: 'HN', name: 'Honduras'.t() },
        { code: 'HK', name: 'Hong Kong'.t() },
        { code: 'HU', name: 'Hungary'.t() },
        { code: 'IS', name: 'Iceland'.t() },
        { code: 'IN', name: 'India'.t() },
        { code: 'ID', name: 'Indonesia'.t() },
        { code: 'IR', name: 'Iran, Islamic Republic of'.t() },
        { code: 'IQ', name: 'Iraq'.t() },
        { code: 'IE', name: 'Ireland'.t() },
        { code: 'IM', name: 'Isle of Man'.t() },
        { code: 'IL', name: 'Israel'.t() },
        { code: 'IT', name: 'Italy'.t() },
        { code: 'JM', name: 'Jamaica'.t() },
        { code: 'JP', name: 'Japan'.t() },
        { code: 'JE', name: 'Jersey'.t() },
        { code: 'JO', name: 'Jordan'.t() },
        { code: 'KZ', name: 'Kazakhstan'.t() },
        { code: 'KE', name: 'Kenya'.t() },
        { code: 'KI', name: 'Kiribati'.t() },
        { code: 'KP', name: 'Korea, Democratic People\'s Republic of'.t() },
        { code: 'KR', name: 'Korea, Republic of'.t() },
        { code: 'KW', name: 'Kuwait'.t() },
        { code: 'KG', name: 'Kyrgyzstan'.t() },
        { code: 'LA', name: 'Lao People\'s Democratic Republic'.t() },
        { code: 'LV', name: 'Latvia'.t() },
        { code: 'LB', name: 'Lebanon'.t() },
        { code: 'LS', name: 'Lesotho'.t() },
        { code: 'LR', name: 'Liberia'.t() },
        { code: 'LY', name: 'Libya'.t() },
        { code: 'LI', name: 'Liechtenstein'.t() },
        { code: 'LT', name: 'Lithuania'.t() },
        { code: 'LU', name: 'Luxembourg'.t() },
        { code: 'MO', name: 'Macao'.t() },
        { code: 'MK', name: 'Macedonia, the Former Yugoslav Republic of'.t() },
        { code: 'MG', name: 'Madagascar'.t() },
        { code: 'MW', name: 'Malawi'.t() },
        { code: 'MY', name: 'Malaysia'.t() },
        { code: 'MV', name: 'Maldives'.t() },
        { code: 'ML', name: 'Mali'.t() },
        { code: 'MT', name: 'Malta'.t() },
        { code: 'MH', name: 'Marshall Islands'.t() },
        { code: 'MQ', name: 'Martinique'.t() },
        { code: 'MR', name: 'Mauritania'.t() },
        { code: 'MU', name: 'Mauritius'.t() },
        { code: 'YT', name: 'Mayotte'.t() },
        { code: 'MX', name: 'Mexico'.t() },
        { code: 'FM', name: 'Micronesia, Federated States of'.t() },
        { code: 'MD', name: 'Moldova, Republic of'.t() },
        { code: 'MC', name: 'Monaco'.t() },
        { code: 'MN', name: 'Mongolia'.t() },
        { code: 'ME', name: 'Montenegro'.t() },
        { code: 'MS', name: 'Montserrat'.t() },
        { code: 'MA', name: 'Morocco'.t() },
        { code: 'MZ', name: 'Mozambique'.t() },
        { code: 'MM', name: 'Myanmar'.t() },
        { code: 'NA', name: 'Namibia'.t() },
        { code: 'NR', name: 'Nauru'.t() },
        { code: 'NP', name: 'Nepal'.t() },
        { code: 'NL', name: 'Netherlands'.t() },
        { code: 'NC', name: 'New Caledonia'.t() },
        { code: 'NZ', name: 'New Zealand'.t() },
        { code: 'NI', name: 'Nicaragua'.t() },
        { code: 'NE', name: 'Niger'.t() },
        { code: 'NG', name: 'Nigeria'.t() },
        { code: 'NU', name: 'Niue'.t() },
        { code: 'NF', name: 'Norfolk Island'.t() },
        { code: 'MP', name: 'Northern Mariana Islands'.t() },
        { code: 'NO', name: 'Norway'.t() },
        { code: 'OM', name: 'Oman'.t() },
        { code: 'PK', name: 'Pakistan'.t() },
        { code: 'PW', name: 'Palau'.t() },
        { code: 'PS', name: 'Palestine, State of'.t() },
        { code: 'PA', name: 'Panama'.t() },
        { code: 'PG', name: 'Papua New Guinea'.t() },
        { code: 'PY', name: 'Paraguay'.t() },
        { code: 'PE', name: 'Peru'.t() },
        { code: 'PH', name: 'Philippines'.t() },
        { code: 'PN', name: 'Pitcairn'.t() },
        { code: 'PL', name: 'Poland'.t() },
        { code: 'PT', name: 'Portugal'.t() },
        { code: 'PR', name: 'Puerto Rico'.t() },
        { code: 'QA', name: 'Qatar'.t() },
        { code: 'RE', name: 'Reunion'.t() },
        { code: 'RO', name: 'Romania'.t() },
        { code: 'RU', name: 'Russian Federation'.t() },
        { code: 'RW', name: 'Rwanda'.t() },
        { code: 'BL', name: 'Saint Barthelemy'.t() },
        { code: 'SH', name: 'Saint Helena, Ascension and Tristan da Cunha'.t() },
        { code: 'KN', name: 'Saint Kitts and Nevis'.t() },
        { code: 'LC', name: 'Saint Lucia'.t() },
        { code: 'MF', name: 'Saint Martin (French part)'.t() },
        { code: 'PM', name: 'Saint Pierre and Miquelon'.t() },
        { code: 'VC', name: 'Saint Vincent and the Grenadines'.t() },
        { code: 'WS', name: 'Samoa'.t() },
        { code: 'SM', name: 'San Marino'.t() },
        { code: 'ST', name: 'Sao Tome and Principe'.t() },
        { code: 'SA', name: 'Saudi Arabia'.t() },
        { code: 'SN', name: 'Senegal'.t() },
        { code: 'RS', name: 'Serbia'.t() },
        { code: 'SC', name: 'Seychelles'.t() },
        { code: 'SL', name: 'Sierra Leone'.t() },
        { code: 'SG', name: 'Singapore'.t() },
        { code: 'SX', name: 'Sint Maarten (Dutch part)'.t() },
        { code: 'SK', name: 'Slovakia'.t() },
        { code: 'SI', name: 'Slovenia'.t() },
        { code: 'SB', name: 'Solomon Islands'.t() },
        { code: 'SO', name: 'Somalia'.t() },
        { code: 'ZA', name: 'South Africa'.t() },
        { code: 'GS', name: 'South Georgia and the South Sandwich Islands'.t() },
        { code: 'SS', name: 'South Sudan'.t() },
        { code: 'ES', name: 'Spain'.t() },
        { code: 'LK', name: 'Sri Lanka'.t() },
        { code: 'SD', name: 'Sudan'.t() },
        { code: 'SR', name: 'Suriname'.t() },
        { code: 'SJ', name: 'Svalbard and Jan Mayen'.t() },
        { code: 'SZ', name: 'Swaziland'.t() },
        { code: 'SE', name: 'Sweden'.t() },
        { code: 'CH', name: 'Switzerland'.t() },
        { code: 'SY', name: 'Syrian Arab Republic'.t() },
        { code: 'TW', name: 'Taiwan, Province of China'.t() },
        { code: 'TJ', name: 'Tajikistan'.t() },
        { code: 'TZ', name: 'Tanzania, United Republic of'.t() },
        { code: 'TH', name: 'Thailand'.t() },
        { code: 'TL', name: 'Timor-Leste'.t() },
        { code: 'TG', name: 'Togo'.t() },
        { code: 'TK', name: 'Tokelau'.t() },
        { code: 'TO', name: 'Tonga'.t() },
        { code: 'TT', name: 'Trinidad and Tobago'.t() },
        { code: 'TN', name: 'Tunisia'.t() },
        { code: 'TR', name: 'Turkey'.t() },
        { code: 'TM', name: 'Turkmenistan'.t() },
        { code: 'TC', name: 'Turks and Caicos Islands'.t() },
        { code: 'TV', name: 'Tuvalu'.t() },
        { code: 'UG', name: 'Uganda'.t() },
        { code: 'UA', name: 'Ukraine'.t() },
        { code: 'AE', name: 'United Arab Emirates'.t() },
        { code: 'GB', name: 'United Kingdom'.t() },
        { code: 'US', name: 'United States'.t() },
        { code: 'UM', name: 'United States Minor Outlying Islands'.t() },
        { code: 'UY', name: 'Uruguay'.t() },
        { code: 'UZ', name: 'Uzbekistan'.t() },
        { code: 'VU', name: 'Vanuatu'.t() },
        { code: 'VE', name: 'Venezuela, Bolivarian Republic of'.t() },
        { code: 'VN', name: 'Viet Nam'.t() },
        { code: 'VG', name: 'Virgin Islands, British'.t() },
        { code: 'VI', name: 'Virgin Islands, U.S.'.t() },
        { code: 'WF', name: 'Wallis and Futuna'.t() },
        { code: 'EH', name: 'Western Sahara'.t() },
        { code: 'YE', name: 'Yemen'.t() },
        { code: 'ZM', name: 'Zambia'.t() },
        { code: 'ZW', name: 'Zimbabwe'.t() }
    ]
});
Ext.define('Ung.store.Devices', {
    extend: 'Ext.data.Store',
    storeId: 'devices',

    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    }

});
Ext.define('Ung.store.Hosts', {
    extend: 'Ext.data.Store',
    storeId: 'hosts',
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
        }
    }

});
Ext.define('Ung.store.Metrics', {
    extend: 'Ext.data.Store',
    storeId: 'metrics',
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
            //rootProperty: 'users'
        }
    }
});
Ext.define('Ung.store.Policies', {
    extend: 'Ext.data.Store',
    alias: 'store.policies',
    storeId: 'policies',
    model: 'Ung.model.Policy'
});
Ext.define('Ung.store.PoliciesTree', {
    extend: 'Ext.data.TreeStore',
    alias: 'store.policiestree',
    storeId: 'policiestree',
    // filterer: 'bottomup',


    build: function () {
        var me = this, policies;

        if(!Rpc.directData('rpc.appManager.app', 'policy-manager')){
            me.setRoot({
                name: 'Policies',
                policyId: 'root', // used for path
                expanded: true,
                children: {
                    policyId: 1,
                    name: 'Default'
                }
            });
        }else{
            Rpc.asyncData('rpc.appManager.app("policy-manager").getSettings')
            .then( function(result){
                if(Util.isDestroyed(me)){
                    return;
                }

                policies = result.policies.list;

                Ext.Array.each(policies, function (policy) {
                    /**
                     * parentId can be 0 or null (if no parent policy), so it is normalized to be just 0 (None)
                     * parentId is also used by the treestore internals so it will be used "parentPolicyId" instead
                     */
                    policy.parentId = policy.parentId || 0;
                    policy.parentPolicyId = policy.parentId;
                });

                var tree = me.recursiveTree(Ext.clone(policies));

                me.setRoot({
                    name: 'Policies',
                    policyId: 'root', // used for path
                    expanded: true,
                    children: tree
                });
            },function(ex){
                Util.handleException(ex);
            });
        }

    },

    recursiveTree: function (array, parent, tree) {
        var me = this;
        tree = typeof tree != undefined ? tree : [];
        parent = parent || { policyId: 0 };


        var children = Ext.Array.filter(array, function (child) {
            return child.parentId === parent.policyId;
        });

        if (!Ext.isEmpty(children)) {
            parent.expanded = true;
            parent.iconCls = 'fa fa-file-text-o';
            if (parent.policyId === 0) {
                tree = children;
            } else {
                parent.children = children;
            }
            Ext.Array.each(children, function (child) {
                // child.parentPolicyId = child.parentId; // parentId is reserved for the tree store
                me.recursiveTree(array, child);
            });
        } else {
            parent.iconCls = 'fa fa-file-text-o';
            parent.leaf = true;
        }
        return tree;
    }

});
Ext.define('Ung.store.Rule', {
    extend: 'Ext.data.Store',
    storeId: 'rule',
    alias: 'store.rule',
    model: 'Ung.model.Rule'
});Ext.define('Ung.store.RuleConditions', {
    extend: 'Ext.data.Store',
    alias: 'store.ruleconditions',
    model: 'Ung.model.Condition'
});Ext.define('Ung.store.Sessions', {
    extend: 'Ext.data.Store',
    storeId: 'sessions',
    model: 'Ung.model.Session',
    sorters: ['bypassed']
});
Ext.define('Ung.store.Site', {
    extend: 'Ext.data.Store',
    storeId: 'site',
    model: 'Ung.model.Policy',
    //fields: ['policyId'],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
            //rootProperty: 'list'
        }
    }
});
Ext.define('Ung.store.Stats', {
    extend: 'Ext.data.Store',
    alias: 'store.stats',
    storeId: 'stats',
    model: 'Ung.model.Stat'
});
Ext.define('Ung.store.Widgets', {
    extend: 'Ext.data.Store',
    alias: 'store.widgets',
    storeId: 'widgets',
    model: 'Ung.model.Widget',
    listeners: {
        // load: function () { },
        // datachanged: function () { },
        update: function (store, record, operation, modifiedFieldNames, details) {
            if (operation === 'edit' && Ext.Array.contains(modifiedFieldNames, 'enabled')) {
                Ext.fireEvent('updatewidget', store, record, operation, modifiedFieldNames, details);
            }
        },
        remove: function (store, records) {
            Ext.fireEvent('removewidgets', store, records);
        },
        add: function (store, records) {
            Ext.fireEvent('addwidgets', store, records);
        },
        // refresh: function (store) { }
    }
});
Ext.define('Ung.controller.Global', {
    extend: 'Ext.app.Controller',
    namespace: 'Ung',

    stores: [
        'Policies',
        'Metrics',
        'Stats',
        'Reports',
        'Widgets',
        'Sessions',
        'Hosts',
        'Devices',
        'Conditions',
        'Countries',
        'Categories',
        'Rule',

        'ReportsTree',
        'PoliciesTree'
    ],

    init: function() {
        var me = this;
        me.callParent(arguments); // Always call parent init

        // Listen for messages from the iframe
        window.addEventListener('message', function(event) {

            // Check if the message is from your Vue iframe app
            if (event.data && event.data.source === 'vue-iframe-app' && event.data.type === 'isDirtyChange') {
                me.isVueDirty = event.data.isDirty;
            }
        });
    },
    listen: {
        controller: {
            '#': {
                unmatchedroute: 'onUnmatchedRoute'
            }
        },
        global: {
            appinstall: 'onAppAction',
            appremove: 'onAppAction',
            resetfields: 'onResetFields', // used to reset the fields after saving the settings
            invalidquery: 'onUnmatchedRoute'
        }
    },

    hashBackup: '', // used to revert the hash when user changes are detected in Apps or Configs

    config: {
        refs: {
            mainView: '#main',
            dashboardView: '#dashboardMain',
            appsView: '#apps',
            reportsView: '#reports',
        },

        routes: {
            '': { before: 'detectChanges', action: 'onRoute' },
            'dashboard:params': {
                before: 'detectChanges',
                action: 'onRoute',
                conditions: {
                    ':params' : '(.*)'
                }
            },
            'reports:params': {
                before: 'detectChanges',
                action: 'onRoute',
                conditions: {
                    ':params' : '(.*)'
                }
            },

            'apps': { before: 'detectChanges', action: 'onApps' },
            'apps/:policyId': { before: 'detectChanges', action: 'onApps' },
            'apps/:policyId/:app': { before: 'detectChanges', action: 'onApps' },
            'apps/:policyId/:app/:view': 'onApps',
            'apps/:policyId/:app/:view/:subView': 'onApps',
            'service/:app': { before: 'detectChanges', action: 'onService' },
            'service/:app/:view': 'onService',
            'service/:app/:view/:subView': 'onService',

            'config': { before: 'detectChanges', action: 'onConfig' },
            'config/:configName': { before: 'detectChanges', action: 'onConfig' },
            'config/:configName/:configView': 'onConfig',
            'config/:configName/:configView/:subView': 'onConfig',
            'config/:configName/:configView/:subView/:subView': 'onConfig',
            'config/:configName/:configView/:subView/:subView/:subView': 'onConfig',

            'sessions': { before: 'detectChanges', action: 'onSessions' },
            'sessions/:params': {
                action: 'onSessions',
                conditions: {
                    ':params' : '([0-9a-zA-Z.?&=-]+)'
                }
            },
            'hosts': { before: 'detectChanges', action: 'onHosts' },
            'hosts/:params': {
                action: 'onHosts',
                conditions: {
                    ':params' : '([0-9a-zA-Z.?&=-]+)'
                }
            },
            'devices': { before: 'detectChanges', action: 'onDevices' },
            'devices/:params': {
                action: 'onDevices',
                conditions: {
                    ':params' : '([0-9a-zA-Z.?&=-]+)'
                }
            },
            'users': { before: 'detectChanges', action: 'onUsers' },
            'expert': 'setExpertMode',
            'noexpert': 'setNoExpertMode'
        }
    },
    isVueDirty: false,

    detectChanges: function () {
        var action = arguments[arguments.length - 1]; // arguments length vary, action being the last one
        var cmp = Ung.app.getMainView().down('#appCard') || Ung.app.getMainView().down('#configCard');
        if (!cmp) {
            action.resume(); // resume if there is no app or config view
            return;
        }

        var dirtyFields = false, dirtyGrids = false;
        Ext.Array.each(cmp.query('field'), function (field) {
            if (!field._neverDirty && field._isChanged && !dirtyFields) {
                dirtyFields = true;
            }
        });
        // check for grids changes
        Ext.Array.each(cmp.query('ungrid'), function (grid) {
            var store = grid.getStore();
            if (store.type === 'chained' || store.skipDetectGridChanges) { return; }
            if (store.getModifiedRecords().length > 0 || store.getRemovedRecords().length > 0 || store.getNewRecords().length > 0 && !dirtyGrids) {
                dirtyGrids = true;
            }
        });

        if (dirtyFields || dirtyGrids || this.isVueDirty) {
            Ext.MessageBox.confirm('Warning'.t(), 'There are unsaved settings which will be lost. Do you want to continue?'.t(),
                function(btn) {
                    if (btn === 'yes') {
                        action.resume(); // if user wants to loose changes move on
                    } else {
                        Ung.app.redirectTo(Ung.app.hashBackup); // otherwise keep it in same view and reset the hash to reflect the same view
                    }
                });
        } else {
            action.resume();
        }
    },

    onResetFields: function (view) {
        Ext.Array.each(view.query('field'), function (field) {
            if (field.hasOwnProperty('_initialValue')) {
                delete field._initialValue;
            }
            if (field.hasOwnProperty('_isChanged')) {
                delete field._isChanged;
            }
        });
    },

    /**
     * Common method used for routing Dashboard and Reports based on conditions query
     */
    onRoute: function (query) {
        var hash = window.location.hash, view, viewModel = null, validQuery = true,
            route = {}, condition, conditions = [],
            decoded, parts, key, sep, val, fmt, table;

        if (hash === '' || Ext.String.startsWith(hash, '#') || Ext.String.startsWith(hash, '#dashboard')) {
            view = 'dashboardMain';
            viewModel = this.getDashboardView().getViewModel();
            Ung.app.conditionsContext = 'DASHBOARD';
        }
        if (Ext.String.startsWith(hash, '#reports')) {
            view = 'reports';
            viewModel = this.getReportsView().getViewModel();
            Ung.app.conditionsContext = 'REPORTS';
        }

        if (query) {
            Ext.Array.each(query.replace('?', '').split('&'), function (part) {
                decoded = decodeURIComponent(part);

                if (decoded.indexOf(':') > 0) {
                    parts = decoded.split(':');
                    key = parts[0];
                    sep = parts[1];
                    fmt = parseInt(parts[2], 10);
                    table = parts[3];
                    val = parts.slice(4,parts.length).join(':');
                } else {
                    parts = decoded.split('=');
                    key = parts[0];
                    val = parts[1];
                }
                if (key === 'cat' || key === 'rep') {
                    route[key] = Util.urlEncode(val);
                } else {
                    if (!key || !sep || !val) {
                        validQuery = false;
                    } else {
                        conditions.push( new Ung.model.ReportCondition({
                            column: key,
                            operator: sep,
                            value: val,
                            autoFormatValue: fmt === 1 ? true : false,
                            table: table,
                        }));
                    }
                }
            });
        }

        if (!validQuery) {
            Ext.fireEvent('invalidquery');
            return;
        }

        if(viewModel != null){
            viewModel.set('query', {
                route: route,
                conditions: conditions,
                string: Ung.model.ReportCondition.getAllQueries(conditions)
            });
        }

        this.getMainView().getViewModel().set('activeItem', view);
    },

    onUnmatchedRoute: function () {
        this.getMainView().getViewModel().set('activeItem', 'invalidRoute');
    },

    onApps: function (policyId, app, view, subView) {
        var me = this;

        policyId = policyId || 1;
        if (!app) {
            Ung.app.redirectTo('#apps/' + policyId);
        }

        this.getMainView().getViewModel().set('activeItem', 'apps');
        this.getMainView().getViewModel().set('policyId', policyId);

        this.getAppsView().setActiveItem('installedApps');
        this.getAppsView().getViewModel().set('onInstalledApps', true);

        if (app) {
            me.loadApp(policyId, app, view, subView);
        }
    },

    onAppAction: function () {
        if (Rpc.exists('rpc.reportsManager')) {
            Rpc.asyncData('rpc.reportsManager.getCurrentApplications').then(function (result) {
                Ext.getStore('categories').loadData(Ext.Array.merge(Util.baseCategories, result.list));
                Ext.getStore('reportstree').build();
            });
        }
    },

    onService: function (app, view, subView) {
        var me = this;
        this.getMainView().getViewModel().set('activeItem', 'apps');
        if (app) {
            me.loadApp(null, app, view, subView);
        }


    },

    getAppInstanceFromPolicyStore: function (policyId, app) {
        if (!policyId) { policyId = 1;}
        var policy = Ext.getStore('policies').findRecord('policyId', policyId);
        return Ext.Array.findBy(policy.get('instances').list, function (inst) {
            return inst.appName === app;
        });
    },

    getAppPropertiesFromPolicyStore: function (policyId, app) {
        if (!policyId) { policyId = 1;}
        var policy = Ext.getStore('policies').findRecord('policyId', policyId);
        return Ext.Array.findBy(policy.get('appProperties').list, function (prop) {
            return prop.name === app;
        });
    },

    loadApp: function (policyId, app, view, subView) {
        var subViews = [];
        for( var i = 3; i < arguments.length; i++){
            if(typeof(arguments[i]) != 'string'){
                break;
            }
            subViews.push(arguments[i]);
        }
        var me = this, mainView = me.getMainView();
        if (mainView.down('app-' + app)) {
            // if app card already exists activate it and select given view
            mainView.getViewModel().set('activeItem', 'appCard');
            var viewTarget = mainView.down('app-' + app).setActiveItem(view || 0);
            mainView.down('app-' + app).subViews = subViews;
            Ung.controller.Global.onSubtabActivate(viewTarget);
            return;
        } else {
            // eventually do not remove the old card
            mainView.remove('appCard');
        }

        if (!policyId) { policyId = 1;}

        var policy = Ext.getStore('policies').findRecord('policyId', policyId);
        var appInstance = me.getAppInstanceFromPolicyStore(policyId, app);
        var appProps = me.getAppPropertiesFromPolicyStore(policyId, app);

        mainView.setLoading(true);
        if (!appInstance || !appProps) {
            // load the policy store one more time
            try {
                var result = Rpc.directData('rpc.appManager.getAppsViews');
                Ext.getStore('policies').loadData(result);
                Ung.app.getGlobalController().getAppsView().getController().getApps();
            } catch (error) {
                Util.handleException(error);
            }

            // fetch values from the updated policy store
            appInstance = me.getAppInstanceFromPolicyStore(policyId, app);
            appProps = me.getAppPropertiesFromPolicyStore(policyId, app);
            if (!appInstance || !appProps) {
                mainView.setLoading(false);
                // Util.handleException('Unable to find app: ' + app);
                Ext.fireEvent('invalidquery');
                return;
            }
        }

        Ext.Loader.loadScript({
            //url: 'script/apps/' + app + '.js',
            // This hack changes the name of ad-blocker to ab.js
            // NGFW-10728
            url: 'script/apps/' + (app=='ad-blocker'?'ab':app) + '.js',
            onLoad: function () {
                Rpc.asyncData('rpc.appManager.app', appInstance.id)
                    .then(function (result) {
                        appInstance.runState = result.getRunState();
                        mainView.add({
                            xtype: 'app-' + app,
                            itemId: 'appCard',
                            appManager: result,
                            activeTab: view || 0,
                            subViews: subViews || [],
                            viewModel: {
                                data: {
                                    instance: appInstance,
                                    policyName: me.getAppsView().getViewModel().get('policyName'),
                                    props: appProps,
                                    license: policy.get('licenseMap')[app],
                                    urlName: app
                                }
                            },
                            listeners: {
                                deactivate: function () {
                                    // remove the app container
                                    mainView.remove('appCard');
                                }
                            }
                        });
                        mainView.getViewModel().set('activeItem', 'appCard');
                        mainView.getViewModel().notify();
                        var appViewModel = mainView.down('app-' + app).getViewModel();
                        appViewModel.set('state', Ext.create('Ung.model.AppState',{vm: appViewModel, app: result}));
                    }, function (ex) {
                        Util.handleException(ex);
                    }).always(function () {
                        mainView.setLoading(false);
                    });
            }
        });
    },

    onConfig: function (config, view, subView) {
        var subViews = [];

        // config must be one of those defined in array, otherwise route is invalid
        if (config && !Ext.Array.contains(['network', 'administration', 'events', 'email', 'local-directory', 'system', 'about'], config)) {
            Ext.fireEvent('invalidquery');
            return;
        }

        for( var i = 2; i < arguments.length; i++){
            if(typeof(arguments[i]) != 'string'){
                break;
            }
            subViews.push(arguments[i]);
        }
        var me = this, mainView = me.getMainView();
        mainView.getViewModel().set('activeItem', 'config');
        if (config) {
            if (mainView.down('config-' + config)) {
                mainView.getViewModel().set('activeItem', 'configCard');
                var viewTarget = mainView.down('config-' + config).setActiveItem(view || 0);
                mainView.down('config-' + config).subViews = subViews;
                Ung.controller.Global.onSubtabActivate(viewTarget);
                return;
            } else {
                mainView.remove('configCard');
            }
            mainView.setLoading(true);
            Ext.Loader.loadScript({
                url: 'script/config/' + config + '.js',
                onLoad: function () {
                    mainView.add({
                        xtype: 'config-' + config,
                        name: config,
                        itemId: 'configCard',
                        activeTab: view || 0,
                        subViews: subViews || [],
                        listeners: {
                            deactivate: function () {
                                // remove the config container
                                mainView.remove('configCard');
                            }
                        }
                    });
                    mainView.getViewModel().set('activeItem', 'configCard');
                    mainView.getViewModel().notify();
                    mainView.setLoading(false);
                }
            });
        }
    },

    setExpertMode: function () {
        rpc.isExpertMode = true;
        this.getMainView().getViewModel().set('isExpertMode', true);
        Ung.app.redirectTo('#apps');
    },

    setNoExpertMode: function () {
        rpc.isExpertMode = false;
        this.getMainView().getViewModel().set('isExpertMode', false);
        Ung.app.redirectTo('#apps');
    },

    onMonitor: function(id, xtype, params){
        var me = this,
            mainview = me.getMainView();

        var filter = null;
        if (params) {
            filter = {
                property: params.split('=')[0].replace('?', ''),
                value: params.split('=')[1],
                source: 'route'
            };
        }

        var existing = mainview.getComponent( id );
        if(existing){
            existing.routeFilter = filter;
            existing.fireEvent('refresh');
        }else{
            this.getMainView().add({
                xtype: xtype,
                itemId: id,
                routeFilter: filter
            });
        }
        this.getMainView().getViewModel().set('activeItem', id);

    },

    onSessions: function (params) {
        this.onMonitor( 'sessions', 'ung.sessions', params);
    },

    onHosts: function ( params ) {
        this.onMonitor( 'hosts', 'ung.hosts', params);
    },

    onDevices: function ( params ) {
        this.onMonitor( 'devices', 'ung.devices', params);
    },

    onUsers: function () {
        this.getMainView().add({
            xtype: 'ung.users',
            itemId: 'users'
        });
        this.getMainView().getViewModel().set('activeItem', 'users');
    },

    statics: {
        //
        // These two methods are used on tab panels with their own sub-tab panels and added
        // to the controller.  See openvpn/server and virus-blocker/advanced.
        //
        activateTaskDelay: 250,
        activateTaskDelayMax: 5000,
        onSubtabActivate: function(panel){
            var me = this;
            var parentPanel = panel.up('apppanel') || panel.up('configpanel');

            // While we're setting tabs, don't trigger the subtab activation.
            // Doing so will loop back into onConfig for a partial path, short-circuiting
            // the loop wer'e doing here.
            Ung.controller.Global.ignoreActivate = true;

            parentPanel.subViews.forEach(function(subView){
                var targetPanel = panel.down('[itemId='+subView+']');
                if(!targetPanel){
                    return;
                }
                var parentPanel = targetPanel.up('tabpanel');
                parentPanel.setActiveItem(subView);
                panel = targetPanel;
                if(parentPanel.disabled){
                    return false;
                }

                if(targetPanel.tab){
                    // For deeply nested tabs, settng the active item sets the tab panel
                    // properly but not the tab itself.  To verify tis properly set, we
                    // spawn a delayed task to keep trying to change the tabbar manually.
                    var activateTaskExpire = (new Date().getTime() / 1000) + 5000;
                    var runActivateTask = new Ext.util.DelayedTask( Ext.bind(function(){
                        if(parentPanel.destroyed){
                            return;
                        }
                        if( ( parentPanel.tabBar.activeTab != targetPanel.tab) &&
                            ( activateTaskExpire >  ( new Date().getTime() / 1000) ) ){
                            runActivateTask.delay( Ung.controller.Global.activateTaskDelay );
                        }
                        parentPanel.tabBar.setActiveTab(targetPanel.tab);
                    }, me) );
                    runActivateTask.delay( Ung.controller.Global.activateTaskDelay );
                }
            });
            Ung.controller.Global.ignoreActivate = false;
        },

        ignoreActivate: false,
        onBeforeSubtabChange: function (tabPanel, card, oldCard) {
            if(Ung.controller.Global.ignoreActivate){
                return;
            }
            var hash = window.location.hash;
            var id = tabPanel.itemId;
            if( id && hash.indexOf(id) > -1 ){
                Ung.app.redirectTo(hash.substr(0,hash.indexOf(id) + id.length) + '/' + card.getItemId());
            }
        }
    }
});
Ext.define('Ung.cmp.AppLicense', {
    extend: 'Ext.form.FieldSet',
    alias: 'widget.applicense',
    title: '<i class="fa fa-file-text"></i> ' + 'License'.t(),

    padding: 10,
    margin: '20 0',
    cls: 'app-section',

    layout: {
        type: 'hbox',
        align: 'middle'
    },

    viewModel: {
        formulas: {
            licenseMessage: function (get) {
                return Util.getLicenseMessage(get('license'));
            }
        }
    },

    items: [{
        xtype: 'component',
        padding: '3 5',
        bind: {
            html: '<i class="fa fa-exclamation-triangle fa-orange"></i> <strong>' + '{licenseMessage}' + '</strong>'
        }
    }, {
        xtype: 'button',
        html: 'Buy Now'.t(),
        iconCls: 'fa fa-shopping-cart',
        bind: {
            href: Util.getStoreUrl() + '?action=buy&libitem=untangle-libitem-{props.name}&' + Util.getAbout()
        }
    }]
});
Ext.define('Ung.cmp.AppMemory', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.appmemory',

    title: 'Memory Usage'.t(),
    border: false,
    controller: 'appmemory',
    viewModel: true,

    disabled: true,
    bind: {
        disabled: '{!state.on}',
    },

    layout: 'fit',
    items: [{
        xtype: 'component',
        reference: 'appchart',
        width: '100%',
        height: '100%'
    }]
});
Ext.define('Ung.cmp.AppMemoryController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.appmemory',

    init: function () {
        this.defaultColors = ['#00b000', '#3030ff', '#009090', '#00ffff', '#707070', '#b000b0', '#fff000', '#b00000', '#ff0000', '#ff6347', '#c0c0c0'];
    },

    control: {
        '#': {
            afterrender: 'onAfterRender',
            // resize: 'onResize'
        }
    },
    listen: {
        store: {
            '#metrics': {
                datachanged: 'onAddPoint'
            }
        }
    },
    updateMetricsCount: 0,

    maxMemory: 0,
    onAfterRender: function (view) {
        var me = this;

        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.metricManager.getMemTotal')
        ]).then(function(result){
            me.maxMemory = Ung.util.Util.humanReadabletoBytes(Ext.getStore('stats').getAt(0).get('totalMemory'));

            me.chart = new Highcharts.Chart({
                chart: {
                    type: 'area',
                    //zoomType: 'x',
                    renderTo: view.lookupReference('appchart').getEl().dom,
                    marginBottom: 20,
                    marginRight: 0,
                    marginLeft: 0,
                    marginTop: 10,
                    padding: [0, 0, 0, 0],
                    backgroundColor: 'transparent',
                    animation: true,
                    style: {
                        fontFamily: 'Source Sans Pro',
                        fontSize: '12px'
                    }
                },
                exporting: {
                    enabled: false
                },
                title: null,
                credits: {
                    enabled: false
                },
                xAxis: [{
                    type: 'datetime',
                    crosshair: {
                        width: 1,
                        dashStyle: 'ShortDot',
                        color: 'rgba(100, 100, 100, 0.3)'
                    },
                    lineColor: '#C0D0E0',
                    lineWidth: 1,
                    tickLength: 3,
                    gridLineWidth: 1,
                    gridLineDashStyle: 'dash',
                    gridLineColor: '#EEE',
                    labels: {
                        style: {
                            fontFamily: 'Source Sans Pro',
                            color: '#555',
                            fontSize: '11px',
                            fontWeight: 600
                        },
                        y: 12
                    },
                    maxPadding: 0,
                    minPadding: 0
                }],
                yAxis: {
                    allowDecimals: false,
                    min: 0,
                    max: me.maxMemory,
                    lineColor: '#C0D0E0',
                    lineWidth: 1,
                    gridLineWidth: 1,
                    gridLineDashStyle: 'dash',
                    gridLineColor: '#EEE',
                    minRange: 1,
                    tickPixelInterval: 50,
                    tickLength: 5,
                    tickWidth: 1,
                    showFirstLabel: false,
                    showLastLabel: true,
                    maxPadding: 0,
                    opposite: false,
                    labels: {
                        align: 'left',
                        useHTML: true,
                        padding: 0,
                        style: {
                            fontFamily: 'Source Sans Pro',
                            color: '#555',
                            fontSize: '11px',
                            fontWeight: 600,
                            background: 'rgba(255, 255, 255, 0.6)',
                            padding: '0 1px',
                            borderRadius: '2px',
                            lineHeight: '11px'
                        },
                        x: 2,
                        y: 5
                    }
                },
                legend: {
                    enabled: false
                },
                tooltip: {
                    shared: true,
                    animation: true,
                    followPointer: true,
                    backgroundColor: 'rgba(255, 255, 255, 0.7)',
                    borderWidth: 1,
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                    style: {
                    textAlign: 'right',
                        fontFamily: 'Source Sans Pro',
                        padding: '5px',
                        fontSize: '10px',
                        marginBottom: '40px'
                    },
                    hideDelay: 0,
                    shadow: false,
                    headerFormat: '<span style="font-size: 11px; line-height: 1.5; font-weight: bold;">{point.key}</span><br/>',
                    pointFormatter: function () {
                        var str = '<span>' + this.series.name + '</span>';
                        if(this.maxMemory != undefined){
                            str += ': <span style="color: ' + this.color + '; font-weight: bold;">' + ( (this.y / this.maxMemory)  * 100).toFixed() + '</span>%';
                        }
                        return str + '<br/>';
                    }
                },
                plotOptions: {
                    area: {
                        fillOpacity: 0.15,
                        lineWidth: 2
                    },
                    spline: {
                        lineWidth: 2,
                        softThreshold: false
                    },
                    series: {
                        marker: {
                            enabled: true,
                            radius: 3,
                            states: {
                                hover: {
                                    enabled: true,
                                    lineWidthPlus: 2,
                                    radius: 4,
                                    radiusPlus: 2
                                }
                            }
                        },
                        states: {
                            hover: {
                                enabled: true,
                                lineWidthPlus: 0,
                                halo: {
                                    size: 2
                                }
                            }
                        }
                    }
                },
                series: [{
                    name: 'Memory Usage'.t(),
                    data: (function () {
                        var data = [],
                            time = Util.getMilliseconds(),
                            i;
                        time = Math.round(time/1000) * 1000;
                        for (i = -6; i <= 0; i += 1) {
                            data.push({
                                x: time + i * 10000,
                                y: 0
                            });
                        }
                        return data;
                    }())
                }]
            });
        }, function (ex) {
            Util.handleException(ex);
        });

    },

    onResize: function () {
        this.getViewController().chart.reflow();
    },

    onAddPoint: function () {
        var me = this;
        if (!this.chart) {
            return;
        }
        var vm = this.getViewModel();
        if (!vm.get('state.on') && this.updateMetricsCount > 0) {
            return;
        }
        this.updateMetricsCount++;
        var appMetrics = Ext.getStore('metrics').findRecord('appId', vm.get('instance.id'));
        if(!appMetrics){
            return;
        }

        var newVal = appMetrics.get('metrics').list.filter(function (metric) {
            return metric.name === 'memory';
        })[0].value || 0;

        me.chart.series[0].addPoint({
            x: Date.now(),
            y: newVal,
            maxMemory: me.maxMemory
        }, true, true);

    }
});
Ext.define('Ung.cmp.AppMetrics', {
    extend: 'Ext.grid.property.Grid',
    alias: 'widget.appmetrics',
    title: 'Metrics'.t(),
    border: false,
    scrollable: true,

    nameColumnWidth: 250,
    hideHeaders: true,

    viewModel: {
        data: {
            metrics: null
        }
    },

    disabled: true,
    bind: {
        disabled: '{!state.on}',
        source: '{metrics}'
    },

    controller: {
        updateMetricsCount: 0,
        control: {
            '#': {
                afterrender: function () {
                    var me = this;
                    me.getViewModel().bind('{instance.runState}', function () {
                        me.updateMetrics();
                    });
                }
            }
        },
        listen: {
            store: {
                '#metrics': {
                    datachanged: 'updateMetrics'
                }
            }
        },

        updateMetrics: function () {
            var vm = this.getViewModel();
            if( !vm.get('state.on') && this.updateMetricsCount > 0) {
                return;
            }
            this.updateMetricsCount++;
            var gridSource = {};
            var appMetrics = Ext.getStore('metrics').findRecord('appId', vm.get('instance.id'));
            if (appMetrics) {
                var expertMode = Rpc.directData('rpc.isExpertMode');
                appMetrics.get('metrics').list.forEach(function (metric) {
                    if(!metric.expert || expertMode){
                        gridSource[metric.displayName.t()] = metric.value + ( metric.displayUnits ? metric.displayUnits : '');
                    }
                });
            }
            vm.set('metrics', gridSource);
        }
    },

    listeners: {
        beforeedit: function () {
            return false;
        }
    }

});
Ext.define('Ung.cmp.AppPanel', {
    extend: 'Ext.tab.Panel',
    alias: 'widget.apppanel',
    layout: 'fit',

    dockedItems: [{
        xtype: 'toolbar',
        ui: 'footer',
        dock: 'top',
        style: { background: '#D8D8D8' },
        items: [{
            xtype: 'button',
            iconCls: 'fa fa-arrow-circle-left',
            hrefTarget: '_self',
            bind: {
                text: 'Back to Apps (<strong>{policyName}</strong>)',
                href: '#apps/{policyId}'
            }
        }, {
            xtype: 'component',
            padding: '0 5',
            bind: {
                html: '<img src="/icons/apps/{props.name}.svg" style="vertical-align: middle;" width="16" height="16"/> <strong>{props.displayName}</strong>' +
                    ' <i class="fa fa-circle {state.colorCls}"></i>'
            }
        }, {
            xtype: 'button',
            itemId: 'reportsBtn',
            ui: 'none',
            margin: '0 5',
            cls: 'view-reports',
            text: '<i class="fa fa-area-chart"></i> ' + 'View Reports'.t(),
            hrefTarget: '_self',
            hidden: true,
            bind: {
                href: '#reports?cat={props.name}',
                hidden: '{!reportsAppStatus.installed || !reportsAppStatus.enabled || !state.on}'
            }
        }]
    }, {
        xtype: 'toolbar',
        dock: 'bottom',
        items: ['->', {
            text: '<strong>' + 'Save'.t() + '</strong>',
            bind:{
                disabled: '{panel.saveDisabled}',
                hidden: '{vueMigrated}'
            },
            iconCls: 'fa fa-floppy-o fa-lg',
            handler: 'setSettings'
        }]
    }],

    listeners: {
        // generic listener for all tabs in Apps, redirection
        beforetabchange: function (tabPanel, newCard, oldCard) {
            var vm = this.getViewModel();
            if (vm.get('props.type') === 'FILTER') {
                Ung.app.redirectTo('#apps/' + vm.get('policyId') + '/' + vm.get('urlName') + '/' + newCard.getItemId());
            } else {
                Ung.app.redirectTo('#service/' + vm.get('props.name') + '/' + newCard.getItemId());
            }
        },

        tabchange: function (tabPanel) {
            Ung.app.hashBackup = window.location.hash; // keep track of hash for changes detection
        },

        afterrender: function (appPanel) {
            if (appPanel.tabBar && appPanel.getViewModel().get('vueMigrated')) {
                appPanel.tabBar.hide();
            }
            // code used for detecting user manual data change
            Ung.app.hashBackup = window.location.hash; // keep track of hash for changes detection
            Ext.Array.each(appPanel.query('field'), function (field) {
                // setup the _initialValue of the field on focus
                field.on('focus', function () {
                    if (!field.hasOwnProperty('_initialValue')) {
                        field._initialValue = field.getValue();
                    }
                });
                field.on('blur', function () {
                    // on field blur check if new value is different than the initial one
                    // add an _isChanged prop which is true if field value is really changed by the user manually
                    if (field._initialValue !== field.getValue()) {
                        field._isChanged = true;
                    } else {
                        field._isChanged = false;
                    }
                });
            });

            // remove View Reports tab button if App does not have reports (e.g. Reports App)
            if (!appPanel.down('appreports')) {
                var rbtn = appPanel.getTabBar().down('#reportsBtn');
                appPanel.getTabBar().remove(rbtn);
            }

        },

        removed: function(){
            this.getViewModel().set('panel.saveDisabled', false);
        }
    }
});
Ext.define('Ung.cmp.AppRemove', {
    extend: 'Ext.button.Button',
    alias: 'widget.appremove',

    // title: '<i class="fa fa-trash fa-red"></i> ' + 'Remove'.t(),

    // padding: 10,
    // margin: '20 0',
    // cls: 'app-section',
    // style: {
    //     borderColor: 'red'
    // },
    viewModel: true,
    hidden: Rpc.directData('rpc.UvmContext.licenseManager.isRestricted'),

    bind: {
        text: 'Remove'.t() + ' {props.displayName}',
    },
    iconCls: 'fa fa-minus-circle fa-red',
    handler: function (btn) {
        var vm = this.getViewModel(),
            mainView = btn.up('#appCard'),
            // settingsView = this.getView();
            message = Ext.String.format('{0} will be uninstalled from this policy.'.t(), vm.get('props.displayName')) + '<br/>' +
            'All of its settings will be lost.'.t() + '\n' + '<br/>' + '<br/>' +
            'Would you like to continue?'.t();

        if (vm.get('instance.appName') === 'policy-manager') { // rebuild policies tree
            if (Ext.getStore('policiestree').getCount() > 1) {
                Ext.Msg.alert('Warning!', 'Policy Manager cannot be removed if there are more than one default policy!');
                return;
            }
        }

        Ext.Msg.confirm('Warning:'.t(), message, function(btn) {
            if (btn === 'yes') {
                // var appItem = settingsView.up('#main').down('#apps').down('#' + vm.get('appInstance.appName'));
                mainView.setLoading(true);

                Rpc.asyncData('rpc.appManager.destroy', vm.get('instance.id'))
                    .then(function () {

                        if (vm.get('instance.appName') === 'reports') {
                            Ung.app.reportscheck(); // check reports
                            Ung.app.redirectTo('#apps');
                            return;
                        }

                        if (vm.get('instance.appName') === 'policy-manager') { // rebuild policies tree
                            Ext.getStore('policiestree').build();
                        }

                        Ext.fireEvent('appremove', vm.get('props.displayName'));

                        vm.set('instance.targetState', null);
                        vm.set('instance.runState', null);

                        Ung.app.redirectTo('#apps/' + vm.get('policyId'));

                        // remove card
                        if (Ung.app.getMainView().down('#appCard')) {
                            Ung.app.getMainView().remove('appCard');
                        }
                    }, function (ex) {
                        Util.handleException(ex);
                    });
            }
        });
    }
});
Ext.define('Ung.cmp.AppReports', {
    extend: 'Ext.form.FieldSet',
    alias: 'widget.appreports',
    title: '<i class="fa fa-pie-chart"></i> ' + 'Reports'.t(),

    viewModel: {
        stores: {
            appReports: {
                source: 'reports',
                filters: [{
                    property: 'category',
                    value: '{props.displayName}',
                    exactMatch: true
                }]
            }
        }
    },

    padding: 10,
    margin: '20 0',
    cls: 'app-section',

    collapsed: true,
    disabled: true,
    hidden: true,
    bind: {
        collapsed: '{!state.on}',
        disabled: '{!state.on}',
        hidden: '{!reportsAppStatus.enabled}'
    },

    items: [{
        xtype: 'dataview',
        bind: '{appReports}',
        cls: 'app-reports',
        tpl: '<tpl for=".">' +
                '<a href="#reports?{url}"><i class="fa {icon}"></i> {localizedTitle}</a>' +
            '</tpl>',
        itemSelector: 'a'
    }]

});
Ext.define('Ung.cmp.AppSessions', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.appsessions',

    title: 'Sessions'.t(),
    border: false,

    controller: 'appsessions',
    viewModel: true,

    disabled: true,
    bind: {
        disabled: '{!state.on}',
    },

    layout: 'fit',
    items: [{
        xtype: 'component',
        reference: 'appchart',
        width: '100%',
        height: '100%'
    }]
});
Ext.define('Ung.cmp.AppSessionsController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.appsessions',

    init: function () {
        this.defaultColors = ['#00b000', '#3030ff', '#009090', '#00ffff', '#707070', '#b000b0', '#fff000', '#b00000', '#ff0000', '#ff6347', '#c0c0c0'];
    },

    control: {
        '#': {
            afterrender: 'onAfterRender',
            resize: 'onResize'
        }
    },
    listen: {
        store: {
            '#metrics': {
                datachanged: 'onAddPoint'
            }
        }
    },
    updateMetricsCount: 0,

    onAfterRender: function (view) {
        this.chart = new Highcharts.Chart({
            chart: {
                type: 'area',
                //zoomType: 'x',
                renderTo: view.lookupReference('appchart').getEl().dom,
                marginBottom: 20,
                marginRight: 0,
                marginLeft: 0,
                marginTop: 10,
                padding: [0, 0, 0, 0],
                backgroundColor: 'transparent',
                animation: true,
                style: {
                    fontFamily: 'Source Sans Pro',
                    fontSize: '12px'
                }
            },
            exporting: {
                enabled: false
            },
            title: null,
            credits: {
                enabled: false
            },
            xAxis: [{
                type: 'datetime',
                crosshair: {
                    width: 1,
                    dashStyle: 'ShortDot',
                    color: 'rgba(100, 100, 100, 0.3)'
                },
                lineColor: '#C0D0E0',
                lineWidth: 1,
                tickLength: 3,
                gridLineWidth: 1,
                gridLineDashStyle: 'dash',
                gridLineColor: '#EEE',
                labels: {
                    style: {
                        fontFamily: 'Source Sans Pro',
                        color: '#555',
                        fontSize: '11px',
                        fontWeight: 600
                    },
                    y: 12
                },
                maxPadding: 0,
                minPadding: 0
            }],
            yAxis: {
                allowDecimals: false,
                min: 0,
                lineColor: '#C0D0E0',
                lineWidth: 1,
                gridLineWidth: 1,
                gridLineDashStyle: 'dash',
                gridLineColor: '#EEE',
                minRange: 1,
                tickPixelInterval: 50,
                tickLength: 5,
                tickWidth: 1,
                showFirstLabel: false,
                showLastLabel: true,
                maxPadding: 0,
                opposite: false,
                labels: {
                    align: 'left',
                    useHTML: true,
                    padding: 0,
                    style: {
                        fontFamily: 'Source Sans Pro',
                        color: '#555',
                        fontSize: '11px',
                        fontWeight: 600,
                        background: 'rgba(255, 255, 255, 0.6)',
                        padding: '0 1px',
                        borderRadius: '2px',
                        //textShadow: '1px 1px 1px #000'
                        lineHeight: '11px'
                    },
                    x: 2,
                    y: 5
                }
            },
            legend: {
                enabled: false
            },
            tooltip: {
                shared: true,
                animation: true,
                followPointer: true,
                backgroundColor: 'rgba(255, 255, 255, 0.7)',
                borderWidth: 1,
                borderColor: 'rgba(0, 0, 0, 0.1)',
                style: {
                    textAlign: 'right',
                    fontFamily: 'Source Sans Pro',
                    padding: '5px',
                    fontSize: '10px',
                    marginBottom: '40px'
                },
                //useHTML: true,
                hideDelay: 0,
                shadow: false,
                headerFormat: '<span style="font-size: 11px; line-height: 1.5; font-weight: bold;">{point.key}</span><br/>',
                pointFormatter: function () {
                    var str = '<span>' + this.series.name + '</span>';
                    str += ': <span style="color: ' + this.color + '; font-weight: bold;">' + this.y + '</span> sessions';
                    return str + '<br/>';
                }
            },
            plotOptions: {
                area: {
                    fillOpacity: 0.15,
                    lineWidth: 2
                },
                spline: {
                    lineWidth: 2,
                    softThreshold: false
                },
                series: {
                    marker: {
                        enabled: true,
                        radius: 3,
                        states: {
                            hover: {
                                enabled: true,
                                lineWidthPlus: 2,
                                radius: 4,
                                radiusPlus: 2
                            }
                        }
                    },
                    states: {
                        hover: {
                            enabled: true,
                            lineWidthPlus: 0,
                            halo: {
                                size: 2
                            }
                        }
                    }
                }
            },
            series: [{
                name: 'Sessions'.t(),
                data: (function () {
                    var data = [],
                        time = Util.getMilliseconds(),
                        i;
                    time = Math.round(time/1000) * 1000;
                    for (i = -6; i <= 0; i += 1) {
                        data.push({
                            x: time + i * 10000,
                            y: 0
                        });
                    }
                    return data;
                }())
            }]
        });
    },

    onResize: function () {
        this.chart.reflow();
    },

    onAddPoint: function () {
        if (!this.chart) {
            return;
        }
        var vm = this.getViewModel();
        if (!vm.get('state.on') && this.updateMetricsCount > 0) {
            return;
        }
        this.updateMetricsCount++;
        var appMetrics = Ext.getStore('metrics').findRecord('appId', vm.get('instance.id'));
        if(!appMetrics){
            return;
        }
        var newVal = appMetrics.get('metrics').list.filter(function (metric) {
            return metric.name === 'live-sessions';
        })[0].value || 0;

        // random for testing
        // newVal = Math.floor(Math.random() * 20) + 15;

        this.chart.series[0].addPoint({
            x: Date.now(),
            y: newVal
        }, true, true);

    }
});
Ext.define('Ung.cmp.AppState', {
    extend: 'Ext.form.FieldSet',
    alias: 'widget.appstate',
    title: '<i class="fa fa-power-off"></i> ' + 'Power'.t(),

    padding: 10,
    margin: '20 0',
    cls: 'app-section',

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    viewModel: {
        formulas: {
            appState: function (get) {
                return Ext.String.format('{0} is {1}.', get('props.displayName'), get('state.status').toLowerCase());
            },
            appStateIcon: function (get) {
                var cls = get('state.colorCls');
                if(!get('state.inconsistent') &&
                    !get('state.power') &&
                    !get('state.on') ||
                    get('state.expired')){
                    cls = 'fa-flip-horizontal ' + cls;
                }
                return cls;
            },
            appStatus: function(get){
                return this.getView().up('#appCard').appManager.getStatus();
            }
        }
    },

    controller: {
        reload: function(){
            var me = this,
                appManager = me.getView().up('#appCard').appManager,
                appView = me.getView().up('#appCard');

            appView.getViewModel().get('state').detect();

            rpc.appsViews = rpc.appManager.getAppsViews();
            Ext.getStore('policies').loadData(rpc.appsViews);
            Ung.app.getGlobalController().getAppsView().getController().getApps();

            if (appManager.getAppProperties().name === 'reports') {
                Ung.app.reportscheck();
            }

        },

        onPower: function (btn) {
            var me = this,
                appManager = me.getView().up('#appCard').appManager,
                appView = me.getView().up('#appCard');

            btn.setDisabled(true);

            appView.getViewModel().get('state').set('power', true);
            if ( appView.getViewModel().get('state').get('on') ){
                appView.getViewModel().get('state').set('on', false);
                appView.getViewModel().set('instance.targetState', 'INITIALIZED');
                Rpc.asyncData(appManager, 'stop')
                .then( function(result){
                    if(Util.isDestroyed(me, btn)){
                        return;
                    }
                    btn.setDisabled(false);
                    me.reload();
                },function(ex){
                    Util.handleException(ex);
                });
            } else {
                appView.getViewModel().get('state').set('on', true);
                appView.getViewModel().set('instance.targetState', 'RUNNING');
                Rpc.asyncData(appManager, 'start')
                .then( function(result){
                    if(Util.isDestroyed(me, btn)){
                        return;
                    }
                    btn.setDisabled(false);
                    if (appManager.getAppProperties().name === 'bandwidth-control') {
                        // sync the qosEnabled code after app is enabled
                        appView.getController().fetchQosData();
                    }
                    me.reload();
                },function(ex){
                    Ext.Msg.alert('Error', ex.message);
                    if(Util.isDestroyed(btn)){
                        return;
                    }
                    // Likely due to an invalid licnese.
                    // Expect the app to shutdown
                    btn.setDisabled(false);
                });
            }
        }
    },

    items: [{
        xtype: 'container',
        layout: 'hbox',
        items: [{
            xtype: 'button',
            cls: 'power-btn',
            bind: {
                iconCls: 'fa fa-toggle-on {appStateIcon} fa-2x'
            },
            handler: 'onPower'
        }, {
            xtype: 'component',
            padding: '3 5',
            bind: {
                html: '<strong>' + '{appState}' + '</strong>'
            }
        }, {
            xtype: 'component',
            html: '<i class="fa fa-spinner fa-spin fa-lg fa-fw"></i>',
            hidden: true,
            bind: {
                hidden: '{!state.power}',
            }
        }]
    },{
        xtype: 'container',
        layout: 'hbox',
        flex: 1,
        hidden: true,
        bind: {
            hidden: '{!state.inconsistent}',
        },
        items:[{
            fieldLabel: 'Status'.t(),
            xtype: 'textarea',
            height: 100,
            flex: 1,
            fieldStyle: {
                fontFamily: 'monospace'
            },
            bind: {
                value: '{appStatus}'
            }
        }]
    }]
});
/**
 * Used in Policy Overview widget
 */
Ext.define('Ung.cmp.AppsPicker', {
    extend: 'Ext.form.field.Picker',
    alias: 'widget.appspicker',

    baseCls: 'tagpicker',

    twoWayBindable: ['apps', 'value'],

    displayField: false,
    valueField: false,
    delimiter: ', ',

    editable: false,
    hideTrigger: true,

    apps: [],

    fieldSubTpl: [
        // listWrapper div is tabbable in Firefox, for some unfathomable reason
        '<div id="{cmpId}-listWrapper" data-ref="listWrapper"' + (Ext.isGecko ? ' tabindex="-1"' : ''),
            '<tpl foreach="ariaElAttributes"> {$}="{.}"</tpl>',
            ' class="' + Ext.baseCSSPrefix + 'tagfield {fieldCls} {typeCls} {typeCls}-{ui}"<tpl if="wrapperStyle"> style="{wrapperStyle}"</tpl>>',
            '<span id="{cmpId}-selectedText" data-ref="selectedText" aria-hidden="true" class="' + Ext.baseCSSPrefix + 'hidden-clip"></span>',
            '<ul id="{cmpId}-itemList" data-ref="itemList" role="presentation" class="' + Ext.baseCSSPrefix + 'tagfield-list{itemListCls}">',
                '<li id="{cmpId}-inputElCt" data-ref="inputElCt" role="presentation" class="' + Ext.baseCSSPrefix + 'tagfield-input">',
                    '<input id="{cmpId}-inputEl" data-ref="inputEl" type="{type}" style="cursor: pointer;"',
                    '<tpl if="name">name="{name}" </tpl>',
                    '<tpl if="value"> value="{[Ext.util.Format.htmlEncode(values.value)]}"</tpl>',
                    '<tpl if="size">size="{size}" </tpl>',
                    '<tpl if="tabIdx != null">tabindex="{tabIdx}" </tpl>',
                    '<tpl if="disabled"> disabled="disabled"</tpl>',
                    '<tpl foreach="inputElAriaAttributes"> {$}="{.}"</tpl>',
                    'class="' + Ext.baseCSSPrefix + 'tagfield-input-field {inputElCls} {emptyCls}" autocomplete="off">',
                '</li>',
            '</ul>',
            '<ul id="{cmpId}-ariaList" data-ref="ariaList" role="listbox"',
                '<tpl if="ariaSelectedListLabel"> aria-label="{ariaSelectedListLabel}"</tpl>',
                '<tpl if="multiSelect"> aria-multiselectable="true"</tpl>',
                ' class="' + Ext.baseCSSPrefix + 'tagfield-arialist">',
            '</ul>',
          '</div>',
        {
            disableFormats: true
        }
    ],

    childEls: [
        'listWrapper', 'itemList', 'inputEl', 'inputElCt', 'selectedText', 'ariaList'
    ],

    initComponent: function() {
        this.callParent(arguments);
    },

    createPicker: function() {
        var me = this;
        me.grid = Ext.create('Ext.grid.Panel', {
            renderTo: Ext.getBody(),
            width: this.bodyEl.getWidth(),
            scrollable: true,
            floating: true,
            // maxHeight: 150,
            minWidth: 300,
            disableSelection: true,
            enableColumnHide: false,
            header: false,
            emptyText: '<p style="text-align: center; margin: 0; line-height: 2;"><i class="fa fa-info-circle fa-lg"></i> No Apps!</p>',
            viewConfig: {
                stripeRows: false,
                // trackOver: false
            },
            store: {
                data: me.getApps(),
                sorters: ['inherited']
                // fields: ['name']
            },
            columns: [{
                dataIndex: 'state',
                align: 'right',
                width: 24,
                renderer: function (state) {
                    return '<i class="fa fa-circle ' + (state.get('on') ? 'fa-green' : 'fa-gray') + '"></i>';
                }
            }, {
                dataIndex: 'displayName',
                flex: 1,
                renderer: function (val, meta, record) {
                    var str = '<img src="/icons/apps/' + record.get('name') + '.svg" style="width: 12px; height: 12px; vertical-align: middle;"/> ';
                    if (!record.get('parentPolicy')) {
                        str += '<strong>' + val + '</strong>';
                    } else {
                        str += val + ' <span style="color: #999;">(<em>' + record.get('parentPolicy') + '</em>)</span>';
                    }
                    return str;
                }
            }, {
                xtype: 'actioncolumn',
                iconCls: 'fa fa-external-link-square',
                align: 'center',
                tooltip: 'Go to App'.t(),
                width: 30,
                handler: function (view, rowIndex, colIndex, item, e, record) {
                    Ung.app.redirectTo('#apps/' + record.get('policyId') + '/' + record.get('name'));
                }
            }]
        });

        return me.grid;
    },

    getApps: function () {
        return this.apps;
    },

    setApps: function (apps) {
        this.apps = apps;
        this.setValue(apps);
    },

    setValue: function (apps) {
        var me = this;
        if (!apps) { return; }
        var total = apps.length, running = 0, inherited = 0;
        Ext.Array.each(apps, function (app) {
            if (app.state.get('on')) {
                running++;
            }
            if (app.inherited) {
                inherited++;
            }
        });

        var str = '<li class="_apps" style="font-size: 11px;"><strong>' + total + '</strong>' +
                  '<span style="color: #999"> &nbsp; ' + running + '</span> <i class="fa fa-circle fa-green" style="font-size: 10px;"></i>' +
                  '<span style="color: #999"> &nbsp; ' + inherited + '</span> <i class="fa fa-level-up fa-gray" style="font-size: 10px;"></i>' +
                  '&nbsp;&nbsp;&nbsp;<i class="fa fa-angle-down fa-lg fa-gray"></i></li>';
        me.itemList.select('._apps').destroy();
        me.inputElCt.insertHtml('beforeBegin', str);
    }
});
Ext.syncRequire('Ung.common.threatprevention');
Ext.define('Ung.cmp.ConditionsEditor', {
    extend: 'Ext.form.FieldSet',
    alias: 'widget.conditionseditor',

    controller: 'conditionseditorcontroller',

    model: 'Ung.model.Condition',

    /**
     * The fields object must always be defined so the grid
     * can access it.
     */
    fields: {
        type: 'conditionType',
        comparator: 'invert',
        value: 'value',
    },
    javaClassValue: '',

    conditions: [],
    conditionsOrder: [],

    allowEmpty: true,

    margin: '0 -10 0 -10',

    actions: {
        addCondition: {
            itemId: 'addConditionBtn',
            text: 'Add Condition'.t(),
            iconCls: 'fa fa-plus'
        }
    },

    isFormField: true,

    text:{
        condition: 'If all of the following conditions are met:'.t(),
        action: 'Perform the following action(s):'.t(),
    },

    border: 0,
    items:[{
        xtype: 'component',
        name: 'conditionLabel',
        padding: '10 0 0 0',
        tpl: '<strong>{text.condition}</strong>'
    },{
        xtype: 'grid',
        disableSelection: true,
        sortableColumns: false,
        enableColumnHide: false,
        layout: 'fit',
        padding: '10 0',
        tbar: ['@addCondition'],
        viewConfig: {
            emptyText: '<p style="text-align: center; margin: 0; line-height: 2"><i class="fa {emptyIcon} fa-2x"></i> <br/>{emptyText}</p>',
            stripeRows: false,
        },
        columns: [{
            header: 'Type'.t(),
            widgetType: 'type',
            menuDisabled: true,
            align: 'right',
            width: Renderer.uriWidth,
            renderer: 'conditionRenderer'
        }, {
            xtype: 'widgetcolumn',
            widgetType: 'comparator',
            width: Renderer.comparatorWidth,
            menuDisabled: true,
            resizable: false,
            cellWrap: true,
            sortable: false,
            widget: {
                xtype: 'container',
                layout: 'fit'
            },
            onWidgetAttach: 'onWidgetAttach',
        }, {
            // DO NOT use flex here.  See onAfterGridLayout() in the controller.
            header: 'Value'.t(),
            widgetType: 'value',
            xtype: 'widgetcolumn',
            cellWrap: true,
            menuDisabled: true,
            sortable: false,
            widget: {
                xtype: 'container',
                layout: 'fit'
            },
            onWidgetAttach: 'onWidgetAttach',
        }, {
            xtype: 'actioncolumn',
            menuDisabled: true,
            sortable: false,
            width: Renderer.iconWidth,
            align: 'center',
            iconCls: 'fa fa-minus-circle fa-red',
            tdCls: 'action-cell-cond',
            handler: 'removeCondition'
        }]
    },{
        xtype: 'component',
        name: 'actionLabel',
        padding: '0 0 10 0',
        tpl: '<strong>{text.action}</strong>'
    }],

    constructor: function(config) {
        var me = this;

        var bind = config.bind || me.bind;
        var model = config.model || me.model;
        var allowEmpty = config.allowEmpty || me.allowEmpty;
        var fields = config.fields || me.fields;

        if(bind){
            me.recordName = bind.substring(1,bind.length - 1);
        }
        me.items.forEach(function(item){
            if(item.xtype == 'grid'){
                if(bind){
                    Ext.apply(item, {
                        bind: {
                            store: {
                                model: model,
                                data: '{' + me.recordName +'.list}'
                            }
                        }
                    });
                }
                if(model && item.columns){
                    item.columns.forEach( function(column){
                        if(column.widgetType == 'type'){
                            column.dataIndex = fields.type;
                        }else if(column.widgetType == 'comparator'){
                            column.widget.bind = '{record.' + fields.comparator + '}';
                        }else if(column.widgetType == 'value'){
                            column.widget.bind = '{record.' + fields.value + '}';
                        }
                    });
                }
                item.viewConfig.emptyText = new Ext.Template(item.viewConfig.emptyText).apply({
                    emptyIcon: allowEmpty ? 'fa-exclamation-triangle' : 'fa-exclamation-circle',
                    emptyText: 'No Conditions! Add from the menu...'.t()
                });
            }
        });
        if(bind){
            delete config.bind;
        }
        me.callParent(arguments);
    },

    validate: function(){
        return this.getController().validate();
    },
    isValid: function(){
        return this.getController().validate();
    },

    statics:{
        rendererConditionTemplate: '{type} <strong>{comparator} <span class="cond-val"> {value}</span></strong>'.t(),
        renderer: function(value, meta){
            if (!value) {
                // No value to process.
                return '';
            }

            var me = this,
                view = me.getView().up('grid'),
                conditions = value.list,
                resp = [], i, valueRenderer = [];

            var conditionsEditorField = Ext.Array.findBy(view.editorFields, function(item){
                if(item.xtype.indexOf('conditionseditor') > -1){
                    return true;
                }
            });

            var conditionsMap = conditionsEditorField.conditions;
            if(conditionsMap == null){
                return '';
            }
            conditions.forEach(function(condition){
                var type = condition[conditionsEditorField.fields.type];
                var comparator = condition[conditionsEditorField.fields.comparator];
                var value = condition[conditionsEditorField.fields.value];

                if(!conditionsMap[type]){
                    return;
                }

                var comparatorRender = '';
                var valueRenderer = [];

                switch (type) {
                    case 'SRC_INTF':
                    case 'DST_INTF':
                        if (value != null) {
                            value.toString().split(',').forEach(function (intfff) {
                                    Util.getInterfaceList(true, true).forEach(function(intf){
                                    if(intf[0] == intfff){
                                        valueRenderer.push(intf[1]);
                                    }
                                });
                            });
                        }
                    break;
                    case 'DST_LOCAL':
                    case 'WEB_FILTER_FLAGGED':
                        valueRenderer.push('true'.t());
                        break;
                    case 'DAY_OF_WEEK':
                        value.toString().split(',').forEach(function (day) {
                            valueRenderer.push(Util.weekdaysMap[day]);
                        });
                        break;
                    default:
                        // to avoid exceptions, in some situations condition value is null
                        if (value !== null) {
                            var found = false;
                            Ung.cmp.ConditionsEditor.conditions.forEach(function(condition){
                                if(condition['name'] == type && condition['values']){
                                    var newValue = [];
                                    value.split(',').forEach(function(v){
                                        found = false;
                                        condition['values'].forEach(function(record){
                                            if(record[0] == v){
                                                found = true;
                                                newValue.push(record[1]);
                                            }
                                        });
                                        if(found == false){
                                            newValue.push(v);
                                        }
                                    });
                                    value = newValue.join(',');
                                }
                            });
                            valueRenderer = value.toString().split(',');
                        } else {
                            valueRenderer = [];
                        }
                }

                switch(conditionsMap[type].type){
                    case 'sizefield':
                        valueRenderer = [Renderer.datasize(value)];
                        break;
                    case 'boolean':
                        if(conditionsMap[type].values){
                            conditionsMap[type].values.forEach(function(field){
                                if(field[0].toString() == value.toString().toLowerCase()){
                                    valueRenderer = [field[1]];
                                }
                            });
                        }else{
                            valueRenderer = ['True'.t()];
                        }
                        break;
                }

                if(conditionsEditorField.fields.comparator == 'invert'){
                    comparatorRender = (comparator == true ? '&nrArr;' : '&rArr;' );
                }else{
                    switch(conditionsMap[type].comparator){
                        case 'boolean':
                            comparatorRender = (comparator == false ? '&nrArr;' : '&rArr;' );
                            break;
                        case 'numeric':
                            switch(comparator){
                                case '<=':
                                    comparatorRender = '&le;';
                                    break;
                                case '>=':
                                    comparatorRender = '&ge;';
                                    break;
                                default:
                                    comparatorRender = comparator;
                            }
                            break;
                        default:
                            switch(comparator){
                                case 'substr':
                                    comparatorRender = '&sub;';
                                    break;
                                case '!substr':
                                    comparatorRender = '&nsub;';
                                    break;
                                default:
                                    comparatorRender = comparator;
                            }
                            break;
                    }
                }
                resp.push(new Ext.Template(
                    Ung.cmp.ConditionsEditor.rendererConditionTemplate
                ).apply({
                    type: ( conditionsMap[type] != undefined ? conditionsMap[type].displayName : type ),
                    comparator: comparatorRender,
                    value: valueRenderer.join(', ')
                }));
            });
            meta.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( resp.join(' &nbsp;&bull;&nbsp; ') ) + '"';
            return resp.length > 0 ? resp.join(' &nbsp;&bull;&nbsp; ') : '<em>' + 'No conditions' + '</em>';
        },
        ProcessDCUserNGroupDataMerge: function(data, result) {
            Ext.Array.each(data.reverse(), function(record) {
                result.list.unshift(record);
            });
            return result.list;
        },
        /**
         * Nearly all rule conditions use the same condition.  Most that don't use a subset.
         * Define what you want by the name values such as:
         *     buildConditions('DST_ADDR', 'DST_PORT', ...)
         * 
         * If you want to customize, specify as an object such as:
         *     buildConditions( {
         *         name: 'DST_LOCAL', 
         *         visibile: false
         *     }, ...)
         * 
         * If you want to pick from this set but add a new condition that won't be used anywhere
         *  else, specify the displayName and type such as:
         *     buildConditions( {
         *         name: 'NEW_CONDITION',
         *         displayName: 'New condition'.t(),
         *         type: 'textField'
         *     }, ...)
         *
         * If your condition set doesn't use any of these and is only used in one module,
         * just define those as a static list without calling this method such as:
         * conditions: [{
         *     name: 'CONDITION_ONLY_HERE',
         *     displayName: 'Only Here Condition'.t(),
         *     type: 'textField'
         * }]
         * 
         * @return {[type]} [description]
         */
        defaultCondition: {
            name: 'name',
            displayName: 'name',
            type: 'textfield',
            comparator: 'invert',
            visible: true,
            allowMultiple: false

        },
        build: function(config){
            var comparators = Ext.clone(Ung.cmp.ConditionsEditor.comparators);
            var me = this;
            var found;
            for(var key in config){
                if(key == 'comparators'){
                    config[key].forEach( function(comparator){
                        found = false;
                        comparators.forEach(function(existingComparator, index){
                            if(existingComparator['name'] == comparator['name']){
                                found = true;
                                comparators[index] = comparator;
                            }
                        });
                        if(found == false){
                            comparators.push(comparator);
                        }
                    });
                }else if(key == 'conditions'){
                    var conditionsOrder = [];
                    var conditions = [];
                    found = false;
                    config[key].forEach( function(configCondition){
                        configCondition = typeof(configCondition) == 'object' ? configCondition : {name: configCondition};

                        var newCondition = Ext.clone(Ung.cmp.ConditionsEditor.defaultCondition);

                        found = false;

                        // Lookup in existing conditions.
                        Ung.cmp.ConditionsEditor.conditions.forEach( function(condition){
                            if(condition.name == configCondition.name){
                                Ext.merge(newCondition, condition);
                                Ext.merge(newCondition, configCondition);
                                conditions.push(newCondition);
                                conditionsOrder.push(newCondition.name);
                                found = true;
                            }
                        });
                        if(!found){
                            // Add new condition
                            if('name' in configCondition && 'displayName' in configCondition && 'type' in configCondition ){
                                Ext.merge(newCondition, configCondition);
                                conditions.push(newCondition);
                                conditionsOrder.push(newCondition.name);
                            }else{
                                console.log("not found");
                                console.log(configCondition);
                            }
                        }
                    } );
                    conditions.forEach(function (currItem){
                        me.getWidgetDataAndField(me, currItem.type, currItem);
                    });
                    config[key] = Ext.Array.toValueMap(conditions, 'name');
                    if( !config['conditionsOrder'] ){
                        config['conditionsOrder'] = conditionsOrder;
                    }
                }
            }
            config['comparators'] = comparators;
            return Ext.apply({}, config);
        },

        comparators: [{
            name: 'invert',
            defaultValue: 'is',
            store: [[
                true, 'is NOT'.t()
            ],[
                false, 'is'.t()
            ]]
        },{
            name: 'numeric',
            defaultValue: '=',
            store:  [[
                '<', '<'.t()
            ],[
                '<=', '<='.t()
            ],[
                '=', '='.t()
            ],[
                '!=', '!='.t()
            ],[
                '>=', '>='.t()
            ],[
                '>', '>'.t()
            ]]
        },{
            name: 'text',
            defaultValue: 'substr',
            store: [[
                '=', '='.t()
            ],[
                '!=', '!='.t()
            ],[
                'substr', 'Contains'.t()
            ],[
                '!substr', 'Does not contain'.t()
            ]]
        },{
            // More accurately a "boolean in string" where is:= and is not:!=
            name: 'boolean',
            defaultValue: '=',
            store: [[
                '=', 'is'.t()
            ],[
                '!=', 'is NOT'.t()
            ]]
        }],

        getWidgetDataAndField: function(me, type, currItem){
            switch (type) {
                case "userfield": {
                    currItem["getData"] = function (field) {
                        var data = [{
                            firstName: '', lastName: null, uid: '[any]', displayName: 'Any User'
                        }, {
                            firstName: '', lastName: null, uid: '[authenticated]', displayName: 'Any Authenticated User'
                        }, {
                            firstName: '', lastName: null, uid: '[unauthenticated]', displayName: 'Any Unauthenticated/Unidentified User'
                        }];

                        if (field) {
                            return Rpc.asyncData('rpc.appManager.app', 'directory-connector')
                                .then(function (app) {
                                    if (Util.isDestroyed(field)) {
                                        return data;
                                    }
                                    if (app) {
                                        return Rpc.asyncData(app, 'getRuleConditonalUserEntries')
                                            .then(function (result) {
                                                if (Util.isDestroyed(field)) {
                                                    return data;
                                                }
                                                return me.ProcessDCUserNGroupDataMerge(data, result);
                                            }, function (ex) {
                                                Util.handleException(ex);
                                                return data;
                                            });
                                    }
                                    return data;
                                }, function (ex) {
                                    Util.handleException(ex);
                                    return data;
                                });
                        } else {
                            try {
                                var appData = Rpc.directData('rpc.appManager.app', 'directory-connector');
                                if (appData) {
                                    var result = Rpc.directData(appData, 'getRuleConditonalUserEntries');
                                    return { keyName: 'uid', data: me.ProcessDCUserNGroupDataMerge(data, result) };
                                }
                            } catch (ex) {
                                Util.handleException(ex);
                                return { keyName: 'uid', data: data };
                            }
                        }
                        return data;
                    };

                    currItem["widgetCreator"] = function (widget, valueBind, condition) {
                        widget.container.add({
                            xtype: 'tagfield',
                            flex: 1,
                            emptyText: 'Select a user or specify a custom value ...',
                            store: { data: [] },
                            filterPickList: true,
                            forceSelection: false,
                            queryMode: 'local',
                            selectOnFocus: false,
                            growMax: 60,
                            createNewOnEnter: true,
                            createNewOnBlur: true,
                            displayField: 'uid',
                            valueField: 'uid',
                            listConfig: {
                                itemTpl: ['<div>{uid}</div>']
                            },
                            bind: {
                                value: valueBind
                            },
                            listeners: {
                                afterrender: function (field) {
                                    condition.getData(field).then(function(data) {
                                        field.getStore().loadData(data);
                                    },function(error) {
                                        console.log("Error occurred while loading user:", error);
                                    });                                    
                                }
                            }
                        });
                    };
                } 
                break;
            
                case "directorygroupfield": {
                    currItem["getData"] = function (field) {
                        var data = [{
                            SAMAccountName: '*', CN: 'Any Group'
                        }];

                        if (field) {
                            return Rpc.asyncData('rpc.appManager.app', 'directory-connector')
                                .then(function (app) {
                                    if (Util.isDestroyed(field)) {
                                        return data;
                                    }
                                    if (app) {
                                        return Rpc.asyncData(app, 'getRuleConditionalGroupEntries')
                                            .then(function (result) {
                                                if (Util.isDestroyed(field)) {
                                                    return data;
                                                }
                                                return  me.ProcessDCUserNGroupDataMerge(data, result);
                                            }, function (ex) {
                                                Util.handleException(ex);
                                                return data;
                                            });
                                    }
                                }, function (ex) {
                                    Util.handleException(ex);
                                    return data;
                                });
                        } else {
                            try {
                                var appData = Rpc.directData('rpc.appManager.app', 'directory-connector');
                                if (appData) {
                                    var result = Rpc.directData(appData, 'getRuleConditionalGroupEntries');
                                    return { keyName: 'SAMAccountName', data: me.ProcessDCUserNGroupDataMerge(data, result) };
                                }
                            } catch (ex) {
                                Util.handleException(ex);
                                return { keyName: 'SAMAccountName', data: data };
                            }
                        }
                        return data;
                    };

                    currItem["widgetCreator"] = function (widget, valueBind, condition) {
                        widget.container.add({
                            xtype: 'tagfield',
                            flex: 1,
                            emptyText: 'Select a group or specify a custom value ...',
                            store: { data: [] },
                            filterPickList: true,
                            forceSelection: false,
                            queryMode: 'local',
                            selectOnFocus: false,
                            growMax: 60,
                            createNewOnEnter: true,
                            createNewOnBlur: true,
                            displayField: 'CN',
                            valueField: 'SAMAccountName',
                            listConfig: {
                                itemTpl: ['<div>{CN} <strong>[{SAMAccountName}]</strong></div>']
                            },
                            bind: {
                                value: valueBind
                            },
                            listeners: {
                                afterrender: function (field) {
                                    condition.getData(field).then(function(data) {
                                        field.getStore().loadData(data);
                                    },function(error) {
                                        console.log("Error occurred while loading directory connector groups:", error);
                                    }); 
                                }
                            }
                        });
                    };
                }
                break;

                case "directorydomainfield": {
                    currItem["getData"] = function (field) {  
                        var data = [{
                            value: '*', description: 'Any Domain'
                        }];
                        var handleDCDomainDataMerge = function(data, result) {
                            Ext.Array.each( result.list, function (record) {
                                data.push({value: record, description: record});
                            });
                            return data;
                        };
                    

                        if (field) {
                            return Rpc.asyncData('rpc.appManager.app', 'directory-connector')
                                .then(function (app) {
                                    if (Util.isDestroyed(field)) {
                                        return data;
                                    }
                                    if (app) {
                                        return Rpc.asyncData(app, 'getRuleConditionalDomainEntries')
                                            .then(function (result) {
                                                if (Util.isDestroyed(field)) {
                                                    return data;
                                                }
                                                return handleDCDomainDataMerge(data, result);
                                            }, function (ex) {
                                                Util.handleException(ex);
                                                return data;
                                            });
                                    }
                                }, function (ex) {
                                    Util.handleException(ex);
                                    return data;
                                });
                        } else {
                            try {
                                var appData = Rpc.directData('rpc.appManager.app', 'directory-connector');
                                if (appData) {
                                    var result = Rpc.directData(appData, 'getRuleConditionalDomainEntries');
                                    return { keyName: 'value', data: handleDCDomainDataMerge(data, result) };
                                }
                            } catch (ex) {
                                Util.handleException(ex);
                                return { keyName: 'value', data: data };
                            }
                        }

                        return data;
                    };

                    currItem["widgetCreator"] = function (widget, valueBind, condition){
                        widget.container.add({
                            xtype: 'tagfield',
                            flex: 1,
                            emptyText: 'Select a domain or specify a custom value ...',
                            store: { data: [] },
                            filterPickList: true,
                            forceSelection: false,
                            queryMode: 'local',
                            selectOnFocus: false,
                            growMax: 60,
                            createNewOnEnter: true,
                            createNewOnBlur: true,
                            displayField: 'description',
                            valueField: 'value',
                            listConfig: {
                                itemTpl: ['<div>{value} <strong>[{description}]</strong></div>']
                            },
                            bind: {
                                value: valueBind
                            },
                            listeners: {
                                afterrender: function (field) {
                                    condition.getData(field).then(function(data) {
                                        field.getStore().loadData(data);
                                    },function(error) {
                                        console.log("Error occurred while loading directory connector domains:", error);
                                    });  
                                }
                            }
                        });
                    };
                }
                break;

                default:
                    break;
            }
        },

        // If not specified, visible is treated as true.
        conditions: [{
            name:"DST_LOCAL",
            displayName: "Destined Local".t(),
            type: "boolean"
        },{
            name:"DST_ADDR",
            displayName: "Destination Address".t(),
            type: 'textfield',
            vtype:"ipMatcher",
            allowBlank: false,
        },{
            name:"DST_PORT",
            displayName: "Destination Port".t(),
            type: 'textfield',
            vtype:"portMatcher",
            allowBlank: false
        },{
            name:"DST_INTF",
            displayName: "Destination Interface".t(),
            type: 'checkboxgroup',
            values: Util.getInterfaceList(true, true),
        },{
            name:"SRC_MAC",
            displayName: "Client MAC Address".t(), 
            type: 'textfield',
            vtype: 'macAddress',
            allowBlank: false,
        },{
            name:'DST_MAC',
            displayName: 'Server MAC Address'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:"PROTOCOL",
            displayName: "Protocol".t(),
            type: 'checkboxgroup',
            values: Util.getProtocolList(false),
        },{
            name:"SRC_INTF",
            displayName: "Source Interface".t(),
            type: 'checkboxgroup',
            values: Util.getInterfaceList(true, true),
        },{
            name:"SRC_ADDR",
            displayName: "Source Address".t(),
            type: 'textfield',
            vtype:"ipMatcher",
            allowBlank: false,
        },{
            name:"SRC_PORT",
            displayName: "Source Port".t(),
            type: 'textfield',
            vtype:"portMatcher",
            visible: Rpc.directData('rpc.isExpertMode'),
            allowBlank: false,
        },{
            name:"CLIENT_TAGGED",
            displayName: 'Client Tagged'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:"SERVER_TAGGED",
            displayName: 'Server Tagged'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'TAGGED',
            displayName: 'Tagged'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'USERNAME',
            displayName: 'Username'.t(),
            type: 'userfield',
            importValidation: true,
        },{
            name:'HOST_HOSTNAME',
            displayName: 'Host Hostname'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'CLIENT_HOSTNAME',
            displayName: 'Client Hostname'.t(),
            type: 'textfield',
            visible: false
        },{
            name:'SERVER_HOSTNAME',
            displayName: 'Server Hostname'.t(),
            type: 'textfield',
            visible: false
        },{
            name:'CLIENT_MAC_VENDOR',
            displayName: 'Client MAC Vendor'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'SERVER_MAC_VENDOR',
            displayName: 'Server MAC Vendor'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'CLIENT_IN_PENALTY_BOX',
            displayName: 'Client in Penalty Box'.t(),
            type: 'boolean',
            visible: false
        },{
            name:'SERVER_IN_PENALTY_BOX',
            displayName: 'Server in Penalty Box'.t(),
            type: 'boolean',
            visible: false
        },{
            name:'HOST_HAS_NO_QUOTA',
            displayName: 'Host has no Quota'.t(),
            type: 'boolean',
            onlyTrue: true,
        },{
            name:'USER_HAS_NO_QUOTA',
            displayName: 'User has no Quota'.t(),
            type: 'boolean',
            onlyTrue: true,
        },{
            name:'CLIENT_HAS_NO_QUOTA',
            displayName: 'Client has no Quota'.t(),
            type: 'boolean',
            visible: Rpc.directData('rpc.isExpertMode')
        },{
            name:'SERVER_HAS_NO_QUOTA',
            displayName: 'Server has no Quota'.t(),
            type: 'boolean',
            visible: Rpc.directData('rpc.isExpertMode')
        },{
            name:'HOST_QUOTA_EXCEEDED',
            displayName: 'Host has exceeded Quota'.t(),
            type: 'boolean',
            onlyTrue: true,
        },{
            name:'USER_QUOTA_EXCEEDED',
            displayName: 'User has exceeded Quota'.t(),
            type: 'boolean',
            onlyTrue: true,
        },{
            name:'CLIENT_QUOTA_EXCEEDED',
            displayName: 'Client has exceeded Quota'.t(),
            type: 'boolean',
            visible: Rpc.directData('rpc.isExpertMode')
        },{
            name:'SERVER_QUOTA_EXCEEDED',
            displayName: 'Server has exceeded Quota'.t(),
            type: 'boolean',
            visible: Rpc.directData('rpc.isExpertMode')
        },{
            name:'HOST_QUOTA_ATTAINMENT',
            displayName: 'Host Quota Attainment'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'USER_QUOTA_ATTAINMENT',
            displayName: 'User Quota Attainment'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'CLIENT_QUOTA_ATTAINMENT',
            displayName: 'Client Quota Attainment'.t(),
            type: 'textfield',
            visible: Rpc.directData('rpc.isExpertMode')
        },{
            name:'SERVER_QUOTA_ATTAINMENT',
            displayName: 'Server Quota Attainment'.t(),
            type: 'textfield',
            visible: Rpc.directData('rpc.isExpertMode')
        },{
            name:'HOST_ENTITLED',
            displayName: 'Host Entitled'.t(), 
            type: 'boolean',
            onlyTrue: true,
        },{
            name:'HTTP_HOST',
            displayName: 'HTTP: Hostname'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_REFERER',
            displayName: 'HTTP: Referrer'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_URI', 
            displayName: 'HTTP: URI'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_URL',
            displayName: 'HTTP: URL'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_CONTENT_TYPE',
            displayName: 'HTTP: Content Type'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_CONTENT_LENGTH',
            displayName: 'HTTP: Content Length'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_REQUEST_METHOD',
            displayName: 'HTTP: Request Method'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_REQUEST_FILE_PATH',
            displayName: 'HTTP: Request File Path'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_REQUEST_FILE_NAME',
            displayName: 'HTTP: Request File Name'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_REQUEST_FILE_EXTENSION',
            displayName: 'HTTP: Request File Extension'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_RESPONSE_FILE_NAME',
            displayName: 'HTTP: Response File Name'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_RESPONSE_FILE_EXTENSION',
            displayName: 'HTTP: Response File Extension'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_USER_AGENT',
            displayName: 'HTTP: Client User Agent'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'HTTP_USER_AGENT_OS',
            displayName: 'HTTP: Client User OS'.t(), 
            type: 'textfield', 
            visible: false
        },{
            name:'APPLICATION_CONTROL_APPLICATION',
            displayName: 'Application Control: Application'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'APPLICATION_CONTROL_CATEGORY', 
            displayName: 'Application Control: Application Category'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'APPLICATION_CONTROL_PROTOCHAIN',
            displayName: 'Application Control: ProtoChain'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'APPLICATION_CONTROL_DETAIL',
            displayName: 'Application Control: Detail'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'APPLICATION_CONTROL_CONFIDENCE',
            displayName: 'Application Control: Confidence'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'APPLICATION_CONTROL_PRODUCTIVITY',
            displayName: 'Application Control: Productivity'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'APPLICATION_CONTROL_RISK',
            displayName: 'Application Control: Risk'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'PROTOCOL_CONTROL_SIGNATURE',
            displayName: 'Application Control Lite: Signature'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'PROTOCOL_CONTROL_CATEGORY',
            displayName: 'Application Control Lite: Category'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'PROTOCOL_CONTROL_DESCRIPTION',
            displayName: 'Application Control Lite: Description'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_CATEGORY',
            displayName: 'Web Filter: Category'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_CATEGORY_DESCRIPTION',
            displayName: 'Web Filter: Category Description'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_FLAGGED',
            displayName: 'Web Filter: Website is Flagged'.t(),
            type: 'boolean',
            onlyTrue: true,
        },{
            name:'WEB_FILTER_REQUEST_METHOD',
            displayName: 'Web Filter: Request Method'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_REQUEST_FILE_PATH',
            displayName: 'Web Filter: Request File Path'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_REQUEST_FILE_NAME',
            displayName: 'Web Filter: Request File Name'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_REQUEST_FILE_EXTENSION',
            displayName: 'Web Filter: Request File Extension'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_RESPONSE_CONTENT_TYPE',
            displayName: 'Web Filter: Content Type'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_RESPONSE_FILE_NAME',
            displayName: 'Web Filter: Response File Name'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'WEB_FILTER_RESPONSE_FILE_EXTENSION',
            displayName: 'Web Filter: Response File Extension'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'DIRECTORY_CONNECTOR_GROUP',
            displayName: 'Directory Connector: User in Group'.t(),
            type: 'directorygroupfield',
            importValidation: true,
        },{
            name:'DIRECTORY_CONNECTOR_DOMAIN',
            displayName: 'Directory Connector: User in Domain'.t(),
            type: 'directorydomainfield',
            importValidation: true,
        },{
            name:'CLIENT_COUNTRY',
            displayName: 'Client Country'.t(),
            type: 'countryfield',
            importValidation: true,
        },{
            name:'SERVER_COUNTRY',
            displayName: 'Server Country'.t(),
            type: 'countryfield',
            importValidation: true,
        },{
            name:'THREAT_PREVENTION_SRC_REPUTATION',
            displayName: 'Threat Prevention: Client address reputation'.t(),
            type: 'checkboxgroup',
            // Also, tips
            values: Ung.common.threatprevention.references.reputatationConditionValues()
        },{
            name:'THREAT_PREVENTION_DST_REPUTATION',
            displayName: 'Threat Prevention: Server address reputation'.t(),
            type: 'checkboxgroup',
            values: Ung.common.threatprevention.references.reputatationConditionValues()
        },{
            name:'THREAT_PREVENTION_SRC_CATEGORIES',
            displayName: 'Threat Prevention: Client address category'.t(),
            type: 'checkboxgroup',
            // Also, tips
            values: Ung.common.threatprevention.references.threatsConditionValues()
        },{
            name:'THREAT_PREVENTION_DST_CATEGORIES',
            displayName: 'Threat Prevention: Server address category'.t(),
            type: 'checkboxgroup',
            // Also, tips
            values: Ung.common.threatprevention.references.threatsConditionValues()
        },{
            name:'SSL_INSPECTOR_SNI_HOSTNAME',
            displayName: 'SSL Inspector: SNI Host Name'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'SSL_INSPECTOR_SUBJECT_DN',
            displayName: 'SSL Inspector: Certificate Subject'.t(),
            type: 'textfield',
            allowBlank: false,
        },{
            name:'SSL_INSPECTOR_ISSUER_DN',
            displayName: 'SSL Inspector: Certificate Issuer'.t(),
            type: 'textfield',
            allowBlank: false,
        }]
    }
});
Ext.define('Ung.cmp.ConditionsEditorController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.conditionseditorcontroller',

    control: {
        '#': {
            afterrender: 'onAfterRender',
            validateField: 'validate',
            removed: 'onRemoved'
        },
        'grid': {
            afterlayout: 'onAfterGridLayout',
        }
    },

    /**
     * [onConditionsRender description]
     * @param  {[type]} grid [description]
     * @return {[type]}                [description]
     */
    onAfterRender: function (component) {
        var me = this;
        var view = this.getView();

        this.masterGrid = component.up('grid');
        this.recordeditor = component.up('window');

        this.recordBind = component.up('window').getViewModel().bind({
            bindTo: '{record}',
        }, this.setMenuConditions);

        me.buildConditions(component, view.conditionsOrder, view.conditions);

        me.getView().down('[name=conditionLabel]').update(me.getView());
        me.getView().down('[name=actionLabel]').update(me.getView());
    },

    buildConditions: function(component){
        var me = this;
        var view = me.getView();

        var menuConditions = [];

        var index = 0;
        var subMenus = {};
        view.conditionsOrder.forEach(function(name){
            index++;
            var condition = view.conditions[name];
            var nameFields = condition.name.split('.');
            if( condition.visible) {
                if( nameFields.length > 1){
                    var masterField = nameFields[0];
                    if( !subMenus[masterField] ){
                        subMenus[masterField] = {
                            showSeparator: false,
                            plain: true,
                            items: [],
                            mouseLeaveDelay: 0,
                            listeners: {
                                click: 'addCondition'
                            }
                        };
                    }
                    subMenus[masterField].items.push({
                        text: nameFields[1],
                        conditionType: condition.name,
                        index: index,
                        allowMultiple: false,
                        tooltip: condition.description ? condition.description : condition.displayName
                    });
                }
            }
        });
        view.conditionsOrder.forEach(function(name){
            index++;
            var condition = view.conditions[name];
            var nameFields = condition.name.split('.');
            if( condition.visible) {
                var masterField = nameFields.length > 1 ? nameFields[0] : null;
                if(masterField && !subMenus[masterField]){
                    return;
                }
                var menuConfig = {
                    text: condition.displayName,
                    conditionType: condition.name,
                    index: index,
                    allowMultiple: false,
                    tooltip: condition.description ? condition.description : condition.displayName
                    // allowMultiple: conditions.allowMultiple != undefined ? conditions.allowMultiple : false
                };
                if(masterField && subMenus[masterField]){
                    menuConfig.text = masterField;
                    menuConfig.menu = subMenus[masterField];
                    delete subMenus[masterField];
                }
                menuConditions.push(menuConfig);
            }
        });

        component.down('#addConditionBtn').setMenu({
            showSeparator: false,
            plain: true,
            items: menuConditions,
            mouseLeaveDelay: 0,
            listeners: {
                click: 'addCondition'
            }
        });

    },

    /**
     * Copy data to record editor conditions record.
     * @param  {[type]} me        [description]
     * @param  {[type]} container [description]
     * @return {[type]}           [description]
     */
    onRemoved: function(me, container){
        me = me.down ? me : me.getView();

        var recordEditorView = this.recordeditor;
        var store = me.down('grid').getStore();

        if(this.recordeditor.cancel){
            store.rejectChanges();
        }else{
            var recordName = me.recordName.split('.')[1];
            if (store.getModifiedRecords().length > 0 || store.getRemovedRecords().length > 0 || store.getNewRecords().length > 0) {
                var data = Ext.Array.pluck(store.getRange(), 'data');
                data.forEach( function(record){
                    if(typeof(record.value) == 'object' && record.value.length){
                        record.value = record.value.join(',');
                    }
                });
                recordEditorView.record.set( recordName, {
                    javaClass: 'java.util.LinkedList',
                    list: data
                });
            }
        }
    },

    /**
     * After initial grid layout, resize value column.  Subsequently, process comparator and widget queues.
     *
     * We should be able to use "flex:1" for the value column, and it does work except if you use
     * a large checkbox group (e.g.,IPS categories which has nearly 100 records).  This causes the layout
     * to eventually break.  It always works fine on a new record add, but would always break when
     * you tried to edit that record.  
     * To get around this, set the column width to a fixed value based on the grid - width of all other columns.
     *
     * A widget queue is also needed thanks to large chekcboxgroups.  Just using the onWidgetAttach listener
     * would cause a race condition with large checkboxgroups not being fully rendered before the next widget
     * came along to render itself.  By throwing them into this queue, layout event is fired upon successful
     * rendering so we can just walk the queues, FIFO style until empty.
     * 
     * @param  component ConditionEditor component.
     */
    valueColumnResized: false,
    lastGridWidth: 0,
    comparatorWidgetQueue: [],
    valueWidgetQueue: [],
    onAfterGridLayout: function (grid) {
        var me = this;
        var gridWidth = grid.body.getWidth();
        var resized = false;
        if(this.lastGridWidth != gridWidth){
            this.lastGridWidth = gridWidth;
            var availableWidth = gridWidth - 2;
            me.resizeColumn = null;
            grid.getColumns().forEach( function(column){
                if(column.widgetType == 'value'){
                    me.resizeColumn = column;
                    return;
                }
                availableWidth -= column.getWidth();
            });
            me.resizeColumn.setWidth(availableWidth);
        }
        var addedComparatorWidget = this.addComparatorWidget();
        var addedValueWidget = null;
        if(!addedComparatorWidget){
            addedValueWidget = this.addValueWidget();
        }

        if(addedComparatorWidget || addedValueWidget){
            this.forceValidate();
        }
    },

    forceValidate: function(){
        this.validate();
        this.getView().up('form').getForm().checkValidity();
    },

    addValueWidget: function(){
        var me = this, 
            view = me.getView(),
            added = false;

        if(me.valueWidgetQueue.length){
            var widget = me.valueWidgetQueue.shift();
            widget.container.removeAll(true);
            widget.container.getBind().html.destroy();
            widget.container.setHtml('');

            var condition = view.conditions[widget.record.get(view.fields.type)];
            added = true;

            var valueBind = '{record.' + view.fields.value + '}';
            switch (condition.type) {
            case 'boolean':
                if(condition.values){
                    widget.container.add({
                        xtype: 'combo',
                        editable: false,
                        matchFieldWidth: false,
                        bind: {
                            value: valueBind
                        },
                        store: condition.values
                    });
                }else{
                    widget.container.add({
                        xtype: 'component',
                        padding: 3,
                        html: 'True'.t()
                    });
                }
                break;
            case 'textfield':
                widget.container.add({
                    xtype: 'textfield',
                    fieldLabel: condition.displayName,
                    hideLabel: true,
                    style: { margin: 0 },
                    bind: {
                        value: valueBind
                    },
                    vtype: condition.vtype,
                    validator: condition.validator,
                    allowBlank: false,
                    listeners:{
                        change: 'forceValidate'
                    }
                });
                break;
            case 'numberfield':
                widget.container.add({
                    xtype: 'numberfield',
                    fieldLabel: condition.displayName,
                    hideLabel: true,
                    style: { margin: 0 },
                    bind: {
                        value: valueBind
                    },
                    vtype: condition.vtype,
                    validator: condition.validator,
                    allowBlank: false,
                    listeners:{
                        change: 'forceValidate'
                    }
                });
                break;
            case 'sizefield':
                widget.container.add({
                    xtype: 'numberfield',
                    fieldLabel: condition.displayName,
                    hideLabel: true,
                    style: { margin: 0 },
                    bind: {
                        value: valueBind
                    },
                    vtype: condition.vtype,
                    validator: condition.validator,
                    allowBlank: false,
                    listeners:{
                        change: 'forceValidate'
                    }
                });
                break;
            case 'select':
                widget.container.add({
                    xtype: 'combo',
                    editable: false,
                    matchFieldWidth: false,
                    bind: {
                        value: valueBind
                    },
                    store: condition.values
                });
                break;
            case 'checkboxgroup':
                var ckItems = [];
                if(condition.store){
                    condition.store.each( function( record ){
                        ckItems.push({
                            inputValue: record.get(condition.storeValue),
                            boxLabel: record.get(condition.storeLabel),
                            autoEl: {
                                tag: 'div',
                                'data-qtip': condition.storeTip(record.get(condition.storeValue), null, record)
                            }
                        });
                    });
                }else{
                    for (var i = 0; i < condition.values.length; i += 1) {
                        ckItems.push({
                            // name: 'ck',
                            inputValue: condition.values[i][0],
                            boxLabel: condition.values[i][1]
                            // !!! autoEl?
                        });
                    }
                }
                widget.container.add({
                    xtype: 'checkboxgroup',
                    bind: {
                        value: valueBind
                    },
                    columns: 3,
                    vertical: true,
                    defaults: {
                        padding: '0 10'
                    },
                    items: ckItems,
                    listeners:{
                        change: 'forceValidate'
                    }
                });
                break;
            case 'countryfield':
                widget.container.add({
                    xtype: 'tagfield',
                    flex: 1,
                    emptyText: 'Select countries or specify a custom value ...',
                    store: { type: 'countries' },
                    filterPickList: true,
                    forceSelection: false,
                    queryMode: 'local',
                    selectOnFocus: false,
                    growMax: 60,
                    createNewOnEnter: true,
                    createNewOnBlur: true,
                    bind: {
                        value: valueBind
                    },
                    displayField: 'name',
                    valueField: 'code',
                    listConfig: {
                        itemTpl: ['<div>{name} <strong>[{code}]</strong></div>']
                    },
                });
                break;
            case 'userfield':
            case 'directorygroupfield':
            case 'directorydomainfield':
                condition.widgetCreator(widget, valueBind, condition);
                break;
            case 'timefield':
                widget.container.add({
                    xtype: 'container',
                    layout: { type: 'hbox', align: 'middle' },
                    hoursStore: (function () {
                        var arr = [];
                        for (var i = 0; i <= 23; i += 1) {
                            arr.push(i < 10 ? '0' + i : i.toString());
                        }
                        return arr;
                    })(),
                    minutesStore: (function () {
                        var arr = [];
                        for (var i = 0; i <= 59; i += 1) {
                            arr.push(i < 10 ? '0' + i : i.toString());
                        }
                        return arr;
                    })(),
                    defaults: {
                        xtype: 'combo', store: [], width: 40, editable: false, queryMode: 'local', listeners: {
                            change: function (combo, newValue) {
                                var view = combo.up('container'), period = '';
                                view.record.set('value', view.down('#hours1').getValue() + ':' + view.down('#minutes1').getValue() + '-' + view.down('#hours2').getValue() + ':' + view.down('#minutes2').getValue());
                            }
                        }
                    },
                    items: [
                        { itemId: 'hours1', },
                        { xtype: 'component', html: ' : ', width: 'auto', margin: '0 3' },
                        { itemId: 'minutes1' },
                        { xtype: 'component', html: 'to'.t(), width: 'auto', margin: '0 3' },
                        { itemId: 'hours2' },
                        { xtype: 'component', html: ' : ', width: 'auto', margin: '0 3' },
                        { itemId: 'minutes2' }
                    ],
                    record: widget.record,
                    listeners: {
                        afterrender: function (view) {
                            var valueField = view.up('conditionseditor').fields.value;
                            view.down('#hours1').setStore(view.hoursStore);
                            view.down('#minutes1').setStore(view.minutesStore);
                            view.down('#hours2').setStore(view.hoursStore);
                            view.down('#minutes2').setStore(view.minutesStore);
                            if (!view.record.get(valueField)) {
                                view.down('#hours1').setValue('12');
                                view.down('#minutes1').setValue('00');
                                view.down('#hours2').setValue('13');
                                view.down('#minutes2').setValue('30');
                            } else {
                                var startTime = view.record.get(valueField).split('-')[0];
                                var endTime = view.record.get(valueField).split('-')[1];
                                view.down('#hours1').setValue(startTime.split(':')[0]);
                                view.down('#minutes1').setValue(startTime.split(':')[1]);
                                view.down('#hours2').setValue(endTime.split(':')[0]);
                                view.down('#minutes2').setValue(endTime.split(':')[1]);
                            }
                        }
                    }
                });
                break;
                default:
                    Util.handleException('Unknown condition value type: ' + condition.type);
            }
        }
        return added;
    },

    addComparatorWidget: function(){
        var me = this, 
            view = me.getView(),
            added = false;

        if(me.comparatorWidgetQueue.length){
            var widget = me.comparatorWidgetQueue.shift();

            widget.container.removeAll(true);
            widget.container.getBind().html.destroy();
            widget.container.setHtml('');

            var condition = view.conditions[widget.record.get(view.fields.type)];
            added = true;

            var comparatorBind = '{record.' + me.getView().fields.comparator + '}';

            var comparatorType = condition.comparator != undefined ? condition.comparator : 'invert';

            var comparator = null;
            view.comparators.forEach( function(c){
                if(c.name == comparatorType){
                    comparator = c;
                }
            });

            if(comparator == null){
                Util.handleException('Unknown comparator value type: ' + comparatorType);
            }else{
                widget.container.add({
                    xtype: 'combo',
                    editable: false,
                    matchFieldWidth: false,
                    bind: {
                        value: comparatorBind
                    },
                    store: comparator.store,
                    listeners: {
                        change: function(combo, newValue, oldValue){
                            if( combo.uiCls == 'form-focus' && combo.rawValue === 'is NOT' ){
                                var record = combo.up().$widgetRecord;
                                if ( record.data['javaClass'] === 'com.untangle.uvm.network.FilterRuleCondition' &&
                                record.data['conditionType'] !== 'SRC_PORT' && 
                                record.data['conditionType'] !== 'DST_PORT' )
                                {
                                    Ext.Msg.alert('Warning'.t(), Ext.String.format('"is NOT" is not supported for multiple values. Ensure to have only one rule for "{0}" condition type with "is NOT" operator.', record.data['conditionType']).t());
                                }
                            }
                            combo.up('conditionseditor').getController().forceValidate();
                        }
                    }
                });
            }

        }
        return added;
    },

    /**
     * Updates the disabled/enabled status of the conditions in the menu
     */
    setMenuConditions: function () {
        var view = this.getView(),
            conditionsEditorView = view.fields ? view : view.down('conditionseditor'),
            conditionsGrid = this.getView().down('grid'),
            menu = conditionsGrid.down('#addConditionBtn').getMenu(),
            store = conditionsGrid.getStore();

        menu.items.each(function (item) {
            if(item.allowMultiple){
                return;
            }
            item.setDisabled(store.findRecord(conditionsEditorView.fields.type, item.conditionType, 0, false, true, true) ? true : false);
        });
    },

    /**
     * Returns the list of supported protocols for parent grid
     */
    getProtocolList: function() {
        var view = this.getView(),
            ruleGrid = view.up('grid');

        if(ruleGrid && ruleGrid.editorFieldProtocolTcpUdpOnly)
            return Util.getProtocolList(true);
        else
            return Util.getProtocolList(false);
    },

    /**
     * Adds a new condition for the edited rule
     */
    addCondition: function (menu, item) {
        var me = this,
            view = this.getView();

        if( item === undefined){
            return;
        }

        if( item.conditionType == "PROTOCOL" ) {
            view.conditions.PROTOCOL.values = this.getProtocolList();
        }

        var record = Ext.create(me.getView().model);

        record.set(view.fields.type, item.conditionType);
        record.set('javaClass', view.javaClassValue);

        // If default value not set in model, fill in empty values with first values from
        // associated comparator and value lists (if any).
        var conditionName = item.conditionType;
        Ext.ClassManager.get(me.getView().model).fields.forEach( function(field){
            if( ( record.get(field.name) == undefined || record.get(field.name) == "" ) && field.defaultValue == undefined){
                for(var conditionField in view.fields){
                    if(view.fields[conditionField] == field.name){
                        switch(conditionField){
                            case 'comparator':
                                var comparator = null;
                                view.comparators.forEach(function(c){
                                    if(c.name == view.conditions[conditionName].comparator){
                                        comparator = c;
                                    }
                                });
                                record.set(field.name, comparator.store[0][0]);
                                break;
                            case 'value':
                                if(view.conditions[conditionName].values){
                                    if(typeof(view.conditions[conditionName].values[0]) == 'object'){
                                        record.set(field.name, view.conditions[conditionName].values[0][0]);
                                    }else{
                                        record.set(field.name, view.conditions[conditionName].values[0]);
                                    }
                                }
                                break;
                        }
                    }
                }
            }
        });

        me.getView().down('grid').getStore().add(record);
        me.setMenuConditions();
    },

    /**
     * Removes a condition from the rule
     */
    removeCondition: function (view, rowIndex, colIndex, item, e, record) {
        var me = this;
        me.getView().down('grid').getStore().remove(record);
        me.setMenuConditions();
        me.forceValidate();
    },

    /**
     * Renders the condition name in the grid
     */
    conditionRenderer: function (value, column) {
        var view = this.getView();

        var displayName = view.conditions[value] ? view.conditions[value].displayName : value;
        var description = view.conditions[value] && view.conditions[value].description ? view.conditions[value].description : displayName;
        column.tdAttr = 'data-qtip="' + Ext.String.htmlEncode(description) + '"';
        return '<strong>' + displayName + ':</strong>';
    },

    /**
     * Adds specific condition editor based on it's defined type
     */
    onWidgetAttach: function (column, container, record) {
        var me = this;

        var widgetType = column.widgetType;

        var found = false;
        me[widgetType + 'WidgetQueue'].forEach(function(value){
            if(value.container == container){
                found = true;
            }
        });
        if(!found){
            me[widgetType + 'WidgetQueue'].push({
                column: column,
                container: container,
                record: record,
                grid: column.up('grid')
            });
        }
    },


    /**
     * Check the widget fields for validity.
     * @return {[type]} [description]
     */
    validate: function(){
        var grid = this.getView().down('grid');

        var fields = grid.query('tableview')[0].query('field');

        if(!this.getView().allowEmpty && !fields.length){
            return false;
        }

        var valid = true;
        Ext.Array.each(fields, function (field) {
            if (!field.isValid()) {
                valid = false;
            }
            // console.log(field);
            // do a switch here for types.
            // If checkboxes, make sure at least one is checked.
        });
        return valid;
    }
});
Ext.define('Ung.cmp.ConfigPanel', {
    extend: 'Ext.tab.Panel',
    alias: 'widget.configpanel',
    layout: 'fit',

    dockedItems: [{
        xtype: 'toolbar',
        ui: 'footer',
        dock: 'top',
        style: { background: '#D8D8D8' },
        items: [{
            text: 'Back to Config',
            iconCls: 'fa fa-arrow-circle-left',
            hrefTarget: '_self',
            href: '#config'
        }, {
            xtype: 'component',
            padding: '0 5',
            bind: { html: '<img src="/icons/config/{iconName}.svg" style="vertical-align: middle;" width="17" height="17"/> <strong>{title}</strong>' }
        }]
    }, {
        xtype: 'toolbar',
        dock: 'bottom',
        items: ['->', {
            text: '<strong>' + 'Save'.t() + '</strong>',
            bind:{
                disabled: '{panel.saveDisabled}',
                hidden: '{vueMigrated}'
            },
            iconCls: 'fa fa-floppy-o fa-lg',
            handler: 'saveSettings'
        }]
    }],

    listeners: {
        // generic listener for all tabs in Apps, redirection
        beforetabchange: function (tabPanel, newCard, oldCard) {
            Ung.app.redirectTo('#config/' + tabPanel.name + '/' + newCard.getItemId());
        },

        tabchange: function (tabPanel) {
            Ung.app.hashBackup = window.location.hash; // keep track of hash for changes detection
        },

        afterrender: function (configPanel) {
            if (configPanel.tabBar && configPanel.getViewModel().get('vueMigrated')) {
                configPanel.tabBar.hide();
            }
            // code used for detecting user manual data change
            Ung.app.hashBackup = window.location.hash; // keep track of hash for changes detection
            Ext.Array.each(configPanel.query('field'), function (field) {
                // setup the _initialValue of the field on focus
                field.on('focus', function () {
                    if (!field.hasOwnProperty('_initialValue')) {
                        field._initialValue = field.getValue();
                    }
                });
                field.on('blur', function () {
                    // on field blur check if new value is different than the initial one
                    // add an _isChanged prop which is true if field value is really changed by the user manually
                    if (field._initialValue !== field.getValue()) {
                        field._isChanged = true;
                    } else {
                        field._isChanged = false;
                    }
                });
            });
        },

        removed: function(){
            this.getViewModel().set('panel.saveDisabled', false);
        }
    }

});
Ext.define('Ung.cmp.CopyToClipboard', {
    extend: 'Ext.form.FieldContainer',
    alias: 'widget.copytoclipboard',

    cls: 'copytoclipboard', // css class used to be able to set styles on copy content (e.g. <pre> element)

    key: {},
    value: {
        key: 'value'
    },

    layout: {
        type: 'hbox'
    },
    dataType: 'text',
    below: 'false', //NGFW-13105: If the items to copy are embedded a level below the component with copytoclipboard type

    items: [{
        xtype: 'button',
        itemId: 'copyClipboard',
        baseCls: 'fa fa-copy',
        margin: '5 0 0 5',
        tooltip: 'Copy to Clipboard'.t(),
        handler: null
    }],

    constructor: function(config) {
        var me = this;

        // Attach our local handler to the copy button
        me.items.forEach(function(item){
            if(item.itemId == 'copyClipboard' &&
               item.handler == null){
                item.handler = me.copy;
            }
        });

        if(config.items){
            var buttonExists = false;

            //Determine if items to copy are embedded below
            //NGFW-13105: the main hostDisplayFields items for wireguard-vpn needs to be put in a fieldset embedded below the copytoclipboard
            //itemsToLoop will be the items that we check for the button and the items are will be copied
            //This could be the main items of copytoclipboard
            //If set to below, the itemsToLoop are in the first item of copytoclipboard.
            //The below setting allows the add modal for wireguard-vpn to render on Safari and allow other items using copytoclipboard to remain unchanged
            var itemsToLoop = config.items;
            if (config.below && config.below == 'true') itemsToLoop = config.items[0].items;

            //Determine if button already exists in configuration
            itemsToLoop.forEach(function(item){
                if(item.itemId == 'copyClipboard'){
                    buttonExists = true;
                }
            });

            //If button does not exist, add the button to the configuration
            if(buttonExists == false){
                me.items.forEach(function(item){
                    itemsToLoop.push(item);
                });
            }

            //NGFW-13105: to render on safari, some items using copytoclipboard needs to be embedeed below in a fieldset
            //This logic sets the fieldset properties to the same as the copytoclipboard object so the copy handler works
            //If items to copy are embedded below copytoclipboard component, set the properties appropriately
            if (config.below && config.below == 'true') {
                if (config.dataType) config.items[0].dataType = config.dataType;
                else config.items[0].dataType = me.dataType;

                if (config.layout) config.items[0].layout = config.layout;
                else config.items[0].layout = me.layout;

                if (config.value) config.items[0].value = config.value;
                else config.items[0].value = me.value;

                if (config.key) config.items[0].key = config.key;
                else config.items[0].key = me.key;
            }
        }

        me.callParent(arguments);
    },

    /**
     * Perform copy to clipboard
     * @param {*} button
     */
    copy: function(button){
        var me = this,
            copyComponent = button.up(),
            sourceElements = copyComponent.query("[xtype!=button]"),
            el = document.createElement('textarea'),
            elementValue = (copyComponent.dataType == 'javascript') ? {} : '';

        sourceElements.forEach( function(sourceEl){
            if(sourceEl.xtype != copyComponent.xtype){
                var value = sourceEl[copyComponent.value.key];
                if(value != undefined){
                    var key = "";
                    if(copyComponent.key.key != null){
                        key = sourceEl[copyComponent.key.key];
                    }
                    if(typeof(value) == "string"){
                        if(copyComponent.value.stripPrefix != null){
                            value = value.replace( copyComponent.value.stripPrefix, '' );
                        }
                        if(copyComponent.value.stripSuffix != null){
                            value = value.replace( copyComponent.value.stripSuffix, '' );
                        }
                    }
                    if(copyComponent.dataType == 'javascript'){
                        elementValue[key] = value;
                        /* Backwards compatibility for copying to appliances < 16.3 */
                        if (key == 'endpointHostname') {
                            elementValue['endpointAddress'] = value;
                        }
                    }else{
                        elementValue += (el.value.length ? "\n" : "") + (key ? key + "=" : '') + value;
                    }
                }
            }
        });

        el.value = (copyComponent.dataType == 'javascript') ? JSON.stringify(elementValue) : elementValue;

        el.setAttribute('readonly', '');
        el.style.position = 'absolute';
        el.style.left = '-9999px';
        document.body.appendChild(el);
        el.select();
        // this executes the actual copy
        document.execCommand('copy');
        // remove the textarea helper
        document.body.removeChild(el);

    }
});
/*
 * File: DateTimeField.js
 *
 * This file requires use of the Ext JS library, under independent license.
 * This is part of the UX for DateTimeField developed by Guilherme Portela
 */
Ext.define('Ung.cmp.DateTimeField', {
    extend: 'Ext.form.field.Date',
    alias: 'widget.datetimefield',

    //<locale>
    /**
     * @cfg {String} format
     * The default date format string which can be overriden for localization support. The format must be valid
     * according to {@link Ext.Date#parse}.
     */
    format: "m/d/Y H:i",
    //</locale>
    /**
     * @cfg {String} altFormats
     * Multiple date formats separated by "|" to try when parsing a user input value and it does not match the defined
     * format.
     */
    altFormats: "m/d/Y H:i:s|c",
    width: 270,

    collapseIf: function(e) {
        var me = this,
            picker = me.picker;

        if (picker.timePicker && !e.within(picker.timePicker.el, false, true)) {
            me.callParent([e]);
        }
    },

    createPicker: function() {
        var me = this,
            parentPicker = this.callParent(),
            parentConfig = Ext.clone(parentPicker.initialConfig),
            initialConfig = Ext.clone(me.initialConfig),
            excludes = ['renderTo', 'width', 'height', 'bind'];

        // Avoiding duplicate ids error
        parentPicker.destroy();

        for (var i=0; i < excludes.length; i++) {
            if (initialConfig.hasOwnProperty([excludes[i]])) {
                delete initialConfig[excludes[i]];
            }
        }

        return Ext.create('Ung.cmp.DateTimePicker', Ext.merge(initialConfig, parentConfig));
    },

    getErrors: function(value) {
        value = arguments.length > 0 ? value : this.formatDate(this.processRawValue(this.getRawValue()));

        var me = this,
            format = Ext.String.format,
            errors = me.superclass.superclass.getErrors.apply(this, arguments),
            disabledDays = me.disabledDays,
            disabledDatesRE = me.disabledDatesRE,
            minValue = me.minValue,
            maxValue = me.maxValue,
            len = disabledDays ? disabledDays.length : 0,
            i = 0,
            svalue,
            fvalue,
            day,
            time;

        if (value === null || value.length < 1) { // if it's blank and textfield didn't flag it then it's valid
             return errors;
        }

        svalue = value;
        value = me.parseDate(value);
        if (!value) {
            errors.push(format(me.invalidText, svalue, Ext.Date.unescapeFormat(me.format)));
            return errors;
        }

        time = value.getTime();
        if (minValue && time < minValue.getTime()) {
            errors.push(format(me.minText, me.formatDate(minValue)));
        }

        if (maxValue && time > maxValue.getTime()) {
            errors.push(format(me.maxText, me.formatDate(maxValue)));
        }

        if (disabledDays) {
            day = value.getDay();

            for(; i < len; i++) {
                if (day === disabledDays[i]) {
                    errors.push(me.disabledDaysText);
                    break;
                }
            }
        }

        fvalue = me.formatDate(value);
        if (disabledDatesRE && disabledDatesRE.test(fvalue)) {
            errors.push(format(me.disabledDatesText, fvalue));
        }

        return errors;
    },

    getRefItems: function() {
        var me = this,
            result = me.callParent();

        if (me.picker && me.picker.timePicker){
            result.push(me.picker.timePicker);
        }

        return result;
    },

    onExpand: function() {
        var me = this,
            timePicker;

        me.callParent();
        timePicker = me.picker && me.picker.timePicker;

        if (timePicker) {
            me.picker.alignTimePicker();
        }
    }
});

/*
 * File: DateTimePicker.js
 *
 * This file requires use of the Ext JS library, under independent license.
 * This is part of the UX for DateTimeField developed by Guilherme Portela
 */

Ext.define('Ung.cmp.DateTimePicker', {
    extend: 'Ext.picker.Date',
    alias: 'widget.datetimepicker',
    requires: [
        'Ext.picker.Date',
        'Ext.slider.Single',
        'Ext.form.field.Time',
        'Ext.form.Label'
    ],
    // <locale>
    /**
     * @cfg {String} todayText
     * The default text that will be displayed in the calendar to pick the curent date.
     */
    todayText: 'Current Date',
    // </locale>
    // <locale>
    /**
     * @cfg {String} hourText
     * The default text displayed above the hour slider
     */
    hourText: 'Hour',
    // </locale>
    // <locale>
    /**
     * @cfg {String} minuteText
     * The default text displayed above the minute slider
     */
    minuteText : 'Minutes',
    // </locale>

    initEvents: function() {
        var me = this,
            eDate = Ext.Date,
            day = eDate.DAY;

        Ext.apply(me.keyNavConfig,{
            up: function(e) {
                if (e.ctrlKey) {
                    if (e.shiftKey) {
                        me.minuteSlider.setValue(me.minuteSlider.getValue() + 1);
                    } else {
                        me.showNextYear();
                    }
                } else {
                    if (e.shiftKey) {
                        me.hourSlider.setValue(me.hourSlider.getValue() + 1);
                    } else {
                        me.update(eDate.add(me.activeDate, day, - 7));
                    }
                }
            },

            down: function(e) {
                if (e.ctrlKey) {
                    if (e.shiftKey) {
                        me.minuteSlider.setValue(me.minuteSlider.getValue() - 1);
                    } else {
                        me.showPrevYear();
                    }
                } else {
                    if (e.shiftKey) {
                        me.hourSlider.setValue(me.hourSlider.getValue() - 1);
                    } else {
                        me.update(eDate.add(me.activeDate, day, 7));
                    }
                }
            }
        });
        me.callParent();
    },

    initComponent: function() {
        var me = this,
            dtAux;

        if (typeof me.value === 'string') {
            me.value = Ext.Date.parse(me.value, me.format);
        } else if (!me.value) {
            me.value = new Date();
        }

        dtAux = me.value;

        dtAux.setSeconds(0);

        me.timeFormat = me.format.indexOf("h") !== -1 ? 'h' : 'H';
        me.hourSlider = new Ext.slider.Single({
            fieldLabel: me.hourText,
            labelAlign: 'top',
            labelSeparator: ' ',
            padding: '0 0 10 17',
            focusable : false,
            value: 0,
            minValue: 0,
            maxValue: 23,
            vertical: true,
            tipText: function(thumb){
                var value = thumb.value;

                if (me.timeFormat === 'H') {
                    return value || '0';
                } else {
                    return (value && value - 12 <= 0) ? value : Math.abs(value - 12);
                }
            },
            listeners: {
                change: me.changeTimeValue,
                scope: me
            }
        });

        me.minuteSlider = new Ext.slider.Single({
            fieldLabel: me.minuteText,
            labelAlign: 'top',
            labelSeparator: ' ',
            padding: '0 10 10 0',
            focusable : false,
            value: 0,
            increment: 1,
            minValue: 0,
            maxValue: 59,
            vertical: true,
            listeners: {
                change: me.changeTimeValue,
                scope: me
            }
        });

        me.timePicker = new Ext.panel.Panel({
            layout: {
                type: 'hbox',
                align: 'stretch'
            },
            border: false,
            defaults: {
                flex: 1
            },
            width: 130,
            floating: true,
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'top',
                ui: 'footer',
                items: [
                    '->', {
                        xtype: 'label',
                        text: me.timeFormat == 'h' ? '12:00 AM' : '00:00'
                    },
                    '->'
                ]
            }],
            items: [me.hourSlider, me.minuteSlider],
            onMouseDown: function(e) {
                e.preventDefault();
            }
        });

        me.callParent();
        me.ownerCt = me.up('[floating]');
        me.timePicker.ownerCt = me.ownerCt;
        me.registerWithOwnerCt();
        me.timePicker.registerWithOwnerCt();
        me.setValue(new Date(dtAux));
    },

    handleTabClick: function (e) {
        this.handleDateClick(e, this.activeCell.firstChild, true);
    },

    getSelectedDate: function (date) {
        var me = this,
            t = Ext.Date.clearTime(date,true).getTime(),
            cells = me.cells,
            cls = me.selectedCls,
            cellItems = cells.elements,
            cLen = cellItems.length,
            cell, c;

        cells.removeCls(cls);

        for (c = 0; c < cLen; c++) {
            cell = cellItems[c].firstChild;
            if (cell.dateValue === t) {
                return cell;
            }
        }
        return null;
    },

    changeTimeValue: function(slider, e, eOpts) {
        var me = this,
            label = me.timePicker.down('label'),
            minutePrefix = me.minuteSlider.getValue() < 10 ? '0' : '',
            hourDisplay = me.hourSlider.getValue(),
            pickerValue, hourPrefix, timeSufix, auxValue;

        if (me.timeFormat == 'h') {
            timeSufix = me.hourSlider.getValue() < 12 ? ' AM' : ' PM';
            hourDisplay = me.hourSlider.getValue() < 13 ? hourDisplay : hourDisplay - 12;
            hourDisplay = hourDisplay || '12';
        }

        hourPrefix = hourDisplay < 10 ? '0' : '';

        label.setText(hourPrefix + hourDisplay + ':' + minutePrefix + me.minuteSlider.getValue() + (timeSufix || ''));

        if (me.pickerField && (pickerValue = me.pickerField.getValue())) {
            auxValue = new Date(pickerValue[slider == me.hourSlider ? 'setHours' : 'setMinutes'](slider.getValue()));
            me.pickerField.setValue(auxValue);
            me.pickerField.fireEvent('select', me.pickerField, auxValue);
        }
    },

    afterShow: function(animateTarget, callback, scope) {
        var me = this,
            timePickerToolbarEl, backgroundColor;

        me.callParent([animateTarget, callback, scope]);
        me.timePicker.show();

        // this is a workaround for the classic theme, where the time
        // panel would have a transparent background with the classic theme.
        timePickerToolbarEl = me.timePicker.down('toolbar').getEl();
        backgroundColor = timePickerToolbarEl.getStyle('background-color');
        if (backgroundColor == 'transparent') {
            timePickerToolbarEl.setStyle('background-color', timePickerToolbarEl.getStyle('border-color'));
        }
    },

    afterSetPosition: function(x, y) {
        this.callParent([x, y]);
        this.alignTimePicker();
    },

    alignTimePicker: function() {
        var me = this,
            el = me.el,
            alignTo = me.getTimePickerSide(),
            xPos = alignTo == 'tl' ? -135 : 5;

        me.timePicker.setHeight(el.getHeight());
        me.timePicker.showBy(me, alignTo, [xPos, 0]);

    },

    onHide: function() {
        var me = this;
        me.timePicker.hide();
        me.callParent();
    },

    beforeDestroy: function() {
        var me = this;

        if (me.rendered) {
            Ext.destroy(
                me.timePicker,
                me.minuteSlider,
                me.hourSlider
            );
        }
        me.callParent();
    },

    getTimePickerSide: function() {
        var el = this.el,
            body = Ext.getBody(),
            bodyWidth = body.getViewSize().width;

        return (bodyWidth < (el.getX() + el.getWidth() + 140)) ? 'tl' : 'tr';
    },

    setValue: function(value) {
        value = value || new Date();

        value.setSeconds(0);
        this.value = new Date(value);
        return this.update(this.value);
    },

    selectToday: function() {
        var me = this,
            btn = me.todayBtn,
            handler = me.handler,
            auxDate = new Date();

        if (btn && !btn.disabled) {
            me.setValue(new Date(auxDate.setSeconds(0)));
            me.fireEvent('select', me, me.value);
            if (handler) {
                handler.call(me.scope || me, me, me.value);
            }
            me.onSelect();
        }
        return me;
    },

    handleDateClick: function(e, t, /*private*/ blockStopEvent) {
        var me = this,
            handler = me.handler,
            hourSet = me.timePicker.items.items[0].getValue(),
            minuteSet = me.timePicker.items.items[1].getValue(),
            auxDate = new Date(t.dateValue);

        if(blockStopEvent !== true) {
            e.stopEvent();
        }

        if (!me.disabled && t.dateValue && !Ext.fly(t.parentNode).hasCls(me.disabledCellCls)) {
            me.doCancelFocus = me.focusOnSelect === false;
            auxDate.setHours(hourSet, minuteSet, 0);
            me.setValue(new Date(auxDate));
            delete me.doCancelFocus;
            me.fireEvent('select', me, me.value);
            if (handler) {
                handler.call(me.scope || me, me, me.value);
            }
            me.onSelect();
        }
    },

    selectedUpdate: function(date) {
        var me = this,
            dateOnly = Ext.Date.clearTime(date, true);

        this.callParent([dateOnly]);
        me.updateSliders();

    },

    fullUpdate: function(date) {
        var me = this,
            dateOnly = Ext.Date.clearTime(date, true);

        this.callParent([dateOnly]);
        me.updateSliders();
    },

    updateSliders: function() {
        var me = this,
            currentDate = (me.pickerField && me.pickerField.getValue()) || new Date();
        if (me.timePicker.rendered) {
            me.hourSlider.setValue(currentDate.getHours());
            me.minuteSlider.setValue(currentDate.getMinutes());
        }
    }
});
Ext.define('Ung.cmp.GoogleDrive', {
    alias: 'widget.googledrive',

    isConfigured: function () {
        var googleDriveConfigured = false, googleManager;
        googleManager = Rpc.directData('rpc.UvmContext.googleManager');
        if( googleManager && googleManager.isGoogleDriveConnected() ) {
            googleDriveConfigured = true;
        }
        return googleDriveConfigured;
    },
    getRootDirectory: function () {
        var googleManager = Rpc.directData('rpc.UvmContext.googleManager');
            rootDirectory = googleManager.getAppSpecificGoogleDrivePath(null);
        return rootDirectory;
    },
    configure: function (policyId) {
        Ung.app.redirectTo('#config/administration/google');
    }
});
Ext.define('Ung.cmp.LicenseLoader', {
    alias: 'widget.licenseloader',

    // update interval in millisecond
    updateFrequency: 60000,
    //how many times to check (50 times x 1 minute = 50 minutes)
    count: 50,
    started: false,
    intervalId: null,
    check: function() {
        this.count = 50;
        if(!this.started) {
            this.intervalId = window.setInterval(function() {Ung.LicenseLoader.run();}, this.updateFrequency);
            this.started = true;
        }
        return true;
    },
    stop: function() {
        if (this.intervalId !== null) {
            window.clearInterval(this.intervalId);
        }
        this.started = false;
    },
    run: function () {
        this.count--;
        if(this.count>0) {
            Ung.Main.reloadLicenses();
        } else {
            this.stop();
        }
    }
});

Ung.LicenseLoader = new Ung.cmp.LicenseLoader();Ext.define('Ung.cmp.SizeField', {
    extend: 'Ext.form.field.Text',
    alias: 'widget.sizefield',

    // compound compoent with text and combo
    // getValue() to record
    // setValue() from record

//    regex: /^(\d+)\s*(|B|MB|KB|GB|TB|PB)$/,

    // getValue: function(){
    //     var value = this.callParent();
    //     console.log('getValue=' + value);
    //     return value;
    // },

    // getRawValue: function(){
    //     var value = this.callParent();
    //     console.log('getRawValue=' + value);

    //     // var matches = this.regex.exec( value);
    //     // if(matches && matches.length == 3){
    //     //     if(matches[2] != ''){
    //     //         Renderer.datasizeMap.forEach(function(size){
    //     //             if(size[1] == matches[2]){
    //     //                 value = parseInt(matches[1],10) * size[0];
    //     //             }
    //     //         });
    //     //     }
    //     // }
    //     // console.log(value);
    //     return value;
    // },

    // setRawValue: function(value){
    //     console.log('setRawValue=' + value);

    //     if(this.regex.test(value)){
    //         console.log('change: set raw value');
    //         value = Renderer.datasize(value);
    //     }

    //     var value = this.callParent([value]);

    // }

    // listeners: {
        // change: function( field, newValue, oldValue){
        //     if(this.regex.test(newValue)){
        //         console.log('change: set raw value');
        //         field.setRawValue(Renderer.datasize(newValue));
        //     }
        // }
    // }
});
Ext.define('Ung.cmp.TagPicker', {
    extend: 'Ext.form.field.Picker',
    // extend: 'Ext.form.field.Tag',
    // extend: 'Ext.form.field.ComboBox',
    alias: 'widget.tagpicker',

    baseCls: 'tagpicker',

    twoWayBindable: ['tags', 'value'],
    publishes: ['tags', 'value'],

    fields: ['name', 'expirationTime'],

    displayField: false,
    valueField: false,
    delimiter: ", ",

    editable: false,
    hideTrigger: true,

    tags: [],

    fieldSubTpl: [
        // listWrapper div is tabbable in Firefox, for some unfathomable reason
        '<div id="{cmpId}-listWrapper" data-ref="listWrapper"' + (Ext.isGecko ? ' tabindex="-1"' : ''),
            '<tpl foreach="ariaElAttributes"> {$}="{.}"</tpl>',
            ' class="' + Ext.baseCSSPrefix + 'tagfield {fieldCls} {typeCls} {typeCls}-{ui}"<tpl if="wrapperStyle"> style="{wrapperStyle}"</tpl>>',
            '<span id="{cmpId}-selectedText" data-ref="selectedText" aria-hidden="true" class="' + Ext.baseCSSPrefix + 'hidden-clip"></span>',
            '<ul id="{cmpId}-itemList" data-ref="itemList" role="presentation" class="' + Ext.baseCSSPrefix + 'tagfield-list{itemListCls}">',
                '<li id="{cmpId}-inputElCt" data-ref="inputElCt" role="presentation" class="' + Ext.baseCSSPrefix + 'tagfield-input">',
                    '<input id="{cmpId}-inputEl" data-ref="inputEl" type="{type}" ',
                    '<tpl if="name">name="{name}" </tpl>',
                    '<tpl if="value"> value="{[Ext.util.Format.htmlEncode(values.value)]}"</tpl>',
                    '<tpl if="size">size="{size}" </tpl>',
                    '<tpl if="tabIdx != null">tabindex="{tabIdx}" </tpl>',
                    '<tpl if="disabled"> disabled="disabled"</tpl>',
                    '<tpl foreach="inputElAriaAttributes"> {$}="{.}"</tpl>',
                    'class="' + Ext.baseCSSPrefix + 'tagfield-input-field {inputElCls} {emptyCls}" autocomplete="off">',
                '</li>',
            '</ul>',
            '<ul id="{cmpId}-ariaList" data-ref="ariaList" role="listbox"',
                '<tpl if="ariaSelectedListLabel"> aria-label="{ariaSelectedListLabel}"</tpl>',
                '<tpl if="multiSelect"> aria-multiselectable="true"</tpl>',
                ' class="' + Ext.baseCSSPrefix + 'tagfield-arialist">',
            '</ul>',
          '</div>',
        {
            disableFormats: true
        }
    ],

    childEls: [
        'listWrapper', 'itemList', 'inputEl', 'inputElCt', 'selectedText', 'ariaList'
    ],

    initComponent: function() {
        this.callParent(arguments);
    },

    // initializing events to apply on the store
    initEvents: function() {
        this.callParent(arguments);
        var v = this;
        var grid = v.up('grid') ? v.up('grid') : v.up('panel').down('grid');
        var store = grid.getStore();
        if (store) {
            // adding filterchange event
            store.on('filterchange', this.onFilterChange, this);
        }
    },

    // Handler for the store's filterchange event
    onFilterChange: function(store) {
        // Update tags when rows are filtered
        this.setValue(this.getTags());
    },

    createPicker: function() {
        var me = this;
        me.grid = Ext.create('Ext.grid.Panel', {
            renderTo: Ext.getBody(),
            width: this.bodyEl.getWidth(),
            scrollable: true,
            floating: true,
            minHeight: 150,
            minWidth: 520,
            disableSelection: true,
            enableColumnHide: false,
            emptyText: '<p style="text-align: center; margin: 0; line-height: 2;"><i class="fa fa-info-circle fa-lg"></i> No Tags!</p>',
            viewConfig: {
                stripeRows: false,
                listeners: {
                    // to avoid some focusing issues
                    cellclick: function (view, cell, cellIndex, record) {
                        if (cellIndex > 0) {
                            return false;
                        }
                    }
                }
            },
            plugins: [{
                ptype: 'cellediting',
                clicksToEdit: 1
            }],
            store: {
                data: me.getTags(),
                fields: ['name', 'expirationTime']
                // sorters: ['expirationTime']
            },
            columns: [{
                header: '<i class="fa fa-tag"></i> ' + 'Name'.t(),
                menuDisabled: true,
                dataIndex: 'name',
                flex: 1,
                editor: {
                    xtype: 'textfield',
                    allowBlank: false
                }
            }, {
                xtype: 'widgetcolumn',
                width: 380,
                menuDisabled: true,
                header: '<i class="fa fa-clock-o"></i> ' + 'Expiration Time'.t(),
                widget: {
                    xtype: 'tagtime',
                    bind: {
                        value: '{record.expirationTime}'
                    }
                }
            }, {
                xtype: 'actioncolumn',
                header: '<i class="fa fa-trash-o"></i>',
                width: 30,
                resizable: false,
                sortable: false,
                menuDisabled: true,
                align: 'center',
                iconCls: 'fa fa-times',
                handler: me.removeTag,
                scope: me
            }],
            bbar: [{
                xtype: 'button',
                itemId: 'addbtn',
                text: 'Add'.t(),
                iconCls: 'fa fa-plus-circle',
                handler: me.addTag,
                scope: me
            }, '->', {
                xtype: 'button',
                text: 'Done'.t(),
                iconCls: 'fa fa-check',
                handler: me.finish,
                scope: me
            }],
        });

        // focus on tag name editing when adding new
        me.grid.getStore().on('add', function (store, records, index) {
            me.grid.getPlugins()[0].startEditByPosition({ row: index, column: 0 });
        });

        return me.grid;
    },

    addTag: function () {
        var me = this;
        me.grid.getStore().add({
            expirationTime: 0,
            expired: false,
            javaClass: 'com.untangle.uvm.Tag',
            name: '',
            valid: true
        });
    },

    removeTag: function (view, rowIndex, colIndex, item, e, record) {
        view.focus(); // important to move the focus on the grid so the picker does not collapse
        record.drop();
    },

    finish: function () {
        this.collapse();
    },

    listeners: {
        collapse: function () {
            this.publishValue();
            this.grid.getStore().commitChanges();
        }
    },

    getTags: function () {
        return this.tags;
    },
    setTags: function (tags) {
        var _tags = [];
        if (tags && Ext.isArray(tags.list)) {
            _tags = tags.list;
        }
        if (this.grid) {
            this.grid.getStore().loadData(_tags);
        }
        this.tags = _tags;
        this.setValue(_tags);
    },

    setValue: function (tags) {
        if(!Array.isArray(tags)){
            return;
        }
        var me = this, value = [];
        Ext.Array.each(tags, function(tag) {
            // value.push(tag.name);
            value.push('<li class="tag-item"><i class="fa fa-tag"></i> ' + tag.name + '</li>');
        });
        if( me.itemList != undefined){
            me.itemList.select('.tag-item').destroy();
            me.itemList.select('.no-tags').destroy();
        }
        if( me.inputElCt != undefined){
            me.inputElCt.insertHtml('beforeBegin', value.join(''));
        }

        if (tags.length === 0) {
            if( me.inputElCt != undefined){
                me.inputElCt.insertHtml('beforeBegin', '<li class="no-tags"><em>' + '</em></li>');
            }
        }
    },

    publishValue: function () {
        var me = this;
        if (me.rendered) {
            me.publishState('tags', {
                javaClass: 'java.util.LinkedList',
                list: Ext.Array.pluck(me.grid.getStore().getRange(), 'data')
            });
        }
    }
});
Ext.define('Ung.cmp.TagTime', {
    extend: 'Ext.form.FieldContainer',
    alias: 'widget.tagtime',

    layout: 'column',
    twoWayBindable: ['value'],

    focusable: false,

    items: [{
        xtype: 'combo',
        margin: '0 0 0 3',
        width: 120,
        store: [
            [-1, 'End of Hour'.t()],
            [-2, 'End of Day'.t()],
            [-3, 'End of Week'.t()],
            [-4, 'End of Month'.t()],
            [0, 'Never'.t()],
            ['', 'Other'.t()] // just a random value to deal with other not special values
        ],
        editable: false,
        focusable: false,
        queryMode: 'local'
    }, {
        xtype: 'datefield',
        margin: '0 0 0 3',
        minValue: new Date(),
        value: new Date(),
        width: 130,
        format: 'date_fmt'.t(),
        editable: false,
        hidden: true
    }, {
        xtype: 'timefield',
        margin: '0 0 0 3',
        value: '11:50 pm',
        width: 110,
        format: 'h:i a',
        increment: 10,
        editable: true,
        hidden: true
    }],

    initComponent: function () {
        var me = this;
        me.callParent();

        me.items.items[0].on({
            scope: me,
            change: me.publishValue
        });
        me.items.items[1].on({
            scope: me,
            change: me.publishValue
        });
        me.items.items[2].on({
            scope: me,
            change: me.publishValue
        });
    },

    publishValue: function () {
        var me = this;
        if (me.rendered) {
            var combo = me.down('combo'), df = me.down('datefield'), tf = me.down('timefield');
            if (combo.getValue() <= 0 && combo.getValue() !== '') {
                me.publishState('value', combo.getValue());
            } else {
                var date = null;
                df.setHidden(false);
                tf.setHidden(false);
                if (df.getValue()) {
                    date = df.getValue();
                    if (tf.getValue()) {
                        date.setHours(tf.getValue().getHours(), tf.getValue().getMinutes(), 0, 0);
                    }
                    me.publishState('value', date.getTime());
                }
            }
        }
    },

    setValue: function (value) {
        var me = this, date, combo = me.items.items[0], df = me.items.items[1], tf = me.items.items[2];

        if (value > 0 || value === '') {
            combo.setValue('');
            df.setHidden(false);
            tf.setHidden(false);

            if (value > 0) {
                date = new Date(value);
            } else {
                date = new Date();
                date.setHours(23, 59, 0, 0); // set custom end of day
            }
            if (date) {
                df.setValue(date);
                tf.setValue(date);
            }
        } else {
            df.setHidden(true);
            combo.setValue(value);
            tf.setHidden(true);
        }
    }
});
Ext.define('Ung.cmp.UnitsField', {
    extend: 'Ext.form.FieldContainer',
    alias: 'widget.unitsfield',

    layout: 'column',
    twoWayBindable: ['value'],

    // publishes: 'value',

    initComponent: function () {
        var me = this;

        me.items = [{
            xtype: 'numberfield',
            width: 100,
            minValue: this.minValue,
            maxValue: this.maxValue
        }, {
            xtype: 'combo',
            margin: '0 5',
            width: 100,
            store: this.units,
            editable: false,
            value: 1
        }];
        me.callParent();

        me.items.items[0].on({
            scope: me,
            change: me.publishValue
        });
        me.items.items[1].on({
            scope: me,
            change: me.publishValue
        });
    },

    publishValue: function () {
        var me = this, nrfield = me.items.items[0], combo = me.items.items[1];
        if (me.rendered) {
            me.publishState('value', nrfield.value * combo.value);
        }
    },

    setValue: function (value) {
        var me = this, nrfield = me.items.items[0], combo = me.items.items[1], comboVal = 1;
        for (var i = 0; i < me.units.length; i += 1) {
            if (me.units[i+1]) {
                if (me.units[i][0] <= value && value < me.units[i+1][0]) {
                    comboVal = me.units[i][0];
                }
            }
        }
        if (value > me.units[me.units.length-1][0]) {
            comboVal = me.units[me.units.length-1][0];
        }
        combo.setValue(comboVal);
        nrfield.setValue(Math.round(value/combo.getValue()));
    }
});
Ext.define('Ung.widget.CpuLoad', {
    extend: 'Ext.container.Container',
    alias: 'widget.cpuloadwidget',
    controller: 'cpuload',
    viewModel: true,

    border: false,
    baseCls: 'widget',
    cls: 'small',

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    items: [{
        xtype: 'component',
        height: 40,
        cls: 'header',
        html: '<h1>' + 'CPU Load'.t() + '</h1>'
    }, {
        xtype: 'container',
        /*
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        */
        items: [{
            xtype: 'component',
            height: 120,
            reference: 'cpulinechart'
        }, {
            xtype: 'component',
            reference: 'cpugaugechart',
            height: 140
        }, {
            xtype: 'component',
            cls: 'cpu-gauge',
            bind: {
                html: '{stats.oneMinuteLoadAvg}<br/><span>{loadLabel}</span>'
            }
        }]
    }]
});
Ext.define('Ung.widget.CpuLoadController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.cpuload',

    control: {
        '#': {
            afterrender: 'onAfterRender',
            resize: 'onResize'
        }
    },

    listen: {
        store: {
            '#stats': {
                datachanged: 'addPoint'
            }
        }
    },

    onAfterRender: function (view) {
        setTimeout(function () {
            view.removeCls('adding');
        }, 100);

        this.lineChart = new Highcharts.Chart({
            chart: {
                type: 'areaspline',
                renderTo: view.lookup('cpulinechart').getEl().dom,
                marginBottom: 15,
                marginTop: 20,
                //padding: [0, 0, 0, 0],
                backgroundColor: 'transparent',
                animation: true,
                style: {
                    fontFamily: 'Source Sans Pro',
                    fontSize: '12px'
                }
            },
            title: null,
            credits: {
                enabled: false
            },
            exporting: {
                enabled: false
            },
            xAxis: [{
                type: 'datetime',
                crosshair: {
                    width: 1,
                    dashStyle: 'ShortDot',
                    color: 'rgba(100, 100, 100, 0.3)'
                },
                lineColor: '#C0D0E0',
                lineWidth: 1,
                tickLength: 3,
                gridLineWidth: 1,
                gridLineDashStyle: 'dash',
                gridLineColor: '#EEE',
                labels: {
                    style: {
                        fontFamily: 'Source Sans Pro',
                        color: '#999',
                        fontSize: '11px',
                        fontWeight: 600
                    },
                    y: 12
                },
                maxPadding: 0,
                minPadding: 0
            }],
            yAxis: {
                min: 0,
                minRange: 2,
                lineColor: '#C0D0E0',
                lineWidth: 1,
                gridLineWidth: 1,
                gridLineDashStyle: 'dash',
                gridLineColor: '#EEE',
                tickAmount: 4,
                tickLength: 5,
                tickWidth: 1,
                tickPosition: 'inside',
                opposite: false,
                labels: {
                    align: 'left',
                    useHTML: true,
                    padding: 0,
                    style: {
                        fontFamily: 'Source Sans Pro',
                        color: '#999',
                        fontSize: '11px',
                        fontWeight: 600,
                        background: 'rgba(255, 255, 255, 0.6)',
                        padding: '0 1px',
                        borderRadius: '2px',
                        //textShadow: '1px 1px 1px #000'
                        lineHeight: '11px'
                    },
                    x: 1,
                    y: -2
                },
                title: null
            },
            legend: {
                enabled: false
            },
            tooltip: {
                shared: true,
                animation: true,
                followPointer: true,
                backgroundColor: 'rgba(255, 255, 255, 0.7)',
                borderWidth: 1,
                borderColor: 'rgba(0, 0, 0, 0.1)',
                style: {
                    textAlign: 'right',
                    fontFamily: 'Source Sans Pro',
                    padding: '5px',
                    fontSize: '10px',
                    marginBottom: '40px'
                },
                //useHTML: true,
                hideDelay: 0,
                shadow: false,
                headerFormat: '<span style="font-size: 11px; line-height: 1.5; font-weight: bold;">{point.key}</span><br/>',
                pointFormatter: function () {
                    var str = '<span>' + this.series.name + '</span>';
                    str += ': <span style="color: ' + this.color + '; font-weight: bold;">' + this.y + '</span>';
                    return str + '<br/>';
                }
            },
            plotOptions: {
                areaspline: {
                    fillOpacity: 0.15,
                    lineWidth: 2
                },
                series: {
                    marker: {
                        enabled: true,
                        radius: 0,
                        states: {
                            hover: {
                                enabled: true,
                                lineWidthPlus: 2,
                                radius: 4,
                                radiusPlus: 2
                            }
                        }
                    },
                    states: {
                        hover: {
                            enabled: true,
                            lineWidthPlus: 0,
                            halo: {
                                size: 2
                            }
                        }
                    }
                }
            },
            series: [{
                name: 'load',
                data: (function () {
                    var data = [], time = Date.now(), i;
                    time = Math.round(time/1000) * 1000;
                    for (i = -6; i <= 0; i += 1) {
                        data.push({
                            x: time + i * 10000,
                            y: 0
                        });
                    }
                    return data;
                }())
            }]
        });

        this.gaugeChart = new Highcharts.Chart({
            chart: {
                type: 'gauge',
                renderTo: view.lookupReference('cpugaugechart').getEl().dom,
                height: 140,
                margin: [-20, 0, 0, 0],
                backgroundColor: 'transparent',
                style: {
                    margin: '0 auto'
                }
            },
            credits: {
                enabled: false
            },
            title: null,
            exporting: {
                enabled: false
            },
            pane: [{
                startAngle: -45,
                endAngle: 45,
                background: null,
                center: ['50%', '135%'],
                size: 280
            }],

            tooltip: {
                enabled: false
            },

            yAxis: [{
                min: 0,
                max: 50,
                minorTickPosition: 'outside',
                tickPosition: 'outside',
                tickColor: '#555',
                minorTickColor: '#999',
                labels: {
                    rotation: 'auto',
                    distance: 20,
                    step: 1
                },
                plotBands: [{
                    from: 0,
                    to: 3,
                    color: 'rgba(112, 173, 112, 1)',
                    innerRadius: '100%',
                    outerRadius: '105%'
                }, {
                    from: 3,
                    to: 6,
                    color: 'rgba(255, 255, 0, 1)',
                    innerRadius: '100%',
                    outerRadius: '105%'
                }, {
                    from: 6,
                    to: 7,
                    color: 'rgba(255, 0, 0, 1)',
                    innerRadius: '100%',
                    outerRadius: '105%'
                }],
                title: null
            }],

            plotOptions: {
                gauge: {
                    dataLabels: {
                        enabled: false
                    },
                    dial: {
                        radius: '99%',
                        backgroundColor: '#999'
                    }
                }
            },
            series: [{
                data: [0]
            }]
        });
        this.addPoint();
    },

    onResize: function () {
        this.lineChart.reflow();
        this.gaugeChart.reflow();
    },

    addPoint: function () {
        if (!this.gaugeChart || !this.lineChart) {
            return;
        }
        var store = Ext.getStore('stats');
        var vm = this.getViewModel(),
            stats = store.first().getData(),
            medLimit = stats.numCpus + 1,
            highLimit = stats.numCpus + 4;

        this.lineChart.yAxis[0].update({
            minRange: stats.numCpus
        });

        this.gaugeChart.yAxis[0].update({
            max: highLimit + 1,
            plotBands: [{
                from: 0,
                to: medLimit,
                color: 'rgba(112, 173, 112, 1)',
                innerRadius: '100%',
                outerRadius: '105%'
            }, {
                from: medLimit,
                to: highLimit,
                color: 'rgba(255, 255, 0, 1)',
                innerRadius: '100%',
                outerRadius: '105%'
            }, {
                from: highLimit,
                to: highLimit + 1,
                color: 'rgba(255, 0, 0, 1)',
                innerRadius: '100%',
                outerRadius: '105%'
            }]
        });

        this.lineChart.series[0].addPoint({
            x: Date.now(),
            y: store.first().getData().oneMinuteLoadAvg
        }, true, true);

        this.gaugeChart.series[0].points[0].update(stats.oneMinuteLoadAvg <= highLimit + 1 ? stats.oneMinuteLoadAvg : highLimit + 1, true);

        if (stats.oneMinuteLoadAvg < medLimit) {
            vm.set('loadLabel', 'low'.t());
        }
        if (stats.oneMinuteLoadAvg > medLimit) {
            vm.set('loadLabel', 'medium'.t());
        }
        if (stats.oneMinuteLoadAvg > highLimit) {
            vm.set('loadLabel', 'high'.t());
        }

    }
});
Ext.define('Ung.widget.Information', {
    extend: 'Ext.container.Container',
    alias: 'widget.informationwidget',

    controller: 'widget',

    border: false,
    baseCls: 'widget small info-widget',

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    items: [{
        xtype: 'component',
        cls: 'header',
        html: '<h1>' + 'Information'.t() + '</h1>'
    }, {
        xtype: 'component',
        cls: 'info-host',
        padding: 5,
        bind: {
            html: '<p class="hostname">{stats.hostname}</p><p class="version">' + 'version'.t() + ': {stats.version}</p>'
        }
    }, {
        xtype: 'component',
        margin: '10 0',
        bind : {
            html: '<table>' +
                    '<tr><td>' + 'uptime'.t() + ':</td><td>{stats.uptimeFormatted}</td></tr>' +
                    '<tr><td>' + 'Server'.t() + ':</td><td>{stats.appliance}</td></tr>' +
                    '<tr><td>' + 'CPU Count'.t() + ':</td><td>{stats.numCpus}</td></tr>' +
                    '<tr><td>' + 'CPU Type'.t() + ':</td><td>{stats.cpuModel}</td></tr>' +
                    '<tr><td>' + 'Architecture'.t() + ':</td><td>{stats.architecture}</td></tr>' +
                    '<tr><td>' + 'Memory'.t() + ':</td><td>{stats.totalMemory}</td></tr>' +
                    '<tr><td>' + 'Disk'.t() + ':</td><td>{stats.totalDisk}</td></tr>' +
                  '</table>'
        }
    }]
});
Ext.define('Ung.widget.InterfaceItem', {
    extend: 'Ext.Component',
    alias: 'widget.interfaceitem',

    bind: {
        html: '<p class="name" style="display: {iface.isWan ? \'block\' : \'none\'};">{iface.name}<sup style="display: {(iface.vrrpEnabled && iface.vrrpMaster) ? \'inline-block\' : \'none\'}">VRRP</sup></p>' +
            '<div class="speeds">' +
            '<div class="speed_up"><i class="fa fa-caret-down fa-lg"></i> <span>{inbound}</span></div>' +
            '<div class="speed_down"><i class="fa fa-caret-up fa-lg"></i> <span>{outbound}</span></div>' +
            '</div>' +
            '<p class="name" style="display: {!iface.isWan ? \'block\' : \'none\'};">{iface.name}<sup style="display: {(iface.vrrpEnabled && iface.vrrpMaster) ? \'inline-block\' : \'none\'}">VRRP</sup></p>' +
            // '<p class="name">{iface.vrrpEnabled}</p>' +
            '<span style="display: {!iface.isWan ? \'block\' : \'none\'}; margin-top: 5px; font-size: 11px;"><img src="' + '/skins/default/images/admin/icons/interface-devices.png" height="16"><br/>{devicesCount}</span>' +
            '<i class="fa fa-caret-down fa-lg pointer"></i>'
    },

    viewModel: {
        formulas: {
            outbound: function (get) {
                var field = get('iface.isWan') ? 'tx' : 'rx';
                var stats = get('stats').getData(),
                    propStr = 'interface_' + get('iface.interfaceId') + '_' + field + 'Bps';
                if (stats.hasOwnProperty(propStr)) {
                    return Util.bytesRenderer(stats[propStr],true);
                } else {
                    return '-';
                }
            },
            inbound: function (get) {
                var field = get('iface.isWan') ? 'rx' : 'tx';
                var stats = get('stats').getData(),
                    propStr = 'interface_' + get('iface.interfaceId') + '_' + field + 'Bps';
                if (stats.hasOwnProperty(propStr)) {
                    return Util.bytesRenderer(stats[propStr],true);
                } else {
                    return '-';
                }
            }
        }
    }
});
Ext.define('Ung.widget.MapDistribution', {
    extend: 'Ext.container.Container',
    alias: 'widget.mapdistributionwidget',

    controller: 'widget',

    border: false,
    baseCls: 'widget',
    visible: false,
    layout: 'fit',

    refreshIntervalSec: 10,

    items: [{
        xtype: 'component',
        cls: 'header',
        itemId: 'header',
        style: { height: '40px' },
        html: '<h1>' + 'Map Distribution'.t() + '</h1>' +
            '<div class="actions"><a class="action-btn"><i class="fa fa-rotate-left fa-lg" data-action="refresh"></i></a></div>'
    }, {
        xtype: 'component',
        height: 260,
        reference: 'mapCmp'
    }],

    // Function to convert bytes to the appropriate unit
    bytesToDynamicSize : function(bytes) {
        if (bytes < 1000) {
            return 10;
        } else if (bytes < 1000 * 1000) {
            return 30;
        } else if (bytes < 1000 * 1000 * 1000) {
            return 50;
        } else if (bytes < 1000 * 1000 * 1000 * 1000) {
            return 70;
        } else {
            return 90;
        }
    },

    fetchData: function (cb) {
        var me = this;
        if (me.chart) {
            me.chart.showLoading('<i class="fa fa-spinner fa-spin fa-2x fa-fw"></i>');
            Rpc.asyncData('rpc.UvmContext.geographyManager.getGeoSessionStats')
            .then( function(result){
                if(Util.isDestroyed(me.chart)){
                    return;
                }
                var data = [], i;
                me.chart.hideLoading();
                cb();
                for (i = 0; i < result.length; i += 1) {
                    var bubbleSize = 0, numberPart = 0, unitPart = "", convertedValue="";
                    if (result[i].bps){
                        convertedValue = Util.bytesRenderer(result[i].bps, true);
                        numberPart = parseFloat(convertedValue);
                        unitPart = convertedValue.replace(/[\d\s.]+/g, '');
                        bubbleSize = result[i].bps;
                    }
                    data.push({
                        country: result[i].country,
                        z: bubbleSize == 0 ? 0 : me.bytesToDynamicSize(bubbleSize),
                        numberPart: numberPart,
                        unitPart: unitPart,
                        sessionCount: result[i].sessionCount
                    });
                }
                me.chart.series[1].setData(data, true, false);
            },function(ex){
                Util.handleException(ex);
            });
        } else {
            cb();
        }
    },

    listeners: {
        afterrender: function (view) {
            if (!Highcharts.map['custom/world']) {
                Ext.Loader.loadScript({
                    url: '/highcharts-6.0.2/world.js',
                    onLoad: function () {
                        if(Util.isDestroyed(view)){
                            return;
                        }
                        view.renderMap(view);
                    }
                });
            } else {
                view.renderMap(view);
            }
        },
        resize: function (view) {
            if (view.chart) {
                view.chart.reflow();
            }
        }
    },

    renderMap: function (me) {
        me.chart = new Highcharts.Map({
            chart : {
                type: 'map',
                renderTo: me.lookup('mapCmp').getEl().dom,
                margin: [5, 5, 5, 5],
                spacing: [5, 5, 5, 5],
                map: 'custom/world'
            },
            title: null,
            legend: {
                enabled: false
            },
            credits: {
                enabled: false
            },
            exporting: {
                enabled: false
            },
            mapNavigation: {
                enabled: true,
                enableMouseWheelZoom: false,
                enableTouchZoom: false,
                buttonOptions: {
                    verticalAlign: 'bottom',
                    x: 5
                }
            },
            plotOptions: {
                series: {
                    allowPointSelect: true,
                    point: {
                        events: {
                            click: function () {
                                if (this.country) {
                                    Ung.app.redirectTo('#sessions/?serverCountry=' + this.country);
                                }
                            }
                        }
                    }
                }
            },
            series : [{
                name: 'Countries',
                color: '#E0E0E0',
                enableMouseTracking: false
            }, {
                type: 'mapbubble',
                joinBy: ['iso-a2', 'country'],
                minSize: 10,
                maxSize: 50,
                zMax: 500
            }],
            tooltip: {
                headerFormat: '',
                pointFormatter: function () {
                    var str = '<strong>' + this.country + '</strong><br/><strong>' + this.sessionCount + '</strong> ' + 'sessions'.t() + '<br/>';
                    str += '<strong>' + this.numberPart + '</strong> ' + this.unitPart ;
                    return str;
                },
                hideDelay: 0
            }
        });
    }
});
Ext.define('Ung.widget.NetworkInformation', {
    extend: 'Ext.container.Container',
    alias: 'widget.networkinformationwidget',

    controller: 'widget',

    border: false,
    baseCls: 'widget small',
    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    viewModel: true,

    refreshIntervalSec: 10,

    items: [{
        xtype: 'component',
        cls: 'header',
        itemId: 'header',
        html: '<h1>' + 'Network Information'.t() + '</h1>' +
            '<div class="actions"><a class="action-btn"><i class="fa fa-rotate-left fa-lg" data-action="refresh"></i></a></div>'
    }, {
        xtype: 'container',
        //cls: 'wg-wrapper flex',
        items: [{
            xtype: 'component',
            bind: {
                html: '<div class="info-box" style="border-bottom: 1px #EEE solid;">' +
                '<div class="info-item">' + 'Currently Active'.t() + '<br/><span>{stats.activeHosts}</span></div>' +
                '<div class="info-item">' + 'Maximum Active'.t() + '<br/><span>{stats.maxActiveHosts}</span></div>' +
                '<div class="info-item">' + 'Known Devices'.t() + '<br/><span>{stats.knownDevices}</span></div>' +
                '<div class="info-actions">' +
                '<a class="wg-button" href="#hosts">' + 'Hosts'.t() + '</a>' +
                '<a class="wg-button" href="#devices">' + 'Devices'.t() + '</a>' +
                '</div>' +
                '</div>'
            }
        }, {
            xtype: 'component',
            bind: {
                html: '<div class="info-box">' +
                '<div class="info-item">' + 'Total Sessions'.t() + '<br/><span>{sessions.totalSessions}</span></div>' +
                '<div class="info-item">' + 'Scanned Sessions'.t() + '<br/><span>{sessions.scannedSessions}</span></div>' +
                '<div class="info-item">' + 'Bypassed Sessions'.t() + '<br/><span>{sessions.bypassedSessions}</span></div>' +
                '<div class="info-actions">' +
                '<a class="wg-button" href="#sessions">' + 'Sessions'.t() + '</a> ' +
                '</div>' +
                '</div>'
            }
        }]
    }],

    fetchData: function (cb) {
        var me = this, vm = me.getViewModel();

        if (vm) {
            me.setLoading({ useTargetEl: true });
            Rpc.asyncData('rpc.sessionMonitor.getSessionStats')
                .then(function(result) {
                    vm.set('sessions', result);
                    me.setLoading(false);
                    cb();
                });
        }
    }
});
Ext.define('Ung.widget.NetworkLayout', {
    extend: 'Ext.container.Container',
    alias: 'widget.networklayoutwidget',

    controller: 'widget',
    border: false,
    baseCls: 'widget',
    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    refreshIntervalSec: 0,

    items: [{
        xtype: 'component',
        cls: 'header',
        height: 40,
        itemId: 'header',
        html: '<h1>' + 'Network Layout'.t() + '</h1>' +
            '<div class="actions"><a class="action-btn"><i class="fa fa-rotate-left fa-lg" data-action="refresh"></i></a></div>'
    }, {
        //xtype: 'container',
        cls: 'net-layout',
        margin: '0 10 10 10',
        layout: {
            type: 'vbox',
            align: 'stretch'
            //pack: 'middle'
        },
        border: false,
        defaults: {
            xtype: 'component'
        },
        items: [{
            html: '<img src="' + '/skins/default/images/admin/icons/interface-cloud.png" style="margin: 0 auto; display: block; height: 30px;"/>'
        }, {
            xtype: 'container',
            cls: 'ifaces',
            height: 75,
            itemId: 'externalInterface'
        }, {
            xtype: 'component',
            cls: 'line'
        }, {
            xtype: 'container',
            cls: 'ifaces',
            height: 120,
            itemId: 'internalInterface'
        }]
    }],

    fetchData: function (cb) {
        var me = this;

        Rpc.asyncData('rpc.networkManager.getNetworkSettings')
            .then(function(result) {
                if(Util.isDestroyed(me)){
                    return;
                }
                cb();
                me.down('#externalInterface').removeAll();
                me.down('#internalInterface').removeAll();
                Ext.each(result.interfaces.list, function (iface) {
                    if (iface.configType !== 'DISABLED') {
                        iface.vrrpMaster = false;
                        if (iface.vrrpEnabled) {
                            iface.vrrpMaster = Rpc.directData('rpc.networkManager.isVrrpMaster', iface.interfaceId);
                        }
                        if (iface.isWan) {
                            me.down('#externalInterface').add({
                                xtype: 'interfaceitem',
                                cls: 'iface wan',
                                viewModel: {
                                    data: {
                                        iface: iface,
                                        devicesCount: 0
                                    }
                                }
                            });
                        } else {
                            me.down('#internalInterface').add({
                                xtype: 'interfaceitem',
                                itemId: 'intf_' + iface.interfaceId,
                                cls: 'iface',
                                viewModel: {
                                    data: {
                                        iface: iface,
                                        devicesCount: 0
                                    }
                                }
                            });
                        }
                    }
                });
                me.getController().onStatsUpdate(); // force fetching devices count
            });
    }
});
Ext.define('Ung.widget.Notifications', {
    extend: 'Ext.container.Container',
    alias: 'widget.notificationswidget',

    controller: 'widget',
    viewModel: {
        data: {
            count: null
        }
    },
    border: false,
    baseCls: 'widget small info-widget',
    height: 300,

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    refreshIntervalSec: 0,
    lastFetchTime: null,

    items: [{
        xtype: 'component',
        cls: 'header',
        itemId: 'header',
        bind: {
            html: '<h1>' + 'Notifications'.t() + ' {count}</h1>' +
                '<div class="actions"><a class="action-btn"><i class="fa fa-rotate-left fa-lg" data-action="refresh"></i></a></div>'
        }
    }, {
        xtype: 'component',
        itemId: 'notif',
        scrollable: 'y',
        flex: 1
    }, {
        xtype: 'button',
        margin: '10 20',
        text: 'Help'.t(),
        iconCls: 'fa fa-question-circle',
        href: Rpc.directData('rpc.helpUrl') + '?fragment=' + window.location.hash.substr(1) + '&' + Util.getAbout(),
        hidden: true,
        bind: { hidden: '{!count || count === "(0)"}' }
    }],

    fetchData: function (cb) {
        var me = this, vm = me.getViewModel(), notifCmp = me.down('#notif');
        me.setLoading({ useTargetEl: true });
        Rpc.asyncData('rpc.notificationManager.getNotifications')
            .then(function (result) {
                var notificationArr = '<ul style="margin: 0; padding: 0 10px 30px 30px;">', i;
                if (result != null && result.list.length > 0) {
                    for (i = 0; i < result.list.length; i += 1) {
                        notificationArr += '<li>' + result.list[i] + '</li>';
                    }
                    notificationArr += '</ul>';
                    notifCmp.setHtml(notificationArr);
                    vm.set('count', '(' + result.list.length + ')');
                } else {
                    notifCmp.setHtml('<p style="text-align: center; font-size: 14px;">' + 'No notifications'.t() + '!</p>');
                    vm.set('count', '(0)');
                }
            }, function (ex) {
                Util.handleException(ex);
            })
            .always(function() {
                me.setLoading(false);
                if (cb) cb();
            });
    }
});
Ext.define('Ung.widget.PolicyOverview', {
    extend: 'Ext.container.Container',
    alias: 'widget.policyoverviewwidget',

    controller: 'widget',

    border: false,
    baseCls: 'widget',
    height: 300,

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    viewModel: true,

    refreshIntervalSec: 30,

    items: [{
        xtype: 'component',
        cls: 'header',
        itemId: 'header',
        html: '<h1>' + 'Policy Overview'.t() + '</h1>' +
            '<div class="actions"><a class="action-btn"><i class="fa fa-rotate-left fa-lg" data-action="refresh"></i></a></div>'
    }, {
        xtype: 'treepanel',
        flex: 1,
        rootVisible: false,
        displayField: 'name',
        store: 'policiestree',
        header: false,
        border: false,
        animate: false,
        useArrows: true,
        disableSelection: true,
        sortableColumns: false,
        enableColumnHide: false,
        columns: [{
            xtype: 'treecolumn',
            text: 'Policy Name (id)'.t(),
            flex: 1,
            dataIndex: 'name',
            renderer: function (val, meta, rec) {
                return '<strong>' + rec.get('name') + '</strong> (' + rec.get('policyId') + ')';
            }
        }, {
            xtype: 'widgetcolumn',
            width: 120,
            text: 'Apps Installed'.t() + ',<br/>' + 'Running'.t() + ', ' + 'Inherited'.t(),
            widget: {
                xtype: 'appspicker',
                bind: {
                    apps: '{record.apps}'
                }
            }
        }, {
            width: 80,
            dataIndex: 'stats',
            align: 'right',
            text: 'Sessions'.t(),
            renderer: function(val) {
                return val ? val.sessionCount : '<span style="color: #CCC">0</span>';
            }
        }, {
            width: 80,
            dataIndex: 'stats',
            align: 'right',
            text: 'Traffic'.t(),
            renderer: function(val, metaData, record) {
                if(val && val.totalBps > 0){
                    var value = Util.bytesRenderer(val.totalBps,true);
                    metaData.tdAttr = 'data-qtip="' + value + '"';
                    return value;
                }
                return '<span style="color: #CCC">0</span>';
            }
        }, {
            xtype: 'actioncolumn',
            iconCls: 'fa fa-external-link-square',
            align: 'center',
            tooltip: 'Go to Policy'.t(),
            width: 30,
            handler: function (view, rowIndex, colIndex, item, e, record) {
                Ung.app.redirectTo('#apps/' + record.get('policyId'));
            }
        }]
    }],

    fetchData: function (cb) {
        var me = this;
        me.down('treepanel').setLoading(true);
        // Ext.getStore('policiestree').build(function () {

        // get policies apps
        Rpc.asyncData('rpc.appManager.getAppsViews')
            .then(function (policies) {

                // get policies stats
                Rpc.asyncData('rpc.sessionMonitor.getPoliciesSessionsStats')
                    .then(function (stats) {

                        // build apps/stats
                        Ext.Array.each(policies, function (policy) {
                            var treePol = Ext.getStore('policiestree').findRecord('policyId', policy.policyId);
                            var apps = [];
                            Ext.Array.each(policy.appProperties.list, function (app) {
                                if (app.type !== 'FILTER') { return; }
                                var instance = Ext.Array.findBy(policy.instances.list, function(instance) { return instance.appName === app.name; });
                                var parentPolicy = null;
                                if (instance) {
                                    // installedAppsNo++;
                                    var inherited = false;
                                    if (instance.policyId && policy.policyId !== instance.policyId) {
                                        parentPolicy = Ext.getStore('policiestree').findRecord('policyId', instance.policyId).get('name');
                                        inherited = true;
                                    }
                                    instance.runState = policy.runStates.map[instance.id];
                                    apps.push({
                                        name: app.name,
                                        displayName: app.displayName,
                                        state: Ext.create('Ung.model.AppState',{instance: instance}),
                                        policyId: instance.policyId,
                                        parentPolicy: parentPolicy,
                                        inherited: inherited
                                    });
                                }
                            });
                            if(treePol){
                                treePol.set('apps', apps);
                                treePol.set('stats', stats[policy.policyId.toString()]);
                            }
                        });

                        Ext.getStore('policiestree').sync();
                        me.down('treepanel').setLoading(false);
                        cb();
                    });
            });
        // });
    }
});
Ext.define('Ung.widget.Report', {
    extend: 'Ext.container.Container',
    alias: 'widget.reportwidget',

    controller: 'widget',
    viewModel: {
        formulas: {
            f_size: function (get) {
                switch(get('widget.size')) {
                case 'SMALL': return 300;
                case 'MEDIUM': return 450;
                case 'LARGE': return 600;
                case 'XLARGE': return 750;
                }
            }
        }
    },
    config: {
        widget: null,
        entry: null
    },

    lastFetchTime: null,


    bind: {
        width: '{f_size}'
    },

    border: false,
    baseCls: 'widget',

    visible: false,

    items: [{
        xtype: 'component',
        cls: 'header',
        itemId: 'header',
        bind: {
            html: '<h1><a href="#reports?{entry.url}{query.string}">{entry.localizedTitle}</a></h1><p><a href="#reports?cat={entry.categorySlug}{query.string}">{entry.category}</a></p>' +
                '<div class="actions">' +
                    '<a class="action-btn"><i class="fa fa-rotate-left fa-lg" data-action="refresh"></i></a>' +
                    '<a class="action-btn"><i class="fa fa-bars fa-lg" data-action="menu"></i></a>' +
                '</div>'
        }
    }, {
        xtype: 'component',
        cls: 'menu',
        itemId: 'menu',
        bind: {
            html: '<p>{entry.description}</p>' +
                '<div class="options">' +
                '<i class="fa fa-times fa-lg" data-action="closemenu"></i>' +
                '<a data-action="export" style="display: {entry.type === "EVENT_LIST" ? "auto" : "none"};"><i class="fa fa-download fa-lg" data-action="export"></i> ' + 'Export (CSV)'.t() + '</a>' +
                '<a data-action="reports" data-url="#reports?{entry.url}{query.string}"><i class="fa fa-external-link-square fa-lg"></i> ' + 'Open in Reports'.t() + '</a>' +
                '<hr/>' +
                '<label style="color: #999; margin: 10px 0; display: block;">' + 'Settings'.t() + '</label>' +
                '<label style="float: left; width: 20%; padding: 5px 0;">' + 'Size'.t() +':</label> <a data-action="size-SMALL" class="size {widget.size === "SMALL" ? "selected" : ""}">S</a>' +
                '<a data-action="size-MEDIUM" class="size {widget.size === "MEDIUM" ? "selected" : ""}">M</a>' +
                '<a data-action="size-LARGE" class="size {widget.size === "LARGE" ? "selected" : ""}">L</a>' +
                '<a data-action="size-XLARGE" class="size {widget.size === "XLARGE" ? "selected" : ""}">XL</a>' +
                '<br/>' +
                '<label>' + 'Auto Refresh'.t() + ':</label> <select>' +
                    '<option value=10 {widget.refreshIntervalSec === 10 ? "selected" : ""}>10 ' + 'seconds'.t() + '</option>' +
                    '<option value=30 {widget.refreshIntervalSec === 30 ? "selected" : ""}>30 ' + 'seconds'.t() + '</option>' +
                    '<option value=60 {widget.refreshIntervalSec === 60 ? "selected" : ""}>1 ' + 'minute'.t() + '</option>' +
                    '<option value=120 {widget.refreshIntervalSec === 120 ? "selected" : ""}>2 ' + 'minutes'.t() + '</option>' +
                    '<option value=300 {widget.refreshIntervalSec === 300 ? "selected" : ""}>5 ' + 'minutes'.t() + '</option>' +
                    '<option value=0 {widget.refreshIntervalSec === 0 ? "selected" : ""}>' + 'never'.t() + '</option>' +
                '</select><br/>' +
                '<button data-action="save">' + 'Save'.t() + '</button>' +
                '</div>'
        }
    }]
});
Ext.define('Ung.widget.Resources', {
    extend: 'Ext.container.Container',
    alias: 'widget.resourceswidget',

    controller: 'widget',

    viewModel: {
        formulas: {
            diskBackgroundStyle: function(get){
                if(get('stats.freeDiskPercent') < 5){
                    return 'background-color: red;';
                }
                return 'background-color:;';
            }
        }
    },

    border: false,
    baseCls: 'widget',
    cls: 'small',

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    items: [{
        xtype: 'component',
        cls: 'header',
        html: '<h1>' + 'Resources'.t() + '</h1>'
    }, {
        xtype: 'container',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'component',
            flex: 1,
            padding: '5 10',
            bind: {
                html: '<div>' +
                        '<p style="margin: 2px; text-align: left; font-weight: bold; font-size: 14px;">' + 'Memory'.t() + '</p>' +
                        '<div class="load-bar"><div class="load-bar-inner" style="left: -{stats.freeMemoryPercent}%;"></div><p>{stats.totalMemory}</p></div>' +
                        '<div class="load-bar-values">' +
                            '<div class="load-used"><strong>{stats.usedMemoryPercent}%</strong> used<br/><span>{stats.usedMemory}</span></div>' +
                            '<div class="load-free">free <strong>{stats.freeMemoryPercent}%</strong><br/><span>{stats.freeMemory}</span></div>' +
                        '</div>' +
                      '</div>'
            }
        }, {
            xtype: 'component',
            flex: 1,
            padding: '5 10',
            hidden: true,
            bind: {
                hidden: '{!stats.SwapTotal}',
                html: '<div>' +
                        '<p style="margin: 2px; text-align: left; font-weight: bold; font-size: 14px;">' + 'Swap'.t() + '</p>' +
                        '<div class="load-bar"><div class="load-bar-inner" style="left: -{stats.freeSwapPercent}%;"></div><p>{stats.totalSwap}</p></div>' +
                        '<div class="load-bar-values">' +
                            '<div class="load-used"><strong>{stats.usedSwapPercent}%</strong> used<br/><span>{stats.usedSwap}</span></div>' +
                            '<div class="load-free">free <strong>{stats.freeSwapPercent}%</strong><br/><span>{stats.freeSwap}</span></div>' +
                        '</div>' +
                      '</div>'
            }
        }, {
            xtype: 'component',
            flex: 1,
            padding: '5 10',
            bind: {
                html: '<div>' +
                        '<p style="margin: 2px; text-align: left; font-weight: bold; font-size: 14px;">' + 'Disk'.t() + '</p>' +
                        '<div class="load-bar"><div class="load-bar-inner" style="left: -{stats.freeDiskPercent}%;{diskBackgroundStyle}"></div><p>{stats.totalDisk}</p></div>' +
                        '<div class="load-bar-values">' +
                            '<div class="load-used"><strong>{stats.usedDiskPercent}%</strong> used<br/><span>{stats.usedDisk}</span></div>' +
                            '<div class="load-free">free <strong>{stats.freeDiskPercent}%</strong><br/><span>{stats.freeDisk}</span></div>' +
                        '</div>' +
                      '</div>'
            }
        }]
    }]
});
Ext.define('Ung.widget.WidgetController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.widget',

    control: {
        '#': {
            beforedestroy: 'onBeforeDestroy',
            afterrender: 'onAfterRender'
        },
        '#header': {
            render: 'headerRender'
        },
        '#menu': {
            render: 'menuRender'
        }
    },

    listen: {
        store: {
            '#stats': {
                // used just to fetch devices count for Network Layout widget
                datachanged: 'onStatsUpdate'
            }
        }
    },

    queuedSaveTaskWait: 0,
    queuedSaveTaskMaxWait: 1000,
    queuedSaveTaskDelay: 100,
    onAfterRender: function (widget) {
        var me = this, vm = me.getViewModel(), eventGrid = widget.down('eventreport > ungrid');
        // add to queue non report widgets when enabled
        vm.bind('{widget.enabled}', function (enabled) {
            if (enabled && (Ext.isFunction(widget.fetchData) || widget.getXType() === 'reportwidget')) {
                widget.visible = true;
                DashboardQueue.add(widget);
            }
        });

        // highlight only widgets for which conditions apply
        if (widget.getXType() === 'reportwidget') {
            vm.bind('{query.conditions}', function (conditions) {
                widget.lastFetchTime = null;
                if (conditions.length === 0) {
                    widget.unmask();
                    return;
                }

                if (!TableConfig.containsColumns(
                        vm.get('entry.table'),
                        Ext.Array.map(conditions, function(condition){
                            return condition.get('column');
                        })
                        )) {
                    widget.mask();
                } else {
                    widget.unmask();
                }
            });
        }

        // for EVENT_LIST widgets save displayColumns setting on column hide/show
        if (eventGrid) {
            me.queuedSaveTask = new Ext.util.DelayedTask( Ext.bind(function(){
                this.queuedSaveTaskWait = this.queuedSaveTaskWait - this.queuedSaveTaskDelay;
                if(this.queuedSaveTaskWait > 0){
                    this.queuedSaveTask.delay( this.queuedSaveTaskDelay );
                }else{
                    Rpc.asyncData('rpc.dashboardManager.setSettings', Ung.dashboardSettings)
                        .then(function () {
                        });
                }
            }, me) );

            eventGrid.addListener('columnhide', function () {
                me.updateWidgetColumns(eventGrid);
            });
            eventGrid.addListener('columnshow', function () {
                me.updateWidgetColumns(eventGrid);
            });
        }
    },


    updateWidgetColumns: function (grid) {
        var me = this, vm = me.getViewModel(), columns = [];
        Ext.Array.each(grid.getColumns(), function (col) {
            if (!col.isHidden()) {
                columns.push(col.dataIndex);
            }
        });
        vm.set('widget.displayColumns', columns);
        me.queuedSaveTaskWait = me.queuedSaveTaskMaxWait;
        me.queuedSaveTask.delay( me.queuedSaveTaskDelay );
    },

    // onRender: function (widget) {
    //     var me = this;
    //     widget.getEl().on({
    //         mouseleave: function () {
    //             me.closeMenu();
    //         }
    //     });
    // },

    headerRender: function (cmp) {
        var me = this, wg = me.getView();
        cmp.getEl().on({
            click: function (e) {
                // on refresh
                if (e.target.dataset.action === 'refresh') {
                    wg.lastFetchTime = null; // reset fetch time
                    DashboardQueue.addFirst(wg); // add it first
                }
                // show menu
                if (e.target.dataset.action === 'menu') {
                    wg.down('#menu').setStyle({ zIndex: 999 });
                    wg.addCls('showmenu');
                }
            }
        });
    },

    menuRender: function (cmp) {
        var me = this, wg = me.getView(), vm = me.getViewModel();
        cmp.getEl().on({
            click: function (e) {
                var action = e.target.dataset.action;

                if (!action) { return; }
                // close menu but only when not selecting size
                if (action.indexOf('size') < 0) {
                    me.closeMenu();
                }

                // on download
                if (action === 'download') {
                    var chart = wg.down('graphreport').getController().chart;
                    if (chart) {
                        chart.exportChart({
                            filename: vm.get('entry.title').trim().replace(/ /g, '_')
                        }, {
                            chart: {
                                backgroundColor: '#FFFFFF'
                            }
                        });
                    }
                }

                // on export
                if (action === 'export') {
                    var grid = wg.down('grid');
                    var exportForm = document.getElementById('exportGridSettings');

                    var data = Ext.Array.pluck(grid.getStore().getRange(), 'data');
                    Ext.Array.forEach(data, function (rec) {
                        delete rec._id;
                    });
                    exportForm.gridName.value = vm.get('entry.title').trim().replace(/ /g, '_') + '-WIDGET-';
                    exportForm.gridData.value = Ext.encode(data);
                    exportForm.submit();
                }

                // on reports
                if (action === 'reports') {
                    Ung.app.redirectTo(e.target.dataset.url);
                }
                // on size
                if (action.indexOf('size') >= 0) {
                    var newSize = e.target.dataset.action.replace('size-', '');
                    vm.set('widget.size', newSize.toUpperCase());
                }

                // on save
                if (action === 'save') {
                    vm.set('widget.refreshIntervalSec', parseInt(wg.down('#menu').getEl().dom.getElementsByTagName('select')[0].value, 10));
                    Rpc.asyncData('rpc.dashboardManager.setSettings', Ung.dashboardSettings)
                        .then(function () {
                            wg.lastFetchTime = null; // reset fetch time
                            DashboardQueue.addFirst(wg);
                        });
                }
            }
        });
    },

    closeMenu: function () {
        var view = this.getView();
        view.removeCls('showmenu');
        if (!view.down('#menu')) { return; }
        Ext.defer(function () {
            view.down('#menu').setStyle({ zIndex: -1 });
        }, 300);
    },


    init: function (view) {
        var vm = view.getViewModel(), entryType;
        if (vm.get('entry')) {
            switch(vm.get('entry.type')) {
            case 'PIE_GRAPH':
            case 'TIME_GRAPH':
            case 'TIME_GRAPH_DYNAMIC':
                entryType = 'graphreport'; break;
            case 'TEXT':
                entryType = 'textreport'; break;
            case 'EVENT_LIST':
                entryType = 'eventreport'; break;
            }

            view.add({
                xtype: entryType,
                itemId: 'report-widget',
                height: 250,
                isWidget: true
            });
        }
    },

    onBeforeDestroy: function (widget) {
        // remove widget from queue if; important if removal is happening while fetching data
        if (widget.tout) {
            clearTimeout(widget.tout);
            widget.tout = null;
        }
    },

    onSettingsBeforeClose: function () {
        var vm = this.getViewModel();
        if (vm.get('widget').dirty) {
            vm.get('widget').reject();
        }
    },

    // used only for Network Layout widget devices number update when stats change
    onStatsUpdate: function () {
        var me = this;
        if (me.getView().getXType() === 'networklayoutwidget') {
            // get devices
            Rpc.asyncData('rpc.hostTable.getHosts')
                .then(function (result) {
                    // reset the number of devices
                    Ext.Array.each(me.getView().query('interfaceitem'), function (intfCmp) {
                        intfCmp.getViewModel().set('devicesCount', 0);
                    });

                    Ext.Array.each(result.list, function (device) {
                        var intfCmp = me.getView().down('#intf_' + device.interfaceId), devNo;
                        if (intfCmp && device.active) {
                            devNo = intfCmp.getViewModel().get('devicesCount') || 0;
                            intfCmp.getViewModel().set('devicesCount', devNo += 1);
                        }
                    });
                }, function (ex) {
                    console.log(ex);
                });
        }
    }

});
Ext.define('Ung.view.apps.Apps', {
    extend: 'Ext.panel.Panel',
    xtype: 'ung.apps',
    itemId: 'apps',
    layout: 'card',

    itemType: Rpc.directData('rpc.skinInfo.appsViewType') === 'rack' ? 'rackitem' : 'simpleitem',

    controller: 'apps',
    viewModel: {
        data: {
            onInstalledApps: true,
            policyName: '',
            appsCount: 0,
            servicesCount: 0,
            autoInstallApps: false
        },
        stores: {
            installableApps: {
                sorters: [ { property: 'viewPosition', direction: 'ASC' }],
            },
            installableServices: {
                sorters: [ { property: 'viewPosition', direction: 'ASC' }]
            }
        }
    },

    defaults: {
        border: false
    },

    dockedItems: [{
        xtype: 'toolbar',
        ui: 'footer',
        dock: 'top',
        style: { background: '#D8D8D8' },
        items: [{
            xtype: 'button',
            text: 'Back to Apps',
            iconCls: 'fa fa-arrow-circle-left',
            focusable: false,
            hidden: true,
            bind: {
                text: 'Back to Apps (<strong>{policyName}</strong>)',
                hidden: '{onInstalledApps}'
            },
            handler: 'backToApps'
        }, {
            xtype: 'button',
            reference: 'policyBtn',
            hidden: true,
            iconCls: 'fa fa-file-text-o',
            focusable: false,
            bind: {
                text: '{policyName}',
                hidden: '{!onInstalledApps || !policyManagerInstalled}'
            }
        }, {
            xtype: 'button',
            text: 'Install Apps'.t(),
            iconCls: 'fa fa-download',
            focusable: false,
            handler: 'showInstall',
            hidden: true,
            bind: {
                hidden: '{!onInstalledApps || isRestricted || !licenseServerConnectivity || !isRegistered }'
            }
        }, {
            xtype: 'component',
            html: '<i class="fa fa-spinner fa-spin fa-lg fa-fw"></i>&nbsp;' + 'Installing recommended apps'.t(),
            hidden: true,
            bind: {
                hidden: '{autoInstallApps == false}'
            }
        }, {
            xtype: 'component',
            reference: 'installHeader',
            html: '',
            hidden: true,
            bind: {
                html: 'Available Apps for &nbsp;<i class="fa fa-file-text-o"></i> <strong>{policyName}</strong>',
                hidden: '{onInstalledApps || !policyManagerInstalled}'
            }
        }]
    }],


    items: [{
        itemId: 'installedApps',
        xtype: Rpc.directData('rpc.skinInfo.appsViewType') === 'rack' ? 'apps-rack' : 'apps-simple',
    }, {
        scrollable: true,

        itemId: 'installableApps',
        layout: { type: 'vbox', align: 'stretch' },
        items: [{
            xtype: 'component',
            cls: 'apps-title',
            html: 'Apps'.t()
        }, {
            xtype: 'dataview',
            bind: '{installableApps}',
            tpl: '<tpl for=".">' +
                    '<div class="app-install-item {extraCls}">' +
                    '<img src="' + '/icons/apps/{name}.svg" width=80 height=80/>' +
                    '<i class="fa fa-download fa-3x"></i>' +
                    '<i class="fa fa-check fa-3x"></i>' +
                    '<span class="loader">Loading...</span>' +
                    '<h3>{displayName}</h3>' + '<p>{desc}</p>' +
                    '</div>' +
                '</tpl>',
            itemSelector: 'div'
        }, {
            xtype: 'component',
            cls: 'apps-title',
            html: 'Service Apps'.t()
        }, {
            xtype: 'dataview',
            bind: '{installableServices}',
            tpl: '<tpl for=".">' +
                    '<div class="app-install-item {extraCls}">' +
                    '<img src="' + '/icons/apps/{name}.svg" width=80 height=80/>' +
                    '<i class="fa fa-download fa-3x"></i>' +
                    '<i class="fa fa-check fa-3x"></i>' +
                    '<span class="loader">Loading...</span>' +
                    '<h3>{displayName}</h3>' + '<p>{desc}</p>' +
                    '</div>' +
                '</tpl>',
            itemSelector: 'div'
        }]
    }]
});
Ext.define('Ung.view.apps.AppsController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.apps',

    control: {
        '#': { afterrender: 'onAfterRender', activate: 'onActivate' },
        '#installableApps': { deactivate: 'onInstallableDeactivate' },
        '#installableApps > dataview': { select: 'onInstallApp' }
    },
    listen: {
        store: {
            '#policiestree': {
                rootchange: 'onRootChange'
            }
        },
        global: {
            // init: 'onInit',
            appremove: 'onAppRemove',
            postregistration: 'onPostRegistration',
        }
    },

    // build the apps components and add them to the view
    onAfterRender: function () {
        var me = this, v=this.getView();

        v.setLoading(true);
        Ung.util.Util.reloadLicenses();
        v.setLoading(false);

        // maybe there is a better way to get all the available apps regardless of policy
        var initPolicy = Rpc.directData('rpc.appsViews')[0]; // take the first policy (default)
        // build add all the apps containers (rack items) and only update them when based on selected policy

        var apps = [], appCmps = [], srvCmps = [];

        Ext.Array.each(initPolicy.appProperties.list, function (app) {
            apps.push(app);
        });

        apps = Ext.Array.sort(apps, function (a, b) {
            if (a.viewPosition < b.viewPosition) {
                return -1;
            }
            return 1;
        });

        Ext.Array.each(apps, function (app) {
            var appItem = {
                xtype: me.getView().itemType,
                itemId: 'app_' + app.name,
                app: app,
                viewModel: {
                    data: {
                        app: app,
                        instanceId: null,
                        installing: false
                    },
                    formulas: {
                        powerCls: {
                            bind: {
                                bindTo: '{state}',
                                deep: true
                            },
                            get: function(state){
                                if(state == null){
                                    return '';
                                }
                                if(state.get('inconsistent')){
                                    return 'inconsistent';
                                }else if(state.get('power')){
                                    return 'powering';
                                }else if(state.get('on')){
                                    return 'on';
                                }else{
                                    return '';
                                }
                            }
                        }
                    }
                }
            };
            if (app.type === 'FILTER') {
                appCmps.push(appItem);
            }else{
                srvCmps.push(appItem);
            }
        });

        me.getView().down('#_apps').add(appCmps);
        me.getView().down('#_services').add(srvCmps);

        var vm = this.getViewModel();

        vm.bind('{reportsAppStatus}', function () {
            Ext.getStore('policiestree').build();
            me.getApps();
        });

        vm.bind('{policyId}', function () {
            if (Ext.getStore('policiestree').getCount() > 0) {
                var policyNode = Ext.getStore('policiestree').findNode('policyId', vm.get('policyId'));
                if (policyNode) {
                    vm.set('policyName', policyNode.get('name'));
                    me.getApps();
                } else {
                    Ext.fireEvent('invalidquery');
                }
            }
        });

        // don't show install button if restricted
        vm.set('isRestricted', Rpc.directData('rpc.UvmContext.licenseManager.isRestricted'));

        // don't show install button if connection to license server is not up
        vm.set('licenseServerConnectivity', Rpc.directData('rpc.UvmContext.licenseManager.getLicenseServerConnectivity'));

        // don't show install button if no cmd registration
        vm.set('isRegistered', Rpc.directData('rpc.isRegistered'));

        // If installing recommended apps on initial install, note this on the console.
        var autoInstallAppsFlag = Rpc.directData('rpc.appManager').isAutoInstallAppsFlag();
        if(autoInstallAppsFlag){
            vm.set('autoInstallApps', true);
            var appInstallMonitorDelay = 250;
            var appInstallMonitor = new Ext.util.DelayedTask( Ext.bind(function(){
                if(Util.isDestroyed(vm)){
                    return;
                }
                me.getApps();
                var autoInstallAppsFlag = Rpc.directData('rpc.appManager').isAutoInstallAppsFlag();
                vm.set('autoInstallApps', autoInstallAppsFlag);
                if(autoInstallAppsFlag == true){
                    appInstallMonitor.delay( appInstallMonitorDelay );
                }

            }, me) );
            appInstallMonitor.delay( appInstallMonitorDelay );
        }
    },

    // when policy changes the apps components are updated based on this policy app instances/props
    applyPolicy: function(policy) {
        var me = this, vm = me.getViewModel(), appVm, app,
            appCard = Ung.app.getMainView().down('#appCard');

        // when loading directly an app via rout, apply policy name for back button text
        if (appCard) {
            appCard.getViewModel().set('policyName', me.getViewModel().get('policyName'));
        }

        me.getView().query(me.getView().itemType).forEach(function (app) {
            appVm = app.getViewModel();
            if(appVm.get('state') && appVm.get('state').get('power')){
                // App is already processing its power mode.  Let them handle it.
                return;
            }
            var appName = appVm.get('app.name');

            var instance = Ext.Array.findBy(policy.instances.list, function(instance) {
                return instance.appName === appName;
            });
            var appProperties = Ext.Array.findBy(policy.appProperties.list, function (prop) {
                return prop.name === appName;
            });

            if (instance) {
                // !!! do async stuff
                var parentPolicy = null, metrics = null;
                if (instance.policyId && policy.policyId !== instance.policyId) {
                    parentPolicy = Ext.getStore('policiestree').findNode('policyId', instance.policyId).get('name');
                }
                if (policy.appMetrics.map[instance.id]) {
                    metrics = policy.appMetrics.map[instance.id].list;
                }

                appVm.set({
                    instance: instance,
                    instanceId: instance.id,
                    runState: policy.runStates.map[instance.id],
                    props: appProperties,
                    parentPolicy: parentPolicy,
                    metrics: metrics,
                    route: (appVm.get('app.type') === 'FILTER') ? '#apps/' + policy.policyId + '/' + appVm.get('app.name') : '#service/' + appVm.get('app.name'),
                    helpSource: Rpc.directData('rpc.helpUrl') + '?fragment=apps/' + policy.policyId + '/' + appVm.get('app.name').replace(/ /g, '-') + '&' + Util.getAbout()
                });
                appVm.set('state', Ext.create('Ung.model.AppState',{vm: appVm}));
            } else {
                appVm.set({
                    instance: null,
                    instanceId: null,
                    state: null,
                    parentPolicy: null,
                    metrics: null,
                    route: null
                });
            }
            var license = policy.licenseMap.map[appVm.get('app.name')];
            var licenseMessage = Util.getLicenseMessage(license);

            appVm.set({
                license: license,
                licenseMessage: licenseMessage,
            });
        });

        // deal with installable apps
        var installableApps = [], installableServices = [];
        Ext.Array.each(policy.installable.list, function (appName) {
            app = Ext.Array.findBy(policy.appProperties.list, function (a) {
                return a.name === appName;
            });
            app.desc = Util.appDescription[app.name];
            app.route = (app.type === 'FILTER') ? '#apps/' + policy.policyId + '/' + app.name : '#service/' + app.name;
            if (app.type === 'FILTER') {
                installableApps.push(app);
            } else {
                installableServices.push(app);
            }
        });
        vm.getStore('installableApps').loadData(installableApps);
        vm.getStore('installableServices').loadData(installableServices);
    },

    // check policy manager when activating apps view
    onActivate: function () {
        this.getViewModel().set('policyManagerInstalled', Rpc.directData('rpc.appManager.app', 'policy-manager') ? true : false);
    },

    // remove already finished installed apps when deactivating the view
    onInstallableDeactivate: function () {
        var me = this, vm = me.getViewModel();
        vm.getStore('installableApps').each(function (app) {
            if (app.get('extraCls') === 'finish') {
                app.drop();
            }
        });
    },

    // when policy id changes by selecting another policy from the tree, get the apps
    onRootChange: function () {
        var me = this, menuItems = [], vm = me.getViewModel();

        if (Ext.getStore('policiestree').getCount() > 0) {
            Ext.getStore('policiestree').each(function (node) {
                menuItems.push({
                    margin: '0 0 0 ' + (node.get('depth') - 1) * 20,
                    text: node.get('name'),
                    iconCls: node.get('iconCls'),
                    href: '#apps/' + node.get('policyId'),
                    hrefTarget: '_self'
                });
            });

            menuItems.push('-');
            menuItems.push({
                text: 'Manage Policies',
                iconCls: 'fa fa-cog',
                href: '#service/policy-manager/policies',
                hrefTarget: '_self'
            });

            me.lookup('policyBtn').setMenu({
                plain: true,
                mouseLeaveDelay: 0,
                items: menuItems,
                listeners: {
                    click: function (menu, item) {
                        // for touch devices this hack is required
                        if (Ext.supports.Touch) {
                            Ung.app.redirectTo(item.href);
                        }
                    }
                }
            });

            var policyNode = Ext.getStore('policiestree').findNode('policyId', vm.get('policyId'));
            if (policyNode) {
                vm.set('policyName', policyNode.get('name'));
                vm.set('policyMenu', true);
            } else {
                Ung.app.redirectTo('#apps/1'); // redirect to main policy
            }
        } else {
            vm.set('policyMenu', false);
        }

        me.getApps(); // set when route changed
    },

    // actual method which fetches apps for a specific policy, then updates the components
    getApps: function () {
        var me = this, vm = this.getViewModel();

        // we need policies store before fetching apps
        if (Ext.getStore('policiestree').getCount() === 0) { return; }

        Rpc.asyncData('rpc.appManager.getAppsView', vm.get('policyId'))
        .then(function (policy) {
            if(Util.isDestroyed(me)){
                return;
            }
            me.applyPolicy(policy);
        });
    },

    // show installable apps card
    showInstall: function () {
        var me = this, vm = this.getViewModel();
        me.getView().setActiveItem('installableApps');
        vm.set('onInstalledApps', false);
    },

    // back to Apps from installable view
    backToApps: function () {
        var me = this, vm = this.getViewModel();
        me.getView().setActiveItem('installedApps');
        vm.set('onInstalledApps', true);
    },


    /**
     * method which initialize the app installation
     */
    onInstallApp: function (view, record) {
        var me = this, vm = me.getViewModel();
        if (!Rpc.directData('rpc.isRegistered') && !Rpc.directData('rpc.isCCHidden')){
            Ext.fireEvent('openregister');
            return;
        }

        // used for installable components
        if (record.get('extraCls') === 'progress') {
            return;
        }

        var appVm = vm.getView().down('#app_' + record.get('name')).getViewModel();
        appVm.set({
            installing: true,
            parentPolicy: null
        });

        // used for installable components
        record.set('extraCls', 'progress');

        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.appManager.instantiate', record.get('name'), vm.get('policyId')),
            Rpc.asyncPromise('rpc.appManager.getAppsViews')
        ])
        .then(function (result) {
            if(Util.isDestroyed(appVm, vm)){
                return;
            }
            var instance = result[0].getAppSettings();

            appVm.set({
                installing: false,
                instance: instance,
                instanceId: instance.id,
                runState: result[1][0].runStates.map[instance.id],
                parentPolicy: null,
                metrics: result[0].getMetrics().list,
                route: (record.get('type') === 'FILTER') ? '#apps/' + instance.policyId + '/' + record.get('name') : '#service/' + record.get('name')
            });
            appVm.set('state', Ext.create('Ung.model.AppState',{vm: appVm}));

            record.set('extraCls', 'finish');

            if (record.get('name') === 'reports') {
                Ung.app.reportscheck();
            }

            if (record.get('name') === 'live-support') { // just reload the page for now
                Ung.app.getMainView().getController().setLiveSupport();
            }

            if (record.get('name') === 'policy-manager') { // build the policies tree
                Ext.getStore('policiestree').build();
                vm.set('policyManagerInstalled', true);
            }

            // update policies to refresh instances
            Ext.getStore('policies').loadData(result[1]);
            Ext.fireEvent('appinstall', record.get('displayName'));
        });
    },

    onAppRemove: function () {
        // just refresh apps to avoid any possible issues with rendering apps from parent policies
        Ung.app.getMainView().getController().setLiveSupport();
        this.getApps();
    },

    // basic power handler for the rack item
    powerHandler: function (btn) {
        var me = this, appVm = btn.up(me.getView().itemType).getViewModel(),
            appInstanceId = appVm.get('instanceId'), appManager;

        // supress clicking if operation pending
        if (btn.hasCls('powering')) {
            return;
        }

        btn.setUserCls('powering');

        if (!appInstanceId) {
            return;
        }
        Rpc.asyncData('rpc.appManager.app', appInstanceId)
        .then(function (result) {
            if(Util.isDestroyed(appVm, btn)){
                return;
            }
            appManager = result;
            appVm.get('state').set('power', true);
            if (!appVm.get('state').get('on') ){
                appVm.set('instance.targetState', 'RUNNING');
                appManager.start(function (result, ex) {
                    if(Util.isDestroyed(appVm)){
                        return;
                    }
                    appVm.get('state').detect();
                    if (ex) {
                        // Expected to be off
                        if (ex.message) {
                            Ext.Msg.alert('Warning'.t(), ex.message);
                        } else {
                            Util.handleException(ex);
                        }
                        appVm.set('instance.targetState', 'INITIALIZED');
                        appVm.get('state').detect();
                        return;
                    }
                    Rpc.asyncData('rpc.appManager.getAppsViews')
                    .then( function(result){
                        Ext.getStore('policies').loadData(result);
                        Ung.app.getGlobalController().getAppsView().getController().getApps();
                    },function(ex){
                        Util.handleException(ex);
                    });
                });
            } else {
                appVm.set('instance.targetState', 'INITIALIZED');
                appManager.stop(function (result, ex) {
                    if(Util.isDestroyed(appVm)){
                        return;
                    }
                    appVm.get('state').detect();
                    if (ex) {
                        // Expected to be on?
                        Util.handleException(ex);
                        appVm.set('instance.targetState', 'RUNNING');
                        appVm.get('state').detect();
                        return;
                    }
                    appVm.set({
                        metrics: null
                    });
                    Rpc.asyncData('rpc.appManager.getAppsViews')
                    .then( function(result){
                        Ext.getStore('policies').loadData(result);
                        Ung.app.getGlobalController().getAppsView().getController().getApps();
                    },function(ex){
                        Util.handleException(ex);
                    });
                });
            }
        }, function (ex) {
            Util.handleException(ex);
        });
    },

    onPostRegistration: function () {
        Ext.MessageBox.alert('Installation Complete!'.t(),
        'The recommended applications have automatically been installed.'.t()  + '<br/><br/>' +
        'Thank you for using Untangle!'.t(),
        function () {
            window.location.href = '/admin/index.do';
        });
    },

});
Ext.define('Ung.view.apps.Rack', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.apps-rack',

    scrollable: 'y',

    border: false,
    bodyBorder: false,

    userCls: 'rack',

    defaults: {
        border: false,
        bodyBorder: false,
        layout: {
            type: 'vbox',
            align: 'middle'
        }
    },

    items: [{
        xtype: 'container',
        items: [{
            xtype: 'component',
            cls: 'apps-separator',
            html: 'Apps'.t()
        }]
    }, {
        xtype: 'container',
        itemId: '_apps'
    }, {
        xtype: 'container',
        items: [{
            xtype: 'component',
            cls: 'apps-separator',
            html: 'Service Apps'.t()
        }]
    }, {
        xtype: 'container',
        itemId: '_services'
    }]
});
Ext.define('Ung.view.apps.RackGraph', {
    extend: 'Ext.container.Container',
    alias: 'widget.rackgraph',
    width: 125,
    height: 75
});
Ext.define('Ung.view.apps.RackGraphController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.rackgraph',

    init: function () {
        this.defaultColors = ['#00b000', '#3030ff', '#009090', '#00ffff', '#707070', '#b000b0', '#fff000', '#b00000', '#ff0000', '#ff6347', '#c0c0c0'];
    },

    control: {
        '#': {
            afterrender: 'onAfterRender'
        }
    },
    listen: {
        store: {
            '#metrics': {
                datachanged: 'onAddPoint'
            }
        }
    },
    updateMetricsCount: 0,

    onAfterRender: function (view) {
        // when instance changes reset metrics
        var me = this;
        me.getViewModel().bind('{instanceId}', function() {
            me.setMetrics();
        });


        // create chart
        this.chart = new Highcharts.Chart({
            chart: {
                type: 'areaspline',
                //zoomType: 'x',
                renderTo: view.down('#rackgraph').getEl().dom,
                spacing: [2, 0, 2, 0],
                margin: [10, 2, 2, 2],
                padding: [0, 0, 0, 0],
                backgroundColor: 'transparent',
                style: {
                    fontFamily: 'Source Sans Pro',
                    fontSize: '12px'
                }
            },
            lang: { noData: '' },
            exporting: {
                enabled: false
            },
            title: null,
            credits: {
                enabled: false
            },
            colors: ['#8EFB6C'],
            xAxis: [{
                type: 'datetime',
                labels: {
                    style: {
                        fontFamily: 'Source Sans Pro',
                        color: '#999',
                        fontSize: '10px'
                    },
                    y: 12
                },
                visible: false
            }],
            yAxis: {
                allowDecimals: false,
                gridLineWidth: 1,
                gridLineDashStyle: 'dash',
                gridLineColor: '#EEE',
                min: 0,
                minRange: 10,
                visible: false
            },
            legend: {
                enabled: false
            },
            tooltip: {
                backgroundColor: 'rgba(255, 255, 255, 0.7)',
                borderWidth: 1,
                borderColor: 'rgba(0, 0, 0, 0.1)',
                style: {
                    fontFamily: 'Source Sans Pro',
                    padding: '5px',
                    fontSize: '10px',
                },
                useHTML: true,
                hideDelay: 0,
                shadow: false,
                headerFormat: '',
                pointFormat: '{point.y} ' + 'sessions'.t()
            },
            plotOptions: {
                areaspline: {
                    fillOpacity: 0.2,
                    lineWidth: 1
                },
                series: {
                    marker: {
                        enabled: false,
                        states: {
                            hover: {
                                enabled: true,
                                lineWidthPlus: 0,
                                radius: 3,
                                radiusPlus: 0
                            }
                        }
                    },
                    states: {
                        hover: {
                            enabled: true,
                            lineWidthPlus: 1,
                            halo: {
                                size: 1
                            }
                        }
                    }
                }
            },
            series: [{
                name: 'Sessions'.t(),
                data: []
            }]
        });
    },

    setMetrics: function () {
        var me = this, metricsCmps = [], stats = [], i,
            metrics = me.getViewModel().get('metrics');

        if (!metrics || metrics.length == 0){
            return;
        }

        // add metrics labels if not added
        if (me.getView().down('#metrics').items.length === 0) {
            for (i = 0; i < metrics.length; i += 1) {
                metricsCmps.push({
                    bind: {
                        html: '<p>' + metrics[i].displayName + ': <span>{stats.'+ i +'}</span></p>'
                    }
                });
            }
            me.getView().down('#metrics').add(metricsCmps);
        }

        // just update the stats values
        for (i = 0; i < metrics.length; i += 1) {
            stats.push(metrics[i].value < 0 ? 0 : metrics[i].value);
        }
        me.getViewModel().set('stats', stats);


        var data = [], 
            time = Util.getMilliseconds();
        time = Math.round(time/1000) * 1000;

        for (i = -17; i <= -1; i += 1) {
            data.push({
                x: time + i * 10000,
                y: 0
            });
        }

        var graphValArr = metrics.filter(function (metric) {
            return metric.name === 'live-sessions';
        });

        if( graphValArr == false ){
            this.chart = null;
            return;
        }

        if (graphValArr && graphValArr[0]) {
            data.push({
                x: time,
                y: graphValArr[0].value < 0 ? 0 : graphValArr[0].value
            });
        }
        me.chart.series[0].setData(data);

    },

    // update metrics/graph when metrics changed
    onAddPoint: function () {
        var me = this, vm = me.getViewModel(),
            appInstanceMetrics = Ext.getStore('metrics').findRecord('appId', vm.get('instanceId'));

        if (!me.chart || !appInstanceMetrics) {
            return;
        }
        var metrics = appInstanceMetrics.get('metrics').list, stats = [];
        if (!metrics || metrics.length == 0) {
            return;
        }

        for (var i = 0; i < metrics.length; i += 1) {
            stats.push(metrics[i].value < 0 ? 0 : metrics[i].value);
        }
        vm.set('stats', stats);

        var graphValArr = metrics.filter(function (metric) {
            return metric.name === 'live-sessions';
        });

        if( graphValArr == false ){
            this.chart = null;
            return;
        }

        if (graphValArr && graphValArr[0]) {
            me.chart.series[0].addPoint({
                x: Date.now(),
                y: graphValArr[0].value < 0 ? 0 : graphValArr[0].value
            }, true, true);
        }

        // random for testing
        // newVal = Math.floor(Math.random() * 20) + 15;

    }
});
Ext.define('Ung.view.apps.RackItem', {
    extend: 'Ext.container.Container',
    alias: 'widget.rackitem',

    baseCls: 'rackitem',

    width: 785,
    height: 93,
    padding: '8 50',

    layout: { type: 'column' },

    disabled: true,
    hidden: true,
    bind: {
        hidden: '{!instanceId && !installing}',
        disabled: '{parentPolicy || installing}',
        userCls: '{parentPolicy ? "from-parent" : (installing ? "installing" : "")}',
    },

    items: [{
        xtype: 'container',
        width: 290,
        layout: { type: 'vbox', align: 'stretch' },
        items: [{
            xtype: 'container',
            layout: { type: 'hbox' },
            cls: 'ttl',
            items: [{
                xtype: 'component',
                bind: {
                    html: '<img src="/icons/apps/{app.name}.svg" width=42 height=42/>'
                }
            }, {
                xtype: 'container',
                layout: { type: 'vbox' },
                items: [{
                    xtype: 'component',
                    cls: 'name',
                    bind: {
                        html: '<p>{app.displayName}</p>'
                    }
                }, {
                    xtype: 'component',
                    cls: 'policy',
                    hidden: true,
                    bind: {
                        hidden: '{!parentPolicy}',
                        html: '<p><i class="fa fa-file-text-o"></i>&nbsp; {parentPolicy}</p>'
                    }
                }, {
                    xtype: 'component',
                    cls: 'license',
                    hidden: true,
                    bind: {
                        hidden: '{!licenseMessage}',
                        html: '<p><i class="fa fa-exclamation-triangle fa-orange"></i> {licenseMessage}</p>'
                    }
                }]
            }]
        }, {
            xtype: 'container',
            margin: '5 0',
            layout: { type: 'hbox' },
            items: [{
                xtype: 'button',
                iconCls: 'fa fa-wrench',
                text: 'Settings'.t(),
                hrefTarget: '_self',
                hidden: true,
                bind: {
                    href: '{route}',
                    hidden: '{parentPolicy || installing}'
                }
            }, {
                xtype: 'button',
                margin: '0 0 0 5',
                iconCls: 'fa fa-question-circle',
                hidden: true,
                bind: {
                    href: '{helpSource}',
                    hidden: '{parentPolicy || installing}',
                }
            }, {
                xtype: 'button',
                margin: '0 0 0 5',
                html: 'Buy Now'.t(),
                iconCls: 'fa fa-shopping-cart',
                hidden: true,
                bind: {
                    href: Util.getStoreUrl() + '?action=buy&libitem=untangle-libitem-{app.name}&' + Util.getAbout(),
                    hidden: '{!license || !license.trial || parentPolicy || installing }',
                }
            }]
        }]
    }, {
        xtype: 'container',
        layout: { type: 'hbox', align: 'stretch' },
        controller: 'rackgraph',
        width: 350,
        height: 75,
        margin: '0 10 0 0',
        items: [{
            xtype: 'component',
            itemId: 'rackgraph',
            cls: 'graph',
            width: 125,
            height: 75,
            bind: {
                userCls: '{state.on ? "on" : "off"}',
            }
        }, {
            xtype: 'container',
            itemId: 'metrics',
            flex: 1,
            margin: '0 0 0 10',
            cls: 'metrics',
            layout: { type: 'vbox', align: 'stretch' },
            defaults: {
                xtype: 'component'
            },
            bind: {
                userCls: '{state.on ? "on" : "off"}',
            }
        }]
    }, {
        xtype: 'button',
        width: 30,
        height: 30,
        baseCls: 'power',
        hideMode: 'visibility',
        disabled: true,
        hidden: true,
        bind: {
            userCls: '{powerCls}',
            disabled: '{parentPolicy}',
            hidden: '{!app.hasPowerButton }'
        },
        renderTpl: '<span id="{id}-btnWrap" data-ref="btnWrap" role="presentation" unselectable="on" style="{btnWrapStyle}" ' + 'class="{btnWrapCls} {btnWrapCls}-{ui} {splitCls}{childElCls}">' +
            '<span id="{id}-btnEl" data-ref="btnEl" role="presentation" unselectable="on" style="{btnElStyle}" ' + 'class="{btnCls} {btnCls}-{ui} {textCls} {noTextCls} {hasIconCls} ' + '{iconAlignCls} {textAlignCls} {btnElAutoHeightCls}{childElCls}">' +
            '<i class="fa fa-power-off"></i>' +
            '</span>' + '</span>',
        handler: 'powerHandler'
    }, {
        xtype: 'component',
        cls: 'loader',
        autoEl: { tag: 'span' },
        hidden: true,
        bind: {
            hidden: '{!installing}'
        }
    }]
});
Ext.define('Ung.view.apps.Simple', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.apps-simple',

    scrollable: 'y',

    border: false,
    bodyBorder: false,

    defaults: {
        border: false,
        bodyBorder: false
    },

    items: [{
        xtype: 'container',
        items: [{
            xtype: 'component',
            cls: 'apps-title',
            html: 'Apps'.t()
        }]
    }, {
        xtype: 'container',
        layout: {
            type: 'column'
        },
        itemId: '_apps'
    }, {
        xtype: 'container',
        items: [{
            xtype: 'component',
            cls: 'apps-title',
            html: 'Service Apps'.t()
        }]
    }, {
        xtype: 'container',
        layout: {
            type: 'column'
        },
        itemId: '_services'
    }]
});
Ext.define('Ung.view.apps.SimpleItem', {
    extend: 'Ext.container.Container',
    alias: 'widget.simpleitem',

    baseCls: 'simpleitem',

    width: 135,
    height: 135,

    viewModel: {
        formulas: {
            html: function (get) {
                var html = '';
                if (get('parentPolicy') || get('installing')) {
                    html += '<a class="app-item">';
                } else {
                    html += '<a href="' + get('route') + '" class="app-item">';
                }
                if (get('app.hasPowerButton')) {
                    html += '<span class="state ' + get('powerCls') + '"><i class="fa fa-power-off"></i></span>';
                }
                if (get('licenseMessage')) {
                    html += '<span class="license">' + get('licenseMessage') +  '</span>';
                }
                html += '<img src="' + '/icons/apps/' + get('app.name') + '.svg" width=80 height=80/>' +
                        '<span class="app-name">' + get('app.displayName') + '</span>';

                if (get('parentPolicy')) {
                    html += '<span class="parent-policy">[' + get('parentPolicy') + ']</span>';
                }
                html += '<span class="loader"></span>';
                html += '</a>';

                return html;
            }
        }
    },

    hidden: true,
    bind: {
        hidden: '{!instanceId && !installing}',
        disabled: '{parentPolicy || installing}',
        userCls: '{parentPolicy ? "from-parent" : (installing ? "installing" : "")}',
        html: '{html}'
    }
});
Ext.define('Ung.view.config.Config', {
    extend: 'Ext.panel.Panel',
    xtype: 'ung.config',
    itemId: 'config',

    controller: 'config',
    viewModel: true,
    scrollable: true,

    items: [{
        xtype: 'dataview',
        store: {data: [
            { name: 'Network'.t(), url: 'network', icon: 'network.svg' },
            { name: 'Administration'.t(), url: 'administration', icon: 'administration.svg' },
            { name: 'Events'.t(), url: 'events', icon: 'events.svg' },
            { name: 'Email'.t(), url: 'email', icon: 'email.svg' },
            { name: 'Local Directory'.t(), url: 'local-directory', icon: 'local-directory.svg' },
            { name: 'System'.t(), url: 'system', icon: 'system.svg' },
        ]},
        tpl: '<p class="apps-title">' + 'Configuration'.t() + '</p>' +
             '<tpl for=".">' +
                '<a href="#config/{url}" class="app-item" style="margin: 10px;">' +
                '<img src="' + '/icons/config/{icon}" width=80 height=80/>' +
                '<span class="app-name">{name}</span>' +
                '</a>' +
            '</tpl>',
        itemSelector: 'a'
    }]
});
Ext.define('Ung.view.config.ConfigController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.config',

    control: {
        '#': {
            deactivate: 'onDeactivate'
        },
        '#subNav': {
            selectionchange: 'onSelect'
        }
    },

    listen: {
        global: {
            loadconfig: 'onLoadConfig'
        }
    },

    onSelect: function (el, sel) {
        // console.log(selected);
        sel.selected = true;
    },


    onLoadConfig: function (configName, configTab) {
        var view = this.getView();
        if (!configName) {
            view.setActiveItem(1);
            return;
        }

        if (view.down('#configCard')) {
            view.down('#configCard').destroy();
        }

        var cfgName = configName.charAt(0).toUpperCase() + configName.slice(1).toLowerCase();

        console.log(cfgName);

        view.down('#subNav').getStore().each(function (item) {
            if (item.get('url') === configName) {
                item.set('selected', 'x-item-selected');
            } else {
                item.set('selected', '');
            }
        });


        view.setLoading('Loading ' + cfgName.t() + '...');
        console.log(cfgName);
        Ext.require('Ung.view.config.' + cfgName.toLowerCase() + '.' + cfgName, function () {
            view.down('#configWrapper').add({
                xtype: 'ung.config.' + cfgName.toLowerCase(),
                region: 'center',
                itemId: 'configCard'
            });
            view.setLoading(false);
            view.setActiveItem(2);
            console.log(configTab);
            if (configTab) {
                view.down('#configCard').setActiveItem(configTab);
            }
        });
    },

    onDeactivate: function (view) {
        // console.log('here');
        // if (view.down('#configCard')) {
        //     view.setActiveItem(0);
        //     view.down('#configCard').destroy();
        // }
        // view.remove('configCard');
    }


});
/**
 * Dashboard view which holds the widgets and manager
 */
Ext.define('Ung.view.dashboard.Dashboard', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.ung-dashboard',
    itemId: 'dashboardMain',

    controller: 'dashboard',
    viewModel: {
        data: {
            managerVisible: false
        }
    },

    config: {
        settings: null // the dashboard settings object / not used, need to check
    },

    layout: 'fit',

    dockedItems: [{
        xtype: 'dashboardmanager',
        dock: 'left',
        width: 250,
        hidden: true,
        bind: {
            hidden: '{!managerVisible}'
        }
    }],

    items: [{
        reference: 'dashboard',
        itemId: 'dashboard',
        bodyCls: 'dashboard',
        bodyPadding: 8,
        border: false,
        // bodyBorder: false,
        scrollable: true,
        dockedItems: [{
            xtype: 'toolbar',
            dock: 'top',
            ui: 'footer',
            height: 30,
            style: { background: '#D8D8D8' },
            items: [{
                text: 'Settings'.t(),
                iconCls: 'fa fa-cog',
                focusable: false,
                handler: 'toggleManager',
                hidden: true,
                bind: {
                    hidden: '{managerVisible}'
                }
            }, {
                xtype: 'globalconditions',
                context: 'DASHBOARD',
                hidden: true,
                bind: {
                    hidden: '{!reportsAppStatus.installed || !reportsAppStatus.enabled}'
                }
            }, {
                xtype: 'container',
                itemId: 'since',
                margin: '0 5',
                layout: {
                    type: 'hbox',
                    align: 'middle'
                },
                hidden: true,
                bind: {
                    hidden: '{!reportsAppStatus.installed || !reportsAppStatus.enabled}'
                },
                items: [{
                    xtype: 'component',
                    margin: '0 5 0 0',
                    style: {
                        fontSize: '11px'
                    },
                    html: '<strong>' + 'Since:'.t() + '</strong>'
                }, {
                    xtype: 'button',
                    iconCls: 'fa fa-clock-o',
                    focusable: false,
                    menu: {
                        plain: true,
                        showSeparator: false,
                        mouseLeaveDelay: 0,
                        items: [
                            { text: '1 Hour ago'.t(), value: 1 },
                            { text: '3 Hours ago'.t(), value: 3 },
                            { text: '6 Hours ago'.t(), value: 6 },
                            { text: '12 Hours ago'.t(), value: 12 },
                            { text: '24 Hours ago'.t(), value: 24 }
                        ],
                        listeners: {
                            click: 'updateSince'
                        }
                    }
                }],
            }, {
                xtype: 'component',
                style: { fontSize: '12px' },
                html: '<i class="fa fa-info-circle"></i> <strong>Reports App not installed!</strong> Report based widgets are not available.',
                hidden: true,
                bind: {
                    hidden: '{reportsAppStatus.installed}'
                }
            }, {
                xtype: 'component',
                style: { fontSize: '12px' },
                html: '<i class="fa fa-info-circle"></i> <strong>Reports App is disabled!</strong> Report based widgets are not available.',
                hidden: true,
                bind: {
                    hidden: '{!reportsAppStatus.installed || reportsAppStatus.enabled}'
                }
            }]
        }]
    }],
    listeners: {
        showwidgeteditor: 'showWidgetEditor'
    }
});
/**
 * Dashboard Controller which displays and manages the Dashboard Widgets
 * Widgets can be affected by following actions:
 * - remove/add/modify widget entry itself;
 * - install/uninstall Reports or start/stop Reports service
 * - install/uninstall Apps which can lead in a report widget to be available or not;
 * - modifying a report that is used by a widget, which requires reload of that affected widget
 */
Ext.define('Ung.view.dashboard.DashboardController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.dashboard',
    viewModel: true,
    control: {
        '#': {
            afterrender: 'onAfterRender',
            activate: 'onActivate',
            deactivate: 'onDeactivate',
        },
        '#dashboard': {
            resize: 'onResize'
        }
    },

    widgetsRendered: false,

    listen: {
        store: {
            '#stats': {
                datachanged: 'onStatsUpdate'
            }
        }
    },

    onAfterRender: function () {
        var me = this, vm = me.getViewModel(),
            dashboardCmp = me.getView().down('#dashboard'),
            text;


        // add scroll/resize events which will triger widgets update
        dashboardCmp.body.on('scroll', me.debounce(me.updateVisibleWidgets, 300));
        dashboardCmp.getEl().on('resize', me.debounce(me.updateVisibleWidgets, 300));

        /**
         * Fetch dashboard settings
         */
        Rpc.asyncData('rpc.dashboardManager.getSettings')
            .then(function (result) {
                // initially the timeframe could be null
                if (!result.timeframe) {
                    result.timeframe = 1;
                }
                Ung.dashboardSettings = result;
                Ext.getStore('widgets').loadData(result.widgets.list);

                if (result.timeframe === 1) {
                    text = '1 Hour ago'.t();
                } else {
                    text = result.timeframe + ' ' + 'Hours ago'.t();
                }

                me.getView().down('#since > button').setText(text);

                Ung.app.reportscheck();
            });

        /**
         * On global conditions change refetch data based on new conditions
         * Using {query.string} because it fires only when the value changes, unlike {query} only
         */
        vm.bind('{query.string}', function () {
            Ext.defer(function() {
                me.updateVisibleWidgets();
            }, 1000);
        });

    },

    /**
     * Helper method used to slowfire resize or scroll events
     */
    debounce: function (fn, delay) {
        var timer = null;
        var me = this;
        return function () {
            clearTimeout(timer);
            timer = setTimeout(function () {
                fn.apply(me, arguments);
            }, delay);
        };
    },

    /**
     * Checks if widget is visible or not in viewport
     * Based on it's visibility it will be added to queue for fetching data
     */
    updateVisibleWidgets: function () {
        var dashboard = this.lookup('dashboard'),
            widgets = dashboard.query('reportwidget'),
            graphReport;
        DashboardQueue.isVisible(dashboard.down('networklayoutwidget'));
        DashboardQueue.isVisible(dashboard.down('mapdistributionwidget'));
        DashboardQueue.isVisible(dashboard.down('networkinformationwidget'));
        DashboardQueue.isVisible(dashboard.down('policyoverviewwidget'));
        DashboardQueue.isVisible(dashboard.down('notificationswidget'));
        Ext.Array.each(widgets, function (widget) {
            if (widget) {
                graphReport = widget.down('graphreport');
                // important to reflow the chart when widget changes size
                if (graphReport && graphReport.getController().chart) {
                    graphReport.getController().chart.reflow();
                }
                DashboardQueue.isVisible(widget);
            }
        });
    },

    updateSince: function (menu, item) {
        var me = this, dashboard = me.lookup('dashboard');
        menu.up('button').setText(item.text);
        Ung.dashboardSettings.timeframe = item.value;

        Rpc.asyncData('rpc.dashboardManager.setSettings', Ung.dashboardSettings)
            .then(function() {
                Ext.Array.each(dashboard.query('reportwidget'), function (widgetCmp) {
                    widgetCmp.lastFetchTime = null;
                });
                me.updateVisibleWidgets();
            });

    },


    onResize: function (view) {
        if (view.down('window')) {
            view.down('window').close();
        }
    },

    toggleManager: function () {
        var me = this, vm = me.getViewModel(),
            columns = me.lookup('dashboardManager').getColumns();

        vm.set('managerVisible', !vm.get('managerVisible'));
        if (!vm.get('managerVisible')) {
            columns[0].setHidden(true);
        }
    },

    onStatsUpdate: function() {
        var vm = this.getViewModel();
        vm.set('stats', Ext.getStore('stats').first());

        Rpc.asyncData('rpc.deviceTable.getDevicesSettings')
            .then( function(result){
                if(Util.isDestroyed(vm)){
                    return;
                }
                if (result && result.devices)
                    vm.set('deviceCount', result.devices.list.length);
            },function(ex){
                Util.handleException(ex);
            });
    },

    onActivate: function () {
        DashboardQueue.paused = false;
        this.updateVisibleWidgets();
    },

    onDeactivate: function () {
        DashboardQueue.paused = true;
        var vm = this.getViewModel();
        if (vm.get('managerVisible')) {
            this.toggleManager();
        }
    }

});
Ext.define('Ung.view.dashboard.Manager', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.dashboardmanager',
    controller: 'dashboardmanager',

    itemId: 'dashboardManager',
    reference: 'dashboardManager',

    bodyBorder: false,
    animCollapse: false,
    floatable: false,
    cls: 'widget-manager',
    // disableSelection: true, // if disabled the drag/drop ordering does not work
    split: true,
    hideHeaders: true,
    rowLines: false,
    store: 'widgets',
    border: false,
    viewConfig: {
        plugins: {
            ptype: 'gridviewdragdrop',
            dragText: 'Drag and drop to reorganize'.t(),
            dragZone: {
                onBeforeDrag: function (data, e) {
                    return Ext.get(e.target).hasCls('fa-align-justify');
                }
            }
        },
        stripeRows: false,
        getRowClass: function (record) {
            var cls = !record.get('enabled') ? 'disabled' : '';
            cls += record.get('markedForDelete') ? ' will-remove' : '';
            return cls;
        },
        listeners: {
            drop: 'onDrop'
        }
    },
    columns: [{
        width: 28,
        align: 'center',
        hidden: true,
        renderer: function (val, meta) {
            meta.tdCls = 'reorder';
            return '<i class="fa fa-align-justify"></i>';
        }
    }, {
        width: 20,
        align: 'center',
        sortable: false,
        hideable: false,
        resizable: false,
        menuDisabled: true,
        //handler: 'toggleWidgetEnabled',
        dataIndex: 'enabled',
        renderer: 'enableRenderer'
    }, {
        dataIndex: 'entryId',
        renderer: 'widgetTitleRenderer',
        flex: 1
    }, {
        xtype: 'widgetcolumn',
        width: 30,
        align: 'center',
        widget: {
            xtype: 'button',
            width: 24,
            enableToggle: true,
            iconCls: 'fa fa-trash fa-gray',
            focusable: false,
            bind: {
                iconCls: 'fa fa-trash {record.markedForDelete ? "fa-red" : "fa-gray"}',
            },
            handler: function (btn) {
                btn.lookupViewModel().get('record').set('markedForDelete', btn.pressed);
            }
        }
    }],
    listeners: {
        itemmouseleave : 'onItemLeave',
        cellclick: 'onItemClick'
    },
    fbar: ['->', {
        text: 'Cancel'.t(),
        iconCls: 'fa fa-ban',
        handler: 'onCancel'
    }, {
        text: 'Apply'.t(),
        iconCls: 'fa fa-floppy-o',
        handler: 'applyChanges'
    }],

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        ui: 'footer',
        style: { background: '#D8D8D8' },
        items: [{
            iconCls: 'fa fa-cog',
            focusable: false,
            text: 'Widgets'.t(),
            menu: {
                plain: true,
                showSeparator: false,
                mouseLeaveDelay: 0,
                items: [
                    { text: 'Import'.t(), iconCls: 'fa fa-download', handler: 'importWidgets' },
                    { text: 'Export'.t(), iconCls: 'fa fa-upload', handler: 'exportWidgets' },
                    '-',
                    {
                        text: 'Add Common Widgets'.t(),
                        iconCls: 'fa fa-plus-circle',
                        menu: {
                            plain: true,
                            showSeparator: false,
                            mouseLeaveDelay: 0,
                            items: [
                                { text: 'Information'.t(), value: 'informationwidget' },
                                { text: 'Resources'.t(), value: 'resourceswidget' },
                                { text: 'CPU Load'.t(), value: 'cpuloadwidget' },
                                { text: 'Network Information'.t(), value: 'networkinformationwidget' },
                                { text: 'Network Layout'.t(), value: 'networklayoutwidget' },
                                { text: 'Map Distribution'.t(), value: 'mapdistributionwidget' },
                                { text: 'Policy Overview'.t(), value: 'policyoverviewwidget' },
                                { text: 'Notifications'.t(), value: 'notificationswidget' }
                            ],
                            listeners: {
                                click: function (menu, item) {
                                    Ext.getStore('widgets').add(Ext.create('Ung.model.Widget', {
                                        type: item.text.replace(' ', '')
                                    }));
                                }
                            }
                        }
                    },
                    // { text: 'Add Report Widget'.t(), iconCls: 'fa fa-plus-circle', itemId: 'reportsMenu' },
                    { text: 'Create New Report Widget'.t(), iconCls: 'fa fa-area-chart', handler: 'newReportWidget' },
                    '-',
                    { text: 'Reorder'.t(), iconCls: 'fa fa-sort', handler: 'showOrderingColumn' },
                    '-',
                    { text: 'Reset to Defaults'.t(), iconCls: 'fa fa-rotate-left', handler: 'resetDashboard' }
                ]
                // listeners: {
                //     beforeshow: 'populateReportsMenu'
                // }
            }
        }, '->', {
            iconCls: 'fa fa-times',
            focusable: false,
            handler: 'onCancel'
        }]
    }],

});
Ext.define('Ung.view.dashboard.ManagerController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.dashboardmanager',
    // viewModel: true,

    control: {
        '#': {
            afterrender: 'onAfterRender',
            show: function (grid) {
                // refresh the grid to update renderers
                grid.getView().refresh();
            }
        }
    },

    listen: {
        global: {
            // events fired by widget store
            addwidgets: 'onAddWidgets',
            removewidgets: 'onRemoveWidgets',
            updatewidget: 'onUpdateWidget',
            appinstall: 'onAppInstall',
            appremove: 'onAppRemove'
        }
    },

    onAfterRender: function (view) {
        var me = this;
        // the dasboard widgets holder
        me.dashboard = view.up('#dashboardMain').lookup('dashboard');

        /**
         * (re)load widgets when Reports App installed/removed or enabled/disabled
         */
        me.getViewModel().bind('{reportsAppStatus}', function () {
            me.loadWidgets();
        });
    },

    /**
     * Render widgets into the dashboard
     */
    loadWidgets: function() {
        var me = this, vm = me.getViewModel(),
            widgetsCmps = [], entry;

        // refresh the dashboard manager grid if the widgets were affected
        // me.lookup('dashboardManager').getView().refresh();
        me.dashboard.removeAll(true);

        Ext.getStore('widgets').each(function (record) {
            if (!record.get('enabled')) {
                widgetsCmps.push({
                    xtype: 'component',
                    itemId: record.get('itemId'),
                    hidden: true
                });
                return;
            }

            if (record.get('type') !== 'ReportEntry') {
                widgetsCmps.push({
                    xtype: record.get('type').toLowerCase() + 'widget',
                    itemId: record.get('itemId'),
                    lastFetchTime: null,
                    visible: true,
                    viewModel: {
                        data: {
                            widget: record
                        }
                    }
                });
                return;
            }

            if (vm.get('reportsAppStatus.installed') && vm.get('reportsAppStatus.enabled')) {
                entry = Ext.getStore('reports').findRecord('uniqueId', record.get('entryId'));
                if (entry && Ext.getStore('categories').findRecord('displayName', entry.get('category'))) {
                    widgetsCmps.push({
                        xtype: 'reportwidget',
                        itemId: record.get('itemId'),
                        lastFetchTime: null,
                        visible: true,
                        viewModel: {
                            data: {
                                widget: record,
                                entry: entry
                            }
                        }
                    });
                } else {
                    // report widget is enabled but App not installed
                    widgetsCmps.push({
                        xtype: 'component',
                        itemId: record.get('itemId'),
                        hidden: true
                    });
                }
            }

        });
        me.getView().getView().refresh(); // refres the grid view
        me.dashboard.add(widgetsCmps);
    },

    // listens on widgets store add event and adds widget component to dashboard
    onAddWidgets: function (store, records) {
        var me = this, entry;

        Ext.Array.each(records, function (record) {
            if (record.get('type') !== 'ReportEntry') {
                me.dashboard.add({
                    xtype: record.get('type').toLowerCase() + 'widget',
                    itemId: record.get('itemId'),
                    lastFetchTime: null,
                    visible: true,
                    viewModel: {
                        data: {
                            widget: record
                        }
                    }
                });
            } else {
                entry = Ext.getStore('reports').findRecord('uniqueId', record.get('entryId'));
                me.dashboard.add({
                    xtype: 'reportwidget',
                    itemId: record.get('itemId'),
                    visible: true,
                    lastFetchTime: null,
                    viewModel: {
                        data: {
                            widget: record,
                            entry: entry
                        }
                    }
                });
            }
        });
        me.applyChanges();
    },

    onRemoveWidgets: function (store, records) {
        var me = this, widgetCmp;
        Ext.Array.each(records, function (rec) {
            widgetCmp = me.dashboard.down('#' + rec.get('itemId'));
            if (widgetCmp) { widgetCmp.destroy(); }
        });
        me.applyChanges();
    },


    onUpdateWidget: function (store, record) {
        var me = this, vm = me.getViewModel(), entry,
            enabled = record.get('enabled'),
            widgetCmp = me.dashboard.down('#' + record.get('itemId')),
            index = store.indexOf(record);

        if (widgetCmp) { widgetCmp.destroy(); }

        if (enabled) {
            if (record.get('type') !== 'ReportEntry') {
                widgetCmp = me.dashboard.insert(index, {
                    xtype: record.get('type').toLowerCase() + 'widget',
                    itemId: record.get('itemId'),
                    visible: true,
                    lastFetchTime: null,
                    viewModel: {
                        data: {
                            widget: record
                        }
                    }
                });
            } else {
                if (!vm.get('reportsAppStatus.installed')) {
                    Ext.Msg.alert('Info'.t(), 'To enable App Widgets please install Reports first!'.t());
                    return;
                }
                if (!vm.get('reportsAppStatus.enabled')) {
                    Ext.Msg.alert('Info'.t(), 'To view App Widgets enable the Reports App first!'.t());
                    return;
                }

                entry = Ext.getStore('reports').findRecord('uniqueId', record.get('entryId'));

                if (entry) {
                    if (Ext.getStore('categories').findRecord('displayName', entry.get('category'))) {
                        widgetCmp = me.dashboard.insert(index, {
                            xtype: 'reportwidget',
                            itemId: record.get('itemId'),
                            visible: true,
                            lastFetchTime: null,
                            viewModel: {
                                data: {
                                    widget: record,
                                    entry: entry
                                }
                            }
                        });
                        // setTimeout(function () {
                        //     me.dashboard.scrollTo(0, me.dashboard.getEl().getScrollTop() + widgetCmp.getEl().getY() - 121, {duration: 300 });
                        // }, 100);
                    } else {
                        Ext.Msg.alert('Install required'.t(), Ext.String.format('To enable this Widget please install <strong>{0}</strong> app first!'.t(), entry.get('category')));
                    }
                } else {
                    Util.handleException('This entry is not available and it should be removed!');
                }

            }
            if (widgetCmp) {
                setTimeout(function () {
                    me.dashboard.scrollTo(0, me.dashboard.getEl().getScrollTop() + widgetCmp.getEl().getY() - 101, {duration: 300 });
                }, 100);
            }
        } else {
            me.dashboard.insert(index, {
                xtype: 'component',
                itemId: record.get('itemId'),
                hidden: true
            });
        }
    },

    newReportWidget: function () {
        this.showWidgetEditor(null, null);
    },

    showWidgetEditor: function (widget, entry) {
        var me = this;
        me.addWin = me.getView().add({
            xtype: 'new-widget',
            viewModel: {
                data: {
                    widget: widget,
                    entry: entry
                }
            }
        });
        me.addWin.show();
    },

    /**
     * Method which sends modified dashboard settings to backend to be saved
     */
    applyChanges: function (btn) {
        var me = this, removable = Ext.getStore('widgets').queryRecords('markedForDelete', true);
        Ext.getStore('widgets').remove(removable);

        // because of the drag/drop reorder the settings widgets are updated to respect new ordering
        Ung.dashboardSettings.widgets.list = Ext.Array.pluck(Ext.getStore('widgets').getRange(), 'data');

        Rpc.asyncData('rpc.dashboardManager.setSettings', Ung.dashboardSettings)
            .then(function() {
                if (btn) { // show saved toast only when Apply button is used
                    Util.successToast('<span style="color: yellow; font-weight: 600;">Dashboard Saved!</span>');
                }
                Ext.getStore('widgets').sync();
                // me.toggleManager();

                me.dashboard.items.each(function (widgetCmp) {
                    if (Ext.getStore('widgets').find('itemId', widgetCmp.getItemId()) < 0) {
                        me.dashboard.remove(widgetCmp);
                    }
                });
            });

    },

    onCancel: function () {
        var me = this, vm = me.getViewModel(),
            columns = me.getView().getColumns();

        vm.set('managerVisible', false);
        columns[0].setHidden(true);
    },

    showOrderingColumn: function () {
        var me = this, columns = me.getView().getColumns();
        columns[0].setHidden(false);
    },

    /**
     * todo: after drag sort event
     */
    onDrop: function (app, data, overModel, dropPosition) {
        var me = this,
            widgetMoved = me.dashboard.down('#' + data.records[0].get('itemId')),
            widgetDropped = me.dashboard.down('#' + overModel.get('itemId'));

        /*
        widgetMoved.addCls('moved');

        window.setTimeout(function () {
            widgetMoved.removeCls('moved');
        }, 300);
        */

        if (dropPosition === 'before') {
            me.dashboard.moveBefore(widgetMoved, widgetDropped);
        } else {
            me.dashboard.moveAfter(widgetMoved, widgetDropped);
        }
    },

    onItemClick: function (table, td, cellIndex, record, tr, rowIndex, e) {
        var me = this, widgetCmp, entry;

        if (cellIndex === 1) {
            if (Ext.Array.contains(e.target.classList, 'fa-info-circle')) {
                entry = Ext.getStore('reports').findRecord('uniqueId', record.get('entryId'));
                if (entry) {
                    Ext.Msg.alert('Install required'.t(), Ext.String.format('To enable this Widget please install <strong>{0}</strong> app first!'.t(), entry.get('category')));
                } else {
                    Util.handleException('This entry is not available and it should be removed!');
                }
                return;
            }
            // toggle visibility or show alerts
            record.set('enabled', !record.get('enabled'));
        }

        if (cellIndex === 2) {
            // highlights in the dashboard the widget which receives click event in the manager grid
            widgetCmp = me.dashboard.down('#' + record.get('itemId'));
            if (widgetCmp && !widgetCmp.isHidden()) {
                me.dashboard.addBodyCls('highlight');
                widgetCmp.addCls('highlight-item');
                me.dashboard.scrollTo(0, me.dashboard.body.getScrollTop() + widgetCmp.getEl().getY() - 101, {duration: 100});
            }
        }
    },

    /**
     * removes the above set highlight
     */
    onItemLeave: function (view, record) {
        var me = this, widgetCmp;
        if (this.tout) {
            window.clearTimeout(this.tout);
        }
        widgetCmp = me.dashboard.down('#' + record.get('itemId'));
        if (widgetCmp) {
            me.dashboard.removeBodyCls('highlight');
            widgetCmp.removeCls('highlight-item');
        }
    },

    resetDashboard: function () {
        var me = this, vm = me.getViewModel();
        Ext.MessageBox.confirm('Warning'.t(),
            'This will overwrite the current dashboard settings with the defaults.'.t() + '<br/><br/>' +
            'Do you want to continue?'.t(),
            function (btn) {
                if (btn === 'yes') {
                    Rpc.asyncData('rpc.dashboardManager.resetSettingsToDefault').then(function () {
                        Rpc.asyncData('rpc.dashboardManager.getSettings')
                            .then(function (result) {
                                Ung.dashboardSettings = result;
                                Ext.getStore('widgets').loadData(result.widgets.list);
                                me.loadWidgets();
                                Util.successToast('Dashboard reset done!');
                                vm.set('managerVisible', false);
                            });
                    });
                }
            });
    },

    // renderers
    enableRenderer: function (value, meta, record) {
        meta.tdCls = 'enable';
        if (record.get('type') !== 'ReportEntry') {
            return '<i class="fa ' + (value ? 'fa-check-circle-o' : 'fa-circle-o') + ' fa-lg"></i>';
        }
        var entry = Ext.getStore('reports').findRecord('uniqueId', record.get('entryId'));
        if (!entry || !Ext.getStore('categories').findRecord('displayName', entry.get('category'))) {
            return '<i class="fa fa-info-circle fa-lg"></i>';
        }
        return '<i class="fa ' + (value ? 'fa-check-circle-o' : 'fa-circle-o') + ' fa-lg"></i>';
    },

    /**
     * renders the title of the widget in the dashboard manager grid, based on various conditions
     */
    widgetTitleRenderer: function (value, metaData, record) {
        var me = this, vm = me.getViewModel(), entry, title, unavailApp, enabled;
        enabled = record.get('enabled');

        if (!value) {
            return '<span style="' + (!enabled ? 'font-weight: 400; color: #777;' : 'font-weight: 600; color: #000;') + '">' + record.get('type') + '</span>'; // <br/><span style="font-size: 10px; color: #777;">Common</span>';
        }
        if (vm.get('reportsAppStatus.installed')) {
            entry = Ext.getStore('reports').findRecord('uniqueId', value);
            if (entry) {
                unavailApp = Ext.getStore('categories').findRecord('displayName', entry.get('category')) ? false : true;
                title = '<span style="' + ((unavailApp || !enabled) ? 'font-weight: 400; color: #777;' : 'font-weight: 600; color: #000;') + '">' + (entry.get('readOnly') ? entry.get('title').t() : entry.get('title')) + '</span>';
                return title;
            } else {
                return 'Unknown Widget'.t();
            }
        } else {
            return '<span style="color: #999;">' + 'App Widget'.t() + '</span>';
        }
    },

    importWidgets: function () {
        var me = this;
        me.importDialog = me.getView().add({
            xtype: 'window',
            title: 'Import Widgets'.t(),
            renderTo: Ext.getBody(),
            modal: true,
            layout: 'fit',
            width: 450,
            items: [{
                xtype: 'form',
                border: false,
                url: 'gridSettings',
                bodyPadding: 10,
                layout: 'anchor',
                items: [{
                    xtype: 'radiogroup',
                    name: 'importMode',
                    simpleValue: true,
                    value: 'replace',
                    columns: 1,
                    vertical: true,
                    items: [
                        { boxLabel: '<strong>' + 'Replace current widgets'.t() + '</strong>', inputValue: 'replace' },
                        { boxLabel: '<strong>' + 'Prepend to current widgets'.t() + '</strong>', inputValue: 'prepend' },
                        { boxLabel: '<strong>' + 'Append to current widgets'.t() + '</strong>', inputValue: 'append' }
                    ]
                }, {
                    xtype: 'component',
                    margin: 10,
                    html: 'with widgets from'.t()
                }, {
                    xtype: 'filefield',
                    anchor: '100%',
                    fieldLabel: 'File'.t(),
                    labelAlign: 'right',
                    allowBlank: false,
                    validateOnBlur: false
                }, {
                    xtype: 'hidden',
                    name: 'type',
                    value: 'import'
                }],
                buttons: [{
                    text: 'Cancel'.t(),
                    iconCls: 'fa fa-ban fa-red',
                    handler: function () {
                        me.importDialog.close();
                    }
                }, {
                    text: 'Import'.t(),
                    iconCls: 'fa fa-check',
                    formBind: true,
                    handler: function (btn) {
                        btn.up('form').submit({
                            waitMsg: 'Please wait while the widgets are imported...'.t(),
                            success: function(form, action) {
                                if (!action.result) {
                                    Ext.MessageBox.alert('Warning'.t(), 'Import failed.'.t());
                                    return;
                                }
                                if (!action.result.success) {
                                    Ext.MessageBox.alert('Warning'.t(), action.result.msg);
                                    return;
                                }
                                me.importHandler(form.getValues().importMode, action.result.msg);
                                me.importDialog.close();
                            },
                            failure: function(form, action) {
                                Ext.MessageBox.alert('Warning'.t(), action.result.msg);
                            }
                        });
                    }
                }]
            }],
        });
        this.importDialog.show();
    },

    importHandler: function (importMode, newData) {
        var me = this, existingData = Ext.Array.pluck(Ext.getStore('widgets').getRange(), 'data');

        Ext.Array.forEach(existingData, function (rec) {
            delete rec._id;
        });

        if (importMode === 'replace') {
            Ext.getStore('widgets').removeAll();
        }
        if (importMode === 'append') {
            Ext.Array.insert(existingData, existingData.length, newData);
            newData = existingData;
        }
        if (importMode === 'prepend') {
            Ext.Array.insert(existingData, 0, newData);
            newData = existingData;
        }

        Ext.getStore('widgets').loadData(newData);
        me.loadWidgets();
    },

    exportWidgets: function () {
        var widgetsArr = [], w;
        Ext.getStore('widgets').each(function (widget) {
            w = widget.getData();
            delete w._id;
            widgetsArr.push(w);
        });

        Ext.MessageBox.wait('Exporting Widgets...'.t(), 'Please wait'.t());
        var exportForm = document.getElementById('exportGridSettings');
        exportForm.gridName.value = 'Widgets'.t(); // used in exported file name
        exportForm.gridData.value = Ext.encode(widgetsArr);
        exportForm.submit();
        Ext.MessageBox.hide();
    },

    populateReportsMenu: function (menu) {
        var menuItem = menu.down('#reportsMenu'),
            root = Ext.getStore('reportstree').getRoot(), items = [], subItems = [];

        root.eachChild(function (catNode) {
            subItems = [];
            catNode.eachChild(function (repNode) { // report node
                subItems.push({
                    text: repNode.get('text')
                });
            });
            items.push({
                text: catNode.get('text'),
                menu: {
                    plain: true,
                    showSeparator: false,
                    mouseLeaveDelay: 0,
                    items: subItems
                }
            });
        });
        menuItem.setMenu({
            plain: true,
            showSeparator: false,
            mouseLeaveDelay: 0,
            items: items
        });
    },


    /**
     * when a app is installed or removed apply changes to dashboard
     */
    onAppInstall: function (displayName) {
        var me = this, entry, index, wg;
        // refresh dashboard manager grid

        Ext.getStore('widgets').each(function (record) {
            index = Ext.getStore('widgets').indexOf(record);
            entry = Ext.getStore('reports').findRecord('uniqueId', record.get('entryId'));
            if (entry && entry.get('category') === displayName) {
                // remove widget placeholder
                me.dashboard.remove(record.get('itemId'));

                wg = me.dashboard.insert(index, {
                    xtype: 'reportwidget',
                    itemId: record.get('itemId'),
                    lastFetchTime: null,
                    visible: true,
                    viewModel: {
                        data: {
                            widget: record,
                            entry: entry,
                        }
                    }
                });
                Ext.defer(function () {
                    DashboardQueue.addFirst(wg);
                }, 500);
            }
        });
    },

    onAppRemove: function (displayName) {
        var me = this, entry, index;
        Ext.getStore('widgets').each(function (record) {
            index = Ext.getStore('widgets').indexOf(record);
            entry = Ext.getStore('reports').findRecord('uniqueId', record.get('entryId'));
            if (entry && entry.get('category') === displayName) {
                // remove widget placeholder
                me.dashboard.remove(record.get('itemId'));
                me.dashboard.insert(index, {
                    xtype: 'component',
                    itemId: record.get('itemId'),
                    hidden: true
                });
            }
        });
    }
});
Ext.define('Ung.view.dashboard.NewWidget', {
    extend: 'Ext.window.Window',
    alias: 'widget.new-widget',

    title: 'Add/Edit Widgets',
    controller: 'new-widget',

    modal: true,
    width: 800,
    height: 500,
    layout: 'border',

    renderTo: Ext.getBody(),

    viewModel: {
        data: {
            widget: null,
            entry: null,
            onDashboard: false,
        },
        formulas: {
            _autorefresh: {
                get: function(get) {
                    var interval = get('widget.refreshIntervalSec');
                    return interval ? true : false;
                },
                set: function (value) {
                    this.set('widget.refreshIntervalSec', value ? 60 : '');
                }
            },
            _timeframe: {
                get: function(get) {
                    return get('widget.timeframe') ? get('widget.timeframe') / 3600 : '';
                },
                set: function (value) {
                    this.set('widget.timeframe', value ? value * 3600 : null);
                }
            },
            _timeframeck: {
                get: function(get) {
                    return get('_timeframe') === '';
                },
                set: function (value) {
                    this.set('_timeframe', value ? '' : 1);
                }
            },
            _columnsck: {
                get: function(get) {
                    return get('widget.displayColumns') ? false : true;
                },
                set: function (value) {
                    if (value) {
                        this.set('widget.displayColumns', null);
                    } else {
                        this.set('widget.displayColumns', this.get('entry.defaultColumns'));
                    }
                }
            }
        }
    },

    items: [{
        xtype: 'treepanel',
        reference: 'tree',
        region: 'west',
        weight: 20,
        width: 250,
        minWidth: 250,
        split: true,
        useArrows: true,
        rootVisible: false,

        viewConfig: {
            selectionModel: {
                type: 'treemodel'
            }
        },
        store: 'reportstree',
        columns: [{
            xtype: 'treecolumn',
            flex: 1,
            dataIndex: 'text',
            renderer: 'treeNavNodeRenderer'
        }],

        tbar: [{
            xtype: 'textfield',
            emptyText: 'Filter reports ...',
            flex: 1,
            triggers: {
                clear: {
                    cls: 'x-form-clear-trigger',
                    hidden: true,
                }
            },
            listeners: {
                change: 'filterTree',
                buffer: 300
            }
        }],
        listeners: {
            select: 'selectNode'
        }
    }, {
        region: 'center',
        reference: 'report',
        layout: 'fit',
        items: [{
            xtype: 'container',
            layout: 'center',
            bind: {
                hidden: '{entry}'
            },
            items: [{
                xtype: 'component',
                width: '100%',
                style: {
                    textAlign: 'center',
                    color: '#777'
                },
                html: '<i class="fa fa-info-circle fa-lg"></i> <br/>' + 'Select a report first ...'
            }]
        }]
    }, {
        region: 'south',
        // title: 'Settings'.t(),
        height: 'auto',

        // split: true,
        // maxHeight: 140,
        // minHeight: 140,
        // layout: 'fit',

        dockedItems: [{
            xtype: 'component',
            dock: 'top',
            ui: 'footer',
            margin: '10 0',
            style: {
                textAlign: 'center',
                fontSize: '11px',
                color: '#333'
            },
            hidden: true,
            bind: {
                hidden: '{!(entry && onDashboard)}',
                html: '<i class="fa fa-info-circle fa-lg"></i> ' + 'This report widget already exists in Dashboard</strong>!',
            }
        }],

        items: [{
            // xtype: 'form',
            border: false,
            bodyPadding: 10,
            layout: {
                type: 'vbox'
                // align: 'stretch'
            },
            hidden: true,
            bind: {
                hidden: '{!entry}'
            },

            items: [{
                xtype: 'checkbox',
                boxLabel: '<strong>' + 'Enabled'.t() + '</strong>',
                bind: '{widget.enabled}'
            }, {
                xtype: 'combo',
                fieldLabel: '<strong>' + 'Auto Refresh'.t() + '</strong>',
                allowBlank: false,
                margin: '0 5',
                store: [
                    [10, '10 ' + 'seconds'.t()],
                    [30, '30 ' + 'seconds'.t()],
                    [60, '1 ' + 'minute'.t()],
                    [120, '2 ' + 'minutes'.t()],
                    [300, '5 ' + 'minutes'.t()],
                    [0, 'never'.t()]
                ],
                editable: false,
                queryMode: 'local',
                bind: '{widget.refreshIntervalSec}'
            }, {
                xtype: 'checkbox',
                reference: 'columnsck',
                fieldLabel: '<strong>' + 'Columns'.t() + '</strong>',
                labelWidth: 'auto',
                boxLabel: 'report defaults',
                hidden: true,
                // publishes: 'value',
                bind: {
                    value: '{_columnsck}',
                    hidden: '{entry.type !== "EVENT_LIST"}'
                }
            }, {
                xtype: 'tagfield',
                hidden: true,
                width: '100%',
                store: {
                    fields: ['name', 'text']
                },
                displayField: 'text',
                valueField: 'name',
                bind: {
                    value: '{widget.displayColumns}',
                    hidden: '{_columnsck}'
                },
                queryMode: 'local',
                // listeners: {
                //     change: 'updateColumns'
                // }
            }]
        }],

        buttons: [{
            text: 'Cancel'.t(),
            iconCls: 'fa fa-ban',
            handler: function (btn) {
                btn.up('window').close();
            }
        }, {
            text: 'Add'.t(),
            iconCls: 'fa fa-plus-circle',
            hidden: true,
            bind: { hidden: '{!entry}' },
            handler: 'onAdd'
        }]
    }]
});
Ext.define('Ung.view.dashboard.NewWidgetController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.new-widget',

    control: {
        '#': { afterrender: 'onAfterRender', beforeclose: 'onClose' }
    },

    onAfterRender: function () {
        var me = this, vm = this.getViewModel();
        if (vm.get('entry')) {
            me.lookup('tree').selectPath('/reports/' + vm.get('entry.url'), 'slug', '/', me.selectNode, me);
            // me.lookup('tree').hide();
        } else {
            // me.lookup('tree').show();
        }
        vm.bind('{widget.displayColumns}', function (val) {
            if (me.getView().down('grid')) {
                var columns = me.getView().down('grid').getColumns();
                if (val) {
                    Ext.Array.each(columns, function (col) {
                        col.setHidden(Ext.Array.indexOf(val, col.dataIndex) < 0);
                    });
                } else {
                    Ext.Array.each(columns, function (col) {
                        col.setHidden(Ext.Array.indexOf(vm.get('entry.defaultColumns'), col.dataIndex) < 0);
                    });
                }
            }
        });
    },

    /**
     * the tree item renderer used after filtering tree
     */
    treeNavNodeRenderer: function(value, meta, record) {
        // if (!record.get('readOnly') && record.get('uniqueId')) {
        //     meta.tdCls = 'x-tree-custom-report';
        // }
        return this.rendererRegExp ? value.replace(this.rendererRegExp, '<span style="font-weight: bold; background: #EEE; color: #000; border-bottom: 1px #000 solid;">$1</span>') : value;
    },

    /**
     * filters reports tree
     */
    filterTree: function (field, value) {
        if (value.length === 1) { return; }


        var me = this, tree = me.lookup('tree');
        me.rendererRegExp = new RegExp('(' + value + ')', 'gi');

        if (!value) {
            tree.getStore().clearFilter();
            tree.collapseAll();
            field.getTrigger('clear').hide();
            return;
        }

        tree.getStore().getFilters().replaceAll({
            property: 'text',
            value: new RegExp(Ext.String.escape(value), 'i')
        });
        tree.expandAll();
        field.getTrigger('clear').show();
    },

    onTreeFilterClear: function () {
        this.lookup('tree').down('textfield').setValue();
    },

    selectNode: function (selModel, node) {
        var me = this, vm = this.getViewModel();
        if (!node.isLeaf()) {
            this.lookup('tree').collapseAll();
            node.expand();
            vm.set({
                entry: null,
                widget: null
            });
            me.lookup('report').remove('entry');
        } else {
            var xtype, onDashboard = true, newWidget;
            var entry = Ext.getStore('reports').findRecord('uniqueId', node.get('uniqueId'));
            me.widget = Ext.getStore('widgets').findRecord('entryId', node.get('uniqueId'));

            vm.set('entry', entry);

            if (me.widget) {
                if (entry.get('type') === 'EVENT_LIST') {
                    var tblCfg = TableConfig.getConfig(entry.get('table'));
                    var str = [];
                    Ext.Array.each(tblCfg.columns, function (col) {
                        str.push({name: col.dataIndex, text: col.header});
                    });
                    me.getView().down('tagfield').getStore().setData(str);
                }
                vm.set({
                    widget: me.widget.copy(null),
                    onDashboard: onDashboard
                });
            } else {
                newWidget = Ext.create('Ung.model.Widget', {
                    displayColumns: entry.get('defaultColumns'),
                    enabled: true,
                    entryId: entry.get('uniqueId'),
                    javaClass: 'com.untangle.uvm.DashboardWidgetSettings',
                    refreshIntervalSec: 60,
                    timeframe: '',
                    type: 'ReportEntry'
                });
                onDashboard = false;
                vm.set({
                    widget: newWidget.copy(null),
                    onDashboard: onDashboard
                });
            }

            switch (node.get('type')) {
            case 'EVENT_LIST':
                xtype = 'eventreport'; break;
            case 'TEXT':
                xtype = 'textreport'; break;
            default:
                xtype = 'graphreport';
            }

            me.lookup('report').remove('entry');

            me.lookup('report').add({
                xtype: xtype,
                title: entry.get('title'),
                itemId: 'entry',
                viewModel: { data: { entry: entry } }
            });
        }
    },

    refreshEntry: function () {
        this.lookup('report').down('#entry').getController().fetchData();
    },

    onClose: function () {
        var me = this, vm = this.getViewModel();
        me.lookup('tree').collapseAll();
        me.lookup('tree').getStore().clearFilter();
        vm.set({
            entry: null,
            widget: null,
            onDashboard: false
        });
        me.lookup('report').remove('entry');
    },

    onAdd: function () {
        var me = this, vm = this.getViewModel();
        Ext.getStore('widgets').add(vm.get('widget'));
        me.getView().close();

    },

    updateColumns: function(cmp, val) {
        var vm = this.getViewModel(), columns = this.getView().down('grid').getColumns();
        Ext.Array.each(columns, function (col) {
            col.setHidden(Ext.Array.indexOf(vm.get('widget.displayColumns'), col.dataIndex) < 0);
        });
    }

});
Ext.define('Ung.view.dashboard.Queue', {
    alternateClassName: 'DashboardQueue',
    singleton: true,
    queue: [],
    processing: false,

    paused: false,

    add: function (widget) {
        this.queue.push(widget);
        this.process();
    },

    addFirst: function (widget) {
        this.queue.unshift(widget);
        this.process();
    },

    isVisible: function (widget) {
        if (!widget || !widget.getEl()) { return; }
        var widgetGeometry = widget.getEl().dom.getBoundingClientRect();
        widget.visible = (widgetGeometry.top + widgetGeometry.height / 2) > 0 && (widgetGeometry.height / 2 + widgetGeometry.top < window.innerHeight);
        if (widget.visible) {
            DashboardQueue.add(widget);
        }
    },

    process: function () {
        var me = this, wg = me.queue[0];

        if (me.queue.length > 0 && !me.processing) {

            /**
             * timeout computes if the widget needs to be refreshed based on refreshIntervalSec
             * for custom widgets refreshIntervalSec is defined in view
             * for report widgets refreshIntervalSec is defined in viewmodel
             * if lastFetchTime = null means the widgets did not fatch data at all, it was just being rendered
             */
            if (wg.lastFetchTime === null) {
                wg.timeout = true;
            } else {
                if (wg.refreshIntervalSec === 0) {
                    wg.timeout = false;
                } else {
                    wg.timeout = ((new Date()).getTime() - wg.lastFetchTime)/1000 - (wg.refreshIntervalSec || wg.getViewModel().get('widget.refreshIntervalSec')) > 0;
                }
            }

            /**
             * if queue is paused (e.g. not in Dashboard view) or
             * widget is not in visible area of the screen or
             * it hasn't passed the timeout to be refreshed
             * just remove it from queue and skip fetching
             */
            if (me.paused || !wg.visible || !wg.timeout || wg.isMasked()) {
                Ext.Array.removeAt(me.queue, 0);
                me.processing = false;
                if (me.queue.length > 0) { me.process(); }
                return;
            }

            me.processing = true;
            if (wg.tout) {clearTimeout(wg.tout); }

            if (wg.down('#report-widget')) {
                wg.down('#report-widget').getController().fetchData(null, function () {
                    var seconds = wg.getViewModel().get('widget.refreshIntervalSec');
                    if (seconds > 0) {
                        // wg.add({ xtype: 'component', itemId: 'timer', cls: 'timer', html: '<div class="inner" style="animation: test ' + seconds + 's linear;"></div>' });
                        wg.tout = setTimeout(function () {
                            DashboardQueue.add(wg);
                        }, seconds * 1000);
                    }
                    wg.lastFetchTime = new Date().getTime();
                    Ext.Array.removeAt(me.queue, 0);
                    me.processing = false;
                    if (me.queue.length > 0) { me.process(); }
                });
            } else {
                wg.fetchData(function () {
                    var seconds = wg.refreshIntervalSec;
                    if (seconds > 0) {
                        wg.tout = setTimeout(function () {
                            DashboardQueue.add(wg);
                        }, seconds * 1000);
                    }
                    wg.lastFetchTime = new Date().getTime();
                    Ext.Array.removeAt(me.queue, 0);
                    me.processing = false;
                    if (me.queue.length > 0) { me.process(); }
                });
            }
        }
    }
});
Ext.define('Ung.view.extra.Devices', {
    extend: 'Ext.panel.Panel',
    xtype: 'ung.devices',
    withValidation: true,

    controller: 'devices',

    layout: 'border',
    bodyPadding: 10,

    defaults: {
        border: true
    },

    items: [{
        xtype: 'fieldset',
        title: 'Auto Device Removal'.t(),
        region: 'north',
        padding: 10,
        checkboxToggle: true,
        collapsible: true,
        collapsed: true,
        layout: 'hbox',
        checkbox: {
            bind: '{settings.autoDeviceRemove}'
        },
        items: [{
            xtype: 'numberfield',
            fieldLabel: 'Remove inactive device after'.t(),
            allowDecimals: false,
            minValue: 1,
            maxValue: 999,
            allowBlank: false,
            blankText: 'You must provide a valid threshold.'.t(),
            labelWidth: 200,
            autoEl: {
                tag: 'div',
                'data-qtip': 'Specify the number of days of inactivity after which a device should be removed.'.t(),
            },
            bind: {
                value: '{settings.autoRemovalThreshold}',
                disabled: '{!settings.autoDeviceRemove}'
            }
        }, {
            xtype: 'displayfield',
            value: 'days'.t(),
            margin: '0 0 0 10',
            width: 75
        }],
    }, {
        xtype: 'ungrid',
        region: 'center',
        itemId: 'devicesgrid',
        reference: 'devicesgrid',
        title: 'Current Devices'.t(),
        store: 'devices',
        stateful: true,
        defaultSortable: true,

        enableColumnHide: true,

        viewConfig: {
            stripeRows: true,
            enableTextSelection: true,
            listeners: {
                // to avoid some focusing issues
                cellclick: function (view, cell, cellIndex, record, line, rowIndex, e) {
                    if (Ext.Array.contains(cell.getAttribute('class').split(' '), 'tag-cell')) {
                        return false;
                    }
                }
            }
        },

        tbar: ['@add', '->', '->', '@export'],
        recordActions: ['edit', 'delete'],
        emptyRow: {
            macAddress: '',
            macVendor: '',
            hostname: '',
            hostnameLastKnown: '',
            interfaceId: -1,
            lastSessionTime: 0,
            tags: {
                javaClass: 'java.util.LinkedList',
                list: []
            },
            username: '',
            javaClass: 'com.untangle.uvm.DeviceTableEntry'
        },

        plugins: [ 'gridfilters', {
            ptype: 'cellediting',
            clicksToEdit: 1
        }],

        fields:[{
            name: 'macAddress',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        }, {
            name: 'macVendor',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'interfaceId',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'hostnameLastKnown',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        }, {
            name: 'hostname',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        }, {
            name: 'username',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        }, {
            name: 'httpUserAgent',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        }, {
            name: 'lastSessionTime',
            sortType: 'asTimestamp',
            convert:  Converter.convertDate,
        }, {
            name: 'tags'
        }],

        columns: [{
            header: 'MAC'.t(),
            columns:[{
                header: 'Address'.t(),
                dataIndex: 'macAddress',
                width: Renderer.macWidth,
                filter: Renderer.stringFilter,
                editor: {
                    xtype: 'textfield',
                    emptyText: '[no MAC Address]'.t()
                }
            }, {
                header: 'Vendor'.t(),
                dataIndex: 'macVendor',
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter,
                editor: {
                    xtype: 'textfield',
                    emptyText: '[no MAC Vendor]'.t()
                }
            }]
        }, {
            header: 'Interface'.t(),
            dataIndex: 'interfaceId',
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter,
            renderer: Renderer.interface
        }, {
            header: 'Last Hostname'.t(),
            dataIndex: 'hostnameLastKnown',
            width: Renderer.hostnameWidth,
            filter: Renderer.stringFilter,
            editor: {
                xtype: 'textfield',
                emptyText: ''
            }
        }, {
            header: 'Hostname'.t(),
            dataIndex: 'hostname',
            width: Renderer.hostnameWidth,
            filter: Renderer.stringFilter,
            editor: {
                xtype: 'textfield',
                emptyText: '[no hostname]'.t()
            }
        }, {
            header: 'Username'.t(),
            dataIndex: 'username',
            width: Renderer.usernameidth,
            filter: Renderer.stringFilter,
            editor: {
                xtype: 'textfield',
                emptyText: '[no device username]'.t()
            }
        }, {
            header: 'HTTP'.t() + ' - ' + 'User Agent'.t(),
            flex: 1,
            dataIndex: 'httpUserAgent',
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter,
            editor: {
                xtype: 'textfield',
                emptyText: '[no HTTP user agent]'.t()
            }
        }, {
            header: 'Last Seen Time'.t(),
            dataIndex: 'lastSessionTime',
            width: Renderer.timestampWidth,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        }, {
            header: 'Tags'.t(),
            width: Renderer.tagsWidth,
            xtype: 'widgetcolumn',
            tdCls: 'tag-cell',
            dataIndex: 'tags',
            widget: {
                xtype: 'tagpicker',
                bind: {
                    tags: '{record.tags}'
                }
            }
        }],
        editorFields: [{
            xtype: 'textfield',
            disabled: true,
            bind: {
                value: '{record.macAddress}',
                disabled: '{record.internalId >= 0}'
            },
            fieldLabel: 'MAC Address'.t(),
            emptyText: '[enter MAC address]'.t(),
            allowBlank: false,
            vtype: 'macAddress',
            maskRe: /[a-fA-F0-9:]/
        }, {
            xtype: 'textfield',
            bind: '{record.macVendor}',
            fieldLabel: 'MAC Vendor'.t(),
            emptyText: '[no MAC Vendor]'.t(),
        }, {
            xtype: 'textfield',
            bind: '{record.hostnameLastKnown}',
            fieldLabel: 'Last Hostname'.t(),
            emptyText: '[no last hostname]'.t(),
        }, {
            xtype: 'textfield',
            bind: '{record.hostname}',
            fieldLabel: 'Hostname'.t(),
            emptyText: '[no hostname]'.t(),
        }, {
            xtype: 'textfield',
            bind: '{record.username}',
            fieldLabel: 'Username'.t(),
            emptyText: '[no username]'.t(),
        }, {
            xtype: 'textfield',
            bind: '{record.httpUserAgent}',
            fieldLabel: 'HTTP'.t() + ' - ' + 'User Agent'.t(),
            emptyText: '[no HTTP user agent]'.t()
        }],
    }, {
        region: 'east',
        xtype: 'recorddetails',
        title: 'Session Details'.t(),
        itemId: 'details',
        width: 350,
        bind: {
            collapsed: '{!devicesgrid.selection}'
        }

    }],
    tbar: [{
        xtype: 'button',
        text: 'Refresh'.t(),
        iconCls: 'fa fa-repeat',
        handler: 'getDevicesSettings',
        bind: {
            disabled: '{autoRefresh}'
        }
    }, {
        xtype: 'button',
        text: 'Reset View'.t(),
        iconCls: 'fa fa-refresh',
        itemId: 'resetBtn',
        handler: 'resetView',
    },
    '-',
    {
        xtype: 'ungridfilter',
        store: 'devices'
    }, '->', {
        xtype: 'button',
        text: 'View Reports'.t(),
        iconCls: 'fa fa-line-chart',
        href: '#reports?cat=devices',
        hrefTarget: '_self',
        hidden: true,
        bind: {
            hidden: '{!reportsAppStatus.enabled}'
        }
    }],
    bbar: ['->', {
        text: '<strong>' + 'Save'.t() + '</strong>',
        iconCls: 'fa fa-floppy-o',
        handler: 'setDevicesSettings'
    }]
});
Ext.define('Ung.view.extra.DevicesController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.devices',

    control: {
        '#': {
            deactivate: 'onDeactivate',
            refresh: 'getDevicesSettings'
        },
        '#devicesgrid': {
            afterrender: 'getDevicesSettings'
        }
    },

    onDeactivate: function (view) {
        view.destroy();
    },

    getDevicesSettings: function () {
        var me = this,
            v = me.getView(),
            vm = me.getViewModel(),
            grid = me.getView().down('#devicesgrid'),
            filters = grid.getStore().getFilters(),
            store = Ext.getStore('devices');

        var existingRouteFilter = filters.findBy( function( filter ){
            if(filter.config.source == "route"){
                return true;
            }
        } );
        if( existingRouteFilter != null ){
            filters.remove(existingRouteFilter);
        }
        if( v.routeFilter ){
            filters.add(v.routeFilter);
        }

        if( !store.getFields() ){
            store.setFields(grid.fields);
        }

        me.getView().setLoading(true);
        Rpc.asyncData('rpc.deviceTable.getDevicesSettings')
            .then(function(result) {
                me.getView().setLoading(false);
                vm.set('settings', result);
                store.loadData(result.devices.list);
                if(store.getSorters().items.length == 0){
                    store.sort('macAddress', 'ASC');
                }
            });
    },

    resetView: function( btn ){
        var grid = this.getView().down('#devicesgrid'),
            store = grid.getStore();

        Ext.state.Manager.clear(grid.stateId);
        store.getSorters().removeAll();
        store.sort('macAddress', 'ASC');
        store.clearFilter();
        grid.reconfigure(null, grid.initialConfig.columns);
    },

    timestampColumns : [ "lastSessionTime" ],

    setDevicesSettings: function () {
        var me = this, list = [], v = me.getView(), vm = me.getViewModel();

        if (!me.validateFields(v)) {
            return;
        }

        me.getView().query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            var filters = store.getFilters().clone();
            store.clearFilter(true);

            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
            }
            list = Ext.Array.pluck(store.getRange(), 'data');

            list.forEach(function(record){
                me.timestampColumns.forEach(function(fieldName){
                    if(record[fieldName] && typeof(record[fieldName]) == "object"){
                        record[fieldName] = record[fieldName].getTime();
                    }
                });
            });

            filters.each( function(filter){
                store.addFilter(filter);
            });
        });

        vm.set('settings.devices.list', list);

        me.getView().setLoading(true);
        Rpc.asyncData('rpc.deviceTable.setDevicesSettings', vm.get('settings')).then(function() {
            me.getDevicesSettings();
        }, function (ex) {
            Util.handleException(ex);
        }).always(function () {
            me.getView().setLoading(false);
        });
    },

    validateFields: function (form) {
        invalidFields = [];

        form.query('field').forEach(function (field) {
            if(field.isHidden()){
                return;
            }
            if(field.up('*{isHidden()==true}')){
                return;
            }
            if(field.up().tab && field.up().tab.isHidden() == true ){
                return;
            }
            if(field.initialConfig.bind && field.$hasBinds == undefined){
                return;
            }
            if( field.isValid() == false){
                invalidFields.push({ label: field.getFieldLabel(), error: field.getActiveError() });
            }
        });

        if (invalidFields.length > 0) {
            Util.invalidFormToast(invalidFields);
            return false;
        }
        return true;
    },
});
Ext.define('Ung.view.extra.Hosts', {
    extend: 'Ext.panel.Panel',
    xtype: 'ung.hosts',

    controller: 'hosts',

    layout: 'border',

    defaults: {
        border: false
    },

    viewModel: {
        data: {
            autoRefresh: false,
            autoSort: true
        }
    },

    items: [{
        xtype: 'ungrid',

        region: 'center',
        itemId: 'hostsgrid',
        reference: 'hostsgrid',
        title: 'Current Hosts'.t(),
        store: 'hosts',
        stateful: true,
        defaultSortable: true,

        enableColumnHide: true,

        viewConfig: {
            stripeRows: false,
            enableTextSelection: true,
            trackOver: false,
        },

        selModel: {
            type: 'rowmodel'
        },

        plugins: [ 'gridfilters', {
            ptype: 'cellediting',
            clicksToEdit: 1
        }],

        fields: [{
            name: 'address',
            type: 'string',
            sortType: 'asIp'
        },{
            name: 'macAddress',
            type: 'string',
            sortType: 'asUnString'
        },{
            name: 'macVendor',
            type: 'string',
            sortType: 'asUnString'
        },{
            name: 'interfaceId',
            type: 'string',
            sortType: 'asUnString'
        },{
            name: 'creationTime',
            sortType: 'asTimestamp',
            convert: Converter.convertDate
        },{
            name: 'lastAccessTime',
            sortType: 'asTimestamp',
            convert: Converter.convertDate
        },{
            name: 'lastSessionTime',
            sortType: 'asTimestamp',
            convert: Converter.convertDate
        },{
            name: 'lastCompletedTcpSessionTime',
            sortType: 'asTimestamp',
            convert: Converter.convertDate
        },{
            name: 'entitled',
        },{
            name: 'active',
        },{
            name: 'httpUserAgent',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'captivePortalAuthenticated',
        },{
            name: 'tags',
        },{
            name: 'hostname',
            type: 'string',
            sortType: 'asHostname',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameSource',
            type: 'string',
            sortType: 'asUnString'
        },{
            name: 'hostnameDhcp',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameDns',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameDevice',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameDeviceLastKnown',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameOpenVpn',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameReports',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameDirectoryConnector',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'hostnameWireGuardVpn',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'username',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'usernameSource',
            type: 'string',
            sortType: 'asUnString'
        },{
            name: 'usernameDirectoryConnector',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'usernameCaptivePortal',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'usernameDevice',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'usernameOpenVpn',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'usernameIpsecVpn',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'usernameWireGuardVpn',
            type: 'string',
            sortType: 'asUnString',
            convert: Converter.stringHtmlEncode
        },{
            name: 'quotaSize',
        },{
            name: 'quotaRemaining',
        },{
            name: 'quotaIssueTime',
            sortType: 'asTimestamp',
            convert: Converter.convertDate
        },{
            name: 'quotaExpirationTime',
            sortType: 'asTimestamp',
            convert: Converter.convertDate
        }],

        columns: [{
            header: 'Address'.t(),
            dataIndex: 'address',
            filter: Renderer.stringFilter
        },{
            header: 'MAC'.t(),
            columns:[{
                header: 'Address'.t(),
                dataIndex: 'macAddress',
                width: Renderer.macWidth,
                filter: Renderer.stringFilter
            },{
                header: 'Vendor'.t(),
                dataIndex: 'macVendor',
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            }]
        },{
            header: 'Interface'.t(),
            dataIndex: 'interfaceId',
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter,
            renderer: Renderer.interface
        },{
            header: 'Creation Time'.t(),
            dataIndex: 'creationTime',
            width: Renderer.timestampWidth,
            hidden: true,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        },{
            header: 'Last Access Time'.t(),
            dataIndex: 'lastAccessTime',
            width: Renderer.timestampWidth,
            hidden: true,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        },{
            header: 'Last Session Time'.t(),
            dataIndex: 'lastSessionTime',
            width: Renderer.timestampWidth,
            hidden: true,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        },{
            header: 'Last Completed TCP Session Time'.t(),
            dataIndex: 'lastCompletedTcpSessionTime',
            width: Renderer.timestampWidth,
            hidden: true,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        },{
            header: 'Entitled Status'.t(),
            dataIndex: 'entitled',
            width: Renderer.booleanWidth,
            hidden: true,
            renderer: Renderer.boolean,
            filter: Renderer.booleanFilter
        },{
            header: 'Active'.t(),
            dataIndex: 'active',
            width: Renderer.booleanWidth,
            renderer: Renderer.boolean,
            filter: Renderer.booleanFilter
        },{
            header: '<i class="fa fa-pencil fa-gray"></i> ' + 'HTTP User Agent'.t(),
            dataIndex: 'httpUserAgent',
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter,
            tdCls: 'editable-column',
            editor: {
                xtype: 'textfield',
                emptyText: ''
            }
        },{
            header: 'Captive Portal Authenticated'.t(),
            dataIndex: 'captivePortalAuthenticated',
            width: Renderer.booleanWidth,
            renderer: Renderer.boolean,
            filter: Renderer.booleanFilter
        },{
            header: '<i class="fa fa-pencil fa-gray"></i> ' + 'Tags'.t(),
            width: Renderer.tagsWidth,
            xtype: 'widgetcolumn',
            tdCls: 'tag-cell editable-column',
            dataIndex: 'tags',
            widget: {
                xtype: 'tagpicker',
                bind: {
                    tags: '{record.tags}'
                }
            }
        },{
            header: 'Hostname'.t(),
            dataIndex: 'hostname',
            width: Renderer.hostnameWidth,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname Source'.t(),
            dataIndex: 'hostnameSource',
            width: Renderer.messageWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (DHCP)'.t(),
            dataIndex: 'hostnameDhcp',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (DNS)'.t(),
            dataIndex: 'hostnameDns',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (Device)'.t(),
            dataIndex: 'hostnameDevice',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (Device Last Known)'.t(),
            dataIndex: 'hostnameDeviceLastKnown',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (OpenVPN)'.t(),
            dataIndex: 'hostnameOpenVpn',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (Reports)'.t(),
            dataIndex: 'hostnameReports',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (Directory Connector)'.t(),
            dataIndex: 'hostnameDirectoryConnector',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Hostname (WireGuardVPN)'.t(),
            dataIndex: 'hostnameWireGuardVpn',
            width: Renderer.hostnameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Username'.t(),
            dataIndex: 'username',
            width: Renderer.usernameWidth,
            filter: Renderer.stringFilter
        },{
            header: 'Username Source'.t(),
            dataIndex: 'usernameSource',
            width: Renderer.messageWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Username (Directory Connector)'.t(),
            dataIndex: 'usernameDirectoryConnector',
            width: Renderer.usernameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Username (Captive Portal)'.t(),
            dataIndex: 'usernameCaptivePortal',
            width: Renderer.usernameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Username (Device)'.t(),
            dataIndex: 'usernameDevice',
            width: Renderer.usernameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Username (OpenVPN)'.t(),
            dataIndex: 'usernameOpenVpn',
            width: Renderer.usernameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Username (IPsec VPN)'.t(),
            dataIndex: 'usernameIpsecVpn',
            width: Renderer.usernameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Username (WireGuard VPN)'.t(),
            dataIndex: 'usernameWireGuardVpn',
            width: Renderer.usernameWidth,
            hidden: true,
            filter: Renderer.stringFilter
        },{
            header: 'Quota'.t(),
            columns: [{
                header: 'Size'.t(),
                dataIndex: 'quotaSize',
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter,
                renderer: Renderer.datasizeoptional
            },{
                header: 'Remaining'.t(),
                dataIndex: 'quotaRemaining',
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter,
                renderer: Renderer.datasizeoptional
            },{
                header: 'Issue Time'.t(),
                dataIndex: 'quotaIssueTime',
                width: Renderer.timestampWidth,
                hidden: true,
                renderer: Renderer.timestampUnixRenderer,
                filter: Renderer.timestampFilter
            },{
                header: 'Expiration Time'.t(),
                dataIndex: 'quotaExpirationTime',
                width: Renderer.timestampWidth,
                hidden: true,
                renderer: Renderer.timestampUnixRenderer,
                filter: Renderer.timestampFilter
            }, {
                xtype: 'actioncolumn',
                width: Renderer.actionWidth,
                align: 'center',
                header: 'Refill Quota'.t(),
                menuText: 'Refill Quota'.t(),
                iconCls: 'fa fa-refresh fa-green',
                handler: 'externalAction',
                action: 'refillQuota'
            }, {
                xtype: 'actioncolumn',
                width: Renderer.actionWidth,
                align: 'center',
                header: 'Drop Quota'.t(),
                menuText: 'Drop Quota'.t(),
                iconCls: 'fa fa-minus-circle',
                handler: 'externalAction',
                action: 'dropQuota'
            }]
        }]
    }, {
        region: 'east',
        xtype: 'recorddetails',
        title: 'Host Details'.t(),
        itemId: 'details',
        width: 350,
        bind: {
            collapsed: '{!hostsgrid.selection}'
        }
    }],
    tbar: [{
        xtype: 'button',
        text: 'Refresh'.t(),
        iconCls: 'fa fa-repeat',
        handler: 'getHosts',
        bind: {
            disabled: '{autoRefresh}'
        }
    }, {
        xtype: 'button',
        text: 'Auto Refresh'.t(),
        bind: {
            iconCls: '{autoRefresh ? "fa fa-check-square-o" : "fa fa-square-o"}'
        },
        enableToggle: true,
        toggleHandler: 'setAutoRefresh'
    }, {
        xtype: 'button',
        text: 'Reset View'.t(),
        iconCls: 'fa fa-refresh',
        itemId: 'resetBtn',
        handler: 'resetView',
    },
    '-', {
        xtype: 'ungridfilter'
    }, '->', {
        xtype: 'button',
        text: 'View Reports'.t(),
        iconCls: 'fa fa-line-chart',
        href: '#reports?cat=hosts',
        hrefTarget: '_self',
        hidden: true,
        bind: {
            hidden: '{!reportsAppStatus.enabled}'
        }
    }],
    bbar: ['->', {
        text: '<strong>' + 'Save'.t() + '</strong>',
        iconCls: 'fa fa-floppy-o',
        handler: 'saveHosts'
    }]
});
Ext.define('Ung.view.extra.HostsController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.hosts',

    control: {
        '#': {
            deactivate: 'onDeactivate',
            refresh: 'getHosts'
        },
        '#hostsgrid': {
            afterrender: 'getHosts'
        }
    },

    onDeactivate: function (view) {
        view.destroy();
    },

    setAutoRefresh: function (btn) {
        var me = this,
            vm = this.getViewModel();
        vm.set('autoRefresh', btn.pressed);

        if (btn.pressed) {
            me.getHosts();
            this.refreshInterval = setInterval(function () {
                me.getHosts();
            }, 5000);
        } else {
            clearInterval(this.refreshInterval);
        }

    },

    resetView: function( btn ){
        var grid = this.getView().down('#hostsgrid'),
            store = grid.getStore();

        Ext.state.Manager.clear(grid.stateId);
        store.getSorters().removeAll();
        store.sort('address', 'ASC');
        store.clearFilter();
        grid.reconfigure(null, grid.initialConfig.columns);
    },

    getHosts: function () {
        var me = this,
            v = me.getView(),
            grid = me.getView().down('#hostsgrid'),
            filters = grid.getStore().getFilters(),
            store = grid.getStore('hosts');

        var existingRouteFilter = filters.findBy( function( filter ){
            if(filter.config.source == "route"){
                return true;
            }
        } );
        if( existingRouteFilter != null ){
            filters.remove(existingRouteFilter);
        }
        if( v.routeFilter ){
            filters.add(v.routeFilter);
        }

        if( !store.getFields() ){
            store.setFields(grid.fields);
        }

        grid.getView().setLoading(true);
        Rpc.asyncData('rpc.hostTable.getHosts')
            .then(function(result) {
                grid.getView().setLoading(false);
                store.loadData(result.list);

                if(store.getSorters().items.length == 0){
                    store.sort('address', 'ASC');
                }

                grid.getSelectionModel().select(0);
            });
    },

    refillQuota: function (view, rowIndex, colIndex, item, e, record) {
        var me = this;
        Ext.MessageBox.wait('Refilling...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.hostTable.refillQuota', record.get('address'))
            .then(function () {
                me.getHosts();
            }, function (ex) {
                Util.handleException(ex);
            }).always(function () {
                Ext.MessageBox.hide();
            });
    },

    dropQuota: function (view, rowIndex, colIndex, item, e, record) {
        var me = this;
        Ext.MessageBox.wait('Removing Quota...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.hostTable.removeQuota', record.get('address'))
            .then(function () {
                me.getHosts();
            }, function (ex) {
                Util.handleException(ex);
            }).always(function () {
                Ext.MessageBox.hide();
            });
    },

    timestampColumns : [ "lastAccessTime", "lastSessionTime", "quotaIssueTime", "quotaExpirationTime", "creationTime", "lastCompletedTcpSessionTime" ],


    saveHosts: function () {
        var me = this, list = [];

        me.getView().query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            var filters = store.getFilters().clone();
            store.clearFilter(true);

            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.isReordered = undefined;
            }
            list = Ext.Array.pluck(store.getRange(), 'data');

            list.forEach(function(record){
                me.timestampColumns.forEach(function(fieldName){
                    if(record[fieldName] && typeof(record[fieldName]) == "object"){
                        record[fieldName] = record[fieldName].getTime();
                    }
                });
            });

            filters.each( function(filter){
                store.addFilter(filter);
            });
        });

        me.getView().setLoading(true);
        Rpc.asyncData('rpc.hostTable.setHosts', {
            javaClass: 'java.util.LinkedList',
            list: list
        }, true).then(function() {
            me.getHosts();
        }, function (ex) {
            Util.handleException(ex);
        }).always(function () {
            me.getView().setLoading(false);
        });
    }

});
Ext.define('Ung.view.extra.Sessions', {
    extend: 'Ext.panel.Panel',
    xtype: 'ung.sessions',

    controller: 'sessions',

    viewModel: {
        data: {
            autoRefresh: false
        }
    },

    layout: 'border',

    defaults: {
        border: false
    },

    // title: 'Current Sessions'.t(),

    items: [{
        region: 'center',
        xtype: 'ungrid',
        itemId: 'sessionsgrid',
        reference: 'sessionsgrid',
        store: 'sessions',
        stateful: true,
        defaultSortable: true,

        enableColumnHide: true,

        selModel: {
            type: 'rowmodel'
        },

        viewConfig: {
            stripeRows: true,
            enableTextSelection: true
        },

        plugins: ['gridfilters'],
        columnLines: true,

        features: [{
            ftype: 'grouping'
        }],

        fields: [{
            name: 'creationTime',
            sortType: 'asTimestamp',
            convert:  Converter.convertDate,
        }, {
            name: 'sessionId',
        }, {
            name: 'mark',
        }, {
            name: 'protocol',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'bypassed',
        }, {
            name: 'policy',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'hostname',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'username',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'natted',
        }, {
            name: 'portForwarded',
        }, {
            name: 'tags',
        }, {
            name: "localAddr",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "remoteAddr",
            type: 'string',
            sortType: 'asUnString'
       },{
            name: "priority"
        },{
            name: "qosPriority"
        },{
            name: "pipeline",
        }, {
            name: 'clientIntf',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'preNatClient',
            type: 'string',
            sortType: 'asIp'
        }, {
            name: 'preNatClientPort',
        }, {
            name: 'postNatClient',
            type: 'string',
            sortType: 'asIp'
        }, {
            name: 'postNatClientPort',
        }, {
            name: 'clientCountry',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'clientLatitude',
        }, {
            name: 'clientLongitude',
        }, {
            name: 'serverIntf',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'preNatServer',
            type: 'string',
            sortType: 'asIp'
        }, {
            name: 'preNatServerPort',
        }, {
            name: 'postNatServer',
            type: 'string',
            sortType: 'asIp'
        }, {
            name: 'postNatServerPort',
        }, {
            name: 'serverCountry',
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: 'serverLatitude',
        }, {
            name: 'serverLongitude',
        }, {
            name: 'clientBps',
            convert: Renderer.sessionSpeed
        }, {
            name: 'serverBps',
            convert: Renderer.sessionSpeed
        }, {
            name: 'totalBps',
            convert: function(value, record){
                if ( record.data.serverBps == null ||
                     record.data.clientBps == null ){
                        return null;
                }
                return Renderer.sessionSpeed(value);
            }
        }, {
            name: "application-control-lite-protocol",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-lite-category",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-lite-description",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-lite-matched",
        }, {
            name: "application-control-protochain",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-application",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-category",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-detail",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-confidence",
        },{
            name: "application-control-productivity",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "application-control-risk",
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: "web-filter-best-category-name",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "web-filter-best-category-description",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "web-filter-best-category-flagged",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "web-filter-best-category-blocked",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "web-filter-flagged",
        }, {
            name: "http-hostname",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-url",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-user-agent",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-uri",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-request-method",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-request-file-name",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-request-file-extension",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-request-file-path",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-response-file-name",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-response-file-extension",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-content-type",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-referer",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "http-content-length",
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: "ssl-subject-dn",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "ssl-issuer-dn",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "ssl-session-inspect",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "ssl-sni-host",
            type: 'string',
            sortType: 'asUnString'
        }, {
            name: "ftp-file-name",
            type: 'string',
            sortType: 'asUnString'
        },{
            name: "ftp-data-session",
        }],

        columns: [{
            header: 'Creation Time'.t(),
            dataIndex: 'creationTime',
            width: Renderer.timestampWidth,
            hidden: true,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        }, {
            header: 'Session ID'.t(),
            dataIndex: 'sessionId',
            width: Renderer.messageWidth,
            hidden: true,
            filter: Renderer.numericFilter
        }, {
            header: 'Mark'.t(),
            dataIndex: 'mark',
            width: Renderer.idWidth,
            hidden: true,
            filter: Renderer.numericFilter,
            renderer: function(value) {
                if (value)
                    return "0x" + value.toString(16);
                else
                    return "";
            }
        }, {
            header: 'Protocol'.t(),
            dataIndex: 'protocol',
            width: Renderer.portWidth,
            filter: Renderer.stringFilter
        }, {
            header: 'Bypassed'.t(),
            dataIndex: 'bypassed',
            width: Renderer.booleanWidth,
            filter: Renderer.booleanFilter,
            renderer: Renderer.boolean
        }, {
            header: 'Policy'.t(),
            dataIndex: 'policy',
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter,
            renderer: Renderer.policy
        }, {
            header: 'Hostname'.t(),
            dataIndex: 'hostname',
            width: Renderer.hostnameWidth,
            filter: Renderer.stringFilter
        }, {
            header: 'Username'.t(),
            dataIndex: 'username',
            width: Renderer.usernameWidth,
            filter: Renderer.stringFilter
        }, {
            header: 'NATd'.t(),
            dataIndex: 'natted',
            width: Renderer.booleanWidth,
            filter: Renderer.booleanFilter,
            hidden: true
        }, {
            header: 'Port Forwarded'.t(),
            dataIndex: 'portForwarded',
            width: Renderer.booleanWidth,
            filter: Renderer.booleanFilter,
            hidden: true
        }, {
            hidden: true,
            header: 'Local Address'.t(),
            dataIndex: "localAddr",
            width: Renderer.ipWidth,
            filter: Renderer.stringFilter
        },{
            hidden: true,
            header: 'Remote Address'.t(),
            dataIndex: "remoteAddr",
            width: Renderer.ipWidth,
            filter: Renderer.stringFilter
        },{
            hidden: true,
            header: 'Bandwidth Control ' + 'Priority'.t(),
            dataIndex: "priority",
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter,
            renderer: Renderer.priority
        },{
            hidden: true,
            header: 'QoS ' + 'Priority'.t(),
            dataIndex: "qosPriority",
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter,
            renderer: Renderer.priority
        },{
            hidden: true,
            header: 'Pipeline'.t(),
            dataIndex: "pipeline",
            width: Renderer.messageWidth,
            filter: Renderer.stringFilter
        }, {
            header: 'Client'.t(),
            columns: [{
                header: 'Interface'.t(),
                dataIndex: 'clientIntf',
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter,
                renderer: Renderer.interface
            }, {
                header: 'Address'.t() + ' (' + 'Pre-NAT'.t() + ')',
                dataIndex: 'preNatClient',
                width: Renderer.ipWidth,
                filter: Renderer.stringFilter,
            }, {
                header: 'Port'.t() + ' (' + 'Pre-NAT'.t() + ')',
                dataIndex: 'preNatClientPort',
                width: Renderer.portWidth,
                filter: Renderer.numericFilter
            }, {
                header: 'Address'.t() + ' (' + 'Post-NAT'.t() + ')',
                dataIndex: 'postNatClient',
                width: Renderer.ipWidth,
                filter: Renderer.stringFilter,
                hidden: true
            }, {
                header: 'Port'.t() + ' (' + 'Post-NAT'.t() + ')',
                dataIndex: 'postNatClientPort',
                width: Renderer.portWidth,
                filter: Renderer.numericFilter,
                hidden: true
            }, {
                header: 'Country'.t(),
                dataIndex: 'clientCountry',
                width: Renderer.booleanWidth,
                filter: Renderer.stringFilter,
                hidden: true
            }, {
                header: 'Latitude'.t(),
                dataIndex: 'clientLatitude',
                width: Renderer.locationWidth,
                filter: Renderer.numericFilter,
                hidden: true
            }, {
                header: 'Longitude'.t(),
                dataIndex: 'clientLongitude',
                filter: Renderer.numericFilter,
                hidden: true
            }]
        }, {
            header: 'Server'.t(),
            columns: [{
                header: 'Interface'.t(),
                dataIndex: 'serverIntf',
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter,
                renderer: Renderer.interface
            }, {
                header: 'Address'.t() + ' (' + 'Pre-NAT'.t() + ')',
                dataIndex: 'preNatServer',
                width: Renderer.ipWidth,
                filter: Renderer.stringFilter,
                hidden: true
            }, {
                header: 'Port'.t() + ' (' + 'Pre-NAT'.t() + ')',
                dataIndex: 'preNatServerPort',
                width: Renderer.portWidth,
                filter: Renderer.numericFilter,
                hidden: true
            }, {
                header: 'Address'.t() + ' (' + 'Post-NAT'.t() + ')',
                width: Renderer.ipWidth,
                dataIndex: 'postNatServer',
                filter: Renderer.stringFilter
            }, {
                header: 'Port'.t() + ' (' + 'Post-NAT'.t() + ')',
                dataIndex: 'postNatServerPort',
                width: Renderer.portWidth,
                filter: Renderer.numericFilter
            }, {
                header: 'Country'.t(),
                dataIndex: 'serverCountry',
                width: Renderer.booleanWidth,
                filter: Renderer.stringFilter
            }, {
                header: 'Latitude'.t(),
                dataIndex: 'serverLatitude',
                width: Renderer.locationWidth,
                filter: Renderer.numericFilter,
                hidden: true
            }, {
                header: 'Longitude'.t(),
                dataIndex: 'serverLongitude',
                width: Renderer.locationWidth,
                filter: Renderer.numericFilter,
                hidden: true
            }]
        }, {
            header: 'Speed'.t(),
            columns: [{
                header: 'Client'.t(),
                dataIndex: 'clientBps',
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter,
                align: 'right',
                renderer: Renderer.renderBps
            }, {
                header: 'Server'.t(),
                dataIndex: 'serverBps',
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter,
                align: 'right',
                renderer: Renderer.renderBps
            }, {
                header: 'Total'.t(),
                dataIndex: 'totalBps',
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter,
                align: 'right',
                renderer: Renderer.renderBps
            }]
        }, {
            header: 'Application Control Lite',
            hidden: true,
            columns: [{
                hidden: true,
                header: 'Protocol'.t(),
                dataIndex: "application-control-lite-protocol",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Category'.t(),
                dataIndex: "application-control-lite-category",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Description'.t(),
                dataIndex: "application-control-lite-description",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Matched?'.t(),
                dataIndex: "application-control-lite-matched",
                width: Renderer.messageWidth,
                filter: Renderer.booleanFilter
            }]
        }, {
            header: 'Application Control',
            columns: [{
                header: 'Protochain'.t(),
                dataIndex: "application-control-protochain",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                header: 'Application'.t(),
                dataIndex: "application-control-application",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Category'.t(),
                dataIndex: "application-control-category",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Detail'.t(),
                dataIndex: "application-control-detail",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Confidence'.t(),
                dataIndex: "application-control-confidence",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Productivity'.t(),
                dataIndex: "application-control-productivity",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Risk'.t(),
                dataIndex: "application-control-risk",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            }]
        }, {
            header: 'Web Filter',
            hidden: true,
            columns: [{
                hidden: true,
                header: 'Category Name'.t(),
                dataIndex: "web-filter-best-category-name",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Category Description'.t(),
                dataIndex: "web-filter-best-category-description",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Category Flagged'.t(),
                dataIndex: "web-filter-best-category-flagged",
                width: Renderer.messageWidth,
                filter: Renderer.booleanFilter
            },{
                hidden: true,
                header: 'Category Blocked'.t(),
                dataIndex: "web-filter-best-category-blocked",
                width: Renderer.booleanWidth,
                filter: Renderer.booleanFilter,
            },{
                hidden: true,
                header: 'Flagged'.t(),
                dataIndex: "web-filter-flagged",
                width: Renderer.booleanWidth,
                filter: Renderer.booleanFilter,
            }]
        }, {
            header: 'HTTP',
            hidden: true,
            columns: [{
                hidden: true,
                header: 'Hostname'.t(),
                dataIndex: "http-hostname",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'URL'.t(),
                dataIndex: "http-url",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'User Agent'.t(),
                dataIndex: "http-user-agent",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'URI'.t(),
                dataIndex: "http-uri",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Request Method'.t(),
                dataIndex: "http-request-method",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Request File Name'.t(),
                dataIndex: "http-request-file-name",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Request File Extension'.t(),
                dataIndex: "http-request-file-extension",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Request File Path'.t(),
                dataIndex: "http-request-file-path",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Response File Name'.t(),
                dataIndex: "http-response-file-name",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Response File Extension'.t(),
                dataIndex: "http-response-file-extension",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Content Type'.t(),
                dataIndex: "http-content-type",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Referrer'.t(),
                dataIndex: "http-referer",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Content Length'.t(),
                dataIndex: "http-content-length",
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter
            }]
        }, {
            header: 'SSL',
            hidden: true,
            columns: [{
                hidden: true,
                header: 'Subject DN'.t(),
                dataIndex: "ssl-subject-dn",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Issuer DN'.t(),
                dataIndex: "ssl-issuer-dn",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Inspected'.t(),
                dataIndex: "ssl-session-inspect",
                width: Renderer.booleanWidth,
                filter: Renderer.booleanFilter
            },{
                hidden: true,
                header: 'SNI Hostname'.t(),
                dataIndex: "ssl-sni-host",
                width: Renderer.hostnameWidth,
                filter: Renderer.stringFilter
            }]
        }, {
            header: 'FTP',
            hidden: true,
            columns: [{
                hidden: true,
                header: 'Filename'.t(),
                dataIndex: "ftp-file-name",
                width: Renderer.messageWidth,
                filter: Renderer.stringFilter
            },{
                hidden: true,
                header: 'Data Session'.t(),
                dataIndex: "ftp-data-session",
                width: Renderer.booleanWidth,
                filter: Renderer.booleanFilter,
            }]
        }, {
            header: 'Tags'.t(),
            dataIndex: 'tags',
            width: Renderer.tagsWidth,
            renderer: Renderer.tags
        }]
    }, {
        region: 'east',
        xtype: 'recorddetails',
        title: 'Session Details'.t(),
        width: 350,
        itemId: 'details',
        bind: {
            collapsed: '{!sessionsgrid.selection}'
        }
    }],
    tbar: [{
        xtype: 'button',
        text: 'Refresh'.t(),
        iconCls: 'fa fa-repeat',
        handler: 'getSessions',
        bind: {
            disabled: '{autoRefresh}'
        }
    }, {
        xtype: 'button',
        text: 'Auto Refresh'.t(),
        bind: {
            iconCls: '{autoRefresh ? "fa fa-check-square-o" : "fa fa-square-o"}'
        },
        enableToggle: true,
        toggleHandler: 'setAutoRefresh'
    }, {
        xtype: 'button',
        text: 'Reset View'.t(),
        iconCls: 'fa fa-refresh',
        itemId: 'resetBtn',
        handler: 'resetView',
    },
    '-',
    {
        xtype: 'ungridfilter'
    }]
});
Ext.define('Ung.view.extra.SessionsController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.sessions',

    control: {
        '#': {
            deactivate: 'onDeactivate',
            refresh: 'getSessions'
        },
        '#sessionsgrid': {
            afterrender: 'getSessions'
        }
    },

    refreshInterval: null,

    onDeactivate: function (view) {
        view.destroy();
    },

    setAutoRefresh: function (btn) {
        var me = this,
            vm = this.getViewModel();
        vm.set('autoRefresh', btn.pressed);

        if (btn.pressed) {
            me.getSessions();
            this.refreshInterval = setInterval(function () {
                me.getSessions();
            }, 5000);
        } else {
            clearInterval(this.refreshInterval);
        }

    },

    resetView: function( btn ){
        var grid = this.getView().down('#sessionsgrid'),
            store = grid.getStore();

        Ext.state.Manager.clear(grid.stateId);
        store.getSorters().removeAll();
        store.sort('bypassed', 'ASC');
        store.clearFilter();
        grid.reconfigure(null, grid.initialConfig.columns);
    },

    getSessions: function () {
        var me = this,
            v = me.getView(),
            grid = v.down('#sessionsgrid'),
            filters = grid.getStore().getFilters(),
            store = Ext.getStore('sessions');

        var existingRouteFilter = filters.findBy( function( filter ){
            if(filter.config.source == "route"){
                return true;
            }
        } );
        if( existingRouteFilter != null ){
            filters.remove(existingRouteFilter);
        }
        if( v.routeFilter ){
            filters.add(v.routeFilter);
        }

        if( !store.getFields() ){
            store.setFields(grid.fields);
        }

        grid.getView().setLoading(true);
        Rpc.asyncData('rpc.sessionMonitor.getMergedSessions')
            .then(function(result) {
                grid.getView().setLoading(false);
                var sessions = result.list;

                sessions.forEach( function( session ){
                    var key;
                    if( session.attachments ){
                        for(key in session.attachments.map ){
                            session[key] = session.attachments.map[key];
                        }
                        delete session.attachments;
                    }
                });

                store.loadData( sessions );

                if(store.getSorters().items.length == 0){
                    store.sort('bypassed', 'ASC');
                }

                grid.getSelectionModel().select(0);
            });
    },

});
Ext.define('Ung.view.extra.Users', {
    extend: 'Ext.panel.Panel',
    xtype: 'ung.users',

    controller: 'users',

    viewModel: {
        data: {
            usersData: []
        },
        stores: {
            users: {
                data: '{usersData}',
                fields: [{
                    name: 'username',
                    type: 'string',
                    sortType: 'asUnString'
                }, {
                    name: 'creationTime',
                    sortType: 'asTimestamp',
                    convert:  Converter.convertDate,
                }, {
                    name: 'lastAccessTime',
                    sortType: 'asTimestamp',
                    convert:  Converter.convertDate,
                }, {
                    name: 'lastSessionTime',
                    sortType: 'asTimestamp',
                    convert:  Converter.convertDate,
                }, {
                    name: 'quotaSize',
                }, {
                    name: 'quotaRemaining',
                }, {
                    name: 'quotaIssueTime',
                    sortType: 'asTimestamp',
                    convert:  Converter.convertDate,
                }, {
                    name: 'quotaExpirationTime',
                    sortType: 'asTimestamp',
                    convert:  Converter.convertDate,
                }, {
                    name: 'tags'
                }]
            }
        }
    },

    layout: 'border',

    defaults: {
        border: false
    },

    items: [{
        region: 'center',
        xtype: 'ungrid',
        itemId: 'usersgrid',
        reference: 'usersgrid',
        title: 'Current Users'.t(),
        stateful: true,
        defaultSortable: true,

        sortField: 'username',
        sortOrder: 'ASC',

        plugins: ['gridfilters'],
        columnLines: true,

        enableColumnHide: true,

        bind: '{users}',

        tbar: ['@add', '->', '->', '@export'],
        recordActions: ['edit', 'delete'],
        emptyRow: {
            username: '',
            lastAccessTime: 0,
            lastSessionTime: 0,
            quotaSize: 0,
            quotaRemaining: 0,
            quotaIssueTime: 0,
            quotaExpirationTime: 0,
            tags: {
                javaClass: 'java.util.LinkedList',
                list: []
            },
            javaClass: 'com.untangle.uvm.UserTableEntry'
        },

        columns: [{
            header: 'Username'.t(),
            dataIndex: 'username',
            width: Renderer.usernameWidth,
            filter: Renderer.stringFilter
        }, {
            header: 'Creation Time'.t(),
            dataIndex: 'creationTime',
            width: Renderer.timestampWidth,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        }, {
            header: 'Last Access Time'.t(),
            dataIndex: 'lastAccessTime',
            width: Renderer.timestampWidth,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        }, {
            header: 'Last Session Time'.t(),
            dataIndex: 'lastSessionTime',
            width: Renderer.timestampWidth,
            renderer: Renderer.timestampUnixRenderer,
            filter: Renderer.timestampFilter
        }, {
            header: 'Quota'.t(),
            columns: [{
                header: 'Size'.t(),
                dataIndex: 'quotaSize',
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter,
                renderer: Renderer.datasizeoptional
            }, {
                header: 'Remaining'.t(),
                dataIndex: 'quotaRemaining',
                width: Renderer.sizeWidth,
                filter: Renderer.numericFilter,
                renderer: Renderer.datasizeoptional
            }, {
                header: 'Issue Time'.t(),
                dataIndex: 'quotaIssueTime',
                width: Renderer.timestampWidth,
                renderer: Renderer.timestampUnixRenderer,
                filter: Renderer.timestampFilter
            }, {
                header: 'Expiration Time'.t(),
                dataIndex: 'quotaExpirationTime',
                width: Renderer.timestampWidth,
                renderer: Renderer.timestampUnixRenderer,
                filter: Renderer.timestampFilter
            }, {
                xtype: 'actioncolumn',
                width: Renderer.actionWidth,
                align: 'center',
                header: 'Refill'.t(),
                menuText: 'Refill'.t(),
                iconCls: 'fa fa-refresh fa-green',
                handler: 'externalAction',
                action: 'refillQuota'
            }, {
                xtype: 'actioncolumn',
                width: Renderer.actionWidth,
                align: 'center',
                header: 'Drop'.t(),
                menuText: 'Drop'.t(),
                iconCls: 'fa fa-minus-circle',
                handler: 'externalAction',
                action: 'dropQuota'
            }]
        }, {
            header: 'Tags'.t(),
            width: Renderer.tagsWidth,
            xtype: 'widgetcolumn',
            tdCls: 'tag-cell',
            dataIndex: 'tags',
            // flex: 1,
            widget: {
                xtype: 'tagpicker',
                bind: {
                    tags: '{record.tags}'
                }
            }
        }],
        editorFields: [{
            xtype: 'textfield',
            bind: '{record.username}',
            fieldLabel: 'Username'.t(),
            emptyText: '[enter Username]'.t(),
            allowBlank: false,
        }, {
            xtype: 'unitsfield',
            fieldLabel: 'Quota Size'.t(),
            minValue: 0,
            maxValue: 1024,
            units: [
                [ 1, 'B'.t() ],
                [ 1024, 'KB'.t() ],
                [ 1048576, 'MB'.t() ],
                [ 1073741824, 'GB'.t() ],
                [ 1099511627776, 'TB'.t() ],
                [ 1125899906842624, 'PB'.t() ]
            ],
            bind: {
                value: '{record.quotaSize}'
            }
        }]
    }, {
        region: 'east',
        xtype: 'recorddetails',
        title: 'User Details'.t(),
        itemId: 'details',
        width: 350,
        bind: {
            collapsed: '{!usersgrid.selection}'
        }
    }],
    tbar: [{
        xtype: 'button',
        text: 'Refresh'.t(),
        iconCls: 'fa fa-repeat',
        handler: 'getUsers'
    }, {
        xtype: 'button',
        text: 'Reset View'.t(),
        iconCls: 'fa fa-refresh',
        itemId: 'resetBtn',
        handler: 'resetView',
    }, '->', {
        xtype: 'button',
        text: 'View Reports'.t(),
        iconCls: 'fa fa-line-chart',
        href: '#reports?cat=users',
        hrefTarget: '_self',
        hidden: true,
        bind: {
            hidden: '{!reportsAppStatus.enabled}'
        }
    }],
    bbar: ['->', {
        text: '<strong>' + 'Save'.t() + '</strong>',
        iconCls: 'fa fa-floppy-o',
        handler: 'saveUsers'
    }]  
});
Ext.define('Ung.view.extra.UsersController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.users',

    control: {
        '#': {
            deactivate: 'onDeactivate'
        },
        '#usersgrid': {
            afterrender: 'getUsers',
        }
    },

    refreshInterval: null,

    onDeactivate: function (view) {
        view.destroy();
    },

    resetView: function( btn ){
        var grid = this.getView().down('#usersgrid');
        Ext.state.Manager.clear(grid.stateId);
        var filter = this.getView().down('ungridfilter');
        if(filter){
            filter.setValue('');
        }
        grid.getStore().clearFilter();
        grid.reconfigure(null, grid.initialConfig.columns);
    },

    getUsers: function () {
        var me = this,
            vm = this.getViewModel(),
            grid = me.getView().down('#usersgrid');

        grid.getView().setLoading(true);
        Rpc.asyncData('rpc.userTable.getUsers')
            .then(function(result) {
                grid.getView().setLoading(false);
                vm.set('usersData', result.list);
            });
    },

    timestampColumns : [ "lastAccessTime", "lastSessionTime", "quotaIssueTime", "quotaExpirationTime", "creationTime" ],

    saveUsers: function () {
        var me = this,
            list = [];

        me.getView().query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            var filters = store.getFilters().clone();
            store.clearFilter(true);

            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
            }
            list = Ext.Array.pluck(store.getRange(), 'data');

            list.forEach(function(record){
                me.timestampColumns.forEach(function(fieldName){
                    if(record[fieldName] && typeof(record[fieldName]) == "object"){
                        record[fieldName] = record[fieldName].getTime();
                    }
                });
            });

            filters.each( function(filter){
                store.addFilter(filter);
            });
        });

        me.getView().setLoading(true);
        Rpc.asyncData('rpc.userTable.setUsers', {
            javaClass: 'java.util.LinkedList',
            list: list
        }).then(function(result, ex) {
             me.getUsers();
        }, function (ex) {
            Util.handleException(ex);
        }).always(function () {
            me.getView().setLoading(false);
        });
   },

    refillQuota: function (view, rowIndex, colIndex, item, e, record) {
        var me = this;
        Ext.MessageBox.wait('Refilling...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.userTable.refillQuota', record.get('username'))
            .then(function () {
                me.getUsers();
            }, function (ex) {
                Util.handleException(ex);
            }).always(function () {
                Ext.MessageBox.hide();
            });
    },

    dropQuota: function (view, rowIndex, colIndex, item, e, record) {
        var me = this;
        Ext.MessageBox.wait('Removing Quota...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.userTable.removeQuota', record.get('username'))
            .then(function () {
                me.getUsers();
            }, function (ex) {
                Util.handleException(ex);
            }).always(function () {
                Ext.MessageBox.hide();
            });
    }
});
Ext.define('Ung.view.main.IframePanel', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.iframe-panel',
    layout: 'fit',
    border: false,
    bodyPadding: 0,

    config: {
        iframeUrl: '',
        messageData: null
    },

    initComponent: function () {
        this.callParent(arguments);

        this.on('afterrender', function (panel) {
            var iframe = document.createElement('iframe');

            iframe.src = panel.iframeUrl || '';
            iframe.width = '100%';
            iframe.height = '100%';
            iframe.allowFullscreen = true;
            iframe.style.border = 'none';

            panel.body.dom.appendChild(iframe);
            panel.iframeEl = iframe;
        });
    },

    updateIframe: function ( iframeUrl, hidden, messageData ) {
        if (iframeUrl) {
            this.iframeUrl = iframeUrl;

            if (this.iframeEl) {
                this.iframeEl.src = iframeUrl;
            }
        }

        if (typeof hidden === 'boolean') {
            this.setHidden(hidden);
        }

        // Message Data to post message to Iframe
        if (messageData) {
            this.messageData = messageData;

            // Send data immediately if iframe already loaded
            if (this.iframeEl && this.iframeEl.contentWindow) {
                var me = this;
                this.iframeEl.onload = function () {
                    me.iframeEl.contentWindow.postMessage(
                        messageData,
                        new URL(me.iframeUrl).origin
                    );
                };
            }
        }
    }
});
Ext.define('Ung.view.main.InvalidRoute', {
    extend: 'Ext.container.Container',
    alias: 'widget.invalidroute',
    itemId: 'invalidRoute',
    cls: 'invalid-route',
    layout: {
        type: 'vbox',
        align: 'center'
    },
    padding: 50,

    items: [{
        xtype: 'component',
        style: {
            textAlign: 'center',
            fontSize: '14px'
        },
        html: '<i class="fa fa-warning fa-3x" style="color: #999;"></i>' +
            '<div><h1>Ooops... Error</h1><p>Sorry, the page you are looking for was not found!</p></div>'
    }, {
        xtype: 'button',
        iconCls: 'fa fa-home fa-lg',
        scale: 'medium',
        margin: '20 0 0 0',
        focusable: false,
        text: 'Go to Dashboard'.t(),
        href: '#',
        hrefTarget: '_self'
    }]
});
Ext.define('Ung.view.main.Main', {
    extend: 'Ext.panel.Panel',
    itemId: 'main',
    reference: 'main',

    controller: 'main',
    viewModel: {},

    layout: 'card',
    border: false,
    bodyBorder: false,
    bind: {
        activeItem: '{activeItem}'
    },
    publishes: 'activeItem',

    dockedItems: [{
        xtype: 'mainheading',
    }, {
        xtype: 'userLicenseMessages',
    }],

    items: [{
        xtype: 'ung-dashboard'
    }, {
        xtype: 'ung.apps'
    }, {
        xtype: 'ung.config'
    }, {
        xtype: 'ung.reports'
    }, {
        xtype: 'invalidroute',
    }]
});
Ext.define('Ung.view.main.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.main',

    control: {
        '#': {
            beforerender: 'onBeforeRender'
        }
    },

    listen: {
        global: {
            afterlaunch: 'afterLaunch',
        }
    },

    afterLaunch: function () {
        if (!rpc.UvmContext.isCCHidden()) {
            this.checkRegister();
        }
        this.checkNotifications();
    },

    checkRegister: function () {
        var me = this;
        if(!Rpc.directData('rpc.isRegistered')) {
            Rpc.asyncData('rpc.UvmContext.isStoreAvailable')
            .then( function(result){
                if(Util.isDestroyed(me)){
                    return;
                }
                if (!result) {
                    me.openOffline();
                }
            },function(ex){
                Util.handleException(ex);
            });
        }
    },

    openOffline: function () {
        if (!Rpc.directData('rpc.UvmContext.licenseManager.isRestricted')) {
            var offView = Ext.create('Ung.view.main.Offline', {});
            offView.show();
        }
    },

    checkNotifications: function () {
        var me = this;
        Rpc.asyncData('rpc.notificationManager.getNotifications')
        .then(function (result) {
            if(Util.isDestroyed(me)){
                return;
            }
            var btn = me.getView().down('#notificationBtn'), notificationArr = '', i;

            if (result != null && result.list.length > 0) {
                btn.show();
                notificationArr += '<h3>' + 'Notifications:'.t() + '</h3><ul>';
                for (i = 0; i < result.list.length; i += 1) {
                    notificationArr += '<li>' + result.list[i] + '</li>';
                }
                notificationArr += '</ul>';
                btn.setText(result.list.length);
            } else {
                btn.hide();
                return;
            }

            btn.setMenu({
                cls: 'notification-menu',
                plain: true,
                shadow: false,
                width: 300,
                items: [{
                    xtype: 'component',
                    padding: '20',
                    style: {
                        color: '#CCC'
                    },
                    autoEl: {
                        html: notificationArr
                    }
                }, {
                    xtype: 'button',
                    iconCls: 'fa fa-question-circle',
                    text: 'Help with Administration Notifications'.t(),
                    margin: '0 20 20 20',
                    href: Rpc.directData('rpc.helpUrl') + '?source=admin_notifications' + '&' + Util.getAbout(),
                    hrefTarget: '_blank'
                }]
            });
        }, function (ex) {
            Util.handleException(ex);
        });
    },




    init: function (view) {
        var vm = view.getViewModel();
        // //view.getViewModel().set('widgets', Ext.getStore('widgets'));
        // vm.set('reports', Ext.getStore('reports'));
        vm.set('policyId', 1);
    },

    onBeforeRender: function(view) {
        this.setLiveSupport();
    },

    setLiveSupport: function() {
        this.getViewModel().set('liveSupport', Rpc.directData('rpc.appManager.app', 'live-support') !== null);
    },

    helpHandler: function (btn) {
        var helpUrl = Rpc.directData('rpc.helpUrl') + '?fragment=' + window.location.hash.substr(1) + '&' + Util.getAbout();
        window.open(helpUrl);
    },

    suggestHandler: function (btn) {
        var suggestUrl = Rpc.directData('rpc.feedbackUrl');
        window.open(suggestUrl);
    },

    supportHandler: function (btn) {
        var me = this;
        // check here if support is enabled and show modal only if not, otherwise open support window
        var systemSettings = Rpc.directData('rpc.systemManager.getSettings');
        if (systemSettings.cloudEnabled && systemSettings.supportEnabled) {
            me.supportLaunch();
        } else {
            me.getView().add({ xtype: 'support' }).show();
        }
    },

    supportLaunch: function () {
        var supportUrl = Util.getStoreUrl() + '?action=support&' + Util.getAbout() + '&fragment=' + window.location.hash.substr(1) + '&line=ngfw';
        var user = Rpc.directData('rpc.adminManager.getSettings').users.list[0];
        if (user) {
            supportUrl += '&email=' + user.emailAddress;
        }
        window.open(supportUrl);
    },

    onDashboard: function () {
        var me = this, route = 'dashboard',
            vm = me.getView().down('#dashboardMain').getViewModel();
        if (vm.get('query.string')) {
            route += vm.get('query.string').replace('&', '?');
        }
        Ung.app.redirectTo(route);
    },

    onReports: function () {
        var me = this, route = 'reports',
            vm = me.getView().down('#reports').getViewModel();
        if (vm.get('query.string')) {
            route += vm.get('query.string').replace('&', '?');
        }
        Ung.app.redirectTo(route);
    }

});
Ext.define('Ung.view.main.MainHeading', {
    extend: 'Ext.toolbar.Toolbar',
    alias: 'widget.mainheading',

    ui: 'navigation',
    dock: 'top',
    border: false,

    defaults: {
        xtype: 'button',
        border: false,
        hrefTarget: '_self',
        plugins: 'responsive',
        responsiveConfig: { 'width >= 1000': { hidden: false, }, 'width < 1000': { hidden: true } }
    },
    items: [{
        html: '<img src="' + '/images/BrandingLogo.png?' + (new Date()).getTime() + '" class="branding-logo"/>',
        cls: 'logo',
        href: '#',
        responsiveConfig: null
    }, {
        text: 'Dashboard'.t(),
        handler: 'onDashboard',
        bind: { userCls: '{activeItem === "dashboardMain" ? "pressed" : ""}' }
    }, {
        text: 'Apps'.t(),
        bind: { href: '#apps/{policyId}', userCls: '{(activeItem === "apps" || activeItem === "appCard") ? "pressed" : ""}' },
    }, {
        text: 'Config'.t(),
        href: '#config',
        bind: { userCls: '{(activeItem === "config" || activeItem === "configCard") ? "pressed" : ""}' },
    }, {
        text: 'Reports'.t(),
        handler: 'onReports',
        bind: {
            userCls: '{activeItem === "reports" ? "pressed" : ""}',
        }
    }, '->', {
        text: 'Sessions'.t(),
        href: '#sessions',
        bind: { userCls: '{activeItem === "sessions" ? "pressed" : ""}' }
    }, {
        text: 'Hosts'.t(),
        href: '#hosts',
        bind: { userCls: '{activeItem === "hosts" ? "pressed" : ""}' }
    }, {
        text: 'Devices'.t(),
        href: '#devices',
        bind: { userCls: '{activeItem === "devices" ? "pressed" : ""}' }
    }, {
        text: 'Users'.t(),
        href: '#users',
        bind: { userCls: '{activeItem === "users" ? "pressed" : ""}' }
    }, {
        xtype: 'component',
        width: 1,
        height: 40,
        margin: '0 10',
        style: { background: '#555' }
    }, {
        iconCls: 'fa fa-exclamation-triangle fa-lg fa-orange',
        itemId: 'notificationBtn',
        cls: 'notification-btn',
        arrowVisible: false,
        menuAlign: 'tr-br',
        hidden: true,
        responsiveConfig: null
    }, {
        iconCls: 'fa fa-lightbulb-o fa-lg',
        handler: 'suggestHandler',
        tooltip: 'Suggest Idea'.t(),
        width: 52,
        responsiveConfig: null
    }, {
        iconCls: 'fa fa-question-circle fa-lg',
        handler: 'helpHandler',
        tooltip: 'Help'.t(),
        width: 52,
        responsiveConfig: null
    }, {
        iconCls: 'fa fa-life-ring fa-lg',
        handler: 'supportHandler',
        tooltip: 'Support'.t(),
        width: 52,
        hidden: true,
        bind: {
            hidden: '{!liveSupport}'
        },
        responsiveConfig: null
    }, {
        responsiveConfig: { 'width >= 1000': { iconCls: 'fa fa-user-circle fa-lg' }, 'width < 1000': { iconCls: 'fa fa-bars fa-lg' } },
        width: 52,
        margin: '0 10 0 0',
        arrowVisible: false,
        menu: {
            cls: 'heading-menu',
            minWidth: 200,
            plain: true,
            border: false,
            bodyBorder: false,
            frame: false,
            shadow: false,
            mouseLeaveDelay: 0,
            defaults: {
                border: false,
                plugins: 'responsive',
                responsiveConfig: { 'width >= 1000': { hidden: true }, 'width < 1000': { hidden: false } }
            },
            items: [{
                text: 'Dashboard'.t(),
                href: '#'
            }, {
                text: 'Apps'.t(),
                href: '#apps' // href is not bindable in menu items, so no policy id passed from men uitem
            }, {
                text: 'Config'.t(),
                href: '#config'
            }, {
                text: 'Reports'.t(),
                href: '#reports'
            }, {
                xtype: 'menuseparator'
            }, {
                text: 'Sessions'.t(),
                href: '#sessions'
            }, {
                text: 'Hosts'.t(),
                href: '#hosts'
            }, {
                text: 'Devices'.t(),
                href: '#devices'
            }, {
                text: 'Users'.t(),
                href: '#users'
            }, {
                xtype: 'menuseparator'
            }, {
                text: 'Account Settings'.t(),
                hrefTarget: '_blank',
                href: Util.getStoreUrl() + '?action=my_account&' + Util.getAbout(),
                responsiveConfig: null
            }, {
                text: 'Logout'.t(),
                href: '/auth/logout?url=/admin&realm=Administrator',
                responsiveConfig: null
            }],
            listeners: {
                click: function (menu, item) {
                    // for touch devices this hack is required
                    if (Ext.supports.Touch) {
                        if (item.hrefTarget === '_blank') {
                            window.open(item.href);
                        } else {
                            document.location.href = item.href;
                        }
                    }
                }
            }
        }
    }]
});
Ext.define('Ung.view.main.Offline', {
    extend: 'Ext.window.Window',
    alias: 'widget.offline',

    title: 'Offline'.t(),
    modal: true,
    width: 700,
    height: 500,

    layout: 'fit',

    items: [{
        xtype: 'container',
        padding: 40,
        layout: { tyep: 'vbox', align: 'middle' },
        style: { background: '#FFF' },
        items: [{
            xtype: 'component',
            html: '<img src="/images/BrandingLogo.png?' + (new Date()).getTime() + '" style="max-width: 300px; max-height: 48px;" />',
            width: 400,
            height: 100
        }, {
            xtype: 'component',
            html: '<h3>' + 'Welcome!'.t() + '</h3>' +
                '<p>' + 'The installation is complete and ready for deployment. The next steps are registration and installing apps from the APPS menu.'.t() + '</p>' +
                '<p style="color: red;">' + 'Unfortunately, Your server was unable to connect to the internet.'.t() + '</p>' +
                '<p>' + 'Before Installing apps, this must be resolved.'.t() + '</p>' +
                '<p><strong>' + 'Possible Resolutions'.t() + '</strong></p>' +
                '<ol><li>' + 'Verify the network settings are correct and the Connectivity Test succeeds.'.t() + '</li>' +
                '<li>' + 'Verify that there are no upstream firewalls blocking HTTP access to the internet.'.t() + '</li>' +
                '<li>' + 'Verify the external interface has the correct IP and DNS settings.'.t() + '</li></ol>'
        }, {
            xtype: 'button',
            margin: '10 0',
            text: 'Open Network Settings'.t(),
            iconCls: 'fa fa-cog',
            href: '#config/network',
            hrefTarget: '_self',
            handler: function (btn) {
                btn.up('window').close();
                Ext.destroy(btn.up('window'));
            }
        }]
    }],
    buttons: [{
        text: 'Close'.t(),
        iconCls: 'fa fa-ban',
        handler: function (btn) {
            btn.up('window').close();
            Ext.destroy(btn.up('window'));
        }
    }]

});
Ext.define('Ung.view.main.RegistrationController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.registration',

    control: {
        '#auth': {
            beforeactivate: 'onBeforeActivateAuth'
        },
        '#register': {
            beforeactivate: 'onBeforeActivateRegister'
        },
        'textfield': {
            keyup: 'submitForm'
        }
    },

    onBeforeActivateAuth: function (auth) {
        this.getViewModel().set('error', null);
        auth.down('#loginForm').reset();
    },

    onBeforeActivateRegister: function (form) {
        this.getViewModel().set('error', null);
        form.reset();
    },

    submitForm: function (field, e) {
        var me = this;
        if (e.getCharCode() === 13) {
            var formCmp = field.up('form');
            if (formCmp.getForm().isValid()) {
                if (formCmp.name === 'loginForm') {
                    me.login(formCmp.down('#loginBtn'));
                }
                if (formCmp.name === 'registerForm') {
                    me.createAccount(formCmp.down('#registerBtn'));
                }
            }
        }
    },

    skipReg: function () {
        this.getView().close();
    },

    finishReg: function() {
        rpc.UvmContext.setRegistered(function(result, ex) {
            if (ex) { Util.handleException(ex); return; }
            rpc.isRegistered = true;
            Ext.fireEvent('postregistration');
        });
        this.getView().close();
        Ext.destroy(this.getView());
    },

    showLogin: function () {
        this.getView().down('#cards').setActiveItem(1);
    },

    showRegister: function () {
        this.getView().down('#cards').setActiveItem(2);
    },

    login: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            form = this.getView().down('#loginForm').getForm();

        vm.set('error', null);
        btn.setDisabled(true);

        if (form.isValid()) {
            me.getView().cloudManager.accountLogin(function(response, exception) {
                btn.setDisabled(false);
                if (exception) {
                    vm.set('error', exception);
                    return;
                }
                if (!response.success) {
                    vm.set('error', response.customerMessage.t());
                    return;
                }
                if (response.token) {
                    me.getView().email = form.findField('email').getValue();
                    me.getView().token = response.token;
                    me.getView().down('#cards').setActiveItem(3);
                }
            },
                form.findField('email').getValue(),
                form.findField('password').getValue(),
                rpc.serverUID,
                rpc.applianceModel,
                rpc.version,
                rpc.installType
            );
        }
    },

    createAccount: function (btn) {
        var me = this,
            vm = me.getViewModel(),
            form = me.getView().down('#register').getForm();

        vm.set('error', null);

        if (form.isValid()) {
            if (form.findField('password').getValue() !== form.findField('passwordConfirm').getValue()) {
                vm.set('error', '"Confirm password" must match the "Password" field.'.t());
                return;
            }
            btn.setDisabled(true);
            me.getView().cloudManager.accountCreate(function(response, exception) {
                    btn.setDisabled(false);
                    if (exception) {
                        console.log(exception);
                        vm.set('error', exception);
                        return;
                    }
                    if (!response.success) {
                        vm.set('error', response.customerMessage.t());
                        return;
                    }
                    if (response.token) {
                        me.getView().email = form.findField('email').getValue();
                        me.getView().token = response.token;
                        me.getView().down('#cards').setActiveItem(3);
                    }
                },
                form.findField('email').getValue(),
                form.findField('password').getValue(),
                form.findField('firstName').getValue(),
                form.findField('lastName').getValue(),
                form.findField('companyName').getValue(),
                rpc.serverUID,
                rpc.applianceModel,
                rpc.version,
                rpc.installType
            );
        }
    }
});
Ext.define('Ung.view.main.Support', {
    extend: 'Ext.window.Window',
    alias: 'widget.support',

    title: 'Contact Untangle Support'.t(),

    name: 'support',
    helpSource: 'support',

    controller: 'support',

    modal: true,
    closable: false,
    width: 800,
    height: 210,
    shadow: false,
    resizable: false,
    draggable: false,
    collapsible: false,

    layout: 'fit',

    defaults: {
        border: false
    },

    items: [{
        xtype: 'panel',
        itemId: 'supportEnabled',
        border: false,
        layout: 'anchor',
        buttonAlign: 'right',
        buttons:[{
            xtype: 'button',
            text: '<strong>' + 'Cancel'.t() + '</strong>',
            iconCls: 'fa fa-ban',
            handler: 'cancelHandler'
        },{
            xtype: 'button',
            text: '<strong>' + 'No - Do Not Enable Support Access'.t() + '</strong>',
            iconCls: 'fa fa-check',
            handler: 'noSupportHandler'
        }, {
            xtype: 'button',
            text: '<strong>' + 'Yes - Enable Support Access'.t() + '</strong>',
            iconCls: 'fa fa-save',
            handler: 'yesSupportHandler'
        }],
        items: [{
            xtype: 'component',
            cls: 'welcome',
            padding: 10,
            html: '<h3>' + 'Remote Support Access is not enabled'.t() + '</h3>' +
                '<p>' + 'Enabling remote support access is recommended for better and fast support.'.t() + '</p>' +
                '<p>' + 'Would you like enable the support team to access your server remotely?'.t() + '</p>'
        }]
    }]
});
Ext.define('Ung.view.main.SupportController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.support',

    cancelHandler: function (btn) {
        btn.up('window').close();
    },

    noSupportHandler: function (btn) {
        Ung.app.getMainView().getController().supportLaunch();
        btn.up('window').close();
    },

    yesSupportHandler: function (btn) {
        var me = this;
        Ung.app.getMainView().getController().supportLaunch(); // open support before saving to prevent popup blocker
        me.getView().setLoading(true);
        Rpc.asyncData('rpc.systemManager.getSettings')
            .then(function (result) {
                result.supportEnabled = true;
                result.cloudEnabled = true;
                Rpc.asyncData('rpc.systemManager.setSettings', result)
                .then(function() {
                    Util.successToast('Remote Support Access enabled!');
                    btn.up('window').close();
                }, function (ex) {
                    console.error(ex);
                    Util.handleException(ex);
                });
            });
    }
});
Ext.define('Ung.view.main.UserLicenseMessages', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.userLicenseMessages',

    dock: 'top',

    controller: 'userLicenseMessages',

    dockedItems: [{
        xtype: 'container',
        itemId: '_userLicenseMessages',
    }],
});Ext.define('Ung.view.main.UserLicenseMessagesController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.userLicenseMessages',

    listen: {
        global: {
            loadUserLicenseMessages: 'loadUserLicenseMessages'
        }
    },

    loadUserLicenseMessages: function () {
        var me = this, vm = me.getViewModel();

        Rpc.asyncData('rpc.UvmContext.licenseManager.getUserLicenseMessages')
        .then(function(result){
            if(Util.isDestroyed(vm)) {
                return;
            }
            var userLicenseMessages = result.list;

            messagesCmps = [];

            Ext.Array.each(userLicenseMessages, function(msg) {
                var icon = '<i class="fa fa-info-circle"></i> ';
                var color = 'black';
                switch(msg.type) {
                    case 'ALERT':
                        icon = '<i class="fa fa-exclamation-triangle"></i> ';
                        color = '#F44336';
                        break;
                    case 'WARNING':
                        icon = '<i class="fa fa-exclamation"></i> ';
                        color = "#FF6600";
                        break;
                }
                var hasClosure = msg.hasClosure;
                var message = msg.message;
                var msgItem = {
                    xtype: 'container',
                    layout: 'hbox',
                    border: 1,
                    style: {
                        borderColor: 'black',
                        borderStyle: 'solid'
                    },
                    items: [
                        {
                            xtype: 'component',
                            style: { 
                                fontSize: '12px', 
                                color: color, 
                                padding: '15px',
                                textAlign: 'center',
                            },
                            html: icon + message.t(),
                            flex: 1
                        },
                        {
                            xtype: 'button',
                            iconCls: 'fa fa-window-close',
                            hidden: !hasClosure,
                            handler: 'removeUserLicenseMessage'
                        }
                    ]
                };

                if (msg.showAsBanner) {
                    messagesCmps.push(msgItem);
                }
            });

            // remove all current UserLicenseMessages messages before adding new ones
            me.getView().down('#_userLicenseMessages').removeAll();
            me.getView().down('#_userLicenseMessages').add(messagesCmps);
        }, function(ex){
            handleException(ex);
        }); 
    },

    removeUserLicenseMessage: function(cmp) {
        cmp.up().destroy();  
    }

});// test
Ext.define('Ung.Application', {
    extend: 'Ext.app.Application',
    namespace: 'Ung',
    autoCreateViewport: false,
    name: 'Ung',
    rpc: null,
    controllers: ['Global'],
    defaultToken : '',
    mainView: 'Ung.view.main.Main',
    context: 'ADMIN', // set the app context ADMIN or REPORTS
    conditionsContext: 'REPORTS', // can be REPORTS or DASHBOARD because they don't share conditions

    /**
     * used to know when data is loaded for the first time
     * when app has loaded and fetched initial resources (e.g. reports)
     * */
    initialLoad: false,

    launch: function () {

        // Build policies tree
        Ext.getStore('policies').loadData(Rpc.directData('rpc.appsViews'));
        Ext.getStore('policiestree').build();

        var isRestricted = Rpc.directData('rpc.UvmContext.licenseManager.isRestricted');

        Ext.Deferred.parallel([
            Rpc.directPromise('rpc.companyName'),
            Rpc.directPromise('rpc.hostname'),
        ], this)
        .then(function(result){
            if(Util.isDestroyed(window)){
                return;
            }
            var hostnameText = '';
            if (!isRestricted) {
                hostnameText = result[1] ? ' - ' + result[1] : ''; 
            }
            window.document.title = result[0] + hostnameText;
        }, function(ex) {
        });

        Ext.get('app-loader').destroy();

        // Start metrics
        Metrics.start();

        Ext.fireEvent('afterlaunch'); // used in Main view ctrl

        document.addEventListener('paste', function(evt){
            var currentHash =  window.location.hash;
            if (currentHash != ''){
                return;
            }
            var url = evt.clipboardData.getData('text/plain');
            if(url && url.indexOf('#') > -1){
                var hashStart=url.substring(url.indexOf('#'));
                Ung.app.redirectTo(hashStart);
            }
        });

        Ung.AppIframe = Ext.create('Ung.view.main.IframePanel', {
            itemId: 'globalIframe',
            iframeUrl: '/console',
            hidden: true
        });
    },

    /**
     * Method called when app loads or when
     * Reports App is installed/removed or enabled/disabled
     */
    reportscheck: function () {
        var mainView = Ung.app.getMainView();

        if(!Rpc.directData('rpc.appManager.app', 'reports')){
            rpc.reportsManager = null;
            Ext.getStore('reports').loadData([]);
            Ext.getStore('reportstree').build();

            if (!Ung.app.initialLoad) {
                Ung.app.initialLoad = true;
                Ext.fireEvent('initialload');
            }

            mainView.getViewModel().set('reportsAppStatus', {
                installed: false,
                enabled: false
            });
        }else{
            rpc.reportsManager = Rpc.directData('rpc.appManager.app("reports").getReportsManager');

            Ext.Deferred.parallel([
                Rpc.asyncPromise('rpc.reportsManager.getReportEntries'),
                Rpc.asyncPromise('rpc.reportsManager.getCurrentApplications')
            ]).then(function (result) {
                if(Util.isDestroyed(mainView)){
                    return;
                }
                if (result[0]) { Ext.getStore('reports').loadData(result[0].list); }
                if (result[1]) { Ext.getStore('categories').loadData(Ext.Array.merge(Util.baseCategories, result[1].list)); }

                // build reports tree
                Ext.getStore('reportstree').build();

                /**
                 * this is needed to initialize global conditions
                 * because the query binding fires before reports have been loaded
                 */
                if (!Ung.app.initialLoad) {
                    Ung.app.initialLoad = true;
                    Ext.fireEvent('initialload');
                }

                /**
                 * Set the reportsAppStatus viewmodel prop.
                 * This is watched in different places when changes, and the view updates based on the status
                 */
                mainView.getViewModel().set('reportsAppStatus', {
                    installed: true,
                    enabled: Rpc.directData('rpc.appManager.app("reports").getRunState') === 'RUNNING'
                });
            }, function (ex) {
            });

        }
    }
});
