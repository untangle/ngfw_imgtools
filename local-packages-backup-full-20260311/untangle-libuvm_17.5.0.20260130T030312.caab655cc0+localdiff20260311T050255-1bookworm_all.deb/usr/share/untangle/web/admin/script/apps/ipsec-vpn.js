Ext.define('Ung.apps.ipsecvpn.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-ipsec-vpn',
    controller: 'app-ipsec-vpn',

    viewModel: {
        data: {
            autoRefresh: false,
            tunnelStatusData: [],
            virtualUserData: [],
            wanListData: []
        },

        stores: {

            tunnelList: {
                data: '{settings.tunnels.list}'
            },

            networkList: {
                data: '{settings.networks.list}'
            },

            listenList: {
                data: '{settings.virtualListenList.list}'
            },

            tunnelStatusStore: {
                data: '{tunnelStatusData}',
                fields: [{
                    name: 'mode'
                }, {
                    name: 'src',
                    sortType: 'asIp'
                }, {
                    name: 'dst',
                    sortType: 'asIp'
                }, {
                    name: 'tmplSrc',
                }, {
                    name: 'tmplDst',
                }, {
                    name: 'proto',
                }, {
                    name: 'inBytes',
                    sortType: 'asInt'
                }, {
                    name: 'outBytes',
                    sortType: 'asInt'
                }]
            },

            virtualUserStore: {
                data: '{virtualUserData}',
                fields: [{
                    name: 'clientAddress',
                    sortType: 'asIp'
                }, {
                    name: 'clientProtocol',
                }, {
                    name: 'clientUsername',
                }, {
                    name: 'netInterface',
                }, {
                    name: 'sessionCreation',
                    convert:  Converter.convertDate,
                }, {
                    name: 'sessionElapsed',
                    sortType: 'asInt'
                }]
            },

            wanListStore: {
                fields: [ 'index' , 'address' , 'name' ],
                data: '{wanListData}'
            },

            activeWanAddress: '',

            P1CipherStore: {
                fields: [ 'name', 'value' ],
                data: [
                    { name: '3DES', value: '3des' },
                    { name: 'AES-128', value: 'aes128' },
                    { name: 'AES-128 GCM w/ 8 bit ICV', value: 'aes128gcm8' },
                    { name: 'AES-128 GCM w/ 12 bit ICV', value: 'aes128gcm12' },
                    { name: 'AES-128 GCM w/ 16 bit ICV', value: 'aes128gcm16' },
                    { name: 'AES-128 GCM w/ 64 bit ICV', value: 'aes128gcm64' },
                    { name: 'AES-128 GCM w/ 96 bit ICV', value: 'aes128gcm96' },
                    { name: 'AES-128 GCM w/ 128 bit ICV', value: 'aes128gcm128' },
                    { name: 'AES-256', value: 'aes256' },
                    { name: 'AES-256 GCM w/ 8 bit ICV', value: 'aes256gcm8' },
                    { name: 'AES-256 GCM w/ 12 bit ICV', value: 'aes256gcm12' },
                    { name: 'AES-256 GCM w/ 16 bit ICV', value: 'aes256gcm16' },
                    { name: 'AES-256 GCM w/ 64 bit ICV', value: 'aes256gcm64' },
                    { name: 'AES-256 GCM w/ 96 bit ICV', value: 'aes256gcm96' },
                    { name: 'AES-256 GCM w/ 128 bit ICV', value: 'aes256gcm128' },
                    { name: 'Camellia', value: 'camellia' },
                    { name: 'Blowfish', value: 'blowfish' },
                    { name: 'Twofish', value: 'twofish' },
                    { name: 'Serpent', value: 'serpent' }
                ]
            },

            P1HashStore: {
                fields: [ 'name', 'value' ],
                data: [
                    { name: 'MD5', value: 'md5' },
                    { name: 'SHA-1', value: 'sha1' },
                    { name: 'SHA-256', value: 'sha2_256' },
                    { name: 'SHA-384', value: 'sha2_384' },
                    { name: 'SHA-512', value: 'sha2_512' }
                ]
            },

            P1GroupStore: {
                fields: [ 'name', 'value' ],
                data: [
                    { name: '1 (modp768)', value: 'modp768' },
                    { name: '2 (modp1024)', value: 'modp1024' },
                    { name: '5 (modp1536)', value: 'modp1536' },
                    { name: '14 (modp2048)', value: 'modp2048' },
                    { name: '15 (modp3072)', value: 'modp3072' },
                    { name: '16 (modp4096)', value: 'modp4096' },
                    { name: '17 (modp6144)', value: 'modp6144' },
                    { name: '18 (modp8192)', value: 'modp8192' },
                    { name: '22 (modp1024s160)', value:'modp1024s160' },
                    { name: '23 (modp2048s224)', value:'modp2048s224' },
                    { name: '24 (modp2048s256)', value: 'modp2048s256' },
                    { name: '25 (ecp192)', value: 'ecp192' },
                    { name: '26 (ecp224)', value: 'ecp224' },
                    { name: '19 (ecp256)', value: 'ecp256' },
                    { name: '20 (ecp384)', value: 'ecp384' },
                    { name: '21 (ecp521)', value: 'ecp521' },
                    { name: '27 (ecp224pb)', value: 'ecp224bp' },
                    { name: '28 (ecp256bp)', value: 'ecp256bp' },
                    { name: '29 (ecp384bp)', value: 'ecp384bp' },
                    { name: '30 (ecp512bp)', value: 'ecp512bp' }
                ]
            },

            P2CipherStore: {
                fields: [ 'name', 'value' ],
                data: [
                    { name: '3DES', value: '3des' },
                    { name: 'AES-128', value: 'aes128' },
                    { name: 'AES-128 GCM w/ 8 bit ICV', value: 'aes128gcm8' },
                    { name: 'AES-128 GCM w/ 12 bit ICV', value: 'aes128gcm12' },
                    { name: 'AES-128 GCM w/ 16 bit ICV', value: 'aes128gcm16' },
                    { name: 'AES-128 GCM w/ 64 bit ICV', value: 'aes128gcm64' },
                    { name: 'AES-128 GCM w/ 96 bit ICV', value: 'aes128gcm96' },
                    { name: 'AES-128 GCM w/ 128 bit ICV', value: 'aes128gcm128' },
                    { name: 'AES-256', value: 'aes256' },
                    { name: 'AES-256 GCM w/ 8 bit ICV', value: 'aes256gcm8' },
                    { name: 'AES-256 GCM w/ 12 bit ICV', value: 'aes256gcm12' },
                    { name: 'AES-256 GCM w/ 16 bit ICV', value: 'aes256gcm16' },
                    { name: 'AES-256 GCM w/ 64 bit ICV', value: 'aes256gcm64' },
                    { name: 'AES-256 GCM w/ 96 bit ICV', value: 'aes256gcm96' },
                    { name: 'AES-256 GCM w/ 128 bit ICV', value: 'aes256gcm128' },
                    { name: 'Camellia', value: 'camellia' },
                    { name: 'Blowfish', value: 'blowfish' },
                    { name: 'Twofish', value: 'twofish' },
                    { name: 'Serpent', value: 'serpent' }
                ]
            },

            P2HashStore: {
                fields: [ 'name', 'value' ],
                data: [
                    { name: 'MD5', value: 'md5' },
                    { name: 'SHA-1', value: 'sha1' },
                    { name: 'SHA-256', value: 'sha2_256' },
                    { name: 'SHA-384', value: 'sha2_384' },
                    { name: 'SHA-512', value: 'sha2_512' },
                    { name: 'AES XCBC', value: 'aesxcbc' },
                    { name: '128-bit AES-GMAC', value: 'aes128gmac' },
                    { name: '192-bit AES-GMAC', value: 'aes192gmac' },
                    { name: '256-bit AES-GMAC', value: 'aes256gmac' }
                ]
            },

            P2GroupStore: {
                fields: [ 'name', 'value' ],
                data: [
                    { name: '0 (disabled)', value: 'disabled' },
                    { name: '1 (modp768)', value: 'modp768' },
                    { name: '2 (modp1024)', value: 'modp1024' },
                    { name: '5 (modp1536)', value: 'modp1536' },
                    { name: '14 (modp2048)', value: 'modp2048' },
                    { name: '15 (modp3072)', value: 'modp3072' },
                    { name: '16 (modp4096)', value: 'modp4096' },
                    { name: '17 (modp6144)', value: 'modp6144' },
                    { name: '18 (modp8192)', value: 'modp8192' },
                    { name: '22 (modp1024s160)', value:'modp1024s160' },
                    { name: '23 (modp2048s224)', value:'modp2048s224' },
                    { name: '24 (modp2048s256)', value: 'modp2048s256' },
                    { name: '25 (ecp192)', value: 'ecp192' },
                    { name: '26 (ecp224)', value: 'ecp224' },
                    { name: '19 (ecp256)', value: 'ecp256' },
                    { name: '20 (ecp384)', value: 'ecp384' },
                    { name: '21 (ecp521)', value: 'ecp521' },
                    { name: '27 (ecp224pb)', value: 'ecp224bp' },
                    { name: '28 (ecp256bp)', value: 'ecp256bp' },
                    { name: '29 (ecp384bp)', value: 'ecp384bp' },
                    { name: '30 (ecp512bp)', value: 'ecp512bp' }
                ]
            }
        }
    },

    items: [
        { xtype: 'app-ipsec-vpn-status' },
        { xtype: 'app-ipsec-vpn-ipsecoptions' },
        { xtype: 'app-ipsec-vpn-ipsectunnels' },
        { xtype: 'app-ipsec-vpn-vpnconfig' },
        { xtype: 'app-ipsec-vpn-grenetworks' },
        { xtype: 'app-ipsec-vpn-ipsecstate' },
        { xtype: 'app-ipsec-vpn-ipsecpolicy' },
        { xtype: 'app-ipsec-vpn-ipseclog' },
        { xtype: 'app-ipsec-vpn-l2tplog' }
    ],

    statics:{
        leftRenderer: function(value, meta, record, rowIndex, columnIndex, store, table){
            var vm = table.up('apppanel').getViewModel();
            if(value == 'active_wan_address'){
                return Ext.String.format('{0} [{1}]', 'Active WAN'.t(), vm.get('activeWanAddress'));
            }
            return value;
        },
        rightRenderer: function(value, meta, record, rowIndex, columnIndex, store, table){
            if(value == '%any'){
                return 'Any Remote Host'.t();
            }
            return value;
        },
        sourceRenderer: function(value, meta, record, rowIndex, columnIndex, store, table){
            if(value == '%config'){
                return 'Request From Peer'.t();
            }
            return value;
        }
    }
});
Ext.define('Ung.apps.ipsecvpn.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-ipsec-vpn',

    control: {
        '#': {
            afterrender: 'getSettings'
        },
        '#status': {
            beforerender: 'onStatusBeforeRender'
        },
        '#ipsec-state': { afterrender: 'refreshIpsecStateInfo' },
        '#ipsec-policy': { afterrender: 'refreshIpsecPolicyInfo' },
        '#ipsec-log': { afterrender: 'refreshIpsecSystemLog' },
        '#l2tp-log': { afterrender: 'refreshIpsecVirtualLog' },
    },

    onStatusBeforeRender: function() {
        var me = this,
            vm = this.getViewModel();
        vm.bind('{state}', function(state) {
            if (state.get('on') ){
                me.getVirtualUsers();
                me.getTunnelStatus();
            }
        });
    },

    getVirtualUsers: function() {
        var grid = this.getView().down('#virtualUsers'),
            vm = this.getViewModel();

        grid.setLoading(true);
        Rpc.asyncData(this.getView().appManager, 'getVirtualUsers')
        .then( function(result){
            if(Util.isDestroyed(grid, vm)){
                return;
            }

            vm.set('virtualUserData', result.list);

            grid.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getTunnelStatus: function() {
        var grid = this.getView().down('#tunnelStatus'),
            vm = this.getViewModel();

        grid.setLoading(true);
        Rpc.asyncData(this.getView().appManager, 'getTunnelStatus')
        .then( function(result){
            if(Util.isDestroyed(grid, vm)){
                return;
            }

            result.list.forEach(function(status){
                if(status['dst'] == '%any'){
                    status['dst'] = 'Any Remote Host'.t();
                }
                if(status['leftSourceIp'] == '%config'){
                    status['leftSourceIp'] = 'Request From Peer'.t();
                }
            });

            vm.set('tunnelStatusData', result.list);

            grid.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getSettings: function() {
        var me = this, v = this.getView(), vm = this.getViewModel();


        var sequence = [
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise('rpc.networkManager.getNetworkSettings'),
            Rpc.asyncPromise('rpc.networkManager.getInterfaceStatus'),
            Rpc.asyncPromise(v.appManager, 'getActiveWanAddress')
        ];
        var wanFailoverApp = Rpc.directData('rpc.appManager.app', 'wan-failover');
        if(wanFailoverApp != null){
            sequence.push(Rpc.asyncPromise(wanFailoverApp, 'getRunState'));
        }

        v.setLoading(true);
        Ext.Deferred.sequence(sequence).then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            vm.set('activeWanAddress', result[3]);
            var wanListData = me.calculateNetworks( result[1], result[2] );
            if(result[4] && result[4] == 'RUNNING'){
                wanListData.push([wanListData.length, 'active_wan_address', 'Active WAN'.t()]);
            }
            vm.set('wanListData', wanListData);

            var settings = result[0];
            var x,y;
            for( x = 0 ; x < settings.tunnels.list.length; x++ ) {
                settings.tunnels.list[x].localInterface = 0;
                for( y = 0 ; y < wanListData.length ; y++) {
                    if (settings.tunnels.list[x].left == wanListData[y][1]) {
                        settings.tunnels.list[x].localInterface = wanListData[y][0];
                    }
                }
            }

            for( x = 0 ; x < settings.networks.list.length; x++ ) {
                settings.networks.list[x].localInterface = 0;
                for( y = 0 ; y < wanListData.length ; y++) {
                    if (settings.networks.list[x].localAddress == wanListData[y][1]) {
                        settings.networks.list[x].localInterface = wanListData[y][0];
                    }
                }
            }

            vm.set('settings', settings);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function() {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        var changes = Util.updateListStoresToSettings(v.query('ungrid'), vm, {
            'settings.tunnels.list': {
                'enabledField': 'active'
            }
        });

        // Build list of sequential commands to run
        var sequence = [
            Rpc.directPromise(v.appManager, 'setSettings', vm.get('settings'))
        ];

        if('settings.tunnels.list' in changes){
            changes['settings.tunnels.list'].deleted.forEach(function(jsonRecord){
                var recordObj = JSON.parse(jsonRecord);
                sequence.unshift(Rpc.directPromise(v.appManager, 'deleteTunnel', me.getTunnelWorkMName(recordObj['id'], recordObj['description'])));
            });
        }

        v.setLoading(true);
        Ext.Deferred.sequence(sequence).then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    /**
     * Return configu/shell-friendly workname of tunnel from id and description.
     * @param integer id Numeric id
     * @param String description Description
     * @return String of configu/shell-friendly name.
     */
    getTunnelWorkMName: function(id, description){
        return Ext.String.format('UT{0}_{1}', id, description.replace(/\W/g, "-"));
    },

    calculateNetworks: function(netSettings, intStatus) {
        var leftDefault = '0.0.0.0';
        var leftSubnetDefault = '0.0.0.0/0';
        var wanListData = [];
        var x,y;

        // we need the interface list and the status list so we can get the IP address of active interfaces
        var counter = 0;

        wanListData.push([ counter++ , '' , 'Custom'.t() ]);

        // build the list of active WAN networks for the interface combo box and set the defaults for left and leftSubnet
        for( x = 0 ; x <  netSettings.interfaces.list.length ; x++ )
        {
            var device = netSettings.interfaces.list[x];

            if (! device.interfaceId) { continue; }
            if (device.disabled) { continue; }

            for( y = 0 ; y < intStatus.list.length ; y++ )
            {
                var status = intStatus.list[y];

                if (! status.v4Address) { continue; }
                if (! status.interfaceId) { continue; }
                if (device.interfaceId !== status.interfaceId) { continue; }

                // found a WAN device
                if (device.isWan)
                {
                    // add the address and name to the WAN list
                    wanListData.push([ counter++ , status.v4Address , device.name ]);

                    // save the first WAN address to use as the default for new tunnels
                    if (leftDefault === '0.0.0.0') { leftDefault = status.v4Address; }
                }

                // found a LAN devices
                else
                {
                    // save the first LAN address to use as the default for new tunnels
                    if (leftSubnetDefault === '0.0.0.0/0') { leftSubnetDefault = (status.v4Address + '/' + status.v4PrefixLength); }
                }
            }
        }

        Ung.util.Util.setAppStorageValue('ipsec.leftDefault', leftDefault);
        Ung.util.Util.setAppStorageValue('ipsec.leftSubnetDefault', leftSubnetDefault);

        return(wanListData);
    },

    configureAuthTarget: function(btn)
    {
        var vm = this.getViewModel(),
            policyId = vm.get('policyId'),
            authType = vm.get('settings.authenticationType');

        switch (authType) {
            case 'LOCAL_DIRECTORY': Ung.app.redirectTo('#config/local-directory'); break;
            case 'RADIUS_SERVER': Ung.app.redirectTo('#apps/' + policyId + '/directory-connector/radius'); break;
            default: return;
        }
    },

    refreshIpsecStateInfo: function (cmp) {
        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var target = v.down('textarea');

        target.setValue('');

        v.setLoading(true);
        Rpc.asyncData( v.up('app-ipsec-vpn').appManager, 'getStateInfo')
        .then(function(result){
            if(Util.isDestroyed(v, target)){
                return;
            }
            target.setValue(result);
            v.setLoading(false);
        });
    },

    refreshIpsecPolicyInfo: function (cmp) {
        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var target = v.down('textarea');

        target.setValue('');

        v.setLoading(true);
        Rpc.asyncData( v.up('app-ipsec-vpn').appManager, 'getPolicyInfo')
        .then(function(result){
            if(Util.isDestroyed(v, target)){
                return;
            }
            target.setValue(result);
            v.setLoading(false);
        });
    },

    refreshIpsecSystemLog: function (cmp) {
        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var target = v.down('textarea');

        target.setValue('');

        v.setLoading(true);
        Rpc.asyncData( v.up('app-ipsec-vpn').appManager, 'getLogFile')
        .then(function(result){
            if(Util.isDestroyed(v, target)){
                return;
            }
            target.setValue(result);
            v.setLoading(false);
        });
    },

    refreshIpsecVirtualLog: function (cmp) {
        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var target = v.down('textarea');

        target.setValue('');

        v.setLoading(true);
        Rpc.asyncData( v.up('app-ipsec-vpn').appManager, 'getVirtualLogFile')
        .then(function(result){
            if(Util.isDestroyed(v, target)){
                return;
            }
            target.setValue(result);
            v.setLoading(false);
        });
    },

    disconnectUser: function(view, row, colIndex, item, e, record) {
        var me = this, v = this.getView(), vm = this.getViewModel();

        var target = v.down('#virtualUsers');
        target.setLoading('Disconnecting...'.t());
        Rpc.asyncData( v.appManager, 'virtualUserDisconnect', record.get("clientAddress"), record.get("clientUsername"))
        .then( function(result){
            if(Util.isDestroyed(target, me)){
                return;
            }

            // this gives the app a couple seconds to process the disconnect before we refresh the list
            setTimeout(function() {
                if(Util.isDestroyed(target, me)){
                    return;
                }
                me.getVirtualUsers();
                target.setLoading(false);
            },2000);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                target.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    statics:{
        modeRenderer: function(value){
            var showtxt = 'Inactive'.t(),
                showico = 'fa fa-circle fa-gray';
            if (value.toLowerCase() === 'active') {
                showtxt = 'Active'.t();
                showico = 'fa fa-circle fa-green';
            }
            if (value.toLowerCase() === 'unknown') {
                showtxt = 'Unknown'.t();
                showico = 'fa fa-exclamation-triangle fa-orange';
            }
            return '<i class="' + showico + '">&nbsp;&nbsp;</i>' + showtxt;
        }
    }
});

Ext.define('Ung.apps.ipsecvpn.cmp.TunnelRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unipsecvpntunnelsrecordeditor',

    controller: 'unipsecvpntunnelsrecordeditorcontroller',
});

Ext.define('Ung.apps.ipsecvpn.cmp.TunnelRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unipsecvpntunnelsrecordeditorcontroller',

    onAfterRender: function(cmp){
        var v = this.getView(),
            vm = this.getViewModel(),
            record = vm.get('record');

        if(record.get('right') == '%any'){
            record.set('rightAny', true);
        }
        if(record.get('leftSourceIp') == '%config'){
            record.set('leftSourceIpAny', true);
        }
        this.callParent([cmp]);
    },

    lastRight: null,
    lasRunMode: null,
    anyRemoteHostChange: function(cmp, newValue, oldValue){
        var me = this,
            record = cmp.bind.value.owner.get('record');

        if(newValue == true){
            if(record.get('right') != '%any'){
                me.lastRight = record.get('right');
            }
            if(record.get('runmode') != 'route'){
                me.lastRunMode = record.get('runmode');
            }
            record.set('right', '%any');
            record.set('runmode', 'route');
        }else{
            record.set('right', me.lastRight != null ? me.lastRight : '');
            record.set('runmode', me.lastRunMode != null ? me.lastRunMode : 'start');
        }
    },

    lastLeftSourceIp: null,
    anyLeftSourceChange: function(cmp, newValue, oldValue){
        var me = this,
            record = cmp.bind.value.owner.get('record');

        if(newValue == true){
            if(record.get('leftSourceIp') != '%config'){
                me.lastLeftSourceIp = record.get('leftSourceIp');
            }
            record.set('leftSourceIp', '%config');
        }else{
            record.set('leftSourceIp', me.lastLeftSourceIp != null ? me.lastLeftSourceIp : '');
        }
    },

    interfaceChange: function(cmp, newValue, oldValue){
        var vm = cmp.ownerCt.ownerCt.ownerCt.getViewModel();
        var wanlist = vm.get('wanListData');
        var recordField = cmp.ownerCt.ownerCt.down("[itemId=externalAddress]");
        var displayField = cmp.ownerCt.ownerCt.down("[itemId=externalAddressCurrent]");
        var value = '';
        var displayValue = '';
        for( var i = 0 ; i < wanlist.length ; i++ ) {
            if(newValue != i){
                continue;
            }
            value = wanlist[i][1];
            if(value == ''){
                value = recordField.getValue();
                if(value == 'active_wan_address'){
                    value = vm.get('activeWanAddress');
                }
            }else if(value == 'active_wan_address'){
                displayValue = vm.get('activeWanAddress');
            }else{
                displayValue = value;
            }
            displayField.setValue(displayValue);
            if (newValue == wanlist[i][0]){
                recordField.setValue(value);
            }
        }

    }
});
Ext.define('Ung.apps.ipsecvpn.view.GreNetworks', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-grenetworks',
    itemId: 'gre-networks',
    title: 'GRE Networks'.t(),
    viewModel: true,
    withValidation: true,
    bodyPadding: 10,
    scrollable: true,

    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'The GRE Networks tab contains configuration options for connecting this server to other servers and networks using the GRE protocol.'.t()
    }],

    items: [{
        xtype: 'textfield',
        bind: '{settings.virtualNetworkPool}',
        vtype: 'cidrBlock',
        allowBlank: false,
        labelWidth: 200,
        // padding: '10 0 0 10',
        fieldLabel: 'GRE Address Pool'.t()
    }, {
        xtype: 'displayfield',
        // padding: '10 0 0 10',
        value: 'Each Remote Network will have a corresponding GRE interface created on this server, with each interface being assigned an IP address from this pool.'.t()
    }, {
        xtype: 'fieldset',
        title: 'GRE Networks'.t(),
        padding: 10,

        layout: {
            type: 'vbox',
            align: 'stretch'
        },

        items: [{
            xtype: 'app-ipsecvpn-gre-networks-grid',
        }]
    }]
});


Ext.define('Ung.apps.ipsecvpn.view.GreNetworksGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-ipsecvpn-gre-networks-grid',
    itemId: 'gre-networks-grid',

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    emptyText: 'No GRE Networks Defined'.t(),

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',
    listProperty: 'settings.networks.list',
    emptyRow: {
        javaClass: 'com.untangle.app.ipsec_vpn.IpsecVpnNetwork',
        'active': true,
        'localAddress': '0.0.0.0',
        'remoteAddress': '0.0.0.0',
        'remoteNetworks': '0.0.0.0/24',
        'description': '',
        'ttl': 64,
        'mtu': 1476
        },

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    bind: '{networkList}',

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'active',
        resizable: false
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'description'
    }, {
        header: 'External IP'.t(),
        width: Renderer.ipWidth,
        dataIndex: 'localAddress',
    }, {
        header: 'Remote Host'.t(),
        width: Renderer.hostnameWidth,
        dataIndex: 'remoteAddress'
    }, {
        header: 'Remote Networks'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'remoteNetworks'
    }, {
        header: 'TTL'.t(),
        width: Renderer.portWidth,
        dataIndex: 'ttl'
    }, {
        header: 'MTU'.t(),
        width: Renderer.portWidth,
        dataIndex: 'mtu'
    }],

    editorFields: [{
        fieldLabel: 'Enabled'.t(),
        bind: '{record.active}',
        xtype: 'checkbox'
    }, {
        fieldLabel: 'Description'.t(),
        bind: '{record.description}',
        xtype: 'textfield',
    }, {
        fieldLabel: 'Interface'.t(),
        xtype: 'combobox',
        bind: {
            store: '{wanListStore}',
            value: '{record.localInterface}'
        },
        allowblank: true,
        editable: false,
        queryMode: 'local',
        displayField: 'name',
        valueField: 'index',
            listeners: {
                change: function(cmp, nval, oval, opts) {
                    var wanlist = this.ownerCt.ownerCt.getViewModel().get('wanListData'); // FIXME - this feels really ugly
                    var finder = this.ownerCt.down("[fieldIndex='externalAddress']"); // FIXME - this feels ugly too
                    for( var i = 1 ; i < wanlist.length ; i++ ) {
                        if (nval == wanlist[i][0]) finder.setValue(wanlist[i][1]);
                    }
                }
            }
    }, {
        fieldLabel: 'External IP'.t(),
        fieldIndex: 'externalAddress',
        bind: {
            value: '{record.localAddress}',
            disabled: '{record.localInterface != 0}'
        },
        xtype: 'textfield',
        vtype: 'ipAddress'
    }, {
        fieldLabel: 'Remote Host'.t(),
        bind: '{record.remoteAddress}',
        xtype: 'textfield',
        vtype: 'ipAddress'
    }, {
        fieldLabel: 'Remote Networks'.t(),
        bind: '{record.remoteNetworks}',
        xtype: 'textarea',
        vtype: 'cidrBlockArea',
        width: 250,
        height: 200
    }, {
        fieldLabel: 'TTL'.t(),
        bind: '{record.ttl}',
        xtype: 'numberfield',
    }, {
        fieldLabel: 'MTU'.t(),
        bind: '{record.mtu}',
        xtype: 'numberfield'
    }]

});
Ext.define('Ung.apps.ipsecvpn.view.IpsecLog', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-ipseclog',
    itemId: 'ipsec-log',
    title: 'IPsec Log'.t(),
    layout: 'fit',
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'button',
        iconCls: 'fa fa-refresh',
        text: 'Refresh',
        target: 'ipsecSystemLog',
        handler: 'refreshIpsecSystemLog'
    }],

    items: [{
        xtype: 'textarea',
        readOnly: true,
        itemId: 'ipsecSystemLog',
        spellcheck: false,
        padding: 0,
        border: false,
        bind: '{ipsecSystemLog}',
        fieldStyle: {
            'fontFamily'   : 'courier new',
            'fontSize'     : '12px'
        }
    }]
});
Ext.define('Ung.apps.ipsecvpn.view.IpsecOptions', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-ipsecoptions',
    itemId: 'ipsec-options',
    title: 'IPsec Options'.t(),
    scrollable: true,
    withValidation: false,
    bodyPadding: 10,

    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'The IPsec Options tab contains common settings that apply to all IPsec traffic.'.t()
    }],

    items: [{
        xtype:'combobox',
        fieldLabel: "Unique ID's".t(),
        labelWidth: 180,
        editable: false,
        width: 400,
        bind: '{settings.uniqueIds}',
        store: [['yes','Yes'],['no','No'],['never','Never'],['keep','Keep']]
    }, {
        xtype: 'component',
        margin: '0 0 20 10',
        html: 'The recommended default value is Yes unless you have a specific reason to change this setting.'.t(),
    }, {
        xtype: 'checkbox',
        fieldLabel: 'Bypass all IPsec traffic'.t(),
        labelWidth: 180,
        bind: {
            value: '{settings.bypassflag}'
        },
    }, {
        xtype: 'component',
        margin: '0 0 20 10',
        html: 'When enabled, IPsec traffic will bypass processing by all Apps and Service Apps'.t(),
    }]
});
Ext.define('Ung.apps.ipsecvpn.view.IpsecPolicy', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-ipsecpolicy',
    itemId: 'ipsec-policy',
    title: 'IPsec Policy'.t(),
    layout: 'fit',
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'button',
        iconCls: 'fa fa-refresh',
        text: 'Refresh',
        target: 'ipsecPolicyInfo',
        handler: 'refreshIpsecPolicyInfo'
    }],

    items: [{
        xtype: 'textarea',
        readOnly: true,
        itemId: 'ipsecPolicyInfo',
        spellcheck: false,
        padding: 0,
        border: false,
        bind: '{ipsecPolicyInfo}',
        fieldStyle: {
            'fontFamily'   : 'courier new',
            'fontSize'     : '12px'
        }
    }]
});
Ext.define('Ung.apps.ipsecvpn.view.IpsecState', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-ipsecstate',
    itemId: 'ipsec-state',
    title: 'IPsec State'.t(),
    layout: 'fit',
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'button',
        iconCls: 'fa fa-refresh',
        text: 'Refresh',
        target: 'ipsecStateInfo',
        handler: 'refreshIpsecStateInfo'
    }],

    items: [{
        xtype: 'textarea',
        readOnly: true,
        itemId: 'ipsecStateInfo',
        spellcheck: false,
        padding: 0,
        border: false,
        bind: '{ipsecStateInfo}',
        fieldStyle: {
            'fontFamily'   : 'courier new',
            'fontSize'     : '12px'
        }
    }]
});
Ext.define('Ung.apps.ipsecvpn.view.IpsecTunnels', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-ipsec-vpn-ipsectunnels',
    itemId: 'ipsec-tunnels',
    title: 'IPsec Tunnels'.t(),
    viewModel: true,
    scrollable: true,
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'The IPsec Tunnels tab is used to create and manage IPsec tunnels'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    emptyText: 'No IPSec Tunnels defined'.t(),

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    listProperty: 'settings.tunnels.list',
    emptyRow: {
        javaClass: 'com.untangle.app.ipsec_vpn.IpsecVpnTunnel',
        'active': true,
        'ikeVersion': 2,
        'conntype': 'tunnel',
        'runmode': 'start',
        'dpddelay': '30',
        'dpdtimeout': '120',
        'phase1Manual': true,
        'phase1Cipher': 'aes256',
        'phase1Hash': 'sha1',
        'phase1Group': 'modp2048',
        'phase1Lifetime' : '28800',
        'phase2Manual': true,
        'phase2Cipher': 'aes256gcm128',
        'phase2Hash': 'sha1',
        'phase2Group': 'modp2048',
        'phase2Lifetime' : '3600',
        'allSubnetNegotation': true,
        'left': [['Ung.util.Util.getAppStorageValue'],['ipsec.leftDefault']],
        'leftId': '',
        'leftSourceIp': '',
        'leftSubnet': [['Ung.util.Util.getAppStorageValue'],['ipsec.leftSubnetDefault']],
        'right': '',
        'rightId': '',
        'rightSourceIp': '',
        'rightSubnet': '',
        'description': '',
        'secret': '',
        'localInterface': 0,
        'rightAny': false,
        'leftSourceIpAny': false,
        'pingAddress': ''
        },

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    bind: '{tunnelList}',

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'active',
        resizable: false
    }, {
        header: 'External IP'.t(),
        width: 200,
        dataIndex: 'left',
        renderer: Ung.apps.ipsecvpn.Main.leftRenderer
    }, {
        header: 'Remote Host'.t(),
        width: Renderer.hostnameWidth,
        dataIndex: 'right',
        renderer: Ung.apps.ipsecvpn.Main.rightRenderer
    }, {
        header: 'Local Source IP Address'.t(),
        width: 200,
        dataIndex: 'leftSourceIp',
        renderer: Ung.apps.ipsecvpn.Main.sourceRenderer
    }, {
        header: 'Local Network'.t(),
        width: Renderer.networkWidth,
        dataIndex: 'leftSubnet',
    }, {
        header: 'Remote Source IP Address'.t(),
        width: 200,
        dataIndex: 'rightSourceIp',
        renderer: Ung.apps.ipsecvpn.Main.sourceRenderer
    }, {
        header: 'Remote Network'.t(),
        width: Renderer.networkWidth,
        dataIndex: 'rightSubnet',
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'description',
        flex: 1,
    }],

    editorHeight: Ext.getBody().getViewSize().height - 60,
    editorWidth: Ext.getBody().getViewSize().width - 60,

    editorXtype: 'ung.cmp.unipsecvpntunnelsrecordeditor',
    editorFields: [{
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype: 'checkbox',
            bind: '{record.active}',
            fieldLabel: 'Enabled'.t(),
            labelWidth: 180
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype: 'textfield',
            bind: '{record.description}',
            fieldLabel: 'Description'.t(),
            labelWidth: 180,
            allowBlank: false,
            width: 500
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'combobox',
            fieldLabel: 'Connection Type'.t(),
            labelWidth: 180,
            editable: false,
            width: 400,
            bind: '{record.conntype}',
            store: [['tunnel','Tunnel'],['transport','Transport']]
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'We recommended selecting <B>Tunnel</B> unless you have a specific reason to use <B>Transport</B>'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'combobox',
            fieldLabel: 'IKE Version'.t(),
            labelWidth: 180,
            editable: false,
            bind: '{record.ikeVersion}',
            store: [[1,'IKEv1'],[2,'IKEv2']]
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Both sides of the tunnel must be configured to use the same IKE version.'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'combobox',
            fieldLabel: 'Connect Mode'.t(),
            labelWidth: 180,
            editable: false,
            bind: {
                disabled: '{record.rightAny == true}',
                value: '{record.runmode}',
            },
            store: [['start','Always Connected'],['route','On Demand']]
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype: 'combobox',
            fieldLabel: 'Interface'.t(),
            labelWidth: 180,
            bind: {
                store: '{wanListStore}',
                value: '{record.localInterface}'
            },
            allowblank: true,
            editable: false,
            queryMode: 'local',
            displayField: 'name',
            valueField: 'index',
            listeners: {
                change: 'interfaceChange'
            }
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype: 'textfield',
            itemId: 'externalAddress',
            bind: {
                value: '{record.left}',
                hidden: '{record.localInterface != 0}'
            },
            fieldLabel: 'Local Address'.t(),
            fieldIndex: 'externalAddress',
            labelWidth: 180,
            allowBlank: false,
            // vtype: 'ipAddress'
        },{
            xtype: 'displayfield',
            fieldLabel: 'Local Address'.t(),
            labelWidth: 180,
            itemId: 'externalAddressCurrent',
            value: '',
            bind: {
                hidden: '{record.localInterface == 0}'
            },
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'WAN IP address of this server'.t()
        }]
    },{
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'checkbox',
            bind: '{record.rightAny}',
            fieldLabel: 'Any Remote Host'.t(),
            labelWidth: 180,
            listeners: {
                change: 'anyRemoteHostChange'
            }
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Allow connections from any IP address'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
        items: [{
            xtype: 'textfield',
        bind: {
            value: '{record.right}',
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
            fieldLabel: 'Remote Host'.t(),
            labelWidth: 180,
            allowBlank: false,
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The public hostname or IP address of the remote IPsec gateway'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype: 'textfield',
            bind: '{record.leftId}',
            fieldLabel: 'Local Identifier'.t(),
            labelWidth: 180
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The authentication ID of the local IPsec gateway. Default = same as <B>External IP</B>'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
        items: [{
            xtype: 'textfield',
            bind: '{record.rightId}',
            fieldLabel: 'Remote Identifier'.t(),
            labelWidth: 180
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The authentication ID of the remote IPsec gateway. Default = same as <B>Remote Host</B>'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'checkbox',
            bind: "{record.allSubnetNegotation}",
            fieldLabel: 'Full Tunnel Mode Negotiation'.t(),
            labelWidth: 180
        }]
    },{
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'checkbox',
            bind: '{record.leftSourceIpAny}',
            fieldLabel: 'Local Source IP Address'.t(),
            labelWidth: 180,
            listeners: {
                change: 'anyLeftSourceChange'
            }
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Request From Peer'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.leftSourceIpAny == true}',
            disabled: '{record.leftSourceIpAny == true}'
        },
        items: [{
            xtype:'textfield',
            bind: "{record.leftSourceIp}",
            fieldLabel: '&nbsp;',
            labelSeparator: '',
            labelWidth: 180,
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype: 'textfield',
            bind: {
                value: '{record.leftSubnet}',
                hidden: '{record.ikeVersion !== 1}',
                disabled: '{record.ikeVersion !== 1}'
            },
            fieldLabel: 'Local Network'.t(),
            labelWidth: 180,
            width: 500,
            allowBlank: false,
            vtype: 'cidrBlock'
        }, {
            xtype: 'textfield',
            bind: {
                value: '{record.leftSubnet}',
                hidden: '{record.ikeVersion !== 2}',
                disabled: '{record.ikeVersion !== 2}'
            },
            fieldLabel: 'Local Network'.t(),
            labelWidth: 180,
            width: 500,
            allowBlank: false,
            vtype: 'cidrBlockList'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The private network attached to the local side of the tunnel'.t(),
            bind: { hidden: '{record.ikeVersion !== 1}' }
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The private networks attached to the local side of the tunnel'.t(),
            bind: { hidden: '{record.ikeVersion !== 2}' }
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
        items: [{
            xtype:'textfield',
            bind: "{record.rightSourceIp}",
            fieldLabel: 'Remote Source IP Address'.t(),
            labelWidth: 180,
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
        items: [{
            xtype: 'textfield',
            bind: {
                value: '{record.rightSubnet}',
                hidden: '{record.ikeVersion !== 1 || record.rightAny == true}',
                disabled: '{record.ikeVersion !== 1 || record.rightAny == true}'
            },
            fieldLabel: 'Remote Network'.t(),
            labelWidth: 180,
            width: 500,
            allowBlank: false,
            vtype: 'cidrBlock'
        }, {
            xtype: 'textfield',
            bind: {
                value: '{record.rightSubnet}',
                hidden: '{record.ikeVersion !== 2 || record.rightAny == true}',
                disabled: '{record.ikeVersion !== 2 || record.rightAny == true}'
            },
            fieldLabel: 'Remote Network'.t(),
            labelWidth: 180,
            width: 500,
            allowBlank: false,
            vtype: 'cidrBlockList'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The private network attached to the remote side of the tunnel'.t(),
            bind: { hidden: '{record.ikeVersion !== 1}' }
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The private networks attached to the remote side of the tunnel'.t(),
            bind: { hidden: '{record.ikeVersion !== 2}' }
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype: 'textfield',
            bind: '{record.secret}',
            fieldLabel: 'Shared Secret'.t(),
            labelWidth: 180,
            width: 700,
            allowBlank: false
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
        items: [{
            xtype:'numberfield',
            bind: '{record.dpddelay}',
            fieldLabel: 'DPD Interval'.t(),
            labelWidth: 180,
            allowBlank: false,
            allowDecimals: false,
            minValue: 0,
            maxValue: 3600
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The number of seconds between R_U_THERE messages.  Enter 0 to disable.'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
        items: [{
            xtype:'numberfield',
            bind: '{record.dpdtimeout}',
            fieldLabel: 'DPD Timeout'.t(),
            labelWidth: 180,
            allowBlank: false,
            allowDecimals: false,
            minValue: 0,
            maxValue: 3600
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'The number of seconds for a dead peer tunnel to be restarted'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        bind: {
            hidden: '{record.rightAny == true}',
            disabled: '{record.rightAny == true}'
        },
        items: [{
            xtype: 'textfield',
            bind: '{record.pingAddress}',
            fieldLabel: 'Ping Address'.t(),
            vtype: 'ipAddress',
            labelWidth: 180
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'An IP address on the remote network to ping for connectivity verification. Leave blank to disable.'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'checkbox',
            bind: '{record.phase1Manual}',
            fieldLabel: 'Phase 1 IKE/ISAKMP Manual Configuration'.t(),
            labelWidth: 300
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase1Manual}' },
        items: [{
            xtype:'combobox',
            bind: {
                value: '{record.phase1Cipher}',
                store: '{P1CipherStore}'
            },
            fieldLabel: 'Encryption'.t(),
            labelWidth: 180,
            width: 350,
            editable: false,
            displayField: 'name',
            valueField: 'value'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = 3DES'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase1Manual}' },
        items: [{
            xtype:'combobox',
            bind: {
                value: '{record.phase1Hash}',
                store: '{P1HashStore}'
            },
            fieldLabel: 'Hash'.t(),
            labelWidth: 180,
            editable: false,
            displayField: 'name',
            valueField: 'value'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = MD5'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase1Manual}' },
        items: [{
            xtype:'combobox',
            bind: {
                value: '{record.phase1Group}',
                store: '{P1GroupStore}'
            },
            fieldLabel: 'DH Key Group'.t(),
            labelWidth: 180,
            editable: false,
            displayField: 'name',
            valueField: 'value'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = 14 (modp2048)'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase1Manual}' },
        items: [{
            xtype:'numberfield',
            bind: {
                value: '{record.phase1Lifetime}',
            },
            fieldLabel: 'Lifetime'.t(),
            labelWidth: 180,
            allowBlank: false,
            allowDecimals: false,
            minValue: 3600,
            maxValue: 86400
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = 28800 seconds, min = 3600, max = 86400'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 0',
        items: [{
            xtype:'checkbox',
            bind: '{record.phase2Manual}',
            fieldLabel: 'Phase 2 ESP Manual Configuration'.t(),
            labelWidth: 300
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase2Manual}' },
        items: [{
            xtype:'combobox',
            bind: {
                value: '{record.phase2Cipher}',
                store: '{P2CipherStore}'
            },
            fieldLabel: 'Encryption'.t(),
            labelWidth: 180,
            width: 350,
            editable: false,
            displayField: 'name',
            valueField: 'value'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = 3DES'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase2Manual}' },
        items: [{
            xtype:'combobox',
            bind: {
                value: '{record.phase2Hash}',
                store: '{P2HashStore}'
            },
            fieldLabel: 'Hash'.t(),
            labelWidth: 180,
            editable: false,
            displayField: 'name',
            valueField: 'value'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = MD5'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase2Manual}' },
        items: [{
            xtype:'combobox',
            bind: {
                value: '{record.phase2Group}',
                hidden: '{!record.phase2Manual}',
                store: '{P2GroupStore}'
            },
            fieldLabel: 'PFS Key Group'.t(),
            labelWidth: 180,
            editable: false,
            displayField: 'name',
            valueField: 'value'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = 14 (modp2048)'.t()
        }]
    }, {
        xtype: 'container',
        layout: 'column',
        margin: '0 0 5 40',
        bind: { hidden: '{!record.phase2Manual}' },
        items: [{
            xtype:'numberfield',
            bind: {
                value: '{record.phase2Lifetime}',
                hidden: '{!record.phase2Manual}'
            },
            fieldLabel: 'Lifetime'.t(),
            labelWidth: 180,
            allowBlank: false,
            allowDecimals: false,
            minValue: 3600,
            maxValue: 86400
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: 'Default = 3600 seconds, min = 3600, max = 86400'.t()
        }]
    }]
});
Ext.define('Ung.apps.ipsecvpn.view.L2tpLog', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-l2tplog',
    itemId: 'l2tp-log',
    title: 'L2TP Log'.t(),
    layout: 'fit',
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'button',
        iconCls: 'fa fa-refresh',
        text: 'Refresh',
        target: 'ipsecVirtualLog',
        handler: 'refreshIpsecVirtualLog'
    }],

    items: [{
        xtype: 'textarea',
        readOnly: true,
        itemId: 'ipsecVirtualLog',
        spellcheck: false,
        padding: 0,
        border: false,
        bind: '{ipsecVirtualLog}',
        fieldStyle: {
            'fontFamily'   : 'courier new',
            'fontSize'     : '12px'
        }
    }]
});
Ext.define('Ung.apps.ipsecvpn.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,

        layout: {
            type: 'vbox',
            align: 'stretch'
        },

        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/ipsec-vpn.svg" width="80" height="80"/>' +
                '<h3>IPsec VPN</h3>' +
                '<p>' + 'IPsec VPN provides secure network access and tunneling to remote users and sites using IPsec, GRE, L2TP, Xauth, and IKEv2 protocols.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'Enabled IPsec Tunnels'.t(),
            padding: 10,
            cls: 'app-section',

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'ungrid',
                itemId: 'tunnelStatus',
                enableColumnHide: true,
                stateful: true,
                trackMouseOver: false,
                resizable: true,
                defaultSortable: true,

                emptyText: 'No Enabled IPsec VPN Tunnels'.t(),

                bind: {
                    store: '{tunnelStatusStore}'
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'Status'.t(),
                    dataIndex: 'mode',
                    sortable: true,
                    width: Renderer.actionWidth,
                    renderer: Ung.apps.ipsecvpn.MainController.modeRenderer,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Local IP'.t(),
                    dataIndex: 'src',
                    sortable: true,
                    width: Renderer.ipWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Remote Host'.t(),
                    dataIndex: 'dst',
                    sortable: true,
                    width: Renderer.hostnameWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Local Network'.t(),
                    dataIndex: 'tmplSrc',
                    sortable: true,
                    width: Renderer.networkWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Remote Network'.t(),
                    dataIndex: 'tmplDst',
                    sortable: true,
                    width: Renderer.networkWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Description'.t(),
                    dataIndex: 'proto',
                    sortable: true,
                    width: Renderer.messageWidth,
                    flex: 1,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Bytes In'.t(),
                    dataIndex: 'inBytes',
                    sortable: true,
                    width: Renderer.sizeWidth,
                    filter: Renderer.numericFilter,
                    renderer: Renderer.count
                }, {
                    header: 'Bytes Out'.t(),
                    dataIndex: 'outBytes',
                    sortable: true,
                    width: Renderer.sizeWidth,
                    filter: Renderer.numericFilter,
                    renderer: Renderer.count
                }],
                bbar: [ '@refresh', '@reset']
            }]
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'Active VPN Sessions'.t(),
            padding: 10,
            cls: 'app-section',

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'ungrid',
                itemId: 'virtualUsers',
                enableColumnHide: true,
                stateful: true,
                trackMouseOver: false,
                resizable: true,
                defaultSortable: true,

                flex: 1,

                emptyText: 'No Active VPN Sessions'.t(),

                bind: {
                    store: '{virtualUserStore}'
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'IP Address'.t(),
                    dataIndex: 'clientAddress',
                    sortable: true,
                    width: Renderer.ipWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Protocol'.t(),
                    dataIndex: 'clientProtocol',
                    sortable: true,
                    width: Renderer.protocolWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Username'.t(),
                    dataIndex: 'clientUsername',
                    sortable: true,
                    width: Renderer.usernameWidth,
                    flex: 1,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Interface'.t(),
                    dataIndex: 'netInterface',
                    sortable: true,
                    width: Renderer.idWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Connect Time'.t(),
                    dataIndex: 'sessionCreation',
                    sortable: true,
                    width: Renderer.timestampWidth,
                    filter: Renderer.timestampFilter,
                    renderer: Renderer.timestampUnixRenderer
                }, {
                    header: 'Elapsed Time'.t(),
                    dataIndex: 'sessionElapsed',
                    width: Renderer.timestampWidth,
                    sortable: true,
                    renderer: Renderer.elapsedTime,
                    filter: Renderer.numericFilter,
                },{
                    header: 'Disconnect'.t(),
                    xtype: 'actioncolumn',
                    width: Renderer.actionWidth + 20,
                    align: 'center',
                    iconCls: 'fa fa-minus-circle',
                    handler: 'externalAction',
                    action: 'disconnectUser',
                }],
                bbar: [ '@refresh', '@reset']

            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        layout: 'fit',
        items: [{
            xtype: 'appmetrics',
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]

});
Ext.define('Ung.apps.ipsecvpn.view.VpnConfig', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ipsec-vpn-vpnconfig',
    itemId: 'vpn-config',
    title: 'VPN Config'.t(),
    scrollable: true,

    viewModel: {
        formulas: {
           _btnConfigureDirectory: function (get) {
                switch (get('settings.authenticationType')) {
                case 'LOCAL_DIRECTORY': return 'Configure Local Directory'.t();
                case 'RADIUS_SERVER': return 'Configure RADIUS'.t();
                default: return '';
                }
            }
        }
    },

    bodyPadding: 10,
    withValidation: true,

    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'The VPN Config tab contains settings used to configure the server to support IPsec L2TP, Xauth, and IKEv2 VPN client connections.'.t()
    }],

    items: [{
        xtype: 'checkbox',
        bind: '{settings.vpnflag}',
        fieldLabel: 'Enable L2TP/Xauth/IKEv2 Server'.t(),
        labelWidth: 200
    },{
        xtype: 'fieldset',
        margin: '10 10 10 -10',
        border: 0,
        hidden: true,
        disabled: true,
        bind: {
            hidden: '{settings.vpnflag == false}',
            disabled: '{settings.vpnflag == false}'
        },

        defaults:{
            labelWidth: 200
        },

        items: [{
            xtype: 'textfield',
            bind: '{settings.virtualAddressPool}',
            vtype: 'cidrBlock',
            allowBlank: false,
            fieldLabel: 'L2TP Address Pool'.t(),
            validator: function(value) {
                return value.split('/')[1] <= 30 ? true : 'Network identifier bits must be less than or equal to 30.'.t();
            }
        },{
            xtype: 'textfield',
            bind: '{settings.virtualXauthPool}',
            vtype: 'cidrBlock',
            allowBlank: false,
            fieldLabel: 'Xauth/IKEv2 Address Pool'.t(),
            validator: function(value) {
                return value.split('/')[1] <= 30 ? true : 'Network identifier bits must be less than or equal to 30.'.t();
            }
        },{
            xtype: 'textfield',
            bind: '{settings.virtualDnsOne}',
            vtype: 'ipAddress',
            allowBlank: true,
            fieldLabel: 'Custom DNS Server 1'.t()
        },{
            xtype: 'textfield',
            bind: '{settings.virtualDnsTwo}',
            vtype: 'ipAddress',
            allowBlank: true,
            fieldLabel: 'Custom DNS Server 2'.t()
        },{
            xtype: 'displayfield',
            value:  '<STRONG>' + 'NOTE: Leave the Custom DNS fields empty to have clients automatically configured to use this server for DNS resolution.'.t() + '</STRONG>'
        },{
            xtype: 'textfield',
            bind: '{settings.virtualSecret}',
            allowBlank: false,
            width: 600,
            fieldLabel: 'IPsec Secret'.t()
        },{
            xtype: 'checkbox',
            bind: '{settings.allowConcurrentLogins}',
            fieldLabel: 'Allow Concurrent Logins',
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 0',
            items: [{
                xtype:'checkbox',
                bind: '{settings.phase1Manual}',
                fieldLabel: 'Phase 1 IKE/ISAKMP Manual Configuration'.t(),
                labelWidth: 300
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase1Manual}' },
            items: [{
                xtype:'combobox',
                bind: {
                    value: '{settings.phase1Cipher}',
                    store: '{P1CipherStore}'
                },
                fieldLabel: 'Encryption'.t(),
                labelWidth: 120,
                width: 350,
                editable: false,
                displayField: 'name',
                valueField: 'value'
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = 3DES'.t()
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase1Manual}' },
            items: [{
                xtype:'combobox',
                bind: {
                    value: '{settings.phase1Hash}',
                    store: '{P1HashStore}'
                },
                fieldLabel: 'Hash'.t(),
                labelWidth: 120,
                editable: false,
                displayField: 'name',
                valueField: 'value'
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = MD5'.t()
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase1Manual}' },
            items: [{
                xtype:'combobox',
                bind: {
                    value: '{settings.phase1Group}',
                    store: '{P1GroupStore}'
                },
                fieldLabel: 'DH Key Group'.t(),
                labelWidth: 120,
                editable: false,
                displayField: 'name',
                valueField: 'value'
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = 14 (modp2048)'.t()
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase1Manual}' },
            items: [{
                xtype:'numberfield',
                bind: {
                    value: '{settings.phase1Lifetime}',
                },
                fieldLabel: 'Lifetime'.t(),
                labelWidth: 120,
                allowBlank: false,
                allowDecimals: false,
                minValue: 3600,
                maxValue: 86400
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = 28800 seconds, min = 3600, max = 86400'.t()
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 0',
            items: [{
                xtype:'checkbox',
                bind: '{settings.phase2Manual}',
                fieldLabel: 'Phase 2 ESP Manual Configuration'.t(),
                labelWidth: 300
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase2Manual}' },
            items: [{
                xtype:'combobox',
                bind: {
                    value: '{settings.phase2Cipher}',
                    store: '{P2CipherStore}'
                },
                fieldLabel: 'Encryption'.t(),
                labelWidth: 120,
                width: 350,
                editable: false,
                displayField: 'name',
                valueField: 'value'
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = 3DES'.t()
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase2Manual}' },
            items: [{
                xtype:'combobox',
                bind: {
                    value: '{settings.phase2Hash}',
                    store: '{P2HashStore}'
                },
                fieldLabel: 'Hash'.t(),
                labelWidth: 120,
                editable: false,
                displayField: 'name',
                valueField: 'value'
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = MD5'.t()
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase2Manual}' },
            items: [{
                xtype:'combobox',
                bind: {
                    value: '{settings.phase2Group}',
                    hidden: '{!settings.phase2Manual}',
                    store: '{P2GroupStore}'
                },
                fieldLabel: 'PFS Key Group'.t(),
                labelWidth: 120,
                editable: false,
                displayField: 'name',
                valueField: 'value'
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = 14 (modp2048)'.t()
            }]
        }, {
            xtype: 'container',
            layout: 'column',
            margin: '0 0 5 40',
            bind: { hidden: '{!settings.phase2Manual}' },
            items: [{
                xtype:'numberfield',
                bind: {
                    value: '{settings.phase2Lifetime}',
                    hidden: '{!settings.phase2Manual}'
                },
                fieldLabel: 'Lifetime'.t(),
                labelWidth: 120,
                allowBlank: false,
                allowDecimals: false,
                minValue: 3600,
                maxValue: 86400
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: 'Default = 3600 seconds, min = 3600, max = 86400'.t()
            }]
        },{
            xtype: 'radiogroup',
            bind: '{settings.authenticationType}',
            simpleValue: 'true',
            columns: 1,
            vertical: true,
            items: [
                { boxLabel: '<strong>' + 'Local Directory'.t() + '</strong>', inputValue: 'LOCAL_DIRECTORY' },
                { boxLabel: '<strong>' + 'RADIUS'.t() + '</strong> (' + 'requires'.t() + ' Directory Connector)', inputValue: 'RADIUS_SERVER' }
            ]
        },{
            xtype: 'button',
            iconCls: 'fa fa-cog',
            width: 200,
            bind: {
                text: '{_btnConfigureDirectory}',
            },
                handler: 'configureAuthTarget'
        },{
            xtype: 'fieldset',
            margin: '20 0 0 0',
            title: 'Server Listen Addresses'.t(),
            padding: 10,

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            items: [{
                xtype: 'ungrid',
                tbar: ['@addInline'],
                recordActions: ['delete'],
                listProperty: 'settings.virtualListenList.list',

                emptyText: 'No Server Listen Addresses Defined'.t(),

                emptyRow: {
                    javaClass: 'com.untangle.app.ipsec_vpn.VirtualListen',
                    'address': ''
                },

                bind: '{listenList}',

                columns: [{
                    header: 'Address'.t(),
                    dataIndex: 'address',
                    width: Renderer.ipWidth,
                    flex: 1,
                    editor: {
                        bind: '{record.address}',
                        xtype: 'textfield',
                        vtype: 'ipAddress'
                    }
                }]
            }]
        }]
    }]
});
