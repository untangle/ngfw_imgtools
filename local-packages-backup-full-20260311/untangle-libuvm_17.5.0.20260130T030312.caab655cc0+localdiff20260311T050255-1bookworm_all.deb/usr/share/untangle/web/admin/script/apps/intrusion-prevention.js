Ext.define('Ung.apps.intrusionprevention.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-intrusion-prevention',
    controller: 'app-intrusion-prevention',

    tbar: [{
        itemId: "signaturesLoadingStatus",
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px'},
        html: ""
    }],

    viewModel: {
        data: {
            signatureStatusTotal: 0,
            signatureStatusLog: 0,
            signatureStatusBlock: 0,
            signatureStatusDisable: 0,
            lastUpdateCheck: '',
            lastUpdate: ''
        },
        stores: {
            rules: {
                storeId: 'rulesStore',
                model: 'Ung.model.intrusionprevention.rule',
                data: '{settings.rules.list}',
                listeners:{
                    update: 'rulesChanged',
                    datachanged: 'rulesChanged'
                }
            },
            signatures: {
                storeId: 'signaturesStore',
                model: 'Ung.model.intrusionprevention.signature',
                data: '{signaturesList}',
                groupField: 'classtype',
                sorters: [{
                    property: 'sid',
                    direction: 'ASC'
                }],
                listeners:{
                    datachanged: 'signaturesChanged'
                }
            },
            variables: {
                storeId: 'variablesStore',
                fields: [{
                    name: 'variable',
                },{
                    name: 'definition'
                },{
                    name: 'description'
                }],
                data: '{settings.variables.list}',
                sorters: [{
                    property: 'variable',
                    direction: 'ASC'
                }],
                listeners:{
                    update: 'variablesChanged',
                    datachanged: 'variablesChanged'
                }
            },
            networkVariables: {
                fields: [{
                    name: 'value'
                },{
                    name: 'description'
                }],
                data: '{networkVariablesList}'
            },
            bypassRules: {
                data: '{settings.bypassRules.list}'
            },
            updateSignatureSchedule: {
                data: '{settings.updateSignatureSchedule.list}'
            }
        }
    },

    items: [
        { xtype: 'app-intrusion-prevention-status' },
        { xtype: 'app-intrusion-prevention-rules' },
        { xtype: 'app-intrusion-prevention-signatures' },
        { xtype: 'app-intrusion-prevention-variables' },
        { xtype: 'app-intrusion-prevention-bypass' },
        { xtype: 'app-intrusion-prevention-advanced',
            tabConfig:{
                hidden: true,
                bind: {
                    hidden: '{!isExpertMode}'
                }
            }
        }
    ],

    statics: {
        updateSignatureFrequency: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'name', 'value' ],
            data: [
                [ 'None'.t(), 'None' ],
                [ 'Daily'.t(), 'Daily' ],
                [ 'Weekly'.t(), 'Weekly' ]
            ]
        }),

        updateSignatureHour: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'stringTime', 'intTime' ],
            data: [
                [ 'Default'.t(), -1],
                [ '1', 1 ],
                [ '2', 2 ],
                [ '3', 3 ],
                [ '4', 4 ],
                [ '5', 5 ],
                [ '6', 6 ],
                [ '7', 7 ],
                [ '8', 8 ],
                [ '9', 9 ],
                [ '10', 10 ],
                [ '11', 11 ],
                [ '12', 12 ]
            ]
        }),

        updateSignatureMinute: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'stringTime', 'intTime' ],
            data: [
                [ 'Default'.t(), -1]
            ]
        }),

        getAllMinutes: function() {
            var store = Ung.apps.intrusionprevention.Main.updateSignatureMinute;
            var i;
            for (i = 0; i < 60; i++) {
                if (i < 10)
                    store.add({'stringTime': '0'+i, 'intTime': i});
                else
                    store.add({'stringTime': i, 'intTime': i});
            }
            return store;
        },

        updateSignatureDays: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'displayValue', 'value' ],
            data: [
                [ 'None'.t(), "None" ],
                [ 'Sunday'.t(), "Sunday" ],
                [ 'Monday'.t(), "Monday" ],
                [ 'Tuesday'.t(), "Tuesday" ],
                [ 'Wednesday'.t(), "Wednesday" ],
                [ 'Thursday'.t(), "Thursday" ],
                [ 'Friday'.t(), "Friday" ],
                [ 'Saturday'.t(), "Saturday" ]
            ]
        }),

        updateSignatureIsAm: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'displayValue', 'value' ],
            data: [
                [ 'AM', true ],
                [ 'PM', false ]
            ]
        }),

        updateSignatureDaily: function() {
            return {
                xtype: 'grid',
    
                hideHeaders: true,
                bodyBorder: false,
                border: false,
                hidden: true,

                bind: {
                    store: '{updateSignatureSchedule}',
                    hidden: '{settings.updateSignatureFrequency != \'Daily\'}'
                },
                columns: [{
                    xtype: 'widgetcolumn',
                    dataIndex: 'enabled',
                    width: 30,
                    widget: {
                        xtype: 'checkbox',
                        bind: '{record.enabled}',
                    }
                }, {
                    dataIndex: 'day',
                    width: 80,
                }, {
                    dataIndex: 'hour',
                    xtype: 'widgetcolumn',
                    widget: {
                        xtype: 'combo',
                        editable: false,
                        queryMode: 'local',
                        bind: '{record.hour}',
                        store: Ung.apps.intrusionprevention.Main.updateSignatureHour,
                        displayField: 'stringTime',
                        valueField: 'intTime'
                    }
                }, {
                    dataIndex: 'colon',
                    width: 20
                }, {
                    dataIndex: 'minute',
                    xtype: 'widgetcolumn',
                    widget: {
                        xtype: 'combo',
                        editable: false,
                        queryMode: 'local',
                        bind: '{record.minute}',
                        store: Ung.apps.intrusionprevention.Main.updateSignatureMinute,
                        displayField: 'stringTime',
                        valueField: 'intTime'
                    }
                }, {
                    dataIndex: 'isAm',
                    xtype: 'widgetcolumn',
                    width: 70,
                    widget: {
                        xtype: 'combo',
                        editable: false,
                        width: 60,
                        padding: '0 0 0 10',
                        queryMode: 'local',
                        bind: '{record.isAm}',
                        store: Ung.apps.intrusionprevention.Main.updateSignatureIsAm,
                        displayField: 'displayValue',
                        valueField: 'value'
                    }
                }]
            };
            
        },

        updateSignatureWeekly: function() {
            return {
                xtype: 'fieldset',

                layout: {
                    type: 'hbox'
                },
    
                border: false,
                hidden: true,
                padding: '0 0 0 0',

                bind: {
                    hidden: '{settings.updateSignatureFrequency != \'Weekly\'}'
                },
                    
                items: [{
                    xtype: 'combo',
                    editable: false,
                    queryMode: 'local',
                    bind: '{settings.updateSignatureWeekly.day}',
                    store: Ung.apps.intrusionprevention.Main.updateSignatureDays,
                    displayField: 'displayValue',
                    valueField: 'value',
                    width: 100
                }, {
                    xtype: 'combo',
                    editable: false,
                    queryMode: 'local',
                    bind: '{settings.updateSignatureWeekly.hour}',
                    store: Ung.apps.intrusionprevention.Main.updateSignatureHour,
                    displayField: 'stringTime',
                    valueField: 'intTime',
                    padding: '0 0 0 20',
                    width: 105
                }, {
                    xtype: 'component',
                    html: ':',
                    width: 20,
                    padding: '0 0 0 8'
                }, {
                    xtype: 'combo',
                    editable: false,
                    queryMode: 'local',
                    bind: '{settings.updateSignatureWeekly.minute}',
                    store: Ung.apps.intrusionprevention.Main.getAllMinutes(),
                    displayField: 'stringTime',
                    valueField: 'intTime',
                    width: 105
                }, {
                    xtype: 'combo',
                    editable: false,
                    queryMode: 'local',
                    bind: '{settings.updateSignatureWeekly.isAm}',
                    store: Ung.apps.intrusionprevention.Main.updateSignatureIsAm,
                    displayField: 'displayValue',
                    valueField: 'value',
                    padding: '0 0 0 10',
                    width: 60
                }]
            };
            
        },

        updateSignatureButton: {
            xtype: 'button',
            text: 'Update Now'.t(),
            handler: 'updateSignatureManual'
        },


        processingStage: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'value', 'description', 'detail'],
            data: [
                ['pre', 'Before other network processing'.t(), 'More detections in this mode which may not be very useful in a gateway environment.'.t()],
                ['post', 'After other network processing'.t(), 'Less detections in this mode which is typically more appropiate for a gateway environment.'.t()]
            ]
        }),

        signatureActions: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'value', 'description'],
            data: [
                [ 'log', 'Log'.t() ],
                [ 'block', 'Block'.t() ],
                [ 'disable', 'Disable'.t() ]
            ]
        }),

        ruleActions: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'value', 'description'],
            data: [
                [ 'default', 'Recommended'.t()],
                [ 'log', 'Enable Log'.t() ],
                [ 'blocklog', 'Enable Block if Recommended is Enabled'.t() ],
                [ 'block', 'Enable Block'.t()],
                [ 'disable', 'Disable'.t() ],
                [ 'whitelist', 'Whitelist'.t() ]
            ]
        }),

        actionNetworks: [{
            label: 'Match source networks'.t(),
            key: 'sourceNetworks' 
        },{
            label: 'Match destination networks'.t(),
            key: 'destinationNetworks'
        }],
        actionRenderer: function(value, meta, record){
            return record.get('description');
        },

        classtypes: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'value', 'description', 'priority' ],
            sorters: [{
                property: 'value',
                direction: 'ASC'
            }],
            data: [
            [ "attempted-admin", "Attempted Administrator Privilege Gain".t(), "high"],
            [ "attempted-user", "Attempted User Privilege Gain".t(), "high" ],
            [ "policy-violation", "Potential Corporate Privacy Violation".t(), "high" ],
            [ "shellcode-detect", "Executable code was detected".t(), "high" ],
            [ "successful-admin", "Successful Administrator Privilege Gain".t(), "high" ],
            [ "successful-user", "Successful User Privilege Gain".t(), "high" ],
            [ "trojan-activity", "A Network Trojan was detected".t(), "high" ],
            [ "unsuccessful-user", "Unsuccessful User Privilege Gain".t(), "high" ],
            [ "web-application-attack", "Web Application Attack".t(), "high" ],

            [ "attempted-dos", "Attempted Denial of Service".t(), "medium" ],
            [ "attempted-recon", "Attempted Information Leak".t(), "medium" ],
            [ "bad-unknown", "Potentially Bad Traffic".t(), "medium" ],
            [ "default-login-attempt", "Attempt to login by a default username and password".t(), "medium" ],
            [ "denial-of-service", "Detection of a Denial of Service Attack".t(), "medium" ],
            [ "misc-attack", "Misc Attack".t(), "medium" ],
            [ "non-standard-protocol", "Detection of a non-standard protocol or event".t(), "medium" ],
            [ "rpc-portmap-decode", "Decode of an RPC Query".t(), "medium" ],
            [ "successful-dos", "Denial of Service".t(), "medium" ],
            [ "successful-recon-largescale", "Large Scale Information Leak".t(), "medium" ],
            [ "successful-recon-limited", "Information Leak".t(), "medium" ],
            [ "suspicious-filename-detect", "A suspicious filename was detected".t(), "medium" ],
            [ "suspicious-login", "An attempted login using a suspicious username was detected".t(), "medium" ],
            [ "system-call-detect", "A system call was detected".t(), "medium" ],
            [ "unusual-client-port-connection", "A client was using an unusual port".t(), "medium" ],
            [ "web-application-activity", "Access to a potentially vulnerable web application".t(), "medium" ],

            [ "general", "General traffic".t(), "low" ],
            [ "misc-activity", "Misc activity".t(), "low" ],
            [ "network-scan", "Detection of a Network Scan".t(), "low" ],
            [ "not-suspicious", "Not Suspicious Traffic".t(), "low" ],
            [ "protocol-command-decode", "Generic Protocol Command Decode".t(), "low" ],
            [ "string-detect", "A suspicious string was detected".t(), "low" ],
            [ "unknown", "Unknown Traffic".t(), "low" ]
            ]
        }),

        classtypeRenderer: function(value, meta, record){
            return Ext.String.format("{0} ({1})".t(), record.get('description'), record.get('priority'));
        },

        categories: Ext.create('Ext.data.ArrayStore', {
            fields: [ 'value', 'description' ],
            sorters: [{
                property: 'value',
                direction: 'ASC'
            }],
            data: [
            ["activex", 'These are designed to catch exploits in the ActiveX framework.'.t() ],
            ["app-layer-events", 'These rules log events related to the application layer.'.t() ],
            ["attack_response", 'These are designed to catch the results of a successful attack. Things like \'id=root\', or error messages that indicate a compromise may have happened. Note: Trojan and virus post-infection activity is included generally in the VIRUS signature set, not here.'.t() ],
            ["botcc", 'These are autogenerated from several sources of known and confirmed active Botnet and other Command and Control hosts. Updated daily, primary data source is Shadowserver.org.' .t() ],
            ["botcc.portgrouped", 'Same as botcc but grouped by destination port.'.t() ],
            ["chat", 'These are designed to catch exploits from various chat applications.'.t() ],
            ["ciarmy", 'These are designed to catch exploits identified by Collective Intellegence Network Security.'.t() ],
            ["compromised", 'Signatures to block known hostile or compromised hosts.'.t() ],
            ["current_events", 'Signatures identified by various alert agencies.'.t() ],
            ["decoder-events", 'These suricata-specific rules log normalization events related to decoding.'.t() ],
            ["deleted", 'When a signature has been deprecated or replaced it is moved to this categories. Signatures are never totally removed from the signature set, they are moved here.'.t() ],
            ["dns", 'This category is for signatures that may indicate the presence of the DNS protocol or vulnerabilities in the DNS protocol on the network.'.t() ],
            ["dns-events", 'These rules log events related to DNS.'.t() ],
            ["dos", 'Intended to catch inbound DOS activity, and outbound indications.'.t() ],
            ["drop", 'This is a daily updated list of the Spamhaus DROP (Don\'t Route or Peer) list. Primarily known professional spammers.'.t() ],
            ["dshield", 'Daily updated list of the DShield top attackers list.'.t() ],
            ["exploit", 'This is an older category which will be deprecated soon. This category looks for exploits against software in a generic form.'.t() ],
            ["files", 'Example rules for using the file handling and extraction functionality in Suricata.'.t() ],
            ["ftp", 'This category is for signatures that may indicate the presence of the ftp protocol or vulnerabilities in the ftp protocol on the network.'.t() ],
            ["games", 'This category is for signatures that may indicate the presence of gaming protocols or vulnerabilities in the gaming protocols on the network.'.t() ],
            ["http-events", 'These rules are rules to log HTTP protocol specific events, typically normal operation.'.t() ],
            ["icmp", 'This category is for signatures that may indicate the presence of icmp traffic or vulnerabilities in icmp on the network.'.t() ],
            ["icmp_info", 'Attempts to determine target hardware and software using typical ICMP behavior.'.t() ],
            ["imap", 'This category is for signatures that may indicate the presence of the imap protocol or vulnerabilities in the imap protocol on the network.'.t() ],
            ["inappropriate", 'Porn, Kiddy porn, sites you shouldn\'t visit at work, etc. Warning: These are generally quite Regex heavy and thus high load and frequent false positives. Only run these if you\'re really interested.'.t() ],
            ["info", 'Signatures that attempt to send informaton to commonly known malware sites.'.t() ],
            ["ipsec-events", 'These rules log events related to insecure IPsec.'.t() ],
            ["kerberos-events", 'These rules log events related to insecure and wrongly configured Kerberos.'.t() ],
            ["malware", 'This category is malware and spyware related with no criminal intent. The threshold for inclusion in this set is typically some form of tracking that stops short of obvious criminal activity.'.t() ],
            ["misc", 'Various, otherwise uncategorizable exploit attempts.'.t() ],
            ["mobile_malware", 'This category contains signatures for the detection of traffic on mobile devices.'.t() ],
            ["modbus-events", 'These rules log events related to modbus.'.t() ],
            ["netbios", 'This category is for signatures that may indicate the presence of NetBIOS traffic or vulnerabilities in NetBIOS on the network.'.t() ],
            ["nfs-events", 'These rules log events related to malformed NFS requests and responses.'.t() ],
            ["ntp-events", 'These rules log events related to malformed NTP requests and responses.'.t() ],
            ["p2p", 'This category deals with pua or Potentially Unwanted Applications that deal with p2p.'.t() ],
            ["policy", "This category is for the rules for things that are often disallowed by company or organizational policy. Myspace, Ebay, that kind of thing.".t() ],
            ["pop3", 'This category is for signatures that may indicate the presence of the pop3 protocol or vulnerabilities in the pop3 protocol on the network.'.t() ],
            ["rpc", 'Remote Proceudre Call exploits.'.t() ],
            ["scada", 'SCADA sourced exploits.'.t() ],
            ["scan", 'Scanning exploits.'.t() ],
            ["shellcode", 'Exploits that attempt to excute shell commands on various operating systems.'.t() ],
            ["smb-events", 'These rules log events related to SMB internal parser errors and malformed requests and responses for SMB.'.t() ],
            ["smtp", 'This category is for signatures that may indicate the presence of the SMTP protocol or vulnerabilities in the SMTP protocol on the network.'.t() ],
            ["smtp-events", 'These rules log events related to SMTP i.e. incorrect configuration, malformed requests.'.t() ],
            ["snmp", 'This category is for signatures that may indicate the presence of the SNMP protocol or vulnerabilities in the SNMP protocol on the network.'.t() ],
            ["sql", 'SQL exploits.'.t() ],
            ["stream-events", 'These rules log events related to streams.'.t() ],
            ["telnet", 'These rules are related to telnet vulnerabilities and presence of telnet.'.t() ],            
            ["tftp", 'This category is for signatures that may indicate the presence of the TFTP protocol or vulnerabilities in the TFTP protocol on the network.'.t() ],
            ["tls-events", 'These rules log events related to insecure and wrong TLS.'.t() ],
            ["tor", 'TOR exploits.'.t() ],
            ["trojan", 'Trojan Horse exploits.'.t() ],
            ["user_agents", 'This category deals with vulnerabilities in or attacks against common application clients.'.t() ],
            ["voip", 'This category deals with vulnerabilities in or attacks against Voice Over IP applications.'.t() ],
            ["web_client", 'This category deals with vulnerabilities in or attacks against Web clients.'.t() ],
            ["web_server", 'This category deals with vulnerabilities in or attacks against Web servers.'.t() ],
            ["web_specific_apps", 'This category deals with vulnerabilities in or attacks against Web based applications on servers.'.t() ],
            ["worm", 'Worm exploits.'.t() ],
            ]
        }),

        categoryRenderer: function(value, meta, record){
            return record.get('description');
        },
    }
});
Ext.define('Ung.apps.intrusionprevention.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-intrusion-prevention',

    control: {
        '#': {
            afterrender: 'getSettings',
        }
    },

    getSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);

        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getAppStatus'),
            Rpc.directPromise('rpc.companyName'),
            Rpc.asyncPromise('rpc.metricManager.getMemTotal'),
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.directPromise('rpc.isExpertMode'),
        ]).then(function(result){
            if(Util.isDestroyed(me, v, vm)){
                return;
            }

            var status = result[0];

            vm.set({
                lastUpdateCheck: (status['lastUpdateCheck'] && status['lastUpdateCheck'] !== null && status['lastUpdateCheck'].time !== 0 ) ? Renderer.timestamp(status['lastUpdateCheck']) : "Never".t(),
                lastUpdate: (status['lastUpdate'] && status['lastUpdate'] !== null && status['lastUpdate'].time !== 0 ) ? Renderer.timestamp(status['lastUpdate']) : "Never".t(),
                daemonErrors: "",
                companyName: result[1],
                system_memory: result[2],
                settings: result[3],
                isExpertMode: result[4],
                homeNetworks: (status.homeNetworks != null ? '[' + status.homeNetworks.join(', ') + ']' : ''),
                defaultNetwork: (status.homeNetworks != null ? status.homeNetworks[0] : '192.168.1.0/24')
            });

            v.setLoading('Loading signatures...'.t());
            var dt = new Ext.util.DelayedTask( Ext.bind(function(){
                me.buildVariables();
                me.getSignatures();
                me.buildErrors(status["errors"]);
                v.setLoading('');
                v.setLoading(false);
            }, me));
            dt.delay(100);
            vm.set('panel.saveDisabled', false);

        }, function (ex) {
            if(!Util.isDestroyed(me, v )){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    buildVariables: function(){
        var me = this, vm = this.getViewModel();

        var networkVariablesList = [{
            value: 'recommended', 
            description: 'Recommended'.t() 
        }];

        vm.get('variables').each( function(variable){
            var value = Ung.apps.intrusionprevention.MainController.variableValueResolve.call(me, variable);
            if(Ung.model.intrusionprevention.rule.ipv4NetworkRegex.test(value)){
                networkVariablesList.push({
                    value: '$' + variable.get('name'),
                    description: Ext.String.format( '{0} - {1}', variable.get('name'), variable.get('value')),
                    detail: value
                });
            }
        });
        vm.set('networkVariablesList', networkVariablesList);
    },

    getsignaturesLoadingStatusText: '<i class="fa fa-spinner fa-spin fa-lg fa-fw"></i> ' + 'Loading signatures {0}/{1} ({2})...'.t(),
    getSignaturesTaskDelay: 100,
    signatureSkips: [],
    // Retrieve signature sets.
    // First ask for a catalog of available set names, then iterate catalog to retrieve each set.
    getSignatures: function(){
        var me = this, v = this.getView(), vm = this.getViewModel();

        var currentSignatures = vm.get('signaturesList');
        if(currentSignatures != null ){
            // Already built
            return;
        }

        var catalog = null;
        var catalogIndex = 0;
        var signatureSkips = [];

        var getSignaturesTask = new Ext.util.DelayedTask( Ext.bind(function(){
            if(Util.isDestroyed(vm)){
                return;
            }
            var response = null;

            v.down("#signaturesLoadingStatus").setVisible(true);
            if(catalog == null){
                v.down("#signaturesLoadingStatus").setHtml(Ext.String.format(me.getsignaturesLoadingStatusText, "0", "0", "catalog"));
                response = Ext.Ajax.request({
                    url: "/admin/download",
                    method: 'POST',
                    async: false,
                    params: {
                        type: "IntrusionPreventionSettings",
                        arg1: "signatures",
                        arg2: !Util.isDestroyed(vm) ? vm.get('instance.id') : null,
                        arg5: "catalog"
                    },
                timeout: 600000});
                catalog = response.responseText.split("\n");
            }else{
                v.down("#signaturesLoadingStatus").setHtml(Ext.String.format(me.getsignaturesLoadingStatusText, catalogIndex, catalog.length, catalog[catalogIndex]));
                try{
                    response = Ext.Ajax.request({
                        url: "/admin/download",
                        method: 'POST',
                        async: false,
                        params: {
                            type: "IntrusionPreventionSettings",
                            arg1: "signatures",
                            arg2: !Util.isDestroyed(vm) ? vm.get('instance.id') : null,
                            arg5: catalog[catalogIndex]
                        },
                        timeout: 600000});
                    me.buildSignatures(response);
                }catch (error){
                    Util.handleException(error);
                    // This failure NEVER occur locally, but CAN occur when retreiving via supssh.
                    // Evidence points to something in the end-device's WAN path matching data
                    // (which is encrypted!) and inexplicbly sending dropping the connection for this
                    // set download, causing this exception to occur.
                    // The evidence inexplicbaly shows this occuring in certain sets only, so
                    // we'll handle by just adding the file name ot the skip list and continuing.
                    console.log(catalog[catalogIndex]);
                    console.log(error);
                    signatureSkips.push(catalog[catalogIndex]);
                }
                catalogIndex++;
            }
            if(catalog != null && catalogIndex < catalog.length){
                // Refire
                getSignaturesTask.delay( me.getSignaturesTaskDelay );
                return;
            }
            // Finished
            v.down("#signaturesLoadingStatus").setVisible(false);
            if(signatureSkips.length){
                console.log("unable to load sets:");
                console.log(signatureSkips);
            }
        }, me) );
        getSignaturesTask.delay( me.getSignaturesTaskDelay );
    },

    buildLocalSignatures: true,
    buildSignatures: function(reserved){
        var me = this, v = this.getView(), vm = this.getViewModel();

        // var t0 = performance.now();
        // var t1 = performance.now();
        // var t2 = performance.now();

        var signatures = vm.get('signaturesList') || [];
        if(typeof(reserved) == 'undefined'){
            /**
             * Rebuild using exisitng list, removing custom signatures.
             */
            var newSignatures = [];
            vm.get('signaturesList').forEach( function(signature){
                if(signature.get('default') == true){
                    newSignatures.push(signature);
                }
            });
            signatures = newSignatures;
        }else{
            /**
             * Build from default signature database.
             */
            var filenameRegex = new RegExp("^# filename: (emerging\-|)(.+)\.rules$");
            // var filenameStrips = ['emerging-'];
            var matches;
            var category;
            reserved.responseText.split("\n").forEach(function(line){
                // if(category == 'attack_response'){
                // if(category == 'games'){
                //     return false;
                // }
                line = line.trim();
                if(line){
                    // if(line.startsWith('# filename')){
                    //     console.log(line);
                    // }
                    // if(line && line != "#" && !line.startsWith("# ") && !line.startsWith("#**") ){
                    if( filenameRegex.test( line ) ){
                        var matches = line.match(filenameRegex);
                        if( matches ){
                            category = matches[2];
                            // console.log(category);
                        }
                    }else if( Ung.model.intrusionprevention.signature.isValid( line ) ){
                        // if(category == 'files'){
                            // console.log(line);
                            signatures.push(new Ung.model.intrusionprevention.signature(line, category, true));
                        // }
                    // }else{
                    //     console.log("invalid signature:" + line);
                    }
                }
            });
        }
        // console.log(signatures);
        // t1 = performance.now();
        // console.log('build signatures: ' + (t1-t0));
        // console.log(signatures.length);

        // Process custom signatures
        if(me.buildLocalSignatures){
            vm.get('settings.signatures.list').forEach(function(settingsSignature){
                signatures.push(new Ung.model.intrusionprevention.signature(settingsSignature.signature, settingsSignature.category, false));
            });
            me.buildLocalSignatures = false;
        }
        // console.log("set signaturesList with " + signatures.length);
        vm.set('signaturesList', signatures);
        var signaturesStore = vm.get("signatures");//.loadData(signatures);
        if(signaturesStore != null){
            signaturesStore.loadData(signatures);
        }

        // Add protocols found in Suricata rules.
        var conditions = v.down('[name=rules]').getController().getConditions();
        var protocols = conditions['PROTOCOL'].values;
        var found;
        signatures.forEach(function(signature){
            var signatureProtocol = signature.get('protocol');
            found = false;
            protocols.forEach( function(protocol){
                if(protocol[0] == signatureProtocol){
                    found = true;
                }
            });
            if(found == false){
                protocols.push([signatureProtocol, signatureProtocol]);
            }
        });
    },


    buildErrors: function(errors){
        var parsedErrors = [],
            vm = this.getViewModel();

        errors.split("\n").forEach( function(error){
            var matches = Ung.apps.intrusionprevention.MainController.regexDaemonError.exec(error);
            if(matches){
                parsedErrors.push(matches[1]);
            }
        });
        vm.set('daemonErrors', parsedErrors.join("\n"));
    },

    setSettings: function (additionalChanged) {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);

        v.query('ungrid').forEach(function (grid) {
            var settingsProperty = grid.listProperty;
            if(grid.getBind().store){
                var bindName = grid.getBind().store.stub.name;
                settingsProperty = grid.getBind().store.owner.config.stores[bindName].data;
                settingsProperty = settingsProperty.substring(1,settingsProperty.length - 1);
            }

            if(settingsProperty){
                var store = grid.getStore();
                if(settingsProperty == 'signaturesList'){
                    var signatures = [];
                    store.each(function(record){
                        if(!record.get('default') && !record.get('markedForDelete')) {
                            signatures.push({
                                javaClass: 'com.untangle.app.intrusion_prevention.IntrusionPreventionSignature',
                                signature: record.getRecord(),
                                category: record.get('category')
                            });
                        }
                    }, this, true);
                    vm.set('settings.signatures.list', signatures);
                }else{
                    if (store.getModifiedRecords().length > 0 ||
                        store.getNewRecords().length > 0 ||
                        store.getRemovedRecords().length > 0 ||
                        store.isReordered) {
                        store.each(function (record) {
                            if (record.get('markedForDelete')) {
                                record.drop();
                            }
                        }, this, true);
                        store.isReordered = undefined;
                        vm.set(settingsProperty, Ext.Array.pluck(store.getRange(), 'data'));
                    }
                }
            }
        });

        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    isVariableUsed: function(variable) {
        var vm = this.getViewModel();

        if(Ext.isEmpty(variable)) {
            return false;
        }

        var signature, originalId, signatureMatches, variableMatches, j, internalId, d;
        // var isUsed = false;
        var isUsed = {};

        vm.get('signatures').each(function(record){
            var signatureMatches = Ung.apps.intrusionprevention.MainController.regexSignature.exec( record.get('signature') );
            if( signatureMatches ) {
                for( j = 1; j < signatureMatches.length; j++ ) {
                    variableMatches = Ung.apps.intrusionprevention.MainController.regexSignatureVariable.exec( signatureMatches[j] );
                    if( variableMatches && variableMatches.shift() == '$'+variable){
                        // isUsed = true;
                        if(!('signatures' in isUsed)){
                            isUsed['signatures'] = [];
                        }
                        // isUsed['signatures'].push(record.get('id'));
                        isUsed['signatures'].push(record);
                        // return false;
                    }
                }
            }
        });

        vm.get('rules').each(function(rule){
            if(rule.get('action') == 'whitelist'){
                if( rule.get('sourceNetworks') == '$'+variable || 
                    rule.get('destinationNetworks') == '$'+variable){
                    if(!('rules' in isUsed)){
                        isUsed['rules'] = [];
                    }
                    // isUsed['rules'].push(rule.get('id'));
                    isUsed['rules'].push(rule);
                }
            }
        });

        return isUsed;
    },

    rulesChanged: function(store, record, action, recordActions, data){
            this.getViewModel().get('signatures').each(function(signature){
            var matchingRules = signature.get('matchingRules'); 
            var index = matchingRules.indexOf(record);
            if(index != -1){
                matchingRules.splice(index, 1);
                signature.set('matchingRules', matchingRules);
            }
        });
        this.getView().down('[itemId=signatures]').getView().refresh();

        var me = this;
        me.watchSignatureStoreTask = new Ext.util.DelayedTask( Ext.bind(function(){
            var me = this,
                vm = me.getViewModel(),
                store = vm.get('signatures');
            if(store == null){
                me.watchSignatureStoreTask.delay( 500 );
            }else{
                var status = me.ruleSignatureMatches();
                vm.set({
                    signatureStatusTotal: store.getCount(),
                    signatureStatusLog: Ext.Array.sum(Ext.Object.getValues(status.log)),
                    signatureStatusBlock: Ext.Array.sum(Ext.Object.getValues(status.block)),
                    signatureStatusDisable: Ext.Array.sum(Ext.Object.getValues(status.disable))
                });
            }
        }, me) );
        me.watchSignatureStoreTask.delay( 500 );
    },

    signaturesChanged: function(store){
        var me = this;

        me.watchSignatureStoreTask = new Ext.util.DelayedTask( Ext.bind(function(){
            var me = this,
                vm = me.getViewModel(),
                store = vm && vm.get('signatures') || null;
            if(store == null){
                if(me.watchSignatureStoreTask){
                    me.watchSignatureStoreTask.delay( 500 );
                }
            }else{
                var status = me.ruleSignatureMatches();
                vm.set({
                    signatureStatusTotal: store.getCount(),
                    signatureStatusLog: Ext.Array.sum(Ext.Object.getValues(status.log)),
                    signatureStatusBlock: Ext.Array.sum(Ext.Object.getValues(status.block)),
                    signatureStatusDisable: Ext.Array.sum(Ext.Object.getValues(status.disable))
                });
                me.getView().down('[itemId=signatures]').getView().getFeature("grouping").collapseAll();

            }
        }, me) );
        me.watchSignatureStoreTask.delay( 500 );
    },

    variablesChanged: function(store){
        this.buildVariables();
        this.getView().down('[itemId=rules]').getView().refresh();
    },

    /**
     * ExtJs does not seem to allow tooltip binding, so to get around this, create
     * model variable with 'value' and 'tip' keys and when the value changes,
     * look at the bind parent value for that object and set the tooltip.
     */
    bindChange: function(cmp){
        cmp.getEl().set({
            'data-qtip': cmp.bind.value.stub.parentValue.tip
        });
    },

    ruleSignatureMatches: function(matchRule, conditions){
        var me = this,
            v = me.getView(),
            vm = me.getViewModel(),
            signatures = vm.get('signatures'),
            status = {
                log: {},
                block: {},
                disable: {}
            };
        // var t0 = performance.now();

        if(signatures == null){
            return status;
        }

        if(conditions == null){
            conditions = v.down('[name=rules]').getController().getConditions();
        }

        var rules = vm.get('rules');
        if(matchRule != null){
            rules = Ext.create('Ext.data.Store');
            rules.add(matchRule);
        }
        if(rules == null){
            return;
        }

        var signatureRecommendedAction, signatureCurrentAction;
        signatures.each( function(signature){
            signatureRecommendedAction = signature.get('recommendedAction');
            var disabled = false;
            if(!matchRule){
                disabled = true;
            }
            rules.each(function(rule){
                if(rule.get('enabled')){
                    var action = rule.get('action');

                    if(rule.matchSignature(signature, conditions, vm) == true){
                        if(action == 'whitelist'){
                            if(signature.data['matchingRules'].indexOf(rule) == -1){
                                signature.data['matchingRules'].push(rule);
                            }
                            return true;
                        }
                        disabled = false;
                        if(action == 'default'){
                            action = signatureRecommendedAction;
                        }
                        if(action == 'blocklog'){
                            action = ( signatureRecommendedAction == 'log' || signatureRecommendedAction == 'block') ? 'block' : 'disable';
                        }
                        if(!matchRule){
                            if(signature.data['matchingRules'].indexOf(rule) == -1){
                                signature.data['matchingRules'].push(rule);
                            }
                        }
                        status[action][signature.get('id')] = true;
                        return false;
                    }
                }
            });

            if(!matchRule && ( disabled == true)){
                status['disable'][signature.get('id')] = true;
            }
        }, this, true);
        // console.log(performance.now()- t0);
        // console.log(status);

        // console.log(status);
        return status;
    },

    updateSignatureManual: function() {
        var me = this, v = this.getView(), vm = this.getViewModel();
        v.setLoading('Updating Signatures...'.t());
        Rpc.asyncData( v.appManager, 'updateSignatureManual')
        .then(function(result){
            if(Util.isDestroyed(me, v, vm)){
                return;
            }
            v.setLoading(false);
            if (result.updateSuccess === true) Util.successToast("Updating Signatures Successful".t());
            else Util.handleException('Update Signatures Failed'.t());
        });
    },

    statics:{
        // Example: Jan 29 09:57:07 devhostname.example.com suricata[126833]: [126833] <Error> -- [ERRCODE: SC_ERR_INVALID_ACTION(142)] - An invalid...
        regexDaemonError:  /\] \- (.*)$/,
        regexSignatureVariable:  /\$([A-Za-z0-9\_]+)/,
        regexSignature: /^([#]+|)(alert|log|pass|activate|dynamic|drop|sdrop|reject)\s+(tcp|udp|icmp|ip)\s+([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+\((.+)\)$/,

        ruleActionsRenderer: function(value, meta, record, x,y, z, table){
            var me = this;

            var variableStore = me.getView().up('apppanel').getViewModel().get('variables');

            var actionValue = Ung.apps.intrusionprevention.Main.ruleActions.findRecord('value', value, 0, false, false, true).get('description');
            var summarySuffix = '';
            var detailSuffix = '';
            if( value == 'whitelist' ){
                var summaryEntries = [];
                var detailEntries = [];
                Ung.apps.intrusionprevention.Main.actionNetworks.forEach( function(network){
                    var value = record.get(network['key']);
                    if(value == 'recommended'){
                        summaryEntries.push('Recommended'.t());
                        detailEntries.push('Recommended'.t());
                    }else{
                        summaryEntries.push(network['label'] + ': !' + value);
                        detailEntries.push(network['label'] + ': !' + Ung.apps.intrusionprevention.MainController.variableValueResolve.call(me, variableStore.findRecord('name', value.substr(1), 0, false, false, true)));
                    }
                });
                summarySuffix = ' [' + summaryEntries.join(', ') + ']';
                detailSuffix = ' [' + detailEntries.join(', ') + ']';
            }
            meta.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( actionValue + detailSuffix ) + '"';
            return actionValue + summarySuffix;
        },

        idRenderer: function( value, metaData, record, rowIdx, colIdx, store ){
            var sid = record.get('sid');
            var gid = record.getOption('gid');
            if(!gid){
                gid = '1';
            }
            metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( "Sid".t() + ": " + sid + ", " + "Gid".t() + ":" + gid) + '"';
            return value;
        },

        classtypeRenderer: function( value, metaData, record, rowIdx, colIdx, store ){
            var classtypeRecord = Ung.apps.intrusionprevention.Main.classtypes.findRecord('value', value, 0, false, false, true);
            var description = value;
            if( classtypeRecord != null ){
                description = classtypeRecord.get('description');
            }
            metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( description ) + '"';
            return value;
        },

        categoryRenderer: function( value, metaData, record, rowIdx, colIdx, store ){
            var description = value;
            var categoryRecord = Ung.apps.intrusionprevention.Main.categories.findRecord('value', value, 0, false, false, true);
            if( categoryRecord != null ){
                description = categoryRecord.get('description');
            }
            metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( description  ) + '"';
            return value;
        },

        referencesMap: {
            "bugtraq": "http://www.securityfocus.com/bid/",
            "cve": "http://cve.mitre.org/cgi-bin/cvename.cgi?name=",
            "nessus": "http://cgi.nessus.org/plugins/dump.php3?id=",
            "arachnids": "http://www.whitehats.com/info/IDS",
            "mcafee": "http://vil.nai.com/vil/content/v",
            "osvdb": "http://osvdb.org/show/osvdb/",
            "msb": "http://technet.microsoft.com/en-us/security/bulletin/",
            "url": "http://"
        },

        signatureRenderer: function(value, metaData, record, rowIdx, colIdx, store){
            if(record.build){
                metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( record.build() ) + '"';
            }
            return Ext.String.htmlEncode( value );
        },

        recommendedActionRenderer: function( value, metaData, record, rowIdx, colIdx, store ){
            var description = value;
            var actionRecord = Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', value, 0, false, false, true);
            if( actionRecord != null ){
                description = actionRecord.get('description');
            }
            metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( description  ) + '"';
            return Ext.String.htmlEncode( description );
        },
        signatureRuleActionRenderer: function(value, metaData, record, rowIdx, colIdx, store){
            var ruleDescription = '';

            var rule = null;
            record.get('matchingRules').forEach( function(matchingRule){
                if(matchingRule.get('action') != 'whitelist'){
                    rule = matchingRule;
                    return false;
                }
            } );

            if(rule != null){
                var ruleAction = rule.get('action');
                var signatureRecommendedAction = record.get('recommendedAction');
                actionDescription = rule.get('action');
                ruleDescription = Ext.String.format( ' (' + 'Rule: {0}, Action:{1}'.t() + ')'.t(), rule.get('description'), Ung.apps.intrusionprevention.Main.ruleActions.findRecord('value', ruleAction, 0, false, false, true).get('description'));
                if(ruleAction == 'default'){
                    actionDescription = Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', signatureRecommendedAction, 0, false, false, true).get('description');
                }else if(ruleAction == 'blocklog'){
                    if(signatureRecommendedAction == 'log'){
                        actionDescription = Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', 'block', 0, false, false, true).get('description');
                    }else{
                        actionDescription = Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', 'disable', 0, false, false, true).get('description');
                    }
                }else{
                    actionDescription = Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', actionDescription, 0, false, false, true).get('description');
                }
            }else{
                actionDescription = Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', 'disable', 0, false, false, true).get('description');
                ruleDescription = ' (' + 'No rule match'.t() + ')';
            }
            metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( actionDescription  ) + Ext.String.htmlEncode( ruleDescription  ) + '"';
            return Ext.String.htmlEncode( actionDescription );
        },

        variableProcessValue: function(name, value){
            var vm = (this.getView().up('apppanel') || this.getView()).getViewModel();

            if(value == 'default'){
                switch(name){
                    case 'HOME_NET':
                        value = vm.get('homeNetworks');
                        break;
                    default:
                        value = 'unknown';
                }
            }
            return value;
        },

        variableValueResolve: function(record){
            var vm = (this.getView().up('apppanel') || this.getView()).getViewModel(),
                variablesStore = vm.get('variables'),
                expandedValue = record.get('value'),
                resolvedRecord = null,
                variableMatches = null,
                resolvedValue = null;

            do{
                variableMatches = Ung.apps.intrusionprevention.MainController.regexSignatureVariable.exec( expandedValue );
                if(variableMatches){
                    resolvedRecord = variablesStore.findRecord('name', variableMatches[1], 0, false, false, true);
                    if(resolvedRecord){
                        resolvedValue = resolvedRecord.get('value');
                        expandedValue = expandedValue.replace(variableMatches[0], Ung.apps.intrusionprevention.MainController.variableProcessValue.call(this, variableMatches[1], resolvedValue));
                    }
                }
            }while(variableMatches != null);

            return Ung.apps.intrusionprevention.MainController.variableProcessValue.call(this, record.get('name'), expandedValue);
        },

        variableValueRenderer: function(value, metaData, record, rowIdx, colIdx, store){
            metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( Ung.apps.intrusionprevention.MainController.variableValueResolve.call(this, record) ) + '"';
            return value;
        },

        regexNumericCondition :  /^(\d+|(\d+\-\d+)|[\d+,]+)$/,
        conditionValidateNumeric: function(value){
            return Ung.apps.intrusionprevention.MainController.regexNumericCondition.exec(value) ? true : 'Invalid numeric value'.t();
        },
}
});

Ext.define('Ung.apps.intrusionprevention.cmp.RuleGridController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.unintrusionrulegrid',

    // !!! need to run on grid initializer
    processRuleSignature: function(record){
        var me = this,
            vm = me.getViewModel(),
            signatures = vm.get('signatures');
        console.log('processRule');
        console.log(record);
        console.log(signatures);
        // foreach signature:
        // if networks != recommended (or new flag to indicate signature change):
        //      Lookup rule in signatures.
        //      Perform deep copy
        //      set "rule generated signature" flag.
        //      Modify signature as appropriate but keep default flag.
        //      
        this.getView().up('apppanel').getController().signaturesChanged();
    },

    getConditions: function(){
        var conditions = {};
        this.getView().editorFields.forEach( function(field){
            if(field.xtype == 'ipsrulesconditionseditor'){
                conditions = field.conditions;
            }
        });
        return conditions;
    },

    getComparators: function(){
        var comparators = {};
        this.getView().editorFields.forEach( function(field){
            if(field.xtype == 'ipsrulesconditionseditor'){
                comparators = field.comparators;
            }
        });
        return comparators;
    },

    onDragDrop: function(){
        this.getView().up('apppanel').getController().signaturesChanged();
    },

    // deleteRecord: function(view, rowIndex, colIndex, item, e, record){
    //     this.processRule(record);
    //     this.callParent(arguments);
    // }
    //

});

Ext.define('Ung.apps.intrusionprevention.cmp.RulesRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unintrusionrulesrecordeditor',

    controller: 'unintrusionrulesrecordeditorcontroller',

    doDestroy: function(){
        // var masterGrid = this.getController().masterGrid;
        this.callParent();
        // delete using rule id lookup.
        //masterGrid.up('apppanel').getController().signaturesChanged();
        // console.log(this);
        // console.log(this.getController());
        //masterGrid.getController().processRuleSignature(this.record);
    }

});

Ext.define('Ung.apps.intrusionprevention.cmp.RulesRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unintrusionrulesrecordeditorcontroller',

    onAfterRender: function (view) {
        this.masterGrid = view.up('grid');

        this.callParent([view]);

        var formpanel = view.down('form');
        formpanel.addDocked({
            xtype: 'toolbar',
            dock: 'bottom',
            items: [{
                xtype: 'tbtext',
                name: 'matchStatus',
                html: '',
            }]
        });
    }
});

Ext.define('Ung.apps.intrusionprevention.cmp.IpsRulesConditionsEditor', {
    extend: 'Ung.cmp.ConditionsEditor',
    alias: 'widget.ipsrulesconditionseditor',

    controller: 'ipsrulesconditionseditorcontroller',


});

Ext.define('Ung.apps.intrusionprevention.cmp.IpsRulesConditionsEditorController', {
    extend: 'Ung.cmp.ConditionsEditorController',
    alias: 'controller.ipsrulesconditionseditorcontroller',

    onAfterRender: function (component) {
        var me = this;

        me.callParent([component]);

        me.updateMatchStatus();
    },

    forceValidate: function(){
        this.callParent();

        this.updateMatchStatus();
    },

    updateMatchStatusCalculator: function(){
        var view = this.getView(),
            store = view.down('grid').getStore(),
            rule = new Ung.model.intrusionprevention.rule({
                action: 'default',
                enabled: 'true',
                conditions: {
                    list: Ext.Array.pluck(store.getRange(), 'data')
                }
            }),
            status = view.up('apppanel').getController().ruleSignatureMatches(rule),
            matchStatus = view.up('form').down('[name=matchStatus]');

        var affectedCount = 0;
        Object.keys(status).forEach(function(k){
            affectedCount += Object.keys(status[k]).length;
        });

        matchStatus.update('Affected signatures:'.t() + ' ' + affectedCount);
    },

    updateMatchStatusCalculatorTask: null,
    updateMatchStatus: function(){
        var me= this;

        if(me.updateMatchStatusCalculatorTask == null){
            me.updateMatchStatusCalculatorTask = new Ext.util.DelayedTask( Ext.bind(this.updateMatchStatusCalculator, me) );
        }
        me.updateMatchStatusCalculatorTask.delay( 500 );
    }
});

Ext.define('Ung.apps.intrusionprevention.cmp.SignaturesRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unintrusionsignaturesrecordeditor',

    controller: 'unintrusionsignaturesrecordeditorcontroller',
});

Ext.define('Ung.apps.intrusionprevention.cmp.SignaturesRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unintrusionsignaturesrecordeditorcontroller',

    editorGidChange: function( me, newValue, oldValue, eOpts ){
        var v = this.getView(),
            vm = this.getViewModel();

        if( ! /^[0-9]+$/.test( newValue )){
            me.setValidation("Gid must be numeric".t());
            return false;
        }

        var record = vm.get('record');
        if(v.getController().validateId(v) == false){
            return false;
        }
        record.setOption('gid', newValue);
        record.setId();
        record.set('signature', record.build());

        me.setValidation(true);
    },

    editorSidChange: function( me, newValue, oldValue, eOpts ){
        var v = this.getView(),
            vm = this.getViewModel();

        if( ! /^[0-9]+$/.test( newValue )){
            me.setValidation("Sid must be numeric".t());
            return false;
        }

        var record = vm.get('record');
        if(v.getController().validateId(v) == false){
            return false;
        }

        record.setOption('sid', newValue);
        record.setId();
        record.set('signature', record.build());

        me.setValidation(true);
    },

    validateId: function(view){
        var vm = this.getViewModel(),
            gidComponent = view.down('[name=gid]'),
            gidValue = gidComponent.getValue(),
            sidComponent = view.down('[name=sid]'),
            sidValue = sidComponent.getValue(),
            match = false;

        var compareRecord = view.record;
        vm.get('signatures').each( function( record ) {
            if( record.get('_id') != compareRecord.get('_id') ){
                if( gidValue == record.get('gid') &&
                    sidValue == record.get('sid')){
                    match = true;
                }
            }
        }, this, true);

        gidComponent.setValidation( match ? "Gid/Sid already in use.".t() : true );
        sidComponent.setValidation( match ? "Gid/Sid already in use.".t() : true );
    },

    editorClasstypeChange: function( me, newValue, oldValue, eOpts ){
        var vm = this.getViewModel();
        if( newValue == null || Ung.apps.intrusionprevention.Main.classtypes.findExact('value', newValue) == null ){
            me.setValidation("Unknown classtype".t());
            return false;
        }
        var record = vm.get('record');
        record.set('classtype', newValue);
        record.set('signature', record.build());
        me.setValidation(true);
    },

    editorMsgChange: function( me, newValue, oldValue, eOpts ){
        var vm = this.getViewModel();
        if( /[";]/.test( newValue ) ){
            me.setValidation( 'Msg contains invalid characters.'.t() );
            return false;
        }
        var record = vm.get('record');
        var content = record.getOption('content');
        if((content == "matchme" && oldValue == "new signature") || ( content == oldValue)){
            record.setOption('content', newValue);
        }
        record.setOption('msg', newValue);
        record.set('signature', record.build());
        me.setValidation(true);
    },

    editorRecommendedActionChange: function( me, newValue, oldValue, eOpts ){
        var vm = this.getViewModel(),
            record = vm.get('record');
        if( newValue == null || Ung.apps.intrusionprevention.Main.signatureActions.findExact('value', newValue) == null ){
            me.setValidation("Unknown action".t());
            return false;
        }
        record.set('recommendedAction', newValue);
        record.set('signature', record.build());
        me.setValidation(true);
    },

    editorSignatureChange: function( me, newValue, oldValue, eOpts ){
        if(!Ung.model.intrusionprevention.signature.isValid(newValue)){
            me.setValidation( 'Signature is invalid.'.t() );
            return false;
        }
        var vm = this.getViewModel(),
            record = vm.get('record');
        var signature = new Ung.model.intrusionprevention.signature(newValue, record.get('category'), false);

        for( var key in signature.data){
            if(key == '_id'){
                continue;
            }
            record.set(key, signature.data[key]);
        }
        me.setValidation(true);
    }

});

Ext.define('Ung.apps.intrusionprevention.cmp.SignatureGridFilter', {
    extend: 'Ung.cmp.GridFilter',
    alias: 'widget.signatureungridfilter',

    controller: 'signatureungridfilter',

    viewModel: {
        data: {
            filterValueDisabled: true
        },
        stores: {
            fields: {
                fields: [{
                    name: 'value',
                },{
                    name: 'description'
                }],
                sorters: [{
                    property: 'value',
                    direction: 'ASC'
                }],
                data: '{fieldsData}'
            },
            comparators: {
                fields: [{
                    name: 'value',
                },{
                    name: 'description'
                }],
                sorters: [{
                    property: 'value',
                    direction: 'DESC'
                }],
                data: '{comparatorsData}'
            },
            values: {
                fields: [{
                    name: 'value',
                },{
                    name: 'description'
                }],
                sorters: [{
                    property: 'value',
                    direction: 'DESC'
                }],
                data: '{valuesData}'
            }
        }
    }

});

Ext.define('Ung.apps.intrusionprevention.cmp.SignatureGridFilterController', {
    extend: 'Ung.cmp.GridFilterController',
    alias: 'controller.signatureungridfilter',

    control: {
        'signatureungridfilter': {
            afterrender: 'afterrenderGetConditions'
        }
    },

    afterrenderGetConditions: function(){
        var me = this,
            v = me.getView(),
            vm = me.getViewModel();

        v.insert(3, {
            xtype: 'button',
            baseCls: 'x-toolbar-item x-btn-default-toolbar-small',
            margin: '2 4 0 0',
            text: 'Create Rule',
            iconCls: 'fa fa-plus-circle fa-lg',
            listeners: {
                click: 'createRuleFromFilter'
            },
            disabled: true,
            bind:{
                disabled: '{!filterMatchesFound}'
            }
        });
        v.insert(2, {
            xtype: 'combo',
            name: 'filterValue',
            _neverDirty: true,
            listeners: {
                change: 'changeFilterSearch',
                buffer: 500
            },
            listConfig: {
                itemTpl: '<div data-qtip="{description}">{value}</div>'
            },
            queryMode: 'local',
            valueField: 'value',
            displayField: 'value',
            triggers: {
                clear: {
                    cls: 'x-form-clear-trigger',
                    hidden: true,
                    handler: function (field) {
                        field.setValue('');
                    }
                }
            },
            disabled: true,
            hidden: true,
            bind:{
                store: '{values}',
                value: '{searchValue}',
                disabled: '{filterValueDisabled}',
                hidden: '{filterValueDisabled}'
            }
        });
        v.insert(2,{
            xtype: 'combo',
            padding: '2 0 0 0',
            _neverDirty: true,
            listeners: {
                change: 'changeFilterComparator',
                buffer: 500
            },
            queryMode: 'local',
            valueField: 'value',
            displayField: 'description',
            bind:{
                store: '{comparators}',
                value: '{comparator}'
            }
        });
        v.insert(2,{
            xtype: 'combo',
            padding: '2 0 0 0',
            _neverDirty: true,
            labelWidth: 'auto',
            name: 'filterField',
            listeners: {
                change: 'changeField'
            },
            queryMode: 'local',
            valueField: 'value',
            displayField: 'description',
            bind:{
                store: '{fields}',
                value: '{field}'
            }
        });

        var filterConditions = [];
        Ext.Object.each(v.up('apppanel').down('[name=rules]').getController().getConditions(), function(k,v){
            filterConditions[k] = v;
            if(k == 'ACTION'){
                filterConditions['ACTIONR'] = Ext.clone(v);
                filterConditions['ACTIONR']['displayName'] = 'Rule Action'.t();
            }
        });
        vm.set('filterConditions', filterConditions);

        var fieldsData = [];
        for(var name in filterConditions){
            if(name == 'SYSTEM_MEMORY'){
                continue;
            }
            fieldsData.push({
                value: name,
                description: filterConditions[name]['displayName']
            });
        }
        vm.set('fieldsData', fieldsData);
        vm.set('field', 'MSG');
    },

    changeField: function(eleme, newValue){
        var me = this,
            view = me.getView(),
            vm = me.getViewModel(),
            conditionComparator =vm.get('filterConditions')[newValue].comparator,
            currentComparator = vm.get('comparator');

        view.up('apppanel').down('[name=rules]').getController().getComparators().forEach(function(comparator){
            if(comparator['name'] == conditionComparator){
                vm.set('comparatorsData', comparator.store);
                var found = false;
                comparator.store.forEach(function(sv){
                    if(currentComparator == sv[0]){
                        found = true;
                    }
                });
                if(!found){
                    vm.set('comparator', comparator.defaultValue);
                }
            }
        });

        vm.set('searchValue', '');
        if(vm.get('filterConditions')[newValue].store || vm.get('filterConditions')[newValue].values){
            if(!vm.get('filterConditions')[newValue].store){
                vm.get('filterConditions')[newValue].store = Ext.create('Ext.data.ArrayStore', {
                    fields: [ 'value', 'description' ],
                    data: vm.get('filterConditions')[newValue].values
                });
            }
            vm.set('searchValue', vm.get('filterConditions')[newValue].store.first().get('value'));
            vm.set('valuesData', Ext.Array.pluck(vm.get('filterConditions')[newValue].store.getRange(), 'data'));
            vm.set('filterValueDisabled', false);
            vm.set('filterSearchDisabled', true);
        }else{
            vm.set('filterValueDisabled', true);
            vm.set('filterSearchDisabled', false);
        }
    },

    changeFilterComparator:function(field){
        var me = this,
            value = field.getValue(),
            grid = this.getView().up('grid') ? this.getView().up('grid') : this.getView().up('panel').down('grid'),
            store = grid.getStore(),
            routeFilter = field.up('panel').routeFilter;

        /**
         * Remove only the filters added through filter data box
         * leave alone the grid filters from columns or routes
         */
        store.getFilters().each(function (filter) {
            if (filter.isGridFilter || filter.source === 'route') {
                return;
            }
            // If filter string is not empty, allow event. Prevent if empty.
            store.removeFilter(filter, value != '' ? true : false);
        });

        // add route filter
        if (routeFilter) {
            store.getFilters().add(routeFilter);
        }

        this.createFilter(grid, store, routeFilter);
    },

    createFilter: function(grid, store, routeFilter){
        var me = this,
            vm = me.getViewModel();

        var searchValue = vm.get('searchValue');

        if(searchValue == ''){
            return;
        }

        var rule = new Ung.model.intrusionprevention.rule({
            action: 'default',
            enabled: 'true',
            conditions: {
                list: [{
                    type: vm.get('field'),
                    comparator: vm.get('comparator'),
                    value: searchValue
                }]
            }
        });

        var status = me.getView().up('apppanel').getController().ruleSignatureMatches(rule, vm.get('filterConditions'));
        store.getFilters().add(function (record) {
            for(var action in status){
                if(status[action][record.data['id']]){
                    return true;
                }
            }
            return false;
        });
    },

    createRuleFromFilter: function(button){
        var me = this,
            vm = me.getViewModel(),
            field = vm.get('field'),
            comparator = vm.get('comparator'),
            value = vm.get('searchValue');

        var newRule = {
            'javaClass': 'com.untangle.app.intrusion_prevention.IntrusionPreventionRule',
            'enabled': true,
            'id': -1,
            'description': '"' + vm.get('fields').findRecord( 'value', field, 0, false, false, true).get('description') + '" ' + vm.get('comparators').findRecord('value', comparator, 0, false, false, true).get('description') + ' "' + value + '"',
            'conditions': {
                'javaClass': "java.util.LinkedList",
                'list': [{
                    'javaClass': 'com.untangle.app.intrusion_prevention.IntrusionPreventionRuleCondition',
                    'type': field,
                    'comparator': comparator,
                    'value': value
                }]
            },
            'action': 'log'
        };
        var rulesTab = button.up('tabpanel').setActiveTab('rules');

        var dt = new Ext.util.DelayedTask( Ext.bind(function(){
            rulesTab.getController().addRecord(null, null, newRule);
        }, me));
        dt.delay(100);
    }
});


Ext.define('Ung.apps.intrusionprevention.cmp.SignatureGridController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.unintrusionsignaturesgrid',

    updateSearchStatusBar: function(){
        // var v = this.getView(),
        //     vm = this.getViewModel(),
        //     appvm = v.up('apppanel').getController().getViewModel(); 
        // // var searchStatus = v.down("[name=searchStatus]");
        // // var hasLogOrBlockFilter = ( v.down("[name=searchLog]").getValue() === true ) || ( v.down("[name=searchBlock]").getValue() === true );
        // // var hasFilter = hasLogOrBlockFilter || ( v.down("[name=searchFilter]").getValue().length >= 2 );
        // var hasFilter = v.down("[name=searchFilter]").getValue().length > 1;
        // var statusText = "", logOrBlockText = "", totalEnabled = 0;
        // // if(!hasLogOrBlockFilter) {
        // //     v.getStore().each(function( record ){
        // //         if( ( record.get('log')) || ( record.get('block')) ) {
        // //             totalEnabled++;
        // //         }
        // //     });
        // //     logOrBlockText = Ext.String.format( '{0} logging or blocking'.t(), totalEnabled);
        // // }
        // if(hasFilter) {
        //     statusText = Ext.String.format( '{0} matching signature(s) found'.t(), v.getStore().getCount() );
        //     // if(!hasLogOrBlockFilter) {
        //     //     statusText += ', ' + logOrBlockText;
        //     // }
        // } else {
        //     statusText = Ext.String.format( '{0} signatures available'.t(), v.getStore().getCount());
        //     // statusText = Ext.String.format( 'Signatures available: {signatureStatusTotal}, Log: {1}, Block: {2}, Disabled: {3}'.t(), appvm.get('signatureStatusTotal'), appvm.get('signatureStatusLog'), appvm.get('signatureStatusBlock'), appvm.get('signatureStatusDisable'));
        // }
        // // searchStatus.update( statusText );
        // vm.set('searchStatus', statusText);
    },

    exportData: function(){
        var grid = this.getView(),
            gridName = (grid.name !== null) ? grid.name : grid.recordJavaClass,
            vm = grid.up('app-intrusion-prevention').getController().getViewModel();

        Ext.MessageBox.wait('Exporting Settings...'.t(), 'Please wait'.t());

        var downloadForm = document.getElementById('downloadForm');
        downloadForm["type"].value = "IntrusionPreventionSettings";
        downloadForm["arg1"].value = "export";
        downloadForm["arg2"].value = vm.get('instance.id');
        downloadForm["arg3"].value = gridName.trim().replace(/ /g, '_');
        downloadForm["arg4"].value = Ext.encode({signatures: grid.up('app-intrusion-prevention').getController().getChangedDataRecords('signatures')});
        downloadForm.submit();

        Ext.MessageBox.hide();
    },

    importHandler: function(importMode, newData){
        this.callParent(arguments);
        // var store = this.getView().getStore();

        // store.each( function(record){
        //     me.updateSignature(record, 'log', record.get('log') );
        //     me.updateSignature(record, 'block', record.get('block') );

        // });
    },

    signaturesReconfigure: function( me , store , columns , oldStore , oldColumns , eOpts ){
        me.getController().updateSearchStatusBar();
    },

    updateSignature: function( record, updatedKey, updatedValue){
        var i, regex;
        var signatureValue = record.get('signature');
        var updatedSubkey = null;

        if(!Ung.model.intrusionprevention.signature.isValid(signatureValue)){
            return;
        }

        // Action replacement
        record.set(updatedKey, updatedValue);
        // if( updatedKey != 'log' && updatedKey != 'block' ){
        if( updatedKey != 'action'){
            record.setOption(updatedKey, updatedValue);
        }
        record.set('signature', record.build());
    }
});

Ext.define('Ung.apps.intrusionprevention.cmp.VariablesRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unintrusionvariablesrecordeditor',

    controller: 'unintrusionvariablesrecordeditorcontroller',
});

Ext.define('Ung.apps.intrusionprevention.cmp.VariablesRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unintrusionvariablesrecordeditorcontroller',

    editorVariableChange: function( me, newValue, oldValue, eOpts ){
        var v = this.getView();
        var vm = this.getViewModel();

        var match = false;
        vm.get('variables').each( function( storeRecord ) {
            if( ( storeRecord !== v.record ) && ( newValue == storeRecord.get('name') ) ){
                match = true;
            }
        });
        if(match){
            me.setValidation("Variable name already in use.".t());
            return false;
        }
        me.setValidation(true);

        if(!Ext.Object.isEmpty(v.up('app-intrusion-prevention').getController().isVariableUsed(newValue))){
            me.setReadOnly(true);
            me.up("").down("[name=activeVariable]").setVisible(true);
        }else{
            me.setReadOnly(false);
            me.up("").down("[name=activeVariable]").setVisible(false);
        }
    }

});

Ext.define('Ung.apps.intrusionprevention.cmp.VariablesGridController', {
    extend: 'Ung.cmp.GridController',

    alias: 'controller.unintrusionvariablesgrid',

    editorWin: function (record) {
        this.dialog = this.getView().add({
            xtype: 'ung.cmp.unintrusionvariablesrecordeditor',
            record: record
        });
        this.dialog.show();
    },

    exportData: function(){
        var grid = this.getView();

        Ext.MessageBox.wait('Exporting Settings...'.t(), 'Please wait'.t());

        var exportForm = document.getElementById('exportGridSettings');
        exportForm.gridName.value = grid.getXType();
        exportForm.gridData.value = this.getExportData(false);
        exportForm.submit();
        Ext.MessageBox.hide();
    },

    deleteRecord: function (view, rowIndex, colIndex, item, e, record) {
        var isUsed = this.getView().up('app-intrusion-prevention').getController().isVariableUsed( record.get('name') );
        if( !Ext.Object.isEmpty(isUsed)){
            var messages = [];
            if('rules' in isUsed){
                isUsed['rules'].forEach( function(rule){
                    messages.push(Ext.String.format( '{0}Rule:{1} {0}{1}{2}'.t(), '<b>', '</b>', rule.get('description') ));
                });
            }
            if('signatures' in isUsed){
                var maxShow = 5;
                var remaining = isUsed['signatures'].length - maxShow; 
                Ext.Array.each(isUsed['signatures'], function(signature){
                    messages.push(Ext.String.format( '{0}Signature:{1} {0}{1}{2}'.t(), '<b>', '</b>', signature.build()));
                    maxShow--;
                    if(!maxShow){
                        return false;
                    }
                });
                if(remaining){
                    messages.push(Ext.String.format('{0} more affected signatures...'.t(), remaining));
                }
            }
            Ext.MessageBox.alert( Ext.String.format("Cannot Delete Variable {0}".t(), record.get('name')), "Variable in use:".t() + "<ul>" + '<li>'+messages.join("<li>") + "</ul>");
        }else{
            if (record.get('markedForNew')) {
                record.drop();
            } else {
                record.set('markedForDelete', true);
            }
        }
    }
});

Ext.define('Ung.model.intrusionprevention.signature',{
    extend: 'Ext.data.Model',
    fields:[{
        name: 'reserved',
        type: 'boolean'
    },{
        name: 'default',
        type: 'boolean'
    },{
        name: 'protocol',
        type: 'string'
    },{
        name: 'lnet',
        type: 'string'
    },{
        name: 'lport',
        type: 'string'
    },{
        name: 'direction',
        type: 'string'
    },{
        name: 'rnet',
        type: 'string'
    },{
        name: 'rport',
        type: 'string'
    },{
        name: 'options',
    },{
        name: 'category',
        type: 'string',
        defaultValue: 'misc'
    },{
        name: 'classtype',
        type: 'string'
    },{
        name: 'recommendedAction',
        type: 'string'
    },{
        name: 'matchingRules'
    },{
        name: 'sid',
        type: 'string'
    },{
        name: 'gid',
        type: 'string'
    },{
        name: 'msg',
        type: 'string'
    },{
        name: 'signature',
        type: 'string'
    },{
        name: 'defaultSignature',
        type: 'string'
    },{
        name: 'networkChanged',
        type: 'boolean'
    }],

    optionsMapIndexes: {},

    constructor: function(signature, category, reserved, session){
        var me = this;
        var data = signature;
        var valid = false;
        if(typeof signature == "string"){
            data = {
                reserved: reserved,
                default: reserved ? true : false,
                protocol: '',
                lnet: '',
                lport: '',
                direction: '',
                rnet: '',
                rport: '',
                options: [],
                category: category,
                recommendedAction: 'log',
                matchingRules: [],
                sid: '1',
                gid: '1',
                networkChanged: false
            };

            valid = Ung.model.intrusionprevention.signature.signatureRegex.test(signature);
            if(valid){
                var matches = Ung.model.intrusionprevention.signature.signatureRegex.exec(signature);

                data['signature'] = signature;
                alert = matches[2].toLowerCase();
                if(matches[3] != ""){
                    data['protocol'] = matches[4].toLowerCase();
                    data['lnet'] = matches[5];
                    data['lport'] = matches[6];
                    data['direction'] = matches[7];
                    data['rnet'] = matches[8];
                    data['rport'] = matches[9];
                }
                data['options'] = matches[10].trim().split(';');
                data['options'].forEach( function(option, index, options){
                    options[index] = option.trim();
                });

                if(matches[1] == '#'){
                    data['recommendedAction'] = 'disable';
                }else{
                    if(matches[2] == 'alert'){
                        data['recommendedAction'] = 'log';
                    }else if(matches[2] == 'reject'){
                        data['recommendedAction'] = 'block';
                    }
                }
            }
        }

        this.callParent([data], session);

        if(typeof signature == "string" && valid){
            me.optionsMapIndexes = {};
            var key = null;
            var foundOptions = [];
            me.data['options'].forEach(function(option, index){
                key = option.substr(0, option.indexOf(':')).trim();
                Ung.model.intrusionprevention.signature.optionsMap.forEach(function(mappedOption){
                    if(mappedOption.name == key){
                        foundOptions.push(key);
                        me.optionsMapIndexes[mappedOption] = index;
                        var value = me.massageGetOptionValue(option.substr(option.indexOf(':') + 1));
                        if(option.defaultValue){
                            value = value ? value : option.defaultValue;
                        }
                        me.data[mappedOption.name] = value;
                    }
                });
            });
            Ung.model.intrusionprevention.signature.optionsMap.forEach(function(mappedOption){
                if(foundOptions.indexOf(mappedOption.name) == -1){
                    me.data[mappedOption.name] = mappedOption.defaultValue;
                }
            });
            this.setId();
        }
    },

    setId: function(){
        this.set('id', this.data['sid'] + '_' + this.data['gid']);
    },

    set: function(fieldName, newValue, options) {
        var result = this.callParent(arguments);
        var me = this;

        if(fieldName != 'signature'){
            // Write back to options
            Ung.model.intrusionprevention.signature.optionsMap.forEach(function(option){
                if(fieldName == option.name){
                    me.setOption(option.name, newValue);
                }
            });
        }else if(fieldName == 'lnet' || fieldName == 'rnet'){
            me.set('networkChanged', true);
        }

        return result;
    },

    massageGetOptionValue: function(value){
        value = value.trim();
        if(value[0] == '"' && value[value.length -1] == '"'){
            value = value.substring(1,value.length - 1);
        }
        return value;
    },

    getOption: function(key){
        var me = this,
            value = null;

        var options = this.get('options');

        var kv = null;
        if(me.optionsMapIndexes && key in me.optionsMapIndexes){
            kv = options[me.optionsMapIndexes[key]].split(':');
            value = me.massageGetOptionValue(kv[1]);
        }else{
            options.forEach( function( option, index, optionsMetadata){
                kv = option.split(':');
                if(kv[0].trim() == key){
                    if(me.optionsMapIndexes && !(key in me.optionsMapIndexes)){
                        me.optionsMapIndexes[key] = index;
                    }
                    kv[1] = me.massageGetOptionValue(kv[1]);
                    if(value != null){
                        // Found second key of same name; create array for return.
                        value = [value];
                    }else if(Array.isArray(value)){
                        value.push(kv[1]);
                    }else{
                        value = kv[1];
                    }
                }
            });
        }
        return value;
    },

    setOption: function( key, value){
        var options = this.get('options');
        var found = false;
        var kv;
        options.forEach( function( option, index, optionsMetadata){
            kv = option.split(':');
            if(kv[0].trim() == key){
                kv[1] = kv[1].trim();
                var preserveQuotes = false;
                if(kv[1][0] == '"' && kv[1][kv[1].length -1] == '"'){
                    preserveQuotes = true;
                }
                kv[1] = (preserveQuotes ? '"' : '' ) + value + (preserveQuotes ? '"' : '' );
                found = true;
                options[index] = kv.join(':');
            }
        });
        if(!found){
            options.push(key + ':' + value);
        }
        this.set('options', options);
    },

    getRecord: function(){
        if(this.get('reserved') == true){
            return {
                sid: this.get('sid'),
                gid: this.get('gid'),
                recommendedAction: this.get('recommendedAction')
            };
        }else{
            return this.build();
        }
    },

    // option to build as recommmended and with rule
    build: function(){
        var signatureAction = 'alert';
        var action = this.get('recommendedAction');
        if( action == 'block' ){
            signatureAction = 'reject';
        }else if(action == 'disable'){
            signatureAction = '#' + signatureAction;
        }

        // Modify lnet/rnet if whitelist rule attached
        var lnet = this.get('lnet');
        var rnet = this.get('rnet');
        this.get('matchingRules').forEach( function(rule){
            if(rule.get('action') == 'whitelist'){
                lnet = rule.addSignatureNetwork("source", lnet, true);
                rnet = rule.addSignatureNetwork("destination", rnet, true);
            }
        });

        return signatureAction + " " +
            (this.get('protocol') ? this.get('protocol') + ' ' : '') +
            (this.get('lnet') ? lnet + ' ' : '') +
            (this.get('lport') ? this.get('lport') + ' ' : '') +
            (this.get('direction') ? this.get('direction') + ' ' : '') +
            (this.get('rnet') ? rnet + ' ' : '') +
            (this.get('rport') ? this.get('rport') + ' ' : '') +
            "(" + this.get('options').join(';') + ")";
    },

    copy: function(){
        var newSignature = new Ung.model.intrusionprevention.signature(this.build(), this.get('category'), this.get('reserved'));
        Ext.Object.merge(newSignature.data, this.data);

        var gid = parseInt(newSignature.get('gid'), 10);
        if( gid < Ung.model.intrusionprevention.signature.customGid){
            gid = Ung.model.intrusionprevention.signature.customGid;
        }else{
            gid += 1;
        }
        newSignature.set('gid', gid.toString());
        newSignature.setId();

        // Somethng about id?

        return newSignature;
    },
    
    statics:{
        customGid: 2400,
        signatureRegex: /^([#\s]+|)(alert|log|pass|activate|dynamic|drop|reject|sdrop)\s+(([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+(\-\>|<>)\s+([^\s]+)\s+([^\s]+)\s+|)\((.+)\)/,
        optionsMap: [{
            name: 'gid',
            defaultValue: '1'
        },{
            name: 'sid'
        },{
            name: 'classtype',
            defaultValue: 'general'
        },{
            name: 'msg'
        }],
        rebuildSignatureKeys:[
            'gid',
            'sid',
            'classtype',
            'category',
            'msg',
            'recommendedAction'
        ],
        isValid: function(signature){
            return Ung.model.intrusionprevention.signature.signatureRegex.test(signature);
        }
    }
});

Ext.define('Ung.model.intrusionprevention.rule',{
    extend: 'Ext.data.Model',
    fields:[{
        name: 'javaClass',
        type: 'string',
        defaultValue: 'com.untangle.app.intrusion_prevention.IntrusionPreventionRule'
    },{
        name: 'action',
        type: 'string'
    },{
        name: 'conditions'
    },{
        name: 'description',
        type: 'string'
    },{
        name: 'enabled',
        type: 'boolean'
    },{
        name: 'id',
        type: 'string'
    },{
        name: 'sourceNetworks',
        type: 'string',
        defaultValue: 'recommended'
    },{
        name: 'destinationNetworks',
        type: 'string',
        defaultValue: 'recommended'
    }],

    hasCustomNetworks: function(){
        // If true, this rule creates a signature copy.  Otherwise it does not.
        var me = this;
        return ( me.get('sourceNetworks') != 'recommended' ) || ( me.get('destinationNetworks') != 'recommended' );
    },

    matchSignature: function(signature, editorConditions, vm){
        var me = this;
        if(!me.get('enabled')){
            return false;
        }
        var allMatch = true;
        me.get('conditions').list.forEach(function(condition){
            var match = true;
            var editorCondition = editorConditions[condition.type];
            if(!editorCondition){
                console.log('Unable to find condition: ' + condition.type);
            }

            var signatureValue = null;
            var conditionKey = condition.type.toLowerCase();
            switch(conditionKey){
                case 'system_memory':
                    signatureValue = vm.get('system_memory');
                    break;
                case 'signature':
                    signatureValue = signature.data['signature'];
                    break;
                case 'classtype':
                    signatureValue = signature.data['classtype'];
                    break;
                case 'msg':
                    signatureValue = signature.data['msg'];
                    break;
                case 'src_addr':
                    signatureValue = signature.data['lnet'];
                    break;
                case 'src_port':
                    signatureValue = signature.data['lport'];
                    break;
                case 'dst_addr':
                    signatureValue = signature.data['rnet'];
                    break;
                case 'dst_port':
                    signatureValue = signature.data['rport'];
                    break;
                case 'custom':
                    signatureValue = signature.data['reserved'] ? "false" : "true";
                    break;
                case 'action':
                    signatureValue = signature.data['recommendedAction'];
                    break;
                default:
                    signatureValue = signature.data[conditionKey];
            }

            if(typeof(signatureValue) == 'string'){
                signatureValue = signatureValue.toLowerCase();
            }

            switch(editorCondition.comparator){
                case 'numeric':
                    match = me.matchesNumeric(parseInt(signatureValue, 10), condition.comparator, condition.value);
                    break;
                case 'boolean':
                    var conditionValue = condition.value;
                    if(typeof(conditionValue) != 'object'){
                        if( typeof(conditionValue) == 'string' ){
                            conditionValue = conditionValue.toLowerCase().split(',');
                        }else{
                            conditionValue = ["true"];
                        }
                    }
                    match = me.matchesIn(signatureValue, condition.comparator, conditionValue);
                    break;
                case 'text':
                    match = me.matchesText(signatureValue, condition.comparator, condition.value.toLowerCase());
                    break;
                case 'network':
                    match = me.matchesNetwork(signatureValue.toLowerCase(), condition.comparator, condition.value.toLowerCase());
                    break;
                case 'port':
                    match = me.matchesPort(signatureValue.toLowerCase(), condition.comparator, condition.value.toLowerCase());
                    break;
                default:
                    // !!! throw exception
                    console.log('unknown comparator:' + editorCondition.comparator);
                    match = false;
            }

            if(!match){
                allMatch = false;
            }
        });

        return allMatch;
    },

    matchesNumeric: function(signatureValue, comparator, conditionValue){
        var me = this,
            conditionValues;
        if(conditionValue.indexOf(',') != -1){
            conditionValues = conditionValue.split(',');
            conditionValues.forEach( function(number, index){
                conditionValues[index] = parseInt(number, 10);
            });
            return me.matchesIn(signatureValue, comparator, conditionValues);
        }else if(conditionValue.indexOf('-') != -1){
            conditionValues = conditionValue.split('-');
            return me.matchesIn(signatureValue, comparator, conditionValues[0].trim(), conditionValues[1].trim());
        }
        conditionValue = parseInt(conditionValue, 10);
        switch(comparator){
            case "=":
                return signatureValue == conditionValue;
            case "!=":
                return signatureValue != conditionValue;
            case "<=":
                return signatureValue <= conditionValue;
            case "<":
                return signatureValue < conditionValue;
            case ">":
                return signatureValue > conditionValue;
            case ">=":
                return signatureValue >= conditionValue;
            case "substr":
                return signatureValue.toString().indexOf(conditionValue.toString()) != -1;
            case "!substr":
                return signatureValue.toString().indexOf(conditionValue.toString()) == -1;
        }

        return false;
    },

    matchesIn: function(signatureValue, comparator, conditionStartValue, conditionStopValue){
        var isIn;
        if(conditionStopValue){
            isIn = (signatureValue >= parseInt(conditionStartValue, 10) && signatureValue <= parseInt(conditionStopValue, 10));
        }else{
            isIn = Ext.Array.contains(conditionStartValue, signatureValue);
        }

        if(comparator == "="){
            return isIn;
        }else if(comparator == "!="){
            return !isIn;
        }

        return false;
    },

    matchesText: function(signatureValue, comparator, conditionValue){
        switch(comparator){
            case "=":
                return signatureValue == conditionValue;
            case "!=":
                return signatureValue != conditionValue;
            case "substr":
                return signatureValue.indexOf(conditionValue) != -1;
            case "!substr":
                return signatureValue.indexOf(conditionValue) == -1;
        }

        return false;
    },

    ipv4NetworkToLong: function(ip, prefix){
        if(prefix == 0){
            return 0;
        }
        var network = 0;
        ip.split('.').forEach( function(octet){
            network <<= 8;
            network += parseInt(octet, 10);
        });
        return ( (network >>> 0) & ( ( ~0 << (32 - prefix)) >>> 0) );
    },

    /**
     * Match network as follows:
     *
     * = or !=              Exact string match or signature contains exact network match.
     * substr or !substr    Text substring match.
     *
     * If signatureValue is a list, any match of the list is considered a valid match.
     * For example, if the list contains a lit of IP addresses like [1.2.3.4, 2.3.4.5], a conditionValue
     * of 1.2.3.0/24 or 2.0.0.0/8 would match even though it's not matching the entire list.
     *
     * @param  {[type]} signatureValue Either a single value or a list if it is inside square brackets.
     * @param  {[type]} comparator  =, !=, substr, ~substr
     * @param  {[type]} conditionValue Value to check.
     * @return {[type]}             true if match, false if not.
     */
    matchesNetwork: function(signatureValue, comparator, conditionValue){
        var equalComparator = comparator.substring(comparator.length-1) == '=';

        var matches;
        var signatureValues = [];
        if(signatureValue[0] == '['){
            signatureValues = signatureValue.substring(1,signatureValue.length-1).split(/\s*,\s*/);
        }else{
            signatureValues.push(signatureValue);
        }

        var targetPrefix = 32;
        if( equalComparator &&
            Ung.model.intrusionprevention.rule.ipv4NetworkRegex.test(conditionValue)){
            matches = Ung.model.intrusionprevention.rule.ipv4NetworkRegex.exec(conditionValue);
            targetPrefix = matches[4] ? parseInt(matches[4], 10) : 32;
            conditionValue = this.ipv4NetworkToLong(matches[1], targetPrefix);
        }

        var record = Ext.Array.findBy(signatureValues, Ext.bind(function(value){
            var matchValue = value;
            if(equalComparator){
                if(Ung.model.intrusionprevention.rule.ipv4NetworkRegex.test(value)){
                    matches = Ung.model.intrusionprevention.rule.ipv4NetworkRegex.exec(value);
                    matchValue = this.ipv4NetworkToLong(matches[1], targetPrefix);
                }
                if(matchValue == conditionValue){
                    return true;
                }
            }else{
                if(value.indexOf(conditionValue) != -1 ){
                    return true;
                }
            }
        }, this) );

        switch(comparator){
            case "=":
                return record != null;
            case "!=":
                return record == null;
            case "substr":
                return record != null;
            case "!substr":
                return record == null;
        }

        return false;
    },

    matchesPort: function(signatureValue, comparator, conditionValue){
        var equalComparator = comparator.substring(comparator.length-1) == '=';

        var signatureValues = [];
        if(signatureValue[0] == '['){
            signatureValues = signatureValue.substring(1,signatureValue.length-1).split(/\s*,\s*/);
        }else{
            signatureValues.push(signatureValue);
        }

        var record = Ext.Array.findBy(signatureValues, Ext.bind(function(value){
            var matchValue = value;
            if(equalComparator){
                if(matchValue == conditionValue){
                    return true;
                }
            }else{
                if(value.indexOf(conditionValue) != -1 ){
                    return true;
                }
            }
        }, this) );

        switch(comparator){
            case "=":
                return record != null;
            case "!=":
                return record == null;
            case "substr":
                return record != null;
            case "!substr":
                return record == null;
        }

        return false;
    },

    addSignatureNetwork: function(sourceType, network, negate){
        if(this.get(sourceType+"Networks") != "recommended"){
            if(network.indexOf('[') > -1){
                network = network.substr(network.indexOf('[') + 1, network.lastIndexOf(']') -1);
            }

            var addNetwork = this.get(sourceType+"Networks");
            if(negate == true){
                addNetwork = '!' + addNetwork;
            }

            if(network == 'any'){
                network = addNetwork;
            }else{
                network = Ext.String.format( '[{0},{1}]', network, addNetwork);
            }
        }
        return network;
    },


    statics:{
        ipv4NetworkRegex: /((\d{1,3}\.){3,3}\d{1,3})(\/(\d{1,2}|)|)/
    }
});


Ext.define ('Ung.apps.intrusionprevention.model.Condition', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'javaClass', type: 'string', defaultValue: ''},
        { name: 'type', type: 'string' },
        { name: 'comparator', type: 'string', defaultValue: '='},
        { name: 'value', type: 'auto', defaultValue: '' }
    ],
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});

Ext.define('Ung.apps.intrusionprevention.cmp.BypassRulesController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.unintrusionbypassrulesgrid',

    warnSrcAddrIsLan: function() {
        var vm = this.getViewModel();

        vm.set('warnBypassRuleSrcAddrIsLan', false);
        var lanIpAddrs = Util.getLanIpAddrs(),
            bypassRules = Ext.Array.pluck(this.getView().getStore().getRange(), 'data');    

        if(bypassRules) {
            bypassRules.forEach(function(rule) {
                if(rule) {
                    rule.conditions.list.forEach(function(condition) {
                        if(condition.conditionType == "SRC_ADDR" && lanIpAddrs.includes(condition.value)) {
                            vm.set('warnBypassRuleSrcAddrIsLan', true);
                        }
                    });
                }
            });
        }
    },
});

Ext.define('Ung.apps.intrusionprevention.cmp.BypassRulesRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unintrusionbypassrulesrecordeditor',

    controller: 'unintrusionbypassrulesrecordeditorcontroller',
});

Ext.define('Ung.apps.intrusionprevention.cmp.BypassRulesRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unintrusionbypassrulesrecordeditorcontroller',

    onApply: function () {
        var view = this.getView();
        if(view.up('[srcAddrIsLanCheck=true]')) {
            var controller = view.up('[srcAddrIsLanCheck=true]').getController();
            this.callParent();
            controller.warnSrcAddrIsLan();
        } else
            this.callParent();
    }
});
Ext.define('Ung.apps.intrusionprevention.view.Advanced', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-intrusion-prevention-advanced',
    itemId: 'advanced',
    scrollable: true,
    withValidation: false,
    name: 'advanced',

    region: 'center',

    title: "Advanced".t(),

    bodyPadding: 10,

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    defaults: {
        xtype: 'fieldset',
        padding: 10,
    },

    items: [{
        title: 'Content Processing'.t(),
        defaults: {
            margin: '5 0'
        },
        items: [{
            xtype: 'numberfield',
            fieldLabel: 'Maximum scan depth (bytes)'.t(),
            labelWidth: 200,
            width: 300,
            allowBlank: false,
            minValue: 0,
            bind: '{settings.iptablesMaxScanSize}'
        }]
    },{
        title: 'Signature Options'.t(),
        defaults: {
            margin: '5 0'
        },
        items: [{
            xtype: 'combo',
            fieldLabel: 'Block action'.t(),
            bind: '{settings.blockAction}',
            queryMode: 'local',
            editable: false,
            displayField: 'description',
            valueField: 'value',
            store: [
                ['reject', 'reject (default)'.t()],
                ['drop', 'drop'.t()]
            ]
        }]
    }, {
        title: 'Update Signatures and Signatures Schedule'.t(),
        defaults: {
            margin: '5 0'
        },
        items: [{
            xtype: 'component',
            html: 'You can manually update signatures or set a schedule.'.t()
        }, {
            xtype: 'combo',
            fieldLabel: 'Frequency'.t(),
            store: Ung.apps.intrusionprevention.Main.updateSignatureFrequency,
            bind: '{settings.updateSignatureFrequency}',
            queryMode: 'local',
            editable: false,
            displayField: 'name',
            valueField: 'value'
        },
        Ung.apps['intrusionprevention'].Main.updateSignatureDaily(),
        Ung.apps['intrusionprevention'].Main.updateSignatureWeekly(),
        Ung.apps['intrusionprevention'].Main.updateSignatureButton]
    }]
});
Ext.define('Ung.apps.intrusionprevention.view.BypassRules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-intrusion-prevention-bypass',
    itemId: 'bypass-rules',
    scrollable: true,
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    title: 'Bypass Rules'.t(),
    controller: 'unintrusionbypassrulesgrid',
    srcAddrIsLanCheck: true,

    listeners: {
        afterrender: 'warnSrcAddrIsLan',
        itemclick: 'warnSrcAddrIsLan'
    },

    dockedItems: [{
        xtype: 'container',
        padding: '8 5',
        style: { fontSize: '12px', background: '#DADADA'},
        html: '<i class="fa fa-exclamation-triangle" style="color: red;"></i> ' + 'One or more rules have the condition of the source address a LAN address.'.t(),
        hidden: true,
        bind: {
            hidden: '{!warnBypassRuleSrcAddrIsLan}'
        }
    }],

    tbar: ['@add', '->', '@import', '@export'],
    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    emptyText: 'No Bypass Rules defined'.t(),

    emptyRow: {
        ruleId: -1,
        enabled: true,
        bypass: true,
        javaClass: 'com.untangle.uvm.network.BypassRule',
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        description: ''
    },

    importValidationJavaClass: true,

    importValidationForComboBox: true,

    bind: '{bypassRules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions,
        {
            header: 'Bypass'.t(),
            xtype: 'checkcolumn',
            dataIndex: 'bypass',
            width: Renderer.booleanWidth
        }],
        editorXtype: 'ung.cmp.unintrusionbypassrulesrecordeditor',
        editorFields: [
            Field.enableRule(),
            Field.description,
            Field.conditions(
                'com.untangle.uvm.network.BypassRuleCondition',[
                "DST_ADDR",
                "DST_PORT",
                "DST_INTF",
                "SRC_ADDR",
                "SRC_PORT",
                "SRC_INTF",
                "PROTOCOL",
                "CLIENT_TAGGED",
                "SERVER_TAGGED"
            ]),
           Field.bypass
    ]
});
Ext.define('Ung.apps.intrusionprevention.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-intrusion-prevention-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    scrollable: true,
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    controller: 'unintrusionrulegrid',

    viewConfig: {
        listeners: {
            drop: 'onDragDrop'
        }
    },

    emptyText: 'No Rules Defined'.t(),
    name: 'rules',

    restrictedRecords: {
        keyMatch: 'id',
        valueMatch: /^reserved\_/,
        editableFields:[
            "enabled"
        ]
    },

    region: 'center',

    bind: '{rules}',

    bbar: [{
        xtype: 'tbtext',
        name: 'ruleStatus',
        bind: {
            html: Ext.String.format('{0}Signatures affected:{1} Log: {2}, Block: {3}, Disabled: {4}'.t(), '<b>', '</b>', '{signatureStatusLog}', '{signatureStatusBlock}', '{signatureStatusDisable}'),
            hidden: '{signatureStatusTotal == 0}'
        }
    }],

    tbar: ['@add', '->', '@import', '@export'],
    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'id',
    copyAppendField: 'description',
    recordModel: 'Ung.model.intrusionprevention.rule',

    emptyRow: {
        javaClass: 'com.untangle.app.intrusion_prevention.IntrusionPreventionRule',
        enabled: true,
        id: -1,
        description: '',
        conditions: {
            javaClass: "java.util.LinkedList",
            'list': []
        },
        action: 'default',
        sourceNetworks: 'recommended',
        destinationNetworks: 'recommended'
    },

    importValidationJavaClass: true,

    importValidationForComboBox: true,

    skipConditionsCheck: true,

    columns: [{
        xtype:'checkcolumn',
        header: "Enabled".t(),
        dataIndex: 'enabled',
        width: Renderer.booleanWidth
    },{
        header: "Description".t(),
        dataIndex: 'description',
        width: Renderer.messageWidth,
        flex:2,
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t(),
            allowBlank: false,
            blankText: 'The description cannot be blank.'.t(),
        }
    },{
        header: "Conditions".t(),
        dataIndex: 'conditions',
        width: Renderer.conditionsWidth,
        flex: 3,
        renderer: Ung.cmp.ConditionsEditor.renderer
    },{
        header: "Action".t(),
        dataIndex: 'action',
        width: Renderer.messageWidth,
        flex: 2,
        renderer: Ung.apps.intrusionprevention.MainController.ruleActionsRenderer,
        editor: {
            xtype: 'combo',
            editable: false,
            queryMode: 'local',
            store: Ung.apps.intrusionprevention.Main.ruleActions,
            displayField: 'description',
            valueField: 'value'
        }
    }],

    editorXtype: 'ung.cmp.unintrusionrulesrecordeditor',
    editorFields: [{
        xtype:'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Enabled'.t(),
    },{
        xtype:'textfield',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: "[enter description]".t(),
        allowBlank: false
    },
    Ung.cmp.ConditionsEditor.build({
        xtype: 'ipsrulesconditionseditor',
        text:{
            condition: 'For all signatures that match the following conditions:'.t(),
            action: 'Modify each signature as:'.t(),
        },
        bind: '{record.conditions}',
        flex: 1,
        model: 'Ung.apps.intrusionprevention.model.Condition',
        fields:{
            type: 'type',
            comparator: 'comparator',
            value: 'value',
        },
        javaClassValue: 'com.untangle.app.intrusion_prevention.IntrusionPreventionRuleCondition',

        comparators:[{
            name: 'numeric',
            defaultValue: '=',
            store: [[
                '<', '<'.t()
            ],[
                '<=', '<='.t()
            ],[
                '=', '='.t()
            ],[
                '!=', '!='.t()
            ],[
                '>=', '>='.t()
            ],[
                '>', '>'.t(),
            ],[
                'substr', 'Contains'.t()
            ],[
                '!substr', 'Does not contain'.t()
            ]]
        },{
            name: 'network',
            defaultValue: 'substr',
            store: [[
                '=', '='.t()
            ],[
                '!=', '!='.t()
            ],[
                'substr', 'Contains'.t()
            ],[
                '!substr', 'Does not contain'.t()
            ]]
        },{
            name: 'port',
            defaultValue: 'substr',
            store: [[
                '=', '='.t()
            ],[
                '!=', '!='.t()
            ],[
                'substr', 'Contains'.t()
            ],[
                '!substr', 'Does not contain'.t()
            ]]
        }],

        conditions: [{
            name: "SID",
            displayName: "Signature Identifier".t(),
            type: "textfield",
            comparator: 'numeric',
            validator: Ung.apps.intrusionprevention.MainController.conditionValidateNumeric
        },{
            name:"GID",
            displayName: "Group Identifier".t(),
            type: 'textfield',
            comparator: 'numeric',
            validator: Ung.apps.intrusionprevention.MainController.conditionValidateNumeric
        },{
            name:"CATEGORY",
            displayName: "Category".t(),
            type: 'checkboxgroup',
            store: Ung.apps.intrusionprevention.Main.categories,
            storeValue: 'value',
            storeLabel: 'value',
            storeTip: Ung.apps.intrusionprevention.Main.categoryRenderer,
            comparator: 'boolean'
        },{
            name:"CLASSTYPE",
            displayName: "Classtype".t(),
            type: 'checkboxgroup',
            store: Ung.apps.intrusionprevention.Main.classtypes,
            storeValue: 'value',
            storeLabel: 'value',
            storeTip: Ung.apps.intrusionprevention.Main.classtypeRenderer,
            comparator: 'boolean'
        },{
            name:"MSG",
            displayName: "Message".t(),
            type: 'textfield',
            comparator: 'text'
        },{
            name:"PROTOCOL",
            displayName: "Protocol".t(),
            type: 'checkboxgroup',
            values: [],
            comparator: 'boolean'
        },{
            name:"SRC_ADDR",
            displayName: "Source Address".t(),
            type: 'textfield',
            vtype: undefined,
            comparator: 'network'
        },{
            name:"SRC_PORT",
            displayName: "Source Port".t(),
            type: 'textfield',
            vtype: undefined,
            comparator: 'port'
        },{
            name:"DST_ADDR",
            displayName: "Destination Address".t(),
            type: 'textfield',
            vtype: undefined,
            comparator: 'network'
        },{
            name:"DST_PORT",
            displayName: "Destination Port".t(),
            type: 'textfield',
            vtype: undefined,
            comparator: 'port'
        },{
            name:"SIGNATURE",
            displayName: "Any part of signature".t(),
            type: 'textfield',
            comparator: 'text'
        },{
            name:"CUSTOM",
            displayName: "Custom signature".t(),
            type: 'boolean',
            comparator: 'boolean',
            values: [[
                "true","True".t()
            ],[
                "false","False".t()
            ]]
        },{
            name:"ACTION",
            displayName: "Recommended Action".t(),
            type: 'checkboxgroup',
            store: Ung.apps.intrusionprevention.Main.signatureActions,
            storeValue: 'value',
            storeLabel: 'description',
            storeTip: Ung.apps.intrusionprevention.Main.actionRenderer,
            comparator: 'boolean'
        },{
            name:"SYSTEM_MEMORY",
            displayName: "System Memory".t(),
            type: 'sizefield',
            comparator: 'numeric',
            validator: Ung.apps.intrusionprevention.MainController.conditionValidateNumeric
        }]
    }),
    {
        xtype: 'combo',
        fieldLabel: 'Action'.t(),
        labelAlign: 'right',
        width: 400,
        store: Ung.apps.intrusionprevention.Main.ruleActions,
        bind: {
            value: '{record.action}'
        },
        queryMode: 'local',
        editable: false,
        typeField: 'type',
        displayField: 'description',
        valueField: 'value'
    },{
        fieldLabel: 'Match source networks'.t(),
        xtype: 'combo',
        labelAlign: 'right',
        width: 400,
        bind: {
            store: '{networkVariables}',
            value: '{record.sourceNetworks}',
            hidden: '{record.action != "whitelist"}'
        },
        listConfig:   {
            itemTpl: '<div data-qtip="{detail}">{description}</div>'
        },
        queryMode: 'local',
        editable: false,
        typeField: 'type',
        displayField: 'description',
        valueField: 'value',
        matchFieldWidth: false
    },{
        fieldLabel: 'Match destination networks'.t(),
        xtype: 'combo',
        labelAlign: 'right',
        width: 400,
        bind: {
            store: '{networkVariables}',
            value: '{record.destinationNetworks}',
            hidden: '{record.action != "whitelist"}'
        },
        listConfig:   {
            itemTpl: '<div data-qtip="{detail}">{description}</div>'
        },
        queryMode: 'local',
        editable: false,
        typeField: 'type',
        displayField: 'description',
        valueField: 'value',
        matchFieldWidth: false
    },{
        xtype: 'component',
        style: 'background-color: yellow;',
        padding: '10px 0px 10px 0px',
        bind:{
            html: Ext.String.format("{0}Warning:{1} No variables found with excluded like '!{2}'.".t(), '<b>', '</b>', '{defaultNetwork}'),
            hidden: '{record.action != "whitelist" || networkVariablesList.length > 1}'
        }
    },{
        xtype: 'component',
        bind:{
            html: Ext.String.format("{0}NOTE:{1} Affected signatures use Recommended action.".t(), '<b>', '</b>'),
            hidden: '{record.action != "whitelist"}'
        }
    }]
});
Ext.define('Ung.apps.intrusionprevention.view.Signatures', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-intrusion-prevention-signatures',
    itemId: 'signatures',
    title: 'Signatures'.t(),
    scrollable: true,
    withValidation: false,
    controller: 'unintrusionsignaturesgrid',

    name: 'signatures',

    region: 'center',

    sortableColumns: true,
    enableColumnHide: true,
    plugins: [
        'gridfilters'
    ],
    features: [{
        id: "grouping",
        ftype: 'grouping',
        groupHeaderTpl: ['{columnName}: {name:this.formatName} ({rows.length} signature{[values.rows.length > 1 ? "s" : ""]})',{
            formatName: function(name){
                return name == null ? "general" : Ext.String.trim(name);
            }
        }],
        startCollapsed: true
     }],

    bind: '{signatures}',

    listeners: {
        reconfigure: 'signaturesReconfigure'
    },

    // tbar: ['@add', '->', '@import', '@export'],
    tbar: [
        '@add',
        '-',
    {
        xtype: 'signatureungridfilter'
    }],
    recordActions: ['edit', 'copy', 'delete'],
    copyId: 'sid',
    copyIdPreserve: true,
    copyAppendField: 'msg',
    copyReferenceFields: ['matchingRules'],
    copyModify: [{
        key: 'reserved',
        value: false,
    },{
        key: 'default',
        value: false,
    }],

    restrictedRecords: {
        keyMatch: 'reserved',
        valueMatch: true
    },

    recordModel: 'Ung.model.intrusionprevention.signature',
    emptyRow: "alert tcp any any -> any any ( msg:\"new signature\"; classtype:unknown; sid:1999999; gid:1; content:\"matchme\"; nocase;)",

    columns: [{
        header: "Gid".t(),
        dataIndex: 'gid',
        width: Renderer.idWidth,
        renderer: Ung.apps.intrusionprevention.MainController.idRenderer
    },{
        header: "Sid".t(),
        dataIndex: 'sid',
        width: Renderer.idWidth,
        renderer: Ung.apps.intrusionprevention.MainController.idRenderer
    },{
        header: "Classtype".t(),
        dataIndex: 'classtype',
        width: Renderer.messageWidth,
        renderer: Ung.apps.intrusionprevention.MainController.classtypeRenderer
    },{
        header: "Category".t(),
        dataIndex: 'category',
        width: Renderer.messageWidth,
        renderer: Ung.apps.intrusionprevention.MainController.categoryRenderer
    },{
        header: "Protocol".t(),
        dataIndex: 'protocol',
        width: Renderer.protocolWidth,
        renderer: Ung.apps.intrusionprevention.MainController.signatureRenderer
    },{
        header: "Msg".t(),
        dataIndex: 'msg',
        width: Renderer.messageWidth,
        flex:3,
        renderer: Ung.apps.intrusionprevention.MainController.signatureRenderer
    },{
        header: "Signature".t(),
        dataIndex: 'signature',
        width: Renderer.messageWidth,
        flex:3,
        hidden: true
    },{
        header: "Recommended Action".t(),
        dataIndex: 'recommendedAction',
        width: Renderer.messageWidth,
        renderer: Ung.apps.intrusionprevention.MainController.recommendedActionRenderer
    },{
        header: "Rule Action".t(),
        dataIndex: 'matchingRules',
        width: Renderer.messageWidth,
        renderer: Ung.apps.intrusionprevention.MainController.signatureRuleActionRenderer
    }],

    editorXtype: 'ung.cmp.unintrusionsignaturesrecordeditor',
    editorFields: [{
        xtype:'numberfield',
        name: 'gid',
        bind: '{record.gid}',
        fieldLabel: 'Gid'.t(),
        emptyText: '[enter gid]'.t(),
        allowBlank: false,
        hideTrigger: true,
        listeners:{
            change: 'editorGidChange'
        }
    },{
        xtype:'numberfield',
        name: 'sid',
        bind: '{record.sid}',
        fieldLabel: 'Sid'.t(),
        emptyText: '[enter sid]'.t(),
        allowBlank: false,
        hideTrigger: true,
        listeners:{
            change: 'editorSidChange'
        }
     },{
        fieldLabel: 'Classtype'.t(),
        editable: false,
        xtype: 'combo',
        queryMode: 'local',
        bind:{
            value: '{record.classtype}',
        },
        store: Ung.apps.intrusionprevention.Main.classtypes,
        valueField: 'value',
        displayField: 'value',
        forceSelection: true,
        listeners: {
            change: 'editorClasstypeChange'
        }
    },{
        fieldLabel: 'Category'.t(),
        bind:{
            value: '{record.category}',
        },
        store: Ung.apps.intrusionprevention.Main.categories,
        emptyText: "[enter category]".t(),
        allowBlank: false,
        xtype: 'combo',
        queryMode: 'local',
        valueField: 'value',
        displayField: 'value'
    },{
        xtype:'textfield',
        bind: '{record.msg}',
        fieldLabel: 'Msg'.t(),
        emptyText: "[enter msg]".t(),
        allowBlank: false,
        listeners: {
            change: 'editorMsgChange'
        }
     },{
        fieldLabel: 'Recommended Action'.t(),
        editable: false,
        xtype: 'combo',
        queryMode: 'local',
        bind:{
            value: '{record.recommendedAction}',
        },
        store: Ung.apps.intrusionprevention.Main.signatureActions,
        valueField: 'value',
        displayField: 'description',
        forceSelection: true,
        listeners: {
            change: 'editorRecommendedActionChange'
        }
     },{
        xtype:'textareafield',
        bind: '{record.signature}',
        fieldLabel: 'Signature'.t(),
        emptyText: "[enter signature]".t(),
        allowBlank: false,
        height: 100,
        listeners:{
            change: 'editorSignatureChange'
        }
    }]
});
Ext.define('Ung.apps.intrusionprevention.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-intrusion-prevention-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',

    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,

        layout: {
            type: 'vbox',
            align: 'stretch'
        },

        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/intrusion-prevention.svg" width="80" height="80"/>' +
                '<h3>Intrusion Prevention</h3>' +
                '<p>' + 'Intrusion Prevention scans, detects, and blocks attacks and suspicious traffic using signatures.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate'
        },{
            xtype: 'fieldset',
            title: '<i class="fa fa-cogs"></i> ' + "Settings".t(),
            defaults: {
                labelWidth: 200
            },
            padding: 10,
            hidden: true,
            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{state.on !== true || state.power === true}',
                disabled: '{state.on !== true || state.power === true}',
                hidden: '{state.on !== true || state.power === true}'
            },
            items:[{
                xtype: 'combo',
                fieldLabel: 'When to scan'.t(),
                bind: '{settings.iptablesProcessing}',
                queryMode: 'local',
                editable: false,
                displayField: 'description',
                valueField: 'value',
                matchFieldWidth: false,
                width: 425,
                store: Ung.apps.intrusionprevention.Main.processingStage,
                listConfig:   {
                    itemTpl: '<div data-qtip="{detail}">{description}</div>'
                },
            }]
        },{
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + "Overview".t(),
            defaults: {
                labelWidth: 200
            },
            padding: 10,
            hidden: true,
            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{state.on !== true || state.power === true}',
                disabled: '{state.on !== true || state.power === true}',
                hidden: '{state.on !== true || state.power === true}'
            },

            items: [{
                xtype: 'container',
                layout: 'hbox',
                padding: '0 0 10 0',
                flex: 1,
                hidden: true,
                bind: {
                    hidden: '{!daemonErrors}',
                },
                items:[{
                    fieldLabel: 'Warnings'.t(),
                    xtype: 'textarea',
                    height: 100,
                    autoWidth: true,
                    flex: 1,
                    fieldStyle: {
                        fontFamily: 'monospace',
                        border: 'solid 5px yellow'
                    },
                    bind: {
                        value: '{daemonErrors}'
                    }
                }]
            },{
                xtype: 'component',
                html: 'One or more signatures are not running.'.t(),
                padding: '0 0 10 0',
                hidden: true,
                bind: {
                    hidden: '{!daemonErrors}',
                },
            },{
                xtype: 'displayfield',
                fieldLabel: "Signatures available".t(),
                bind:{
                    value: '{signatureStatusTotal}',
                    hidden: '{signatureStatusTotal == 0}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: '&nbsp;'.repeat(5) + Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', 'log').get('description'),
                bind: {
                    value: '{signatureStatusLog}',
                    hidden: '{signatureStatusLog == 0}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: '&nbsp;'.repeat(5) + Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', 'block').get('description'),
                bind: {
                    value: '{signatureStatusBlock}',
                    hidden: '{signatureStatusBlock == 0}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: '&nbsp;'.repeat(5) + Ung.apps.intrusionprevention.Main.signatureActions.findRecord('value', 'disable').get('description'),
                bind: {
                    value: '{signatureStatusDisable}',
                    hidden: '{signatureStatusDisable == 0}'
                }
            }, {
                xtype: 'component',
                style: 'background-color: yellow;',
                padding: '10px 0px 10px 0px',
                bind:{
                    html: Ext.String.format("{0}Warning:{1} No signatures are enabled for Log or Block.".t(), '<b>', '</b>'),
                    hidden: '{signatureStatusTotal == 0 || signatureStatusTotal != signatureStatusDisable}'
                }
            }, {
                xtype: 'displayfield',
                fieldLabel: "Last update".t(),
                bind: {
                    value: '{lastUpdate}',
                    hidden: '{lastUpdate == ""}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: '&nbsp;'.repeat(5) + "Last check".t(),
                bind: {
                    value: '{lastUpdateCheck}',
                    hidden: '{lastUpdateCheck == ""}'
                }
            }, {
                xtype: 'component',
                bind:{
                    html: Ext.String.format("{0}Note:{1} {2} continues to maintain the recommended signature settings through automatic updates. You are free to add signatures, however it is not required.".t(), '<b>', '</b>', '{companyName}')
                }
            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appmemory',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
Ext.define('Ung.apps.intrusionprevention.view.Variables', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-intrusion-prevention-variables',
    itemId: 'variables',
    scrollable: true,
    withValidation: false,
    controller: 'unintrusionvariablesgrid',

    name: 'variables',

    region: 'center',

    title: "Variables".t(),
    sortableColumns: true,

    bind: '{variables}',

    tbar: ['@add', '->', '@import', '@export'],
    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyRow: {
        name: '',
        value: '',
        javaClass: 'com.untangle.app.intrusion_prevention.IntrusionPreventionVariable',
    },

    columns: [{
        header: 'Name'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'name'
    },{
        header: 'Value'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'value',
        renderer: Ung.apps.intrusionprevention.MainController.variableValueRenderer,
        editor: {
            xtype:'textfield',
            emptyText: "[enter value]".t(),
            allowOnlyWhitespace: false
        }
    }],

    editorFields:[{
        xtype: 'container',
        layout: 'column',
        margin: '0 0 4 80',
        items: [{
            xtype:'textfield',
            bind: '{record.name}',
            fieldLabel: 'Name'.t(),
            emptyText: '[enter name]'.t(),
            labelAlign: 'right',
            labelWdith: 150,
            allowOnlyWhitespace: false,
            listeners: {
                change: 'editorVariableChange'
            }
        }, {
            xtype: 'label',
            name: 'activeVariable',
            hidden: true,
            margin: '5 0 0 10',
            html: 'Variable is used by one or more signatures.'.t(),
            cls: 'boxlabel'
        }]
    },{
        xtype:'textfield',
        bind: '{record.value}',
        fieldLabel: 'Value'.t(),
        emptyText: '[enter value]'.t(),
        allowOnlyWhitespace: false
    }]
});
