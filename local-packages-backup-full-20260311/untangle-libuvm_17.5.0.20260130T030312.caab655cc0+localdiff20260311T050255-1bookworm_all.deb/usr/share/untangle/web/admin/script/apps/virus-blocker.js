Ext.define('Ung.apps.virusblocker.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-virus-blocker',
    controller: 'app-virus-blocker',

    viewModel: {

        stores: {
            passSites: { data: '{settings.passSites.list}' },
            fileExtensions: { data: '{settings.httpFileExtensions.list}', sorters: 'string' },
            mimeTypes: { data: '{settings.httpMimeTypes.list}', sorters: 'string' }
        },

        formulas: {
            getSignatureTimestamp: {
                get: function(get) {
                    var stamp = Rpc.directData(this.getView().appManager, 'getLastSignatureUpdate');
                    if ((stamp == null) || (stamp === 0)) return('unknown');
                    return(Util.timestampFormat(stamp));
                }
            }
        }

    },

    items: [
        { xtype: 'app-virus-blocker-status' },
        { xtype: 'app-virus-blocker-scanoptions' },
        { xtype: 'app-virus-blocker-passsites' },
        { xtype: 'app-virus-blocker-advanced' }
    ]

});
Ext.define('Ung.apps.virusblocker.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-virus-blocker',

    control: {
        '#': {
            afterrender: 'getSettings',
        },
        '#advanced': {
            activate: Ung.controller.Global.onSubtabActivate,
            beforetabchange: Ung.controller.Global.onBeforeSubtabChange
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        // set the enabled custom block page based on URL existance
        vm.bind('{settings.customBlockPageUrl}', function (url) {
            vm.set('settings.customBlockPageEnabled', url.length > 0);
        });

        var mostRecentTrademarkEndYear = 2021;
        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise(v.appManager, 'isFileScannerAvailable'),
            Rpc.asyncPromise('rpc.systemManager.getMilliseconds')
        ])
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result[0]);
            vm.set('isFileScannerAvailable', result[1]);

            // Get the current year to show as the end year of the BitDefender trademark.
            // This satisfies both our license agreement as well as let customers know
            // that we are "current" regardless of the engine (we always download the most recent signatures) 
            // However, don't show any earlier than our most recently known mark to show something wrong with a bad date
            var currentDate = new Date(result[2]);
            vm.set('trademarkEndYear', (currentDate.getFullYear() > mostRecentTrademarkEndYear) ? currentDate.getFullYear() : mostRecentTrademarkEndYear);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    }

});
Ext.define('Ung.apps.virusblocker.view.Advanced', {
    extend: 'Ext.Panel',
    alias: 'widget.app-virus-blocker-advanced',
    itemId: 'advanced',
    title: 'Advanced'.t(),
    withValidation: true,

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    items: [{
        xtype: 'fieldset',
        title: 'Custom block page'.t(),
        margin: 10,
        padding: 10,
        layout: 'fit',
        items: [{
            xtype: 'textfield',
            emptyText: 'http://example.com',
            fieldLabel: 'URL',
            vtype: 'url',
            bind: '{settings.customBlockPageUrl}',
            listeners: {
                // add 'http://' prefix if missing
                blur: function(el) {
                    var url = el.getValue();
                    if (url.length) {
                        if (!url.startsWith("http://") && !url.startsWith("https://")) {
                            el.setValue("http://" + url);
                        }
                    }
                }
            }
        }]
    }, {
        xtype: 'fieldset',
        title: 'Scan Engines'.t(),
        margin: '10 10 20 10',
        padding: '5 10',
        items: [{
            xtype: 'checkbox',
            boxLabel: 'Enable ScoutIQ&trade; Cloud Scan'.t(),
            bind: '{settings.enableCloudScan}'
        }]
    }, {
        xtype: 'tabpanel',
        flex: 1,
        defaults: {
            xtype: 'ungrid',
            tbar: ['@add', '->', '@import', '@export'],
            recordActions: ['edit', 'copy', 'delete'],
            copyAppendField: 'description',
        },
        items: [{
            title: 'File Extensions'.t(),
            itemId: 'file_extensions',
            emptyText: 'No File Extensions defined'.t(),

            listProperty: 'settings.httpFileExtensions.list',
            emptyRow: {
                string: '',
                enabled: true,
                description: '',
                javaClass: 'com.untangle.uvm.app.GenericRule'
            },

            bind: '{fileExtensions}',

            columns: [{
                header: 'File Type'.t(),
                width: Renderer.idWidth,
                dataIndex: 'string',
                editor: {
                    xtype: 'textfield',
                    emptyText: '[enter file type]'.t(),
                    allowBlank: false
                }
            }, {
                xtype: 'checkcolumn',
                width: Renderer.booleanWidth,
                header: 'Scan'.t(),
                dataIndex: 'enabled',
                resizable: false
            }, {
                header: 'Description'.t(),
                width: Renderer.messageWidth,
                flex: 1,
                dataIndex: 'description',
                editor: {
                    xtype: 'textfield',
                    emptyText: '[no description]'.t()
                }
            }],
            editorFields: [{
                xtype: 'textfield',
                bind: '{record.string}',
                fieldLabel: 'File Type'.t(),
                emptyText: '[enter file type]'.t(),
                allowBlank: false,
                regex: RegExp("^[\\?\\^\\w~!@#$-]+"),
                regexText: 'File type can only start with an alphanumeric character or any one of those special characters ? ^ _ ~ ! @ # $ and -'.t(),
                width: 400
            }, {
                xtype: 'checkbox',
                bind: '{record.enabled}',
                fieldLabel: 'Scan'.t()
            }, {
                xtype: 'textarea',
                bind: '{record.description}',
                fieldLabel: 'Description'.t(),
                emptyText: '[no description]'.t(),
                width: 400,
                height: 60
            }]
        }, {
            title: 'MIME Types'.t(),
            itemId: 'mime_types',
            emptyText: 'No MIME Types defined'.t(),

            listProperty: 'settings.httpMimeTypes.list',
            emptyRow: {
                string: '',
                enabled: true,
                description: '',
                javaClass: 'com.untangle.uvm.app.GenericRule'
            },

            bind: '{mimeTypes}',

            columns: [{
                header: 'MIME Type'.t(),
                width: Renderer.messageWidth,
                flex: 1,
                dataIndex: 'string',
                editor: {
                    xtype: 'textfield',
                    emptyText: '[enter MIME type]'.t(),
                    allowBlank: false
                }
            }, {
                xtype: 'checkcolumn',
                width: Renderer.booleanWidth,
                header: 'Scan'.t(),
                dataIndex: 'enabled',
                resizable: false
            }, {
                header: 'Description'.t(),
                width: Renderer.messageWidth,
                flex: 4,
                dataIndex: 'description',
                editor: {
                    xtype: 'textfield',
                    emptyText: '[no description]'.t()
                }
            }],
            editorFields: [{
                xtype: 'textfield',
                bind: '{record.string}',
                fieldLabel: 'MIME Type'.t(),
                emptyText: '[enter MIME type]'.t(),
                allowBlank: false,
                width: 400
            }, {
                xtype: 'checkbox',
                bind: '{record.enabled}',
                fieldLabel: 'Pass'.t()
            }, {
                xtype: 'textarea',
                bind: '{record.description}',
                fieldLabel: 'Description'.t(),
                emptyText: '[no description]'.t(),
                width: 400,
                height: 60
            }]
        }]
    }]
});
Ext.define('Ung.apps.virusblocker.view.PassSites', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-virus-blocker-passsites',
    itemId: 'pass-sites',
    title: 'Pass Sites'.t(),
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Do not scan traffic to the specified sites.  Use caution!'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',
    emptyText: 'No Pass Sites defined'.t(),
    importValidationJavaClass: true,

    listProperty: 'settings.passSites.list',
    emptyRow: {
        string: '',
        enabled: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{passSites}',

    columns: [{
        header: 'Site'.t(),
        width: Renderer.uriWidth,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter site]'.t(),
            allowOnlyWhitespace: false,
            validator: Util.urlIpValidator
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Pass'.t(),
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'Site'.t(),
        emptyText: '[enter site]'.t(),
        allowOnlyWhitespace: false,
        width: 400,
        validator: Util.urlIpValidator
    }, {
        xtype: 'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Pass'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]

});
Ext.define('Ung.apps.virusblocker.view.ScanOptions', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-virus-blocker-scanoptions',
    itemId: 'scan-options',
    title: 'Scan Options'.t(),
    scrollable: true,
    withValidation: false,
    bodyPadding: 10,
    layout: {
        type: 'vbox',
    },

    items: [{
        xtype: 'checkbox',
        boxLabel: '<strong>' + 'Scan HTTP'.t() + '</strong>',
        bind: '{settings.scanHttp}'
    }, {
        xtype: 'checkbox',
        boxLabel: '<strong>' + 'Scan SMTP'.t() + '</strong>',
        bind: '{settings.scanSmtp}'
    }, {
        xtype: 'combo',
        editable: false,
        fieldLabel: 'Action'.t(),
        labelAlign: 'right',
        queryMode: 'local',
        store: [
            ['pass', 'pass message'.t()],
            ['remove', 'remove infection'.t()],
            ['block', 'block message'.t()]
        ],
        disabled: true,
        bind: {
            value: '{settings.smtpAction}',
            disabled: '{!settings.scanSmtp}'
        }
    }, {
        xtype: 'checkbox',
        boxLabel: '<strong>' + 'Scan FTP'.t() + '</strong>',
        bind: '{settings.scanFtp}'
    }]
});
Ext.define('Ung.apps.virusblocker.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-virus-blocker-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/virus-blocker.svg" width="80" height="80"/>' +
                '<h3>Virus Blocker</h3>' +
                '<p>' + 'Virus Blocker detects and blocks malware before it reaches users\' desktops or mailboxes.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'displayfield',
            fieldLabel: '<STRONG>' + 'Signatures were last updated'.t() + '</STRONG>',
            labelWidth: 250,
            bind: {
                value: '{getSignatureTimestamp}',
                hidden: '{!isFileScannerAvailable}'
            }
        },{
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
