Ext.define('Ung.apps.configurationbackup.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-configuration-backup',
    controller: 'app-configuration-backup',

    viewModel: {
        formulas: {
            driveConfiguredText: function (get) {
                return get('googleDriveIsConfigured') ? 'The Google Connector is configured'.t() : 'The Google Connector is unconfigured.'.t();
            }
        }
    },

    items: [
        { xtype: 'app-configuration-backup-status' },
        { xtype: 'app-configuration-backup-cloud' },
        { xtype: 'app-configuration-backup-googleconnector' }
    ]

});
Ext.define('Ung.apps.configurationbackup.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-configuration-backup',

    requires: [
        'Ung.cmp.GoogleDrive'
    ],

    control: {
        '#': {
            afterrender: 'getSettings',
        }
    },

    backupNow: function (btn) {
        Ext.MessageBox.wait('Backing up... This may take a few minutes.'.t(), 'Please wait'.t());

        Rpc.asyncData(this.getView().appManager, 'sendBackup')
        .then(function(result){
            Ext.MessageBox.hide();
        },function(ext){
            Util.handleException(ex);
            Ext.MessageBox.hide();
        });
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result);
            var googleDrive = new Ung.cmp.GoogleDrive();
            vm.set( 'googleDriveIsConfigured', googleDrive.isConfigured() );
            vm.set( 'googleDriveConfigure', function(){ googleDrive.configure(vm.get('policyId')); });
            vm.set( 'rootDirectory', googleDrive.getRootDirectory() );

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    }

});
Ext.define('Ung.apps.configurationbackup.view.Cloud', {
    extend: 'Ext.form.Panel',
    alias: 'widget.app-configuration-backup-cloud',
    itemId: 'cloud',
    title: 'Cloud'.t(),
    scrollable: true,
    withValidation: true,
    viewModel: true,
    bodyPadding: 10,

    items: [{
        title: 'Cloud'.t(),
        bodyPadding: 10,
        items: [{
            xtype: 'fieldset',
            title: '<i class="fa fa-files-o"></i> ' + 'Daily Backup'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'numberfield',
                allowDecimals: false,
                minValue: 0,
                maxValue: 23,
                fieldLabel: 'Hour'.t(),
                bind: '{settings.hourInDay}',
                allowBlank: false,
            }, {
                xtype: 'numberfield',
                allowDecimals: false,
                minValue: 0,
                maxValue: 59,
                fieldLabel: 'Minute'.t(),
                bind: '{settings.minuteInHour}',
                allowBlank: false,
            }]
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-files-o"></i> ' + 'Backup Now'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'component',
                html: '<strong>' + 'Force an immediate backup now.'.t() + '</strong>',
                margin: '0 0 10 0'
            }, {
                xtype: 'button',
                text: 'Backup now'.t(),
                handler: 'backupNow'
            }]
        }]
    }]
});
Ext.define('Ung.apps.configurationbackup.view.GoogleConnector', {
    extend: 'Ext.form.Panel',
    alias: 'widget.app-configuration-backup-googleconnector',
    itemId: 'google-connector',
    title: 'Google Connector'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,
    bodyPadding: 10,

    items: [{
        title: 'Google Connector'.t(),
        items:[{
            xtype: 'component',
            margin: '10 0 0 10',
            bind: {
                html: '{driveConfiguredText}',
                style: { color: '{googleDriveIsConfigured ? "green" : "red"}'}
            }
        },{
            xtype: "button",
            text: 'Configure Google Drive'.t(),
            iconCls: "fa fa-check-circle",
            margin: '10 0 10 10',
            bind:{
                handler: '{googleDriveConfigure}'
            }
        },{
            xtype: 'fieldset',
            collapsible: false,
            hidden: true,
            disabled: true,
             bind: {
                 hidden: '{googleDriveIsConfigured == false}',
                 disabled: '{googleDriveIsConfigured == false}'
             },
            items: [{
                xtype: "checkbox",
                bind: '{settings.googleDriveEnabled}',
                fieldLabel: 'Enable upload to Google Drive'.t(),
                labelWidth: 200,
                autoEl: {
                    tag: 'div',
                    'data-qtip': "If enabled and configured Configuration Backup will upload backups to google drive.".t()
                },
                listeners: {
                    disable: function (ck) {
                        ck.setValue(false);
                    }
                }
            }, {
                xtype: 'fieldset',
                hidden: true,
                disabled: true,
                bind: {
                    hidden: '{settings.googleDriveEnabled == false}',
                    disabled: '{settings.googleDriveEnabled == false}'
                },
                layout: {
                    type: 'hbox'
                },
                items: [{
                    xtype: 'displayfield',
                    margin: '10 0 10 10',
                    fieldLabel: 'Google Drive Directory',
                    labelWidth: 150,
                    renderer: function() {
                        var rootDirectory = Rpc.directData('rpc.UvmContext.googleManager.getAppSpecificGoogleDrivePath', null);
                        if (!rootDirectory || rootDirectory.trim() === '')
                            return '';
                        return Ext.String.format('<strong><span class="cond-val">{0}</span></strong>', rootDirectory + " /");
                    }
                },{
                    xtype: 'textfield',
                    margin: '10 10 10 0',
                    regex: /^[\w\. \/]+$/,
                    regexText: "The field can have only alphanumerics, spaces, or periods.".t(),
                    bind: '{settings.googleDriveDirectory}',
                    width: 200,
                    emptyText: 'Enter folder name',
                    autoEl: {
                        tag: 'div',
                        'data-qtip': "The destination directory in google drive.".t()
                    }
                }]
            }]
        }]
    }]
});
Ext.define('Ung.apps.configurationbackup.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-configuration-backup-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    items: [{
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/configuration-backup.svg" width="80" height="80"/>' +
                '<h3>Configuration Backup</h3>' +
                '<p>' + 'Configuration Backup automatically creates backups of settings and uploads them to <i>My Account</i> and <i>Google Drive</i>.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate'
        }, {
            xtype: 'appreports'
        }, {
            xtype: 'appremove'
        }]
    }]
});
