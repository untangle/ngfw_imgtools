Ext.define('Ung.apps.applicationcontrol.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-application-control',
    controller: 'app-application-control',

    viewModel: {
        stores: {
            protoRules: { data: '{settings.protoRules.list}' },
            logicRules: { data: '{settings.logicRules.list}' }
        }
    },

    items: [
        { xtype: 'app-application-control-status' },
        { xtype: 'app-application-control-applications' },
        { xtype: 'app-application-control-rules' }
    ]

});
Ext.define('Ung.apps.applicationcontrol.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-application-control',

    control: {
        '#': {
            afterrender: 'onAfterRender'
        }
    },

    onAfterRender: function () {
        var me = this, v = me.getView(), vm = me.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getStatistics')
        .then( function(result){
            if(Util.isDestroyed(v)){
                return;
            }

            vm.set('statistics', result);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v)){
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
        me.getSettings();
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

           vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            var filters = store.getFilters().clone();
            store.clearFilter(true);

            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                }, this, true);
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }

            filters.each( function(filter){
                store.addFilter(filter);
            });
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    statics: {
        actionRenderer: function(action){
            switch(action.actionType) {
                case 'ALLOW': return 'Allow'.t();
                case 'BLOCK': return 'Block'.t();
                case 'TARPIT': return 'Tarpit'.t();
                default: return 'Unknown Action'.t() + ': ' + act;
            }
        }
    }

});
Ext.define('Ung.apps.applicationcontrol.view.Applications', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-application-control-applications',
    itemId: 'applications',
    title: 'Applications'.t(),
    withValidation: false,
    listProperty: 'settings.protoRules.list',
    bind: '{protoRules}',

    extraColumnConfig: {
        flag: { allowBlank: false, xtype: 'checkbox' },
        productivity: { allowBlank: false, xtype: 'numberfield' },
        name: { xtype: 'textfield' },
        tarpit: { xtype: 'checkbox' },
        description: { xtype: 'textfield' },
        block: { allowBlank: false, xtype: 'checkbox' },
        risk: { allowBlank: false, xtype: 'numberfield' },
        id: { allowBlank: false, xtype: 'numberfield' },
        guid: { allowBlank: false,xtype: 'textfield' }
    },

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Application Control Applications allows for simple control over all recognized traffic types.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'ungridfilter'
        },
        '->', '@replace', '@export'
        ]
    }],

    columns: [{
        header: 'Application'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'guid'
    }, {
        xtype: 'checkcolumn',
        header: 'Block'.t(),
        dataIndex: 'block',
        width: Renderer.booleanWidth,
        resizable: false,
        listeners: {
            checkchange: function(col, row, checked, record) {
                if (checked) record.set('tarpit', false);
            }
        }
    }, {
        xtype: 'checkcolumn',
        header: 'Tarpit'.t(),
        dataIndex: 'tarpit',
        width: Renderer.booleanWidth,
        resizable: false,
        listeners: {
            checkchange: function(col, row, checked, record) {
                if (checked) record.set('block', false);
            }
        }
    }, {
        xtype: 'checkcolumn',
        header: 'Flag'.t(),
        dataIndex: 'flag',
        width: Renderer.booleanWidth,
        resizable: false
    }, {
        header: 'Name'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'name'
    }, {
        header: 'Category'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'category'
    }, {
        header: 'Productivity'.t(),
        width: Renderer.idWidth,
        dataIndex: 'productivity'
    }, {
        header: 'Risk',
        width: Renderer.idWidth,
        dataIndex: 'risk'
    }, {
        header: 'Description (click for full text)'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'description',
        flex: 1
    }]
});
Ext.define('Ung.apps.applicationcontrol.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-application-control-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Application Control rules are used to control traffic post-classification.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'id',  
    copyAppendField: 'description',

    listProperty: 'settings.logicRules.list',

    emptyText: 'No Rules defined'.t(),

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    nestedFieldsArr: {
        fields: ['action'],
        extraConfig: { flag: { xtype: 'checkbox' } }
    },

    extraColumnConfig: {
        id: { allowBlank: false, xtype: 'numberfield' },
    },

    emptyRow: {
        enabled: true,
        description: '',
        action: {
            actionType: 'BLOCK',
            javaClass: 'com.untangle.app.application_control.ApplicationControlLogicRuleAction',
            flag: true
        },
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.application_control.ApplicationControlLogicRule'
    },

    bind: '{logicRules}',

    columns: [{
        header: 'Rule Id'.t(),
        width: Renderer.idWidth,
        align: 'right',
        resizable: false,
        dataIndex: 'id',
        renderer: Renderer.id
    },
    Column.enabled,
    Column.description,
    Column.conditions,
    {
        header: 'Action'.t(),
        dataIndex: 'action',
        width: Renderer.actionWidth,
        renderer: Ung.apps.applicationcontrol.MainController.actionRenderer
    }],

    // todo: continue this stuff
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.application_control.ApplicationControlLogicRuleCondition',[
            'DST_ADDR',
            'DST_PORT',
            'DST_INTF',
            'SRC_ADDR',
            'SRC_PORT',
            'SRC_INTF',
            'PROTOCOL',
            'TAGGED',
            'USERNAME',
            'HOST_HOSTNAME',
            'CLIENT_HOSTNAME',
            'SERVER_HOSTNAME',
            'SRC_MAC',
            'DST_MAC',
            'CLIENT_MAC_VENDOR',
            'SERVER_MAC_VENDOR',
            'CLIENT_IN_PENALTY_BOX',
            'SERVER_IN_PENALTY_BOX',
            'HOST_HAS_NO_QUOTA',
            'USER_HAS_NO_QUOTA',
            'CLIENT_HAS_NO_QUOTA',
            'SERVER_HAS_NO_QUOTA',
            'HOST_QUOTA_EXCEEDED',
            'USER_QUOTA_EXCEEDED',
            'CLIENT_QUOTA_EXCEEDED',
            'SERVER_QUOTA_EXCEEDED',
            'HOST_QUOTA_ATTAINMENT',
            'USER_QUOTA_ATTAINMENT',
            'CLIENT_QUOTA_ATTAINMENT',
            'SERVER_QUOTA_ATTAINMENT',
            'HOST_ENTITLED',
            'HTTP_HOST',
            'HTTP_REFERER',
            'HTTP_URI',
            'HTTP_URL',
            'HTTP_CONTENT_TYPE',
            'HTTP_CONTENT_LENGTH',
            'HTTP_REQUEST_METHOD',
            'HTTP_REQUEST_FILE_PATH',
            'HTTP_REQUEST_FILE_NAME',
            'HTTP_REQUEST_FILE_EXTENSION',
            'HTTP_RESPONSE_FILE_NAME',
            'HTTP_RESPONSE_FILE_EXTENSION',
            'HTTP_USER_AGENT',
            'HTTP_USER_AGENT_OS',
            'APPLICATION_CONTROL_APPLICATION',
            'APPLICATION_CONTROL_CATEGORY',
            'APPLICATION_CONTROL_PROTOCHAIN',
            'APPLICATION_CONTROL_DETAIL',
            'APPLICATION_CONTROL_CONFIDENCE',
            'APPLICATION_CONTROL_PRODUCTIVITY',
            'APPLICATION_CONTROL_RISK', 
            'PROTOCOL_CONTROL_SIGNATURE',
            'PROTOCOL_CONTROL_CATEGORY',
            'PROTOCOL_CONTROL_DESCRIPTION',
            'WEB_FILTER_CATEGORY',
            'WEB_FILTER_CATEGORY_DESCRIPTION',
            'WEB_FILTER_FLAGGED',
            'DIRECTORY_CONNECTOR_GROUP',
            'DIRECTORY_CONNECTOR_DOMAIN',
            'CLIENT_COUNTRY',
            'SERVER_COUNTRY',
            'THREAT_PREVENTION_SRC_REPUTATION',
            'THREAT_PREVENTION_DST_REPUTATION',
            'THREAT_PREVENTION_SRC_CATEGORIES',
            'THREAT_PREVENTION_DST_CATEGORIES',
        ]), {
            xtype: 'combo',
            fieldLabel: 'Action Type'.t(),
            bind: '{_action.actionType}',
            allowBlank: false,
            editable: false,
            store: [
                ['ALLOW', 'Allow'.t()],
                ['BLOCK', 'Block'.t()],
                ['TARPIT', 'Tarpit'.t()]
            ],
            queryMode: 'local',
        }
    ]
});
Ext.define('Ung.apps.applicationcontrol.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-application-control-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: {
        formulas: {
            trafficStats: function (get) {
                return [
                    { name: 'Sessions Scanned'.t(), value: get('statistics.sessionCount') },
                    { name: 'Sessions Allowed'.t(), value: get('statistics.allowedCount') },
                    { name: 'Sessions Flagged'.t(), value: get('statistics.flaggedCount') },
                    { name: 'Sessions Blocked'.t(), value: get('statistics.blockedCount') }
                ];
            },
            applicationStats: function (get) {
                return [
                    { name: 'Known Applications'.t(), value: get('statistics.protoTotalCount') },
                    { name: 'Flagged Applications'.t(), value: get('statistics.protoFlagCount') },
                    { name: 'Blocked Applications'.t(), value: get('statistics.protoBlockCount') },
                    { name: 'Tarpitted Applications'.t(), value: get('statistics.protoTarpitCount') }
                ];
            },
            ruleStats: function (get) {
                return [
                    { name: 'Total Rules'.t(), value: get('statistics.logicTotalCount') },
                    { name: 'Active Rules'.t(), value: get('statistics.logicLiveCount') }
                ];
            }
        }
    },

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/application-control.svg" width="80" height="80"/>' +
                '<h3>Application Control</h3>' +
                '<p>' + 'Application Control scans sessions and identifies the associated applications allowing each to be flagged and/or blocked.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            region: 'center',
            title: 'Statistics'.t(),
            xtype: 'tabpanel',
            disabled: true,
            bind: {
                disabled: '{!state.on}'
            },
            defaults: {
                xtype: 'propertygrid',
                border: false,
                nameColumnWidth: 250,
                sortableColumns: false,
                hideHeaders: true,
                listeners: {
                    beforeedit: function () {
                        return false;
                    }
                }
            },
            items: [{
                title: 'Traffic'.t(),
                bind: { store: { data: '{trafficStats}' } }
            }, {
                title: 'Application'.t(),
                bind: { store: { data: '{applicationStats}' } }
            }, {
                title: 'Rule'.t(),
                bind: { store: { data: '{ruleStats}' } }
            }]
        }, {
            xtype: 'appmetrics',
            region: 'south',
            split: true,
            height: '40%'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]

});
