Ext.define('Ung.apps.openvpn.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-openvpn',
    controller: 'app-openvpn',

    viewModel: {
        stores: {
            remoteClients: {
                data: '{settings.remoteClients.list}'
            },
            remoteServers: {
                data: '{settings.remoteServers.list}'
            },
            groups: {
                data:'{settings.groups.list}'
            },
            exportedNetworks: {
                data:'{settings.exports.list}'
            },
            serverConfiguration: {
                data: '{settings.serverConfiguration.list}'
            },
            clientConfiguration: {
                data: '{settings.clientConfiguration.list}'
            },
            clientStatusList: {
                data: '{clientStatusData}',
                fields: [{
                    name: 'address',
                    type: 'string',
                    sortType: 'asIp'
                },{
                    name: 'clientName',
                    type: 'string',
                    sortType: 'asUnString'
                },{
                    name: 'start',
                    sortType: 'asTimestamp',
                    convert:  Converter.convertDate,
                },{
                    name: 'poolAddress',
                    type: 'string',
                    sortType: 'asIp'
                }]
            },
            serverStatusList: {
                data: '{serverStatusData}',
                filters: [{
                    property: 'enabled',
                    value: true
                }]
            }

        },

        data: {
            clientStatusData: [],
            serverStatusData: [],
        },

        formulas: {
            getSiteUrl: {
                get: function(get) {
                    var publicUrl = Rpc.directData('rpc.networkManager.getPublicUrl');
                    return(publicUrl.split(":")[0] + ":" + get('settings.port'));
                }
            }
        }
    },

    items: [
        { xtype: 'app-openvpn-status' },
        { xtype: 'app-openvpn-server' },
        { xtype: 'app-openvpn-client' },
        { xtype: 'app-openvpn-advanced' }
    ]

});
Ext.define('Ung.apps.openvpn.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-openvpn',

    control: {
        '#': {
            afterrender: 'getSettings'
        },
        '#server': {
            activate: Ung.controller.Global.onSubtabActivate,
        },
        '#server #server': {
            beforetabchange: Ung.controller.Global.onBeforeSubtabChange
        }
    },

    getActiveClients: function () {
        var grid = this.getView().down('#activeClients'),
            vm = this.getViewModel();

        grid.setLoading(true);
        Rpc.asyncData(this.getView().appManager, 'getActiveClients')
        .then( function(result){
            if(Util.isDestroyed(grid, vm)){
                return;
            }
            vm.set('clientStatusData', result.list);

            grid.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getRemoteServers: function () {
        var grid = this.getView().down('#remoteServers'),
            vm = this.getViewModel();

        grid.setLoading(true);
        Rpc.asyncData(this.getView().appManager, 'getRemoteServersStatus')
        .then( function(result){
            if(Util.isDestroyed(grid, vm)){
                return;
            }

            vm.set('serverStatusData', result.list);

            grid.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            // set a flag on existing users to prevent changing the name
            for(var i = 0 ; i < result.remoteClients.list.length ; i++) {
                result.remoteClients.list[i].existing = true;
            }

            vm.set('settings', result);
            me.getOrignalPasswd();

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

        // trigger active clients/servers fetching when instance run state changes
        vm.bind('{state.on}', function (stateon) {
            if (stateon) {
                me.getActiveClients();
                me.getRemoteServers();
            } else {
                vm.set({
                    clientStatusData: [],
                    serverStatusData: []
                });
            }
        });
    },

    getOrignalPasswd: function() {
        var vm = this.getViewModel();
        servers = vm.get('settings.remoteServers.list');
        if(servers){
            servers.forEach(function(server){
                encryptedPassword = server.remoteServerEncryptedPassword;
                if(encryptedPassword != null && encryptedPassword != ""){
                    server.authPassword = Util.getDecryptedPassword(server.remoteServerEncryptedPassword);
                }
            });
        }
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        if (me.validateSettings() != true) return;

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    validateSettings: function() {
        var v = this.getView();

        var clientStore = v.query('app-openvpn-remote-clients-grid')[0].getStore();
        var groupStore = v.query('app-openvpn-groups-grid')[0].getStore();
        var message = "";
        var problem = 0;
        var counter = 0;
        var clientNames = {};
        var groupNames = {};

        // make sure they don't try to delete all groups
        counter = 0;
        groupStore.each(function(record) {
            if (!record.get('markedForDelete')) counter++;
        });

        if ((counter == 0) && (groupStore.data.length > 0)) {
            groupStore.each(function(record) {
                record.set('markedForDelete', false);
            });
            problem++;
            Ext.MessageBox.alert("Delete Group Failed".t(), "There must be at least one group.".t());
        }
        if (problem != 0) return(false);

        // make sure they don't try to delete a group with active remote clients
        groupStore.each(function(record) {
            if (record.get('markedForDelete')) {
                var finder = clientStore.findRecord('groupId' , record.get('groupId'));
                if ((finder != null) && (!finder.get('markedForDelete'))) {
                    message = Ext.String.format("The group: {0} cannot be deleted because it is being used by the client: {1} in the Remote Clients list.".t(), record.get('name'), finder.get('name'));
                    record.set('markedForDelete', false);
                    problem++;
                    Ext.MessageBox.alert("Delete Group Failed".t(), message);
                }
            }
        });
        if (problem != 0) return(false);

        // we must not allow port 443 or Apache will get very upset
        var pfield = Ext.ComponentQuery.query('textfield[fieldIndex=listenPort]')[0];
        var pvalue = pfield.getValue();
        if (pvalue === '443') {
            Ext.MessageBox.alert("Invalid Port".t(), "The configured port value is reserved. Please enter a different value.".t());
            return(false);
        }

        return(true);
    },

    uploadFile: function(cmp) {
        var me = this;
        var form = Ext.ComponentQuery.query('form[name=upload_form]')[0];
        var file = Ext.ComponentQuery.query('textfield[name=uploadConfigFileName]')[0].value;
        if ( file == null || file.length === 0 ) {
            Ext.MessageBox.alert('Select File'.t(), 'Please choose a file to upload.'.t());
            return;
        }
        Ext.MessageBox.wait("Uploading File...".t(), "Please Wait".t());
        form.submit({
            url: "/openvpn/uploadConfig",
            success: Ext.bind(function( form, action ) {
                if(Util.isDestroyed(me)){
                    return;
                }
                Ext.MessageBox.hide();
                Ext.MessageBox.alert('Success'.t(), 'The configuration has been imported.'.t());
                me.getSettings();
            }, this),
            failure: Ext.bind(function( form, action ) {
                Ext.MessageBox.hide();
                Ext.MessageBox.alert('Failure'.t(), 'Import failure'.t() + ": " + action.result.code);
            }, this)
        });
    },

    configureAuthenticationMethod: function (btn) {
        var me = this, vm = this.getViewModel();
        var policyId = vm.get('policyId');
        var authType = this.getViewModel().get('settings.authenticationType');

        Rpc.asyncData('rpc.appManager.app', 'directory-connector')
        .then( function(directoryConnectorApp){
            if(Util.isDestroyed(me, policyId, authType)){
                return;
            }

            // Default to local directory
            var checkDirectoryConnector = false;
            var url = '#config/local-directory';
            switch (authType) {
                case 'RADIUS':
                    checkDirectoryConnector = true;
                    url = '#apps/' + policyId + '/directory-connector/radius';
                    break;
                case 'ACTIVE_DIRECTORY':
                    checkDirectoryConnector = true;
                    url = '#apps/' + policyId + '/directory-connector/active-directory';
                    break;
                case 'ANY_DIRCON':
                    checkDirectoryConnector = true;
                    url = '#apps/' + policyId + '/directory-connector';
                    break;
            }
            if( checkDirectoryConnector && directoryConnectorApp == null){
                me.showMissingServiceWarning();
            }else{
                Ung.app.redirectTo(url);
            }

        },function(ex){
            Util.handleException(ex);
        });
    },

    showMissingServiceWarning: function() {
        Ext.MessageBox.alert('Service Not Installed'.t(), 'The Directory Connector application must be installed to use this feature.'.t());
    }
});



Ext.define('Ung.apps.openvpn.SpecialGridController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.app-openvpn-special',

    getClientConfig: function(view, row, colIndex, item, e, record) {
        if( record.dirty ){
            Ext.MessageBox.alert(
                "Cannot download".t(),
                "Remote Client information has been modified.  You must Save before downloading the client.".t()
            );
            return;
        }
        this.getDistributeWindow().populate(record);
    },

    getDistributeWindow: function() {
        this.distributeWindow = Ext.create('Ext.window.Window', {
            title: 'Download Client Configuration'.t(),
            items: [{
                xtype: 'panel',
                items: [{
                    xtype: 'fieldset',
                    title: 'Download'.t(),
                    margin: 10,
                    defaults: { margin: 10 },
                    items: [{
                        xtype: 'component',
                        html: 'These files can be used to configure your Remote Clients.'.t(),
                    }, {
                        xtype: 'component',
                        name: 'downloadGenericConfigurationFile',
                        html: " "
                    }, {
                        xtype: 'component',
                        name: 'downloadUntangleConfigurationFile',
                        html: " "
                    }, {
                        xtype: 'component',
                        html: '<BR>'
                    }, {
                        xtype: 'component',
                        html: 'This file can be used to configure Chromebook clients.  On the target device, browse to <b>chrome://net-internals#chromeos</b> and use Import ONC file.'.t(),
                    }, {
                        xtype: 'component',
                        name: 'downloadChromebookConfigurationFile',
                        html: " "
                    }, {
                        xtype: 'component',
                        html: '<BR>'
                    }, {
                        xtype: 'component',
                        autoEl: {
                            tag: 'div',
                            children: [{
                                tag: 'a',
                                href: 'https://wiki.edge.arista.com/index.php/OpenVPN',
                                html: 'See our OpenVPN documentation for information and download links for common VPN clients'
                            }]
                        }
                    }]
                }]
            }],
            bbar: ['->', {
                name: 'close',
                iconCls: 'fa fa-window-close',
                text: 'Close'.t(),
                handler: function() {
                    this.distributeWindow.close();
                },
                scope: this
            }],
            closeWindow: function() {
                this.destroy();
            },
            populate: function( record ) {
                var me = this;
                this.record = record;
                this.setTitle('Download Client Configuration'.t() + ' | ' + record.data.name);

                var clients = [{
                  name: 'downloadUntangleConfigurationFile',
                  type: 'zip',
                  message: 'Download client configuration zip file for remote NGFW OpenVPN site to site connections.'.t()
                },{
                  name: 'downloadGenericConfigurationFile',
                  type: 'ovpn',
                  message: 'Download client configuration as a single ovpn file with all certificates included inline (For use with OpenVPN Community Edition).'.t()
                },{
                  name: 'downloadChromebookConfigurationFile',
                  type: 'onc',
                  message: 'Download client configuration ONC file for Chromebook.'.t()
                }];

                Ext.MessageBox.wait("Building OpenVPN Clients...".t(), "Please Wait".t());
                var builders = [];
                clients.forEach( function(client){
                    client["link"] = me.down('[name="' + client.name + '"]');
                    client["link"].update('Loading...'.t());
                    builders.push( Rpc.asyncPromise( 'rpc.appManager.app(openvpn).getClientDistributionDownloadLink', me.record.data.name, client.type ) );
                });

                Ext.Deferred.sequence(builders)
                .then(function(result){
                    if(Util.isDestroyed(clients)){
                        return;
                    }
                    result.forEach( function(client, index){
                        clients[index].link.update('&bull;&nbsp;<a href="'+client+'" target="_blank">'+clients[index].message + '</a>');
                    });
                },function(ex){
                    Util.handleException(ex);
                });
                Ext.MessageBox.hide();
            }
        });

        this.distributeWindow.show();
        return this.distributeWindow;
    },

    statics:{
        groupRenderer: function(value, meta, record, row, col, store, grid){
            var groupList = this.getViewModel().get('groups');
            var grpname = 'Unknown'.t();
            groupList.each(function(record) { if (record.get('groupId') == value) grpname = record.get('name'); });
            return(grpname);
        },
        typeRenderer: function(value){
            return value ? 'Network'.t() : 'Individual Client'.t();
        }
    }

});
Ext.define('Ung.apps.openvpn.view.Advanced', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-openvpn-advanced',
    itemId: 'advanced',
    title: 'Advanced'.t(),
    viewModel: true,
    withValidation: true,
    bodyPadding: 10,
    scrollable: true,

    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: '<i class="fa fa-exclamation-triangle" style="color: red;"></i> ' +
              'Advanced settings require careful configuration.<br>' +
              '<i class="fa fa-exclamation-triangle" style="color: red;"></i> ' +
              'Misconfiguration can compromise the proper operation and security of your server.<br>' +
              '<i class="fa fa-exclamation-triangle" style="color: red;"></i> ' +
              'Changes made on this tab are not officially supported.<br>'.t()
    }],

    items: [{
        xtype: 'container',
        layout: 'column',
        items: [{
            xtype: 'combo',
            fieldLabel: 'Protocol'.t(),
            labelWidth: 180,
            bind: '{settings.protocol}',
            store: [['udp','UDP'],['tcp','TCP']],
            editable: false,
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: '(default = UDP)'.t()
        }]
    },{
        xtype: 'container',
        layout: 'column',
        items: [{
            xtype: 'textfield',
            fieldLabel: 'Port'.t(),
            fieldIndex: 'listenPort',
            labelWidth: 180,
            bind: '{settings.port}'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: '(default = 1194)'.t()
        }]
    },{
        xtype: 'container',
        layout: 'column',
        items: [{
            xtype: 'textfield',
            fieldLabel: 'Cipher'.t(),
            labelWidth: 180,
            bind: '{settings.cipher}',
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: '(default = AES-128-CBC)'.t()
        }]
    },{
        xtype: 'container',
        layout: 'column',
        items: [{
            xtype: 'checkbox',
            fieldLabel: 'Client To Client Allowed'.t(),
            labelWidth: 180,
            bind: '{settings.clientToClient}'
        }, {
            xtype: 'displayfield',
            margin: '0 0 0 10',
            value: '(default = checked)'.t()
        }]
    },{
        xtype: 'fieldset',
        title: 'Server Configuration'.t(),

        layout: {
            type: 'vbox',
            align: 'stretch'
        },

        items: [{
            xtype: 'app-openvpn-config-editor-grid',
            listProperty: 'settings.serverConfiguration.list',
            itemId: 'server-config-editor-grid',
            bind: '{serverConfiguration}'
        }]
    },{
        xtype: 'fieldset',
        title: 'Client Configuration'.t(),

        layout: {
            type: 'vbox',
            align: 'stretch'
        },

        items: [{
            xtype: 'app-openvpn-config-editor-grid',
            listProperty: 'settings.clientConfiguration.list',
            itemId: 'client-config-editor-grid',
            bind: '{clientConfiguration}'
        }]
    }]
});

Ext.define('Ung.apps.openvpn.view.ConfigEditorGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-openvpn-config-editor-grid',

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@addInline', '->', '@import', '@export']
    }],

    recordActions: ['delete'],
    topInsert: true,

    emptyRow: {
        javaClass: 'com.untangle.app.openvpn.OpenVpnConfigItem',
        'optionName': null,
        'optionValue': null,
        'excludeFlag': false,
        'readOnly': false,
    },

    importValidationJavaClass: true,

    listeners: {
        cellclick: function(grid,td,cellIndex,record,tr,rowIndex,e,eOpts)  {
            // not allowed to edit default options
            if (record.data.readOnly) { return(false); }
        }
    },

    columns: [{
        header: 'Option Name'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'optionName',
        editable: false,
        editor: {
            xtype: 'textfield',
            bind: '{record.optionName}',
        },
    }, {
        header: 'Option Value'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'optionValue',
        editor: {
            xtype: 'textfield',
            bind: '{record.optionValue}'
        }
    }, {
        header: 'Option Type'.t(),
        width: Renderer.actionWidth + 20,
        dataIndex: 'readOnly',
        resizable: false,
        renderer: function(val) {
            return(val ? 'default' : 'custom');
        }
    }, {
        xtype: 'checkcolumn',
        header: 'Exclude'.t(),
        width: Renderer.booleanWidth + 10,
        dataIndex: 'excludeFlag',
        resizable: false,
    }]

});
Ext.define('Ung.apps.openvpn.view.Client', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-openvpn-client',
    itemId: 'client',
    title: 'Client'.t(),
    viewModel: true,
    autoScroll: true,
    withValidation: true,

    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'The Client tab is used to configure the servers that OpenVPN will connect as a client.'.t()
    }],

    defaults: {
        padding: '0 0 0 10'
    },

    items: [{
        xtype: 'app-openvpn-client-tab-panel',
        padding: '20 20 0 20',
    },{
        xtype: 'form',
        name: 'upload_form',
        border: false,
        margin: '10 10 10 10',
        items: [{
            xtype: 'fileuploadfield',
            name: 'uploadConfigFileName',
            anchor: '100%',
            buttonOnly: true,
            buttonConfig: {
                iconCls: 'fa fa-upload',
                width: 300,
                height: 40,
                text: 'Upload Remote Server Configuration File'.t(),
            },
            listeners: { 'change': 'uploadFile' }
        }]
    }]
});

Ext.define('Ung.apps.openvpn.view.ClientTabs', {
    extend: 'Ext.tab.Panel',
    alias: 'widget.app-openvpn-client-tab-panel',
    itemId: 'openvpn-client-tab-panel',
    viewModel: true,
    layout: 'fit',

    items: [{
        title: 'Remote Servers'.t(),
        items: [
            { xtype: 'app-openvpn-remote-servers-grid' }
            ]
    }]

});

Ext.define('Ung.apps.openvpn.view.RemoteServersGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-openvpn-remote-servers-grid',
    itemId: 'openvpn-remote-servers-grid',

    emptyText: 'No Remote Servers defined'.t(),

    recordActions: ['edit','delete'],
    listProperty: 'settings.remoteServers.list',
    emptyRow: {
        javaClass: 'com.untangle.app.openvpn.OpenVpnRemoteServer',
        'enabled': true,
        'name': '',
        },

    bind: '{remoteServers}',

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Server Name'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'name',
        editor: {
            xtype: 'textfield',
            vtype: 'openvpnName',
            bind: '{record.name}'
        }
    }, {
        header: 'Username',
        width: 200,
        dataIndex: 'authUsername',
        renderer: function(value, meta, record) {
            if (record.data.authUserPass) return(value);
            return('[User/Pass Auth Disabled]'.t());
        }
    }],

    editorFields: [
        Field.enableRule(),
    {
        xtype: 'textfield',
        fieldLabel: 'Server Name'.t(),
        readOnly: true,
        name: 'serverName',
        bind: '{record.name}'
    }, {
        xtype: 'checkbox',
        fieldLabel: 'Username/Password Authentication',
        name: 'authUserPass',
        bind: '{record.authUserPass}'
    }, {
        xtype: 'textfield',
        fieldLabel: 'Username'.t(),
        allowBlank: false,
        bind: {
            value: '{record.authUsername}',
            disabled: '{record.authUserPass == false}',
            hidden: '{record.authUserPass == false}'
        },
    }, {
        xtype: 'textfield',
        fieldLabel: 'Password'.t(),
        allowBlank: false,
        inputType: 'password',
        bind: {
            value: '{record.authPassword}',
            disabled: '{record.authUserPass == false}',
            hidden: '{record.authUserPass == false}'
        },
    }]
});
Ext.define('Ung.apps.openvpn.view.Server', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-openvpn-server',
    itemId: 'server',
    title: 'Server'.t(),
    scrollable: true,

    withValidation: true,

    viewModel: {
        formulas: {
            _btnConfigureDirectory: function (get) {
                switch (get('settings.authenticationType')) {
                case 'LOCAL_DIRECTORY': return 'Configure Local Directory'.t();
                case 'RADIUS': return 'Configure RADIUS'.t();
                case 'ACTIVE_DIRECTORY': return 'Configure Active Directory'.t();
                case 'ANY_DIRCON': return 'Configure Directory Connector'.t();
                default: return '';
                }
            }
        }
    },

    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'The Server tab is used to configure OpenVPN to operate as a server for remote clients'.t()
    }],

    layout: 'border',

    items: [{
        xtype: 'panel',
        region: 'west',
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        scrollable: true,
        layout: {
            type: 'anchor'
        },
        bodyPadding: 10,
        defaults: {
            anchor: '100%',
            labelAlign: 'top'
        },
        items: [{
            xtype: 'checkbox',
            boxLabel: 'Server Enabled'.t(),
            bind: '{settings.serverEnabled}'
        },{
            fieldLabel: 'Site Name'.t(),
            xtype: 'textfield',
            vtype: 'openvpnName',
            disabled: true,
            bind: {
                value: '{settings.siteName}',
                disabled: '{settings.serverEnabled == false}'
            },
            allowBlank: false
        },{
            fieldLabel: 'Address Space'.t(),
            xtype: 'textfield',
            vtype: 'cidrBlockOnlyRanges',
            disabled: true,
            bind: {
                value: '{settings.addressSpace}',
                disabled: '{settings.serverEnabled == false}'
            },
        },{
            xtype: 'checkbox',
            boxLabel: 'NAT OpenVPN Traffic'.t(),
            disabled: true,
            bind: {
                value: '{settings.natOpenVpnTraffic}',
                disabled: '{settings.serverEnabled == false}'
            },
        },{
            fieldLabel: 'Site URL'.t(),
            xtype: 'displayfield',
            disabled: true,
            bind: {
                value: '{getSiteUrl}',
                disabled: '{settings.serverEnabled == false}'
            },
        },{
            xtype: 'checkbox',
            boxLabel: 'Username/Password Authentication',
            disabled: true,
            bind: {
                value: '{settings.authUserPass}',
                disabled: '{settings.serverEnabled == false}'
            },
        },{
            xtype: 'checkbox',
            boxLabel: 'Add MFA client configuration'.t(),
            disabled: true,
            autoEl: {
                tag: 'div',
                'data-qtip': 'If enabled, the keyword <I>static-challenge</I> will<BR>' +
                'be added to the client configuration. <BR>This requests the OpenVPN client<BR>' +
                'to ask for a TOTP code.'
            },
            bind: {
                value: '{settings.totpClientPrompt}',
                disabled: '{settings.authUserPass == false || settings.authenticationType !== "LOCAL_DIRECTORY"}',
                hidden: '{settings.authUserPass == false}'
            },
        },
        {
            xtype: 'container',
            items: [{
                xtype: 'displayfield',
                value: 'MFA Client Timeout (hours):'.t()
            }, {
                xtype: 'textfield',
                hideLabel: true,
                bind: {
                    value: '{settings.mfaClientTimeout}'
                }
            }, {
                xtype: 'displayfield',
                value: '(0 = no timeout)'.t(),
            }],
            bind: {
                hidden: '{settings.totpClientPrompt == false}',
                disabled: '{settings.authUserPass == false || settings.authenticationType !== "LOCAL_DIRECTORY"}',
            }
        },{
            xtype: 'container',
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            hidden: true,
            disabled: true,
            bind: {
                disabled: '{settings.serverEnabled == false}',
                hidden: '{!settings.authUserPass}'
            },
            items: [{
                xtype: 'displayfield',
                margin: '10 0 10 0',
                value: '<B>NOTE:</B> Enabling or disabling Username/Password Authentication will require existing remote client configuration files to be downloaded again.'
            }, {
                xtype: 'radiogroup',
                fieldLabel: 'Authentication Method'.t(),
                labelAlign: 'top',
                bind: '{settings.authenticationType}',
                simpleValue: 'true',
                columns: 1,
                vertical: true,
                items: [
                    { boxLabel: '<strong>' + 'Local Directory'.t() + '</strong>', inputValue: 'LOCAL_DIRECTORY' },
                    { boxLabel: '<strong>' + 'RADIUS'.t() + '</strong> (' + 'requires'.t() + ' Directory Connector)', inputValue: 'RADIUS' },
                    { boxLabel: '<strong>' + 'Active Directory'.t() + '</strong> (' + 'requires'.t() + ' Directory Connector)', inputValue: 'ACTIVE_DIRECTORY' },
                    { boxLabel: '<strong>' + 'Any Directory Connector'.t() + '</strong> (' + 'requires'.t() + ' Directory Connector)', inputValue: 'ANY_DIRCON' }
                ]
            }, {
                // todo: update this button later
                xtype: 'button',
                iconCls: 'fa fa-cog',
                margin: '5 0',
                scale: 'medium',
                bind: {
                    text: '{_btnConfigureDirectory}'
                },
                handler: 'configureAuthenticationMethod'
            }]
        }]
    }, {
        xtype: 'tabpanel',
        itemId: 'server',
        region: 'center',

        defaults: {
            border: false
        },
        disabled: true,
        bind: {
            disabled: '{settings.serverEnabled == false}',
        },
        items: [{
            title: 'Remote Clients'.t(),
            itemId: 'remote_clients',
            xtype: 'app-openvpn-remote-clients-grid'
        },{
            title: 'Groups'.t(),
            itemId: 'groups',
            xtype: 'app-openvpn-groups-grid'
        },{
            title: 'Exported Networks'.t(),
            itemId: 'exported_networks',
            xtype: 'app-openvpn-exported-networks-grid'
        }]
    }]
});

Ext.define('Ung.apps.openvpn.cmp.RemoteClientsGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-openvpn-remote-clients-grid',
    itemId: 'remote-clients-grid',
    viewModel: true,
    controller: 'app-openvpn-special',

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'delete'],
    listProperty: 'settings.remoteClients.list',
    emptyRow: {
        javaClass: 'com.untangle.app.openvpn.OpenVpnRemoteClient',
        'enabled': true,
        'name': '',
        'groupId': 1,
        'export': false,
        'existing': false
    },

    importValidationJavaClass: true,

    importValidationForComboBox: true,

    bind: '{remoteClients}',

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Client Name'.t(),
        width: Renderer.usernameWidth,
        flex: 1,
        dataIndex: 'name',
    }, {
        header: 'Group'.t(),
        width: Renderer.usernameWidth,
        flex: 1,
        dataIndex: 'groupId',
        renderer: Ung.apps.openvpn.SpecialGridController.groupRenderer
    },{
        header: 'Type'.t(),
        width: Renderer.usernameWidth,
        flex: 1,
        dataIndex: 'export',
        renderer: Ung.apps.openvpn.SpecialGridController.typeRenderer,
    },
    {
        xtype: 'actioncolumn',
        header: 'Get Client Configuration'.t(),
        width: Renderer.emailWidth,
        iconCls: 'fa fa-download',
        align: 'center',
        handler: 'getClientConfig',
    }],

    editorFields: [{
        xtype: 'checkbox',
        fieldLabel: 'Enabled'.t(),
        bind: '{record.enabled}'
    }, {
        xtype: 'textfield',
        vtype: 'openvpnName',
        fieldLabel: 'Client Name'.t(),
        allowBlank: false,
        bind: {
            value: '{record.name}',
            readOnly: '{record.existing}'
        },
        validator: function(value, component) {
            if(component === undefined)
                    component = this;
            return Util.isUnique(value, 'remote client', 'name', component," app-openvpn-remote-clients-grid");
        }    
    }, {
        xtype: 'combobox',
        fieldLabel: 'Group'.t(),
        bind: {
            value: '{record.groupId}',
            store: '{groups}'
        },
        allowBlank: false,
        editable: false,
        queryMode: 'local',
        displayField: 'name',
        valueField: 'groupId'
    }, {
        xtype: 'combo',
        fieldLabel: 'Type'.t(),
        editable: false,
        bind: '{record.export}',
        store: [[false,'Individual Client'.t()],[true,'Network'.t()]]
    }, {
        xtype: 'textfield',
        fieldLabel: 'Remote Networks'.t(),
        emptyText: '[Enter comma separated list of networks in CIDR format]'.t(),
        bind: {
            value: '{record.exportNetwork}',
            disabled: '{!record.export}',
            hidden: '{!record.export}'
        },
        allowBlank: false,
        vtype: 'cidrBlockList',
        validator: function(value, component) {
            if(component === undefined)
                    component = this;
            return Util.isIpIntersects(value, 'remote client', 'exportNetwork', component," app-openvpn-remote-clients-grid");
        }
    }]

});

Ext.define('Ung.apps.openvpn.cmp.GroupsGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-openvpn-groups-grid',
    itemId: 'groups-grid',
    viewModel: true,

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'name',
    listProperty: 'settings.groups.list',
    emptyRow: {
        javaClass: 'com.untangle.app.openvpn.OpenVpnGroup',
        'enabled': true,
        'name': '',
        'groupId': -1,
        'export': false
    },

    importValidationJavaClass: true,

    importValidationForComboBox: true,

    bind: '{groups}',

    columns: [{
        header: 'Group Name'.t(),
        allowBlank: false,
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'name',
    }, {
        header: 'Full Tunnel'.t(),
        width: Renderer.booleanWidth + 20,
        dataIndex: 'fullTunnel',
    }, {
        header: 'Push DNS'.t(),
        width: Renderer.booleanWidth + 20,
        dataIndex: 'pushDns'
    }],

    editorFields: [{
        xtype: 'textfield',
        fieldLabel: 'Group Name'.t(),
        bind: '{record.name}',
        validator: function(value, component) {
            if(component === undefined)
                    component = this;
            return Util.isUnique(value, 'group', 'name', component, 'app-openvpn-groups-grid');
        }
    }, {
        xtype: 'checkbox',
        fieldLabel: 'Full Tunnel'.t(),
        bind: '{record.fullTunnel}'
    }, {
        xtype: 'checkbox',
        fieldLabel: 'Push DNS'.t(),
        bind: '{record.pushDns}'
    }, {
        xtype: 'displayfield',
        value: '<STRONG>' + 'Push DNS Configuration'.t() + '</STRONG>',
        bind: {
            hidden: '{!record.pushDns}'
        }
    }, {
        xtype:'combo',
        fieldLabel: 'Push DNS Server'.t(),
        editable: false,
        store: [[true,'OpenVPN Server'.t()],[false,'Custom'.t()]],
        bind: {
            value: '{record.pushDnsSelf}',
            hidden:'{!record.pushDns}'
        }
    }, {
        xtype: 'textfield',
        fieldLabel: 'Push DNS Custom 1'.t(),
        bind: {
            value: '{record.pushDns1}',
            disabled: '{record.pushDnsSelf}',
            hidden:'{!record.pushDns}'
        }
    }, {
        xtype: 'textfield',
        fieldLabel: 'Push DNS Custom 2'.t(),
        bind: {
            value: '{record.pushDns2}',
            disabled: '{record.pushDnsSelf}',
            hidden:'{!record.pushDns}'
        }
    }, {
        xtype:'textfield',
        fieldLabel: 'Push DNS Domain'.t(),
        bind: {
            value: '{record.pushDnsDomain}',
            hidden:'{!record.pushDns}'
        }
    }]

});

Ext.define('Ung.apps.openvpn.cmp.ExportedNetworksGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-openvpn-exported-networks-grid',
    itemId: 'exported-clients-grid',
    viewModel: true,

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'name',
    listProperty: 'settings.exports.list',
    emptyRow: {
        javaClass: 'com.untangle.app.openvpn.OpenVpnExport',
        'enabled': true,
        'name': '',
        'network': ''
    },

    importValidationJavaClass: true,

    bind: '{exportedNetworks}',

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Export Name'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'name',
    }, {
        header: 'Network'.t(),
        width: Renderer.networkWidth,
        dataIndex: 'network',
    }],

    editorFields: [{
        xtype: 'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Enabled'.t()
    }, {
        xtype: 'textfield',
        bind: '{record.name}',
        allowBlank: false,
        fieldLabel: 'Export Name'.t()
    }, {
        xtype:'textfield',
        vtype: 'cidrBlock',
        allowBlank: false,
        fieldLabel: 'Network'.t(),
        bind: '{record.network}'
    }]

});
Ext.define('Ung.apps.openvpn.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-openvpn-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,

        layout: {
            type: 'vbox',
            align: 'stretch'
        },

        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/openvpn.svg" width="80" height="80"/>' +
                '<h3>OpenVPN</h3>' +
                '<p>' + 'OpenVPN provides secure network access and tunneling to remote users and sites using the OpenVPN protocol.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'Connected Remote Clients'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'ungrid',
                itemId: 'activeClients',
                enableColumnHide: true,
                stateful: true,
                trackMouseOver: false,
                resizable: true,
                defaultSortable: true,

                emptyText: 'No Active Clients'.t(),

                bind: {
                    store: '{clientStatusList}'
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'Address'.t(),
                    dataIndex: 'address',
                    width: Renderer.ipWidth,
                    filter: Renderer.stringFilter,
                    flex: 1
                }, {
                    header: 'Client'.t(),
                    dataIndex: 'clientName',
                    width: Renderer.usernameWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Pool Address'.t(),
                    dataIndex: 'poolAddress',
                    width: Renderer.networkWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Start Time'.t(),
                    dataIndex: 'start',
                    renderer: Renderer.timestampUnixRenderer,
                    width: Renderer.timestampWidth,
                    filter: Renderer.timestampFilter
                }, {
                    header: 'Rx Data'.t(),
                    dataIndex: 'bytesRxTotal',
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize,
                    filter: Renderer.numericFilter
                }, {
                    header: 'Tx Data'.t(),
                    dataIndex: 'bytesTxTotal',
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize,
                    filter: Renderer.numericFilter
                }],
                bbar: ['@refresh', '@reset']
            }]
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'Connected Remote Servers'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'ungrid',
                title: 'Remote Server Status'.t(),
                itemId: 'remoteServers',
                enableColumnHide: true,
                stateful: true,
                trackMouseOver: false,
                resizable: true,
                defaultSortable: true,

                emptyText: 'No Remote Servers'.t(),

                bind: {
                    store: '{serverStatusList}'
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'Name'.t(),
                    dataIndex: 'name',
                    width: Renderer.hostnameWidth,
                    filter: Renderer.stringFilter,
                    flex: 1
                }, {
                    header: 'Connected'.t(),
                    dataIndex: 'connected',
                    width: Renderer.messageWidth,
                    filter: Renderer.booleanFilter
                }, {
                    header: 'Rx Data'.t(),
                    dataIndex: 'bytesRead',
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize,
                    filter: Renderer.numericFilter
                }, {
                    header: 'Tx Data'.t(),
                    dataIndex:'bytesWritten',
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize,
                    filter: Renderer.numericFilter
                }],
                bbar: ['@refresh', '@reset']
            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        layout: 'fit',
        items: [{
            xtype: 'appmetrics',
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]

});
