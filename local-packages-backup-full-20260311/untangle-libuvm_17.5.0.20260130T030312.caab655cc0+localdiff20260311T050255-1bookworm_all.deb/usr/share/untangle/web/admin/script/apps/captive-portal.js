Ext.define('Ung.apps.captive-portal.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-captive-portal',
    controller: 'app-captive-portal',

    viewModel: {
        stores: {
            captureRules: { data: '{settings.captureRules.list}' },
            passedClients: { data: '{settings.passedClients.list}' },
            passedServers: { data: '{settings.passedServers.list}' }
        }
    },

    items: [
        { xtype: 'app-captive-portal-status' },
        { xtype: 'app-captive-portal-capturerules' },
        { xtype: 'app-captive-portal-passedhosts' },
        { xtype: 'app-captive-portal-captivepage' },
        { xtype: 'app-captive-portal-userauthentication' }
    ]

});
Ext.define('Ung.apps.captive-portal.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-captive-portal',

    control: {
        '#': {
            afterrender: 'getSettings'
        },
        '#activeUsers': {
            afterrender: 'getActiveUsers'
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getActiveUsers: function (cmp) {
        var vm = this.getViewModel();
        var grid = this.getView().down('#activeUsers');

        grid.setLoading(true);
        Rpc.asyncData(this.getView().appManager, 'getActiveUsers')
        .then( function(result){
            if(Util.isDestroyed(grid, vm)){
                return;
            }
            vm.set('activeUsers', result.list);

            grid.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    previewCaptivePage: function () {
        var vm = this.getViewModel();
        if (!vm.get('state.on')) {
            Ext.MessageBox.alert('Captive Portal is Disabled'.t(),
                'You must turn on the Captive Portal to preview the Captive Page.'.t());
            return;
        }

        // Below custom page condition can be removed when all users have upgraded to v17.2 and no user is having page type - custom
        var custfile = this.getViewModel().get('settings.customFilename');
        var pagetype = vm.get('settings.pageType');

        if ( (pagetype == 'CUSTOM') && ((custfile == null) || (custfile.length === 0)) ) {
            Ext.MessageBox.alert('Missing Custom Captive Page'.t(),
                'Custom captive portal has been deprecated. Switch to Basic Message or Basic Logic Configuration.'.t());
            return;
        }

        window.open('/capture/handler.py/index?appid=' + vm.get('instance.id') , '_blank');
    },

    configureAuthenticationMethod: function (btn) {
        var me = this, vm = this.getViewModel();
        var policyId = vm.get('policyId');
        var authType = this.getViewModel().get('settings.authenticationType');

        Rpc.asyncData('rpc.appManager.app', 'directory-connector')
        .then( function(directoryConnectorApp){
            if(Util.isDestroyed(me, policyId, authType)){
                return;
            }

            // Default to local directory
            var checkDirectoryConnector = false;
            var url = '#config/local-directory';
            switch (authType) {
                case 'RADIUS':
                    checkDirectoryConnector = true;
                    url = '#apps/' + policyId + '/directory-connector/radius';
                    break;
                case 'ACTIVE_DIRECTORY':
                    checkDirectoryConnector = true;
                    url = '#apps/' + policyId + '/directory-connector/active-directory';
                    break;
                case 'ANY_DIRCON':
                    checkDirectoryConnector = true;
                    url = '#apps/' + policyId + '/directory-connector';
                    break;
            }
            if( checkDirectoryConnector && directoryConnectorApp == null){
                me.showMissingServiceWarning();
            }else{
                Ung.app.redirectTo(url);
            }

        },function(ex){
            Util.handleException(ex);
        });
    },

    showMissingServiceWarning: function() {
        Ext.MessageBox.alert('Service Not Installed'.t(), 'The Directory Connector application must be installed to use this feature.'.t());
    },

    logoutUser: function(view, row, col, item, e, record) {
        var me = this;
        var vm = this.getViewModel();
        var netaddr = record.get("userAddress");
        var grid = this.getView().down('#activeUsers');

        grid.setLoading('Logging Out User...'.t());
        Ext.Deferred.sequence([
            Rpc.asyncPromise(this.getView().appManager, 'userAdminLogout', netaddr),
            Rpc.asyncPromise(this.getView().appManager, 'getActiveUsers')
        ], this)
        .then( function(result){
            if(Util.isDestroyed(grid, me, view, vm)){
                return;
            }
            vm.set('activeUsers', result[1].list);

            grid.setLoading(false);
            setTimeout(function() {
                if(Util.isDestroyed(me, view)){
                    return;
                }
                me.getActiveUsers(view);
            },500);
        },function(ex){
            if(!Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },
});
Ext.define('Ung.apps.captive-portal.view.CaptivePage', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-captive-portal-captivepage',
    itemId: 'captive-page',
    title: 'Captive Page'.t(),
    withValidation: true,
    viewModel: {
        formulas: {
            _redirectUrl: {
                get: function (get) {
                    return get('settings.redirectUrl');
                },
                set: function (value) {
                    var useValue = value;
                    if ((value.length > 0) && (value.indexOf('http://') !== 0) && (value.indexOf('https://') !== 0)) {
                        useValue = ('http://' + value);
                    }
                    this.set('settings.redirectUrl', useValue);
                }
            }
        }
    },

    bodyPadding: 10,
    scrollable: 'y',

    layout: {
        type: 'vbox'
    },

    // tbar can be removed when all users have upgraded to v17.2 and no user is having page type - custom
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px' },
        hidden: true,
        bind: {
            hidden: '{settings.pageType !== "CUSTOM"}',
        },
        html: '<i class="fa fa-exclamation-triangle" style="color: red;"></i> ' + 'Custom captive portal has been deprecated. Switch to Basic Message or Basic Logic Configuration.'.t()
    }],

    items: [{
        xtype: 'radiogroup',
        margin: '0 0 20 0',
        bind: '{settings.pageType}',
        simpleValue: true,
        columns: 2,
        items: [
            { boxLabel: '<strong>' + 'Basic Message'.t() + '</strong>', inputValue: 'BASIC_MESSAGE', width: 150 },
            { boxLabel: '<strong>' + 'Basic Login'.t() + '</strong>', inputValue: 'BASIC_LOGIN', width: 150 },
            { xtype: 'button', iconCls: 'fa fa-eye', text: 'Preview Captive Portal Page'.t(), margin: '10 0 0 0', handler: 'previewCaptivePage' }
        ]
    }, {
        xtype: 'fieldset',
        width: '100%',
        title: 'Captive Portal Page Configuration'.t(),
        padding: 10,
        hidden: true,
        bind: {
            hidden: '{settings.pageType !== "BASIC_MESSAGE"}'
        },
        defaults: {
            xtype: 'textfield',
            allowBlank: false,
            labelWidth: 120,
            labelAlign: 'right'
        },
        items: [{
            fieldLabel: 'Page Title'.t(),
            bind: '{settings.basicMessagePageTitle}'
        }, {
            fieldLabel: 'Welcome Text'.t(),
            width: 400,
            bind: '{settings.basicMessagePageWelcome}'
        }, {
            xtype: 'textarea',
            width: 400,
            height: 250,
            fieldLabel: 'Message Text'.t(),
            bind: '{settings.basicMessageMessageText}'
        }, {
            xtype: 'checkbox',
            fieldLabel: 'Agree Checkbox'.t(),
            bind: '{settings.basicMessageAgreeBox}'
        }, {
            fieldLabel: 'Agree Text'.t(),
            width: 400,
            bind: '{settings.basicMessageAgreeText}'
        }, {
            fieldLabel: 'Lower Text'.t(),
            width: 400,
            bind: '{settings.basicMessageFooter}'
        }]
    }, {
        xtype: 'fieldset',
        width: '100%',
        title: 'Captive Portal Page Configuration'.t(),
        padding: 10,
        hidden: true,
        bind: {
            hidden: '{settings.pageType !== "BASIC_LOGIN"}'
        },
        defaults: {
            xtype: 'textfield',
            allowBlank: false,
            labelWidth: 120,
            labelAlign: 'right'
        },
        items: [{
            fieldLabel: 'Page Title'.t(),
            bind: '{settings.basicLoginPageTitle}'
        }, {
            fieldLabel: 'Welcome Text'.t(),
            width: 400,
            bind: '{settings.basicLoginPageWelcome}'
        }, {
            fieldLabel: 'Username Text'.t(),
            bind: '{settings.basicLoginUsername}'
        }, {
            fieldLabel: 'Password Text'.t(),
            bind: '{settings.basicLoginPassword}'
        }, {
            xtype: 'textarea',
            allowBlank: true,
            width: 600,
            height: 200,
            fieldLabel: 'Message Text'.t(),
            bind: '{settings.basicLoginMessageText}'
        }, {
            fieldLabel: 'Lower Text'.t(),
            width: 600,
            bind: '{settings.basicLoginFooter}'
        }]
    }, {
        xtype: 'fieldset',
        width: '100%',
        title: 'HTTPS/SSL Root Certificate Detection'.t(),
        padding: 10,
        hidden: true,
        bind: {
            hidden: '{settings.pageType === "CUSTOM"}'
        },
        items: [{
            xtype: 'radiogroup',
            bind: '{settings.certificateDetection}',
            simpleValue: true,
            columns: 1,
            vertical: true,
            items: [
                { boxLabel: 'Disable certificate detection.'.t(), inputValue: 'DISABLE_DETECTION' },
                { boxLabel: 'Check certificate. Show warning when not detected.'.t(), inputValue: 'CHECK_CERTIFICATE' },
                { boxLabel: 'Require certificate. Prohibit login when not detected.'.t(), inputValue: 'REQUIRE_CERTIFICATE' }
            ]
        }]
    }, {
        xtype: 'fieldset',
        width: '100%',
        title: 'Session Redirect'.t(),
        padding: 10,
        items: [{
            xtype: 'checkbox',
            boxLabel: 'Block instead of capture and redirect unauthenticated HTTPS connections'.t(),
            bind: '{settings.disableSecureRedirect}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Use hostname instead of IP address for the capture page redirect'.t(),
            bind: '{settings.redirectUsingHostname}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Always use HTTPS for the capture page redirect'.t(),
            bind: '{settings.alwaysUseSecureCapture}'
        }, {
            xtype: 'textfield',
            width: 600,
            fieldLabel: 'Redirect URL'.t(),
            bind: '{_redirectUrl}',
            vtype: 'url'
        }, {
            xtype: 'component',
            margin: '10 0 0 0',
            html: '<B>NOTE:</B> The Redirect URL field must start with http:// or https:// and allows you to specify a page to display immediately after user authentication.  If you leave this field blank, users will instead be forwarded to their original destination.'.t()
        }]
    }]
});
Ext.define('Ung.apps.captive-portal.view.CaptureRules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-captive-portal-capturerules',
    itemId: 'capture-rules',
    title: 'Capture Rules'.t(),
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Network access is controlled based on the set of rules defined below. To learn more click on the <b>Help</b> button below.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    listProperty: 'settings.captureRules.list',

    emptyText: 'No Capture Rules defined'.t(),

    emptyRow: {
        ruleId: -1,
        enabled: true,
        description: '',
        capture: false,
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.captive_portal.CaptureRule'
    },

    bind: '{captureRules}',

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    extraColumnConfig: {
        id: { xtype: 'numberfield' },
    },

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions, {
            xtype: 'checkcolumn',
            header: 'Capture',
            dataIndex: 'capture',
            resizable: false,
            width: Renderer.booleanWidth
        }

    ],

    // todo: continue this stuff
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.captive_portal.CaptureRuleCondition', [
            "DST_ADDR",
            "DST_PORT",
            "DST_INTF",
            "SRC_ADDR",
            "SRC_PORT",
            "SRC_INTF",
            "PROTOCOL",
            "TAGGED",
            "USERNAME",
            "HOST_HOSTNAME",
            "CLIENT_HOSTNAME",
            "SERVER_HOSTNAME",
            "SRC_MAC",
            "DST_MAC",
            "CLIENT_MAC_VENDOR",
            "SERVER_MAC_VENDOR",
            "CLIENT_IN_PENALTY_BOX",
            "SERVER_IN_PENALTY_BOX",
            "HOST_HAS_NO_QUOTA",
            "USER_HAS_NO_QUOTA",
            "CLIENT_HAS_NO_QUOTA",
            "SERVER_HAS_NO_QUOTA",
            "HOST_QUOTA_EXCEEDED",
            "USER_QUOTA_EXCEEDED",
            "CLIENT_QUOTA_EXCEEDED",
            "SERVER_QUOTA_EXCEEDED",
            "HOST_QUOTA_ATTAINMENT",
            "USER_QUOTA_ATTAINMENT",
            "CLIENT_QUOTA_ATTAINMENT",
            'HOST_ENTITLED',
            "SERVER_QUOTA_ATTAINMENT",
            "DIRECTORY_CONNECTOR_GROUP",
            'DIRECTORY_CONNECTOR_DOMAIN',
            'HTTP_HOST',
            'HTTP_REFERER', 
            'HTTP_URI',
            'HTTP_URL',
            'HTTP_CONTENT_TYPE',
            'HTTP_CONTENT_LENGTH',
            'HTTP_REQUEST_METHOD',
            'HTTP_REQUEST_FILE_PATH',
            'HTTP_REQUEST_FILE_NAME',
            'HTTP_REQUEST_FILE_EXTENSION',
            'HTTP_RESPONSE_FILE_NAME',
            'HTTP_RESPONSE_FILE_EXTENSION',
            'HTTP_USER_AGENT',
            'HTTP_USER_AGENT_OS',
            'SSL_INSPECTOR_SNI_HOSTNAME',
            'SSL_INSPECTOR_SUBJECT_DN',
            'SSL_INSPECTOR_ISSUER_DN',
            "CLIENT_COUNTRY",
            "SERVER_COUNTRY",
            'THREAT_PREVENTION_SRC_REPUTATION',
            'THREAT_PREVENTION_SRC_CATEGORIES',
            'THREAT_PREVENTION_DST_REPUTATION',
            'THREAT_PREVENTION_DST_CATEGORIES'
        ]), {
            xtype: 'combo',
            allowBlank: false,
            bind: '{record.capture}',
            fieldLabel: 'Action Type'.t(),
            editable: false,
            store: [[true, 'Capture'.t()], [false, 'Pass'.t()]],
            queryMode: 'local'
        }
    ]
});
Ext.define('Ung.apps.captive-portal.view.PassedHosts', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-captive-portal-passedhosts',
    itemId: 'passed-hosts',
    title: 'Passed Hosts'.t(),
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'The pass lists provide a quick alternative way to allow access from specific clients, or to specific servers.'.t()
    }],

    layout: 'border',

    defaults: {
        xtype: 'ungrid',
        // border: false,
        split: true,
        tbar: ['@addInline', '->', '@import', '@export'],

        recordActions: ['delete'],

        emptyRow: {
            enabled: true,
            log: false,
            address: '0.0.0.0',
            description: '',
            javaClass: 'com.untangle.app.captive_portal.PassedAddress'
        },

        importValidationJavaClass: true,

        extraColumnConfig: {
            enabled: { xtype: 'checkcolumn' },
            log: { xtype: 'checkcolumn' },
        },

        columns: [
            Column.enabled,{
                xtype: 'checkcolumn',
                header: 'Log'.t(),
                dataIndex: 'log',
                resizable: false,
                width: Renderer.booleanWidth
            }, {
                header: 'Address'.t(),
                width: Renderer.ipWidth,
                dataIndex: 'address',
                editor: {
                    xtype: 'textfield',
                    emptyText: '[enter address]'.t(),
                    vtype: 'ipMatcher',
                    allowBlank: false
                }
            }, {
                header: 'Description'.t(),
                width: Renderer.messageWidth,
                flex: 1,
                dataIndex: 'description',
                editor: {
                    xtype: 'textfield',
                    emptyText: '[no description]'.t()
                }
            }
        ]
    },

    items: [{
        region: 'center',
        title: 'Pass Listed Client Addresses'.t(),
        bind: '{passedClients}',
        listProperty: 'settings.passedClients.list',
        emptyText: 'No Pass Listed Client Addresses defined'.t(),
        bbar: [{
            xtype: 'component',
            padding: 5,
            style: {
                fontSize: '10px',
                color: '#777'
            },
            html: '<i class="fa fa-info-circle"></i> ' + 'Pass Listed Client Addresses is a list of Client IPs that are not subjected to the Captive Portal.'.t()
        }]
    }, {
        region: 'south',
        height: '50%',
        title: 'Pass Listed Server Addresses'.t(),
        bind: '{passedServers}',
        emptyText: 'No Pass Listed Server Addresses defined'.t(),
        listProperty: 'settings.passedServers.list',
        bbar: [{
            xtype: 'component',
            padding: 5,
            style: {
                fontSize: '10px',
                color: '#777'
            },
            html: '<i class="fa fa-info-circle"></i> ' + 'Pass Listed Server Addresses is a list of Server IPs that unauthenticated clients can access without authentication.'.t()
        }]
    }]
});
Ext.define('Ung.apps.captive-portal.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-captive-portal-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/captive-portal.svg" width="80" height="80"/>' +
                '<h3>Captive Portal</h3>' +
                '<p>' + 'Captive Portal allows administrators to require network users to complete a defined process, such as logging in or accepting a network usage policy, before accessing the internet.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'Active Sessions'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            layout: 'fit',

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'ungrid',
                itemId: 'activeUsers',
                minHeight: 150,
                trackMouseOver: false,
                sortableColumns: true,
                enableColumnHide: false,

                emptyText: 'No Active Sessions',

                bind: {
                    store: {
                        data: '{activeUsers}'
                    }
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'User Address'.t(),
                    dataIndex: 'userAddress',
                    width: Renderer.usernameWidth,
                    filter: Renderer.stringFilter
                }, {
                    header: 'User Name'.t(),
                    dataIndex: 'userName',
                    width: Renderer.usernameWidth,
                    flex: 1,
                    filter: Renderer.stringFilter
                }, {
                    header: 'Login Time'.t(),
                    dataIndex: 'sessionCreation',
                    width: Renderer.timestampWidth,
                    renderer: Renderer.timestamp,
                    filter: Renderer.timestampFilter
                }, {
                    header: 'Session Count'.t(),
                    dataIndex: 'sessionCounter',
                    width: Renderer.sizeWidth,
                    renderer: Renderer.count,
                    filter: Renderer.numericFilter
                }, {
                    header: 'Logout'.t(),
                    xtype: 'actioncolumn',
                    width: Renderer.actionWidth,
                    align: 'center',
                    iconCls: 'fa fa-minus-circle',
                    handler: 'externalAction',
                    action: 'logoutUser'
                }],
                bbar: [ '@refresh', '@reset']
            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
Ext.define('Ung.apps.captive-portal.view.UserAuthentication', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-captive-portal-userauthentication',
    itemId: 'user-authentication',
    title: 'User Authentication'.t(),
    scrollable: true,
    withValidation: true,
    viewModel: {
        formulas: {
            _idleTimeout: {
                get: function (get) {
                    return get('settings.idleTimeout') / 60;
                },
                set: function (value) {
                    this.set('settings.idleTimeout', value * 60);
                }
            },
            _userTimeout: {
                get: function (get) {
                    return get('settings.userTimeout') / 60;
                },
                set: function (value) {
                    this.set('settings.userTimeout', value * 60);
                }
            },
            _cookieTimeout: {
                get: function (get) {
                    return get('settings.sessionCookiesTimeout') / 60;
                },
                set: function (value) {
                    this.set('settings.sessionCookiesTimeout', value * 60);
                }
            },
            _btnConfigureDirectory: function (get) {
                switch (get('settings.authenticationType')) {
                case 'LOCAL_DIRECTORY': return 'Configure Local Directory'.t();
                case 'RADIUS': return 'Configure RADIUS'.t();
                case 'ACTIVE_DIRECTORY': return 'Configure Active Directory'.t();
                case 'ANY_DIRCON': return 'Configure Directory Connector'.t();
                default: return '';
                }
            },
            _btnConfigureDisabled: function (get) {
                switch (get('settings.authenticationType')) {
                case 'LOCAL_DIRECTORY': return false;
                case 'RADIUS': return  false;
                case 'ACTIVE_DIRECTORY': return false;
                case 'ANY_DIRCON': return false;
                default: return true;
                }
            }

        }
    },

    bodyPadding: 10,

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    defaults: {
        xtype: 'fieldset',
        padding: 10,
    },

    items: [{
        title: 'Authentication Method'.t(),
        items: [{
            xtype: 'radiogroup',
            bind: '{settings.authenticationType}',
            simpleValue: 'true',
            columns: 1,
            vertical: true,
            items: [
                { boxLabel: '<strong>' + 'None'.t() + '</strong>', inputValue: 'NONE' },
                { boxLabel: '<strong>' + 'Local Directory'.t() + '</strong>', inputValue: 'LOCAL_DIRECTORY' },
                { boxLabel: '<strong>' + 'RADIUS'.t() + '</strong> (' + 'requires'.t() + ' Directory Connector)', inputValue: 'RADIUS' },
                { boxLabel: '<strong>' + 'Active Directory'.t() + '</strong> (' + 'requires'.t() + ' Directory Connector)', inputValue: 'ACTIVE_DIRECTORY' },
                { boxLabel: '<strong>' + 'Any Directory Connector'.t() + '</strong> (' + 'requires'.t() + ' Directory Connector)', inputValue: 'ANY_DIRCON' },
                { boxLabel: '<strong>' + 'Google Account'.t() + '</strong> (OAuth Provider, requires SSL Inspector)', inputValue: 'GOOGLE' },
                { boxLabel: '<strong>' + 'Microsoft Account'.t() + '</strong> (OAuth Provider)', inputValue: 'MICROSOFT' },
                { boxLabel: '<strong>' + 'Any OAuth Provider'.t() + '</strong> (' + 'uses OAuth provider selection page'.t() + ')', inputValue: 'ANY_OAUTH' },
            ]
        }, {
            // todo: update this button later
            xtype: 'button',
            iconCls: 'fa fa-cog',
            disabled: true,
            hidden: true,
            bind: {
                text: '{_btnConfigureDirectory}',
                disabled: '{_btnConfigureDisabled}',
                hidden: '{_btnConfigureDisabled}'
            },
            handler: 'configureAuthenticationMethod'
        }]
    }, {
        title: 'Session Settings'.t(),
        defaults: {
            margin: '5 0'
        },
        items: [{
            xtype: 'container',
            layout: { type: 'hbox', align: 'middle' },
            items: [{
                xtype: 'numberfield',
                fieldLabel: 'Idle Timeout (minutes)'.t(),
                invalidText: 'The Idle Timeout must be 0 or greater.'.t(),
                labelWidth: 200,
                width: 300,
                allowBlank: false,
                minValue: 0,
                bind: '{_idleTimeout}'
            }, {
                xtype: 'label',
                margin: '0 0 0 10',
                style: {
                    fontSize: '11px',
                    color: '#555'
                },
                html: 'Clients will be unauthenticated after this amount of idle time. They may re-authenticate immediately.  Zero disables idle timeout.'.t()
            }]
        }, {
            xtype: 'container',
            layout: { type: 'hbox', align: 'middle' },
            items: [{
                xtype: 'numberfield',
                fieldLabel: 'Timeout (minutes)'.t(),
                invalidText: 'The Timeout must be more than 5 minutes and less than 525600 minutes.'.t(),
                labelWidth: 200,
                width: 300,
                allowBlank: false,
                maxValue: 525600,
                minValue: 5,
                bind: '{_userTimeout}'
            }, {
                xtype: 'label',
                margin: '0 0 0 10',
                style: {
                    fontSize: '11px',
                    color: '#555'
                },
                html: 'Clients will be unauthenticated after this amount of time regardless of activity. They may re-authenticate immediately.'.t()
            }]
        }, {
            xtype: 'checkbox',
            boxLabel: 'Allow Concurrent Logins'.t(),
            tooltip: 'This will allow multiple hosts to use the same username & password concurrently.'.t(),
            bind: '{settings.concurrentLoginsEnabled}',
        }, {
            xtype: 'checkbox',
            boxLabel: 'Track logins using MAC address'.t(),
            tooltip: 'This will allow client authentication to be tracked by MAC address instead of IP address.'.t(),
            bind: '{settings.useMacAddress}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Allow Cookie-based authentication'.t(),
            tooltip: 'This will allow authenicated clients to continue to access even after session idle and timeout values.'.t(),
            bind: '{settings.sessionCookiesEnabled}'
        }, {
            xtype: 'container',
            margin: '0 0 0 20',
            layout: { type: 'hbox', align: 'middle' },
            disabled: true,
            hidden: true,
            bind: {
                disabled: '{!settings.sessionCookiesEnabled}',
                hidden: '{!settings.sessionCookiesEnabled}'
            },
            items: [{
                xtype: 'numberfield',
                fieldLabel: 'Cookie Timeout (minutes)'.t(),
                invalidText: 'The Cookie Timeout must be more than 5 minutes and less than 525600 minutes.'.t(),
                labelWidth: 200,
                width: 300,
                allowBlank: false,
                maxValue: 525600,
                minValue: 5,
                bind: '{_cookieTimeout}'
            }, {
                xtype: 'label',
                margin: '0 0 0 10',
                style: {
                    fontSize: '11px',
                    color: '#555'
                },
                html: 'Clients will be unauthenticated after this amount of time regardless of activity. They may re-authenticate immediately.'.t()
            }]
        }]
    }]
});
