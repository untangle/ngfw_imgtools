Ext.define('Ung.apps.livesupport.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-live-support',
    controller: 'app-live-support',

    viewModel: {
        data: {
            companyName: '',
            companyURL: '',
            serverUID: '',
            fullVersionAndRevision: ''
        }
    },

    items: [{
        xtype: 'app-live-support-status'
    }]
});
Ext.define('Ung.apps.livesupport.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.app-live-support',

    control: {
        '#': {
            afterrender: 'onAfterRender'
        }
    },

    onAfterRender: function(){
        var me = this, v = me.getView(), vm = me.getViewModel();

        // There's nothing to save on this form.
        vm.set('panel.saveDisabled', true);

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.directPromise('rpc.companyName'),
            Rpc.directPromise('rpc.companyURL'),
            Rpc.directPromise('rpc.serverUID'),
            Rpc.directPromise('rpc.fullVersionAndRevision')
        ], this)
        .then(function (result) {
            if(Util.isDestroyed(v, vm)){
                return;
            }
            vm.set({
                companyName: result[0],
                companyURL: result[1],
                serverUID: result[2],
                fullVersionAndRevision: result[3],
            });

            var paidFrame = v.down('[itemId=paidFrame]');
            var freeFrame = v.down('[itemId=freeFrame]');

            // get the license and show either the Get Support or Learn More section
            Rpc.asyncData('rpc.UvmContext.licenseManager.getLicense', 'live-support').then(function(license) {
                if ((license) && (license.valid)) {
                    paidFrame.setHidden(false);
                } else {
                    freeFrame.setHidden(false);
                }
            });

            v.setLoading(false);
        });
    },

    supportHandler: function(btn){
        this.getView().up('[itemId=main]').getController().supportHandler(btn);
    },

    // When the license is not valid we want the Learn More button open the companyURL configured
    // in the branding manager. If it is not configured or is our Untangle default, we open
    // our Live-Support app page.
    learnMoreHandler: function(btn){
        var target = this.getViewModel().get('companyURL');
        if ((target) && (target !== '') && (! target.includes('edge.arista.com'))) {
            window.open(target);
        } else {
            window.open(rpc.uriManager.getUriWithPath("https://edge.arista.com/shop/Live-Support"));
        }
    }
});
Ext.define('Ung.apps.livesupport.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-live-support-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    requires: [
        'Ung.cmp.LicenseLoader'
    ],

    items: [{
        title: 'Status'.t(),
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/live-support.svg" width="80" height="80"/>' +
                '<h3>Live Support</h3>' +
                '<p>' + 'Live Support provides on-demand help for any technical issues.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-life-ring"></i> ' + 'Live Support'.t(),
            itemId: 'paidFrame',
            padding: 10,
            margin: '20 0',
            cls: 'app-section',
            hidden: true,
            items: [{
                xtype: 'component',
                bind: {
                    html: Ext.String.format('This {0} Server is entitled to Live Support.'.t(), Rpc.directData('rpc.companyName'))
                },
                html: Ext.String.format('This {0} Server is entitled to Live Support.'.t(), '{companyName}'),
                margin: '0 0 10 0'
            }, {
                xtype: 'button',
                text: 'Get Support!'.t(),
                handler: 'supportHandler'
            }]
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-life-ring"></i> ' + 'Live Support'.t(),
            itemId: 'freeFrame',
            padding: 10,
            margin: '20 0',
            cls: 'app-section',
            hidden: true,
            items: [{
                xtype: 'component',
                bind: {
                    html: Ext.String.format('This {0} Server is NOT entitled to Live Support.'.t(), Rpc.directData('rpc.companyName'))
                },
                html: Ext.String.format('This {0} Server is NOT entitled to Live Support.'.t(), '{companyName}'),
                margin: '0 0 10 0'
            }, {
                xtype: 'button',
                text: 'Learn More!'.t(),
                handler: 'learnMoreHandler'
            }]
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-info-circle"></i> ' + 'Support Information'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',
            defaults: {
                xtype: 'displayfield',
                labelWidth: 50,
                labelAlign: 'right'
            },
            items: [{
                fieldLabel: '<strong>' + 'UID'.t() + '</strong>',
                bind: '{serverUID}'
            }, {
                fieldLabel: '<strong>' + 'Build'.t() + '</strong>',
                bind: '{fullVersionAndRevision}'
            }]
        }, {
            xtype: 'appremove'
        }]
    }]

});
