Ext.define('Ung.config.email.EmailTest', {
    extend: 'Ext.window.Window',
    width: 500,
    height: 300,
    modal: true,

    alias: 'widget.config.email.test',

    controller: 'config.email.test',

    title: 'Email Test'.t(),
    autoShow: true,

    layout: 'fit',
    plain: false,
    bodyBorder: false,
    border: false,

    items: [{
        xtype: 'form',
        // border: false,
        bodyPadding: 10,
        layout: 'anchor',
        items: [{
            xtype: 'component',
            html: '<strong style="margin-bottom:20px;font-size:11px;display:block;">' + 'Enter an email address to send a test message and then press Send. That email account should receive an email shortly after running the test. If not, the email settings may not be correct.<br/><br/>It is recommended to verify that the email settings work for sending to both internal (your domain) and external email addresses.'.t() + '</strong>'
        }, {
            xtype: 'textfield',
            anchor: '100%',
            vtype: 'email',
            validateOnBlur: true,
            allowBlank: false,
            fieldLabel: 'Email Address'.t(),
            emptyText: '[enter email]'.t(),
            bind: {
                disabled: '{processing === true}'
            }
        }, {
            xtype: 'component',
            bind: {
                html: '{emailRef}'
            }
        }, {
            xtype: 'component',
            padding: 10,
            style: {
                textAlign: 'center',
            },
            hidden: true,
            bind: {
                html: '{processingIcon}',
                hidden: '{processing === false}'
            }
        }],

        buttons: [{
            text: 'Cancel'.t(),
            handler: 'cancel'
        }, {
            text: 'Send'.t(),
            formBind: true,
            handler: 'sendMail'
        }]
    }],

    viewModel: {
        data: {
            processingIcon: null,
            processing: false
        },
    }

});
Ext.define('Ung.config.email.EmailTestController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.config.email.test',

    sendMail: function (btn) {
        var v = this.getView(), vm = this.getViewModel();
        btn.setDisabled(true);
        vm.set({
            processing: true,
            processingIcon: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>'
        });
        Rpc.asyncData('rpc.UvmContext.mailSender.sendTestMessage', v.down('textfield').getValue())
        .then(function (result) {
            if(Util.isDestroyed(vm, btn)){
                return;
            }
            if (result == 'Completed') {
                vm.set({
                    processing: null,
                    processingIcon: '<i class="fa fa-check fa-3x fa-fw" style="color: green;"></i> <br/>' + 'Email sent. Verify successful delivery with recipient.'.t()
                });
            } else {
                vm.set({
                    processing: null,
                    processingIcon: '<i class="fa fa-close fa-3x fa-fw" style="color: red;"></i> <br/>' + result
                });
            }
            btn.setDisabled(false);
        }, function(ex){
            if(!Util.isDestroyed(btn)){
                btn.setDisabled(false);
            }
        });
    },
    cancel: function () {
        this.getView().close();
    }

});
Ext.define('Ung.config.email.Main', {
    extend: 'Ung.cmp.ConfigPanel',
    alias: 'widget.config-email',
    name: 'email',

    controller: 'config.email',

    viewModel: {
        data: {
            title: 'Email'.t(),
            iconName: 'email',

            globalSafeList: null,
        }
    },

    items: [
        { xtype: 'config-email-outgoingserver' },
        {
            xtype: 'config-email-safelist',
            tabConfig: {
                hidden: true,
                bind: { hidden: '{!smtp}' }
            }
        },
        {
            xtype: 'config-email-quarantine',
            tabConfig: {
                hidden: true,
                bind: { hidden: '{!smtp}' }
            }
        }
    ]
});
Ext.define('Ung.config.email.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.config.email',

    control: {
        '#': { afterrender: 'loadSettings'}
    },

    originalMailSender: null,

    loadSettings: function () {
        var me = this, v = me.getView(), vm = me.getViewModel();

        var sequence = [
            Rpc.asyncPromise('rpc.UvmContext.mailSender.getSettings')
        ];
        var dataNames = [
            'mailSender'
        ];

        if(Rpc.directData('rpc.appManager.app', 'smtp')){
            vm.set('smtp', true);
            sequence.push(
                Rpc.asyncPromise('rpc.appManager.app("smtp").getSmtpSettings'),
                Rpc.asyncPromise('rpc.appManager.app("smtp").getSafelistAdminView.getSafelistContents', 'GLOBAL'),
                Rpc.asyncPromise('rpc.appManager.app("smtp").getSafelistAdminView.getUserSafelistCounts'),
                Rpc.asyncPromise('rpc.appManager.app("smtp").getQuarantineMaintenenceView.listInboxes'),
                Rpc.asyncPromise('rpc.appManager.app("smtp").getQuarantineMaintenenceView.getInboxesTotalSize'),
                Rpc.directPromise('rpc.companyName')
            );

            dataNames.push(
                'smtpSettings',
                'globalSafeList',
                'userSafeList',
                'inboxesList',
                'inboxesTotalSize',
                'companyName'
            );
        }else{
            vm.set('smtp', false);
        }

        v.setLoading(true);
        Ext.Deferred.sequence(sequence, this).then(function(result) {
            if(Util.isDestroyed(me, v, vm)){
                return;
            }
            dataNames.forEach(function(name, index){
                vm.set(name, result[index]);
            });

            me.originalMailSender = Ext.clone(result[0]);
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
        });
    },


    saveSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(this.getView())) {
            return null;
         }

        var fromAddressCmp = v.down('textfield[name="FromAddress"]');
        if (fromAddressCmp.rendered && !fromAddressCmp.isValid()) {
            Ung.app.redirectTo('#config/email/outgoing-server');
            Ext.MessageBox.alert('Warning'.t(), 'A From Address must be specified.'.t());
            fromAddressCmp.focus(true);
            return null;
        }

        v.setLoading(true);

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            /**
             * Important!
             * update custom grids only if are modified records or it was reordered via drag/drop
             */
            if (store.getModifiedRecords().length > 0 || store.isReordered) {

                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;

                if (grid.getItemId() === 'safeListStore') { // this needs to be transformed back to array
                    var emails = [];
                    store.each(function(record) {
                        emails.push(record.get('emailAddress'));
                    });
                    vm.set('globalSafeList', emails);
                } else {
                    vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
                }
                // store.commitChanges();
            }
        });

        var sequence = [
            Rpc.asyncPromise('rpc.UvmContext.mailSender.setSettings', vm.get('mailSender'))
        ];

        if(Rpc.directData('rpc.appManager.app', 'smtp')){
            sequence.push(Rpc.asyncPromise('rpc.appManager.app("smtp").setSmtpSettingsWithoutSafelists', vm.get('smtpSettings')));
            sequence.push(Rpc.asyncPromise('rpc.appManager.app("smtp").getSafelistAdminView.replaceSafelist', 'GLOBAL', vm.get('globalSafeList')));
        }
        Ext.Deferred.sequence(sequence, this).then(function(result) {
            if(Util.isDestroyed(me, v, vm)){
                return;
            }
            me.loadSettings();
            Util.successToast('Email settings saved!');
            Ext.fireEvent('resetfields', v);
        }, function (ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
        });

        // testEmail needs to handle this as a promise.
        return Ext.Deferred.resolved();
    },

    testEmail: function () {
        var me = this, vm = this.getViewModel(),
            modifiedVal = Ext.encode(vm.get('mailSender')),
            originalVal = Ext.encode(me.originalMailSender);

        if (originalVal !== modifiedVal) {
            Ext.Msg.show({
                title: 'Save Changes?'.t(),
                msg: Ext.String.format('Your current settings have not been saved yet.{0}Would you like to save your settings before executing the test?'.t(), '<br />'),
                buttons: Ext.Msg.YESNOCANCEL,
                fn: function(btnId) {
                    if(Util.isDestroyed(me)){
                        return;
                    }
                    if (btnId === 'yes') {
                        me.saveSettings().then(function () {
                            Ext.create('Ung.config.email.EmailTest');
                        });
                    }
                    if (btnId === 'no') {
                        Ext.create('Ung.config.email.EmailTest');
                    }
                },
                animEl: 'elId',
                icon: Ext.MessageBox.QUESTION
            });
        } else {
            Ext.create('Ung.config.email.EmailTest');
        }
    },

    purgeUserSafeList: function (btn) {
        var me = this,
            grid = btn.up('grid'),
            selected = grid.getSelectionModel().getSelected(),
            accounts = [];

        if (!selected || selected.length === 0) {
            return;
        }

        selected.each(function(record) {
            accounts.push(record.get('emailAddress'));
        });

        Ext.MessageBox.wait('Purging...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.appManager.app("smtp").getSafelistAdminView.deleteSafelists', accounts)
        .then(function() {
            if(Util.isDestroyed(me)){
                return;
            }
            me.loadSettings();
        }).always(function () {
            Ext.MessageBox.hide();
        });
    },

    purgeInboxes: function (btn) {
        var me = this,
            grid = btn.up('grid'),
            selected = grid.getSelectionModel().getSelected(),
            accounts = [];

        if (!selected || selected.length === 0) {
            return;
        }

        selected.each(function(record) {
            accounts.push(record.get('address'));
        });

        Ext.MessageBox.wait('Purging...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.appManager.app("smtp").getQuarantineMaintenenceView.deleteInboxes', accounts)
        .then(function() {
            if(Util.isDestroyed(me)){
                return;
            }
            me.refreshUserQuarantines();
        }).always(function () {
            Ext.MessageBox.hide();
        });
    },

    releaseInboxes: function (btn) {
        var me = this,
            grid = btn.up('grid'),
            selected = grid.getSelectionModel().getSelected(),
            accounts = [];

        if (!selected || selected.length === 0) {
            return;
        }

        selected.each(function(record) {
            accounts.push(record.get('address'));
        });

        Ext.MessageBox.wait('Releasing...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.appManager.app("smtp").getQuarantineMaintenenceView.rescueInboxes', accounts)
        .then(function() {
            if(Util.isDestroyed(me)){
                return;
            }
            me.refreshUserQuarantines();
        }).always(function () {
            Ext.MessageBox.hide();
        });
    },

    showQuarantineDetails: function (view, rowIndex, colIndex, item, e, record) {
        var me = this;
        me.dialog = me.getView().add({
            xtype: 'window',
            title: 'Email Quarantine Details for:'.t() + ' ' + record.get('address'),
            width: Ext.getBody().getViewSize().width - 20,
            maxHeight: Ext.getBody().getViewSize().height - 20,
            modal: true,
            layout: 'fit',
            items: [{
                xtype: 'ungrid',
                reference: 'mailsGrid',
                account: record.get('address'),
                border: false,
                bodyBorder: false,
                emptyText: 'No emails'.t(),
                selModel: {
                    selType: 'checkboxmodel'
                },
                store: { data: [] },
                plugins: ['gridfilters'],
                sortField: 'quarantinedDate',
                fields: [{
                    name: 'mailID'
                }, {
                    name: 'quarantinedDate',
                }, {
                    name: 'size'
                }, {
                    name: 'sender'
                }, {
                    name: 'subject'
                }, {
                    name: 'quarantineCategory'
                }, {
                    name: 'quarantineDetail'
                }],
                columns: [{
                    header: 'Date'.t(),
                    width: Renderer.timestampWidth,
                    dataIndex: 'quarantinedDate',
                    renderer: Renderer.timestamp
                }, {
                    header: 'Sender'.t(),
                    width: Renderer.emailWidth,
                    dataIndex: 'sender',
                    filter: { type: 'string' }
                }, {
                    header: 'Subject'.t(),
                    width: Renderer.messageWidth,
                    flex: 1,
                    dataIndex: 'subject',
                    filter: { type: 'string' }
                }, {
                    header: 'Size (KB)'.t(),
                    width: Renderer.sizeWidth,
                    dataIndex: 'size',
                    renderer: Renderer.datasize,
                    filter: { type: 'numeric' }
                }, {
                    header: 'Category'.t(),
                    width: Renderer.idWidth,
                    dataIndex: 'quarantineCategory',
                    filter: { type: 'string' }
                }, {
                    header: 'Detail'.t(),
                    width: Renderer.sizeWidth,
                    dataIndex: 'quarantineDetail',
                    renderer: function(value) {
                        var detail = value;
                        if (isNaN(parseFloat(detail))) {
                            if (detail === 'Message determined to be a fraud attempt') {
                                return 'Phish'.t();
                            }
                        } else {
                            return parseFloat(detail).toFixed(3);
                        }
                        return detail;
                    },
                    filter: { type: 'numeric' }
                }],
                tbar: [{
                    text: 'Purge Selected'.t(),
                    iconCls: 'fa fa-circle fa-red',
                    handler: 'externalAction',
                    action: 'purgeMails',
                    disabled: true,
                    bind: {
                        disabled: '{!mailsGrid.selection}'
                    }
                }, {
                    text: 'Release Selected'.t(),
                    iconCls: 'fa fa-circle fa-green',
                    handler: 'externalAction',
                    action: 'releaseMails',
                    disabled: true,
                    bind: {
                        disabled: '{!mailsGrid.selection}'
                    }
                }],
            }],
            fbar: [{
                text: 'Done'.t(),
                iconCls: 'fa fa-check',
                handler: function (btn) {
                    btn.up('window').close();
                }
            }],
            listeners: {
                afterrender: function (win) {
                    me.getAccountEmails();
                },
                close: function () {
                    me.refreshUserQuarantines();
                }
            }
        });
        me.dialog.show();
    },

    refreshUserQuarantines: function () {
        var me = this, vm = me.getViewModel();
        me.lookup('inboxesGrid').setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise ('rpc.appManager.app("smtp").getQuarantineMaintenenceView.listInboxes'),
            Rpc.asyncPromise('rpc.appManager.app("smtp").getQuarantineMaintenenceView.getInboxesTotalSize')
        ], this).then(function(result) {
            if(Util.isDestroyed(vm)){
                return;
            }
            vm.set({
                inboxesList: result[0],
                inboxesTotalSize: result[1]
            });
        }, function(ex) {
            console.error(ex);
            Util.handleException(ex);
        }).always(function() {
            me.lookup('inboxesGrid').setLoading(false);
        });
    },


    getAccountEmails: function () {
        var me = this;
        if (!me.dialog) {
            return;
        }

        var grid = me.dialog.down('grid');
        me.dialog.setLoading(true);
        Rpc.asyncData('rpc.appManager.app("smtp").getQuarantineMaintenenceView.getInboxRecords', grid.account)
        .then(function (result) {
            if(Util.isDestroyed(grid)){
                return;
            }
            if (result && result.list) {
                for (var i=0; i< result.list.length; i++) {
                    /* copy values from mailSummary to object */
                    result.list[i].subject = result.list[i].mailSummary.subject;
                    result.list[i].sender = result.list[i].mailSummary.sender;
                    result.list[i].quarantinedDate = result.list[i].internDate;
                    result.list[i].quarantineCategory = result.list[i].mailSummary.quarantineCategory;
                    result.list[i].quarantineDetail = result.list[i].mailSummary.quarantineDetail;
                    result.list[i].size = result.list[i].mailSummary.quarantineSize;
                }
            }
            grid.getStore().loadData(result.list);
        }).always(function () {
            if(Util.isDestroyed(me)){
                return;
            }
            me.dialog.setLoading(false);
        });
    },

    purgeMails: function (btn) {
        var me = this,
            grid = btn.up('grid'),
            selected = grid.getSelectionModel().getSelected(),
            emails = [];

        if (!selected || selected.length === 0) {
            return;
        }

        selected.each(function(record) {
            emails.push(record.get('mailID'));
        });

        Ext.MessageBox.wait('Purging...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.appManager.app("smtp").getQuarantineMaintenenceView.purge', grid.account, emails)
        .then(function() {
            if(Util.isDestroyed(me)){
                return;
            }
            me.getAccountEmails();
        }).always(function () {
            Ext.MessageBox.hide();
        });
    },

    releaseMails: function (btn) {
        var me = this,
            grid = btn.up('grid'),
            selected = grid.getSelectionModel().getSelected(),
            emails = [];

        if (!selected || selected.length === 0) {
            return;
        }

        selected.each(function(record) {
            emails.push(record.get('mailID'));
        });

        Ext.MessageBox.wait('Releasing...'.t(), 'Please wait'.t());
        Rpc.asyncData('rpc.appManager.app("smtp").getQuarantineMaintenenceView.rescue', grid.account, emails)
        .then(function() {
            if(Util.isDestroyed(me)){
                return;
            }
            me.getAccountEmails();
        }).always(function () {
            Ext.MessageBox.hide();
        });
    }
});
Ext.define('Ung.config.email.view.OutgoingServer', {
    extend: 'Ext.form.Panel',
    alias: 'widget.config-email-outgoingserver',
    itemId: 'outgoing-server',
    scrollable: true,
    withValidation: true,
    viewModel: true,
    title: 'Outgoing Server'.t(),

    bodyPadding: 10,

    items: [{
        xtype: 'fieldset',
        title: 'Outgoing Email Server'.t(),
        items: [{
            xtype: 'component',
            padding: 10,
            bind:{
                html: Ext.String.format('The Outgoing Email Server settings determine how the {0} Server sends emails such as reports, quarantine digests, etc. In most cases the cloud hosted mail relay server is preferred. Alternatively, you can configure mail to be sent directly to mail account servers. You can also specify a valid SMTP server that will relay mail for the {0} Server.'.t(), '{companyName}')
            }
        }, {
            xtype: 'radiogroup',
            margin: '0 0 10 10',
            simpleValue: true,
            bind: '{mailSender.sendMethod}',
            columns: 1,
            vertical: true,
            items: [
                { boxLabel: '<strong>' + 'Send email directly'.t() + '</strong>', inputValue: 'DIRECT' },
                { boxLabel: '<strong>' + 'Send email using the specified SMTP Server'.t() + '</strong>', inputValue: 'CUSTOM' }
            ]
        }, {
            xtype: 'fieldset',
            border: false,
            defaults: {
                labelWidth: 200,
                labelAlign: 'right'
            },
            disabled: true,
            bind: {
                disabled: '{mailSender.sendMethod !== "CUSTOM"}'
            },
            items: [{
                xtype: 'textfield',
                fieldLabel: 'Server Address or Hostname'.t(),
                bind: '{mailSender.smtpHost}',
                allowBlank: false,
                vtype: 'hostName',
            }, {
                xtype: 'textfield',
                width: 260,
                fieldLabel: 'Server Port'.t(),
                bind: '{mailSender.smtpPort}',
                vtype: 'port'
            }, {
                xtype: 'component',
                margin: '0 0 0 200',
                padding: 5,
                html: '<i class="fa fa-exclamation-triangle" style="color: red;"></i> ' + 'Warning:'.t() + ' ' + 'SMTPS (465) is deprecated and not supported. Use STARTTLS (587).'.t(),
                hidden: true,
                bind: {
                    hidden: '{mailSender.smtpPort !== "465"}'
                }
            }, {
                xtype: 'checkbox',
                fieldLabel: 'Use Authentication'.t(),
                reference: 'cb',
                bind: '{mailSender.sendMethod == "CUSTOM" && mailSender.authUser !== null}'
            }, {
                xtype: 'textfield',
                fieldLabel: 'Login'.t(),
                hidden: true,
                bind: {
                    value: '{mailSender.authUser}',
                    hidden: '{!cb.checked}'
                }
            }, {
                xtype: 'textfield',
                inputType: 'password',
                fieldLabel: 'Password'.t(),
                hidden: true,
                bind: {
                    value: '{mailSender.authPass}',
                    hidden: '{!cb.checked}'
                }
            }]
        } ]
    }, {
        xtype: 'fieldset',
        title: 'Email From Address'.t(),
        padding: 10,
        items: [{
            xtype: 'textfield',
            bind:{
                value: '{mailSender.fromAddress}',
                fieldLabel: Ext.String.format('The {0} Server will send email from this address.'.t(), '{companyName}'),
            },
            labelAlign: 'top',
            emptyText: '[enter email]'.t(),
            vtype: 'email',
            allowBlank: false,
            name: 'FromAddress',
        }]
    }, {
        xtype: 'fieldset',
        title: 'Email Test'.t(),
        padding: 10,
        items: [{
            xtype: 'component',
            html: 'The Email Test will send an email to a specified address with the current configuration. If the test email is not received your settings may be incorrect.'.t()
        }, {
            xtype: 'button',
            margin: '10 0 0 0',
            text: 'Email Test'.t(),
            handler: 'testEmail'
        }]
    }]

});
Ext.define('Ung.config.email.view.Quarantine', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-email-quarantine',
    itemId: 'quarantine',
    scrollable: true,
    withValidation: true,
    title: 'Quarantine'.t(),

    viewModel: {
        formulas: {
            maxHoldTime: {
                get: function (get) { return get('smtpSettings.quarantineSettings.maxMailIntern') / (1440*60*1000); },
                set: function (value) { this.set('smtpSettings.quarantineSettings.maxMailIntern', value * (1440*60*1000)); }
            },
            digestHour: {
                get: function (get) {
                    var date = new Date();
                    date.setHours(get('smtpSettings.quarantineSettings.digestHourOfDay'));
                    date.setMinutes(get('smtpSettings.quarantineSettings.digestMinuteOfDay'));
                    return date;
                },
                set: function (value) {
                    this.set('smtpSettings.quarantineSettings.digestHourOfDay', value.getHours());
                    this.set('smtpSettings.quarantineSettings.digestMinuteOfDay', value.getMinutes());
                }
            },
            quarantineTotalDisk: function (get) {
                return Ext.String.format('Total Disk Space Used: {0}'.t(), Renderer.datasize(get('inboxesTotalSize')));
            }
        },
        stores: {
            qInboxes: { data: '{inboxesList.list}' },
            qAddresses: { data: '{smtpSettings.quarantineSettings.allowedAddressPatterns.list}' },
            qForwards: { data: '{smtpSettings.quarantineSettings.addressRemaps.list}' }
        }
    },

    layout: 'border',

    items: [{
        region: 'center',
        border: false,
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'form',
            bodyPadding: 20,
            defaults: {
                labelWidth: 250
            },
            items: [{
                xtype: 'numberfield',
                fieldLabel: 'Maximum Holding Time (days)'.t(),
                allowBlank: false,
                minValue: 0,
                maxValue: 99,
                regex: /^([0-9]|[0-9][0-9])$/,
                regexText: 'Maximum Holding Time must be a number in range 0-99'.t(),
                bind: '{maxHoldTime}'
            }, {
                xtype: 'checkbox',
                fieldLabel: 'Send Daily Quarantine Digest Emails'.t(),
                bind: '{smtpSettings.quarantineSettings.sendDailyDigests}'
            }, {
                xtype: 'timefield',
                fieldLabel: 'Quarantine Digest Sending Time'.t(),
                allowBlank: false,
                editable: false,
                increment: 30,
                disabled: true,
                bind: {
                    value: '{digestHour}',
                    disabled: '{smtpSettings.quarantineSettings.sendDailyDigests == false}'
                }
            }, {
                xtype: 'component',
                margin: '10 0 0 0',
                html: Ext.String.format('Users can also request Quarantine Digest Emails manually at this link: <b>https://{0}/quarantine/</b>'.t(), Rpc.directData('rpc.networkManager.getPublicUrl'))
            }]
        }, {
            xtype: 'ungrid',
            reference: 'inboxesGrid',
            title: 'User Quarantines'.t(),
            flex: 1,

            emptyText: 'No User Quarantines defined'.t(),

            selModel: {
                selType: 'checkboxmodel'
            },

            bind: '{qInboxes}',

            tbar: [{
                text: 'Purge Selected'.t(),
                iconCls: 'fa fa-circle fa-red',
                handler: 'externalAction',
                action: 'purgeInboxes',
                disabled: true,
                bind: {
                    disabled: '{!inboxesGrid.selection}'
                }
            }, {
                text: 'Release Selected'.t(),
                iconCls: 'fa fa-circle fa-green',
                handler: 'externalAction',
                action: 'releaseInboxes',
                disabled: true,
                bind: {
                    disabled: '{!inboxesGrid.selection}'
                }
            }, '->', {
                xtype: 'tbtext',
                bind: {
                    text: '{quarantineTotalDisk}'
                }
            }],
            columns: [{
                header: 'Account Address'.t(),
                dataIndex: 'address',
                width: Renderer.emailWidth,
                flex: 1
            }, {
                header: 'Message Count'.t(),
                width: Renderer.messageWidth,
                align: 'right',
                dataIndex: 'totalMails'
            }, {
                header: 'Data Size'.t(),
                width: Renderer.sizeWidth,
                align: 'right',
                renderer: Renderer.datasize,
                dataIndex: 'totalSz',
            }, {
                xtype: 'actioncolumn',
                width: Renderer.actionWidth,
                menuDisabled: true,
                align: 'center',
                header: 'Detail'.t(),
                iconCls: 'fa fa-envelope',
                handler: 'externalAction',
                action: 'showQuarantineDetails'
            }]
        }]
    }, {
        region: 'east',
        width: '40%',
        split: true,
        border: false,
        layout: 'border',

        items: [{
            region: 'center',
            title: 'Quarantinable Addresses'.t(),

            dockedItems: [{
                xtype: 'component',
                padding: 10,
                style: {
                    fontSize: '11px'
                },
                html: 'Email addresses on this list will have quarantines automatically created. All other emails will be marked and not quarantined.'.t(),
                dock: 'top'
            }],

            layout: 'fit',

            items: [{
                xtype: 'ungrid',
                border: false,
                emptyText: 'No Quarantinable Addresses defined'.t(),

                bind: '{qAddresses}',

                tbar: ['@addInline', '->', '@import', '@export'],
                recordActions: ['delete'],
                listProperty: 'smtpSettings.quarantineSettings.allowedAddressPatterns.list',
                emptyRow: {
                    javaClass: 'com.untangle.app.smtp.EmailAddressRule',
                    address: ''
                },

                importValidationJavaClass: true,

                columns: [{
                    header: 'Quarantinable Address'.t(),
                    flex: 1,
                    width: Renderer.emailWidth,
                    dataIndex: 'address',
                    editor: {
                        xtype: 'textfield',
                        emptyText: '[enter email address rule]'.t(),
                        allowBlank: false,
                        vtype: 'emailwildcard'
                    }
                }],
            }]
        }, {
            region: 'south',
            height: '50%',
            split: true,
            title: 'Quarantine Forwards'.t(),

            dockedItems: [{
                xtype: 'component',
                padding: 10,
                style: {
                    fontSize: '11px'
                },
                html: 'This is a list of email addresses whose quarantine digest gets forwarded to another account. This is common for distribution lists where the whole list should not receive the digest.'.t(),
                dock: 'top'
            }],

            layout: 'fit',

            items: [{
                xtype: 'ungrid',
                border: false,

                emptyText: 'No Quarantine Forwards defined'.t(),
                bind: '{qForwards}',

                importValidationJavaClass: true,

                tbar: ['@addInline', '->', '@import', '@export'],
                recordActions: ['delete'],

                listProperty: 'smtpSettings.quarantineSettings.addressRemaps.list',
                emptyRow: {
                    javaClass: 'com.untangle.app.smtp.EmailAddressPairRule',
                    address1: '',
                    address2: '',
                },

                columns: [{
                    header: 'Distribution List Address'.t(),
                    dataIndex: 'address1',
                    width: Renderer.emailWidth,
                    editor: {
                        xtype: 'textfield',
                        emptyText: 'distributionlistrecipient@example.com'.t(),
                        vtype: 'email',
                        allowBlank: false
                    }
                }, {
                    header: 'Send to Address'.t(),
                    dataIndex: 'address2',
                    width: Renderer.emailWidth,
                    flex: 1,
                    editor: {
                        xtype: 'textfield',
                        emptyText: 'quarantinelistowner@example.com'.t(),
                        vtype: 'email',
                        allowBlank: false
                    }
                }]
            }]
        }]
    }]

});
Ext.define('Ung.config.email.view.SafeList', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-email-safelist',
    itemId: 'safe-list',
    scrollable: true,
    withValidation: false,
    title: 'Safe List'.t(),

    viewModel: {
        formulas: {
            globalSafeListMap: function (get) {
                if (get('globalSafeList')) {
                    return Ext.Array.map(get('globalSafeList'), function (email) {
                        return { emailAddress: email };
                    });
                }
                return {};
            }
        },
        stores: {
            globalSL: { data: '{globalSafeListMap}' },
            userSL: { data: '{userSafeList.list}' }
        }
    },

    layout: 'border',

    items: [{
        xtype: 'ungrid',
        itemId: 'safeListStore',
        region: 'center',
        title: 'Global Safe List'.t(),

        emptyText: 'No Global Safe List email addresses defined'.t(),

        bind: '{globalSL}',

        tbar: ['@addInline', '->', '@import', '@export'],
        recordActions: ['delete'],
        emptyRow: {
        },

        importValidationJavaClass: true,

        topInsert: true,

        columns: [{
            header: 'Email Address'.t(),
            dataIndex: 'emailAddress',
            width: Renderer.emailWidth,
            flex: 1,
            editor: {
                xtype: 'textfield',
                allowBlank: false,
                bind: '{record.emailAddress}',
                emptyText: '[enter email]'.t(),
                // vtype: 'email'
            },
            renderer: function (value) {
                if (!value || value.length === 0) {
                    return '<span style="color: red;">[add email address here]'.t() + '</span>';
                }
                return value;
            }
        }]
    }, {
        xtype: 'ungrid',
        reference: 'userSafeListGrid',
        region: 'east',

        width: '50%',
        split: true,

        title: 'Per User Safe Lists'.t(),

        emptyText: 'No Per User Safe List email addresses defined'.t(),

        selModel: {
            selType: 'checkboxmodel'
        },

        bind: '{userSL}',

        tbar: [{
            text: 'Purge Selected'.t(),
            iconCls: 'fa fa-circle fa-red',
            handler: 'externalAction',
            action: 'purgeUserSafeList',
            disabled: true,
            bind: {
                disabled: '{!userSafeListGrid.selection}'
            }
        }],

        columns: [{
            header: 'Account Address'.t(),
            dataIndex: 'emailAddress',
            width: Renderer.emailWidth,
            flex: 1
        }, {
            header: 'Safe List Size'.t(),
            width: Renderer.messageWidth,
            dataIndex: 'count'
        // }, {
        //     // todo: the show detail when available data
        //     header: 'Show Detail'.t(),
        //     width: Renderer.actionWidth + 20,
        }],
    }]

});
