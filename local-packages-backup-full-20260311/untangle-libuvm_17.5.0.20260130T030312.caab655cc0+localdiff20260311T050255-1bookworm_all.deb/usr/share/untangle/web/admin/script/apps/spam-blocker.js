Ext.define('Ung.apps.spamblocker.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-spam-blocker',
    controller: 'app-spam-blocker',

    items: [
        { xtype: 'app-spam-blocker-status' },
        { xtype: 'app-spam-blocker-email' }
    ]
});
Ext.define('Ung.apps.spamblocker.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-spam-blocker',

    control: {
        '#': {
            afterrender: 'getSettings',
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise(v.appManager, 'getLastUpdateCheck'),
            Rpc.asyncPromise(v.appManager, 'getLastUpdate')
        ]).then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set({
                settings: result[0],
                lastUpdateCheck: result[1].time ? Renderer.timestamp(result[1].time) : 'Never'.t(),
                lastUpdate: result[2].time ? Renderer.timestamp(result[2].time) : 'Never'.t()
            });

            v.lookup('predefinedStrength').setValue(result[0].smtpConfig.strength);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setStrength: function (combo, newValue, oldValue) {
        var me = this, vm = this.getViewModel();
        if (!Ext.Array.contains([30, 33, 35, 43, 50], newValue)) {
            me.lookup('predefinedStrength').setValue(0);
            vm.set('strength', oldValue/10);
        } else {
            vm.set('settings.smtpConfig.strength', newValue);
        }
    }


});
Ext.define('Ung.apps.spamblocker.view.Email', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-spam-blocker-email',
    itemId: 'email',
    title: 'Email'.t(),
    scrollable: true,
    withValidation: true,
    viewModel: {
        formulas: {
            strength: {
                get: function (get) {
                    return (get('settings.smtpConfig.strength') / 10).toFixed(1);
                },
                set: function (value) {
                    this.set('settings.smtpConfig.strength', Math.round(value * 10));
                }
            },
            superSpamStrength: {
                get: function (get) {
                    return get('settings.smtpConfig.superSpamStrength') / 10;
                },
                set: function (value) {
                    this.set('settings.smtpConfig.superSpamStrength', Math.round(value * 10));
                }
            }
        }
    },

    tbar: [{
        xtype: 'checkbox',
        boxLabel: '<strong>' + 'Scan SMTP'.t() + '</strong>',
        bind: '{settings.smtpConfig.scan}',
        padding: 5
    }],

    layout: 'fit',

    items: [{
        xtype: 'container',
        padding: 10,
        disabled: true,
        scrollable: 'y',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        bind: {
            disabled: '{!settings.smtpConfig.scan}'
        },
        defaults: {
            margin: '5 0',
        },
        items: [{
            xtype: 'container',
            layout: { type: 'vbox' },
            items: [{
                xtype: 'container',
                margin: '0 0 10 0',
                layout: { type: 'hbox', align: 'middle' },
                items: [{
                    xtype: 'combo',
                    reference: 'predefinedStrength',
                    publishes: 'value',
                    editable: false,
                    fieldLabel: 'Strength'.t(),
                    width: 300,
                    store: [
                        [50, 'Low (Threshold: 5.0)'.t()],
                        [43, 'Medium (Threshold: 4.3)'.t()],
                        [35, 'High (Threshold: 3.5)'.t()],
                        [33, 'Very High (Threshold: 3.3)'.t()],
                        [30, 'Extreme (Threshold: 3.0)'.t()],
                        [0, 'Custom'.t()]
                    ],
                    queryMode: 'local',
                    listeners: {
                        change: 'setStrength'
                    }
                }, {
                    xtype: 'numberfield',
                    reference: 'customStrength',
                    margin: '0 10',
                    hidden: true,
                    bind: {
                        value: '{strength}',
                        hidden: '{predefinedStrength.value !== 0}'
                    },
                    width: 80,
                    allowDecimals: true,
                    allowBlank: false,
                    step: 0.1,
                    minValue: -2147483648,
                    maxValue: 2147483647
                }, {
                    xtype: 'component',
                    html: 'Strength Value must be a number. Smaller value is higher strength.'.t(),
                    hidden: true,
                    bind: {
                        hidden: '{predefinedStrength.value !== 0}'
                    }
                }]
            }, {
                xtype: 'combo',
                editable: false,
                store: [
                    ['MARK', 'Mark'.t()],
                    ['PASS', 'Pass'.t()],
                    ['DROP', 'Drop'.t()],
                    ['QUARANTINE', 'Quarantine'.t()]
                ],
                // valueField: 'key',
                // displayField: 'name',
                fieldLabel: 'Action'.t(),
                width: 300,
                queryMode: 'local',
                bind: {
                    value: '{settings.smtpConfig.msgAction}'
                }
            }]
        }, {
            xtype: 'fieldset',
            title: 'Drop Super Spam'.t(),
            collapsible: true,
            collapsed: true,
            checkboxToggle: true,
            checkbox: {
                bind: '{settings.smtpConfig.blockSuperSpam}'
            },
            margin: '10 0',
            padding: 10,
            layout: {
                type: 'vbox'
            },
            items: [{
                xtype: 'numberfield',
                labelWidth: 150,
                fieldLabel: 'Super Spam Threshold'.t(),
                bind: '{superSpamStrength}',
                allowDecimals: false,
                allowBlank: false,
                minValue: 0,
                maxValue: 2147483647
            }]
        }, {
            xtype: 'fieldset',
            title: 'Advanced SMTP Configuration'.t(),
            collapsible: true,
            collapsed: true,
            padding: 10,
            layout: {
                type: 'vbox'
            },
            defaults: {
                xtype: 'checkbox'
            },
            items: [{
                boxLabel: 'Enable tarpitting'.t(),
                bind: '{settings.smtpConfig.tarpit}'
            }, {
                boxLabel: 'Enable greylisting'.t(),
                bind: '{settings.smtpConfig.greylist}'
            }, {
                boxLabel: 'Add email headers'.t(),
                bind: '{settings.smtpConfig.addSpamHeaders}'
            }, {
                boxLabel: 'Close connection on scan failure'.t(),
                bind: '{settings.smtpConfig.failClosed}'
            }, {
                boxLabel: 'Scan outbound (WAN) SMTP'.t(),
                bind: '{settings.smtpConfig.scanWanMail}'
            }, {
                boxLabel: 'Allow and ignore TLS sessions'.t(),
                bind: '{settings.smtpConfig.allowTls}'
            }, {
                xtype: 'numberfield',
                fieldLabel: 'CPU Load Limit'.t(),
                labelWidth: 150,
                bind: '{settings.smtpConfig.loadLimit}',
                allowDecimals: true,
                allowBlank: false,
                blankText: 'Value must be a float.'.t(),
                minValue: 0,
                maxValue: 50
            }, {
                xtype: 'numberfield',
                fieldLabel: 'Concurrent Scan Limit'.t(),
                labelWidth: 150,
                bind: '{settings.smtpConfig.scanLimit}',
                allowDecimals: false,
                allowBlank: false,
                blankText: 'Value must be a integer.'.t(),
                minValue: 0,
                maxValue: 100
            }, {
                xtype: 'numberfield',
                fieldLabel: 'Message Size Limit'.t(),
                labelWidth: 150,
                bind: '{settings.smtpConfig.msgSizeLimit}',
                allowDecimals: false,
                allowBlank: false,
                blankText: 'Value must be a integer.'.t(),
                minValue: 0,
                maxValue: 2147483647
            }]
        }]
    }]

});
Ext.define('Ung.apps.spamblocker.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-spam-blocker-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/spam-blocker.svg" width="80" height="80"/>' +
                '<h3>Spam Blocker</h3>' +
                '<p>' + 'Spam Blocker detects, blocks, and quarantines spam before it reaches users\' mailboxes.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        },{
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + "Updates".t(),
            defaults: {
                labelWidth: 200
            },
            padding: 10,
            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}',
            },

            items: [{
                xtype: 'displayfield',
                fieldLabel: "Last check for updates".t(),
                bind: '{lastUpdateCheck}'
            }, {
                xtype: 'displayfield',
                fieldLabel: "Last update".t(),
                bind: '{lastUpdate}'
            }, {
                xtype: 'component',
                bind:{
                    html: Ext.String.format("{0}Note:{1} {2} continues to maintain the default signature settings through automatic updates. You are free to modify and add signatures, however it is not required.".t(), '<b>', '</b>', '{companyName}')
                }
            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
