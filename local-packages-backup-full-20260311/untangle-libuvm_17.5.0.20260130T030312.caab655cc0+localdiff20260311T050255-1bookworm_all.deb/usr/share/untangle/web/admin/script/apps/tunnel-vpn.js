Ext.define('Ung.apps.tunnel-vpn.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-tunnel-vpn',
    controller: 'app-tunnel-vpn',

    viewModel: {
        data: {
            autoReload: false,
            tunnelProviderSelected: false,
            tunnelProviderTitle: '',
            tunnelProviderInstructions: '',
            tunnelUsernameHidden: true,
            tunnelPasswordHidden: true,
            tunnelStatusData: []
        },
        stores: {
            tunnels: {
                data: '{settings.tunnels.list}',
            },
            rules: {
                data: '{settings.rules.list}'
            },
            destinationTunnelList: {
                fields: [ 'index', 'name' ],
                data: '{destinationTunnelData}'
            },
            interfaceList: {
                fields: [ 'index', 'name' ],
                data: '{interfaceData}'
            },
            tunnelStatusList: {
                data: '{tunnelStatusData}',
                fields:[{
                    name: 'tunnelId',
                    sortType: 'asInt'
                }, {
                    name: 'tunnelName',
                }, {
                    name: 'elapsedTime',
                }, {
                    name: 'recvTotal',
                    sortType: 'asInt'
                }, {
                    name: 'xmitTotal',
                    sortType: 'asInt'
                }, {
                    name: 'stateInfo'
                }]
            }
        },
    },

    items: [
        { xtype: 'app-tunnel-vpn-status' },
        { xtype: 'app-tunnel-vpn-tunnels' },
        { xtype: 'app-tunnel-vpn-rules' },
        { xtype: 'app-tunnel-vpn-log' },
    ]

});
Ext.define('Ung.apps.tunnel-vpn.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-tunnel-vpn',

    control: {
        '#': {
            afterrender: 'getSettings'
        },
        '#status': {
            activate: 'getTunnelStatus'
        },
        '#log': {
            activate: 'getTunnelLog'
        },
    },

    getTunnelStatus: function () {
       var grid = this.getView().down('#tunnelStatus'),
            vm = this.getViewModel();

        grid.setLoading(true);
        Rpc.asyncData(this.getView().appManager, 'getTunnelStatusList')
        .then(function(result){
            grid.setLoading(false);
            if(Util.isDestroyed(vm)){
                return;
            }

            vm.set('tunnelStatusData', !result ? [] : result.list);

        }, function(ex) {
            Util.handleException(ex);
        });
    },

    recycleTunnel: function(view, row, colIndex, item, e, record) {
        var me = this, grid = this.getView().down('#tunnelStatus');

        grid.setLoading('Recycling...'.t());
        Rpc.asyncData(this.getView().appManager, 'recycleTunnel', record.get("tunnelId"))
        .then(function(result){
            setTimeout(function() {
                if(Util.isDestroyed(grid, me)){
                    return;
                }
                me.getTunnelStatus();
                grid.setLoading(false);
            },2000);

        }, function(ex) {
            if(Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getSettings: function () {
        var me = this,
            v = me.getView(),
            vm = me.getViewModel();

        v.setLoading(true);

        vm.set('providers',{
            NGFirewall: {
                description: 'NGFirewall'.t(),
                userAuth: false,
                providerTitle: 'Upload the NGFirewall OpenVPN config zip',
                providerInstructions: '<li>' + 'Log in the main NGFirewall server'.t() + '<br/>' +
                    '<li>' + 'Inside "OpenVPN" app settings in Server > Remote Clients add new client and hit Save'.t() + '<br/>' +
                    '<li>' + 'Click Download for the new client and download the configuration zip file for remote NGFirewall OpenVPN clients'.t() + '<br/>' +
                    '<li>' + 'Upload the zip file below'.t() + '<br/>'
            },
            NordVPN: {
                description: 'NordVPN'.t(),
                userAuth: true,
                providerTitle: 'Upload the NordVPN OpenVPN config zip'.t(),
                providerInstructions: '<li>' + 'Log in to "My account" at nordvpn.com'.t() + '<br/>' +
                    '<li>' + 'Click on the "Download area"'.t() + '<br/>' +
                    '<li>' + 'Download the Linux ".OVPN configuration files" zip'.t() + '<br/>' +
                    '<li>' + 'Choose an ovpn file for a server (in your region)'.t() + '<br/>' +
                    '<li>' + 'Upload the chosen ovpn file below'.t() + '<br/>' +
                    '<li>' + 'Provide the username/password of your NordVPN account'.t() + '<br/>'
            },
            ExpressVPN: {
                description: 'ExpressVPN'.t(),
                userAuth: true,
                providerTitle: 'Upload the ExpressVPN OpenVPN config zip'.t(),
                providerInstructions: '<li>' + 'Log in to "My account" at expressvpn.com'.t() + '<br/>' +
                    '<li>' + 'Click on "Set up ExpressVPN"'.t() + '<br/>' +
                    '<li>' + 'Click on "Manual Configuration" and choose "OpenVPN"'.t() + '<br/>' +
                    '<li>' + 'Provide the username/password provided by ExpressVPN'.t() + '<br/>' +
                    '<li>' + 'NOTE: This is not your ExpressVPN account username/password'.t() + '<br/>' +
                    '<li>' + 'Choose your server and download the corresponding .ovpn file'.t() + '<br/>' +
                    '<li>' + 'Upload the .ovpn file'.t() + '<br/>'
            },
            PrivateInternetAccess: {
                description: 'PrivateInternetAccess'.t(),
                userAuth: true,
                providerTitle: 'Upload the PrivateInternetAccess OpenVPN config ovpn file'.t(),
                providerInstructions: '<li>' + 'Download the appropriate ovpn file here from:'.t() + '<br/>' +
                    '<li>' + '<a href="https://www.privateinternetaccess.com/pages/openvpn-ios" target="_blank">https://www.privateinternetaccess.com/pages/openvpn-ios</a>' + '<br/>' +
                    '<li>' + 'Edit the .ovpn file and remove the &quot;crl-verify&quot; section'.t() + '<br/>' +
                    '<li>' + 'Upload the .ovpn file'.t() + '<br/>' +
                    '<li>' + 'Provide the username/password of your account'.t() + '<br/>'
            },
            CustomZip: {
                description: 'Custom zip file'.t(),
                userAuth: false,
                providerTitle: 'Upload the Custom OpenVPN config zip'.t(),
                providerInstructions: '<li>' + 'Upload the Custom OpenVPN Config .zip File'.t() + '<br/>'
            },
            CustomZipPass: {
                description: 'Custom zip file with username/password'.t(),
                userAuth: true,
                providerTitle: 'Upload the Custom OpenVPN config zip with username/password'.t(),
                providerInstructions: '<li>' + 'Upload the Custom OpenVPN Config .zip File'.t() + '<br/>' +
                    '<li>' + 'Provide the username/password'.t() + '<br/>'
            },
            CustomOvpn: {
                description: 'Custom ovpn file'.t(),
                userAuth: false,
                providerTitle: 'Upload the Custom OpenVPN .ovpn file'.t(),
                providerInstructions: '<li>' + 'Upload the Custom OpenVPN Config .ovpn File'.t() + '<br/>'
            },
            CustomOvpnPass: {
                description: 'Custom ovpn file with username/password'.t(),
                userAuth: true,
                providerTitle: 'Upload the Custom OpenVPN .ovpn file with username/password'.t(),
                providerInstructions: '<li>' + 'Upload the Custom OpenVPN Config .ovpn File'.t() + '<br/>' +
                    '<li>' + 'Provide the username/password'.t() + '<br/>'
            },
            CustomConf: {
                description: 'Custom conf file'.t(),
                userAuth: false,
                providerTitle: 'Upload the Custom OpenVPN .conf file'.t(),
                providerInstructions: '<li>' + 'Upload the Custom OpenVPN Config .conf File'.t() + '<br/>'
            },
            CustomConfPass: {
                description: 'Custom conf file with username/password'.t(),
                userAuth: true,
                providerTitle: 'Upload the Custom OpenVPN .conf file with username/password'.t(),
                providerInstructions: '<li>' + 'Upload the Custom OpenVPN Config .conf File'.t() + '<br/>' +
                    '<li>' + 'Provide the username/password'.t() + '<br/>'
            },
        });

        var providers = vm.get('providers');
        var providerComboListData = [['', 'Select'.t()]];

        for( var provider in providers ){
            providerComboListData.push([provider, providers[provider].description]);
        }

        vm.set('providersComboList', Ext.create('Ext.data.ArrayStore', {
            fields: [ 'name', 'description' ],
            data: providerComboListData
        }) );

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise('rpc.networkManager.getNetworkSettings')
        ])
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            var appSettings = result[0];
            var networkSettings = result[1];
            
            vm.set('settings', appSettings);
            var destinationTunnelData = [];
            destinationTunnelData.push([-1, 'Any Available Tunnel'.t()]);
            destinationTunnelData.push([0, 'Route Normally'.t()]);
            if ( appSettings.tunnels && appSettings.tunnels.list ) {
                for (var i = 0 ; i < appSettings.tunnels.list.length ; i++) {
                    var tunnel = appSettings.tunnels.list[i];
                    destinationTunnelData.push([tunnel.tunnelId, tunnel.name]);
                }
            }
            vm.set('destinationTunnelData', destinationTunnelData);

            var interfaceData = [];
            interfaceData.push([0, 'Any Interface'.t()]);
            var intf;
            for (var c = 0 ; c < networkSettings.interfaces.list.length ; c++) {
                intf = networkSettings.interfaces.list[c];
                var name = intf.name;
                var key = intf.interfaceId;
                // only allow addressed WANs (is there any use case for non-WANs? perhaps)
                if ( intf.configType == 'ADDRESSED' && intf.isWan) {
                    interfaceData.push( [ key, name ] );
                }
            }
            vm.set('interfaceData', interfaceData);
            
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (me.validateSettings() != true) return;
        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);
        var sequence = [
            Rpc.asyncPromise(v.appManager, 'setSettings', vm.get('settings') ),
        ];

        var validSave = true;
        var tunnelNamesToImport = [];
        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;

                var items = Ext.Array.pluck(store.getRange(), 'data');
                if(grid.listProperty == 'settings.tunnels.list'){
                    items.forEach(function(tunnel){
                        if( tunnel.tunnelId == -1 ){
                            var tunnelId = me.getNextAvailableTunnelId(items);
                            if( tunnelId === false){
                                validSave = false;
                                Util.handleException("Unable to obtain a unique tunnel id, cannot add tunnel".t() + ": " + tunnel.name);
                                return;
                            }
                            tunnel.tunnelId = tunnelId;
                        }
                        if(tunnel.tempPath){
                            tunnelNamesToImport.push(tunnel.name);
                            sequence.push( Rpc.asyncPromise(v.appManager, 'importTunnelConfig', tunnel.tempPath, tunnel.provider, tunnel.tunnelId));
                            delete tunnel.tempPath;
                        }
                    });
                }
                vm.set(grid.listProperty, items);
            }
        });

        if( validSave == false ){
            return;
        }

        v.setLoading(true);
        Ext.Deferred.sequence(sequence)
        .then(function(result){
            if(Util.isDestroyed(v, vm, tunnelNamesToImport, sequence)){
                return;
            }

            Util.successToast('Settings saved');

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            result.shift();
            result.forEach(function(result, index){
                Util.successToast('Configuration imported'.t() + ': ' + tunnelNamesToImport[index]);
            });

            me.getSettings();

            if(sequence.length > 1){
                // Added one or more tunnels but not powered on.
                if( !vm.get('state.on')){
                    v.down('appstate').down('button').click();
                }
            }
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getNextAvailableTunnelId: function(current){
        var found = false;
        var tunnel;
        var vm = this.getViewModel();
        var tunnels = vm.get('settings.tunnels.list');
        var virtualInterfaces = Rpc.directData('rpc.networkManager.getNetworkSettings.virtualInterfaces.list');

        for( var i = 200; i < 240; i++ ){
            found = false;
            for(tunnel in tunnels){
                if ( tunnel.tunnelId != null && i == tunnel.tunnelId ) {
                    found = true;
                    break;
                }
            }
            if(current){
                current.forEach( function(tunnel){
                    if ( tunnel.tunnelId != null && i == tunnel.tunnelId ) {
                        found = true;
                        return;
                    }
                });
            }

            if(virtualInterfaces){
                virtualInterfaces.forEach( function( intf ){
                    if( i == intf.interfaceId){
                        found = true;
                        return;
                    }
                });
            }

            if (!found) {
                return i;
            }
        }
        return false;
    },

    validateSettings: function() {
        return(true);
    },

    getTunnelLog: function(cmp)
    {
        var appPanel = cmp.up('apppanel');
        Rpc.asyncData( appPanel.appManager, 'getLogFile')
        .then(function(result){
            if(Util.isDestroyed(appPanel)){
                return;
            }
            appPanel.down('#tunnelLog').setValue(result);
        }, function(ex){
            Util.handleException(ex);
        });
    },

    statics: {
        tunnelidRenderer: function(value){
            if(value == -1){
                return 'New'.t();
            }
            return 'tun' + value;
        }
    }
});

Ext.define('Ung.apps.tunnel-vpn.TunnelGridController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.untunnelgrid',

    deleteRecord: function (view, rowIndex, colIndex, item, e, record) {
        var me = this,
            vm = me.getViewModel();

        var rulesInUse = [];
        var recordTunnelId = record.get('tunnelId');
        var rules = vm.get('rules');
        rules.each( function(rule){
            if( ( recordTunnelId != -1 ) && ( recordTunnelId == rule.get('tunnelId') ) ){
                rulesInUse.push( rule.get('description') );
            }
        });

        if(rulesInUse.length > 0){
            Util.handleException('Cannot delete tunnel.  It is used by one or more rules'.t() + ': ' + rulesInUse.join(','));
        }else{
            this.callParent(arguments);
        }
    },

    checkauth: function( e, editor){
        var vm = this.getViewModel();

        var providers = vm.get('providers');
        return providers[editor.record.get('provider')].userAuth;
    }

 });

Ext.define('Ung.apps.tunnel-vpn.TunnelRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.untunnelrecordeditor',

    controller: 'untunnelrecordeditorcontroller',

});

Ext.define('Ung.apps.tunnel-vpn.TunnelRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.untunnelrecordeditorcontroller',

    uploadFile: function(cmp) {
        var me = this,
            vm = me.getViewModel(),
            component = cmp;

        var form = Ext.ComponentQuery.query('form[name=upload_form]')[0];
        Ext.MessageBox.wait('Uploading and validating...'.t(), 'Please wait'.t());

        component.setValidation(true);

        form.submit({
            url: "upload",
            success: Ext.bind(function( form, action ) {
                Ext.MessageBox.hide();
                if(Util.isDestroyed(vm)){
                    return;
                }
                var resultMsg = action.result.msg.split('&');
                vm.set('fileResult', resultMsg[1]);
                vm.set('record.tempPath', resultMsg[0]);
            }, this),
            failure: Ext.bind(function( form, action ) {
                Ext.MessageBox.hide();
                if(Util.isDestroyed(component, vm)){
                    return;
                }
                vm.set('fileResult', action.result.msg);
                component.setValidation('Must upload valid VPN config file'.t());
            }, this)
        });
    },
    providerChange: function(combo, newValue, oldValue){
        var me = this,
            vm = me.getViewModel();

        vm.set('fileResult', '');
        if( newValue == ''){
            vm.set('tunnelProviderSelected', false);
            vm.set('tunnelProviderTitle', '');
            vm.set('tunnelProviderInstructions', '');
            combo.setValidation('Provider must be selected');
        }else{
            vm.set('tunnelProviderSelected', true);

            var fileButton = Ext.ComponentQuery.query('[name=upload_file]')[0];
            if(vm.get('record.tunnelId') != -1){
                fileButton.setValidation(true);
            }

            var record = vm.get('record');
            if( ( oldValue != null ) &&
                ( newValue != oldValue ) &&
                ( record.modified && (( typeof record.modified.provider == undefined ) || record.modified.provider != newValue )) ){
                fileButton.setValidation('Provider changed');
            }

            combo.setValidation(true);

            var providers = vm.get('providers');
            for( var provider in providers ){
                if(provider == newValue){
                    vm.set('tunnelProviderTitle', providers[provider].providerTitle);
                    vm.set('tunnelProviderInstructions', providers[provider].providerInstructions);

                    if(providers[provider].userAuth == true){
                        vm.set('tunnelUsernameHidden', false);
                        vm.set('tunnelPasswordHidden', false);
                    }else{
                        vm.set('tunnelUsernameHidden', true);
                        vm.set('tunnelPasswordHidden', true);
                    }
                }
            }
        }
        me.updateTunnelName();
    },

    defaultTunnelName: 'tunnel',

    updateTunnelName: function() {
        var me = this,
            v = me.getView(),
            tunnelName = v.down('[name=tunnelName]'),
            providerValue = v.down('[name=provider]').getValue();

        var newDefaultTunnelName = 'tunnel';
        if( providerValue != '' ){
            newDefaultTunnelName += '-' + providerValue;
        }
        if(tunnelName.getValue() == me.defaultTunnelName){
            tunnelName.setValue(newDefaultTunnelName);
        }
        me.defaultTunnelName = newDefaultTunnelName;
    }
});
Ext.define('Ung.apps.ipsecvpn.view.Log', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-tunnel-vpn-log',
    itemId: 'log',
    title: 'Log'.t(),
    layout: 'fit',
    scrollable: true,
    withValidation: true,
    tbar: [{
        xtype: 'button',
        iconCls: 'fa fa-refresh',
        text: 'Refresh',
        target: 'tunnelLog',
        handler: 'getTunnelLog'
    }],

    items: [{
        xtype: 'textarea',
        readOnly: true,
        itemId: 'tunnelLog',
        spellcheck: false,
        padding: 0,
        border: false,
        bind: '{tunnelLog}',
        fieldStyle: {
            'fontFamily'   : 'courier new',
            'fontSize'     : '12px'
        }
    }]
});
Ext.define('Ung.apps.tunnel-vpn.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-tunnel-vpn-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    viewModel: true,
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Rules determine which sessions will use a tunnel VPN connections. Rules are evaluated in order and the action from the first matching rule is used to route the matching session.<BR>'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    emptyText: 'No Rules defined'.t(),
    
    importValidationJavaClass: true,

    importValidationForComboBox: true,

    listProperty: 'settings.rules.list',

    emptyRow: {
        ruleId: 0,
        enabled: true,
        description: '',
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.tunnel_vpn.TunnelVpnRule',
        tunnelId: 0
    },

    bind: '{rules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions, {
            header: 'Destination Tunnel'.t(),
            dataIndex: 'tunnelId',
            width: Renderer.messageWidth,
            flex: 1,
            renderer: function(value, meta, record, row, col, store, grid) {
                var tunnellist = this.getViewModel().get('destinationTunnelList');
                var dstname = 'Unknown'.t();
                tunnellist.each(function(record) { if (record.get('index') == value) dstname = record.get('name'); });
                return(dstname);
            }
        }
    ],

    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.tunnel_vpn.TunnelVpnRuleCondition', [
            "DST_ADDR",
            "DST_PORT",
            "SRC_ADDR",
            "SRC_PORT",
            "SRC_INTF",
            "PROTOCOL",
            "CLIENT_TAGGED",
            "SERVER_TAGGED"
        ]), {
            xtype: 'combo',
            fieldLabel: 'Destination Tunnel'.t(),
            bind: {
                value: '{record.tunnelId}',
                store: '{destinationTunnelList}'
            },
            allowBlank: false,
            editable: false,
            queryMode: 'local',
            displayField: 'name',
            valueField: 'index'
        }
    ]

});
Ext.define('Ung.apps.tunnel-vpn.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-tunnel-vpn-status',
    itemId: 'status',
    title: 'Status'.t(),
    viewModel: true,
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/tunnel-vpn.svg" width="80" height="80"/>' +
                '<h3>Tunnel VPN</h3>' +
                '<p>' + 'Tunnel VPN provides connectivity through encrypted tunnels to remote VPN servers and services.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'Tunnel Status'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'ungrid',
                itemId: 'tunnelStatus',
                enableColumnHide: true,
                stateful: true,
                trackMouseOver: false,
                resizable: true,
                defaultSortable: true,

                flex: 1,

                emptyText: 'No Tunnels defined'.t(),

                bind: {
                    store: '{tunnelStatusList}'
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'Tunnel ID'.t(),
                    dataIndex: 'tunnelId',
                    sortable: true,
                    width: Renderer.idWidth
                }, {
                    header: 'Tunnel Name'.t(),
                    dataIndex: 'tunnelName',
                    sortable: true,
                    width: Renderer.messageWidth,
                    flex: 1
                }, {
                    header: 'Elapsed Time'.t(),
                    dataIndex: 'elapsedTime',
                    sortable: true,
                    width: Renderer.messageWidth,
                    renderer: function(value) {
                        var total = parseInt(value / 1000,10);
                        var hours = (parseInt(total / 3600,10) % 24);
                        var minutes = (parseInt(total / 60,10) % 60);
                        var seconds = parseInt(total % 60,10);
                        var result = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);
                        return result;
                    }
                }, {
                    header: 'Rx Data'.t(),
                    dataIndex: 'recvTotal',
                    sortable: true,
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize,
                    filter: Renderer.numericFilter
                }, {
                    header: 'Tx Data'.t(),
                    dataIndex: 'xmitTotal',
                    sortable: true,
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize,
                    filter: Renderer.numericFilter
                }, {
                    header: 'Tunnel Status'.t(),
                    sortable: true,
                    dataIndex: 'stateInfo',
                    width: Renderer.messageWidth
                }, {
                    header: 'Recycle'.t(),
                    xtype: 'actioncolumn',
                    width: Renderer.actionWidth,
                    align: 'center',
                    iconCls: 'fa fa-recycle',
                    handler: 'externalAction',
                    action: 'recycleTunnel',
                }],
                bbar: [ '@refresh', '@reset']
            }]
        },{
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        layout: 'fit',
        items: [{
            xtype: 'appmetrics',
            scrollable: true,
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
Ext.define('Ung.apps.tunnel-vpn.view.Tunnels', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-tunnel-vpn-tunnels',
    itemId: 'tunnels',
    title: 'Tunnels'.t(),
    viewModel: true,
    withValidation: false,
    controller: 'untunnelgrid',
    editorXtype: 'ung.cmp.untunnelrecordeditor',

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Configure Tunnel VPN tunnels (connections) to remote VPN services'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add']
    }],

    plugins: [{
        ptype: 'cellediting',
        clicksToEdit: 1,
        listeners: {
            beforeedit: 'checkauth'
        }
    }, {
        ptype: 'responsive'
    }],

    emptyText: 'No Tunnels defined'.t(),

    recordActions: ['edit', 'delete'],
    listProperty: 'settings.tunnels.list',

    bind: '{tunnels}',

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.idWidth,
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Tunnel ID'.t(),
        width: Renderer.idWidth,
        dataIndex: 'tunnelId',
        renderer: Ung.apps['tunnel-vpn'].MainController.tunnelidRenderer
    }, {
        header: 'Tunnel Name'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'name',
        editor: {
            xtype: 'textfield',
            bind: '{record.name}'
        }
    }, {
        header: 'Provider'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'provider',
    }, {
        header: 'Username'.t(),
        width: Renderer.usernameWidth,
        dataIndex: 'username',
        editor: {
            xtype: 'textfield',
            bind: '{record.username}',
            listeners: {
                beforeedit: 'checkauth'
            }
        }
    }],

    emptyRow: {
        enabled: true,
        name: 'tunnel',
        provider: '',
        javaClass: 'com.untangle.app.tunnel_vpn.TunnelVpnTunnelSettings',
        tunnelId: -1,
        nat: true,
        boundInterfaceId: 0
    },

    editorFields: [
        Field.enableRule(),
    {
        xtype: 'textfield',
        fieldLabel: 'Tunnel Name'.t(),
        name: 'tunnelName',
        bind: '{record.name}'
    },{
        xtype: 'hidden',
        name: 'tunnelId',
        bind: '{record.tunnelId}'
    }, {
        xtype: 'combo',
        name: 'provider',
        fieldLabel: 'Provider'.t(),
        editable: false,
        valueField: 'name',
        displayField: 'description',
        bind: {
            value: '{record.provider}',
            store: '{providersComboList}'
        },
        listeners: {
            change: 'providerChange'
        }
    },{
        xtype: 'component',
        margin: '0 10 0 190',
        bind: {
            html: '{tunnelProviderTitle}'
        }
    },{
        xtype: 'component',
        margin: '0 10 0 190',
        bind: {
            html: '{tunnelProviderInstructions}'
        }
    },{
        xtype: 'form',
        name: 'upload_form',
        border: false,
        margin: '10 10 0 170',
        items: [{
            xtype: 'container',
            layout: 'hbox',
            items: [{
                xtype: 'filefield',
                label: 'Upload Config File'.t(),
                name: 'upload_file',
                buttonText: 'Select VPN Config File'.t(),
                buttonOnly: true,
                margin: '10 0 10 0',
                listeners: {
                    change: 'uploadFile'
                },
                bind: {
                    disabled: '{tunnelProviderSelected == false}'
                },
                validation: 'Must upload VPN config file'.t()
            },{
                xtype: 'label',
                margin: '5 0 0 0',
                bind: {
                    text: '{fileResult}',
                    disabled: '{tunnelProviderSelected == false}'
                }
            }]
        },{
            xtype: 'hidden',
            name: 'type',
            value: 'tunnel_vpn'
        },{
            xtype: 'hidden',
            name: 'argument',
            bind: {
                value: '{record.provider}',
            },
        }]
    }, {
        xtype: 'textfield',
        fieldLabel: 'Username'.t(),
        allowBlank: false,
        bind: {
            value: '{record.username}',
            disabled: '{tunnelUsernameHidden == true}',
            hidden: '{tunnelProviderSelected == false}'
        },
        regex: /^(?!\s).*[^\s]$/,
        regexText: 'Invalid Username, whitespaces at beginning or end are not allowed'.t()
    }, {
        xtype: 'textfield',
        fieldLabel: 'Password'.t(),
        inputType: 'password',
        allowOnlyWhitespace: false,
        bind: {
            value: '{record.password}',
            disabled: '{tunnelUsernameHidden == true}',
            hidden: '{tunnelProviderSelected == false}'
        },
        listeners: {
            afterrender: function() {
                var me = this,
                vm = me.up('window').getViewModel(),
                record = vm.get('record');
                if(record && !record.get('password') && record.get('encryptedTunnelVpnPassword')){
                    me.setValue(Util.getDecryptedPassword(record.get('encryptedTunnelVpnPassword')));
                }
            }
        },
    }, {
        xtype: 'fieldset',
        margin: '0 10 0 190',
        title: 'Advanced'.t(),
        collapsible: true,
        collapsed: true,
        padding: 10,
        layout: {
            type: 'vbox'
        },
        defaults: {
            xtype: 'checkbox'
        },
        items: [{
            xtype: 'checkbox',
            labelWidth: '100%',
            fieldLabel: 'NAT traffic exiting this tunnel'.t(),
            bind: {
                value: '{record.nat}'
            }
        }, {
            xtype: 'combo',
            fieldLabel: 'Interface'.t(),
            bind: {
                value: '{record.boundInterfaceId}',
                store: '{interfaceList}'
            },
            allowBlank: false,
            editable: false,
            queryMode: 'local',
            displayField: 'name',
            valueField: 'index'
        }]
    }]

});
