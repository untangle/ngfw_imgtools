Ext.define('Ung.apps.webfilter.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-web-filter',
    controller: 'app-web-filter',

    viewModel: {
        stores: {
            categories: {
                data: '{settings.categories.list}',
                groupField: 'category'
            },
            categoriesNames: {
                data: '{settings.categories.list}',
                sorters: [{
                    property: 'name',
                    direction: 'ASC'
                }],
            },
            searchTerms:   { data: '{settings.searchTerms.list}' },
            blockedUrls:   { data: '{settings.blockedUrls.list}' },
            passedUrls:    { data: '{settings.passedUrls.list}' },
            passedClients: { data: '{settings.passedClients.list}' },
            filterRules:   { data: '{settings.filterRules.list}' }
        },
        data: {
            isAddAction: false 
        }
    },

    items: [
        { xtype: 'app-web-filter-status' },
        { xtype: 'app-web-filter-categories' },
        { xtype: 'app-web-filter-searchterms' },
        { xtype: 'app-web-filter-sitelookup' },
        { xtype: 'app-web-filter-blocksites' },
        { xtype: 'app-web-filter-passsites' },
        { xtype: 'app-web-filter-passclients' },
        { xtype: 'app-web-filter-rules' },
        { xtype: 'app-web-filter-advanced' }
    ]

});
Ext.define('Ung.apps.webfilter.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-web-filter',

    control: {
        '#': {
            afterrender: 'getSettings',
        },
        '#site-lookup': {
            afterrender: 'initSiteLookup'
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        // set the enabled custom block page based on URL existance
        vm.bind('{settings.customBlockPageUrl}', function (url) {
            vm.set('settings.customBlockPageEnabled', url.length > 0);
        });

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.directPromise('rpc.isExpertMode'),
        ]).then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set({
                settings: result[0],
                isExpertMode: result[1]
            });

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            var filters = store.getFilters().clone();
            store.clearFilter(true);

            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                }, this, true);
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
            filters.each( function(filter){
                store.addFilter(filter);
            });
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    clearHostCache: function () {
        var v = this.getView();
        Ext.MessageBox.wait('Clearing Category URL Cache...'.t(), 'Please Wait'.t());

        Rpc.asyncData(v.appManager, 'clearCache')
        .then(function(result){
            Ext.MessageBox.hide();
            Util.successToast('The Category URL Cache was cleared succesfully.'.t());
        }, function(ex) {
            Util.handleException(ex);
            Ext.MessageBox.hide();
        });
    },

    initSiteLookup: function() {
        var vm = this.getViewModel();
        vm.set('siteLookupInput', '');
        vm.set('siteLookupAddress', '');
        vm.set('siteLookupCategory', '');
        vm.set('siteLookupCheckbox', false);
        vm.set('siteLookupSuggest', '');
    },

    handleSiteLookup: function() {
        var v = this.getView(), vm = this.getViewModel();

        var inputField = v.down("[fieldIndex='siteLookupInput']");

        if (inputField.getValue().length == 0) {
            Ext.MessageBox.alert('Site URL is empty'.t() , 'You must enter the Site URL for category search.'.t());
            return;
        }

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'lookupSite', inputField.getValue())
        .then(function(result){
            if(Util.isDestroyed(v, vm, inputField)){
                return;
            }
            v.setLoading(false);

            var showAddress = v.down("[fieldIndex='siteLookupAddress']");
            var showCategory = v.down("[fieldIndex='siteLookupCategory']");
            var suggestBox = v.down("[fieldIndex='siteLookupSuggest']");
            var masterList = vm.get('settings.categories.list');
            showAddress.setValue(inputField.getValue());
            inputField.setValue('');

            var currentCategories = [];
            var suggested = null;

            if(result && result.list && masterList ){
                result.list.forEach(function(id){
                    var category = Ext.Array.findBy(masterList, function(cat){
                        if(cat.id == id){
                            return true;
                        }
                    });
                    if(category){
                        currentCategories.push(category.name);
                        if(suggested == null){
                            suggested = category.id;
                        }
                    }
                });
            }
            showCategory.setValue(currentCategories.join(","));
            suggestBox.setValue(suggested);
        }, function(ex) {
            if(!Util.isDestroyed(v)){
                v.setLoading(false);
                return;
            }
            Util.handleException(ex);
        });
    },

    handleCategorySuggest: function() {
        var v = this.getView(), vm = this.getViewModel();

        var showAddress = v.down("[fieldIndex='siteLookupAddress']");
        var suggestBox = v.down("[fieldIndex='siteLookupSuggest']");

        if (showAddress.getValue().length == 0) {
            Ext.MessageBox.alert('Last Search URL is empty'.t() , 'You must search for a Site URL before you can suggest a different category.'.t());
            return;
        }

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'recategorizeSite', showAddress.getValue(), suggestBox.getValue())
        .then(function(result){
            if(Util.isDestroyed(v, vm, showAddress, suggestBox)){
                return;
            }
            v.setLoading(false);

            var showCategory = v.down("[fieldIndex='siteLookupCategory']");
            var checkBox = v.down("[fieldIndex='siteLookupCheckbox']");

            if (result == suggestBox.getValue()) {
                Ext.MessageBox.alert('Suggestion Submitted'.t(), showAddress.getValue() + ' - ' + vm.get('categories').findRecord('id', result, 0, false, false, true).get('name'));
            } else {
                Ext.MessageBox.alert('Unable to submit suggestion.'.t(), 'Please try again later.'.t());
            }

            showAddress.setValue('');
            showCategory.setValue('');
            suggestBox.setValue('');
            checkBox.setValue(false);

        }, function(ex) {
            if(!Util.isDestroyed(v)){
                v.setLoading(false);
                return;
            }
            Util.handleException(ex);
        });
    },

});

Ext.define('Ung.apps.webfilter.cmp.BlockSitesController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.blocksites',

    addRecord: function () {
        var vm = this.getViewModel();
        if (vm) vm.set('isAddAction', true);
        this.callParent(arguments);
    },
    editRecord: function () {
        var vm = this.getViewModel();
        if (vm) vm.set('isAddAction', false);
        this.callParent(arguments); 
    }
});

Ext.define('Ung.apps.webfilter.cmp.PassSitesController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.passsites',

    addRecord: function () {
        var vm = this.getViewModel();
        if (vm) vm.set('isAddAction', true);
        this.callParent(arguments);
    },
    editRecord: function () {
        var vm = this.getViewModel();
        if (vm) vm.set('isAddAction', false);
        this.callParent(arguments); 
    }
});


Ext.define('Ung.apps.webfilter.cmp.SearchTermsGridController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.unwebfiltersearchtermsgrid',

    handleImport: function(btn){
        var me = this;

        btn.up('form').submit({
            waitMsg: 'Please wait while the settings are uploaded...'.t(),
            success: function(form, action) {
                if (!action.result) {
                    Ext.MessageBox.alert('Warning'.t(), 'Import failed.'.t());
                    return;
                }
                if (!action.result.success) {
                    Ext.MessageBox.alert('Warning'.t(), action.result.msg);
                    return;
                }

                var blocked = false;
                var flagged = false;

                /**
                 * NGFW-12869
                 * checkboxgroup has a specific behaviour for form.getValues()
                 * - if nothing is checked, form.getValues() does not contain anything related to it
                 * - if a single one is checked, form.getValues() will return the string value of that checked one
                 * - and only if more than one are checked, form.getValues() will return an array of checked values
                 */
                var defaultActions = form.getValues().defaultActions;

                // defaultActions is undefined is nothing is checked
                if (defaultActions) {
                    // defaultActions is a string if a single one is checked
                    if (Ext.isString(defaultActions)) {
                        defaultActions = [defaultActions];
                    }
                    // defaultActions is an array only if more than one are checked
                    defaultActions.forEach(function(action){
                        if(action == 'block'){
                            blocked = true;
                        }
                        if(action == 'flag'){
                            flagged = true;
                        }
                    });
                }

                var fileType = form.getValues().fileType;
                var jsonArray = [];
                if(fileType == 'COMMA'){
                    action.result.msg.split("\n").forEach( function(line){
                        line = line.trim();
                        if(!line.length || line[0] == '#'){
                            return;
                        }
                        if(line.indexOf(',') > -1){
                            line.split(",").forEach( function(term){
                                term = term.trim();
                                jsonArray.push({
                                    string: term,
                                    description: term,
                                    blocked: blocked,
                                    flagged: flagged,
                                    javaClass: "com.untangle.uvm.app.GenericRule"
                                });
                            });
                        }
                    });
                }else if(fileType == 'NEWLINE'){
                    action.result.msg.split("\n").forEach( function(line){
                        line = line.trim();
                        if(!line.length){
                            return;
                        }
                        jsonArray.push({
                            string: line,
                            description: line,
                            blocked: blocked,
                            flagged: flagged,
                            javaClass: "com.untangle.uvm.app.GenericRule"
                        });
                    });

                }else{
                    jsonArray = action.result.msg;
                }

                me.importHandler(form.getValues().importMode, jsonArray);
            },
            failure: function(form, action) {
                Ext.MessageBox.alert('Warning'.t(), action.result.msg);
            }
        });
    }
});Ext.define('Ung.apps.webfilter.view.Advanced', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-web-filter-advanced',
    itemId: 'advanced',
    title: 'Advanced'.t(),
    scrollable: true,
    withValidation: true,

    bodyPadding: 10,

    items: [{
        xtype: 'fieldset',
        title: 'Process HTTPS traffic by SNI (Server Name Indication) information if present'.t(),
        collapsible: true,
        checkboxToggle: true,
        checkbox: {
            bind: '{settings.enableHttpsSni}'
        },
        padding: 10,
        items: [{
            xtype: 'checkbox',
            margin: '0 0 0 20',
            boxLabel: 'Process HTTPS traffic by hostname in server certificate when SNI information not present'.t(),
            disabled: true,
            bind: {
                value: '{settings.enableHttpsSniCertFallback}',
                disabled: '{!settings.enableHttpsSni}'
            },
            listeners: {
                disable: function (ck) {
                    ck.setValue(false);
                }
            }
        }, {
            xtype: 'checkbox',
            margin: '0 0 0 20',
            boxLabel: 'Process HTTPS traffic by server IP if both SNI and certificate hostname information are not available'.t(),
            disabled: true,
            bind: {
                value: '{settings.enableHttpsSniIpFallback}',
                disabled: '{!settings.enableHttpsSniCertFallback}'
            },
            listeners: {
                disable: function (ck) {
                    ck.setValue(false);
                }
            }
        }]
    }, {
        xtype: 'fieldset',
        title: 'Safe browsing options'.t(),
        padding: '10 15',
        cls: 'app-section',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'checkbox',
            boxLabel: 'Enforce safe search on popular search engines'.t(),
            bind: '{settings.enforceSafeSearch}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Enforce Restricted Mode on YouTube'.t(),
            bind: '{settings.restrictYoutube}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Force searches through kid-friendly search engine'.t(),
            bind: '{settings.forceKidFriendly}'
        }]
    },{
        xtype: 'fieldset',
        title: 'Block options'.t(),
        padding: '10 15',
        cls: 'app-section',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'checkbox',
            boxLabel: 'Block QUIC Sessions (UDP port 443)'.t(),
            bind: '{settings.blockQuic}'
        }, {
            xtype: 'checkbox',
            margin: '0 0 5 20',
            boxLabel: 'Log blocks'.t(),
            bind: {
                hidden: '{!isExpertMode || !settings.blockQuic}',
                value: '{settings.logQuic}'
            }
        }, {
            xtype: 'checkbox',
            boxLabel: 'Block pages from IP only hosts'.t(),
            bind: '{settings.blockAllIpHosts}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Pass if referrer matches any Pass Sites'.t(),
            bind: '{settings.passReferers}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Close connection for blocked HTTPS sessions without redirecting to block page'.t(),
            bind: '{settings.closeHttpsBlockEnabled}'
        }, {
            xtype: 'checkbox',
            hidden: true,
            boxLabel: 'Block Encrypted Client Hello (ECH)'.t(),
            bind: '{settings.blockECH}'
        }]
    }, {
        xtype: 'fieldset',
        title: 'Restrict Google applications'.t(),
        checkboxToggle: true,
        checkbox: {
            bind: '{settings.restrictGoogleApps}'
        },
        collapsible: true,
        collapsed: true,
        padding: 10,
        cls: 'app-section',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'displayfield',
            value: 'NOTE:'.t() + ' ' + '<i>SSL Inspector</i> ' + 'must be installed and running with the Inspect Google Traffic configured to Inspect.'.t()
        }, {
            xtype: 'textfield',
            fieldLabel: 'Specify the comma separated list of domains allowed to access non-search Google applications'.t(),
            labelAlign: 'top',
            bind: '{settings.restrictGoogleAppsDomain}',
            validator: function(fieldValue) {
                if (fieldValue.length === 0) {
                    return true;
                }
                var domains = fieldValue.split(/,/);
                for (var i = 0; i < domains.length; i++){
                    var domain = domains[i];
                    if (domain.match(/^([^:]+):\/\//) !== null) {
                        return 'Domain cannot contain URL protocol.'.t();
                    }
                    if (domain.match( /^([^:]+):\d+\// ) !== null) {
                        return 'Domain cannot contain port.'.t();
                    }
                    if (domain.trim().length === 0) {
                        return 'Invalid domain specified'.t();
                    }
                }
                return true;
            }
        }],
        listeners: {
            collapse: function (el) {
                el.down('textfield').setValue('');
            }
        }
    }, {
        xtype: 'fieldset',
        title: 'Custom block page'.t(),
        padding: '10 15',
        layout: 'fit',
        items: [{
            xtype: 'textfield',
            emptyText: 'http://example.com',
            fieldLabel: 'URL',
            vtype: 'url',
            bind: '{settings.customBlockPageUrl}',
            listeners: {
                // add 'http://' prefix if missing
                blur: function (el) {
                    var url = el.getValue();
                    if (url.length) {
                        if (!url.startsWith("http://") && !url.startsWith("https://")) {
                            el.setValue("http://" + url);
                        }
                    }
                }
            }
        }]
    }, {
        xtype: 'displayfield',
        value: 'NOTE:'.t() + ' ' + 'Unblock operations are not available for custom block page'.t()
    }, {
        xtype: 'fieldset',
        title: 'Unblock Options'.t(),
        padding: 10,
        cls: 'app-section',
        layout: {
            type: 'vbox'
        },
        bind:{
            hidden: '{settings.customBlockPageEnabled}',
            disabled: '{settings.customBlockPageEnabled}',
        },
        items: [{
            xtype: 'container',
            items: [{
                xtype: 'combo',
                width: 200,
                editable: false,
                queryMode: 'local',
                store: [
                    ['None', 'None'.t()],
                    ['Host', 'Temporary'.t()],
                    ['Global', 'Permanent and Global'.t()]
                ],
                bind: '{settings.unblockMode}'
            }, {
                xtype: 'container',
                margin: '0 0 0 10',
                hidden: true,
                disabled: true,
                bind: {
                    hidden: '{settings.unblockMode !== "Host"}',
                    disabled: '{settings.unblockMode !== "Host"}'
                },
                items: [{
                    xtype: 'container',
                    layout: 'column',
                    width: 500,
                    items:[{
                        xtype: 'textfield',
                        fieldLabel: 'Timeout'.t(),
                        bind: '{settings.unblockTimeout}'
                    },{
                        xtype: 'label',
                        margin: '5 0 0 5',
                        html: 'seconds'.t(),
                        cls: 'boxlabel'
                    }]
                }]
            }, {
                xtype: 'checkbox',
                margin: '0 0 0 10',
                boxLabel: 'Require Password'.t(),
                hidden: true,
                disabled: true,
                bind: {
                    value: '{settings.unblockPasswordEnabled}',
                    disabled: '{settings.unblockMode === "None"}',
                    hidden: '{settings.unblockMode === "None"}'
                },
                listeners: {
                    disable: function (el) {
                        el.setValue(false);
                    }
                }
            }]
        }, {
            xtype: 'container',
            layout: {
                type: 'hbox',
                align: 'center'
            },
            margin: '0 0 0 20',
            hidden: true,
            disabled: true,
            bind: {
                hidden: '{!settings.unblockPasswordEnabled}',
                disabled: '{!settings.unblockPasswordEnabled}'
            },
            items: [{
                xtype: 'radiogroup',
                margin: '10 0',
                columns: 2,
                simpleValue: true,
                bind: '{settings.unblockPasswordAdmin}',
                items: [
                    { boxLabel: 'Administrator Password'.t(), inputValue: true, width: 200 },
                    { boxLabel: 'Custom Password'.t(), inputValue: false }
                ]
            }, {
                xtype: 'textfield',
                inputType: 'password',
                disabled: true,
                hidden: true,
                bind: {
                    value: '{settings.unblockPassword}',
                    disabled: '{settings.unblockPasswordAdmin}',
                    hidden: '{settings.unblockPasswordAdmin}'
                },
                margin: '0 0 0 10',
                listeners: {
                    disable: function (el) {
                        el.setValue('');
                    }
                }
            }],
            listeners: {
                disable: function (el) {
                    el.down('radiogroup').setValue(false);
                }
            }
        }]
    }, {
        xtype: 'button',
        text: 'Clear Category URL Cache.'.t(),
        iconCls: 'fa fa-trash-o fa-red',
        handler: 'clearHostCache'
    }]

});
Ext.define('Ung.apps.webfilter.view.BlockSites', {
    extend: 'Ung.cmp.Grid',
    alias:  'widget.app-web-filter-blocksites',
    itemId: 'block-sites',
    title:  'Block Sites'.t(),
    controller: 'blocksites',
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Block or flag access to sites associated with the specified category.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyText: 'No Block Sites defined'.t(),

    importValidationJavaClass: true,

    listProperty: 'settings.blockedUrls.list',
    emptyRow: {
        string: '',
        blocked: true,
        isGlobal: false,
        flagged: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{blockedUrls}',

    viewConfig: {
        getRowClass : Ung.util.Util.getGlobalRowClass
    },
    
    columns: [{
        header: 'Site'.t(),
        width: Renderer.uriWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter site]'.t(),
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Block'.t(),
        dataIndex: 'blocked',
        resizable: false
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Global'.t(),
        dataIndex: 'isGlobal',
        resizable: false, 
        listeners: {
            beforecheckchange: Ung.util.Util.canToggleGlobalCheckbox
        },
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Flag'.t(),
        dataIndex: 'flagged',
        resizable: false,
        tooltip: 'Flag as Violation'.t()
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'Site'.t(),
        emptyText: '[enter site]'.t(),
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.blocked}',
        fieldLabel: 'Block'.t()
    }, {
        xtype: 'checkbox',
        bind: {
            value: '{record.isGlobal}',
            hidden: '{!isAddAction}'
        },    
        fieldLabel: 'Global'.t(),
    },  {
        xtype: 'checkbox',
        bind: '{record.flagged}',
        fieldLabel: 'Flag'.t(),
        tooltip: 'Flag as Violation'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]
});
Ext.define('Ung.apps.webfilter.view.Categories', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-filter-categories',
    itemId: 'categories',
    title: 'Categories'.t(),
    withValidation: false,
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'Block or flag access to sites associated with the specified category.'.t()
    },{
        xtype: 'ungridfilter'
    }],

    features: [{
        ftype: 'grouping',
        groupHeaderTpl: ['Group: {name:this.formatName} ({rows.length} {[values.rows.length > 1 ? "categories" : "category"]})'.t(),{
            formatName: function(name){
                return Ext.String.trim(name);
            }
        }],
        startCollapsed: false
     }],

    listProperty: 'settings.categories.list',

    bind: '{categories}',

    columns: [{
        header: 'Group'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'category'
    },{
        header: 'Category'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'name'
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Block'.t(),
        dataIndex: 'blocked',
        resizable: false
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Flag'.t(),
        dataIndex: 'flagged',
        resizable: false,
        //tooltip: 'Flag as Violation'.t()
        // checkAll: {}
    }, {
        header: 'Description'.t(),
        flex: 4,
        width: Renderer.messageWidth,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            allowBlank: false
        }
    }]
});
Ext.define('Ung.apps.webfilter.view.PassClients', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-filter-passclients',
    itemId: 'pass-clients',
    title: 'Pass Clients'.t(),
    withValidation: false,

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Allow access for client networks regardless of matching block policies.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyText: 'No Pass Clients defined'.t(),

    importValidationJavaClass: true,

    listProperty: 'settings.passedClients.list',
    emptyRow: {
        string: '1.2.3.4',
        enabled: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{passedClients}',

    columns: [{
        header: 'IP address/range'.t(),
        width: Renderer.networkWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter IP address/range]'.t(),
            vtype: 'ipMatcher',
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Pass'.t(),
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'IP address/range'.t(),
        emptyText: '[enter IP address/range]'.t(),
        vtype: 'ipMatcher',
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Pass'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]

});
Ext.define('Ung.apps.webfilter.view.PassSites', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-filter-passsites',
    itemId: 'pass-sites',
    title: 'Pass Sites'.t(),
    withValidation: false,
    controller: 'passsites',
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Allow access to the specified site regardless of matching block policies.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyText: 'No Pass Sites defined'.t(),

    importValidationJavaClass: true,

    viewConfig: {
        getRowClass : Ung.util.Util.getGlobalRowClass
    },

    listProperty: 'settings.passedUrls.list',
    emptyRow: {
        string: '',
        enabled: true,
        isGlobal: false,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{passedUrls}',

    columns: [{
        header: 'Site'.t(),
        width: Renderer.uriWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter site]'.t(),
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Pass'.t(),
        dataIndex: 'enabled',
        resizable: false
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Global'.t(),
        dataIndex: 'isGlobal',
        resizable: false,
        listeners: {
            beforecheckchange: Ung.util.Util.canToggleGlobalCheckbox
        },
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'Site'.t(),
        emptyText: '[enter site]'.t(),
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Pass'.t()
    }, {
        xtype: 'checkbox',
        bind: {
            value: '{record.isGlobal}',
            hidden: '{!isAddAction}'
        }, 
        fieldLabel: 'Global'.t(),
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]

});
Ext.define('Ung.apps.webfilter.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-filter-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Web Filter rules allow creating flexible block and pass conditions.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    emptyText: 'No Rules defined'.t(),

    importValidationJavaClass: true,

    importValidationForComboBox: true,

    listProperty: 'settings.filterRules.list',

    emptyRow: {
        ruleId: 0,
        enabled: true,
        flagged: true,
        blocked: false,
        description: '',
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.web_filter.WebFilterRule'
    },

    bind: '{filterRules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.flagged,
        Column.blocked,
        Column.description,
        Column.conditions
    ],
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.web_filter.WebFilterRuleCondition', [
            'DST_ADDR',
            'DST_PORT',
            'DST_INTF',
            'SRC_ADDR',
            'SRC_PORT',
            'SRC_INTF',
            'PROTOCOL',
            'TAGGED',
            'USERNAME',
            'HOST_HOSTNAME',
            'CLIENT_HOSTNAME',
            'SERVER_HOSTNAME',
            'SRC_MAC',
            'DST_MAC',
            'CLIENT_MAC_VENDOR',
            'SERVER_MAC_VENDOR',
            'CLIENT_IN_PENALTY_BOX',
            'SERVER_IN_PENALTY_BOX',
            'HOST_HAS_NO_QUOTA',
            'USER_HAS_NO_QUOTA',
            'CLIENT_HAS_NO_QUOTA',
            'SERVER_HAS_NO_QUOTA',
            'HOST_QUOTA_EXCEEDED',
            'USER_QUOTA_EXCEEDED',
            'CLIENT_QUOTA_EXCEEDED',
            'SERVER_QUOTA_EXCEEDED',
            'HOST_QUOTA_ATTAINMENT',
            'USER_QUOTA_ATTAINMENT',
            'CLIENT_QUOTA_ATTAINMENT',
            'SERVER_QUOTA_ATTAINMENT',
            'HOST_ENTITLED',
    
            'HTTP_HOST',
            'HTTP_REFERER',
            'HTTP_URI',
            'HTTP_URL',
            'HTTP_CONTENT_TYPE',
            'HTTP_CONTENT_LENGTH',
            'HTTP_REQUEST_METHOD',
            'HTTP_REQUEST_FILE_PATH',
            'HTTP_REQUEST_FILE_NAME',
            'HTTP_REQUEST_FILE_EXTENSION',
            'HTTP_RESPONSE_FILE_NAME',
            'HTTP_RESPONSE_FILE_EXTENSION',
            'HTTP_USER_AGENT',
            'HTTP_USER_AGENT_OS',
    
            'WEB_FILTER_CATEGORY',
            'WEB_FILTER_CATEGORY_DESCRIPTION',
            'WEB_FILTER_FLAGGED',
            'WEB_FILTER_REQUEST_METHOD',
            'WEB_FILTER_REQUEST_FILE_PATH',
            'WEB_FILTER_REQUEST_FILE_NAME',
            'WEB_FILTER_REQUEST_FILE_EXTENSION',
            'WEB_FILTER_RESPONSE_CONTENT_TYPE',
            'WEB_FILTER_RESPONSE_FILE_NAME',
            'WEB_FILTER_RESPONSE_FILE_EXTENSION',
            
            // 'APPLICATION_CONTROL_APPLICATION',
            // 'APPLICATION_CONTROL_CATEGORY',
            // 'APPLICATION_CONTROL_PROTOCHAIN',
            // 'APPLICATION_CONTROL_DETAIL',
            // 'APPLICATION_CONTROL_CONFIDENCE',
            // 'APPLICATION_CONTROL_PRODUCTIVITY',
            // 'APPLICATION_CONTROL_RISK',
    
            'PROTOCOL_CONTROL_SIGNATURE',
            'PROTOCOL_CONTROL_CATEGORY',
            'PROTOCOL_CONTROL_DESCRIPTION',
    
            'DIRECTORY_CONNECTOR_GROUP',
            'DIRECTORY_CONNECTOR_DOMAIN',
    
            'SSL_INSPECTOR_SNI_HOSTNAME',
            'SSL_INSPECTOR_SUBJECT_DN',
            'SSL_INSPECTOR_ISSUER_DN',
    
            'CLIENT_COUNTRY',
            'SERVER_COUNTRY',

            'THREAT_PREVENTION_SRC_REPUTATION',
            'THREAT_PREVENTION_SRC_CATEGORIES',
            'THREAT_PREVENTION_DST_REPUTATION',
            'THREAT_PREVENTION_DST_CATEGORIES'
        ]),
        Field.flagged,
        Field.blockedCombo
    ]
});
Ext.define('Ung.apps.webfilter.view.SearchTerms', {
    extend: 'Ung.cmp.Grid',
    alias:  'widget.app-web-filter-searchterms',
    itemId: 'search-terms',
    title:  'Search Terms'.t(),
    withValidation: false,
    controller: 'unwebfiltersearchtermsgrid',

    import:{
        items: [{
            fieldLabel: 'Format'.t(),
            name: 'fileType',
            editable: false,
            xtype: 'combo',
            queryMode: 'local',
            value: 'COMMA',
            store: [[
                'COMMA', 'Comma delimited'
            ],[
                'NEWLINE', 'Newline delimited'
            ],[
                'JSONArray', 'JSON array'
            ]],
            forceSelection: true
        },{
            fieldLabel: 'Default actions'.t(),
            displayName: 'Default actions'.t(),
            xtype: 'checkboxgroup',
            columns: 1,
            items: [{
                boxLabel: 'Block'.t(),
                name: 'defaultActions',
                inputValue: 'block',
                checked: true
            },{
                boxLabel: 'Flag'.t(),
                name: 'defaultActions',
                inputValue: 'flag',
                checked: true
            }]
        }],
        handler: 'handleImport'
    },

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Block or flag searches with the specified term.'.t()
        },{
            xtype: 'ungridfilter'
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyText: 'No Search Terms defined'.t(),
    
    importValidationJavaClass: true,

    listProperty: 'settings.searchTerms.list',
    emptyRow: {
        string: '',
        blocked: true,
        flagged: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{searchTerms}',

    columns: [{
        header: 'Term'.t(),
        width: Renderer.uriWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter term]'.t(),
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Block'.t(),
        dataIndex: 'blocked',
        resizable: false
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Flag'.t(),
        dataIndex: 'flagged',
        resizable: false,
        tooltip: 'Flag as Violation'.t()
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'Term'.t(),
        emptyText: '[enter term]'.t(),
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.blocked}',
        fieldLabel: 'Block'.t()
    }, {
        xtype: 'checkbox',
        bind: '{record.flagged}',
        fieldLabel: 'Flag'.t(),
        tooltip: 'Flag as Violation'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]
});
Ext.define('Ung.apps.webfilter.view.SiteLookup', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-web-filter-sitelookup',
    itemId: 'site-lookup',
    title: 'Site Lookup'.t(),
    viewModel: true,
    bodyPadding: 10,
    scrollable: true,
    defaultButton: 'searchButton',
    withValidation: false,
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'Lookup the category for websites.'.t()
    }],

    items: [{
        xtype: 'fieldset',
        margin: '0 0 5 -10',
        layout: 'column',
        border: false,
        items: [{
            xtype: 'displayfield',
            value: 'Web Filter must be enabled to perform lookups'.t(),
            bind:{
                hidden: '{state.on == true}'
            }
        },{
            xtype: 'textfield',
            fieldLabel: 'Site URL'.t(),
            fieldIndex: 'siteLookupInput',
            bind: {
                hidden: '{state.on == false}',
                value: '{siteLookupInput}'
            },
            width: 400
        }, {
            xtype: 'button',
            reference: 'searchButton',
            text: 'Search'.t(),
            iconCls: 'fa fa-search',
            margin: '0 0 0 10',
            handler: 'handleSiteLookup',
            bind:{
                hidden: '{state.on == false}',
                disabled: '{siteLookupInput.length === 0}'
            }
        }],
    }, {
        xtype: 'displayfield',
        labelWidth: 160,
        fieldLabel: 'Last Search URL'.t(),
        fieldIndex: 'siteLookupAddress',
        bind: {
            value: '{siteLookupAddress}',
            hidden: '{siteLookupAddress.length === 0}'
        }
    }, {
        xtype: 'displayfield',
        labelWidth: 160,
        fieldLabel: 'Last Search Category'.t(),
        fieldIndex: 'siteLookupCategory',
        bind: {
            value: '{siteLookupCategory}',
            hidden: '{siteLookupCategory.length === 0}'
        }
    }, {
        xtype: 'checkbox',
        fieldLabel: 'Suggest a different category'.t(),
        fieldIndex: 'siteLookupCheckbox',
        labelWidth: 200,
        bind: {
            value: '{siteLookupCheckbox}',
            hidden: '{siteLookupAddress.length === 0}'
        }
    }, {
        xtype: 'fieldset',
        border: false,
        bind: {
            hidden: '{!siteLookupCheckbox}'
        },
        items: [{
            xtype: 'component',
            margin: '10 0 0 20',
            html: 'NOTE: This is only a suggestion and may not be accepted. If accepted it may take a few days to become active.'.t()
        }, {
            xtype: 'combobox',
            margin: '10 0 0 20',
            width: 400,
            fieldIndex: 'siteLookupSuggest',
            displayField: 'name',
            valueField: 'id',
            editable: false,
            bind: {
                value: '{siteLookupSuggest}',
                store: '{categoriesNames}'
            },
        }, {
            xtype: 'button',
            text: 'Suggest'.t(),
            margin: '10 0 0 20',
            iconCls: 'fa fa-share-square',
            handler: 'handleCategorySuggest'
        }]
    }]

});
Ext.define('Ung.apps.webfilter.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-web-filter-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/web-filter.svg" width="80" height="80"/>' +
                '<h3>Web Filter</h3>' +
                '<p>' + 'Web Filter scans and categorizes web traffic to monitor and enforce network usage policies.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
