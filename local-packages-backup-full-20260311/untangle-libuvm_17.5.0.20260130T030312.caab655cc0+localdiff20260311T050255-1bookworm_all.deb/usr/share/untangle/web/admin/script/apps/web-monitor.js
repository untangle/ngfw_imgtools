Ext.define('Ung.apps.webmonitor.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-web-monitor',
    controller: 'app-web-monitor',

    viewModel: {
        stores: {
            categories:    { 
                data: '{settings.categories.list}',
                groupField: 'category'
            },
            blockedUrls:   { data: '{settings.blockedUrls.list}' },
            passedUrls:    { data: '{settings.passedUrls.list}' },
            passedClients: { data: '{settings.passedClients.list}' },
            filterRules:   { data: '{settings.filterRules.list}' }
        }
    },

    items: [
        { xtype: 'app-web-monitor-status' },
        { xtype: 'app-web-monitor-categories' },
        { xtype: 'app-web-monitor-flagsites' },
        { xtype: 'app-web-monitor-passsites' },
        { xtype: 'app-web-monitor-passclients' },
        { xtype: 'app-web-monitor-rules' },
        { xtype: 'app-web-monitor-advanced' }
    ]

});
Ext.define('Ung.apps.webmonitor.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-web-monitor',

    control: {
        '#': {
            afterrender: 'getSettings',
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            var filters = store.getFilters().clone();
            store.clearFilter(true);

            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                }, this, true);
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }

            filters.each( function(filter){
                store.addFilter(filter);
            });
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    clearHostCache: function () {
        Ext.MessageBox.wait('Clearing Category URL Cache...'.t(), 'Please Wait'.t());

        Rpc.asyncData( this.getView().appManager, 'clearCache')
        .then(function(result){
            Ext.MessageBox.hide();
            Util.successToast('The Category URL Cache was cleared succesfully.'.t());
        },function(ex){
            Ext.MessageBox.hide();
            Util.handleException(ex);
        });
    }

});
Ext.define('Ung.apps.webmonitor.view.Advanced', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-web-monitor-advanced',
    itemId: 'advanced',
    title: 'Advanced'.t(),
    scrollable: true,
    withValidation: false,
    bodyPadding: 10,

    items: [{
        xtype: 'fieldset',
        title: 'Process HTTPS traffic by SNI (Server Name Indication) information if present'.t(),
        collapsible: true,
        checkboxToggle: true,
        checkbox: {
            bind: '{settings.enableHttpsSni}'
        },
        padding: 10,
        items: [{
            xtype: 'checkbox',
            margin: '0 0 0 20',
            boxLabel: 'Process HTTPS traffic by hostname in server certificate when SNI information not present'.t(),
            disabled: true,
            bind: {
                value: '{settings.enableHttpsSniCertFallback}',
                disabled: '{!settings.enableHttpsSni}'
            },
            listeners: {
                disable: function (ck) {
                    ck.setValue(false);
                }
            }
        }, {
            xtype: 'checkbox',
            margin: '0 0 0 20',
            boxLabel: 'Process HTTPS traffic by server IP if both SNI and certificate hostname information are not available'.t(),
            disabled: true,
            bind: {
                value: '{settings.enableHttpsSniIpFallback}',
                disabled: '{!settings.enableHttpsSniCertFallback}'
            },
            listeners: {
                disable: function (ck) {
                    ck.setValue(false);
                }
            }
        }]
    }, {
        xtype: 'button',
        text: 'Clear Category URL Cache.'.t(),
        iconCls: 'fa fa-trash-o fa-red',
        handler: 'clearHostCache'
    }]

});
Ext.define('Ung.apps.webmonitor.view.Categories', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-monitor-categories',
    itemId: 'categories',
    title: 'Categories'.t(),
    withValidation: false,
    tbar: [{
        xtype: 'ungridfilter'
    },{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'Flag access to sites associated with the specified category.'.t()
    }],

    features: [{
        ftype: 'grouping',
        groupHeaderTpl: ['Group: {name:this.formatName} ({rows.length} {[values.rows.length > 1 ? "categories" : "category"]})'.t(),{
            formatName: function(name){
                return Ext.String.trim(name);
            }
        }],
        startCollapsed: false
     }],

    listProperty: 'settings.categories.list',

    bind: '{categories}',

    columns: [{
        header: 'Category'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'name'
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Flag'.t(),
        dataIndex: 'flagged',
        resizable: false,
        tooltip: 'Flag as Violation'.t()
        // checkAll: {}
    }, {
        header: 'Description'.t(),
        flex: 4,
        width: Renderer.messageWidth,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            allowBlank: false
        }
    }]
});
Ext.define('Ung.apps.webmonitor.view.FlagSites', {
    extend: 'Ung.cmp.Grid',
    alias:  'widget.app-web-monitor-flagsites',
    itemId: 'flag-sites',
    title:  'Flag Sites'.t(),
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Flag access to specific sites.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyText: 'No Flag Sites defined'.t(),

    listProperty: 'settings.blockedUrls.list',
    emptyRow: {
        string: '',
        blocked: false,
        flagged: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{blockedUrls}',

    columns: [{
        header: 'Site'.t(),
        width: Renderer.uriWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter site]'.t(),
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Flag'.t(),
        dataIndex: 'flagged',
        resizable: false,
        tooltip: 'Flag as Violation'.t()
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'Site'.t(),
        emptyText: '[enter site]'.t(),
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.flagged}',
        fieldLabel: 'Flag'.t(),
        tooltip: 'Flag as Violation'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]
});
Ext.define('Ung.apps.webmonitor.view.PassClients', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-monitor-passclients',
    itemId: 'pass-clients',
    title: 'Pass Clients'.t(),
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Allow unflagged access for client networks regardless of matching policies.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyText: 'No Pass Clients defined'.t(),

    listProperty: 'settings.passedClients.list',
    emptyRow: {
        string: '1.2.3.4',
        enabled: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{passedClients}',

    columns: [{
        header: 'IP address/range'.t(),
        width: Renderer.networkWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter IP address/range]'.t(),
            vtype: 'ipMatcher',
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Pass'.t(),
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'IP address/range'.t(),
        emptyText: '[enter IP address/range]'.t(),
        vtype: 'ipMatcher',
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Pass'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]

});
Ext.define('Ung.apps.webmonitor.view.PassSites', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-monitor-passsites',
    itemId: 'pass-sites',
    title: 'Pass Sites'.t(),
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Allow unflagged access to the specified site regardless of matching policies.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',

    emptyText: 'No Pass Sites defined'.t(),

    listProperty: 'settings.passedUrls.list',
    emptyRow: {
        string: '',
        enabled: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{passedUrls}',

    columns: [{
        header: 'Site'.t(),
        width: Renderer.uriWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter site]'.t(),
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Pass'.t(),
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'Site'.t(),
        emptyText: '[enter site]'.t(),
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Pass'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]

});
Ext.define('Ung.apps.webmonitor.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-web-monitor-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Web Monitor rules allow creating flexible flag and pass conditions.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    emptyText: 'No Rules defined'.t(),

    listProperty: 'settings.filterRules.list',

    emptyRow: {
        ruleId: 0,
        enabled: true,
        flagged: true,
        blocked: false,
        description: '',
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.web_filter.WebFilterRule'
    },

    bind: '{filterRules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.flagged,
        Column.description,
        Column.conditions
    ],
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.web_filter.WebFilterRuleCondition', [
            'DST_ADDR',
            'DST_PORT',
            'DST_INTF',
            'SRC_ADDR',
            'SRC_PORT',
            'SRC_INTF',
            'PROTOCOL',
            'TAGGED',
            'USERNAME',
            'HOST_HOSTNAME',
            'CLIENT_HOSTNAME',
            'SERVER_HOSTNAME',
            'SRC_MAC',
            'DST_MAC',
            'CLIENT_MAC_VENDOR',
            'SERVER_MAC_VENDOR',
            'CLIENT_IN_PENALTY_BOX',
            'SERVER_IN_PENALTY_BOX',
            'HOST_HAS_NO_QUOTA',
            'USER_HAS_NO_QUOTA',
            'CLIENT_HAS_NO_QUOTA',
            'SERVER_HAS_NO_QUOTA',
            'HOST_QUOTA_EXCEEDED',
            'USER_QUOTA_EXCEEDED',
            'CLIENT_QUOTA_EXCEEDED',
            'SERVER_QUOTA_EXCEEDED',
            'HOST_QUOTA_ATTAINMENT',
            'USER_QUOTA_ATTAINMENT',
            'CLIENT_QUOTA_ATTAINMENT',
            'SERVER_QUOTA_ATTAINMENT',
            'HOST_ENTITLED',
    
            'HTTP_HOST',
            'HTTP_REFERER',
            'HTTP_URI',
            'HTTP_URL',
            'HTTP_CONTENT_LENGTH',
            'HTTP_REQUEST_METHOD',
            'HTTP_REQUEST_FILE_PATH',
            'HTTP_REQUEST_FILE_NAME',
            'HTTP_REQUEST_FILE_EXTENSION',
            'HTTP_CONTENT_TYPE',
            'HTTP_RESPONSE_FILE_NAME',
            'HTTP_RESPONSE_FILE_EXTENSION',
            'HTTP_USER_AGENT',
            'HTTP_USER_AGENT_OS',
    
            'WEB_FILTER_CATEGORY',
            'WEB_FILTER_CATEGORY_DESCRIPTION',
            'WEB_FILTER_FLAGGED',
            'WEB_FILTER_REQUEST_METHOD',
            'WEB_FILTER_REQUEST_FILE_PATH',
            'WEB_FILTER_REQUEST_FILE_NAME',
            'WEB_FILTER_REQUEST_FILE_EXTENSION',
            'WEB_FILTER_RESPONSE_CONTENT_TYPE',
            'WEB_FILTER_RESPONSE_FILE_NAME',
            'WEB_FILTER_RESPONSE_FILE_EXTENSION',
    
            'APPLICATION_CONTROL_APPLICATION',
            'APPLICATION_CONTROL_CATEGORY',
            'APPLICATION_CONTROL_PROTOCHAIN',
            'APPLICATION_CONTROL_DETAIL',
            'APPLICATION_CONTROL_CONFIDENCE',
            'APPLICATION_CONTROL_PRODUCTIVITY',
            'APPLICATION_CONTROL_RISK',
    
            'PROTOCOL_CONTROL_SIGNATURE',
            'PROTOCOL_CONTROL_CATEGORY',
            'PROTOCOL_CONTROL_DESCRIPTION',
    
            'DIRECTORY_CONNECTOR_GROUP',
            'DIRECTORY_CONNECTOR_DOMAIN',
    
            'SSL_INSPECTOR_SNI_HOSTNAME',
            'SSL_INSPECTOR_SUBJECT_DN',
            'SSL_INSPECTOR_ISSUER_DN',
    
            'CLIENT_COUNTRY',
            'SERVER_COUNTRY',

            'THREAT_PREVENTION_SRC_REPUTATION',
            'THREAT_PREVENTION_SRC_CATEGORIES',
            'THREAT_PREVENTION_DST_REPUTATION',
            'THREAT_PREVENTION_DST_CATEGORIES'
        ]),
        Field.flagged,
    ]
});
Ext.define('Ung.apps.webmonitor.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-web-monitor-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/web-monitor.svg" width="80" height="80"/>' +
                '<h3>Web Monitor</h3>' +
                '<p>' + 'Web Monitor scans and categorizes web traffic to monitor network usage.'.t() +
                '<br><br>' + 'Upgrade to Web Filter to control network usage and enforce policies that allow, block, flag or alert web traffic.'.t() +
                ' <a target="_blank" href="' + rpc.uriManager.getUriWithPath('https://edge.arista.com/shop/web-filter') + '">LEARN MORE<a/></p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
