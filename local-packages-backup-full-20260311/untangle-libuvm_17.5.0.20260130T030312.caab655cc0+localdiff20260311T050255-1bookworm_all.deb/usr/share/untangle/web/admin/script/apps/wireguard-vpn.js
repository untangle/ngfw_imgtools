Ext.define('Ung.apps.wireguard-vpn.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-wireguard-vpn',
    controller: 'app-wireguard-vpn',

    viewModel: {
        stores: {
            tunnelStatusList: {
                data: '{tunnelStatusData}',
                fields: [{
                    name: 'interface',
                },{
                    name :'tunnel-description',
                },{
                    name :'public-key',
                },{
                    name: 'private-key',
                },{
                    name :'peer-key',
                },{
                    name: 'listen-port',
                },{
                    name: 'fwmark'
                },{
                    name: 'peer-key'
                },{
                    name: 'preshared-key'
                },{
                    name: 'endpoint'
                }, {
                    name: 'configured-endpoint',
                },{
                    name: 'allowed-ips'
                },{
                    name: 'latest-handshake',
                    convert: Converter.convertDate,
                },{
                    name: 'transfer-rx'
                },{
                    name: 'transfer-txt'
                },{
                    name: 'persistent-keepalive'
                }]
            },
            tunnels: {
                data:'{settings.tunnels.list}'
            },
            networks: {
                data: '{settings.networks.list}'
            },
            networkProfiles: {
                data: '{settings.networkProfiles.list}'
            }
        },

        data: {
            tunnelStatusData: []
        },

        formulas: {
            getSiteUrl: {
                get: function(get) {
                    var publicUrl = Rpc.directData('rpc.networkManager.getPublicUrl');
                    return(publicUrl.split(":")[0] + ":" + get('settings.listenPort'));
                }
            },
            peerAddress: {
                get: function(get){
                    var address = get('settings.addressPool');
                    if(!address){
                        return address;
                    }
                    return address.split('/')[0];
                }
            }
        }
    },

    items: [
        { xtype: 'app-wireguard-vpn-status' },
        { xtype: 'app-wireguard-vpn-settings' },
        { xtype: 'app-wireguard-vpn-tunnels' }
    ],
    statics: {
        dynamicEndpointRenderer: function(value, cell, record, rowIndex, columnIndex, store, table){
            var dataIndex = table.getColumnManager().columns[columnIndex].dataIndex;
            if(dataIndex == 'endpointDynamic'){
                return value ? 'Roaming'.t() : 'Static'.t();
            }else if(record.get('endpointDynamic')){
                return '&mdash;';
            }
            return value;
        },

        statusHandshakeRenderer: function(value){
            if(value == 0){
                return 'No recent activity'.t();
            }
            return Renderer.timestampUnixRenderer(value);
        },

        hostDisplayFields: function(collapsible, collapsed, recordEditor){
            return {
                    xtype: 'fieldset',
                    title: 'Local Service Information'.t(),
                    itemId: 'localserviceinfo',
                    collapsible: collapsible ? true : false,
                    collapsed: collapsible && collapsed ? true : false,
                    layout: {
                        type: 'vbox'
                    },
                    defaults: {
                        labelWidth: 170,
                        labelAlign: recordEditor ? 'right' : 'left',
                    },
                    items:[{
                        xtype: 'copytoclipboard',
                        width: '100%',
                        key: {
                            key: 'itemId'
                        },
                        dataType: 'javascript',
                        below: 'true',
                        items: [{
                            xtype: 'fieldset',
                            border: false,
                            width: '100%',
                            defaults: {
                                labelWidth: 150,
                                labelAlign: recordEditor ? 'right' : 'left',
                                defaults: {
                                    labelWidth: 150,
                                    labelAlign: recordEditor ? 'right' : 'left',
                                }
                            },
                            items: [{
                                xtype: 'fieldset',
                                border: false,
                                width: '90%',
                                items: [{
                                    xtype: 'displayfield',
                                    itemId: 'hostname',
                                    fieldLabel: 'Hostname'.t(),
                                    cls: 'x-selectable',
                                    bind: {
                                        value: '{hostname}'
                                    }
                                }, {
                                    xtype: 'displayfield',
                                    itemId: 'publicKey',
                                    fieldLabel: 'Public Key'.t(),
                                    cls: 'x-selectable',
                                    bind: {
                                        value: '{settings.publicKey}'
                                    }
                                }, {
                                    fieldLabel: 'Local Endpoint Hostname'.t(),
                                    itemId: 'endpointHostname',
                                    xtype: 'displayfield',
                                    cls: 'x-selectable',
                                    bind: {
                                        value: '{localHostname}',
                                    }
                                },{
                                    fieldLabel: 'Local Endpoint Port'.t(),
                                    itemId: 'endpointPort',
                                    xtype: 'displayfield',
                                    cls: 'x-selectable',
                                    bind: {
                                        value: '{settings.listenPort}',
                                    }
                                }, {
                                    xtype: 'displayfield',
                                    itemId: 'peerAddress',
                                    fieldLabel: 'Peer IP Address'.t(),
                                    cls: 'x-selectable',
                                    bind: {
                                        value: '{peerAddress}',
                                    }
                                }, {
                                    xtype: 'displayfield',
                                    itemId: 'networks',
                                    fieldLabel: 'Local Networks'.t(),
                                    cls: 'x-selectable',
                                    bind: {
                                        value: '{localNetworkList}',
                                    },
                                    renderer: function(value) {
                                        return value ? value.replace(/,\s*/g, ', ') : '';
                                    }
                                }]
                            }]
                        }]
                    }]
            };
        }
    }

});
Ext.define('Ung.apps.wireguard-vpn.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-wireguard-vpn',

    control: {
        '#': {
            afterrender: 'getSettings'
        }
    },

    // When comparing settings for conditional restarts, ignore these values.
    conditionalRestartIgnoreKeys: [
        'tunnels'
    ],

    getSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise('rpc.networkManager.getNetworkSettings'),
            Rpc.asyncPromise('rpc.networkManager.getPublicUrl')
        ], this).then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            vm.set('originalSettings', JSON.parse(JSON.stringify(result[0])));
            vm.set('settings', result[0]);
            vm.set('panel.saveDisabled', false);
            vm.set('localHostname', result[2].split(":")[0]);

            var networkSettings = result[1];
            var warning = '';
            var listenPort = vm.get('settings.listenPort');
            if(me.isUDPAccessAllowedForPort(networkSettings, listenPort) == false) {
                warning = '<i class="fa fa-exclamation-triangle fa-red fa-lg"></i> <strong>' + 'There are no enabled access rules to allow traffic on UDP port '.t() + listenPort + '</strong>';
            }
            vm.set('warning', warning);
            vm.set('hostname', networkSettings['hostName']);

            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

        // trigger active clients/servers fetching when instance run state changes
        vm.bind('{state.on}', function (stateon) {
            if (stateon) {
                me.getTunnelStatus();
            } else {
                vm.set({
                    tunnelStatusData: []
                });
            }
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        var changes = Util.updateListStoresToSettings(v.query('ungrid'), vm);

        // Determine if non-tunnel changes have been made.
        // NOTE: This code attempts to not restart the wireguard interface
        // if only the tunnels have changed.  Under previous circumstances, wireguard will pick up
        // the tunnel changes from configuration and allow connections.
        // HOWEVER, by adding routes to route table namespaces using the Table=
        // and NOT restarting causes new connections to go into the main table and
        // not the target table.  As a result, we'll comment this out until WireGuard can fix this bug.
        var settingsChanged = true;
        // var settingsChanged = Util.isSettingsChanged(vm.get('originalSettings'), vm.get('settings'), me.conditionalRestartIgnoreKeys);
        // if(settingsChanged == false && Ext.Object.isEmpty(changes)){
        //     // If no changes but no tunnel changes either, consider this a call to perform full restart.
        //     settingsChanged = true;
        // }

        // Build list of sequential commands to run
        var sequence = [
            Rpc.directPromise(v.appManager, 'setSettings', vm.get('settings'), settingsChanged)
        ];

        if('settings.tunnels.list' in changes){
            changes['settings.tunnels.list'].deleted.forEach(function(jsonRecord){
                // Delete tunnel commands inserted before settings commit.
                var recordObj = JSON.parse(jsonRecord);
                sequence.unshift(Rpc.directPromise(v.appManager, 'deleteTunnel', recordObj['publicKey']));
            });

            // Format routedNetworkProfiles checkbox list value to java compatible object
            vm.get('settings.tunnels.list').forEach(function(tunnel) {
                if(tunnel.routedNetworkProfiles && !tunnel.routedNetworkProfiles.javaClass) {
                    tunnel.routedNetworkProfiles.javaClass = 'java.util.LinkedList';
                    if(!tunnel.routedNetworkProfiles.list)
                        tunnel.routedNetworkProfiles.list = [];
                    if(typeof tunnel.routedNetworkProfiles.list === 'string')
                        tunnel.routedNetworkProfiles.list = [ tunnel.routedNetworkProfiles.list ];
                }
            });
        }

        v.setLoading(true);
        Ext.Deferred.sequence(sequence).then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            if('settings.tunnels.list' in changes){
                me.addTunnels(changes['settings.tunnels.list']);
            }
            me.getSettings();

            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    /**
     * From Util.storeGetChangedRecords result, add tunnels by waiting
     * for tunnel store to be reloaded then pulling publicKeys.
     *
     * This is neccessary because on new tunnels, the keypair is added when
     * the records are written and not known until after we reload.
     *
     * @param {*} changes Util.storeGetChangedRecords result with added field.
     */
    addTunnels: function( changes ){
        if(changes == undefined || !changes.added.length){
            // No adds.
            return;
        }
        var me = this, v = this.getView(), vm = this.getViewModel();

        var tunnelsLoadCount = vm.get('tunnels').loadCount;

        var tunnelLoadTaskDelay = 100;
        var tunnelLoadTaskCountMax = 500;
        var tunnelLoadTaskCount = 0;
        var tunnelLoadTask = new Ext.util.DelayedTask( Ext.bind(function(){
            if(Util.isDestroyed(vm, changes)){
                return;
            }
            tunnelLoadTaskCount++;
            if(tunnelLoadTaskCount > tunnelLoadTaskCountMax){
                // Too many attempts
                return;
            }
            var tunnels = vm.get('tunnels');
            if(tunnels.loadCount == tunnelsLoadCount){
                /** Store has not been updated yet, so delay */
                tunnelLoadTask.delay( tunnelLoadTaskDelay );
                return;
            }
            var sequence = [];
            changes.added.forEach(function(jsonRecord){
                var recordObj = JSON.parse(jsonRecord);

                // Attempt to find based on publicKey and if not that, the peerAddress.
                var recordIndex = tunnels.find('publicKey', recordObj['publicKey']);
                if(recordIndex == -1){
                    recordIndex = tunnels.find('peerAddress', recordObj['peerAddress']);
                }
                if(recordIndex != -1){
                    // With updated record, get its publicKey for addTunnel call.
                    var record = tunnels.getAt(recordIndex);
                    if(record != null){
                        var publicKey = record.get('publicKey');
                        if(publicKey != ""){
                            sequence.push(Rpc.asyncPromise(v.appManager, 'addTunnel', publicKey));
                        }
                    }
                }
            });

            if(sequence.length == 0){
                // Did not find any matches.  Try again.
                tunnelLoadTask.delay( tunnelLoadTaskDelay );
                return;
            }

            // Perform addTunnel operations.
            if(sequence.length){
                Ext.Deferred.sequence(sequence, this)
                .then(function(result){
                    if(Util.isDestroyed(vm)){
                        return;
                    }
                }, function(ex) {
                    if(!Util.isDestroyed(v, vm)){
                        vm.set('panel.saveDisabled', true);
                        v.setLoading(false);
                    }
                });

            }
        }, me) );
        tunnelLoadTask.delay( tunnelLoadTaskDelay );
   },

    getTunnelStatus: function () {
        var me = this,
            grid = this.getView().down('#tunnelStatus'),
            vm = this.getViewModel();

        grid.setLoading(true);
        Rpc.asyncData(this.getView().appManager, 'getTunnelStatus')
        .then( function(result){
            if(Util.isDestroyed(grid, vm)){
                return;
            }
            var status = Ext.JSON.decode(result);

            var delay = 100;
            var updateStatusTask = new Ext.util.DelayedTask( Ext.bind(function(){
                if(Util.isDestroyed(vm, status)){
                    return;
                }
                var tunnels = vm.get('tunnels');
                if(!tunnels){
                    updateStatusTask.delay(delay);
                    return;
                }
                tunnels.each(function(tunnel){
                    status.wireguard.forEach(function(status){
                        if(tunnel.get('publicKey') == status['peer-key']){
                            status['tunnel-description'] = tunnel.get('description');
                            status['configured-endpoint'] = tunnel.get('endpointHostname');
                        }
                    });
                });
                vm.set('tunnelStatusData', status.wireguard);
            }, me) );
            updateStatusTask.delay( delay );

            grid.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    isUDPAccessAllowedForPort: function(networkSettings, listenPort) {
        if(networkSettings.accessRules && networkSettings.accessRules.list) {
            for(var i=0; i<networkSettings.accessRules.list.length ; i++) {
                var rule = networkSettings.accessRules.list[i];
                if(rule.enabled == true && rule.blocked == false) {
                    if(rule.conditions && rule.conditions.list) {
                        var isUDP = false;
                        var isPort = false;
                        for(var j=0; j<rule.conditions.list.length ; j++) {
                            var condition = rule.conditions.list[j];
                            if(condition.invert == false) {
                                if(condition.conditionType == 'PROTOCOL' && condition.value == 'UDP') {
                                    isUDP = true;
                                }
                                if(condition.conditionType == 'DST_PORT' && parseInt(condition.value, 10) == listenPort) {
                                    isPort = true;
                                }
                            }
                        }

                        if(isUDP == true && isPort == true) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    },

    getNewAddressSpace: function() {
        var me = this,
        vm = this.getViewModel();
        Rpc.asyncData(this.getView().appManager, 'getNewAddressPool')
        .then( function(result){
            if(Util.isDestroyed(me, vm)){
                return;
            }

            vm.set('settings.addressPool', result);
        },function(ex){
            Util.handleException(ex);
        });
    },

    getNextUnusedPoolAddr: function() {
        var me = this,
        vm = me.getViewModel(),
        addressPool = vm.get('settings.addressPool'),
        store = vm.getStore('tunnels');
        return Util.getUnusedPoolAddr(addressPool, store, 'peerAddress');
    },

    settingsChangeListener: function(field, newValue, settingField) {
        var app = Rpc.directData('rpc.UvmContext.appManager').app('wireguard-vpn'),
            currentFieldValue = app.getSettings()[settingField];

        var warningLabel = field.nextSibling('label[cls=warningLabel]'),
            metaData = warningLabel.getEl();

        if (newValue != currentFieldValue) {
            warningLabel.setHtml('<span class="fa fa-exclamation-triangle" style="color: orange;"></span>');
            metaData.set({
                'data-qtip': 'Clients will need to configure their connections'.t(),
            });
            warningLabel.show();
        } else {
            warningLabel.hide();
        }
    }
});

Ext.define('Ung.apps.reports.cmp.Ung.apps.wireguard-vpn.cmp.WireGuardVpnTunnelGridController', {
    extend: 'Ung.cmp.GridController',

    alias: 'controller.unwireguardvpntunnelgrid',

    remoteConfigDisabled: function(view, rowIndex, colIndex, item, record){
        if(record.get('id') == "" || record.get('id') == -1){
            return true;
        }
        return false;
    },

    getRemoteConfig: function(unk1, unk2, unk3, event, unk5, record){
        var v = this.getView();
        var dialog = v.add({
            xtype: 'app-wireguard-vpn-remote-config',
            title: 'Remote Configuration'.t(),
            record: record
        });
        // NGFW-13550 - show dialog centered on screen
        // dialog.setPosition(event.getXY());
        dialog.show();
    }
});

Ext.define('Ung.apps.wireguard-vpn.cmp.WireGuardVpnTunnelRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unwireguardvpntunnelrecordeditor',
    alias: 'widget.unwireguardvpntunnelrecordeditor',
    itemId: 'unwireguardvpntunnelrecordeditor',

    controller: 'unwireguardvpntunnelrecordeditorcontroller'
});

Ext.define('Ung.apps.wireguard-vpn.cmp.WireGuardVpnTunnelRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unwireguardvpntunnelrecordeditorcontroller',

    control: {
        '#unwireguardvpntunnelrecordeditor': {
            afterrender: 'afterTunnelsEditorRender'
        }
    },

    pasteTunnel: function(component){
        if(!component.target ||
           !component.target.dataset ||
           !component.target.dataset.componentid){
            return;
        }
        var el = Ext.getCmp(component.target.dataset.componentid);
        if(!el){
            return;
        }
        var view = el.up('unwireguardvpntunnelrecordeditor'),
            controller = view.getController(),
            record = view.record;
        if(record.get('id') != -1){
            // Only on a new record.
            return;
        }

        var remote = {};
        try{
            remote = JSON.parse(component.event.clipboardData.getData("text/plain"));
        }catch(e){
            return;
        }

        var remoteToRecordTask = new Ext.util.DelayedTask( Ext.bind(function(){
            if(Util.isDestroyed(remote, record)){
                return;
            }
            record.set('description', remote['hostname']);
            record.set('endpointDynamic', false);
            Ext.Object.each(remote, function(key, value){
                /* Backwards compatibility from 16.3 */
                if (key == 'endpointAddress') {
                    key = 'endpointHostname';
                }
                if(key in record.data){
                    record.set(key, value);
                }
            });
            record.set('networks',record.get('networks').split(/\s*,\s*/).join("\r\n"));
        }, view) );
        remoteToRecordTask.delay( 150 );
    },

    // get next pool address
    getNextUnusedPoolAddr: function(){
        var me = this,
        grid = this.mainGrid,
        store = grid.getStore(),
        addressPool = grid.up('panel').up('apppanel').getViewModel().get('settings.addressPool');
        return Util.getUnusedPoolAddr(addressPool, store, 'peerAddress');
    },

    // Override onAfterRender so we can prepopulate the peerAddress field with the next
    // available address from the wireguard tunnel address pool.  We loop through the
    // existing tunnels to make sure we select an address that isn't already used.  After
    // setting the peerAddress, we then call the default onAfterRender.
    onAfterRender: function (view) {
        var me = this,
            grid = this.mainGrid, vm = this.getViewModel(),
            record = vm.get('record');

        this.callParent([view]);

        // Set routed networks from the profiles selected for a tunnel dynamically
        var rnProfileList;
        if(record.get('routedNetworkProfiles')) {
            rnProfileList = record.get('routedNetworkProfiles').list;
        }
        me.setRoutedNetworksFromProfiles(rnProfileList, vm, record);
        view.down('form').add(
            Ung.apps['wireguard-vpn'].Main.hostDisplayFields(true, !record.get('markedForNew'), true)
        );

        view.getEl().on('paste', me.pasteTunnel);
    },

    endpointTypeComboChange: function(combo, newValue, oldValue){
        var me = this,
            record = me.getViewModel().get('record');
            form = combo.up('form');

        form.down('[itemId=publicKey]').allowBlank = newValue;
        form.down('[itemId=publicKey]').validate();

        var peerAddress = record.get('peerAddress');
        if(newValue && !peerAddress){
            // Dynamic
            record.set('peerAddress', me.getNextUnusedPoolAddr());
        } else if(!newValue && peerAddress){
            // Static
            if(record.get('markedForNew')){
                if(peerAddress == me.getNextUnusedPoolAddr()){
                    record.set('peerAddress', '');
                }
            }
        }
    },

    afterTunnelsEditorRender: function() {
        var v = this.getView(),
            vm = this.getViewModel(),
            items = [],
            routedNetworks = v.down('#routednetworkscbgroup'),
            localNetProfiles = vm.get('settings.networkProfiles.list');

        // Add all the Local Networks Profiles from settings page as checkboxes
        // to be selected as Routed Network Profiles on tunnel add/edit window
        localNetProfiles.forEach(function(profile) {
            items.push({
                boxLabel: profile.profileName,
                name: 'list', 
                inputValue: profile.profileName,
                autoEl: {
                    tag: 'div',
                    'data-qtip': profile.subnetsAsString
                }
            });
        });
        routedNetworks.add(items);
    },

    /**
     * listener for Routed Network Profiles change 
     */
    onRoutednetworkscbgroupChange: function(checkboxgroup, newValue, oldValue, eOpts) {
        var editor = checkboxgroup.up('unwireguardvpntunnelrecordeditor'),
            record = editor.record,
            form = editor.down('form'),
            localServiceInfo = form && form.down('#localserviceinfo');

        if (localServiceInfo) {
            form.remove(localServiceInfo, true);  // autoDestroy = true
        }

        this.setRoutedNetworksFromProfiles(newValue.list, record);
        var newCmp = Ung.apps['wireguard-vpn'].Main.hostDisplayFields(true, false, true );

        if (form) form.add(newCmp);

    },

    /**
     * Sets the routedNetworks from selected profile names in tunnel store
     */
    setRoutedNetworksFromProfiles: function(profiles, record) {
        var vm = this.getViewModel(),
            localNetProfiles = vm.get('settings.networkProfiles.list'),
            routedNetworks = "",
            networksList = [];

        if(profiles) {
            if(typeof profiles === 'string') {
                profiles = [ profiles ];
            }

            localNetProfiles.forEach(function(profile) {
                if(profiles.indexOf(profile.profileName) !== -1) {
                    var newList = profile.subnetsAsString.split(',');
                    for (var i = 0; i < newList.length; i++) {
                        var net = newList[i].trim();
                        if (net && networksList.indexOf(net) === -1) {
                            networksList.push(net);
                        }
                    }
                }
            });
            routedNetworks = networksList.join(',');
        }   

        vm.set('localNetworkList', routedNetworks);
        record.set('routedNetworks', routedNetworks);
    }
});
Ext.define('Ung.apps.wireguard-vpn.RemoteConfig', {
    extend: 'Ext.window.Window',
    alias: 'widget.app-wireguard-vpn-remote-config',
    renderTo: Ext.getBody(),
    constrain: true,

    scrollable: true,

    onEsc: Ext.emptyFn,
    closable: false,
    modal: true,

    controller: 'app-wireguard-vpn-remote-config',

    viewModel:{
        data: {
            minDate: null,
            maxDate: null
        }
    },

    bodyStyle: {
        background: 'white'
    },

    // NGFW-13550 give a predefined width/height for the dialog
    layout: 'fit',
    width: 500,
    height: 500,

    items: [{
        xtype: 'panel',

        bodyStyle: {
            "background-color": 'white'
        },
        bodyPadding: 10,
        border: false,
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        scrollable: true,
        // NGFW-13550 - move type selection into a docked toolbar
        dockedItems: [{
            xtype: 'toolbar',
            dock: 'top',
            padding: 10,
            items: [{
                fieldLabel: 'Type'.t(),
                xtype: 'combobox',
                editable: false,
                hidden: false,
                bind:{
                    value: '{type}',
                    hidden: '{error}',
                },
                queryMode: 'local',
                store: [
                    [ 'qrcode', 'Quick Reference Code'.t()],
                    [ 'file', 'Configuration File'.t()]
                ],
                forceSelection: true,
            }]
        }],
        items:[{
            // NGFW-13550 - put qr-code image in a container so it's not stretched by above layout stretch
            xtype: 'container',
            layout: 'center',
            items: [{
                xtype: 'panel',
                border: false,
                itemId: 'qrcode',
                alt: 'Quick Reference Code'.t(),
                autoCreate: true,
            }],
            hidden: true,
            bind: {
                hidden: '{type != "qrcode" || error ? true : false}',
            },
        },{
            xtype: 'copytoclipboard',
            left: 'true',
            value:{
                key: 'html',
                stripPrefix: '<pre>',
                stripSuffix: '</pre>'
            },
            items:[{
                xtype: 'component',
                itemId: 'file',
                html: '',
                flex: 1,
            }],
            hidden: true,
            bind: {
                hidden: '{type != "file" || error? true : false}',
            },
        },{
            xtype: 'component',
            style: {
                'color': 'red',
                'font-weight': 'bold'
            },
            html: 'Unable to retrieve configuration'.t(),
            hidden: true,
            bind: {
                hidden: '{!error}',
            }
        }]
    }],

    buttons: [{
        text: 'Close'.t(),
        iconCls: 'fa fa-ban',
        handler: 'closeWindow'
    }]
});
Ext.define('Ung.apps.wireguard-vpn.RemoteconfigController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-wireguard-vpn-remote-config',

    control: {
        '#': {
            afterrender: 'afterrender'
        }
    },

    afterrender: function(view){
        var me = this,
            vm = me.getViewModel(),
            appManager = view.up('app-wireguard-vpn').appManager,
            publicKey = view.record.get('publicKey'),
            qrcodeImage = view.down('[itemId=qrcode]'),
            configFile = view.down('[itemId=file]');

        view.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(appManager, 'createRemoteQrCode', publicKey),
            Rpc.asyncPromise(appManager, 'getRemoteConfig', publicKey)
        ], this).then( function(result){
            if(Util.isDestroyed(view)){
                return;
            }

            if(result[0] == ""){
                vm.set('error', true);
            }else{
                vm.set('error', false);
                view.down('[itemId=qrcode]').setHtml(result[0]);
                view.down('[itemId=file]').setHtml('<pre>' + result[1] + '</pre>');
            }

            view.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(view)){
                view.setLoading(false);
            }
            Util.handleException(ex);
        });

        vm.set('type', 'qrcode');
    },

    closeWindow: function (button) {
        button.up('window').close();
    },

});
Ext.define('Ung.apps.wireguard-vpn.view.Settings', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wireguard-vpn-settings',
    itemId: 'settings',
    title: 'Settings'.t(),
    scrollable: true,

    withValidation: true,
    padding: '8 5',

    defaults: {
        labelWidth: 200
    },

    items: [{
        xtype: 'fieldcontainer',
        layout: 'hbox',
        items: [{
            fieldLabel: 'Listen port'.t(),
            xtype: 'textfield',
            vtype: 'isSinglePortValid',
            maxLength: 5,
            enforceMaxLength :true,
            bind: {
                value: '{settings.listenPort}'
            },
            allowBlank: false,
            labelWidth: 200,
            padding: '8 5 5 0',
            listeners: {
                change: function(field, newValue, oldValue) {
                    this.up('app-wireguard-vpn').getController().settingsChangeListener(field, newValue, 'listenPort');
                }
            }
        },{
            xtype: 'label',
            cls: 'warningLabel',
            hidden: true,
            margin: '18 0 5 5'
        }]
    },{
        fieldLabel: 'Keepalive interval'.t(),
        xtype: 'textfield',
        maxLength: 5,
        bind: {
            value: '{settings.keepaliveInterval}'
        },
        regex: RegExp("^[1-9]\\d*$"),
        regexText: 'Only accepts valid positive integer.'.t(),
        allowBlank: false
    },{
        xtype: 'fieldcontainer',
        layout: 'hbox',
        items: [{
            fieldLabel: 'MTU'.t(),
            xtype: 'textfield',
            vtype: 'mtu',
            bind: {
                value: '{settings.mtu}'
            },
            allowBlank: false,
            labelWidth: 200,
            padding: '8 5 5 0',
            listeners: {
                change: function(field, newValue, oldValue) {
                    this.up('app-wireguard-vpn').getController().settingsChangeListener(field, newValue, 'mtu');
                }
            }
        },{
            xtype: 'label',
            cls: 'warningLabel',
            hidden: true,
            margin: '18 0 5 5'
        }],
    }, {
        xtype: "checkbox",
        bind: '{settings.mapTunnelDescUser}',
        fieldLabel: 'Set authenticated username as tunnel description'.t(),
        padding: '8 5 5 0',
        autoEl: {
            tag: 'div',
            'data-qtip': "If enabled, tunnel description will be set as authenticated user".t()
        },
        checked: false
    }, {
        xtype: 'fieldset',
        title: 'Remote Client Configuration'.t(),
        layout: {
            type: 'vbox'
        },
        defaults: {
            labelWidth: 190,
            padding: "0 0 10 0"
        },
        items:[{
            xtype: 'textfield',
            fieldLabel: 'DNS Server'.t(),
            vtype: 'ipMatcher',
            bind: {
                value: '{settings.dnsServer}'
            }
        },{
            xtype: 'textfield',
            fieldLabel: 'DNS Search Domains'.t(),
            bind: {
                value: '{settings.dnsSearchDomain}'
            },
            emptyText: '[no domain]'.t()
        },{
            xtype: 'fieldcontainer',
            layout: 'hbox',
            items: [{
                xtype: 'label',
                text: 'Local Network Profiles:'.t(),
                width: 195
            },{
                xtype: 'ungrid',
                itemId: 'localNetworkGrid',
                tbar: ['@addInline'],
                recordActions: ['delete'],
                listProperty: 'settings.networkProfiles.list',
                width: 562,
                bind: '{networkProfiles}',
                restrictedRecords: {
                    keyMatch: 'reserved',
                    valueMatch: true
                },
                listeners: {
                    cellclick: function(grid,td,cellIndex,record,tr,rowIndex,e,eOpts)  {
                        if (record.data.profileName === 'Full Tunnel') { 
                            record.set('reserved', true);
                            return false; 
                        }
                    },
                    afterrender: function(grid) {
                        Ext.Function.defer(function() { 
                            var store = grid.getStore();
                            store.each(function(record) {
                                if(record.get('profileName') === 'Full Tunnel')
                                    record.set('reserved', true);
                            });
                        }, 2000);
                    }
                },
                emptyRow: {
                    javaClass: 'com.untangle.app.wireguard_vpn.WireGuardVpnNetworkProfile',
                    profileName: 'DefaultProfileName',
                    subnetsAsString: '10.0.0.0/24,10.1.0.0/24',
                },
                columns: [{
                    dataIndex: 'profileName',
                    header: 'Profile Name',
                    width: 200,
                    editor:{
                        xtype: 'textfield',
                        allowBlank: false,
                        emptyText: '[enter profile name]'.t(),
                        blankText: 'Invalid profile name'.t(),
                        validator: function(value) {
                            var grid = this.up('grid[itemId=localNetworkGrid]'),
                                store = grid.getStore(),
                                record = grid.getSelectionModel().getSelection()[0];
                            var me = this,
                                defaultProfileName = me.up('#settings').down("#localNetworkGrid").initialConfig.emptyRow.profileName;
                            if(value == defaultProfileName) return 'Change default profile name.'.t();
                            // Check if a record with the same name exists in the store
                            var isNameUnique = store.findBy(function(profile) {
                                if(record === profile) return false;
                                return profile.get('profileName') === value;
                            });
                            return isNameUnique === -1 ? true : 'Profile name already exists.'.t();
                        }
                    }
                }, {
                    dataIndex: 'subnetsAsString',
                    header: 'Network Addresses',
                    width: 300,
                    flex: 1,
                    renderer: function(value) {
                        var qtip = value ? value.replace(/,\s*/g, ', ') : '';
                        return '<span data-qtip="' + Ext.String.htmlEncode(qtip) + '">' +
                               Ext.String.htmlEncode(value) +
                               '</span>';
                    },
                    editor:{
                        xtype: 'textfield',
                        vtype: 'cidrBlockList',
                        allowBlank: false,
                        emptyText: '[enter comma seperated networks]'.t(),
                        blankText: 'Invalid address specified'.t(),
                        validator: function(value) {
                            try{
                                var isValidVtypeField = Ext.form.field.VTypes[this.vtype](value);
                                if(!isValidVtypeField) return true;

                                networks = value.split(',');
                                profileNets = [];
                                for(var i=0; i < networks.length; i++) {
                                    if(profileNets.indexOf(networks[i]) !== -1) return 'Duplicate networks in the profile'.t();
                                    if(profileNets.length > 0) {
                                        res = Util.findIpPoolConflict(networks[i], profileNets, this, true);
                                        if(res != true) return res; 
                                    } 
                                    profileNets.push(networks[i]);

                                    var res = Util.networkValidator(networks[i]);
                                    if(res != true) return res;

                                    var me = this,
                                        settings = me.up('#settings'),
                                        peerNetworkIp = settings.down('#peerNetworkIp').getValue(),
                                        localNetworkStore = [];

                                    if(peerNetworkIp) localNetworkStore.push(peerNetworkIp);

                                    res = Util.findIpPoolConflict(networks[i], localNetworkStore, this, true);
                                    if(res != true) return res;
                                }    
                                return true;                          
                            } catch(err) {
                                console.log(err);
                                return true;
                            }                        
                        }
                    },
                }]
            }, {
                xtype: 'label',
                cls: 'warningLabel',
                margin: '13 0 5 25',
                html: '<span class="fa fa-exclamation-triangle" style="color: orange;" data-qtip="On profile name edit clients will need to configure their connections!"></span>'
            }]
        }]
    }, {
        xtype: 'fieldset',
        title: 'Peer IP Address Pool'.t(),
        layout: {
            type: 'vbox'
        },
        defaults: {
            labelWidth: 190
        },
        items:[{
            fieldLabel: 'Assignment'.t(),
            xtype: 'combobox',
            bind: {
                value: '{settings.autoAddressAssignment}'
            },
            editable: false,
            queryMode: 'local',
            store: [
                [true, 'Automatic'.t()],
                [false, 'Self-assigned'.t()]
            ],
            forceSelection: true
        },{
            xtype: 'fieldcontainer',
            layout: 'hbox',
            defaults: {
                labelWidth: 190
            },
            items: [{
                    fieldLabel: 'Network Space'.t(),
                    xtype: 'textfield',
                    vtype: 'cidrAddr',
                    itemId: 'peerNetworkIp',
                    bind: {
                        value: '{settings.addressPool}',
                        disabled: '{settings.autoAddressAssignment}',
                        editable: '{!settings.autoAddressAssignment}'
                    },
                    listeners: {
                        change: function(field, newValue, oldValue) {
                            this.up('app-wireguard-vpn').getController().settingsChangeListener(field, newValue, 'addressPool');
                        }
                    },
                    validator: function(value) {
                        try{
                            var isValidVtypeField = Ext.form.field.VTypes[this.vtype](value);
                            if(!isValidVtypeField){
                                return true;
                            }

                            // Ensure the network is in a private IP range
                            if (!Util.isPrivateCIDR(value)) {
                                return "Only private IP ranges are allowed (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)";
                            }
                            var localNetworkStoreFn = this.up('#settings').down('#localNetworkGrid').getStore();

                            var localNetworkStore = [];
                            
                            localNetworkStoreFn.each(function (profile){
                                if(profile.get("subnetsAsString")){
                                    var subnets = profile.get("subnetsAsString").split(',');
                                    for (var i = 0; i < subnets.length; i++) {
                                        var subnet = subnets[i].trim();
                                        if (subnet !== "0.0.0.0/0" && localNetworkStore.indexOf(subnet) === -1) {
                                            localNetworkStore.push(subnet);
                                        }
                                    }
                                }
                            });
                            return Util.findIpPoolConflict(value, localNetworkStore, this, true);

                        } catch(err) {
                            console.log(err);
                            return true;
                        }                        
                    }
                },
                {
                    xtype:'button',
                    text: 'New Network Space'.t(),
                    bind:{
                        disabled: '{!settings.autoAddressAssignment}'
                    },
                    listeners: {
                        click: 'getNewAddressSpace'
                    }
                },{
                    xtype: 'label',
                    cls: 'warningLabel',
                    hidden: true,
                    margin: '10 0 5 10'
                }
            ]
        }]
    }]
});
Ext.define('Ung.apps.wireguard-vpn.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wireguard-vpn-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,

        layout: {
            type: 'vbox',
            align: 'stretch'
        },

        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/wireguard-vpn.svg" width="80" height="80"/>' +
                '<h3>WireGuard VPN</h3>' +
                '<p>' + 'WireGuard VPN provides secure network access and tunneling to remote users and sites using the WireGuard VPN protocol.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        },
        {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'Enabled Tunnels'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'component',
                margin: '0 0 10 0',
                hidden: true,
                bind: {
                    html: '{warning}',
                    hidden: '{!warning}'
                }
            },{
                xtype: 'ungrid',
                itemId: 'tunnelStatus',
                enableColumnHide: true,
                stateful: true,
                trackMouseOver: false,
                resizable: true,
                defaultSortable: true,

                emptyText: 'No Active WireGuard Tunnels'.t(),

                bind: {
                    store: '{tunnelStatusList}'
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'Interface'.t(),
                    dataIndex: 'interface',
                    width: Renderer.idWidth,
                    filter: Renderer.stringFilter,
                    hidden: true
                }, {
                    header: 'Description'.t(),
                    dataIndex: 'tunnel-description',
                    width: Renderer.messageWidth,
                    filter: Renderer.stringFilter,
                    flex: 1
                }, {
                    header: 'Peer Public Key'.t(),
                    dataIndex: 'peer-key',
                    width: Renderer.messageWidth,
                    filter: Renderer.stringFilter,
                    flex: 1,
                    hidden: true
                }, {
                    header: 'Remote Endpoint'.t(),
                    dataIndex: 'configured-endpoint',
                    width: Renderer.ipWidth + Renderer.portWidth
                }, {
                    header: 'Detected Endpoint'.t(),
                    dataIndex: 'endpoint',
                    width: Renderer.ipWidth + Renderer.portWidth,
                    hidden: true
                }, {
                    header: 'Remote Networks'.t(),
                    dataIndex: 'allowed-ips',
                    width: Renderer.networkWidth,
                }, {
                    header: 'Last Handshake'.t(),
                    dataIndex: 'latest-handshake',
                    width: Renderer.timestampWidth,
                    renderer: Ung.apps['wireguard-vpn'].Main.statusHandshakeRenderer,
                    filter: Renderer.timestampFilter
                }, {
                    header: 'Keepalive'.t(),
                    dataIndex: 'persistent-keepalive',
                    width: Renderer.messageWidth,
                    hidden: true
                }, {
                    header: 'Bytes In'.t(),
                    dataIndex: 'transfer-rx',
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize
                }, {
                    header: 'Bytes Out'.t(),
                    dataIndex: 'transfer-tx',
                    width: Renderer.sizeWidth,
                    renderer: Renderer.datasize
                }],
                bbar: ['@refresh', '@reset']
            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        layout: 'fit',
        items: [{
            xtype: 'appmetrics',
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }],

    listeners: {
        activate: 'getTunnelStatus'
    }

});
Ext.define('Ung.apps.wireguard-vpn.view.Tunnels', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wireguard-vpn-tunnels',
    itemId: 'tunnels',
    title: 'Tunnels'.t(),
    scrollable: true,

    withValidation: true,
    padding: '8 5',

    items: [{
        xtype: 'app-wireguard-vpn-server-tunnels-grid',
    }]
});

Ext.define('Ung.apps.wireguard-vpn.cmp.TunnelsGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-wireguard-vpn-server-tunnels-grid',
    itemId: 'server-tunnels-grid',
    viewModel: true,

    controller: 'unwireguardvpntunnelgrid',

    emptyText: 'No tunnels defined'.t(),

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '-', { xtype: 'ungridfilter', store: 'tunnels' }, '->', '@import', '@export']
    }],
    plugins: [ 'gridfilters', {
        ptype: 'cellediting',
        clicksToEdit: 1
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',
    copyModify: [{
        key: 'publicKey',
        value: '',
    },{
        key: 'peerAddress',
        value: function() {
            var wirgrdVpnCmp = Ext.ComponentQuery.query('[alias=widget.app-wireguard-vpn]')[0];
            if(wirgrdVpnCmp)
                return wirgrdVpnCmp.getController().getNextUnusedPoolAddr();
            else return '';
        }
    }],

    listProperty: 'settings.tunnels.list',
    emptyRow: {
        'javaClass': 'com.untangle.app.wireguard_vpn.WireGuardVpnTunnel',
        'id': -1,
        'enabled': true,
        'description': '',
        'publicKey': '',
        'endpointDynamic': true,
        'endpointHostname': '',
        'endpointPort': 51820,
        'peerAddress': '',
        'networks': '',
        'pingInterval': 60,
        'pingConnectionEvents': true,
        'pingUnreachableEvents': false,
        'assignDnsServer': false,
        'routedNetworkProfiles': {
            'javaClass': 'java.util.LinkedList',
            'list': []
        },
        'routedNetworks':''
    },

    importValidationJavaClass: true,

    bind: '{tunnels}',

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'description',
        filter: Renderer.stringFilter
    }, {
        header: 'Remote Public Key'.t(),
        width: 290,
        dataIndex: 'publicKey',
    }, {
        header: 'Remote Peer IP Address'.t(),
        width: Renderer.ipWidth,
        dataIndex: 'peerAddress',
        editor: {
            xtype: 'textfield',
            allowBlank: false,
            vtype: 'isSingleIpValid',
            emptyText: '[enter peer IP address]'.t(),
            validator: function(value) {
                return peerIpAddrValidator(value, 'peerAddress', this, 'app-wireguard-vpn-server-tunnels-grid');
            }
        },
        filter: Renderer.stringFilter
    }, {
        header: 'Remote Networks'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'networks',
        filter: Renderer.stringFilter
    }, {
        header: 'Remote Endpoint'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'endpointDynamic',
        renderer: Ung.apps['wireguard-vpn'].Main.dynamicEndpointRenderer,
        filter: Renderer.booleanFilter
    }, {
        header: 'Hostname'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'endpointHostname',
        renderer: Ung.apps['wireguard-vpn'].Main.dynamicEndpointRenderer,
        filter: Renderer.stringFilter
    }, {
        header: 'Port'.t(),
        width: Renderer.portWidth,
        dataIndex: 'endpointPort',
        renderer: Ung.apps['wireguard-vpn'].Main.dynamicEndpointRenderer,
        filter: Renderer.numericFilter
    }, {
        xtype: 'actioncolumn',
        header: 'Remote Client'.t(),
        width: Renderer.messageWidth,
        iconCls: 'fa fa-cog',
        align: 'center',
        handler: 'getRemoteConfig',
        isDisabled: 'remoteConfigDisabled'
    }],

    editorXtype: 'ung.cmp.unwireguardvpntunnelrecordeditor',
    editorFields: [{
        xtype: 'checkbox',
        fieldLabel: 'Enabled'.t(),
        bind: '{record.enabled}'
    }, {
        xtype: 'textfield',
        fieldLabel: 'Description'.t(),
        allowBlank: false,
        bind: {
            value: '{record.description}'
        },
        validator: function(value, component) {
            if(component === undefined)
                    component = this;
            return Util.isUnique(value, 'tunnel', 'description', component, 'app-wireguard-vpn-server-tunnels-grid');
        }
    }, {
        xtype: 'textfield',
        itemId: 'publicKey',
        vtype: 'wireguardPublicKey',
        fieldLabel: 'Remote Public Key'.t(),
        bind: {
            value: '{record.publicKey}'
        },
        validator: function(value, component) {
            if(component == undefined){
                component = this;
            }
            return Util.isUnique(value, 'tunnel', 'publicKey', component, 'app-wireguard-vpn-server-tunnels-grid');
        }
    }, {
        xtype: 'fieldset',
        title: 'Remote Endpoint'.t(),
        layout: {
            type: 'vbox'
        },
        defaults: {
            labelWidth: 170,
            labelAlign: 'right'
        },
        items:[{
            fieldLabel: 'Type'.t(),
            xtype: 'combobox',
            editable: false,
            bind: {
                value: '{record.endpointDynamic}'
            },
            queryMode: 'local',
            store: [
                [true, 'Roaming'.t()],
                [false, 'Static'.t()]
            ],
            forceSelection: true,
            listeners: {
                change: 'endpointTypeComboChange'
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Hostname'.t(),
            hidden: true,
            disabled: true,
            allowBlank: false,
            vtype: 'hostName',
            bind: {
                value: '{record.endpointHostname}',
                hidden: '{record.endpointDynamic}',
                disabled: '{record.endpointDynamic}'
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Port'.t(),
            vtype: 'isSinglePortValid',
            hidden: true,
            disabled: true,
            allowBlank: false,
            bind: {
                value: '{record.endpointPort}',
                hidden: '{record.endpointDynamic}',
                disabled: '{record.endpointDynamic}'
            }
        }]
    }, {
        xtype: 'textfield',
        fieldLabel: 'Remote Peer IP Address'.t(),
        vtype: 'isSingleIpValid',
        allowBlank: false,
        bind: {
            value: '{record.peerAddress}'
        },
        validator: function(value, component) {
            if(component == undefined){
                component = this;
            }
            return peerIpAddrValidator(value, 'peerAddress', component, 'app-wireguard-vpn-server-tunnels-grid');
        }
    }, {
        xtype: 'textarea',
        fieldLabel: 'Remote Networks'.t(),
        vtype: 'cidrBlockArea',
        allowBlank: true,
        width: 250,
        height: 50,
        bind: {
            value: '{record.networks}'
        },
        validator: function(value, component) {
            try{
                var isValidVtypeField = Ext.form.field.VTypes[this.vtype](value);
                var peerNetworkIp ;
                if(!isValidVtypeField){
                    return true;
                }
                
                var remoteNetworks = value;
                
                if(remoteNetworks.trim().length<=0){
                    return true;
                }
                if(component === undefined){
                    peerNetworkIp  = this.up("app-wireguard-vpn").getViewModel().get("settings").addressPool;
                }else{
                    peerNetworkIp  = component.getView().up().up().getViewModel()._data.settings.addressPool;
                }
                var localNetworkStore = remoteNetworks.length > 0 ? Ext.Array.map(remoteNetworks.split("\n"),function (remoteIpAddr){
                    return remoteIpAddr.trim();
                }) : [];
                
                return Util.findIpPoolConflict(peerNetworkIp, localNetworkStore, this, false);

            } catch(err) {
                console.log(err);
                return true;
            }                        
        }
    }, {
        xtype: 'checkboxgroup',
        fieldLabel: 'Routed Network Profiles'.t(),
        useParentDefinition: true,
        // labelWidth: 155,
        itemId: 'routednetworkscbgroup',
        bind: {
            value: '{record.routedNetworkProfiles}'
        },
        listeners: {
            change: 'onRoutednetworkscbgroupChange'
        },
        columns: 3,
        vertical: true
    }, {
        xtype: 'checkbox',
        fieldLabel: 'Assign DNS Server'.t(),
        bind: {
            value: '{record.assignDnsServer}',
            hidden: '{!record.endpointDynamic}',
            disabled: '{!record.endpointDynamic}'
        }
    }, {
        xtype: 'fieldset',
        title: 'Monitor'.t(),
        padding: 10,
        layout: {
            type: 'vbox'
        },
        bind: {
            hidden: '{record.endpointDynamic}'
        },
        defaults: {
            labelWidth: 170,
            labelAlign: 'right'
        },
        items:[{
            xtype: 'textfield',
            fieldLabel: 'Ping IP Address'.t(),
            allowBlank: true,
            vtype: 'isSingleIpValid',
            bind: {
                value: '{record.pingAddress}',
            }
        }, {
            xtype: 'numberfield',
            fieldLabel: 'Ping Interval'.t(),
            allowBlank: false,
            allowDecimals: false,
            minValue: 0,
            maxValue: 300,
            bind: {
                value: '{record.pingInterval}',
                disabled: '{!record.pingAddress}'
            }
        },{
            xtype: 'checkbox',
            fieldLabel: 'Alert on Tunnel Up/Down'.t(),
            bind: {
                value: '{record.pingConnectionEvents}',
                disabled: '{!record.pingAddress}'
            }
        },{
            xtype: 'checkbox',
            fieldLabel: 'Alert on Ping Unreachable'.t(),
            bind: {
                value: '{record.pingUnreachableEvents}',
                disabled: '{!record.pingAddress}'
            }
        }]
    }]
});

function isUnique(value, field, component) {
    var currentRecord ;
    if(component.getId().indexOf('textfield') !== -1){
    if(component.up('window')!=undefined)
         currentRecord = component.up('window').getViewModel().data.record.get(field);
    if (value === currentRecord) {
        return true;
    }
    //Return true if editable field peerAddress in grid is not modified
    if(!component.dirty && field === 'peerAddress') {
        return true; 
    }
    }
    var grid = Ext.ComponentQuery.query('app-wireguard-vpn-server-tunnels-grid')[0];
    var store = grid.getStore();

    var isNameUnique = store.findBy(function(record) {
        return record.get(field) === value;
    }) === -1;
    
    return isNameUnique? true : Ext.String.format('A tunnel with this {0} already exists.'.t(), field);
}


function isIPAddressUnderNWRange(value, component) { 
    var wirgrdVpnCmp = Ext.ComponentQuery.query('[alias=widget.app-wireguard-vpn]')[0];
    var addrpool;
    if(wirgrdVpnCmp)
        unusedPoolAddr =  wirgrdVpnCmp.getController().getNextUnusedPoolAddr();
    if(component.getId().indexOf('textfield') !== -1){
         addrpool = component.up('tabpanel').getViewModel().data.originalSettings.addressPool;
    }else{
         addrpool = component.getView().up().up().getViewModel()._data.settings.addressPool;
    }
    var subnet = addrpool.split('/')[1];
    var pool = addrpool.split('/')[0];
    netMask = Util.getV4NetmaskMap()[subnet ? subnet: 32];
    network = Util.getNetwork(pool, netMask); 
    //Flag to check if IP address is reserved for WG Interface
    isReservedForWGInterface = Util.convertIPIntoDecimal(value) < Util.convertIPIntoDecimal(Util.incrementIpAddr(pool, 2));
    if (unusedPoolAddr === '' &&  value === '') {
        return 'No more pool addresses are available in the address pool.'.t();
    }else if(!Util.isIPInRange(value, network, netMask) ||  isReservedForWGInterface) {
        return 'Please ensure that the entered IP address is within the specified subnet IP range.'.t();
    } else{
        return true;
    }       
}

function peerIpAddrValidator(value, field, component, grid) {
    var uniqueError = Util.isUnique(value, 'tunnel', field, component, grid);
    if (uniqueError !== true) {
        return uniqueError;
    } else {
        return true;
    }
}