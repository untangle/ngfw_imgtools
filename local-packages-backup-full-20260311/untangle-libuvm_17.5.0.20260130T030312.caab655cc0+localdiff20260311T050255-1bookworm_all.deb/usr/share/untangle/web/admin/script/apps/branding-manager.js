Ext.define('Ung.apps.brandingmanager.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-branding-manager',
    controller: 'app-branding-manager',

    items: [
        { xtype: 'app-branding-manager-status' },
        { xtype: 'app-branding-manager-settings' }
    ]

});
Ext.define('Ung.apps.brandingmanager.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-branding-manager',

    needRackReload: false,
    originalDefaultLogo: true,

    control: {
        '#': {
            afterrender: 'getSettings',
        }
    },

    getSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(me, v, vm)){
                return;
            }

            vm.set('settings', result);
            me.originalDefaultLogo = vm.get('settings').defaultLogo;

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        if(me.originalDefaultLogo !== vm.get('settings').defaultLogo){
            me.needRackReload = true;
        }

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);

            if(me.needRackReload){
                window.location.reload();
            }
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    onUpload: function( field, value, eOpts){
        var formPanel = this.getView().down('form[name=upload_logo_form]');
        var fileField = formPanel.down('filefield');

        if (fileField.getValue().length === 0) {
            Ext.MessageBox.alert('Failed'.t(), 'Please select an image to upload.'.t() );
            return false;
        }

        formPanel.getForm().submit({
            waitMsg: 'Please wait while your logo image is uploaded...'.t(),
            success: Ext.bind(function(form, action) {
                this.needRackReload = true;
                Ext.MessageBox.alert( 'Succeeded'.t(), 'Upload Logo Succeeded.'.t(),
                    function() {
                        fileField.reset();
                    }
                );
            }, this),
            failure: Ext.bind(function(form, action) {
                Ext.MessageBox.alert( 'Failed'.t(), 'Upload Logo Failed. The logo must be the correct dimensions and in GIF, PNG, or JPG format.'.t() );
            }, this)
        });

        return true;
    }

});
Ext.define('Ung.apps.brandingmanager.view.Settings', {
    extend: 'Ext.form.Panel',
    alias: 'widget.app-branding-manager-settings',
    itemId: 'settings',
    title: 'Settings'.t(),
    scrollable: true,

    bodyPadding: 10,
    withValidation: true,

    items:[{
        title: 'Logo'.t(),
        items: [{
            xtype: 'radiogroup',
            columns: 1,
            simpleValue: true,
            bind: '{settings.defaultLogo}',
            items:[{
                xtype: 'radio',
                boxLabel: 'Use Default Logo'.t(),
                inputValue: true
            }, {
                xtype: 'radio',
                boxLabel: 'Use Custom Logo. Maximum size is 166 x 100.'.t(),
                inputValue: false
            }]
        },{
            xtype: 'form',
            bodyStyle: 'padding:0px 0px 0px 25px',
            name: 'upload_logo_form',
            url: 'upload',
            border: false,

            disabled: true,
            hidden: true,
            bind: {
                hidden: '{settings.defaultLogo == true}',
                disabled: '{settings.defaultLogo == true}'
            },

            items: [{
                xtype: 'filefield',
                label: 'Logo'.t(),
                name: 'logo',
                accept: 'image/*',
                buttonText: 'Select Image...'.t(),
                width: 300,
                listeners: {
                    change: 'onUpload'
                }
            },{
                xtype: 'hidden',
                name: 'type',
                value: 'logo'
            }]
        }]
    },{
        title: 'Contact Information'.t(),
        defaults: {
            labelWidth: 150,
            width: 500
        },
        items: [{
            xtype: 'textfield',
            fieldLabel: 'Company Name'.t(),
            name: 'Company Name',
            allowBlank: true,
            bind: '{settings.companyName}',
        },{
            xtype: 'textfield',
            fieldLabel: 'Company URL'.t(),
            name: 'Company URL',
            allowBlank: true,
            bind: '{settings.companyUrl}',
        },{
            xtype: 'textfield',
            fieldLabel: 'Contact Name'.t(),
            name: 'Contact Name',
            allowBlank: true,
            bind: '{settings.contactName}'
        },{
            xtype: 'textfield',
            fieldLabel: 'Contact Email'.t(),
            name: 'contact_email',
            allowBlank: true,
            vtype: 'email',
            bind: '{settings.contactEmail}',
        }]
      },{
        title: 'Banner Message'.t(),
        defaults: {
            labelWidth: 150,
            width: 500
        },
        items:[{
            xtype: "textarea",
            allowBlank: true,
            name: "bannerMessage",
            height: 100,
            fieldLabel: 'Message Text'.t(),
            bind: '{settings.bannerMessage}'
        }]
    }]
});
Ext.define('Ung.apps.brandingmanager.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-branding-manager-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    items: [{
        border: false,
        bodyPadding: 10,
        scrollable: true,
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/branding-manager.svg" width="80" height="80"/>' +
                '<h3>Branding Manager</h3>' +
                '<p>' + 'The Branding Settings are used to set the logo and contact information that will be seen by users (e.g. reports).'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appremove'
        }]
    }]
});
