Ext.define('Ung.apps.sslinspector.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-ssl-inspector',
    controller: 'app-ssl-inspector',

    viewModel: {

        data: {
            autoRefresh: false,
            trustedCertData: []
        },

        stores: {
            ignoreRules: { data: '{settings.ignoreRules.list}' },
            trustedCertList: { data: '{trustedCertData}' }
        }
    },

    items: [
        { xtype: 'app-ssl-inspector-status' },
        { xtype: 'app-ssl-inspector-configuration' },
        { xtype: 'app-ssl-inspector-rules' }
    ]

});
Ext.define('Ung.apps.sslinspector.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-ssl-inspector',

    control: {
        '#': {
            afterrender: 'onAfterRender'
        }
    },

    onAfterRender: function () {
        var vm = this.getViewModel();

        Rpc.asyncData('rpc.UvmContext.certificateManager.validateActiveInspectorCertificates')
        .then(function (result) {
            if(Util.isDestroyed(vm)){
                return;
            }
            vm.set('serverCertificateVerification', result);
        }, function (ex) {
            Util.handleException(ex);
        });
        this.getSettings();
        this.getTrustedCerts();
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

           vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }
        
        v.query('ungrid').forEach(function (grid) {
            if (grid.listProperty) {
                var store = grid.getStore();
                if (store.getModifiedRecords().length > 0 ||
                    store.getNewRecords().length > 0 ||
                    store.getRemovedRecords().length > 0 ||
                    store.isReordered) {
                    store.each(function (record) {
                        if (record.get('markedForDelete')) {
                            record.drop();
                        }
                    });
                    store.isReordered = undefined;
                    vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
                }
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getTrustedCerts: function() {
        var v = this.getView(), vm = this.getViewModel();

        Rpc.asyncData(v.appManager, 'getTrustCatalog')
        .then(function(result){
            if(Util.isDestroyed(vm)){
                return;
            }
            vm.set('trustedCertData', result.list);
        }, function(ex) {
            Util.handleException(ex);
        });
    },

    uploadTrustedCertificate: function(view, row, colIndex, item, e, record) {
        this.uploadCertificateWin = Ext.create('Ext.Window', {
            title: "Upload Trusted Certificate".t(),
            layout: 'fit',
            modal: true,
            width: 600,
            height: 200,
            autoScroll: true,
            items: [{
                xtype: "form",
                name: "upload_trusted_cert_form",
                url: "upload",
                items: [{
                    xtype: 'filefield',
                    fieldLabel: "File".t(),
                    name: "filename",
                    margin: "10 10 10 10",
                    width: 560,
                    labelWidth: 50,
                    allowBlank: false,
                    validateOnBlur: false
                }, {
                    xtype: 'textfield',
                    fieldLabel: "Alias".t(),
                    name: "argument",
                    margin: "10 10 10 10",
                    width: 200,
                    labelWidth: 50,
                    allowBlank: false
                }, {
                    xtype: "button",
                    text: "Upload Certificate".t(),
                    width: 200,
                    margin: "10 10 10 80",
                    handler: Ext.bind(function() {
                        this.handleFileUpload();
                    }, this)
                }, {
                    xtype: "button",
                    text: "Cancel".t(),
                    width: 200,
                    margin: "10 10 10 10",
                    handler: Ext.bind(function() {
                        this.uploadCertificateWin.close();
                    }, this)
                }, {
                    xtype: "hidden",
                    name: "type",
                    value: "trusted_cert"
                    }]
                }]
        });

        this.uploadCertificateWin.show();
    },

    handleFileUpload: function() {
        var me = this;
        var form = this.uploadCertificateWin.down('form[name="upload_trusted_cert_form"]');
        var fileText = form.down('filefield[name="filename"]');
        var nameText = form.down('textfield[name="argument"]');
        if (fileText.getValue().length === 0) {
            Ext.MessageBox.alert("Invalid or missing File".t(), "Please select a certificate to upload.".t());
            return false;
            }
        if (nameText.getValue().length === 0) {
            Ext.MessageBox.alert("Invalid or missing Alias".t(), "Please enter a unique alias or nickname for the certificate.".t());
            return false;
        }

        form.submit({
            waitMsg: "Inspecting File...".t(),
            success: Ext.bind(function(form, action) {
                this.uploadCertificateWin.close();
                me.getTrustedCerts();
            }, this),
            failure: Ext.bind(function(form, action) {
                this.uploadCertificateWin.close();
                Ext.MessageBox.alert("Upload Failure".t(), action.result.msg);
            }, this)
        });
        return true;
    },

    statics:{
        actionRenderer: function(action){
            switch (action.actionType) {
                case 'INSPECT': return 'Inspect'.t();
                case 'IGNORE': return 'Ignore'.t();
                default: return 'Unknown Action'.t() + ': ' + act;
            }
        }
    }

});

Ext.define('Ung.apps.sslinspector.SpecialGridController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.app-sslinspector-special',

    deleteTrustedCertificate: function(view, row, colIndex, item, e, record) {
        var me = this, v = this.getView();

        v.setLoading('Deleting Certificate...'.t());
        Rpc.asyncData(view.up('apppanel').appManager, 'removeTrustedCertificate', record.get("certAlias"))
        .then(function(result){
            if(Util.isDestroyed(me, v)){
                return;
            }
            setTimeout(function() {
                if(Util.isDestroyed(me, v)){
                    return;
                }
                me.getView().up('app-ssl-inspector').getController().getTrustedCerts();
                v.setLoading(false);
            },500);

        }, function(ex) {
            Util.handleException(ex);
        });
    },
});
Ext.define('Ung.apps.sslinspector.view.Configuration', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ssl-inspector-configuration',
    itemId: 'configuration',
    title: 'Configuration'.t(),
    bodyPadding: 10,
    withValidation: false,
    scrollable: true,

    viewModel: {
    },

    defaults: {
        border: false
    },

    items: [{
        title: "Description".t(),
        xtype: 'fieldset',
        padding: '10 0 10 0',
        html: "The SSL Inspector is an SSL decryption engine that allows other applications and services to process port 443 HTTPS and port 25 SMTPS traffic just like unencrypted port 80 HTTP and port 25 SMTP traffic. To do this, the application generates new SSL certificates on the fly which it uses to perform a the man-in-the-middle style inspection of traffic. To eliminate certificate security warnings on client computers and devices, you should download the root certificate and add it to the list of trusted authorities on each client connected to your network.".t()
    }, {
        xtype: 'fieldset',
        layout: 'column',
        items: [{
            xtype: 'button',
            margin: '0 5 0 5',
            width: 250,
            text: "Download Root Certificate".t(),
            iconCls: 'fa fa-download',
            handler: Ext.bind(function() {
                var downloadForm = document.getElementById('downloadForm');
                downloadForm["type"].value = "certificate_download";
                downloadForm["arg1"].value = "root";
                downloadForm.submit();
            }, this)
        },{
            xtype: 'displayfield',
            margin: '0 5 0 5',
            columnWidth: 1,
            value: "Click here to download the root certificate.".t(),
        }]
    }, {
        title: "Options".t(),
        xtype: 'fieldset',
        labelWidth: 230,
        padding: '10 0 0 0',
        items: [{
            xtype: 'checkbox',
            fieldLabel: "Enable SMTPS Traffic Processing".t(),
            labelWidth: 240,
            bind: '{settings.processEncryptedMailTraffic}'
        },{
            xtype: 'checkbox',
            fieldLabel: "Enable HTTPS Traffic Processing".t(),
            labelWidth: 240,
            bind: '{settings.processEncryptedWebTraffic}'
        },{
            xtype: 'checkbox',
            fieldLabel: "Block Invalid HTTPS Traffic".t(),
            labelWidth: 240,
            bind: '{settings.blockInvalidTraffic}'
        },{
            xtype: 'displayfield',
            padding: '0 0 0 20',
            value:  "When the SSL Inspector detects non-HTTPS traffic on port 443, it will normally ignore this traffic and allow it to flow unimpeded.  If you enable this checkbox, non-HTTPS traffic will instead be blocked.".t()
        }]
    }, {
        xtype: 'fieldset',
        padding: '10 0 10 0',
        layout: { type: 'hbox', align: 'left' },
        defaults: {
            margin: '0 0 0 30',
            labelWidth: 60
        },
        title: "Client Connection Protocols".t(),
        items: [{
            xtype: 'checkbox',
            fieldLabel: "SSLv2Hello".t(),
            labelWidth: 70,
            name: 'client_SSLv2Hello',
            bind: '{settings.client_SSLv2Hello}'
        },{
            xtype: 'checkbox',
            fieldLabel: "SSLv3".t(),
            labelWidth: 40,
            name: 'client_SSLv3',
            bind: '{settings.client_SSLv3}'
        },{
            xtype: 'checkbox',
            fieldLabel: "TLSv1".t(),
            labelWidth: 40,
            name: 'client_TLSv10',
            bind: '{settings.client_TLSv10}'
        },{
            xtype: 'checkbox',
            fieldLabel: "TLSv1.1".t(),
            name: 'client_TLSv11',
            bind: '{settings.client_TLSv11}'
        },{
            xtype: 'checkbox',
            fieldLabel: "TLSv1.2".t(),
            name: 'client_TLSv12',
            bind: '{settings.client_TLSv12}'
        },
        {
            xtype: 'checkbox',
            fieldLabel: "TLSv1.3".t(),
            name: 'client_TLSv13',
            bind: '{settings.client_TLSv13}'
        }]
    }, {
        xtype: 'fieldset',
        padding: '10 0 10 0',
        layout: { type: 'hbox', align: 'left' },
        defaults: {
            margin: '0 0 0 30',
            labelWidth: 60
        },
        title: "Server Connection Protocols".t(),
        items: [{
            xtype: 'checkbox',
            fieldLabel: "SSLv2Hello".t(),
            labelWidth: 70,
            name: 'server_SSLv2Hello',
            bind: '{settings.server_SSLv2Hello}'
        },{
            xtype: 'checkbox',
            fieldLabel: "SSLv3".t(),
            labelWidth: 40,
            name: 'server_SSLv3',
            bind: '{settings.server_SSLv3}'
        },{
            xtype: 'checkbox',
            fieldLabel: "TLSv1".t(),
            labelWidth: 40,
            name: 'server_TLSv10',
            bind: '{settings.server_TLSv10}'
        },{
            xtype: 'checkbox',
            fieldLabel: "TLSv1.1".t(),
            name: 'server_TLSv11',
            bind: '{settings.server_TLSv11}'
        },{
            xtype: 'checkbox',
            fieldLabel: "TLSv1.2".t(),
            name: 'server_TLSv12',
            bind: '{settings.server_TLSv12}'
        },
        {
            xtype: 'checkbox',
            fieldLabel: "TLSv1.3".t(),
            name: 'server_TLSv13',
            bind: '{settings.server_TLSv13}'
        }]
    }, {
        xtype: 'fieldset',
        padding: '10 0 10 0',
        title: "Server Trust".t(),
        labelWidth: 230,
        items: [{
            xtype: 'checkbox',
            fieldLabel: "Trust All Server Certificates".t(),
            labelWidth: 200,
            name: 'serverBlindTrust',
            bind: '{settings.serverBlindTrust}'
        },{
            xtype: 'displayfield',
            padding: '0 100 10 20',
            value:  "When this check box is enabled, the inspector will blindly trust all server certificates.  When clear, the inspector will only trust server certificates signed by a well known and trusted root certificate authority, or certificates that you have added to the list below.".t()
        }, {
            xtype: 'button',
            text: "Upload Trusted Certificate".t(),
            margin: '0 20 0 20',
            handler: 'uploadTrustedCertificate',
        }, {
            xtype: 'displayfield',
            margin: '10 20 0 20',
            value:  "<b>NOTE:</b> When uploading or deleting trusted certificates, changes are applied immediately.".t()
        }, {
            xtype: 'app-ssl-inspector-trusted-certs-grid',
            padding: '10 20 0 20'
        }]
    }]

});

Ext.define('Ung.apps.sslinspector.view.TrustedCertsGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-ssl-inspector-trusted-certs-grid',
    itemId: 'trusted-certs-grid',
    title: "Trusted Certificates &nbsp;&nbsp; (click any cell to see details)".t(),
    viewModel: true,
    controller: 'app-sslinspector-special',
    bind: '{trustedCertList}',

    emptyText: 'No Trusted Certificates'.t(),

    columns: [{
        header: 'Alias'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'certAlias'
    }, {
        header: 'Issued To'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'issuedTo',
    }, {
        header: 'Issued By'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'issuedBy'
    }, {
        header: 'Date Valid'.t(),
        width: Renderer.dateWidth,
        dataIndex: 'dateValid'
    }, {
        header: 'Date Expires'.t(),
        width: Renderer.dateWidth,
        dataIndex: 'dateExpire'
    }, {
        header: 'Delete'.t(),
        xtype: 'actioncolumn',
        width: Renderer.actionWidth,
        align: 'center',
        iconCls: 'fa fa-trash',
        handler: 'deleteTrustedCertificate'
    }]
});
Ext.define('Ung.apps.sslinspector.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-ssl-inspector-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Ignore rules are used to configure traffic which should be ignored by the inspection engine.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    listProperty: 'settings.ignoreRules.list',

    emptyText: 'No Rules defined'.t(),
    
    importValidationJavaClass: true,
    importValidationForComboBox: true,
    nestedFieldsArr: {
        fields: ["action"],
        extraConfig: { flag: { xtype: "checkbox" } }
    },

    emptyRow: {
        ruleId: 0,
        enabled: true,
        description: '',
        action: {
            actionType: 'IGNORE',
            javaClass: 'com.untangle.app.ssl_inspector.SslInspectorRuleAction',
            flag: true
        },
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.ssl_inspector.SslInspectorRule'
    },

    bind: '{ignoreRules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions,
    {
        header: 'Action'.t(),
        dataIndex: 'action',
        width: Renderer.actionWidth,
        renderer: Ung.apps.sslinspector.MainController.actionRenderer
    }],

    // todo: continue this stuff
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.ssl_inspector.SslInspectorRuleCondition', [
            'DST_ADDR',
            'DST_PORT',
            'DST_INTF',
            'SRC_ADDR',
            'SRC_PORT',
            'SRC_INTF',
            'PROTOCOL',
            'TAGGED',
            'USERNAME',
            'HOST_HOSTNAME',
            'CLIENT_HOSTNAME',
            'SERVER_HOSTNAME',
            'SRC_MAC',
            'DST_MAC',
            'CLIENT_MAC_VENDOR',
            'SERVER_MAC_VENDOR',
            'CLIENT_IN_PENALTY_BOX',
            'SERVER_IN_PENALTY_BOX',
            'HOST_HAS_NO_QUOTA',
            'USER_HAS_NO_QUOTA',
            'CLIENT_HAS_NO_QUOTA',
            'SERVER_HAS_NO_QUOTA',
            'HOST_QUOTA_EXCEEDED',
            'USER_QUOTA_EXCEEDED',
            'CLIENT_QUOTA_EXCEEDED',
            'SERVER_QUOTA_EXCEEDED',
            'HOST_QUOTA_ATTAINMENT',
            'USER_QUOTA_ATTAINMENT',
            'CLIENT_QUOTA_ATTAINMENT',
            'SERVER_QUOTA_ATTAINMENT',
            'HOST_ENTITLED',
            'HTTP_USER_AGENT',
            'HTTP_USER_AGENT_OS',
            'DIRECTORY_CONNECTOR_GROUP',
            'DIRECTORY_CONNECTOR_DOMAIN',
            'SSL_INSPECTOR_SNI_HOSTNAME',
            'SSL_INSPECTOR_SUBJECT_DN',
            'SSL_INSPECTOR_ISSUER_DN',
            'CLIENT_COUNTRY',
            'SERVER_COUNTRY',
            'THREAT_PREVENTION_SRC_REPUTATION',
            'THREAT_PREVENTION_DST_REPUTATION',
            'THREAT_PREVENTION_SRC_CATEGORIES',
            'THREAT_PREVENTION_DST_CATEGORIES',
        ]), {
            xtype: 'combo',
            name: 'action',
            fieldLabel: 'Action Type'.t(),
            bind: '{_action.actionType}',
            allowBlank: false,
            editable: false,
            store: [['INSPECT', 'Inspect'.t()], ['IGNORE', 'Ignore'.t()]],
            queryMode: 'local'
        }
    ]
});
Ext.define('Ung.apps.sslinspector.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ssl-inspector-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/ssl-inspector.svg" width="80" height="80"/>' +
                '<h3>SSL Inspector</h3>' +
                '<p>' + 'SSL Inspector allows for full decryption of HTTPS and SMTPS so that other applications can process the encrypted streams.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'component',
            bind: { html: '{serverCertificateVerification}' }
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'center',
            height: 200
        }, {
            xtype: 'appmetrics',
            region: 'south',
            split: true,
            height: 'auto'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]

});
