Ext.define('Ung.apps.bandwidthcontrol.ConfWizard', {
    extend: 'Ext.window.Window',
    alias: 'widget.app-bandwidth-control-wizard',
    title: '<i class="fa fa-magic"></i> ' + 'Bandwidth Control Setup Wizard'.t(),
    modal: true,

    controller: 'app-bandwidth-control-wizard',
    viewModel: {
        type: 'app-bandwidth-control-wizard'
    },

    width: 800,
    height: 450,

    layout: 'card',

    defaults: {
        border: false,
        scrollable: 'y',
        bodyPadding: 10
    },

    items: [{
        title: 'Welcome'.t(),
        header: false,
        itemId: 'welcome',
        layout: {
            type: 'vbox'
        },
        items: [{
            xtype: 'component',
            html: '<h2>' + 'Welcome to the Bandwidth Control Setup Wizard!'.t() + '</h2>',
        }, {
            xtype: 'component',
            html: '<p>' + 'This wizard will help guide you through your initial setup and configuration of Bandwidth Control.'.t() + '</p>',
        }, {
            xtype: 'component',
            html: '<p>' + 'Bandwidth Control leverages information provided by other applications in the rack.'.t() + '</p><ul>' +
                '<li>' + 'Web Filter (non-Lite) provides web site categorization.'.t() + '</li>' +
                '<li>' + 'Application Control provides protocol profiling categorization.'.t() + '</li>' +
                '<li>' + 'Application Control Lite provides protocol profiling categorization.'.t() + '</li>' +
                '<li>' + 'Directory Connector provides username/group information.'.t() + '</li></ul>' +
                '<p><strong>' + 'For optimal Bandwidth Control performance install these applications.'.t() + '</strong></p>'
        }, {
            xtype: 'component',
            html: '<i class="fa fa-exclamation-triangle fa-red"></i> ' + 'WARNING: Completing this setup wizard will overwrite the previous settings with new settings. All previous settings will be lost!'.t()
        }]
    }, {
        title: 'WAN Bandwidth'.t(),
        header: false,
        itemId: 'wan',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'component',
            html: '<h2>' + 'Configure WANs download and upload bandwidths'.t() + '</h2>'
        }, {
            xtype: 'component',
            html: '<p>' + Ext.String.format('{0}Note:{1} When enabling QoS valid Download Bandwidth and Upload Bandwidth limits must be set for all WAN interfaces.'.t(), '<font color="red">','</font>') + '<br/>' +
                'It is suggested to set these around 95% to 100% of the actual measured bandwidth available for each WAN.'.t() + '</p>',
        }, {
            xtype: 'component',
            bind: {
                html: '<p><i class="fa fa-exclamation-triangle fa-red"></i> <span style="color: red;">' + 'WARNING: These settings must be reasonably accurate for Bandwidth Control to operate properly!'.t() + '</span> </p>' +
                    '<p>{bandwidthLabel}</p>'
            }
        }, {
            xtype: 'ungrid',
            trackMouseOver: false,
            sortableColumns: false,
            enableColumnHide: false,

            emptyText: 'No WAN Interfaces defined'.t(), 
            plugins: {
                ptype: 'cellediting',
                clicksToEdit: 1
            },

            bind: {
                store: {
                    data: '{interfaces}',
                    filters: [
                        { property: 'configType', value: 'ADDRESSED' },
                        { property: 'isWan', value: true }
                    ]
                }
            },

            columns: [{
                header: 'Interface Id'.t(),
                align: 'right',
                width: Renderer.idWidth,
                resizable: false,
                dataIndex: 'interfaceId'
            }, {
                header: 'WAN'.t(),
                width: Renderer.messageWidth,
                flex: 1,
                dataIndex: 'name'
            }, {
                header: 'Download Bandwidth'.t(),
                width: Renderer.sizeWidth,
                flex: 1,
                resizable: false,
                dataIndex: 'downloadBandwidthKbps',
                editor: {
                    xtype: 'numberfield',
                    allowBlank : false,
                    allowDecimals: false,
                    minValue: 0
                },
                renderer: function (value) {
                    return Ext.isEmpty(value) ? 'Not set'.t() : (value + ' ' + 'kbps'.t());
                }
            }, {
                header: 'Upload Bandwidth'.t(),
                width: Renderer.sizeWidth,
                flex: 1,
                resizable: false,
                dataIndex: 'uploadBandwidthKbps',
                editor: {
                    xtype: 'numberfield',
                    allowBlank : false,
                    allowDecimals: false,
                    minValue: 0
                },
                renderer: function (value) {
                    return Ext.isEmpty(value) ? 'Not set'.t() : (value + ' ' + 'kbps'.t());
                }
            }]
        }]
    }, {
        title: 'Configuration'.t(),
        header: false,
        itemId: 'configuration',
        items: [{
            xtype: 'component',
            html: '<h2>' + 'Choose a starting configuration'.t() + '</h2>'
        }, {
            xtype: 'component',
            html: '<p>' + 'Several initial default configurations are available for Bandwidth Control. Please select the environment most like yours below.'.t() + '</p>',
        }, {
            xtype: 'combo',
            fieldLabel: 'Configuration'.t(),
            margin: 10,
            editable: false,
            bind: '{selectedConf}',
            store: [
                ['business_business', 'Business'.t()],
                ['school_school', 'School'.t()],
                ['school_college', 'College/University'.t()],
                ['business_government', 'Government'.t()],
                ['business_nonprofit', 'Non-Profit'.t()],
                ['school_hotel', 'Hotel'.t()],
                ['home', 'Home'.t()],
                ['metered', 'Metered Internet'.t()],
                ['custom', 'Custom'.t()]
            ]
        }, {
            xtype: 'component',
            margin: 10,
            bind: {
                html: '{confDetails}'
            }
        }]
    }, {
        title: 'Quotas'.t(),
        header: false,
        itemId: 'quotas',
        items: [{
            xtype: 'component',
            html: '<h2>' + 'Configure Quotas'.t() + '</h2>'
        }, {
            xtype: 'component',
            html: '<p>' + 'Quotas for bandwidth can be set for hosts and users. This allows some hosts/users to be allocated high bandwidth, as long as it is remains within a certain usage quota; however, their bandwidth will be slowed if their quota is exceeded.'.t() + '</p>'
        }, {
            xtype: 'fieldset',
            checkboxToggle: true,
            checkbox: {
                bind: {
                    value: '{quota.enabled}'
                }
            },
            collapsible: true,
            title: 'Enable Quotas'.t(),
            margin: 10,
            padding: 10,
            items: [{
                xtype: "checkbox",
                bind: "{quota.hostEnabled}",
                fieldLabel: "Enable Quotas for Hosts (IP addresses)".t(),
                labelWidth: 250,
                checked: true
            }, {
                xtype: "checkbox",
                bind: "{quota.userEnabled}",
                fieldLabel: "Enable Quotas for Users (usernames)".t(),
                labelWidth: 250,
                checked: true
            }, {
                xtype: 'component',
                margin: '10 0 5 0',
                html: '<strong>' + 'Quota Expiration'.t() + '</strong><br/>' +
                    '<span style="font-size: 11px; color: #555;">' + 'controls how long a quota lasts (hourly, daily, weekly). The default is Daily.'.t() + '</span>'
            }, {
                xtype: 'combo',
                allowBlank: false,
                editable: false,
                forceSelection: false,
                store: [
                    [-4, 'End of Month'.t()], //END_OF_MONTH
                    [-3, 'End of Week'.t()], //END_OF_WEEK
                    [-2, 'End of Day'.t()], //END_OF_DAY
                    [-1, 'End of Hour'.t()] //END_OF_HOUR
                ],
                queryMode: 'local',
                bind: '{quota.expiration}'
            }, {
                xtype: 'component',
                margin: '10 0 5 0',
                html: '<strong>' + 'Quota Size'.t() + '</strong><br/>' +
                    '<span style="font-size: 11px; color: #555;">' + 'configures the size of the quota given to each host. The default is 1 Gb.'.t() + '</span>'
            }, {
                xtype: 'container',
                // width: 200,
                layout: {
                    type: 'hbox'
                },
                items: [{
                    xtype: 'numberfield',
                    allowBlank: false,
                    width: 80,
                    bind: '{quota.size}'
                }, {
                    xtype: 'combo',
                    margin: '0 0 0 5',
                    width: 100,
                    editable: false,
                    store: [
                        [1, 'bytes'.t()],
                        [1024, 'Kilobytes'.t()],
                        [1024*1024, 'Megabytes'.t()],
                        [1024*1024*1024, 'Gigabytes'.t()],
                        [1024*1024*1024*1024, 'Terrabytes'.t()]
                    ],
                    queryMode: 'local',
                    bind: '{quota.unit}'
                }]
            }, {
                xtype: 'component',
                margin: '10 0 5 0',
                html: '<strong>' + 'Quota Exceeded Priority'.t() + '</strong><br/>' +
                    '<span style="font-size: 11px; color: #555;">' + 'configures the priority given to hosts that have exceeded their quota.'.t() + '</span>'
            }, {
                xtype: 'combo',
                allowBlank: false,
                width: 200,
                editable: false,
                store: [
                    [1, 'Very High'.t()],
                    [2, 'High'.t()],
                    [3, 'Medium'.t()],
                    [4, 'Low'.t()],
                    [5, 'Limited'.t()],
                    [6, 'Limited More'.t()],
                    [7, 'Limited Severely'.t()]
                ],
                queryMode: 'local',
                bind: '{quota.priority}'
            }]
        }]
    }, {
        title: 'Finish'.t(),
        header: false,
        itemId: 'finish',
        items: [{
            xtype: 'component',
            html: '<h2>' + 'Congratulations'.t() + '</h2>'
        }, {
            xtype: 'component',
            html: '<p><strong>' + 'Bandwidth Control is now configured and enabled.'.t() + '</strong></p>'
        }]
    }],

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'bottom',
        ui: 'footer',
        defaults: {
            minWidth: 200
        },
        items: [{
            hidden: true,
            bind: {
                text: 'Previous'.t() + ' - <strong>' + '{prevBtnText}' + '</strong>',
                hidden: '{!prevBtn}'
            },
            iconCls: 'fa fa-chevron-circle-left',
            handler: 'onPrev'
        }, '->',  {
            hidden: true,
            bind: {
                text: 'Next'.t() + ' - <strong>' + '{nextBtnText}' + '</strong>',
                hidden: '{!nextBtn}'
            },
            iconCls: 'fa fa-chevron-circle-right',
            iconAlign: 'right',
            handler: 'onNext'
        }, {
            text: 'Close'.t(),
            hidden: true,
            bind: {
                hidden: '{nextBtn}'
            },
            iconCls: 'fa fa-check',
            handler: 'onFinish'
        }]
    }]


});
Ext.define('Ung.apps.bandwidthcontrol.ConfWizardController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-bandwidth-control-wizard',

    control: {
        '#': {
            afterrender: 'onAfterRender'
        },
        'window > panel': {
            activate: 'onActivateCard'
        }
    },

    onAfterRender: function () {
        var me = this,
            vm = this.getViewModel();

        Rpc.asyncData('rpc.networkManager.getNetworkSettings')
        .then(function (result) {
            if(Util.isDestroyed(me, vm)){
                return;
            }
            me.networkSettings = result;
            vm.set('interfaces', result.interfaces.list);

            var u = 0, d = 0, intf;
            for (var i = 0 ; i < result.interfaces.list.length ; i++ ) {
                intf = result.interfaces.list[i];
                if (intf.isWan) {
                    u += intf.uploadBandwidthKbps || 0;
                    d += intf.downloadBandwidthKbps || 0;
                }
            }
            vm.set('bandwidthLabel', Ext.String.format('Total: {0} kbps ({1} Mbit) download, {2} kbps ({3} Mbit) upload'.t(), d, d/1000, u, u/1000));
        },function(ex){
            Util.handleException(ex);
        });
    },

    onActivateCard: function (panel) {
        var vm = this.getViewModel(),
            layout = this.getView().getLayout();

        vm.set('prevBtn', layout.getPrev());
        if (layout.getPrev()) {
            vm.set('prevBtnText', layout.getPrev().getTitle());
        }
        vm.set('nextBtn', layout.getNext());
        if (layout.getNext()) {
            vm.set('nextBtnText', layout.getNext().getTitle());
        }
    },

    onNext: function () {
        var v = this.getView(),
            vm = this.getViewModel(),
            activeItem = v.getLayout().getActiveItem();

        if (activeItem.getItemId() === 'welcome') {
            v.getLayout().next();
        }

        if (activeItem.getItemId() === 'wan') {
            var grid = activeItem.down('grid'),
                invalidValues = false;

            grid.getStore().each(function (intf) {
                if (
                    (!intf.get('downloadBandwidthKbps') || intf.get('downloadBandwidthKbps') === 0) ||
                    (!intf.get('uploadBandwidthKbps') || intf.get('uploadBandwidthKbps') === 0)) {
                    invalidValues = true;
                }
            });
            if (invalidValues) {
                Ext.Msg.alert('Warning'.t(), 'Invalid values'.t());
            } else {
                if (grid.getStore().getModifiedRecords().length > 0 || !this.networkSettings.qosSettings.qosEnabled) {
                    this.networkSettings.qosSettings.qosEnabled = true;
                    for(var i = 0; i < this.networkSettings.interfaces.list.length; i++) {
                        var intf = this.networkSettings.interfaces.list[i];
                        if(intf.isWan) {
                            intf.qosEnabled = true;
                        }
                    }

                    // the download/upload values were modified via binding
                    Ext.MessageBox.wait('Configuring WAN...'.t(), 'Please wait'.t());
                    Metrics.stop();
                    Rpc.asyncData('rpc.networkManager.setNetworkSettings', this.networkSettings)
                    .then(function () {
                        if(Util.isDestroyed(Metrics, v)){
                            return;
                        }
                        Metrics.start();
                        v.getLayout().next();
                    }).always(function () {
                        Ext.MessageBox.hide();
                    });
                } else {
                    v.getLayout().next();
                }
            }
        }
        if (activeItem.getItemId() === 'configuration') {
            var startConf = activeItem.down('combo').getValue();
            if (!startConf) {
                Ext.MessageBox.alert('Error'.t(), 'You must select a starting configuration.'.t());
                return;
            }
            Ext.MessageBox.wait('Configuring Settings...'.t(), 'Please wait'.t());
            this.getView().appManager.wizardLoadDefaults(function (result) {
                Ext.MessageBox.hide();
                v.getLayout().next();
            }, startConf.replace(/_.*/,''));
        }
        if (activeItem.getItemId() === 'quotas') {
            if (!vm.get('quota.enabled')) {
                v.getLayout().next();
                return;
            }

            Ext.MessageBox.wait('Configuring Quotas...'.t(), 'Please wait'.t());
            if (vm.get('quota.hostEnabled')) {
                this.getView().appManager.wizardAddHostQuotaRules(vm.get('quota.expiration'),
                                                                  Math.round(vm.get('quota.size') * vm.get('quota.unit')),
                                                                  vm.get('quota.priority'));
            }
            if (vm.get('quota.userEnabled')) {
                this.getView().appManager.wizardAddUserQuotaRules(vm.get('quota.expiration'),
                                                                  Math.round(vm.get('quota.size') * vm.get('quota.unit')),
                                                                  vm.get('quota.priority'));
            }

            Ext.MessageBox.hide();
            v.getLayout().next();
        }

    },

    onPrev: function () {
        var v = this.getView();
        if (v.getLayout().getPrev()) {
            v.getLayout().prev();
        }
    },

    onFinish: function () {
        // fire finish event to reload settings ant try to start app
        this.getView().fireEvent('finish');
        this.getView().close();
    }});
Ext.define('Ung.apps.bandwidthcontrol.ConfWizardModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.app-bandwidth-control-wizard',

    formulas: {
        selectedConf: {
            get: function () {
                return;
            },
            set: function (val) {
                var details = this.get('confs')[val], html = '<p>' + details.desc + '</p>';
                if (details.benefits) {
                    html += '<p style="font-weight: bold;">' + 'Benefits:'.t() + '</p><ul>';
                    details.benefits.forEach(function (val) { html += '<li>' + val + '</li>'; });
                    html += '</ul>';
                }
                if (details.prioritizes) {
                    html += '<p style="font-weight: bold;">' + 'Prioritizes:'.t() + '</p><ul>';
                    details.prioritizes.forEach(function (val) { html += '<li>' + val + '</li>'; });
                    html += '</ul>';
                }
                if (details.deprioritizes) {
                    html += '<p style="font-weight: bold;">' + 'De-prioritizes:'.t() + '</p><ul>';
                    details.deprioritizes.forEach(function (val) { html += '<li>' + val + '</li>'; });
                    html += '</ul>';
                }
                if (details.limits) {
                    html += '<p style="font-weight: bold;">' + 'Limits:'.t() + '</p><ul>';
                    details.limits.forEach(function (val) { html += '<li>' + val + '</li>'; });
                    html += '</ul>';
                }
                this.set('confDetails', html);
            }
        }
    },

    data: {
        // nextBtnText: 'WAN Bandwidth'.t(),

        quota: {
            enabled: false,
            hostEnabled: true,
            userEnabled: true,
            expiration: -2,
            size: 1,
            unit: 1024*1024*1024,
            priority: 6
        },

        confs: {
            business_business: {
                desc: 'This initial configuration provides common settings suitable for most small and medium-sized businesses.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used in businesses'.t(),
                    'de-prioritizes traffic of greedy non-work-related activities such as peer-to-peer file sharing'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when you need it most'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'any detected Peer-to-Peer traffic'.t(),
                    'all web traffic in violation of company policy'.t()
                ]
            },
            school_school: {
                desc: 'This initial configuration provides common settings suitable for most School Districts, Elementary through High Schools, or Charter Schools.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used in schools'.t(),
                    'prioritizes school-related traffic, such as traffic to Education sites or Search Engines'.t(),
                    'de-prioritizes traffic of greedy non-school-related activities such as peer-to-peer file sharing'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when you need it most'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'web traffic to download sites'.t(),
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'any detected Peer-to-Peer traffic'.t(),
                    'all web traffic in violation of school policy'.t()
                ]
            },
            school_college: {
                desc: 'This initial configuration provides common settings suitable for most Community Colleges, Universities, and associated Campus Networks.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used in schools'.t(),
                    'prioritizes school-related traffic, such as traffic to Education sites or Search Engines'.t(),
                    'de-prioritizes traffic of greedy non-school-related activities, peer-to-peer file sharing, or BitTorrent'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when you need it most'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'web traffic to download sites'.t(),
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'any detected Peer-to-Peer traffic'.t(),
                    'all web traffic in violation of school policy'.t()
                ],
                limits: [
                    'heavily limits BitTorrent usage'.t()
                ]
            },
            business_government: {
                desc: 'This initial configuration provides common settings suitable for most governmental organizations.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used in government'.t(),
                    'de-prioritizes traffic of greedy non-work-related activities, such as peer-to-peer file sharing'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when you need it most'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'any detected Peer-to-Peer traffic'.t(),
                    'all web traffic in violation of organization\'s policy'.t()
                ],
                limits: [
                    'heavily limits BitTorrent usage'.t()
                ]
            },
            business_nonprofit: {
                desc: 'This initial configuration provides common settings suitable for most charitable and not-for-profit organizations.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used in businesses'.t(),
                    'de-prioritizes traffic of greedy non-work-related activities, such as peer-to-peer file sharing'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when you need it most'.t(),
                    'saves money by controlling bandwidth'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'any detected Peer-to-Peer traffic'.t(),
                    'all web traffic in violation of organization\'s policy'.t()
                ]
            },
            school_hotel: {
                desc: 'This initial configuration provides common settings suitable for most Hotel and Motels.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used by guests'.t(),
                    'web traffic to business-related sites (Search Engines, Finance, Business/Services, etc)'.t(),
                    'de-prioritizes traffic of peer-to-peer file sharing'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when it is needed most'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'web traffic to download sites'.t(),
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'any detected Peer-to-Peer traffic'.t(),
                    'all web traffic in violation of policy'.t()
                ],
                limits: [
                    'heavily limits BitTorrent usage'.t()
                ]
            },
            home: {
                desc: 'This initial configuration provides common settings suitable for most home users and households.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used in households'.t(),
                    'prioritizes internet radio and video so that these services run flawlessly while downloads are running'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when you need it most'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'internet radio (e.g. Pandora&reg;,  Last.fm<small><sup>TM</sup></small>)'.t(),
                    'internet video (e.g. YouTube&reg;, Hulu<small><sup>TM</sup></small>, NetFlix&reg;)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'all web traffic in violation of the household policy'.t()
                ]
            },
            metered: {
                desc: 'This initial configuration provides common settings suitable for organizations that pay variable rates for bandwidth.'.t() + '<br/><br/>' +
                    'For organizations that have to pay bandwidth rates proportional to bandwidth usage or have significant overage fees, this configuration maximizes bandwidth available to important interactive services, while minimizing bandwidth use for other less important or background tasks.'.t(),
                benefits: [
                    'optimizes internet responsiveness by prioritizing traffic of interactive services most commonly used in organizations'.t(),
                    'de-prioritizes traffic of non-work-related activities, such as gaming, peer-to-peer file sharing, or online videos'.t(),
                    'de-prioritizes non-real-time background traffic, to avoid slowing your internet connection when you need it most'.t(),
                    'saves money'.t()
                ],
                prioritizes: [
                    'interactive traffic and services (Remote Desktop, Email, DNS, SSH)'.t(),
                    'interactive web traffic'.t()
                ],
                deprioritizes: [
                    'any detected Peer-to-Peer traffic'.t(),
                    'all web traffic in violation of the organization\'s policy'.t()
                ],
                limits: [
                    'non-real-time background services (e.g. Microsoft&reg; updates, backup services)'.t(),
                    'all web traffic to Download Sites'.t(),
                    'heavily limits BitTorrent usage'.t()
                ]
            },
            custom: {
                desc: 'This is a basic configuration with no rules set by default.'.t() + '<br/><br/>' +
                    'This is a good option for users who wish to build their own rules configuration from scratch.'.t()
            }
        }

    },
});
Ext.define('Ung.apps.bandwidthcontrol.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-bandwidth-control',
    controller: 'app-bandwidth-control',

    viewModel: {
        stores: {
            rules: { data: '{settings.rules.list}' }
        }
    },

    items: [
        { xtype: 'app-bandwidth-control-status' },
        { xtype: 'app-bandwidth-control-rules' }
    ]

});
Ext.define('Ung.apps.bandwidthcontrol.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-bandwidth-control',

    control: {
        '#': {
            afterrender: 'afterRender'
        }
    },

    afterRender: function () {
        this.getSettings();
        this.fetchQosData();
    },

    // use a callback function needed for config wizard
    getSettings: function (cb) {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.directPromise('rpc.networkManager.getNetworkSettings.qosSettings.qosEnabled')
        ],this).then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set({
                settings: result[0],
                isConfigured: result[0].configured,
                qosEnabled: result[1]
            });
            if (cb) {
                cb(vm.get('isConfigured'));
            }

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },
    
    /**
     * Method called to fetch the current value of qosEnabled
     */
    fetchQosData: function (){
        var v = this.getView(), vm = this.getViewModel();
        try{
            var qosEnabled = Rpc.directData('rpc.networkManager.getNetworkSettings.qosSettings.qosEnabled');
            vm.set("qosEnabled",qosEnabled);
        }catch (error){
            Util.handleException(error);
        }
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    runWizard: function (btn) {
        var me = this;
        me.wizard = me.getView().add({
            xtype: 'app-bandwidth-control-wizard',
            appManager: me.getView().appManager,
            listeners: {
                // when wizard is finished, reload settings and try to start the app
                finish: function () {
                    me.getSettings(function (configured) {
                        if (configured && !me.getViewModel().get('state.on')) {
                            me.getView().down('appstate').down('button').click();
                        }
                    });
                }
            }
        });
        me.wizard.show();
    },

    statics: {
        actionRenderer: function (value, metaData, record){
            if (typeof value === 'undefined') {
                return 'Unknown action'.t();
            }
            switch(value.actionType) {
                case 'SET_PRIORITY':
                    var priostr;
                    switch(value.priority) {
                        case 1: priostr = 'Very High'.t(); break;
                        case 2: priostr = 'High'.t(); break;
                        case 3: priostr = 'Medium'.t(); break;
                        case 4: priostr = 'Low'.t(); break;
                        case 5: priostr = 'Limited'.t(); break;
                        case 6: priostr = 'Limited More'.t(); break;
                        case 7: priostr = 'Limited Severely'.t(); break;
                        default: priostr = 'Unknown Priority'.t() + ': ' + value.priority; break;
                    }
                    var result = 'Set Priority'.t() + ' [' + priostr + ']';
                    return result;
                case 'TAG_HOST': return 'Tag Host'.t();
                case 'APPLY_PENALTY_PRIORITY': return 'Apply Penalty Priority'.t(); // DEPRECATED
                case 'GIVE_CLIENT_HOST_QUOTA': return 'Give Client a Quota'.t();
                case 'GIVE_HOST_QUOTA': return 'Give Host a Quota'.t();
                case 'GIVE_USER_QUOTA': return 'Give User a Quota'.t();
            default: return 'Unknown Action'.t() + ': ' + value;
        }
    }
    }
});
Ext.define('Ung.apps.bandwidthcontrol.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-bandwidth-control-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Rules are evaluated in-order on network traffic.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    listProperty: 'settings.rules.list',

    emptyText: 'No Rules defined'.t(),

    importValidationJavaClass: true,
    importValidationForComboBox: true,
    nestedFieldsArr: {
        fields: ["action"],
        nestedFieldCondn: {
            priority: function (value) { return value !== "SET_PRIORITY"; },
            quotaTime: function (value) { return value !== "GIVE_HOST_QUOTA" && value !== "GIVE_USER_QUOTA"; },
            quotaBytes: function (value) { return value !== "GIVE_HOST_QUOTA" && value !== "GIVE_USER_QUOTA"; },
            tagName: function (value) { return value !== "TAG_HOST"; },
            tagTime: function (value) { return value !== "TAG_HOST"; },
        },
        toCompareField: "actionType"
    },

    emptyRow: {
        ruleId: 0,
        enabled: true,
        description: '',
        action: {
            actionType: 'SET_PRIORITY',
            javaClass: 'com.untangle.app.bandwidth_control.BandwidthControlRuleAction',
            priority: 7,
            quotaBytes: null,
            quotaTime: null,
            tagName: null,
            tagTime: null
        },
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.bandwidth_control.BandwidthControlRule'
    },

    bind: '{rules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions,
    {
        header: 'Action'.t(),
        dataIndex: 'action',
        flex: 1,
        width: Renderer.messageWidth,
        renderer: Ung.apps.bandwidthcontrol.MainController.actionRenderer
    }],

    // todo: continue this stuff
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.bandwidth_control.BandwidthControlRuleCondition', [
            "DST_ADDR",
            "DST_PORT",
            "DST_INTF",
            "SRC_ADDR",
            "SRC_PORT",
            "SRC_INTF",
            "PROTOCOL",
            "TAGGED",
            "USERNAME",
            "HOST_HOSTNAME",
            "CLIENT_HOSTNAME",
            "SERVER_HOSTNAME",
            {
                name:"HOST_MAC",
                displayName: "Host MAC Address".t(),
                type: "textfield",
                allowBlank: false,
            },
            "SRC_MAC",
            "DST_MAC",
            {
                name:"HOST_MAC_VENDOR",
                displayName: "Host MAC Vendor".t(),
                type: "textfield",
                allowBlank: false,
            },
            "CLIENT_MAC_VENDOR",
            "SERVER_MAC_VENDOR",
            {
                name:"HOST_IN_PENALTY_BOX",
                displayName: "Host in Penalty Box".t(),
                type: "boolean",
                onlyTrue: true,
            },
            "CLIENT_IN_PENALTY_BOX",
            "SERVER_IN_PENALTY_BOX",
            "HOST_HAS_NO_QUOTA",
            "USER_HAS_NO_QUOTA",
            "CLIENT_HAS_NO_QUOTA",
            "SERVER_HAS_NO_QUOTA",
            "HOST_QUOTA_EXCEEDED",
            "USER_QUOTA_EXCEEDED",
            "CLIENT_QUOTA_EXCEEDED",
            "SERVER_QUOTA_EXCEEDED",
            "HOST_QUOTA_ATTAINMENT",
            "USER_QUOTA_ATTAINMENT",
            "CLIENT_QUOTA_ATTAINMENT",
            "SERVER_QUOTA_ATTAINMENT",
            'HOST_ENTITLED',
            "HTTP_HOST",
            "HTTP_REFERER",
            "HTTP_URI",
            "HTTP_URL",
            "HTTP_CONTENT_TYPE",
            "HTTP_CONTENT_LENGTH",
            "HTTP_USER_AGENT",
            "HTTP_USER_AGENT_OS",
            "APPLICATION_CONTROL_APPLICATION",
            "APPLICATION_CONTROL_CATEGORY",
            "APPLICATION_CONTROL_PROTOCHAIN",
            "APPLICATION_CONTROL_DETAIL",
            "APPLICATION_CONTROL_CONFIDENCE",
            "APPLICATION_CONTROL_PRODUCTIVITY",
            "APPLICATION_CONTROL_RISK",
            "PROTOCOL_CONTROL_SIGNATURE",
            "PROTOCOL_CONTROL_CATEGORY",
            "PROTOCOL_CONTROL_DESCRIPTION",
            "WEB_FILTER_CATEGORY",
            "WEB_FILTER_CATEGORY_DESCRIPTION",
            "WEB_FILTER_FLAGGED",
            "DIRECTORY_CONNECTOR_GROUP",
            'DIRECTORY_CONNECTOR_DOMAIN',
            {
                name:"REMOTE_HOST_COUNTRY",
                displayName: 'Remote Host Country'.t(),
                type: 'countryfield',
                importValidation: true,
            },
            "CLIENT_COUNTRY",
            "SERVER_COUNTRY",
            'THREAT_PREVENTION_SRC_REPUTATION',
            'THREAT_PREVENTION_SRC_CATEGORIES',
            'THREAT_PREVENTION_DST_REPUTATION',
            'THREAT_PREVENTION_DST_CATEGORIES'
        ]), {
            xtype: 'combo',
            reference: 'actionType',
            publishes: 'value',
            fieldLabel: 'Action Type'.t(),
            bind: '{_action.actionType}',
            allowBlank: false,
            editable: false,
            store: [
                ['SET_PRIORITY', 'Set Priority'.t()],
                ['TAG_HOST', 'Tag Host'.t()],
                ['GIVE_HOST_QUOTA', 'Give Host a Quota'.t()],
                ['GIVE_USER_QUOTA', 'Give User a Quota'.t()]
            ],
            queryMode: 'local',
        }, {
            xtype: 'combo',
            fieldLabel: 'Priority'.t(),
            hidden: true,
            disabled: true,
            bind: {
                value: '{_action.priority}',
                hidden: '{actionType.value !== "SET_PRIORITY"}',
                disabled: '{actionType.value !== "SET_PRIORITY"}'
            },
            allowBlank: false,
            editable: false,
            store:[
                [1, 'Very High'.t()],
                [2, 'High'.t()],
                [3, 'Medium'.t()],
                [4, 'Low'.t()],
                [5, 'Limited'.t()],
                [6, 'Limited More'.t()],
                [7, 'Limited Severely'.t()]
            ],
            queryMode: 'local',
        }, {
            xtype: 'combo',
            fieldLabel: 'Quota Expiration'.t(),
            hidden: true,
            disabled: true,
            bind: {
                value: '{_action.quotaTime}',
                hidden: '{actionType.value !== "GIVE_HOST_QUOTA" && actionType.value !== "GIVE_USER_QUOTA"}',
                disabled: '{actionType.value !== "GIVE_HOST_QUOTA" && actionType.value !== "GIVE_USER_QUOTA"}'
            },
            allowBlank: false,
            editable: true,
            store:[
             [-4, "End of Month".t()], //END_OF_MONTH from QuotaBoxEntry
             [-3, "End of Week".t()], //END_OF_WEEK from QuotaBoxEntry
             [-2, "End of Day".t()], //END_OF_DAY from QuotaBoxEntry
             [-1, "End of Hour".t()] //END_OF_HOUR from QuotaBoxEntry
            ],
            queryMode: 'local',
        }, {
            xtype: 'numberfield',
            fieldLabel: 'Quota Bytes'.t(),
            hidden: true,
            disabled: true,
            bind: {
                value: '{_action.quotaBytes}',
                hidden: '{actionType.value !== "GIVE_HOST_QUOTA" && actionType.value !== "GIVE_USER_QUOTA"}',
                disabled: '{actionType.value !== "GIVE_HOST_QUOTA" && actionType.value !== "GIVE_USER_QUOTA"}'
            },
            allowBlank: false,
            editable: true,
        }, {
            xtype: 'textfield',
            fieldLabel: 'Tag Name'.t(),
            hidden: true,
            disabled: true,
            bind: {
                value: '{_action.tagName}',
                hidden: '{actionType.value !== "TAG_HOST"}',
                disabled: '{actionType.value !== "TAG_HOST"}'
            },
            allowBlank: false,
            editable: true,
        }, {
            xtype: 'numberfield',
            fieldLabel: 'Tag Time (Seconds)'.t(),
            hidden: true,
            disabled: true,
            bind: {
                value: '{_action.tagTime}',
                hidden: '{actionType.value !== "TAG_HOST"}',
                disabled: '{actionType.value !== "TAG_HOST"}'
            },
            allowBlank: false,
            editable: true,
        }
    ]
});
Ext.define('Ung.apps.bandwidthcontrol.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-bandwidth-control-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',

        defaults: {
            xtype: 'fieldset',
        },

        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/bandwidth-control.svg" width="80" height="80"/>' +
                '<h3>Bandwidth Control</h3>' +
                '<p>' + 'Bandwidth Control monitors, manages, and shapes bandwidth usage on the network'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
            hidden: true,
            bind: {
                hidden: '{!isConfigured}'
            },
        }, {
            title: '<i class="fa fa-cog"></i> ' + 'Configuration'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',
            items: [{
                xtype: 'component',
                html: 'Bandwidth Control is unconfigured. Use the Wizard to configure Bandwidth Control.'.t(),
                hidden: true,
                bind: {
                    hidden: '{isConfigured}'
                }
            }, {
                xtype: 'component',
                html: '<i class="fa fa-exclamation-triangle fa-red"></i><span style="color: red;">' + ' WARNING: Bandwidth Control is enabled, but QoS is not enabled. Bandwidth Control requires QoS to be enabled.'.t() + '</span>',
                hidden: true,
                bind: {
                    hidden: '{!isConfigured || qosEnabled}'
                }
            }, {
                xtype: 'component',
                html: 'Bandwidth Control is configured'.t(),
                hidden: true,
                bind: {
                    hidden: '{!isConfigured}'
                }
            }, {
                xtype: 'button',
                margin: '10 0 0 0',
                text: 'Run Bandwidth Control Setup Wizard'.t(),
                iconCls: 'fa fa-magic',
                handler: 'runWizard'
            }]
        }, {
            xtype: 'appreports',
            hidden: true,
            bind: {
                hidden: '{!isConfigured}'
            },
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
