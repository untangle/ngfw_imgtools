/**
 * Extend the condition editor to support events..
 *
 * The biggest change is to handle the first record in the condition list which is the "class"
 * field.  This controls which class fields are selectable and targets (tags).
 *
 */
Ext.define('Ung.config.events.ConditionsEditor', {
    extend: 'Ung.cmp.ConditionsEditor',
    alias: 'widget.eventconditionseditor',

    controller: 'eventconditionseditorcontroller',
    model: 'Ung.model.EventCondition',

    javaClassValue: 'com.untangle.uvm.event.EventRuleCondition',

    allowAllClasses: false,

    constructor: function(config) {
        var me = this;

        var items = Ext.Array.clone(me.items);

        var pos = -1;
        Ext.Array.findBy(items, function(item, index){
            if(item.name == 'conditionLabel'){
                pos = index;
                return true;
            }
        });
        Ext.Array.insert(items, pos+1, [{
            xtype: 'combo',
            name: 'classSelect',
            fieldLabel: 'Class'.t(),
            editable: false,
            queryMode: 'local',
            width: '100%',
            bind:{
                value: '{record.class}',
                store: (config.allowAllClasses === true) ? '{allClasses}' : '{classes}'
            },
            valueField: 'name',
            displayField: 'name',
            forceSelection: true,
            listConfig:   {
                itemTpl: '<div data-qtip="{description}">{name}</div>'
            },
            listeners: {
                change: 'onClassChange'
            }
        }]);

        config.items = items;

        me.callParent(arguments);
    },

    statics:{
        classRenderer: function(value, meta){
            var me = this,
                view = me.getView().up('grid'),
                conditionsEditorField = Ext.Array.findBy(view.editorFields, function(item){
                    if(item.xtype.indexOf('conditionseditor') > -1){
                        return true;
                    }
                }),
                classFields = me.up('config-events').getViewModel().get(conditionsEditorField.allowAllClasses ? 'allClassFields' : 'classFields'),
                className = '';

            if(!value.list.length){
                if(conditionsEditorField && conditionsEditorField.allowAllClasses){
                    className = 'All';
                }else{
                    className = 'UNKNOWN';
                }
            }else{
                className = value.list[0]['fieldValue'];
                className = className.substring(1, className.length -1);
            }
            meta.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( classFields[className] ? classFields[className].description : 'Unknown'.t() ) + '"';
            return className;
        },
        conditionsRenderer: function(value, meta){
            var me = this,
                view = me.getView().up('grid'),
                conditionsEditorField = Ext.Array.findBy(view.editorFields, function(item){
                    if(item.xtype.indexOf('conditionseditor') > -1){
                        return true;
                    }
                }),
                classFields = me.up('config-events').getViewModel().get(conditionsEditorField.allowAllClasses ? 'allClassFields' : 'classFields'),
                className = '',
                valueList = Ext.Array.clone(value.list);

            if(!value.list.length){
                var valueString = '<i>' + 'Match all fields'.t() + '</i>';
                meta.tdAttr = 'data-qtip="' + valueString + '"';
                return valueString;
            }else{
                className = value.list[0]['fieldValue'];
                className = className.substring(1, className.length -1);
                if(classFields[className] && classFields[className].conditions){
                    conditionsEditorField.conditions = classFields[className].conditions;
                }
                valueList.shift();
            }

            return Ung.cmp.ConditionsEditor.renderer.call(this, { list: valueList}, meta);
        }
    }

});

Ext.define('Ung.config.events.ConditionsEditorController', {
    extend: 'Ung.cmp.ConditionsEditorController',
    alias: 'controller.eventconditionseditorcontroller',

    onAfterRender: function (component) {
        var me = this,
            view = me.getView(),
            vm = this.getViewModel(),
            record = vm.get('record');

        var className = null;
        if(record.get('conditions').list.length){
            me.classCondition = record.get('conditions').list.shift();
            className =  me.classCondition.fieldValue;
            if(className.length && className[0] == '*'){
                className = className.substring(1, className.length -1);
            }
        }
        if(className == null){
            className = 'All';
        }
        record.set('class', className);
        record.commit();

        var classFields = vm.get('allClassFields');
        if(className){
            if(classFields[className].conditionsOrder){
                view.conditionsOrder = classFields[className].conditionsOrder;
            }
            if(classFields[className].conditions){
                view.conditions = classFields[className].conditions;
            }
        }
        me.callParent([component]);
    },

    onRemoved: function(me, container){
        var recordEditorView = this.recordeditor,
            store = me.down('grid').getStore(),
            vm = this.getViewModel(),
            record = vm.get('record'),
            recordName = me.recordName.split('.')[1],
            data = [],
            modified = store.getModifiedRecords().length || store.getRemovedRecords().length || store.getNewRecords().length;

        me = me.down ? me : me.getView();
        var classValue = record.get('class');

        if(this.recordeditor.cancel){
            if(record.previousValues && record.previousValues.class){
                classValue = record.previousValues.class;
            }
            store.rejectChanges();
        }

        data = Ext.Array.pluck(store.getRange(), 'data');
        data.forEach( function(record){
            if(typeof(record.value) == 'object' && record.value.length){
                record.value = record.value.join(',');
            }
        });

        var className = "";
        if(classValue == 'All'){
            className = 'All';
        }else{
            this.classCondition.fieldValue = '*' + classValue + '*';
            data.unshift(this.classCondition);
        }

        recordEditorView.record.set( recordName, {
            javaClass: 'java.util.LinkedList',
            list: data
        });
        if(this.recordeditor.cancel || !modified && !recordEditorView.record.modified){
            recordEditorView.record.commit();
        }
    },

    onClassChange: function( combo, newValue, oldValue ){
        var me = this,
            view = me.getView(),
            appVm = view.up('config-events').getViewModel(),
            classFields = appVm.get('allClassFields'),
            classValue = newValue;

        view.down('grid').setVisible( newValue == 'All' ? false : true);

        view.conditionsOrder = classFields[classValue]['conditionsOrder'];
        view.conditions = classFields[classValue]['conditions'];
        view.comparators = Ext.clone(Ung.cmp.ConditionsEditor.comparators);
        me.buildConditions(view);
        me.updateTargetFields();

        if(oldValue == null){
            return;
        }

        var record = this.getViewModel().get('record');
        if(record.previousValues &&
            record.previousValues.class &&
            oldValue == record.previousValues.class){
            // Set back to previous and cancelled.
            return;
        }

        if( newValue != oldValue ) {
            if ( view.down('grid').getStore().getData().length > 0 ) {
                Ext.MessageBox.confirm(
                    'Change Class'.t(),
                    'If you change the class, fields may be removed. Are you sure?'.t(),
                    Ext.bind(function(button){
                        if (button == 'no') {
                            record.set('class', oldValue);
                        } else {
                            this.classChangeFields(newValue, oldValue);
                        }
                    },this)
                );
            }
        }
    },

    classChangeFields: function( newClassName, oldClassName ){
        var view = this.getView(),
            appVm = view.up('config-events').getViewModel();

        // Remove fields if they do not exist in new class.
        // console.log('classChangeFields');
        var oldFields = appVm.get('classFields')[oldClassName].conditions;
        var newFields = appVm.get('classFields')[newClassName].conditions;

        var store = this.getView().down('grid').getStore();
        var match;
        store.each(Ext.bind( function( record ){
            match = false;
            for( var field in newFields){
                if(record.get('field') == field){
                    // Provisionally match!
                    match = true;

                    // But look for other reasons why it may not be true.
                    for(var oldField in oldFields){
                        if(field == oldField){
                            if( field.type != oldField.type){
                                // Form display is not the same.
                                match = false;
                            }
                            if( field.values && oldField.values ){
                                // Enumerated, but field value list is not the same.
                                if(field.values.length != oldField.values.length){
                                    match = false;
                                }
                                var i = field.values.length;
                                while( i-- ){
                                    if(field.values[i] != oldField.values[i]){
                                        match = false;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if(match === false){
                store.remove(record);
            }
        }, this) );

        // While slightly out of place, this is the best place to check for trigger target field
        // since it also depends on class fields.
        // var targetCombo = this.getView().down('#target');
        var targetCombo = this.getView().up('window').down('#target');
        if(targetCombo){
            var comboValue = targetCombo.getValue();
            match = false;
            // newFields.forEach( function( field ){
            for( var field in newFields){
                if( field.name == comboValue){
                    match = true;
                }
            }
            if( match == false ){
                targetCombo.setValue( newFields[Object.keys(newFields)[0]].name );
            }
        }

    },

    updateTargetFields: function(){
        var me = this,
            view = me.getView(),
            appVm = view.up('config-events').getViewModel(),
            targetFields = [];

        for(var conditionName in view.conditions){
            targetFields.push([conditionName, conditionName]);
        }
        appVm.get( 'targetFields' ).loadData( targetFields );
    }

});Ext.define ('Ung.model.EventCondition', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'javaClass', type: 'string'},
        { name: 'field', type: 'string' },
        { name: 'comparator', type: 'string'},
        { name: 'fieldValue', type: 'string'}
    ],
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});
Ext.define('Ung.config.events.Main', {
    extend: 'Ung.cmp.ConfigPanel',
    alias: 'widget.config-events',
    name: 'events',

    controller: 'config-events',

    viewModel: {
        type: 'config-events',
        formulas: {
            templateEmailSubject: {
                bind: '{settings.emailSubject}',
                get: function(get){
                    return this.get('settings.emailSubject') || this.get('templateDefaults.emailSubject');
                },
                set: function(value){
                    this.set('settings.emailSubject', (value == this.get('templateDefaults.emailSubject')) ? null : value);
                }
            },
            templateEmailBody: {
                bind: '{settings.emailBody}',
                get: function(get){
                    return this.get('settings.emailBody') || this.get('templateDefaults.emailBody');
                },
                set: function(value){
                    this.set('settings.emailBody', (value.replace(/(\r\n|\n)/gm, '\n') == this.get('templateDefaults.emailBody').replace(/(\r\n|\n)/gm, '\n')) ? null : value);
                }
            }
        }
    },

    items: [
        { xtype: 'config-events-alerts' },
        { xtype: 'config-events-triggers' },
        { xtype: 'config-events-syslog' },
        { xtype: 'config-events-email-template' }
    ]
});
Ext.define('Ung.config.events.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.config-events',

    control: {
        '#': { afterrender: 'loadEvents', },
        '#syslog': { 
            afterrender: function() {
                var me = this;
                Ext.Function.defer(function() { me.onSyslogRulesGridChange(); }, 1000);
            } 
        }
    },

    loadEvents: function () {
        var v = this.getView(),
            vm = this.getViewModel();
        v.setLoading(true);

        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.eventManager.getSettings'),
            Rpc.asyncPromise('rpc.eventManager.getClassFields'),
            Rpc.asyncPromise('rpc.eventManager.getTemplateParameters'),
            Rpc.asyncPromise('rpc.eventManager.defaultEmailSettings')
        ], this).then(function(result) {
            if(Util.isDestroyed(v, vm)){
                return;
            }

            var classFields = {};
            var className;
            var classes = [];
            for(className in result[1]){
                classes.push([className, result[1][className]["description"]]);
                var conditions = [];
                var conditionsOrder = [];
                result[1][className]["fields"].forEach(function(field){
                    var fieldNames = field.name.split('.');
                    var ignoreFieldName = fieldNames[fieldNames.length-1]; 
                    if(ignoreFieldName == 'class' || ignoreFieldName == 'timeStamp' ){
                        return;
                    }

                    if(field.name){
                        field.displayName = field.name;
                    }

                    if(field.values){
                        field.type = 'select';
                        field.comparator = 'boolean';
                    }else{
                        switch(field.type.toLowerCase()){
                            case 'boolean':
                                field.type = 'boolean';
                                field.comparator = 'boolean';
                                field.values = [[
                                    true,"True".t()
                                ],[
                                    false,"False".t()
                                ]];
                                break;
                            case 'double':
                            case 'float':
                            case 'integer':
                            case 'int':
                            case 'long':
                            case 'short':
                                field.type = 'numberfield';
                                field.comparator = 'numeric';
                                break;
                            default:
                                field.type = 'textfield';
                                field.comparator = 'text';
                                break;
                        }
                    }

                    var newCondition = Ext.clone(Ung.cmp.ConditionsEditor.defaultCondition);
                    Ext.merge(newCondition, field);
                    conditions.push(newCondition);
                    conditionsOrder.push(newCondition.name);
                });
                classFields[className] = {
                    'description': result[1][className]['description'],
                    'conditions': Ext.Array.toValueMap(conditions, 'name'),
                    'conditionsOrder': conditionsOrder
                };
            }

            var allClassFields = Ext.clone(classFields);
            allClassFields['All'] = {
                description: 'Match all classes (NOT RECOMMENDED!)'.t(),
                conditions: [],
                conditionsOrder: []
            };
            var allClasses = Ext.clone(classes);
            allClasses.push(['All', allClassFields['All']['description']]);

            var templateParametersStore = new Ext.data.JsonStore({
                fields: ['name', 'description'],
                data: result[2]
            });

            vm.set({
                settings: result[0],
                classFields: classFields,
                allClassFields: allClassFields,
                classes: Ext.create('Ext.data.ArrayStore', {
                    fields: [ 'name', 'description' ],
                    sorters: [{
                        property: 'name',
                        direction: 'ASC'
                    }],
                    data: classes
                }),
                allClasses: Ext.create('Ext.data.ArrayStore', {
                    fields: [ 'name', 'description' ],
                    sorters: [{
                        property: 'name',
                        direction: 'ASC'
                    }],
                    data: allClasses
                }),
                targetFields: Ext.create('Ext.data.ArrayStore', {
                    fields: [ 'name', 'description' ],
                    sorters: [{
                        property: 'name',
                        direction: 'ASC'
                    }],
                    data: []
                }),
                templateParametersStore: templateParametersStore,
                templateDefaults: result[3].map,
                templateUnmatched: ''
            });

            if(vm.get("settings.syslogServers.list").length > 0){
                vm.set('syslogServersGridEmpty', false);
            }else{
                vm.set('syslogServersGridEmpty', true);
            }

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
        });
    },

    saveSettings: function () {
        var me = this,
            v = this.getView(),
            vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            /**
             * Important!
             * update custom grids only if are modified records or it was reordered via drag/drop
             */
            if (store.getModifiedRecords().length > 0 || store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                if(grid.itemId == 'syslogservers') {
                    store.each(function (record) {
                        if(!record.get('tag')) {
                            record.set('tag', Ext.String.format('uvm-to-{0}', record.get('host')));
                        }
                    });
                }
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
                store.commitChanges();
            }
        });

        Rpc.asyncData('rpc.eventManager.setSettings', vm.get('settings'))
        .then(function() {
            if(Util.isDestroyed(me, v)){
                return;
            }
            me.loadEvents();
            Util.successToast('Events'.t() + ' ' + 'settings saved!'.t());
            Ext.fireEvent('resetfields', v);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
            Ext.Function.defer(function() { me.onSyslogRulesGridChange(); }, 1000);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
        });
    },

    /**
     * Format the template preview for display in HTML contexT:
     *     -    If any unmatched %paramters% are found, highlight with cite.
     *     -    Replace spaces wth &nbsp;
     * @param  template to modify.
     * @return Modified template.
     */
    templateFormat: function(template){
        var vm = this.getViewModel();
        template = template.replace( /\%[^\%\s]*\%/gm, function(parameter){
            vm.set('templateUnmatched', 'One or more customization parameters are unknown'.t() );
            return '<cite>' + parameter+ '</cite>';
        });
        template = template.replace( /\s/g, '&nbsp;');
        return template;
    },

    /**
     * On template fields change, set a preview task to fire in 500ms.
     * After fired, display results in preview.
     */
    getPreviewTask: null,
    templateChange: function(cmp, newValue, oldValue, eOpts){
        var v = this.getView(),
            vm = this.getViewModel();

        var alertRule = {
            javaClass: 'com.untangle.uvm.event.AlertRule',
            conditions: {
                javaClass: 'java.util.LinkedList',
                list: [{
                    comparator: '=',
                    field: 'class',
                    fieldValue: '*SystemStatEvent*',
                    javaClass: 'com.untangle.uvm.event.EventRuleCondition'
                }]
            },
            description: 'Preview Rule'.t(),
            ruleId: -1,
            enabled: true,
            thresholdEnabled: false,
            thresholdTimeframeSec: 60,
            thresholdGroupingField: null,
            email: true,
            emailLimitFrequency: false,
            emailLimitFrequencyMinutes: 0,

        };

        var event = {
            javaClass: 'com.untangle.uvm.logging.SystemStatEvent',
            load15: 0.08,
            load5: 0.02,
            load1: 0
        };

        var me = this;
        var meChange = me;
        if(me.getPreviewTask == null){
            me.getPreviewTask = new Ext.util.DelayedTask( Ext.bind(function(){
                var me = this,
                    vm = me.getViewModel();

                    Ext.Deferred.sequence([
                        Rpc.asyncPromise('rpc.eventManager.emailAlertFormatPreview', alertRule, event, v.down('[itemId=emailSubject]').getValue(), v.down('[itemId=emailBody]').getValue(), v.down('[itemId=emailConvert]').getValue()),
                    ], this).then(function(result) {
                        if(Util.isDestroyed(vm)){
                            return;
                        }

                        vm.set('templateUnmatched', '');
                        vm.set('previewSubject', me.templateFormat(result[0].map['emailSubject']));
                        vm.set('previewBody', me.templateFormat(result[0].map['emailBody']));
                        meChange.getPreviewTask = null;

                    }, function(ex) {
                        if(!Util.isDestroyed(vm)){
                            vm.set('panel.saveDisabled', true);
                            v.setLoading(false);
                        }
                        meChange.getPreviewTask = null;
                    });
            }, me) );
        }
        me.getPreviewTask.delay( 500 );

    },

    /**
     * Pull default templates and populate.
     */
    templateDefaults: function(){
        var me = this,
            vm = this.getViewModel();

        Rpc.asyncData('rpc.eventManager.defaultEmailSettings')
        .then(function(result) {
            if(Util.isDestroyed(me, vm)){
                return;
            }
            for(var key in result.map){
                var value = result.map[key];
                if(value == "true" || value == "false"){
                    vm.set("settings." + key, (value == "true") ? true : false);
                }else{
                    vm.set("settings." + key, null);
                }
            }
        });
    },

    onSyslogServersGridChange: function(store, record){
        var vm = this.getViewModel();
        if((store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0)) {
            vm.set('syslogRuleGridDisabled', true);
            // Check if modified records only have reserved boolean modified 
            // and accordingly set skipDetectGridChanges flag
            var isGridPropertyChanged;
            store.getModifiedRecords().forEach(function(modifiedRecord) {
                if(modifiedRecord.modified) {
                    var keys = Object.keys(modifiedRecord.modified);
                    if(!(keys.length === 1 && keys[0] === 'reserved')) {
                        isGridPropertyChanged = true;
                    }
                }
            });
            store.skipDetectGridChanges = !isGridPropertyChanged;
        } else {
            vm.set('syslogRuleGridDisabled', false);
        }
    },

    onSyslogRulesGridChange: function(store, record) {
        var view = this.getView(),
            vm = this.getViewModel(),
            usedServerIds = {},
            serverList = [];
        store = store ? store : view.down('config-events-syslog').down('[itemId=syslogrules]').getStore();

        // Find serverId's of syslog servers which are used in syslog rules         
        store.each(function(rulesRecord) {
            if(!rulesRecord.get('markedForDelete')) {
                if(rulesRecord.data.syslogServers && rulesRecord.data.syslogServers.list) {
                    serverList = rulesRecord.data.syslogServers.list;
                    if(!Ext.isArray(serverList)) {
                        serverList = [ serverList ];
                    }
                    serverList.forEach(function(serverId) {
                        usedServerIds[serverId] = true;
                    });
                }
            }
        });

        // Mark used syslog server records as reserved
        var syslogServerStore = view.down('config-events-syslog').down('[itemId=syslogservers]').getStore();
        syslogServerStore.each(function(serversRecord) {
            if(usedServerIds[serversRecord.get('serverId')]) {
                serversRecord.set('reserved', true);
            } else {
                serversRecord.set('reserved', false);
            }
        });
        vm.set('syslogRuleGridDisabled', false);
    },

    statics: {
        conditionsClass: {
            header: 'Class'.t(),
            width: Renderer.conditionsWidth,
            flex: 2,
            dataIndex: 'conditions',
            renderer: function(){
                return Ung.config.events.ConditionsEditor.classRenderer.apply(this, arguments);
            }
        },
        conditions: {
            header: 'Conditions'.t(),
            width: Renderer.conditionsWidth,
            flex: 2,
            dataIndex: 'conditions',
            renderer: function(){
                return Ung.config.events.ConditionsEditor.conditionsRenderer.apply(this, arguments);
            }
        }
    }

});

Ext.define('Ung.config.events.SyslogRulesController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.uneventssyslogrulesgrid',

    sysLogServersRenderer: function(value, column) {
        value.javaClass = "java.util.LinkedList";
        if(value.list) {
            if(!Ext.isArray(value.list)) {
                value.list = [ value.list ];
            }
            return this.getSysLogsServerNameFromId(value.list, column);
        } else {
            value.list = [];
        }
        var noServerStr = '<i>' + 'No Sys Log Server'.t() + '<i>';
        column.tdAttr = 'data-qtip="' + Ext.String.htmlEncode(noServerStr) + '"';
        return noServerStr;
    },

    /**
     * Method to get list of syslog server hostnames from syslog server Id list
     * @param list List of sysolg server id's
     * @return List of syslog server host names whose id's are present in serverId list
     */
    getSysLogsServerNameFromId: function(serverIds, column) {
        if(serverIds.length == 0) {
            var noServerStr = '<i>' + 'No Sys Log Server'.t() + '<i>';
            column.tdAttr = 'data-qtip="' + Ext.String.htmlEncode(noServerStr) + '"';
            return noServerStr;
        }

        var serverList = this.getViewModel().get('settings.syslogServers.list'),
            data = serverList.filter(function(server) {
                return serverIds.includes(server.serverId);
            }).map(function(server) {
                return server.description;
            });
        column.tdAttr = 'data-qtip="' + Ext.String.htmlEncode(data.join(", ")) + '"';
        return data.join(", ");
    }
});

Ext.define('Ung.config.events.SyslogRulesEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unsyslogruleseditor',
    itemId: 'syslogruleseditor',

    controller: 'unsyslogruleseditorcontroller'
});

Ext.define('Ung.config.events.SyslogRulesEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unsyslogruleseditorcontroller',

    control: {
        '#syslogruleseditor': {
            afterrender: 'afterSysLogRuleEditorRender'
        }
    },

    afterSysLogRuleEditorRender: function() {
        var view = this.getView();
            actionContainer = view.down('#actioncontainer');
        actionContainer.removeAll();
        actionContainer.add({
            xtype: 'checkboxgroup',
            fieldLabel: 'Syslog Servers'.t(),
            useParentDefinition: true,
            itemId: 'syslogserverscheckbox',
            labelWidth: 155,
            readOnlyCls: 'x-item-disabled',
            bind: {
                value: '{record.syslogServers}'
            },
            columns: 3,
            vertical: true,
            items: this.getSyslogServerCBItems()
        });
    },

    getSyslogServerCBItems: function() {
        var view = this.getView(),
            items = [],
            syslogServerStore = view.up('config-events-syslog').down('[itemId=syslogservers]').getStore();

        syslogServerStore.each(function(record) {
            if(record.get('serverId') > 0 && !record.get('markedForDelete')) {
                var readOnly = !record.get('enabled'),
                    qtip = readOnly ? Ext.String.format('Enable the server with host {0}'.t(), record.get('host')) : record.get('host');
                items.push({ 
                    boxLabel: record.get('description'),
                    name: 'list', 
                    inputValue: Number(record.get('serverId')),
                    autoEl: {
                        tag: 'div',
                        'data-qtip': qtip
                    },
                    readOnly: readOnly
                });
            }
        });
        return items;
    }
});
Ext.define('Ung.config.events.MainModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.config-events',

    data: {
        title: 'Events'.t(),
        iconName: 'events',

        settings: null,
        record: null

    },

    stores: {
        alertRules: { data: '{settings.alertRules.list}' },
        triggerRules: { data: '{settings.triggerRules.list}' },
        syslogRules: { 
            data: '{settings.syslogRules.list}',
            listeners: {
                update: 'onSyslogRulesGridChange',
                datachanged: 'onSyslogRulesGridChange'
            }
        },
        syslogServers: { 
            data: '{settings.syslogServers.list}',
            listeners: {
                update: 'onSyslogServersGridChange',
                datachanged: 'onSyslogServersGridChange'
            }
        }
    }
});
Ext.define('Ung.config.events.view.Alerts', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-events-alerts',
    itemId: 'alerts',
    title: 'Alerts'.t(),
    scrollable: true,
    withValidation: false,
    bodyPadding: 10,

    items: [{
        xtype: 'ungrid',
        title: 'Alert Rules'.t(),
        region: 'center',

        listProperty: 'settings.alertRules.list',
        tbar: ['@add', '->', '@import', '@export'],
        recordActions: ['edit', 'copy', 'delete', 'reorder'],
        copyId: 'ruleId',
        copyAppendField: 'description',

        bind:{
            store: '{alertRules}'
        },

        emptyRow: {
            javaClass: 'com.untangle.uvm.event.AlertRule',
            conditions: {
                javaClass: 'java.util.LinkedList',
                list: [{
                    comparator: '=',
                    field: 'class',
                    fieldValue: '*SystemStatEvent*',
                    javaClass: 'com.untangle.uvm.event.EventRuleCondition'
                }]
            },
            ruleId: -1,
            enabled: true,
            thresholdEnabled: false,
            thresholdTimeframeSec: 60,
            thresholdGroupingField: null,
            email: true,
            emailLimitFrequency: false,
            emailLimitFrequencyMinutes: 0,
        },

        importValidationJavaClass: true,
        importValidationForAlertEvents: true,
        importValidationForFieldSet: true,
        importValidationForComboBox: true,

        columns: [
            Column.ruleId,
            Column.enabled,
            Column.description,
            Ung.config.events.MainController.conditionsClass,
            Ung.config.events.MainController.conditions,
        {
            xtype:'checkcolumn',
            header: 'Log'.t(),
            dataIndex: 'log',
            width: Renderer.booleanWidth,
            sortable: false
        },{
            xtype:'checkcolumn',
            header: 'Email'.t(),
            dataIndex: 'email',
            width: Renderer.booleanWidth
        }],

        editorFields: [
            Field.enableRule(),
            Field.description,
            // Field.conditions,
        {
            xtype: 'eventconditionseditor',
            bind: '{record.conditions}',
            fields: {
                type: 'field',
                comparator: 'comparator',
                value: 'fieldValue',
            }
        },{
            xtype: 'fieldset',
            title: 'As well as the following conditions:'.t(),
            items:[{
                xtype:'checkbox',
                labelWidth: 160,
                bind: "{record.thresholdEnabled}",
                fieldLabel: 'Enable Thresholds'.t(),
                listeners: {
                    disable: function (ck) {
                        ck.setValue(false);
                    }
                }
            },{
                xtype:'fieldset',
                collapsible: false,
                hidden: true,
                disabled: true,
                bind: {
                    hidden: '{!record.thresholdEnabled}',
                    disabled: '{!record.thresholdEnabled}'
                },
                items: [{
                    xtype:'numberfield',
                    fieldLabel: 'Exceeds Threshold Limit'.t(),
                    labelWidth: 160,
                    bind: '{record.thresholdLimit}'
                },{
                    xtype: 'container',
                    layout: 'column',
                    margin: '0 0 5 0',
                    items: [{
                        xtype: 'numberfield',
                        fieldLabel: 'Over Timeframe'.t(),
                        labelWidth: 160,
                        disabled: true,
                        bind: {
                            value: '{record.thresholdTimeframeSec}',
                            disabled: '{!record.thresholdEnabled}'
                        },
                        allowDecimals: false,
                        allowBlank: false,
                        minValue: 60,
                        maxValue: 60*24*60*7, // 1 week
                    }, {
                        xtype: 'label',
                        html: '(seconds)'.t(),
                        cls: 'boxlabel'
                    }]
                },{
                    xtype:'textfield',
                    fieldLabel: 'Grouping Field'.t(),
                    labelWidth: 160,
                    bind: '{record.thresholdGroupingField}'
                }]
            }]
        }, {
            xtype: 'fieldset',
            title: 'Perform the following action(s):'.t(),
            items:[{
                xtype:'checkbox',
                fieldLabel: 'Log'.t(),
                labelWidth: 160,
                bind: '{record.log}'
            }, {
                xtype:'checkbox',
                fieldLabel: 'Send Email'.t(),
                labelWidth: 160,
                bind: '{record.email}',
                listeners: {
                    disable: function (ck) {
                        ck.setValue(false);
                    }
                }
            },{
                xtype:'fieldset',
                collapsible: false,
                hidden: true,
                disabled: true,
                bind: {
                    hidden: '{record.email == false}',
                    disabled: '{record.email == false}'
                },
                items: [{
                    xtype:'checkbox',
                    fieldLabel: 'Limit Send Frequency'.t(),
                    labelWidth: 160,
                    bind: '{record.emailLimitFrequency}'
                },{
                    xtype: 'container',
                    layout: 'column',
                    margin: '0 0 5 0',
                    items: [{
                        xtype: 'numberfield',
                        fieldLabel: 'To once per'.t(),
                        labelWidth: 160,
                        bind: '{record.emailLimitFrequencyMinutes}',
                        allowDecimals: false,
                        allowBlank: false,
                        minValue: 0,
                        maxValue: 24*60*7, // 1 weeks
                    }, {
                        xtype: 'label',
                        html: '(minutes)'.t(),
                        cls: 'boxlabel'
                    }]
                }]
            }]
        }]
    }]
});
Ext.define('Ung.config.events.view.EmailTemplate', {
    extend: 'Ext.form.Panel',
    alias: 'widget.config-events-email-template',
    itemId: 'emailtemplate',
    title: 'Email Template'.t(),
    scrollable: true,

    bodyPadding: 10,
    withValidation: true,

    items:[{
        xtype:'fieldset',
        title: 'Emailed Alert Template Settings'.t(),
        collapsible: false,
        items:[{
            xtype:'fieldset',
            title: 'Customization Parameters'.t(),
            collapsible: true,
            collapsed: true,
            items:[{
                xtype: 'ungrid',
                columns:[{
                    text: 'Name'.t(),
                    dataIndex: 'name',
                    flex: 1
                },{
                    text: 'Description'.t(),
                    dataIndex: 'description',
                    flex: 2
                }],
                bind:{
                    store: '{templateParametersStore}'
                }
            }],
        },{
            xtype: 'textfield',
            fieldLabel: 'Subject'.t(),
            itemId: 'emailSubject',
            labelWidth: 150,
            width: 550,
            bind: '{templateEmailSubject}',
            allowBlank: false,
            blankText: 'Subject must be specified.'.t(),
            listeners: {
                change: 'templateChange'
            }
        },{
            xtype: "textarea",
            fieldLabel: "Body".t(),
            itemId: 'emailBody',
            blankText: 'Body must be specified.'.t(),
            allowBlank: false,
            labelWidth: 150,
            width: 550,
            height: 200,
            bind: '{templateEmailBody}',
            listeners: {
                change: 'templateChange'
            }
        },{
            xtype: "displayfield",
            margin: '0 0 0 155',
            bind: {
                hidden: '{templateUnmatched == ""}',
                value: '{templateUnmatched}'
            }
        },{
            xtype: "checkbox",
            itemId: 'emailConvert',
            allowBlank: false,
            fieldLabel: "Human-readable values".t(),
            labelWidth: 150,
            bind: '{settings.emailConvert}',
            listeners: {
                change: 'templateChange'
            }
        },{
            xtype: 'container',
            layout: 'column',
            items:[{
                xtype: 'button',
                text: 'Reset to defaults'.t(),
                iconCls: 'fa fa-recycle',
                handler: 'templateDefaults',
                width: 150
            },{
                xtype: 'component',
                margin: '4 0 10 10',
                html: Ext.String.format( 'Reset template to defaults.'.t(),'<b>','</b>')
            }]
        }]
    },{
        xtype:'fieldset',
        title: 'Preview'.t(),
        collapsible: false,
        items:[{
            xtype: 'displayfield',
            fieldLabel: 'Subject'.t(),
            fieldStyle: {
                'font-family': 'monospace, monospace'
            },
            bind: {
                value: '{previewSubject}'
            }
        },{
            xtype: 'displayfield',
            fieldLabel: 'Body'.t(),
            fieldStyle: {
                'font-family': 'monospace, monospace'
            },
            bind: {
                value: '{previewBody}'
            }
        }]
    }]
});
Ext.define('Ung.config.events.view.Syslog', {
    extend: 'Ext.form.Panel',
    alias: 'widget.config-events-syslog',
    itemId: 'syslog',
    title: 'Syslog'.t(),
    scrollable: true,

    bodyPadding: 10,
    withValidation: true,

    items:[
    {
        xtype: 'ungrid',
        title: 'Servers'.t(),
        itemId: 'syslogservers',
        region: 'center',

        restrictedRecords: {
            keyMatch: 'reserved',
            valueMatch: true
        },

        padding: '0 0 10 0',
        bind: {
            store: '{syslogServers}',
        },

        listProperty: 'settings.syslogServers.list',
        tbar: ['@add'],
        recordActions: ['edit', 'delete'],

        emptyText: 'No Servers Configured'.t(),

        emptyRow: {
            javaClass: 'com.untangle.uvm.event.SyslogServer',
            serverId: -1,
            enabled: true,
            port: 514,
            protocol: "UDP"
        },

        columns: [
            Column.serverId,
            Column.enabled,
            Column.description,
        {
            header: 'Host'.t(),
            dataIndex: 'host',
            flex: 1,
            width: Renderer.hostnameWidth
        }, {
            header: 'Port'.t(),
            width: Renderer.portWidth,
            dataIndex: 'port'
        },{
            header: 'Protocol'.t(),
            width: Renderer.protocolWidth,
            dataIndex: 'protocol'
        },{
            header: 'Tag'.t(),
            width: Renderer.tagsWidth,
            dataIndex: 'tag',
            renderer: function(value, column, record) {
                if(!value) {
                    return Ext.String.format('uvm-to-{0}', record.get('host'));
                }
                return value;
            }
		}],

        editorFields: [
            Field.enableRule(),
            {
                xtype: 'textfield',
                fieldLabel: 'Description'.t(),
                bind: '{record.description}',
                emptyText: '[no description]'.t(),
                allowBlank: false,
                validator: function(value) {
                    var store = this.up('#syslogservers').getStore(),
                        currentServerId = this.up('window').getViewModel().get('record.serverId');
                
                    // Check if a record with the same description exists in the store
                    var isDescUnique = store.findBy(function(record) {
                        if(currentServerId == -1) {
                            return record.get('description') === value;
                        } else {
                            return record.get('serverId') !== currentServerId && record.get('description') === value;
                        }
                    }) === -1;
                    return (isDescUnique) ? true : 'Duplicate description.'.t();
                }
            },
            {
                xtype: 'textfield',
                fieldLabel: 'Host'.t(),
                bind: '{record.host}',
                emptyText: '[no host]'.t(),
                allowBlank: false,
                blankText: 'This field is required'.t()
            },{
                xtype: 'numberfield',
                fieldLabel: 'Port'.t(),
                bind: '{record.port}',
                toValidate: true,
                allowDecimals: false,
                minValue: 0,
                allowBlank: false,
                blankText: 'You must provide a valid port.'.t(),
                vtype: 'port'
            },{
                xtype: 'combo',
                editable: false,
                fieldLabel: 'Protocol'.t(),
                bind: '{record.protocol}',
                queryMode: 'local',
                store: [["UDP", 'UDP'.t()],
                        ["TCP", "TCP".t()]]
            },{
                xtype: 'textfield',
                fieldLabel: 'Tag'.t(),
                bind: '{record.tag}',
                emptyText: '[default tag: uvm-to-{host}]'.t(),
                validator: function(value) {
                    var store = this.up('#syslogservers').getStore(),
                        currentServerId = this.up('window').getViewModel().get('record.serverId');
                
                    // Check if a record with the same tag exists in the store
                    var isTagUnique = store.findBy(function(record) {
                        if(currentServerId == -1) {
                            return record.get('tag') === value;
                        } else {
                            return record.get('serverId') !== currentServerId && record.get('tag') === value;
                        }                        
                    }) === -1;
                    return (isTagUnique) ? true : 'Tag already exists.'.t();
                }
            }
        ]
    },{
        xtype: 'container',
        padding: '8 5',
        style: { fontSize: '12px', background: '#DADADA'},
        html: '<i class="fa fa-info-circle" style="color: orange;"></i> ' + 'Save the New/Modified/Deleted records in Syslog Server grid to enable Syslog Rules'.t(),
        hidden: true,
        bind: {
            hidden: '{!syslogRuleGridDisabled}'
        }
    },{
        xtype: 'ungrid',
        controller: 'uneventssyslogrulesgrid',
        title: 'Rules'.t(),
        itemId: 'syslogrules',
        region: 'center',

        disabled: false,
        bind: {
            store: '{syslogRules}',
            disabled: '{syslogRuleGridDisabled || syslogServersGridEmpty}'
        },

        listProperty: 'settings.syslogRules.list',
        tbar: ['@add'],
        recordActions: ['edit', 'copy', 'delete', 'reorder'],
        copyId: 'ruleId',
        copyAppendField: 'description',

        emptyText: 'No Rules Configured'.t(),

        emptyRow: {
            javaClass: 'com.untangle.uvm.event.SyslogRule',
            conditions: {
                javaClass: 'java.util.LinkedList',
                list: [{
                    comparator: '=',
                    field: 'class',
                    fieldValue: '*SystemStatEvent*',
                    javaClass: 'com.untangle.uvm.event.EventRuleCondition'
                }]
            },
            ruleId: -1,
            enabled: true,
            thresholdEnabled: false,
            thresholdTimeframeSec: 60,
            thresholdGroupingField: null,
            syslog: true,
            syslogServers: {
                "javaClass": "java.util.LinkedList",
                "list": []
            }
        },

        columns: [
            Column.ruleId,
            Column.enabled,
            Column.description,
            Ung.config.events.MainController.conditionsClass,
            Ung.config.events.MainController.conditions,
        {
            header: 'Syslog Servers'.t(),
            width: Renderer.conditionsWidth,
            flex: 2,
            dataIndex: 'syslogServers',
            renderer: 'sysLogServersRenderer'
        }],

        editorXtype: 'ung.cmp.unsyslogruleseditor',
        editorFields: [
            Field.enableRule(),
            Field.description,
        {
            xtype: 'eventconditionseditor',
            bind: '{record.conditions}',
            fields: {
                type: 'field',
                comparator: 'comparator',
                value: 'fieldValue',
            },
            allowAllClasses: true
        },{
            xtype: 'fieldset',
            title: 'As well as the following conditions:'.t(),
            items:[{
                xtype:'checkbox',
                labelWidth: 160,
                bind: "{record.thresholdEnabled}",
                fieldLabel: 'Enable Thresholds'.t(),
                listeners: {
                    disable: function (ck) {
                        ck.setValue(false);
                    }
                }
            },{
                xtype:'fieldset',
                collapsible: false,
                hidden: true,
                disabled: true,
                bind: {
                    hidden: '{!record.thresholdEnabled}',
                    disabled: '{!record.thresholdEnabled}'
                },
                items: [{
                    xtype:'numberfield',
                    fieldLabel: 'Exceeds Threshold Limit'.t(),
                    labelWidth: 160,
                    bind: '{record.thresholdLimit}'
                },{
                    xtype: 'container',
                    layout: 'column',
                    margin: '0 0 5 0',
                    items: [{
                        xtype: 'numberfield',
                        fieldLabel: 'Over Timeframe'.t(),
                        labelWidth: 160,
                        disabled: true,
                        bind: {
                            value: '{record.thresholdTimeframeSec}',
                            disabled: '{!record.thresholdEnabled}'
                        },
                        allowDecimals: false,
                        allowBlank: false,
                        minValue: 60,
                        maxValue: 60*24*60*7, // 1 week
                    }, {
                        xtype: 'label',
                        html: '(seconds)'.t(),
                        cls: 'boxlabel'
                    }]
                },{
                    xtype:'textfield',
                    fieldLabel: 'Grouping Field'.t(),
                    labelWidth: 160,
                    bind: '{record.thresholdGroupingField}'
                }]
            }]
        }, {
            xtype: 'fieldset',
            title: 'Perform the following action(s):'.t(),
            itemId: 'actioncontainer'
        }]
    }]
});
Ext.define('Ung.config.events.view.Triggers', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-events-triggers',
    itemId: 'triggers',
    title: 'Triggers'.t(),
    scrollable: true,
    withValidation: false,
    bodyPadding: 10,
    layout: { type: 'vbox', align: 'stretch' },

    items: [{
        xtype: 'ungrid',
        title: 'Trigger Rules'.t(),
        region: 'center',

        bind:{
            store: '{triggerRules}'
        },

        listProperty: 'settings.triggerRules.list',
        tbar: ['@add', '->', '@import', '@export'],
        recordActions: ['edit', 'copy', 'delete', 'reorder'],
        copyId: 'ruleId',
        copyAppendField: 'description',

        emptyRow: {
            javaClass: 'com.untangle.uvm.event.TriggerRule',
            conditions: {
                javaClass: 'java.util.LinkedList',
                list: [{
                    comparator: '=',
                    field: 'class',
                    fieldValue: '*SystemStatEvent*',
                    javaClass: 'com.untangle.uvm.event.EventRuleCondition'
                }]
            },
            action: 'TAG_HOST',
            tagName: 'tag',
            tagTarget: 'activeHosts',
            tagLifetimeSec: 300,
            ruleId: -1,
            thresholdEnabled: false,
            thresholdTimeframeSec: 60,
            thresholdGroupingField: null,
            enabled: true
        },

        importValidationJavaClass: true,
        importValidationForAlertEvents: true,
        importValidationForFieldSet: true,
        importValidationForComboBox: true,

        columns: [
            Column.ruleId,
            Column.enabled,
            Column.description,
            Ung.config.events.MainController.conditionsClass,
            Ung.config.events.MainController.conditions,
            {
                header: 'Action'.t(),
                dataIndex: 'action',
                width: Renderer.messagwWidth,
                renderer: function (value, metaData, record) {
                    if (typeof value === 'undefined') {
                        return 'Unknown action'.t();
                    }
                    switch(value) {
                      case 'TAG_HOST': return 'Tag Host'.t();
                      case 'UNTAG_HOST': return 'Untag Host'.t();
                      case 'TAG_USER':return 'Tag User'.t();
                      case 'UNTAG_USER':return 'Untag User'.t();
                      case 'TAG_DEVICE':return 'Tag Device'.t();
                      case 'UNTAG_DEVICE':return 'Untag Device'.t();
                    default: return 'Unknown Action'.t() + ': ' + value;
                    }
                }
            }],

        editorFields: [
            Field.enableRule(),
            Field.description,
            {
            xtype: 'eventconditionseditor',
            bind: '{record.conditions}',
            fields: {
                type: 'field',
                comparator: 'comparator',
                value: 'fieldValue',
            },
            },{
                xtype: 'fieldset',
                title: 'As well as the following conditions:'.t(),
                items:[{
                    xtype:'checkbox',
                    labelWidth: 160,
                    bind: "{record.thresholdEnabled}",
                    fieldLabel: 'Enable Thresholds'.t(),
                    listeners: {
                        disable: function (ck) {
                            ck.setValue(false);
                        }
                    }
                },{
                    xtype:'fieldset',
                    collapsible: false,
                    hidden: true,
                    disabled: true,
                    bind: {
                        hidden: '{!record.thresholdEnabled}',
                        disabled: '{!record.thresholdEnabled}'
                    },
                    items: [{
                        xtype:'numberfield',
                        fieldLabel: 'Exceeds Threshold Limit'.t(),
                        labelWidth: 160,
                        bind: '{record.thresholdLimit}'
                    },{
                        xtype: 'container',
                        layout: 'column',
                        margin: '0 0 5 0',
                        items: [{
                            xtype: 'numberfield',
                            fieldLabel: 'Over Timeframe'.t(),
                            labelWidth: 160,
                            disabled: true,
                            bind: {
                                value: '{record.thresholdTimeframeSec}',
                                disabled: '{!record.thresholdEnabled}'
                            },
                            allowDecimals: false,
                            allowBlank: false,
                            minValue: 60,
                            maxValue: 60*24*60*7, // 1 week
                        }, {
                            xtype: 'label',
                            html: '(seconds)'.t(),
                            cls: 'boxlabel'
                        }]
                    },{
                        xtype:'textfield',
                        fieldLabel: 'Grouping Field'.t(),
                        labelWidth: 160,
                        bind: '{record.thresholdGroupingField}'
                    }]
                }]
            }, {
                xtype: 'fieldset',
                title: 'Perform the following action(s):'.t(),
                items:[{
                    xtype: 'combo',
                    reference: 'actionType',
                    publishes: 'value',
                    fieldLabel: 'Action Type'.t(),
                    bind: '{record.action}',
                    allowBlank: false,
                    editable: false,
                    labelWidth: 160,
                    store: [
                        ['TAG_HOST', 'Tag Host'.t()],
                        ['UNTAG_HOST', 'Untag Host'.t()],
                        ['TAG_USER', 'Tag User'.t()],
                        ['UNTAG_USER', 'Untag User'.t()],
                        ['TAG_DEVICE', 'Tag Device'.t()],
                        ['UNTAG_DEVICE', 'Untag Device'.t()]
                    ],
                    queryMode: 'local'
                }, {
                    xtype: 'combo',
                    itemId: 'target',
                    fieldLabel: 'Target'.t(),
                    labelWidth: 160,
                    editable: true,
                    forceSelection: false,
                    queryMode: 'local',
                    width: 350,
                    bind:{
                        value: '{record.tagTarget}',
                        store: '{targetFields}'
                    },
                    valueField: 'name',
                    displayField: 'description'
                }, {
                    xtype: 'textfield',
                    bind: {
                        value: '{record.tagName}'
                    },
                    labelWidth: 160,
                    fieldLabel: 'Tag Name'.t(),
                    allowBlank: false
                },{
                    xtype: 'container',
                    layout: 'column',
                    hidden: true,
                    bind: {
                        hidden: '{record.action !== "TAG_HOST" && record.action !== "TAG_USER" && record.action !== "TAG_DEVICE"}'
                    },
                    margin: '0 0 5 0',
                    items: [{
                        xtype: 'numberfield',
                        fieldLabel: 'Tag Lifetime'.t(),
                        labelWidth: 160,
                        disabled: true,
                        bind: {
                            value: '{record.tagLifetimeSec}',
                            disabled: '{record.action !== "TAG_HOST" && record.action !== "TAG_USER" && record.action !== "TAG_DEVICE"}'
                        },
                        allowBlank: false
                    }, {
                        xtype: 'label',
                        html: '(seconds)'.t(),
                        cls: 'boxlabel'
                    }]
                }]
            }]
    }]
});
