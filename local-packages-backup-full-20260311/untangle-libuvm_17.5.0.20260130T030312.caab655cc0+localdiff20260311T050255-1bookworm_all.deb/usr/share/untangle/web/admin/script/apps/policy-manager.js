Ext.define('Ung.apps.policymanager.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-policy-manager',

    controller: 'app-policy-manager',

    viewModel: {
        data: {
            appsData: [],
            newPolicy: null
        },
        stores: {
            appsStore: {
                data: '{appsData}',
                // filters: [{
                //     property: 'type',
                //     value: 'FILTER'
                // }],
                sorters: 'viewPosition'
            },
            rules: { data: '{settings.rules.list}' }
        }
    },

    items: [
        { xtype: 'app-policy-manager-status' },
        { xtype: 'app-policy-manager-policies' },
        { xtype: 'app-policy-manager-rules' }
    ]
});
Ext.define('Ung.apps.policymanager.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-policy-manager',

    control: {
        '#': {
            afterrender: 'getSettings',
            deactivate: 'onDeactivate'
        }
    },

    listen: {
        store: {
            '#policiestree': {
                rootchange: 'onRootChange'
            }
        }
    },

    settings: null,
    tree: [],
    policiesMap: {},
    selectedPolicyId: null,

    onDeactivate: function () {
        this.lookup('tree').getSelectionModel().deselectAll();
        this.getViewModel().set('appsData', []);
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel(), policies, selNode;

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    // this saves only the rules as the policies are saved on the fly
    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    onRootChange: function (newRoot) {
        var me = this, selNode;

        if (me.selectedPolicyId) {
            selNode = newRoot.findChild('policyId', me.selectedPolicyId, true);
            if (selNode) {
                // short delay for node selection
                // todo: fix some issue when removing PolicyManager but tries to select a path
                setTimeout(function() {
                    me.lookup('tree').selectPath(selNode.getPath('policyId'), 'policyId');
                }, 100);
            }
        }else{
            var tree = me.lookup('tree');
            if( tree != null){
                tree.getSelectionModel().select(0);
            }
        }
    },

    onPolicySelect: function (rowModel, selectedNode) {
        var me = this;
        me.selectedPolicyId = selectedNode.get('policyId');
        me.selectedPolicyName = selectedNode.get('name');

        Rpc.asyncData('rpc.appManager.getAppsView', selectedNode.get('policyId'))
        .then(function (result) {
            if(Util.isDestroyed(me)){
                return;
            }
            me.buildApps(result);
        }, function(ex) {
            Util.handleException(ex);
        });
    },

    buildApps: function (policy) {
        var me = this, appsList = [], instance, status = null, parentPolicy = null;

        // fix NGFW-10894 - after creating new policy and installing apps within policy manager
        Rpc.asyncData('rpc.appManager.getAppsViews')
            .then(function (policies) {
                Ext.getStore('policies').loadData(policies);
            });
        // also get the current policy apps if were installed/removed
        Ung.app.getGlobalController().getAppsView().getController().getApps();

        Ext.Array.each(policy.appProperties.list, function (app) {

            if (app.type !== 'FILTER') { return; }

            instance = Ext.Array.findBy(policy.instances.list, function(instance) { return instance.appName === app.name; });
            parentPolicy = null;

            // If there is no instance of the app and it is not in the installable list, return
            if(!Ext.Array.contains(policy.installable.list, app.name) && instance === null) { return; }

            if (instance) {
                if (instance.policyId && policy.policyId !== instance.policyId) {
                    parentPolicy = me.lookup('tree').getStore().findNode('policyId', instance.policyId).get('name');
                }

                instance.runState = policy.runStates.map[instance.id];

                Ext.apply(app, {
                    state: Ext.create('Ung.model.AppState',{instance: instance}),
                    instanceId: instance.id || null,
                    parentPolicy: parentPolicy || null,
                });
            }
            appsList.push(app);
        });

        this.getViewModel().set('appsData', appsList);
    },

    onInstall: function (btn) {
        var me = this, rec = btn.getViewModel().get('record');

        Ext.Msg.wait('Installing ' + rec.get('displayName'), me.selectedPolicyName, { interval: 500, text: '' });

        Rpc.asyncData('rpc.appManager.instantiate', rec.get('name'), me.selectedPolicyId)
        .then(function (result1) {
            Rpc.asyncData('rpc.appManager.getAppsView', me.selectedPolicyId)
                .then(function (result2) {
                    me.buildApps(result2);
                    Ext.Msg.close();
                });
        });
    },

    onRemove: function (btn) {
        var me = this, rec = btn.getViewModel().get('record');

        Ext.Msg.wait('Removing ' + rec.get('displayName'), me.selectedPolicyName, { interval: 500, text: '' });

        Rpc.asyncData('rpc.appManager.destroy', rec.get('instanceId'))
            .then(function (result) {
                Rpc.asyncData('rpc.appManager.getAppsView', me.selectedPolicyId)
                    .then(function (result2) {
                        me.buildApps(result2);
                        Ext.Msg.close();
                    });
            });
    },

    onStart: function (btn) {
        var me = this, rec = btn.getViewModel().get('record'),
            appManager = Rpc.directData('rpc.appManager.app', rec.get('instanceId'));

        if (appManager) {
            Ext.Msg.wait('Starting ' + rec.get('displayName'), me.selectedPolicyName, { interval: 500, text: '' });
            Ext.Deferred.sequence([
                Rpc.directPromise(appManager, 'start'),
                Rpc.directPromise('rpc.appManager.getAppsView', me.selectedPolicyId)
            ]).then(function(result){
                if(Util.isDestroyed(me)){
                    return;
                }
                me.buildApps(result[1]);
                Ext.Msg.close();

            }, function(ex){
                Ext.Msg.close();
                Util.handleException(ex);
            });
        }
    },

    onStop: function (btn) {
        var me = this, rec = btn.getViewModel().get('record'),
            appManager = rpc.appManager.app(rec.get('instanceId'));

        if (appManager) {
            Ext.Msg.wait('Stopping ' + rec.get('displayName'), me.selectedPolicyName, { interval: 500, text: '' });
            Ext.Deferred.sequence([
                Rpc.directPromise(appManager, 'stop'),
                Rpc.directPromise('rpc.appManager.getAppsView', me.selectedPolicyId)
            ]).then(function(result){
                if(Util.isDestroyed(me)){
                    return;
                }
                me.buildApps(result[1]);
                Ext.Msg.close();

            }, function(ex){
                Ext.Msg.close();
                Util.handleException(ex);
            });
        }
    },

    removePolicy: function (view, rowIndex, colIndex, item, e, record) {
        var me = this, vm = me.getViewModel(), idx;

        var appAssociated = false;
        for (var i = 0; i < vm.get('appsData').length; i++) {
            // 'state' object is only present for the installed apps
            if (vm.get('appsData')[i].state) {
                appAssociated = true;
                break;
            }
        }

        if (appAssociated) {
            var message = 'Cannot delete policy as it is associated with one or more apps. Remove all the associated apps to delete the policy.'.t();
            Util.showWarningMessage(message, message, Ext.emptyFn());
            return;
        }

        Ext.Array.each(vm.get('settings.policies.list'), function (p, index) {
            if (p.policyId === record.get('policyId')) {
                idx = index;
            }
        });

        Ext.Array.removeAt(vm.get('settings.policies.list'), idx);

        view.setLoading(true);
        Rpc.asyncData(me.getView().appManager, 'setSettings', vm.get('settings'))
        .then( function(result){
            if(Util.isDestroyed(view, vm, record)){
                return;
            }
            view.setLoading(false);
            if (me.selectedPolicyId === record.get('policyId')) {
                me.selectedPolicyId = null;
                vm.set('appsData', []);
            }
            Ext.getStore('policiestree').build();
        }, function(ex) {
            if(Util.isDestroyed(view)){
                view.setLoading(true);
            }
            Util.handleException(ex);
        });
    },

    editPolicy: function (view, rowIndex, colIndex, item, e, record) {
        this.showEditor(record);
    },

    addPolicy: function () {
        this.showEditor();
    },

    showEditor: function (rec) {
        var me = this, 
            vm = this.getViewModel(),
            policiesStore = [[0, 'None'.t()]], 
            initialName;

        if (!me.lookup('tree')) { return; }
        me.lookup('tree').getRootNode().cascadeBy(function (node) {
            if (node.isRoot()) { return; }
            if (rec) {
                if (node.get('policyId') !== rec.get('policyId') && !node.isAncestor(rec)) {
                    policiesStore.push([node.get('policyId'), node.get('name')]);
                }
            } else {
                policiesStore.push([node.get('policyId'), node.get('name')]);
            }
        });

        if (rec) { initialName = rec.get('name'); }

        me.editWin = me.getView().add({
            xtype: 'window',
            width: 300,
            modal: true,
            title: rec ? 'Edit Policy' : 'New Policy',
            items: [{
                xtype: 'form',
                layout: 'anchor',
                bodyPadding: 10,
                border: false,
                defaults: {
                    anchor: '100%'
                },
                items: [{
                    xtype: 'hidden',
                    name: 'policyId',
                    value: rec ? rec.get('policyId') : vm.get('settings.nextPolicyId')
                }, {
                    xtype: 'hidden',
                    name: 'javaClass',
                    value: 'com.untangle.app.policy_manager.PolicySettings'
                }, {
                    xtype:  'textfield',
                    name: 'name',
                    fieldLabel: '<strong>' + 'Name'.t() + '</strong>',
                    emptyText: 'enter policy name',
                    allowBlank: false,
                    labelAlign: 'top',
                    value: rec ? rec.get('name') : '',
                    msgTarget: 'side',
                    validator: function (val) {
                        if (val === initialName) { return true; } // if name not modified it can be saved
                        if (Ext.getStore('policiestree').find('name', val, 0, false, false, true) >= 0) {
                            return 'This policy name already exists'.t();
                        }
                        return true;
                    }
                }, {
                    xtype:  'textarea',
                    name: 'description',
                    fieldLabel: '<strong>' + 'Description'.t() + '</strong>',
                    emptyText: 'enter policy description',
                    labelAlign: 'top',
                    value: rec ? rec.get('description') : ''
                }, {
                    xtype: 'combo',
                    name: 'parentId',
                    fieldLabel: '<strong>' + 'Parent'.t() + '</strong>',
                    reference: 'policiesCombo',
                    labelAlign: 'top',
                    value: rec ? rec.get('parentPolicyId') : 0,
                    store: policiesStore,
                    emptyText: 'Select parent',
                    allowBlank: false,
                    hidden: rec && rec.get('policyId') === 1,
                    queryMode: 'local',
                    editable: false
                }],
                buttons: [{
                    text: 'Cancel'.t(),
                    iconCls: 'fa fa-ban',
                    handler: function (btn) {
                        btn.up('window').close();
                    }
                }, {
                    text: rec ? 'Save'.t() : 'Add'.t(),
                    action: rec ? 'save' : 'add',
                    formBind: true,
                    iconCls: 'fa fa-floppy-o',
                    handler: 'savePolicy'
                }]
            }]
        });
        me.editWin.show();
    },

    savePolicy: function (btn) {
        var me = this, 
            vm = this.getViewModel(),
            win = btn.up('window'), 
            values = btn.up('form').getValues();

        values.policyId = parseInt(values.policyId, 10);
        values.parentId = parseInt(values.parentId, 10);

        if (btn.action === 'save') {
            var editPolicy = Ext.Array.findBy(vm.get('settings.policies.list'), function (policy) {
                return policy.policyId === values.policyId;
            });
            Ext.apply(editPolicy, values);
        } else {
            vm.get('settings.policies.list').push(values);
        }

        // Save just this policy, not all other changes.
        win.setLoading(true);
        Rpc.asyncData(me.getView().appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(vm)){
                // win and btn cclaim to be destroyed at this point but not really?
                return;
            }
            win.setLoading(false);

            if (btn.action === 'add') {
                me.selectedPolicyId = values.policyId;
            }
            Ext.getStore('policiestree').build();
            me.getSettings();
        }, function(ex) {
            win.setLoading(true);
            Util.handleException(ex);
        });

        win.close();
    }

});
Ext.define('Ung.apps.policymanager.view.Policies', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-policy-manager-policies',
    itemId: 'policies',
    title: 'Policies'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'west',
        split: true,
        collapsible: false,
        width: 300,
        minWidth: 300,

        xtype: 'treepanel',
        reference: 'tree',
        title: 'Manage Policies',
        rootVisible: false,
        displayField: 'name',
        store: 'policiestree',
        useArrows: true,

        tbar: [{
            text: 'Add Policy',
            iconCls: 'fa fa-plus-circle',
            handler: 'addPolicy'
        }],
        columns: [{
            header: 'Policy'.t(),
            xtype: 'treecolumn',
            flex: 1,
            dataIndex: 'name',
            renderer: function (val, meta, rec) {
                return '<strong>' + rec.get('name') + '</strong> [' + rec.get('policyId') + ']';
            }
        }, {
            header: 'Edit'.t(),
            xtype: 'actioncolumn',
            width: Renderer.actionWidth,
            align: 'center',
            iconCls: 'fa fa-pencil',
            handler: 'editPolicy'
        }, {
            header: 'Delete'.t(),
            xtype: 'actioncolumn',
            width: Renderer.actionWidth,
            align: 'center',
            iconCls: 'fa fa-times',
            isDisabled: function (view, rowIndex, colIndex, item , record) {
                return record.get('policyId') === 1 || !record.isLeaf();
            },
            handler: 'removePolicy'
        }],
        listeners: {
            select: 'onPolicySelect'
        }
    }, {
        region: 'center',
        xtype: 'grid',
        reference: 'apps',
        title: 'Apps'.t(),
        bind: '{appsStore}',

        emptyText: 'Select Policy'.t(),
        viewConfig: {
            getRowClass: function (rec) {
                return rec.get('parentPolicy') ? 'parent-policy' : '';
            }
        },

        columns: [{
            header: 'Id',
            align: 'right',
            width: Renderer.idWidth,
            dataIndex: 'instanceId',
        }, {
            header: 'Status',
            width: Renderer.messageWidth,
            dataIndex: 'state',
            renderer: function(state){
                if(!state){
                    return '';
                }
                return Ext.String.format('<i class="fa fa-circle {0}"></i> {1}', state.get('colorCls'), state.get('status'));
            }
        }, {
            header: 'Name',
            width: Renderer.messageWidth,
            dataIndex: 'displayName',
            flex: 1,
            renderer: function (val, meta, rec) {
                return '<strong>' + val + '</strong>';
            }
        }, {
            header: 'Inherited from',
            dataIndex: 'parentPolicy',
            width: Renderer.messageWidth
        }, {
            header: 'Action'.t(),
            xtype: 'widgetcolumn',
            width: Renderer.actionWidth,
            widget: {
                xtype: 'button',
                disabled: true,
                bind: {
                    disabled: '{record.parentPolicy}',
                    text: '{record.state.on ? "Stop" : "Run"}',
                    iconCls: 'fa {record.state.on ? "fa-stop" : "fa-play"}',
                    handler: '{record.state.on ? "onStop" : "onStart"}',
                },
            },
            renderer: function (val, meta, record) {
                if (!record.get('state')) {
                    meta.style = 'display: none';
                }
            }
        }, {
            header: 'Manage'.t(),
            xtype: 'widgetcolumn',
            width: Renderer.actionWidth + 20,
            widget: {
                xtype: 'button',
                bind: {
                    text: '{(record.state && !record.parentPolicy) ? "Remove" : "Install"}',
                    iconCls: 'fa {(record.state && !record.parentPolicy) ? "fa-ban" : "fa-download"}',
                    handler: '{(record.state && !record.parentPolicy) ? "onRemove" : "onInstall"}',
                }
            }
        }]
    }]
});
Ext.define('Ung.apps.policymanager.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-policy-manager-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Policy Manager enables administrators to create different policies and handle different sessions with different policies based on rules.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    emptyText: 'No Rules defined'.t(),

    listProperty: 'settings.rules.list',

    emptyRow: {
        ruleId: -1,
        enabled: true,
        targetPolicy: 1,
        description: '',
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.policy_manager.PolicyRule'
    },

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    extraColumnConfig: {
        ruleId: { xtype: 'numberfield' },
    },

    bind: '{rules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions, {
            header: 'Target Policy'.t(),
            width: Renderer.messageWidth,
            dataIndex: 'targetPolicy',
            renderer: function (val) {
                var plc = Ext.getStore('policiestree').findNode('policyId', val);
                return plc ? plc.get('name') : '';
            },
            resizable: false,
        }
    ],
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.policy_manager.PolicyRuleCondition', [
            'DST_ADDR',
            'DST_PORT',
            'DST_INTF',
            'SRC_ADDR',
            'SRC_PORT',
            'SRC_INTF',
            'PROTOCOL',
            'TAGGED',
            'USERNAME',
            {
                name:'TIME_OF_DAY',
                displayName: 'Time of Day'.t(),
                type: "timefield"
            },{
                name:'DAY_OF_WEEK',
                displayName: 'Day of Week'.t(),
                type: "checkboxgroup",
                values: [[
                    '1', 'Sunday'.t()
                ],[
                    '2', 'Monday'.t()
                ],[
                    '3', 'Tuesday'.t()
                ],[
                    '4', 'Wednesday'.t()
                ],[
                    '5', 'Thursday'.t()
                ], [
                    '6', 'Friday'.t()
                ],[
                    '7', 'Saturday'.t()
                ]]
            },
            'HOST_HOSTNAME',
            'CLIENT_HOSTNAME',
            'SERVER_HOSTNAME',
            'SRC_MAC',
            'DST_MAC',
            'CLIENT_MAC_VENDOR',
            'SERVER_MAC_VENDOR',
            'CLIENT_IN_PENALTY_BOX',
            'SERVER_IN_PENALTY_BOX',
            'HOST_HAS_NO_QUOTA',
            'USER_HAS_NO_QUOTA',
            'CLIENT_HAS_NO_QUOTA',
            'SERVER_HAS_NO_QUOTA',
            'HOST_QUOTA_EXCEEDED',
            'USER_QUOTA_EXCEEDED',
            'CLIENT_QUOTA_EXCEEDED',
            'SERVER_QUOTA_EXCEEDED',
            'HOST_QUOTA_ATTAINMENT',
            'USER_QUOTA_ATTAINMENT',
            'CLIENT_QUOTA_ATTAINMENT',
            'SERVER_QUOTA_ATTAINMENT',
            'HOST_ENTITLED',
            'DIRECTORY_CONNECTOR_GROUP',
            'DIRECTORY_CONNECTOR_DOMAIN',
            'HTTP_USER_AGENT',
            'HTTP_USER_AGENT_OS',
            'CLIENT_COUNTRY',
            'SERVER_COUNTRY'
        ]), {
            xtype: 'combo',
            allowBlank: false,
            bind: '{record.targetPolicy}',
            fieldLabel: 'Target Policy'.t(),
            editable: false,
            displayField: 'name',
            valueField: 'policyId',
            store: 'policiestree',
            queryMode: 'local'
        }
    ]

});
Ext.define('Ung.apps.policymanager.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-policy-manager-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    items: [{
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/policy-manager.svg" width="80" height="80"/>' +
                '<h3>Policy Manager</h3>' +
                '<p>' + 'Policy Manager enables administrators to create different policies and handle different sessions with different policies based on rules.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appreports',
        }, {
            xtype: 'appremove'
        }]
    }]
});
