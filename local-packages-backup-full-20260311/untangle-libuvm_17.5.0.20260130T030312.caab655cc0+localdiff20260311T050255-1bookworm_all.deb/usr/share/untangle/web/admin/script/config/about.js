Ext.define('Ung.config.about.Main', {
    extend: 'Ung.cmp.ConfigPanel',
    alias: 'widget.config-about',
    name: 'about',

    controller: 'config-about',

    viewModel: {
        data: {
            title: 'About'.t(),
            iconName: 'about',

            kernelVersion: '',
            modificationState: '',
            rebootCount: '',
            activeSize: '',
            maxActiveSize: ''
        }
    },

    items: [{
        xtype: 'config-about-server'
    }, {
        xtype: 'config-about-licenses'
    }, {
        xtype: 'config-about-licenseagreement'
    }]

});
Ext.define('Ung.config.about.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.config-about',

    control: {
        '#': {
            afterrender: 'onAfterRender'
        },
        '#licenses': {
            afterrender: 'reloadLicenses'
        }
    },

    onAfterRender: function(){
        var me = this, v = me.getView(), vm = me.getViewModel();

        // There's nothing to save on this form.
        vm.set('panel.saveDisabled', true);

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.adminManager.getKernelVersion'),
            Rpc.asyncPromise('rpc.adminManager.getModificationState'),
            Rpc.asyncPromise('rpc.adminManager.getRebootCount'),
            Rpc.asyncPromise('rpc.hostTable.getCurrentActiveSize'),
            Rpc.asyncPromise('rpc.hostTable.getMaxActiveSize'),
            Rpc.directPromise('rpc.fullVersionAndRevision'),
            Rpc.directPromise('rpc.serverUID'),
            Rpc.directPromise('rpc.serverSerialnumber'),
            Rpc.directPromise('rpc.regionName')
        ], this)
        .then(function (result) {
            if(Util.isDestroyed(v, vm)){
                return;
            }
            var protectedAbout = new Ext.data.ArrayStore({
                fields: ['name', 'value'],
                data: []
            });
            var serverUID = result[6];
            protectedAbout.add({name: 'UID'.t(), value: serverUID});
            if (result[7] !='') {
                protectedAbout.add({name: 'Serial Number'.t(), value: result[7]});
            }
            protectedAbout.commitChanges();

            var publicAbout = new Ext.data.ArrayStore({
                fields: ['name', 'value'],
                data: []
            });
            publicAbout.add({name: 'Build'.t(), value: result[5]});
            publicAbout.add({name: 'Kernel'.t(), value: result[0]});
            publicAbout.add({name: 'Region'.t(), value: result[8]});
            publicAbout.add({name: 'History'.t(), value: result[1]});
            publicAbout.add({name: 'Reboots'.t(), value: result[2]});
            publicAbout.add({name: 'Current active device count'.t(), value: result[3]});
            publicAbout.add({name: 'Highest active device count since reboot'.t(), value: result[4]});

            publicAbout.commitChanges();

            if( serverUID &&
                serverUID.length == 19 ) {
                Ext.data.JsonP.request({
                    url: Util.getStoreUrl() + '?action=find_account&uid=' + serverUID,
                    type: 'GET',
                    success: function(response, opts) {
                        if( response!=null &&
                            response.account) {
                            protectedAbout.add({name: 'Account'.t(), value: response.account});
                            protectedAbout.commitChanges();
                        }
                    },
                    failure: function(response, opts) {
                        console.log("Failed to get account info from UID:", serverUID);
                    }
                });
            }

            vm.set({
                protectedAbout: protectedAbout,
                publicAbout: publicAbout
            });
            v.setLoading(false);
        });
    },

    reloadLicenses: function () {
        var vm = this.getViewModel(), v = this.getView();

        v.setLoading(true);
        Ung.util.Util.reloadLicenses();
        v.setLoading(false);

        Rpc.asyncData('rpc.UvmContext.licenseManager.getLicenses').
        then(function(result) {
            if(Util.isDestroyed(vm)){
                return;
            }
            vm.set('licenses', result.list);
        });
    }

});
Ext.define('Ung.config.about.view.LicenseAgreement', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-about-licenseagreement',
    itemId: 'license-agreement',
    scrollable: true,

    title: 'License Agreement'.t(),

    items: [{
        xtype: 'button',
        margin: 10,
        text: 'View License'.t(),
        iconCls: 'fa fa-file-text-o',
        href: Rpc.directData('rpc.UvmContext.getLegalUrl')
    }]

});
Ext.define('Ung.config.about.view.Licenses', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-about-licenses',
    itemId: 'licenses',
    scrollable: true,

    title: 'Licenses'.t(),
    layout: 'fit',
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px' },
        html: Ext.String.format('Licenses determine entitlement to paid applications and services. Click Refresh to force reconciliation with the license server.'.t(), '<b>', '</b>')
    }],

    items: [{
        xtype: 'ungrid',
        itemId: 'licenses',

        emptyText: 'No Licenses defined'.t(),

        bind: {
            store: {
                data: '{licenses}'
            }
        },
        columns: [{
            header: 'Name'.t(),
            dataIndex: 'displayName',
            width: Renderer.messageWidth
        }, {
            header: 'App'.t(),
            dataIndex: 'currentName',
            width: Renderer.messageWidth,
            flex: 1
        }, {
            header: 'UID'.t(),
            dataIndex: 'UID',
            width: Renderer.messageWidth
        }, {
            header: 'Start Date'.t(),
            dataIndex: 'start',
            width: Renderer.dateWidth,
            renderer: Renderer.timestamp
        }, {
            header: 'End Date'.t(),
            dataIndex: 'end',
            width: Renderer.dateWidth,
            renderer: Renderer.timestamp
        }, {
            header: 'Seats'.t(),
            dataIndex: 'seatsDisplay',
            width: Renderer.idWidth
        }, {
            header: 'Valid'.t(),
            dataIndex: 'valid',
            width: Renderer.booleanWidth
        }, {
            header: 'Status',
            dataIndex: 'status',
            width: Renderer.messageWidth
        }],

    }],

    bbar: [{
        text: 'Refresh'.t(),
        iconCls: 'fa fa-refresh',
        handler: 'reloadLicenses'
    }]

});
Ext.define('Ung.config.about.view.Server', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-about-server',
    itemId: 'server',
    scrollable: true,

    title: 'Server'.t(),

    items:[{
        xtype: 'ungrid',
        itemId: 'protected_about',

        tbar: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600, Color: 'red' },
            html: 'Do not publicly share this information.'.t()
        }],
        hideHeaders: true,

        bind: {
            store: '{protectedAbout}'
        },
        columns: [{
            header: 'Name'.t(),
            dataIndex: 'name',
            width: 250
        }, {
            header: 'Value'.t(),
            dataIndex: 'value',
            flex: 1
        }]
    },{
        xtype: 'ungrid',
        itemId: 'public_about',

        tbar: [{
            xtype: 'tbtext',
            padding: '8 5',
            html: 'Sharable information.'.t()
        }],
        hideHeaders: true,

        bind: {
            store: '{publicAbout}'
        },
        columns: [{
            header: 'Name'.t(),
            dataIndex: 'name',
            width: 250
        }, {
            header: 'Value'.t(),
            dataIndex: 'value',
            flex: 1
        }]
    }]
});
