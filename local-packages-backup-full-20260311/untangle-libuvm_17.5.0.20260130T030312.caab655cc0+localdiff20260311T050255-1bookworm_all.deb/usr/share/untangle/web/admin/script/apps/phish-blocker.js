Ext.define('Ung.apps.phishblocker.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-phish-blocker',
    controller: 'app-phish-blocker',

    items: [
        { xtype: 'app-phish-blocker-status' },
        { xtype: 'app-phish-blocker-email' }
    ]

});
Ext.define('Ung.apps.phishblocker.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-phish-blocker',

    control: {
        '#': {
            afterrender: 'getSettings',
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise(v.appManager, 'getLastUpdate')
        ]).then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set({
                settings: result[0],
                lastUpdate: result[1] ? Renderer.timestamp(result[1]) : 'Never'.t()
            });

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    }

});
Ext.define('Ung.apps.phishblocker.view.Email', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-phish-blocker-email',
    itemId: 'email',
    title: 'Email'.t(),
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'checkbox',
        boxLabel: '<strong>' + 'Scan SMTP'.t() + '</strong>',
        bind: '{settings.smtpConfig.scan}',
        padding: 5
    }],

    layout: 'fit',

    items: [{
        xtype: 'container',
        padding: 10,
        disabled: true,
        scrollable: 'y',
        layout: {
            type: 'vbox',
            // align: 'stretch'
        },
        bind: {
            disabled: '{!settings.smtpConfig.scan}'
        },
        defaults: {
            margin: '5 0',
        },
        items: [{
            xtype: 'combo',
            editable: false,
            store: [
                ['MARK', 'Mark'.t()],
                ['PASS', 'Pass'.t()],
                ['DROP', 'Drop'.t()],
                ['QUARANTINE', 'Quarantine'.t()]
            ],
            fieldLabel: 'Action'.t(),
            width: 300,
            queryMode: 'local',
            bind: {
                value: '{settings.smtpConfig.msgAction}'
            }
        }]
    }]
});
Ext.define('Ung.apps.phishblocker.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-phish-blocker-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/phish-blocker.svg" width="80" height="80"/>' +
                '<h3>Phish Blocker</h3>' +
                '<p>' + 'Phish Blocker detects and blocks phishing emails using signatures.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        },{
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + "Updates".t(),
            defaults: {
                labelWidth: 200
            },
            padding: 10,
            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },

            items: [{
                xtype: 'displayfield',
                fieldLabel: "Last update".t(),
                bind: '{lastUpdate}'
            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
