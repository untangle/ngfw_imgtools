Ext.define('Ung.apps.adblocker.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-ad-blocker',
    controller: 'app-ad-blocker',

    viewModel: {
        stores: {
            rules: { data: '{settings.rules.list}' },
            userRules: { data: '{settings.userRules.list}' },
            cookies: { data: '{settings.cookies.list}' },
            userCookies: { data: '{settings.userCookies.list}' },
            passedUrls: { data: '{settings.passedUrls.list}' },
            passedClients: { data: '{settings.passedClients.list}' }
        }
    },

    items: [
        { xtype: 'app-ad-blocker-status' },
        { xtype: 'app-ad-blocker-options' },
        { xtype: 'app-ad-blocker-adfilters' },
        { xtype: 'app-ad-blocker-cookiefilters' },
        { xtype: 'app-ad-blocker-passlists' }
    ]

});
Ext.define('Ung.apps.adblocker.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-ad-blocker',

    control: {
        '#': {
            afterrender: 'getSettings'
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result);
            vm.set('lastUpdate', result.lastUpdate || 'Never'.t());

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    updateFilters: function() {
        var me = this, v = this.getView(), vm = this.getViewModel();
        Ext.MessageBox.wait("Updating filters, this may take a few minutes...".t(), "Please wait".t());

        Rpc.asyncData(v.appManager, 'updateList')
        .then(function(result){
            if(Util.isDestroyed(me)){
                return;
            }
            Ext.MessageBox.hide();
            me.getSettings();
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                Ext.MessageBox.hide();
            }
            Util.handleException(ex);
        });
    },

    statics:{
        actionRenderer: function(value){
            return value ? 'Block'.t() : 'Pass'.t();
        },

        flaggedRenderer: function(value){
            return value ? 'Yes'.t() : '';
        }
    }

});
Ext.define('Ung.apps.ad-blocker.view.AdFilters', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ad-blocker-adfilters',
    itemId: 'ad-filters',
    title: 'Ad Filters'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    border: false,

    defaults: {
        xtype: 'ungrid',
    },

    items: [{
        region: 'center',
        title: 'Standard Filters'.t(),

        listProperty: 'settings.rules.list',
        bind: '{rules}',

        columns: [
            Column.enabled, {
                header: 'Rule'.t(),
                width: Renderer.messagwWidth,
                dataIndex: 'string',
                flex: 1
            }, {
                header: 'Action'.t(),
                width: Renderer.messagwWidth,
                dataIndex: 'blocked',
                resizable: false,
                renderer: Ung.apps.adblocker.MainController.actionRenderer
            }, {
                header: 'Slow'.t(),
                width: Renderer.messagwWidth,
                dataIndex: 'flagged',
                resizable: false,
                renderer: Ung.apps.adblocker.MainController.modeRenderer
            }]
    }, {
        region: 'south',
        height: '50%',
        split: true,

        title: 'User Defined Filters'.t(),

        tbar: ['@add', '->', '@import', '@export'],
        recordActions: ['edit', 'copy', 'delete'],
        copyAppendField: 'string',

        listProperty: 'settings.userRules.list',
        bind: '{userRules}',

        emptyText: 'No User Defined Filters defined'.t(),

        emptyRow: {
            string: '',
            enabled: true,
            blocked: true,
            javaClass: 'com.untangle.uvm.app.GenericRule'
        },

        extraColumnConfig: {
            blocked: { allowBlank: false, xtype: 'checkbox' },
            flagged: { allowBlank: false, xtype: 'checkbox' },
            name: { xtype: 'textfield' },
            description: { xtype: 'textfield' },
            readOnly: { xtype: 'checkbox' },
            id: { xtype: 'numberfield' },
            category: { xtype: 'textfield' },
            enabled: { allowBlank: false, xtype: 'checkbox' },
        },

        columns: [
            Column.enabled, {
                header: 'Rule'.t(),
                width: Renderer.messagwWidth,
                dataIndex: 'string',
                flex: 1,
                editor: {
                    xtype: 'textfield',
                    emptyText: '[enter rule]'.t(),
                    allowBlank: false
                }
            }, {
                header: 'Action'.t(),
                width: Renderer.messagwWidth,
                dataIndex: 'blocked',
                resizable: false,
                renderer: Ung.apps.adblocker.MainController.actionRenderer
            }, {
                header: 'Slow'.t(),
                width: Renderer.messagwWidth,
                dataIndex: 'flagged',
                resizable: false,
                renderer: Ung.apps.adblocker.MainController.modeRenderer
            }],
        editorFields: [{
            xtype: 'checkbox',
            bind: '{record.enabled}',
            fieldLabel: 'Enable'.t()
        }, {
            xtype: 'textfield',
            bind: '{record.string}',
            fieldLabel: 'Rule'.t(),
            emptyText: '[enter rule]'.t(),
            allowBlank: false,
            width: 400
        }, {
            xtype: 'combo',
            bind: '{record.blocked}',
            fieldLabel: 'Action'.t(),
            editable: false,
            store: [[true, 'Block'.t()], [false, 'Pass'.t()]],
            width: 200,
            queryMode: 'local'
        }]
    }]
});
Ext.define('Ung.apps.ad-blocker.view.CookieFilters', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ad-blocker-cookiefilters',
    itemId: 'cookie-filters',
    title: 'Cookie Filters'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    border: false,

    defaults: {
        xtype: 'ungrid',
    },

    items: [{
        region: 'center',
        title: 'Standard Cookie Filters'.t(),

        listProperty: 'settings.cookies.list',
        bind: '{cookies}',

        columns: [
            Column.enabled, {
                header: 'Rule'.t(),
                width: Renderer.messageWidth,
                dataIndex: 'string',
                flex: 1
            }]
    }, {
        region: 'south',
        height: '50%',
        split: true,

        title: 'User Defined Cookie Filters'.t(),

        tbar: ['@add', '->', '@import', '@export'],
        recordActions: ['edit', 'copy', 'delete'],
        copyAppendField: 'string',

        listProperty: 'settings.userCookies.list',
        bind: '{userCookies}',

        emptyRow: {
            string: '',
            enabled: true,
            javaClass: 'com.untangle.uvm.app.GenericRule'
        },

        emptyText: 'No User Defined Cookie Filters Defined'.t(),

        extraColumnConfig: {
            blocked: { xtype: 'checkbox' },
            flagged: { xtype: 'checkbox' },
            name: { xtype: 'textfield' },
            description: { xtype: 'textfield' },
            readOnly: { xtype: 'checkbox' },
            id: { xtype: 'numberfield' },
            category: { xtype: 'textfield' },
            enabled: { allowBlank: false, xtype: 'checkbox' },
        },

        columns: [
            Column.enabled, {
                header: 'Rule'.t(),
                width: Renderer.messageWidth,
                dataIndex: 'string',
                flex: 1,
                editor: {
                    xtype: 'textfield',
                    emptyText: '[enter rule]'.t(),
                    allowBlank: false
                }
            }],
        editorFields: [{
            xtype: 'checkbox',
            bind: '{record.enabled}',
            fieldLabel: 'Enable'.t()
        }, {
            xtype: 'textfield',
            bind: '{record.string}',
            fieldLabel: 'Rule'.t(),
            emptyText: '[enter rule]'.t(),
            allowBlank: false,
            width: 400
        }]
    }]

});
Ext.define('Ung.apps.ad-blocker.view.Options', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ad-blocker-options',
    itemId: 'options',
    title: 'Options'.t(),
    scrollable: true,
    withValidation: false,
    bodyPadding: 10,

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    defaults: {
        xtype: 'fieldset',
        cls: 'app-section',
        padding: 10
    },

    items: [{
        title: 'Block'.t(),
        items: [{
            xtype: 'checkbox',
            boxLabel: 'Block Ads'.t(),
            bind: '{settings.scanAds}'
        }, {
            xtype: 'checkbox',
            boxLabel: 'Block Tracking & Ad Cookies',
            bind: '{settings.scanCookies}'
        }]
    }, {
        title: 'Update filters'.t(),
        items: [{
            xtype: 'button',
            text: 'Update'.t(),
            iconCls: 'fa fa-refresh',
            handler: 'updateFilters'
        }, {
            xtype: 'component',
            margin: '10 0 0 0',
            bind: {
                html: Ext.String.format('The current filter list was last modified: {0}. You are free to disable filters and add new ones, however it is not required.'.t(),
                '{lastUpdate}')
            }
        }]
    }]
});
Ext.define('Ung.apps.ad-blocker.view.PassLists', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ad-blocker-passlists',
    itemId: 'pass-lists',
    title: 'Pass Lists'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    border: false,

    defaults: {
        xtype: 'ungrid',
    },

    items: [{
        region: 'center',
        title: 'Passed Sites'.t(),

        tbar: ['@add', '->', '@import', '@export'],
        recordActions: ['edit', 'copy', 'delete'],
        copyAppendField: 'description',

        listProperty: 'settings.passedUrls.list',
        bind: '{passedUrls}',

        emptyText: 'No Passed Sites Defined'.t(),

        emptyRow: {
            string: '',
            enabled: true,
            description: '',
            javaClass: 'com.untangle.uvm.app.GenericRule'
        },

        importValidationJavaClass: true,

        extraColumnConfig: {
            blocked: { xtype: 'checkbox' },
            flagged: { xtype: 'checkbox' },
            name: { xtype: 'textfield' },
            description: { xtype: 'textfield' },
            readOnly: { xtype: 'checkbox' },
            id: { xtype: 'numberfield' },
            category: { xtype: 'textfield' },
            enabled: { allowBlank: false, xtype: 'checkbox' },
        },

        columns: [{
            header: 'Site'.t(),
            width: Renderer.messagwWidth,
            dataIndex: 'string',
            editor:{
                xtype: 'textfield',
                allowBlank: false,
                emptyText: '[enter site]'.t(),
                validator: Util.urlValidator,
                blankText: 'Invalid URL specified'.t()
            }
        }, {
            xtype:'checkcolumn',
            header: 'Pass'.t(),
            dataIndex: 'enabled',
            resizable: false,
            width: Renderer.booleanWidth
        }, {
            header: 'Description'.t(),
            width: Renderer.messagwWidth,
            dataIndex: 'description',
            flex: 1,
            editor: {
                xtype: 'textfield',
                emptyText: '[no description]'.t()
            }
        }],

        editorFields: [{
            xtype: 'textfield',
            bind: '{record.string}',
            fieldLabel: 'Site'.t(),
            emptyText: '[enter site]'.t(),
            allowBlank: false,
            width: 400,
            validator: Util.urlValidator
        }, {
            xtype: 'checkbox',
            bind: '{record.enabled}',
            fieldLabel: 'Pass'.t()
        }, {
            xtype: 'textarea',
            bind: '{record.description}',
            fieldLabel: 'Description'.t(),
            emptyText: '[no description]'.t(),
            width: 400,
            height: 60
        }]
    }, {
        region: 'south',
        height: '50%',
        split: true,

        title: 'Passed Client IP Addresses'.t(),

        tbar: ['@add', '->', '@import', '@export'],
        recordActions: ['edit', 'copy', 'delete'],
        copyAppendField: 'description',
        listProperty: 'settings.passedClients.list',
        bind: '{passedClients}',

        emptyText: 'No Passed Client IP Addresses Defined'.t(),

        emptyRow: {
            string: '1.2.3.4',
            enabled: true,
            description: '',
            javaClass: 'com.untangle.uvm.app.GenericRule'
        },

        extraColumnConfig: {
            blocked: { xtype: 'checkbox' },
            flagged: { xtype: 'checkbox' },
            name: { xtype: 'textfield' },
            description: { xtype: 'textfield' },
            readOnly: { xtype: 'checkbox' },
            id: { xtype: 'numberfield' },
            category: { xtype: 'textfield' },
            enabled: { allowBlank: false, xtype: 'checkbox' },
        },

        columns: [{
            header: 'IP Address/Range'.t(),
            width: Renderer.networkWidth,
            dataIndex: 'string',
            editor:{
                xtype: 'textfield',
                allowBlank: false,
                emptyText: '[enter ip]'.t()
            }
        }, {
            xtype:'checkcolumn',
            header: 'Pass'.t(),
            dataIndex: 'enabled',
            resizable: false,
            width: Renderer.booleanWidth
        }, {
            header: 'Description'.t(),
            width: Renderer.messagwWidth,
            dataIndex: 'description',
            flex: 1,
            editor: {
                xtype: 'textfield',
                emptyText: '[no description]'.t()
            }
        }],

        editorFields: [{
            xtype: 'textfield',
            bind: '{record.string}',
            fieldLabel: 'IP address/range'.t(),
            emptyText: '[enter ip]'.t(),
            allowBlank: false,
            width: 400
        }, {
            xtype: 'checkbox',
            bind: '{record.enabled}',
            fieldLabel: 'Pass'.t()
        }, {
            xtype: 'textarea',
            bind: '{record.description}',
            fieldLabel: 'Description'.t(),
            emptyText: '[no description]'.t(),
            width: 400,
            height: 60
        }]
    }]
});
Ext.define('Ung.apps.ad-blocker.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-ad-blocker-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: {
        formulas: {
            statistics: function (get) {
                return [{
                    name: 'Total Filters Available'.t(),
                    value: get('settings.rules.list').length + get('settings.userRules.list').length
                }, {
                    name: 'Total Filters Enabled'.t(),
                    value: Ext.Array.filter(get('settings.rules.list'), function (r) { return r.enabled; }).length +
                        Ext.Array.filter(get('settings.userRules.list'), function (r) { return r.enabled; }).length
                }, {
                    name: 'Total Cookie Rules Available'.t(),
                    value: get('settings.cookies.list').length + get('settings.userCookies.list').length
                }, {
                    name: 'Total Cookie Rules Enabled'.t(),
                    value: Ext.Array.filter(get('settings.cookies.list'), function (c) { return c.enabled; }).length +
                        Ext.Array.filter(get('settings.userCookies.list'), function (c) { return c.enabled; }).length
                }];
            }
        }
    },

    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/ad-blocker.svg" width="80" height="80"/>' +
                '<h3>Ad Blocker</h3>' +
                '<p>' + 'Ad Blocker blocks advertising content and tracking cookies for scanned web traffic.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true,
        }, {
            xtype: 'propertygrid',
            region: 'center',
            title: 'Statistics'.t(),
            border: false,
            nameColumnWidth: 250,
            sortableColumns: false,
            disabled: true,
            hideHeaders: true,
            bind: {
                disabled: '{!state.on}',
                store: { data: '{statistics}' }
            },
            listeners: {
                beforeedit: function () {
                    return false;
                }
            }
        }, {
            xtype: 'appmetrics',
            region: 'south',
            split: true,
            height: '40%'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
