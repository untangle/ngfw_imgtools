Ext.define('Ung.apps.directoryconnector.view.ActiveDirectoryGroups', {
    extend: 'Ext.window.Window',
    alias: 'widget.app-directory-connector-activedirectorygroups',
    width: 900,
    height: 600,

    layout: 'fit',
    scrollable: true,

    onEsc: Ext.emptyFn,
    closable: false,
    modal: true,

    tbar: [{
        xtype: 'ungridfilter'
    }],

    items: [{
        xtype: 'ungrid',
        name: 'mapGrid',
        hasEdit: false,
        hasDelete: false,
        hasAdd: false,
        sortField: 'uid',
        reserveScrollbar: true,
        store: [],
        plugins:['gridfilters'],
        columnMenuDisabled: false,
        fields:[{
            name: 'uid'
        },{
            name:'groups'
        },{
            name:'domain'
        }],
        viewConfig: {
            stripeRows: true,
            enableTextSelection: true,
            // Workaround for text selection in Ext 6.2
            getRowClass: function () {
                return this.enableTextSelection ? 'x-selectable' : '';
            }
        },
        columns: [{
            header: 'Name'.t(),
            dataIndex:'group',
            sortable: true,
            width: Renderer.usernameWidth,
            flex: 1,
            filter: {
                type: 'string'
            }
        },{
            header: 'Users'.t(),
            dataIndex: 'users',
            sortable: true,
            width: Renderer.messageWidth,
            flex: 1,
            filter: {
                type: 'string'
            }
        },{
            header: 'Domains'.t(),
            dataIndex: 'domains',
            sortable: true,
            width: Renderer.hostnameWidth,
            flex: 1,
            filter: {
                type: 'string'
            }
        }]
    }],

    buttons: [{
        text: 'Close',
        iconCls: 'fa fa-close',
        handler: 'closeWindow'
    }]

});

Ext.define('Ung.apps.directoryconnector.view.ActiveDirectoryUsers', {
    extend: 'Ext.window.Window',
    alias: 'widget.app-directory-connector-activedirectoryusers',
    width: 900,
    height: 600,

    layout: 'fit',
    scrollable: true,

    onEsc: Ext.emptyFn,
    closable: false,
    modal: true,

    tbar: [{
        xtype: 'ungridfilter'
    }],

    items: [{
        xtype: 'ungrid',
        name: 'mapGrid',
        hasEdit: false,
        hasDelete: false,
        hasAdd: false,
        sortField: 'uid',
        // reserveScrollbar: true,
        store: [],
        plugins:['gridfilters'],
        columnMenuDisabled: false,
        fields:[{
            name: 'uid'
        },{
            name:'domain'
        }],
        viewConfig: {
            stripeRows: true,
            enableTextSelection: true,
            // Workaround for text selection in Ext 6.2
            getRowClass: function () {
                return this.enableTextSelection ? 'x-selectable' : '';
            }
        },
        columns: [{
            header: 'Name'.t(),
            dataIndex:'uid',
            sortable: true,
            width: Renderer.usernameWidth,
            flex: 1,
            filter: {
                type: 'string'
            }
        },{
            header: 'Groups'.t(),
            dataIndex:'groups',
            sortable: true,
            width: Renderer.usernameWidth,
            flex: 1,
            filter: {
                type: 'string'
            }
        },{
            header: 'Domain'.t(),
            dataIndex: 'domain',
            sortable: true,
            width: Renderer.hostnameWidth,
            flex: 1,
            filter: {
                type: 'string'
            }
        }]
    }],

    buttons: [{
        text: 'Close',
        iconCls: 'fa fa-close',
        handler: 'closeWindow'
    }]

});

Ext.define('Ung.apps.directoryconnector.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-directory-connector',
    controller: 'app-directory-connector',

    viewModel: {
        type: 'app-directory-connector',
    },

    items: [
        { xtype: 'app-directory-connector-status' },
        { xtype: 'app-directory-connector-usernotificationapi' },
        { xtype: 'app-directory-connector-activedirectory' },
        { xtype: 'app-directory-connector-radius' }
    ]

});
Ext.define('Ung.apps.directory-connector.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-directory-connector',

    control: {
        '#': {
            afterrender: 'getSettings',
        }
    },

    getSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this,
            v = this.getView(),
            vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        if (vm.get('settings').radiusSettings.enabled) {
            var isValidUrl = Util.urlIpValidator(vm.get('settings').radiusSettings.server);
            if (isValidUrl !== true) {
                Ext.Msg.alert('Warning'.t(), isValidUrl);
                return;
            }
        }

        v.setLoading(true);
        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    downloadUserApiScript: function(){
        window.open("../userapi/");
    },

    closeWindow: function (button) {
        button.up('window').close();
    },


    activeDirectoryUsers: function(domain){
        var v = this.getView();

        if(typeof(domain) == "object"){
            domain = null;
        }

        Ext.MessageBox.wait( "Obtaining users...".t(), "Active Directory Users".t());
        var dialog = v.add({
            xtype: 'app-directory-connector-activedirectoryusers',
            title: domain ? domain + ' ' + 'Users'.t(): 'All Users'.t()
        });

        Rpc.asyncData( v.appManager.getActiveDirectoryManager(), 'getUsers', domain)
        .then(function(result){
            if(Util.isDestroyed(v, dialog)){
                return;
            }
            dialog.show();
            dialog.down("[name=mapGrid]").getStore().loadData(result);
            Ext.MessageBox.close();
        }, function(ex){
            Ext.MessageBox.close();
            Util.handleException(ex);
        });

    },

    activeDirectoryGroupMap: function(domain){
        var v = this.getView();

        if(typeof(domain) == "object"){
            domain = null;
        }

        Ext.MessageBox.wait( "Obtaining user group map...".t(), "Active Directory Users".t());
        var dialog = v.add({
            xtype: 'app-directory-connector-activedirectorygroups',
            title: 'All Groups'.t()
        });

        Rpc.asyncData( v.appManager.getActiveDirectoryManager(), 'getUsers', domain)
        .then(function(result){
            if(Util.isDestroyed(v, dialog)){
                return;
            }
            var groups = [];
            result.forEach(function(user){
                var groupIndex = null;
                user["groups"].forEach(function(userGroup){
                    var group = Ext.Array.findBy(groups, function(row, index){
                        if(row['group'] == userGroup){
                            return true;
                        }
                    });
                    if(group == null){
                        groups.push({
                            'group': userGroup,
                            'users': [],
                            'domains': []
                        });
                        group = groups[groups.length - 1];
                    }
                    if(group['users'].indexOf(user['uid']) == -1){
                        group['users'].push(user['uid']);
                    }
                    if(group['domains'].indexOf(user['domain']) == -1){
                        group['domains'].push(user['domain']);
                    }
                });
            });

            dialog.show();
            dialog.down("[name=mapGrid]").getStore().loadData(groups);
            Ext.MessageBox.close();
        }, function(ex){
            Ext.MessageBox.close();
            Util.handleException(ex);
        });

    },

    activeDirectoryGroupRefreshCache: function(){
        Ext.MessageBox.wait( "Refreshing Group Cache...".t(), "Refresh Group Cache".t());
        Rpc.asyncData( this.getView().appManager, 'refreshGroupCache')
        .then(function(result){
            Ext.MessageBox.close();
        }, function(ex){
            Ext.MessageBox.close();
            Util.handleException(ex);
        });
    },

    radiusTest: function(){
        var v = this.getView(), vm = this.getViewModel();

        Ext.MessageBox.wait( "Testing RADIUS...".t(), "RADIUS Test".t());
        var username = v.down('textfield[name=radiusTestUsername]').getValue();
        var password = v.down('textfield[name=radiusTestPassword]').getValue();

        Rpc.asyncData( v.appManager.getRadiusManager(), 'getRadiusStatusForSettings', vm.get('settings'), username, password )
        .then(function(result){
            var message = result.t();
            Ext.MessageBox.alert("RADIUS Test".t(), message);
        }, function(ex){
            Ext.MessageBox.close();
            Util.handleException(ex);
        });
    },
});

Ext.define('Ung.apps.directory-connector.ActiveDirectoryServerGridController', {
    extend: 'Ung.cmp.GridController',

    alias: 'controller.unadserversgrid',

    ouFilterRenderer: function(u,cell,record){
        return record.get('OUFilters').list.join(', ');
    },

    azureChanger: function(elem, rowIndex, checked){
        var record;
        if( typeof(rowIndex) == 'object'){
            record = rowIndex;
        }else{
            record = elem.getView().getRecord(rowIndex);
        }

        var azureValue;
        if(checked === undefined){
            azureValue = elem.getValue();
        }else{
            azureValue = checked;
        }

        if(azureValue){
            record.set('LDAPSecure', true);
            this.portChanger(null, record, true);
        }
    },

    portChanger: function(elem, rowIndex, checked){
        var record;
        if( typeof(rowIndex) == 'object'){
            record = rowIndex;
        }else{
            record = elem.getView().getRecord(rowIndex);
        }

        var secureValue;
        if(checked === undefined){
            secureValue = elem.getValue();
        }else{
            secureValue = checked;
        }

        var currentPortValue = record.get('LDAPPort');
        if( secureValue ){
            if( currentPortValue == "389"){
                record.set('LDAPPort', '636');
            }
        }else{
            if( currentPortValue == "636"){
                record.set('LDAPPort', '389');
            }
        }
    },

    serverTest: function( element, rowIndex, columnIndex, column, pos, record){
        var v = this.getView();

        var settings = Ext.clone(record.data);
        var ouFilterGrid = v.query('[itemId=unoufiltergrid]');
        if(ouFilterGrid.length){
            ouFilterGrid.forEach( function( grid ){
                var ouFilters = [];
                grid.getStore().each( function(record){
                    if (record.get('markedForDelete')){
                        return;
                    }
                    ouFilters.push(record.get('field1'));
                });
                settings.OUFilters.list = ouFilters;
                settings.ouFiltersQuery = ouFilters.join('<br>');
            });
        }else{
            settings.OUFilter = record.get('OUFilters');
            settings.ouFiltersQuery = record.get('OUFilters')['list'].join('<br>');
        }

        Ext.create('Ung.apps.directory-connector.cmp.ActiveDirectoryServerTest', {
            settings: settings,
            appManager: v.up('[itemId=appCard]').appManager
        });
    },

    serverUsers: function( element, rowIndex, columnIndex, column, pos, record){
        this.getView().up('[itemId=appCard]').getController().activeDirectoryUsers(record.get('domain'));
    },

    serverGroupMap: function( element, rowIndex, columnIndex, column, pos, record){
        this.getView().up('[itemId=appCard]').getController().activeDirectoryGroupMap(record.get('domain'));
    },

    isServerDisabled: function(table, rowIndex, colIndex, item, record){
        return !record.get('enabled');
    },

});

Ext.define('Ung.apps.directory-connector.cmp.ActiveDirectoryServerTest', {
    extend: 'Ext.window.Window',
    modal: true,

    alias: 'widget.apps.directory-connector.activedirectoryservertest',

    controller: 'app.activedirectoryservertest',

    title: 'Active Directory Test'.t(),
    autoShow: true,

    layout: 'fit',
    plain: false,
    bodyBorder: false,
    border: false,

    items: [{
        xtype: 'form',
        layout: 'anchor',
        items: [{
            xtype: 'fieldset',
            title: 'Settings'.t(),
            items: [{
                xtype: 'displayfield',
                fieldLabel: 'Domain',
                bind:{
                    value: '{settings.domain}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'OU',
                hidden: true,
                bind:{
                    value: '{settings.ouFiltersQuery}',
                    hidden: '{settings.ouFiltersQuery == ""}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'Azure',
                bind:{
                    value: '{settings.azure}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'Host',
                bind:{
                    value: '{settings.LDAPHost}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'Secure',
                bind:{
                    value: '{settings.LDAPSecure}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'User',
                bind:{
                    value: '{settings.superuser}'
                }
            }]
        }, {
            xtype: 'progressbar',
            name: 'checkUpgradesProgressbar',
            bind:{
                visible: '{completed == false}',
                hidden: '{completed == true}'
            }
        }, {
            xtype: 'fieldset',
            title: 'Status'.t(),
            hidden: true,
            bind:{
                hidden: '{completed == false}'
            },
            items: [{
                xtype: 'displayfield',
                fieldLabel: 'Result',
                bind: {
                    value: '<i class="fa {statusIcon} fa-fw" style="color: {statusIconColor};"></i> <b>{statusText}</b>',
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'Search Base(s)',
                bind:{
                    value: '{status.searchBases}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'Users found',
                hidden: true,
                bind:{
                    value: '{status.userCount}',
                    hidden: '{statusResult == "FAIL"}'
                }
            },{
                xtype: 'displayfield',
                fieldLabel: 'Groups found',
                hidden: true,
                bind:{
                    value: '{status.groupCount}',
                    hidden: '{statusResult == "FAIL"}'
                }
            }]
        }],

        buttons: [{
            text: 'Ok'.t(),
            handler: 'close'
        }]
    }],

    viewModel: {
        data: {
            processingIcon: null,
            processing: false
        },
    }

});

Ext.define('Ung.apps.directory-connector.cmp.ActiveDirectoryServerTestController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app.activedirectoryservertest',

    control: {
        '#': {
            afterrender: 'afterrender',
        }
    },

    afterrender: function(){
        var v = this.getView(), vm = this.getViewModel();

        vm.set('completed', false);

        var progressbar = v.down('progressbar');

        progressbar.wait('Checking...');
        vm.set('settings', v.settings);

        Rpc.asyncData( v.appManager.getActiveDirectoryManager(), 'getStatusForSettings', vm.get('settings'))
        .then(function(status){
            if(Util.isDestroyed(v, vm, progressbar)){
                return;
            }
            progressbar.reset();
            progressbar.updateText('Completed'.t());

            vm.set('completed', true);
            var statusResults = status['status'].split('_');
            vm.set('statusResult', statusResults[0]);
            var statusIcon = 'fa-close';
            var statusIconColor = 'red';
            if(statusResults[0] == 'PASS'){
                statusIcon = 'fa-check';
                statusIconColor = 'green';
            }else if(statusResults[0] == 'WARN'){
                statusIcon = 'fa-exclamation-triangle';
                statusIconColor = '#CCCC00';
            }
            vm.set('statusIcon', statusIcon);
            vm.set('statusIconColor', statusIconColor);

            var statusText = "";
            switch(status['status']){
                case 'WARN_QUERY_NO_USERS':
                    statusText = 'Successfully queried but no users found.'.t();
                    break;
                case 'FAIL_EMPTY_SETTINGS':
                    statusText = 'Empty settings!'.t();
                    break;
                case 'FAIL_QUERY':
                    statusText = 'Connection Failed: Check AD server settings, certificates, network, and firewall rules.'.t();
                    break;
                case 'AUTH_QUERY_FAIL':
                    statusText = 'Authentication failure!'.t();
                    break;
                case 'FAIL_QUERY_NONE':
                    statusText = 'Query failed, cannot find object defined by domain and OU'.t();
                    break;
                case 'FAIL_QUERY_REFERRAL':
                    statusText = 'Response contained a referral defined by domain and OU'.t();
                    break;
                case 'PASS':
                    statusText = 'Success!'.t();
                    break;
            }
            vm.set('statusText', statusText);
            status.searchBases = status.searchBases.join("<br>");
            vm.set('status', status);
        }, function(ex){
            Ext.MessageBox.close();
            Util.handleException(ex);
        });
    },

    close: function () {
        this.getView().close();
    }

});


Ext.define('Ung.apps.directory-connector.cmp.ActiveDirectoryServerRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unactivedirectoryserverrecordeditor',

    controller: 'unactivedirectoryserverrecordeditorcontroller'

});

Ext.define('Ung.apps.directory-connector.cmp.ActiveDirectoryServerRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unactivedirectoryserverrecordeditorcontroller',

    onApply: function () {
        var v = this.getView(), vm = this.getViewModel();

        if (!this.action) {
            for (var fieldName in vm.get('record').modified) {
                v.record.set(fieldName, vm.get('record').get(fieldName));
            }
        }else if (this.action === 'add') {
            this.mainGrid.getStore().add(v.record);
        }

        v.query('[itemId=unoufiltergrid]').forEach( function( grid ){
            var ouFiltersData = vm.get('record').get('OUFilters');
            var ouFilters = [];
            grid.getStore().each( function(record){
                if (record.get('markedForDelete')){
                    return;
                }
                ouFilters.push(record.get('field1'));
            });
            ouFiltersData.list = ouFilters;
            vm.get('record').set('OUFilters', ouFiltersData);
            v.up('grid').getView().refresh();
        });
        v.close();
    },

    azureChanger: function(element){
        this.getView().up('grid').getController().azureChanger(element, this.getViewModel().get('record') );
    },

    portChanger: function(element){
        this.getView().up('grid').getController().portChanger(element, this.getViewModel().get('record') );
    },

    serverTest: function(element){
        this.getView().up('grid').getController().serverTest( element, 0, 0, null, null, this.getViewModel().get('record'));
    }
});
Ext.define('Ung.apps.directoryconnector.MainModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.app-directory-connector',

    data: {
        // title: 'Events'.t(),
        // iconName: 'events',

        settings: null,
        record: null

    },

    stores: {
        activeDirectoryServers: { data: '{settings.activeDirectorySettings.servers.list}' }
    }
});
Ext.define('Ung.apps.directoryconnector.view.ActiveDirectory', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-directory-connector-activedirectory',
    itemId: 'active-directory',
    title: 'Active Directory'.t(),
    withValidation: false,
    viewModel: true,
    bodyPadding: 10,
    scrollable: true,

    items:[{
        xtype: 'fieldset',
        title: 'Active Directory Connector'.t(),
        items: [{
            xtype: 'component',
            margin: '10 0 0 0',
            html: Ext.String.format(
                "This allows the server to connect to an {0}Active Directory Server{1} for authentication of username/passwords and building of a user-group map.".t(),
                '<b>','</b>')
        }, {
            xtype: 'component',
            margin: '10 0 0 20',
            html: Ext.String.format(
                "{0}NOTE:{1}  Additional steps are required to associate hosts and sessions with usernames, such as using Captive Portal, the Active Directory Server Login Monitor Agent, or the Login Script.".t() + "</br>" +
                    "See {0}Help{1} for more details.".t(),
                '<i>','</i>','<i>','</i>')
        }, {
                xtype: "checkbox",
                bind: '{settings.activeDirectorySettings.enabled}',
                fieldLabel: 'Enable Active Directory Connector'.t(),
                labelWidth: '100%',
                margin: '10 0 10 0',
                listeners: {
                    disable: function (ck) {
                        ck.setValue(false);
                    }
                }
            }, {
                xtype: 'ungrid',
                controller: 'unadserversgrid',
                split: true,
                title: 'Active Directory Servers'.t(),
                margin: '10 10 10 0',

                tbar: ['@add', '->', '@import', '@export'],
                recordActions: ['edit', 'delete', 'reorder'],

                listProperty: 'settings.activeDirectorySettings.servers.list',
                ruleJavaClass: 'com.untangle.app.directory_connector.ActiveDirectoryServer',

                importValidationJavaClass: true,
                importValidatorParams: { "superuserPass": "encrSupUserPass" },

                emptyRow: {
                    LDAPHost: '',
                    LDAPPort: 636,
                    LDAPSecure: true,
                    OUFilters: {
                        javaClass: "java.util.LinkedList",
                        list: []
                    },
                    domain: '',
                    enabled: true,
                    javaClass: "com.untangle.app.directory_connector.ActiveDirectoryServer",
                    superuser: '',
                    superuserPass:''
                },

                disabled: true,
                hidden: true,

                bind: {
                    store: '{activeDirectoryServers}',
                    disabled: '{!settings.activeDirectorySettings.enabled}',
                    hidden: '{!settings.activeDirectorySettings.enabled}'
                },

                columns: [{
                    xtype: 'checkcolumn',
                    header: 'Enabled'.t(),
                    dataIndex: 'enabled',
                    resizable: false,
                    width: Renderer.actionWidth
                }, {
                    header: 'Domain'.t(),
                    dataIndex: 'domain',
                    flex: 1,
                    editor: {
                        xtype: 'textfield',
                        bind: '{record.domain}'
                    }
                }, {
                    xtype: 'checkcolumn',
                    header: 'Azure'.t(),
                    dataIndex: 'azure',
                    width: Renderer.actionWidth,
                    listeners: {
                        beforecheckchange: 'azureChanger'
                    },
                }, {
                    header: 'OU Filters'.t(),
                    width: Renderer.messageWidth,
                    dataIndex: 'record.OUFilters.list',
                    renderer: 'ouFilterRenderer',
                    flex: 1
                }, {
                    header: 'Host'.t(),
                    dataIndex: 'LDAPHost',
                    flex: 1,
                    width: Renderer.hostnameWidth,
                    editor: {
                        xtype: 'textfield',
                        bind: '{record.LDAPHost}'
                    }
                }, {
                    header: 'Port'.t(),
                    width: Renderer.portWidth,
                    dataIndex: 'LDAPPort',
                    editor: {
                        xtype: 'numberfield',
                        bind: '{record.LDAPPort}',
                        minValue: 0,
                        maxValue: 65535,
                    }
                }, {
                    xtype: 'checkcolumn',
                    header: 'Secure'.t(),
                    width: Renderer.actionWidth,
                    dataIndex: 'LDAPSecure',
                    listeners: {
                        beforecheckchange: 'portChanger'
                    },
                }, {
                    xtype: 'actioncolumn',
                    header: 'Test'.t(),
                    width: Renderer.actionWidth,
                    iconCls: 'fa fa-cogs',
                    align: 'center',
                    handler: 'serverTest',
                    isDisabled: 'isServerDisabled'
                }, {
                    xtype: 'actioncolumn',
                    header: 'Users'.t(),
                    width: Renderer.actionWidth,
                    iconCls: 'fa fa-user',
                    align: 'center',
                    handler: 'serverUsers',
                    isDisabled: 'isServerDisabled'
                }, {
                    xtype: 'actioncolumn',
                    header: 'Groups'.t(),
                    width: Renderer.actionWidth,
                    iconCls: 'fa fa-user',
                    align: 'center',
                    handler: 'serverGroupMap',
                    isDisabled: 'isServerDisabled'
                }],

                editorXtype: 'ung.cmp.unactivedirectoryserverrecordeditor',
                editorFields: [
                    Field.enableRule(),
                {
                    xtype: 'textfield',
                    fieldLabel: 'Domain'.t(),
                    bind: '{record.domain}',
                    emptyText: '[no domain]'.t(),
                    allowBlank: false
                },{
                    xtype: 'checkbox',
                    fieldLabel: 'Azure'.t(),
                    bind: '{record.azure}',
                    handler: 'azureChanger',
                    listeners: {
                        beforecheckchange: 'azureChanger'
                    }
                },{
                    xtype: 'container',
                    layout: 'column',
                    margin: '0 0 5 0',
                    width: 800,
                    items: [{
                        xtype: 'label',
                        html: 'Active Directory Organizations'.t(),
                        width: 190,
                    },{
                        xtype: 'ungrid',
                        itemId: 'unoufiltergrid',
                        width: 305,
                        border: false,
                        titleCollapse: true,
                        tbar: ['@addInline'],
                        recordActions: ['delete'],
                        bind: '{record.OUFilters.list}',
                        maxHeight: 140,
                        emptyRow: {
                            field1: ''
                        },
                        columns: [{
                            header: 'Organizational Unit'.t(),
                            dataIndex: 'field1',
                            width: 200,
                            flex: 1,
                            editor : {
                                xtype: 'textfield',
                                vtype: 'x500attributes',
                                emptyText: '[enter OU]'.t(),
                                allowBlank: false
                            }
                        }]
                    },{
                        xtype: 'label',
                        html: '(optional)'.t(),
                        cls: 'boxlabel'
                    }]
                },{
                    xtype: 'textfield',
                    fieldLabel: 'Host'.t(),
                    bind: '{record.LDAPHost}',
                    emptyText: '[no host]'.t(),
                    allowBlank: false
                },{
                    xtype: 'numberfield',
                    fieldLabel: 'Port'.t(),
                    bind: '{record.LDAPPort}', 
                    emptyText: '[no port]'.t(),
                    allowBlank: false,
                    minValue: 0,
                    maxValue: 65535,
                },{
                    xtype: 'checkbox',
                    fieldLabel: 'Secure'.t(),
                    bind: '{record.LDAPSecure}',
                    handler: 'portChanger',
                    listeners: {
                        beforecheckchange: 'portChanger'
                    }
                }, {
                    xtype: 'textfield',
                    fieldLabel: 'Authentication Login'.t(),
                    bind: '{record.superuser}',
                    emptyText: '[no authentication login]'.t(),
                    allowBlank: false
                }, {
                    xtype: 'textfield',
                    inputType: 'password',
                    fieldLabel: 'Authentication Password'.t(),
                    bind: '{record.superuserPass}',
                    validator: function (value, encPass) {
                        // Either superuserPass or encrSupUserPass should not be blank
                        if(value) return true;
                        var emptyText = "[Leave empty to keep the current password unchanged]".t();
                        // encPass is recieved from import validation call
                        if(encPass) {
                            this.emptyText = emptyText;
                            return true;
                        }
                        if(this.lookupViewModel) {
                            var record = this.lookupViewModel().get('record');
                            if(record && record.data.encrSupUserPass) {
                                this.emptyText = emptyText;
                                return true;
                            } 
                        }
                        this.emptyText = "[no authentication password]".t();
                        return "This field is required".t();
                    }
                },{
                    xtype: 'container',
                    layout: 'column',
                    items:[{
                        xtype: 'button',
                        text: 'Active Directory Test'.t(),
                        margin: '10 0 10 0',
                        iconCls: 'fa fa-cogs',
                        disabled: true,
                        bind: {
                            disabled: '{record.enabled == false || record.domain == "" || record.LDAPHost == "" || record.LDAPPort == "" || record.superuser == "" || record.password == ""}'
                        },
                        handler: 'serverTest'
                    },{
                        xtype: 'component',
                        margin: '12 0 10 10',
                        html: Ext.String.format( 'Verify the connection to the Active Directory Server.'.t(),'<b>','</b>')
                    }]
                }]
        },{
            xtype: 'panel',
            disabled: true,
            hidden: true,
            bind: {
                disabled: '{!settings.activeDirectorySettings.enabled}',
                hidden: '{!settings.activeDirectorySettings.enabled}'
            },
            border: 0,
            margin: '0 0 10 0',
            layout: {
                type: 'table',
                columns: 2
            },
            items:[{
                xtype: 'button',
                text: 'Users'.t(),
                iconCls: 'fa fa-user',
                handler: 'activeDirectoryUsers'
            },{
                xtype: 'label',
                margin: '0 0 0 10',
                html: "Verify all users from all servers.".t() + ' ' + 'In additional to authentication, some rules allow for user matching conditions.'.t(),
                cls: 'boxlabel'
            },{
                xtype: 'button',
                text: 'Groups'.t(),
                iconCls: 'fa fa-group',
                handler: 'activeDirectoryGroupMap'
            },{
                xtype: 'label',
                margin: '0 0 0 10',
                html: "Verify all user group mappings from all servers.".t() + ' ' + 'Some rules allow for group matching conditions.'.t(),
                cls: 'boxlabel'
            },{
                xtype: 'button',
                text: 'Refresh Group Cache'.t(),
                iconCls: 'fa fa-refresh',
                handler: 'activeDirectoryGroupRefreshCache'
            },{
                xtype: 'label',
                margin: '0 0 0 10',
                html: "The group cache automatically refreshes every 20 minutes.".t() + ' ' + "Force an immediate refresh.".t(),
                cls: 'boxlabel'
            }]
        }]
    }]
});
Ext.define('Ung.apps.directoryconnector.view.Radius', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-directory-connector-radius',
    itemId: 'radius',
    title: 'RADIUS'.t(),
    withValidation: true,

    viewModel: true,
    bodyPadding: 10,
    scrollable: true,

    items:[{
        xtype: 'fieldset',
        title: 'RADIUS Connector'.t(),
        items: [{
            xtype: 'component',
            margin: '10 0 0 0',
            html: Ext.String.format(
                "This allows your server to connect to a {0}RADIUS Server{1} in order to identify users for use by Captive Portal and L2TP/IPsec.".t(),
                '<b>','</b>')
        }, {
            xtype: "checkbox",
            bind: '{settings.radiusSettings.enabled}',
            fieldLabel: 'Enable RADIUS Connector'.t(),
            labelWidth: 200,
            margin: '10 0 10 0',
            listeners: {
                disable: function (ck) {
                    ck.setValue(false);
                }
            }
        }, {
            xtype: 'fieldset',
            border: 0,
            hidden: true,
            disabled: true,
            bind: {
                hidden: '{settings.radiusSettings.enabled == false}',
                disabled: '{settings.radiusSettings.enabled == false}'
            },
            defaults: {
                labelWidth: 190,
                width: 400
            },
            items: [{
                xtype: 'textfield',
                fieldLabel: 'RADIUS Server IP or Hostname'.t(),
                bind: '{settings.radiusSettings.server}'
            }, {
                xtype: 'textfield',
                fieldLabel: 'Authentication Port'.t(),
                bind: '{settings.radiusSettings.authPort}'
            }, {
                xtype: 'textfield',
                fieldLabel: 'Accounting Port'.t(),
                bind: '{settings.radiusSettings.acctPort}'
            },{
                xtype: 'textfield',
                fieldLabel: 'Shared Secret'.t(),
                bind: '{settings.radiusSettings.sharedSecret}',
                maxLength: 48,
                enforceMaxLength: true,
            },{
                xtype: "combo",
                fieldLabel: "Authentication Method".t(),
                bind: '{settings.radiusSettings.authenticationMethod}',
                store: [
                    [ "MSCHAPV2", "MS-CHAP v2".t() ],
                    [ "MSCHAPV1", "MS-CHAP v1".t() ],
                    [ "CHAP", "CHAP".t() ],
                    [ "PAP", "PAP".t() ]
                ],
                queryMode: 'local',
            },{
                xtype: 'container',
                width: 'auto',
                html: 'IMPORTANT'.t() + ':</b>&nbsp;&nbsp' + 'When using Windows as a RADIUS server, the best security and compatibility is achieved by selecting MS-CHAP v2.  Please also make sure the MS-CHAP v2 protocol is enabled for RADIUS clients in the Windows Network Policy Server.'.t()
            }]
        }, {
            xtype: 'fieldset',
            title: 'RADIUS Test'.t(),
            hidden: true,
            disabled: true,
            bind: {
                hidden: '{settings.radiusSettings.enabled == false}',
                disabled: '{settings.radiusSettings.enabled == false}'
            },
            defaults: {
                labelWidth: 190,
                width: 400
            },
            items: [{
                xtype: 'component',
                width: 'auto',
                margin: '10 0 10 0',
                html: Ext.String.format( 'The {0}RADIUS Test{1} verifies that the server can authenticate the provided username/password.'.t(),'<b>','</b>')
            },{
                xtype:'textfield',
                name: 'radiusTestUsername',
                fieldLabel: 'Username'.t(),
                _neverDirty: true
            },{
                xtype:'textfield',
                name: 'radiusTestPassword',
                fieldLabel: 'Password'.t(),
                inputType: 'password',
                _neverDirty: true
            },{
                xtype: 'button',
                text: 'RADIUS Test'.t(),
                iconCls: 'fa fa-cogs',
                labelWidth: 'auto',
                width: 'auto',
                margin: '10 0 10 0',
                handler: 'radiusTest'
            }]
        }]
    }]
});
Ext.define('Ung.apps.directoryconnector.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-directory-connector-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    items: [{
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/directory-connector.svg" width="80" height="80"/>' +
                '<h3>Directory Connector</h3>' +
                '<p>' + 'Directory Connector allows integration with external directories and services, such as Active Directory and RADIUS.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appreports'
        }, {
            xtype: 'appremove'
        }]
    }]
});
Ext.define('Ung.apps.directoryconnector.view.UserNotificationApi', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-directory-connector-usernotificationapi',
    itemId: 'user-notification-api',
    title: 'User Notification API'.t(),
    scrollable: true,
    withValidation: true,
    viewModel: true,
    bodyPadding: 10,

    items:[{
        xtype: 'fieldset',
        title: 'User Notification API'.t(),
        items: [{
            xtype: 'component',
            margin: '10 0 10 0',
            html: "The User Notification API provides a web-based app/API to allow scripts and agents to update the server's username-to-IP address mapping in order to properly identify users for Policy Manager, Reports, and other applications.".t()
       }, {
            xtype: "checkbox",
            bind: '{settings.apiEnabled}',
            fieldLabel: 'Enable User Notification API'.t(),
            labelWidth: 190,
            listeners: {
                disable: function (ck) {
                    ck.setValue(false);
                }
            }
        }, {
            xtype: 'fieldset',
            margin: '10 10 10 -10',
            border: 0,
            hidden: true,
            disabled: true,
            bind: {
                hidden: '{settings.apiEnabled == false}',
                disabled: '{settings.apiEnabled == false}'
            },
            items: [{
                xtype: 'fieldcontainer',
                layout: 'column',
                items: [{
                    xtype:'textfield',
                    name: 'secretKey',
                    fieldLabel: 'Secret Key'.t(),
                    labelWidth: 190,
                    bind: '{settings.apiSecretKey}',
                }]
        },{
            xtype: 'component',
            margin: '10 0 10 0',
            html: "If you use an Active Directory server, you should install the Active Directory Login Monitor on the server as described by the help documentation.  Otherwise, you will need to download and install the following script on all clients.".t()
        }, {
                xtype: 'button',
                text: 'Download User Notification Login Script'.t(),
                iconCls: 'fa fa-download',
                margin: '10 0 10 0',
                handler: 'downloadUserApiScript'
            }]
        }]
    }]
});
