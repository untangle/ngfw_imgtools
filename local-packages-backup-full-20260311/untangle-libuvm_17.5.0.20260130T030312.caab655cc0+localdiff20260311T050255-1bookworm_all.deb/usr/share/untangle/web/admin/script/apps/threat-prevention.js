Ext.syncRequire('Ung.common.threatprevention');
Ext.define('Ung.apps.threatprevention.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-threat-prevention',
    controller: 'app-threat-prevention',

    viewModel: {
        type: 'app-threat-prevention'
    },

    items: [
        { xtype: 'app-threat-prevention-status' },
        { xtype: 'app-threat-prevention-threats' },
        { xtype: 'app-threat-prevention-pass-sites' },
        { xtype: 'app-threat-prevention-rules' },
        { xtype: 'app-threat-prevention-threatlookup' },
        { xtype: 'app-threat-prevention-advanced' }
    ]
});
Ext.define('Ung.apps.threatprevention.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-threat-prevention',

    control: {
        '#': {
            afterrender: 'getSettings'
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        // set the enabled custom block page based on URL existance
        vm.bind('{settings.customBlockPageUrl}', function (url) {
            vm.set('settings.customBlockPageEnabled', url.length > 0);
        });

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise(v.appManager, 'getReportInfo', 'localNetworks', null)
        ], this)
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result[0]);
            vm.set('localNetworks', result[1]);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

        var threatList = [];
        Ung.common.threatprevention.references.threats.each( function(threat){
            threatList.push(threat.get('description'));
        });
        vm.set('threatList', "Match may contain one or more of the following categories:".t()+'<br>'+'<i>'+threatList.join(", ")+'</i>');
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    /**
     * showSliderInfo will display the Threat Temperature Gauge above the slider, as well as the label below the slider with the current threat description information.
     * @param {Ung.ThreatSlider} slider - The threat reputation slider object
     */
    showSliderInfo: function(slider) {
        var me = this, vm = this.getViewModel(), view = this.getView();

        var sliderVal = slider.getValue();

        var rangeArguments = [slider.rangeTpl];
        var matchingThreats = [];
        Ung.common.threatprevention.references.reputations.each( function(threat, index){
            rangeArguments.push(threat.get('color'));
            if(sliderVal > 0 &&
                ( sliderVal >= threat.get('rangeBegin') ) ){
                matchingThreats.push(threat.get('description'));
            }
        });

        var vLabel = Ext.String.format(slider.labelTpl, matchingThreats.length == 0 ? "None" : matchingThreats.join(", ") ) +
        ( matchingThreats.length == 0 ? Ext.String.format(slider.labelNoneTpl) : '') +
        ( matchingThreats.length == Ung.common.threatprevention.references.reputations.getCount() ? Ext.String.format(slider.labelAllTpl) : '' );
        var vRange =  Ext.String.format.apply(null, rangeArguments);

        vm.set('threatMeter', vRange);
        vm.set('currentThreatDescription', vLabel);
    },

    /**
     * handleThreatLookup is the click event handler to retrieve threat prevention data on a URL or IP Address from the getUrlHistory API
     */
    handleThreatLookup: function() {
        var me = this,
            v = this.getView(),
            vm = this.getViewModel(),
            lookupInput = vm.get('threatLookupInfo.inputVal');

        // Clear current values.
        vm.set( 'threatLookupInfo.resultAddress', '');
        vm.set( 'threatLookupInfo.resultServerReputation', '');
        vm.set( 'threatLookupInfo.resultClientReputation', '');

        if(!lookupInput) {
            return;
        }

        var urlParts = lookupInput.match(Ext.form.field.VTypes.mask.urlAddrRe);

        // Don't perform lookup if local
        var local = false;
        vm.get('localNetworks').forEach( function(network){
            if(Util.ipMatchesNetwork(urlParts[3] ? urlParts[3] : urlParts[0], network['address'], network['netmask'])){
                local = true;
            }
        });

        if(urlParts[3] != undefined){
            // User specified url so pick the host.
            lookupInput = urlParts[3];
            if(urlParts[5] != undefined){
                // Path also specified
                lookupInput += urlParts[5];
            }
        }

        vm.set( 'threatLookupInfo.local', local);
        if(local){
            return;
        }

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getReportInfo', 'getIpInfo', [lookupInput]),
            Rpc.asyncPromise(v.appManager, 'getReportInfo', 'getUrlInfo', [lookupInput]),
            Rpc.asyncPromise(v.appManager, 'getReportInfo', 'getIpHistory', [lookupInput]),
            Rpc.asyncPromise(v.appManager, 'getReportInfo', 'getUrlHistory', [lookupInput])
        ], this)
        .then(function(results){
            if(Util.isDestroyed(me, v, vm)){
                return;
            }
            v.setLoading(false);

            urlAddress = lookupInput;
            ipAddress = null;

            var ipResult = {};
            var ipOccurances = null;
            if(results[0] != null){
                // If path specified, we won't get an ip result
                ipResult = results[0][0];
                if(ipResult.hasOwnProperty('ip')){
                    ipAddress = ipResult.ip;
                }
                ipOccurances = results[2][0]['queries']['getrephistory']['history_count'];
                ipOccurances = (ipOccurances > 0) ? Ext.String.format('{0} occurrences', ipOccurances) : null;
            }

            var urlResult = {};
            if(results[1] != null){
                urlResult = results[1][0];
                if(urlResult.hasOwnProperty('url')){
                    urlAddress = urlResult.url;
                }
            }
            var urlOccurances = results[3][1]['queries']['getrepinfo']['threathistory'];
            urlOccurances = (urlOccurances > 0) ? Ext.String.format('{0} occurrences', urlOccurances) : null;

            if(ipAddress != null && ipAddress != urlAddress){
                vm.set( 'threatLookupInfo.resultAddress', Ext.String.format("{0} ({1})", urlAddress, ipAddress));
            }else{
                vm.set( 'threatLookupInfo.resultAddress', urlAddress);
            }
            if(urlResult.hasOwnProperty('reputation')){
                vm.set( 'threatLookupInfo.resultServerReputation', me.getReputationStatus(urlResult.reputation, urlOccurances));
            }
            if(ipResult.hasOwnProperty('reputation')){
                vm.set( 'threatLookupInfo.resultClientReputation', me.getReputationStatus(ipResult.reputation, ipOccurances));
            }

        }, function(ex) {
            if(!Util.isDestroyed(v)){
                v.setLoading(false);
                return;
            }
            Util.handleException(ex);
        });
    },

    /**
     * Get formatted reputation with description and detail
     * @param  reputation Integer value of reputation
     * @param  extra Extra values to show in parens after the reputation level.
     */
    getReputationStatus: function(reputation, extra){
        var reputationStatus = "";
        Ung.common.threatprevention.references.reputations.each(function(record){
            if(reputation >= record.get('rangeBegin') &&
               reputation <= record.get('rangeEnd')){
                if(extra){
                    reputationStatus = Ext.String.format("<b>{0}</b> ({1}) - {2}", record.get('description'), extra, record.get('details'));
                }else{
                    reputationStatus = Ext.String.format("<b>{0}</b> - {1}", record.get('description'), record.get('details'));
                }
            }
        });
        return reputationStatus;
    }
});

Ext.define('Ung.ThreatSlider', {
    extend: 'Ext.slider.Single',
    alias: 'widget.threatslider',
    useTips: true,
    tipText: function(thumb){
        var matchingThreat = null;
        Ung.common.threatprevention.references.reputations.each( function(threat){
            if(thumb.value >= threat.get('rangeBegin') && thumb.value <= threat.get('rangeEnd')){
                matchingThreat = threat;
            }
        });
        if(matchingThreat){
            return Ext.String.format(thumb.ownerCt.tipTpl, matchingThreat.get('description'), matchingThreat.get('details'));
        }
    },
    initComponent: function() {
        this.callParent();
    },
    /**
     * Override to support reverse slider.
     */
    calculateThumbPosition: function(v) {
        var me = this,
            minValue = me.minValue,
            maxValue = me.maxValue,
            pos = ((maxValue - v) / me.getRange() * 100);
        if (isNaN(pos)) {
            pos = 0;
        }
        return pos;
    },
    /**
     * Override to support reverse slider.
     */
    reversePixelValue : function(pos) {
        return this.maxValue - (pos / this.getRatio());
    },
    /**
     * Override to support reverse slider.
     */
    onKeyDown: function(e) {
        var me = this,
            ariaDom = me.ariaEl.dom,
            k, val;

        k = e.getKey();

        /*
         * The behaviour for keyboard handling with multiple thumbs is currently undefined.
         * There's no real sane default for it, so leave it like this until we come up
         * with a better way of doing it.
         */
        if (me.disabled || me.thumbs.length !== 1) {
            // Must not mingle with the Tab key!
            if (k !== e.TAB) {
                e.preventDefault();
            }

            return;
        }

        switch (k) {
            case e.UP:
            case e.RIGHT:
                val = e.ctrlKey ? me.minValue : me.getValue(0) - me.keyIncrement;
                break;

            case e.DOWN:
            case e.LEFT:
                val = e.ctrlKey ? me.maxValue : me.getValue(0) + me.keyIncrement;
                break;

            case e.HOME:
                val = me.minValue;
                break;

            case e.END:
                val = me.maxValue;
                break;

            case e.PAGE_UP:
                val = me.getValue(0) + me.pageSize;
                break;

            case e.PAGE_DOWN:
                val = me.getValue(0) - me.pageSize;
                break;
        }

        if (val !== undefined) {
            e.stopEvent();

            val = me.normalizeValue(val);

            me.setValue(0, val, undefined, true);

            if (ariaDom) {
                ariaDom.setAttribute('aria-valuenow', val);
            }
        }
    }
});
Ext.define('Ung.apps.threatprevention.MainModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.app-threat-prevention',

    data: {
        title: 'Threat Prevention'.t(),
        iconName: 'threatprevention',

        threatMeter: null,
        currentThreatDescription: null,
        threatList: null,

    },
    stores: {
        rules: { data: '{settings.rules.list}' },
        passSites: { data: '{settings.passSites.list}' },
        threatLookupInfo: {
            model: 'Ung.apps.threatprevention.ThreatLookupInfo',
            target: 'server', 
            local: false
        }
    }
});
/**
 * ThreatLookupInfo is a model to represent the threat info that should be displayed on the Lookup Threat Tab
 */
Ext.define('Ung.apps.threatprevention.ThreatLookupInfo', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'inputVal', type: 'string'},
        {name: 'local', type: 'boolean'},
        {name: 'resultAddress', type: 'string'},
        {name: 'resultServerReputation', type: 'string'},
        {name: 'resultClientReputation', type: 'string'},
    ],

    hasMany: [{
        model: 'ThreatCategories',
        name: 'categories'
    },{
        model: 'ThreatHistory',
        name: 'history'
    }]
});

/**
 * ThreatCategories model contains confidence% and category ID of a threat that shows up in the Threat History or in the Threat Lookup Info
 */
Ext.define('Ung.apps.threatprevention.ThreatCategories', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'catid', type: 'int'},
        {name: 'confidence', type: 'int'}
    ]
});

/**
 * ThreatHistory contains a timestamp and any categories associated with historical data about the threat
 */
Ext.define('Ung.apps.threatprevention.ThreatHistory', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'timestamp', type: 'int'}
    ],
    hasMany: [{
        model: 'ThreatCategories',
        name: 'categories'
    }]
});Ext.define('Ung.apps.threatprevention.view.Advanced', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-threat-prevention-advanced',
    itemId: 'advanced',
    title: 'Advanced'.t(),
    scrollable: true,
    bodyPadding: 10,
    withValidation: true,

    items: [{
        xtype: 'fieldset',
        title: 'Custom block page'.t(),
        padding: '10 15',
        layout: 'fit',
        items: [{
            xtype: 'textfield',
            emptyText: 'http://example.com',
            fieldLabel: 'URL',
            vtype: 'url',
            bind: '{settings.customBlockPageUrl}',
            listeners: {
                // add 'http://' prefix if missing
                blur: function (el) {
                    var url = el.getValue();
                    if (url.length) {
                        if (!url.startsWith("http://") && !url.startsWith("https://")) {
                            el.setValue("http://" + url);
                        }
                    }
                }
            }
        }]
    }, {
        xtype: 'fieldset',
        title: 'Block options'.t(),
        padding: '10 15',
        cls: 'app-section',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'checkbox',
            boxLabel: 'Close connection for blocked HTTPS sessions without redirecting to block page'.t(),
            bind: '{settings.closeHttpsBlockEnabled}'
        }]
    }]
});
Ext.define('Ung.apps.threatprevention.view.PassSites', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-threat-prevention-pass-sites',
    itemId: 'pass-sites',
    title: 'Pass Sites'.t(),
    scrollable: true,
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyAppendField: 'description',

    listProperty: 'settings.passSites.list',

    emptyText: 'No Pass Sites defined'.t(),

    emptyRow: {
        string: '',
        enabled: true,
        description: '',
        javaClass: 'com.untangle.uvm.app.GenericRule'
    },

    bind: '{passSites}',

    extraColumnConfig: {
        blocked: { xtype: 'checkbox' },
        flagged: { xtype: 'checkbox' },
        name: { xtype: 'textfield' },
        description: { xtype: 'textfield' },
        readOnly: { xtype: 'checkbox' },
        id: { xtype: 'numberfield' },
        category: { xtype: 'textfield' },
        enabled: { allowBlank: false, xtype: 'checkbox' },
    },

    columns: [{
        header: 'Site'.t(),
        width: Renderer.uriWidth,
        flex: 1,
        dataIndex: 'string',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter URL or IP address]'.t(),
            allowBlank: false
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.booleanWidth,
        header: 'Pass'.t(),
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
        editor: {
            xtype: 'textfield',
            emptyText: '[no description]'.t()
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.string}',
        fieldLabel: 'Site'.t(),
        emptyText: '[enter URL or IP address]'.t(),
        allowBlank: false,
        width: 400
    }, {
        xtype: 'checkbox',
        bind: '{record.enabled}',
        fieldLabel: 'Pass'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 400,
        height: 60
    }]
});
Ext.define('Ung.apps.threatprevention.view.Rules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-threat-prevention-rules',
    itemId: 'rules',
    title: 'Rules'.t(),
    scrollable: true,
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    listProperty: 'settings.rules.list',

    emptyText: 'No Rules defined'.t(),

    emptyRow: {
        ruleId: 0,
        enabled: true,
        action: "pass",
        flag: true,
        description: '',
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.threat_prevention.ThreatPreventionRule'
    },

    bind: '{rules}',

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions,
        {
        header: "Action".t(),
        dataIndex: 'action',
        width: Renderer.messageWidth,
        flex: 2,
        editor: {
            xtype: 'combo',
            editable: false,
            matchFieldWidth: false,
            queryMode: 'local',
            valueField: 'value',
            displayField: 'description',
            store: Ung.common.threatprevention.references.actions
        }
    }],

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    extraColumnConfig: {
        ruleId: { xtype: 'numberfield' },
    },

    // todo: continue this stuff
    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.threat_prevention.ThreatPreventionRuleCondition', [
            'DST_ADDR',
            'DST_PORT',
            'DST_INTF',
            'SRC_ADDR',
            'SRC_PORT',
            'SRC_INTF',
            'PROTOCOL',
            'TAGGED',
            'USERNAME',
            'HOST_HOSTNAME',
            'CLIENT_HOSTNAME',
            'SERVER_HOSTNAME',
            'SRC_MAC',
            'DST_MAC',
            'CLIENT_MAC_VENDOR',
            'SERVER_MAC_VENDOR',
            'CLIENT_IN_PENALTY_BOX',
            'SERVER_IN_PENALTY_BOX',
            'HOST_HAS_NO_QUOTA',
            'USER_HAS_NO_QUOTA',
            'CLIENT_HAS_NO_QUOTA',
            'SERVER_HAS_NO_QUOTA',
            'HOST_QUOTA_EXCEEDED',
            'USER_QUOTA_EXCEEDED',
            'CLIENT_QUOTA_EXCEEDED',
            'SERVER_QUOTA_EXCEEDED',
            'HOST_QUOTA_ATTAINMENT',
            'USER_QUOTA_ATTAINMENT',
            'CLIENT_QUOTA_ATTAINMENT',
            'SERVER_QUOTA_ATTAINMENT',
            'HOST_ENTITLED',
            'THREAT_PREVENTION_SRC_REPUTATION',
            'THREAT_PREVENTION_DST_REPUTATION',
            'THREAT_PREVENTION_SRC_CATEGORIES',
            'THREAT_PREVENTION_DST_CATEGORIES',
            'HTTP_HOST',
            'HTTP_REFERER',
            'HTTP_URI',
            'HTTP_URL',
            'HTTP_CONTENT_TYPE',
            'HTTP_CONTENT_LENGTH',
            'HTTP_REQUEST_METHOD',
            'HTTP_REQUEST_FILE_PATH',
            'HTTP_REQUEST_FILE_NAME',
            'HTTP_REQUEST_FILE_EXTENSION',
            'HTTP_RESPONSE_FILE_NAME',
            'HTTP_RESPONSE_FILE_EXTENSION',
            'HTTP_USER_AGENT',
            'HTTP_USER_AGENT_OS',
        ]),
    {
        xtype: 'combo',
        fieldLabel: 'Action'.t(),
        editable: false,
        matchFieldWidth: false,
        queryMode: 'local',
        valueField: 'value',
        displayField: 'description',
        bind:{
            value: '{record.action}'
        },
        store: Ung.common.threatprevention.references.actions
    },{
        xtype: 'checkbox',
        bind: '{record.flag}',
        fieldLabel: 'Flag'.t()
    }]
});
Ext.define('Ung.apps.threatprevention.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-threat-prevention-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/threat-prevention.svg" width="80" height="80"/>' +
                '<h3>Threat Prevention</h3>' +
                '<p>' + 'Threat Prevention prevents threats associated with  untrustworthy IP Addresses and Websites based on their reputation.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        layout: 'fit',
        items: [{
            xtype: 'appmetrics'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]

});
Ext.define('Ung.apps.threatprevention.view.ThreatLookup', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-threat-prevention-threatlookup',
    itemId: 'lookup',
    title: 'Threat Lookup'.t(),
    scrollable: true,
    bodyPadding: 10,
    defaultButton: 'searchButton',
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: {
            fontSize: '12px',
            fontWeight: 600
        },
        html: 'Lookup the threat information for websites or IP Addresses.'.t()
    }],
    withValidation: false,
    items: [{
        xtype: 'fieldset',
        title: 'IP Address and URL Threats'.t(),
        width: '100%',
        items: [{
            xtype: 'textfield',
            fieldLabel: 'IP Address or URL'.t(),
            labelWidth: 150,
            _neverDirty: true,
            fieldIndex: 'threatLookupInput',
            width: 500,
            vtype: 'ipOrUrl',
            margin: '10 0 0 0',
            bind: {
                hidden: '{state.on == false}',
                value: '{threatLookupInfo.inputVal}'
            }
        }, {
            xtype: 'button',
            reference: 'searchButton',
            text: 'Search'.t(),
            iconCls: 'fa fa-search',
            handler: 'handleThreatLookup',
            margin: '10 0 10 0',
            disabled: true,
            bind: {
                hidden: '{state.on == false}',
                disabled: '{threatLookupInfo.inputVal.length === 0}'
            }
        },{
            xtype: 'displayfield',
            value: 'IP Address is in local network, no lookup performed.'.t(),
            bind: {
                hidden: '{threatLookupInfo.local === false}'
            }
        }, {
            xtype: 'fieldset',
            title: 'Threat Results'.t(),
            hidden: true,
            layout: {
                type :'vbox',
                align : 'stretch'
            },
            bind: {
                hidden: '{threatLookupInfo.resultAddress.length === 0}'
            },
            items: [{
                xtype: 'displayfield',
                labelWidth: 160,
                fieldLabel: 'URL (IP Address)'.t(),
                bind: {
                    value: '{threatLookupInfo.resultAddress}',
                    hidden: '{threatLookupInfo.resultAddress.length === 0}'
                }
            },{
                xtype: 'displayfield',
                labelWidth: 160,
                fieldLabel: 'Server Reputation'.t(),
                bind: {
                    value: '{threatLookupInfo.resultServerReputation}',
                    hidden: '{threatLookupInfo.resultServerReputation.length === 0}'
                }
            },{
                xtype: 'displayfield',
                labelWidth: 160,
                fieldLabel: 'Client Reputation'.t(),
                bind: {
                    value: '{threatLookupInfo.resultClientReputation}',
                    hidden: '{threatLookupInfo.resultClientReputation.length === 0}'
                }
            }]
        }]
    }]
});
Ext.define('Ung.apps.threatprevention.view.Threats', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-threat-prevention-threats',
    itemId: 'threats',
    title: 'Threats'.t(),
    withValidation: false,
    scrollable: true,

    bodyPadding: 10,

    items: [{
        xtype: 'fieldset',
        title: 'IP Address and URL Threats'.t(),
        layout: 'vbox',
        items:[{
            itemId: 'threatReputation',
            xtype: 'container',
            layout: 'hbox',
            margin: '0 0 20 0',
            items: [{
                xtype: 'label',
                text: 'Reputation Threshold'.t(),
                margin: '0 5 0 0',
                width: 125
            },{
                xtype: 'container',
                layout: 'vbox',
                items:[{
                    xtype: 'label',
                    itemId: 'threatRange',
                    bind: {
                        html: '{threatMeter}'
                    }
                },{
                    xtype: 'threatslider',
                    referenceId: 'threatSlider',
                    viewLabel: 'threatLabel',
                    rangeLabel: 'threatRange',
                    width: 450,
                    height: 20,
                    maxValue: 100,
                    minValue: 0,
                    increment: 20,
                    bind:{
                        value: '{settings.reputationThreshold}'
                    },
                    listeners: {
                        afterrender: 'showSliderInfo',
                        change: 'showSliderInfo'
                    },
                    labelTpl: 'Block traffic assessed as <i>{0}</i>'.t(),
                    labelNoneTpl: '<br><b>' + 'Warning: No traffic will be blocked'.t() + '</b>',
                    labelAllTpl: '<br><b>' + 'Warning: All traffic will be blocked'.t() + '</b>',
                    tipTpl: '{0} - {1}'.t(),
                    rangeTpl: '<table style="width:450px; height:75px;border-collapse:collapse; margin-top: -29px"><tr>' + 
                        '<td style="vertical-align:bottom; width:20%;">Trustworthy</td>'+
                        '<td style="vertical-align:bottom; width:20%;">Low Risk</td>'+
                        '<td style="vertical-align:bottom; width:20%;">Moderate Risk</td>'+
                        '<td style="vertical-align:bottom; width:20%;">Suspicious</td>'+
                        '<td style="vertical-align:bottom; width:20%;">High Risk</td>'+
                        '</tr><tr>' + 
                        '<td style="background-color:#{0}; height:32px;"></td>'+
                        '<td style="background-color:#{1};"></td>'+
                        '<td style="background-color:#{2};"></td>'+
                        '<td style="background-color:#{3};"></td>'+
                        '<td style="background-color:#{4};"></td>'+
                        '</tr></table>'
                },{
                    xtype: 'label',
                    itemId: 'threatLabel',
                    bind: {
                        html: '{currentThreatDescription}'
                    }    
                }]
            }]
        },{
            xtype: 'displayfield',
            fieldLabel: 'Categories'.t(),
            labelWidth: 125,
            bind: {
                value: '{threatList}'
            },
            padding: '0 10 10 0'
        // },{
        //     xtype: 'displayfield',
        //     value: 'Matching traffic will be blocked'.t(),
        //     padding: '0 10 10 0'
        }]
    }]
});
