Ext.define('Ung.apps.wan-balancer.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-wan-balancer',
    controller: 'app-wan-balancer',

    viewModel: {

        data: {
            autoRefresh: false,
            interfaceWeightData: [],
            destinationWanData: []
        },

        stores: {
            routeRules: {
                data: '{settings.routeRules.list}'
            },
            interfaceWeightList: {
                data: '{interfaceWeightData}'
            },
            destinationWanList: {
                fields: [ 'index', 'name' ],
                data: '{destinationWanData}'
            }
        }
    },

    items: [
        { xtype: 'app-wan-balancer-status' },
        { xtype: 'app-wan-balancer-trafficallocation' },
        { xtype: 'app-wan-balancer-routerules' }
    ]

});
Ext.define('Ung.apps.wan-balancer.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-wan-balancer',

    control: {
        '#': {
            beforerender: 'getSettings'
        }
    },

    getSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();
        v.setLoading(true);

        Ext.Deferred.sequence([
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise('rpc.networkManager.getNetworkSettings')
        ])
        .then( function(result){
            if(Util.isDestroyed(me, v, vm)){
                return;
            }

            vm.set('settings', result[0]);
            me.calculateNetwork(result[1]);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });

    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            if (grid.listProperty != null) {
            var store = grid.getStore();
                if (store.getModifiedRecords().length > 0 ||
                    store.getNewRecords().length > 0 ||
                    store.getRemovedRecords().length > 0 ||
                    store.isReordered) {
                    store.each(function (record) {
                        if (record.get('markedForDelete')) {
                            record.drop();
                        }
                    });
                    store.isReordered = undefined;
                    vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
                }
            }
        });

        me.setWeights();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    calculateNetwork: function( networkSettings ) {
        var interfaceWeightData = [];
        var destinationWanData = [];
        var trafficAllocation = "";
        var total = 0, i, intf, weight, intfCount;

        var vm = this.getViewModel();
        var weightArray = vm.get('settings.weights');

        for (i = 0 ; i < networkSettings.interfaces.list.length ; i++) {
            intf = networkSettings.interfaces.list[i];
            if (intf.configType != 'ADDRESSED' || !intf.isWan ) continue;
            weight = weightArray[intf.interfaceId-1];
            interfaceWeightData.push({
                interfaceId: intf.interfaceId,
                name: intf.name,
                weight: weight,
                description: ""
            });
            total += weight;
        }

        trafficAllocation += "<TABLE WIDTH=600 BORDER=1 CELLSPACING=0 CELLPADDING=5 STYLE=border-collapse:collapse;>";

        intfCount = interfaceWeightData.length;
        for(i = 0 ; i < intfCount ; i++) {
            interfaceWeightData[i].description = this.getDescription(intfCount, total, interfaceWeightData[i].weight);
            var item = interfaceWeightData[i];
            trafficAllocation += "<TR><TD>" + Ext.String.format("{0} interface".t(), item.name) + "</TD><TD>" + item.description + "</TD></TR>";
        }

        trafficAllocation += "</TABLE>";

        destinationWanData.push([0, 'Balance'.t()]);

        for (var c = 0 ; c < networkSettings.interfaces.list.length ; c++) {
            intf = networkSettings.interfaces.list[c];
            var name = intf.name;
            var key = intf.interfaceId;
            if ( intf.configType == 'ADDRESSED' && intf.isWan) {
                destinationWanData.push( [ key, name ] );
            }
        }

        vm.set('interfaceWeightData', interfaceWeightData);
        vm.set('trafficAllocation', trafficAllocation);
        vm.set('destinationWanData', destinationWanData);
    },

    getDescription: function(intfCount, total, weight) {
        var percent = ( total == 0 ) ? Math.round(( 1 / intfCount ) * 1000) / 10 : Math.round(( weight / total ) * 1000) / 10;
        return Ext.String.format("{0}% of Internet traffic.".t(), percent);
    },

    setWeights: function() {
        var vm = this.getViewModel();

        // JSON serializes out empty elements
        var weights = [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        0, 0, 0, 0, 0 ];

        var iwd = vm.get('interfaceWeightData');

        iwd.forEach(function(record) {
            weights[record.interfaceId - 1] = record.weight;
        });

        vm.set('settings.weights', weights);
    },

    statics: {
        destinationWanRenderer: function(value){
            var wanlist = this.getViewModel().get('destinationWanList');
            var dstname = 'Unknown'.t();
            wanlist.each(function(record) { if (record.get('index') == value) dstname = record.get('name'); });
            return(dstname);
        }
    }

});
Ext.define('Ung.apps.wan-balancer.view.RouteRules', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-wan-balancer-routerules',
    itemId: 'route-rules',
    title: 'Route Rules'.t(),
    viewModel: true,
    scrollable: true,
    withValidation: false,
    editorFieldProtocolTcpUdpOnly: true,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Route Rules are used to assign specific sessions to a specific WAN interface. Rules are evaluated in order and the WAN interface of the first matching rule is used to route the matching session.<BR>If there is no matching rule or the rule is set to Balance the session will be routed according to the Traffic Allocation settings.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete', 'reorder'],
    copyId: 'ruleId',  
    copyAppendField: 'description',

    listProperty: 'settings.routeRules.list',

    emptyRow: {
        ruleId: 0,
        enabled: true,
        description: '',
        conditions: {
            javaClass: 'java.util.LinkedList',
            list: []
        },
        javaClass: 'com.untangle.app.wan_balancer.RouteRule'
    },

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    extraColumnConfig: {
        ruleId: { xtype: 'numberfield' },
    },

    bind: '{routeRules}',

    emptyText: 'No Route Rules defined'.t(),

    columns: [
        Column.ruleId,
        Column.enabled,
        Column.description,
        Column.conditions, {
            header: 'Destination WAN'.t(),
            dataIndex: 'destinationWan',
            width: Renderer.messageWidth,
            renderer: Ung.apps['wan-balancer'].MainController.destinationWanRenderer
        }
    ],

    editorFields: [
        Field.enableRule(),
        Field.description,
        Field.conditions(
            'com.untangle.app.wan_balancer.RouteRuleCondition', [
            "DST_ADDR",
            "DST_PORT",
            "SRC_ADDR",
            "SRC_PORT",
            "SRC_INTF",
            "PROTOCOL",
            "CLIENT_TAGGED",
            "SERVER_TAGGED"
        ]), {
            xtype: 'combo',
            fieldLabel: 'Destination WAN'.t(),
            bind: {
                value: '{record.destinationWan}',
                store: '{destinationWanList}'
            },
            allowBlank: false,
            editable: false,
            queryMode: 'local',
            displayField: 'name',
            valueField: 'index'
        }
    ]

});
Ext.define('Ung.apps.wan-balancer.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wan-balancer-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/wan-balancer.svg" width="80" height="80"/>' +
                '<h3>WAN Balancer</h3>' +
                '<p>' + 'WAN Balancer spreads network traffic across multiple internet connections for better performance.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'app-wan-balancer-allocation',
        }, {
            xtype: 'button',
            text: 'Configure additional WAN interfaces'.t(),
            iconCls: 'fa fa-cogs',
            handler: function() { Ung.app.redirectTo('#config/network'); }
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appmetrics',
            region: 'center'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});

Ext.define('Ung.apps.wan-balancer.view.Allocation', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wan-balancer-allocation',
    itemId: 'Allocation',
    title: 'Current Traffic Allocation'.t(),
    padding: '0 0 20 0',
    border: false,

    items: [{
        xtype: 'component',
        html: 'Currently, WAN Balancer is attempting to share traffic over the existing WAN interfaces with the ratio displayed below. To change this ratio click on Traffic Allocation.'.t(),
        margin: '0 0 15 0'
    }, {
        xtype: 'component',
        padding: '10 0 10 0',
        bind: { html: '{trafficAllocation}' }
    }]
});
Ext.define('Ung.apps.wan-balancer.view.TrafficAllocation', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wan-balancer-trafficallocation',
    itemId: 'traffic-allocation',
    title: 'Traffic Allocation'.t(),
    viewModel: true,
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'Allocate traffic across WAN interfaces'.t()
    }],

    items: [{
        xtype: 'displayfield',
        padding: '10 10 0 10',
        value: 'Traffic allocation across WAN interfaces is controlled by assigning a relative weight (1-100) to each interface.'.t() + '<BR>' +
               'After entering the weight of each interface the resulting allocation is displayed.'.t() + '<BR>' +
               'If all WAN interfaces have the same bandwidth it is best to assign the same weight to all WAN interfaces.'.t() + '<BR>' +
               'If the WAN interfaces vary in bandwidth, enter numbers that correlate the relative available bandwidth.'.t() + '<BR>' +
               'For example: 15 for a 1.5Mbit/sec T1, 60 for a 6 mbit link, and 100 for a 10mbit link.'.t()
    },{
        xtype: 'app-wan-balancer-weight-grid',
        padding: '10 10 10 10'
    }]

});

Ext.define('Ung.apps.wan-balancer.view.WeightGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-wan-balancer-weight-grid',
    itemId: 'weight-grid',
    title: 'Interface Weights'.t(),
    bind: '{interfaceWeightList}',

    emptyText: 'No WAN Interfaces defined'.t(),

    columns: [{
        header: 'Interface'.t(),
        dataIndex: 'name',
        width: Renderer.idWidth,
    }, {
        header: 'Weight'.t(),
        dataIndex: 'weight',
        width: Renderer.sizeWidth,
        editor: {
            xtype: 'numberfield',
            allowDecimals: false,
            minValue: 0,
            maxValue: 100,
            emptyText: '[enter weight]'.t(),
            allowOnlyWhitespace: false
        }
    }, {
        header: 'Resulting Traffic Allocation'.t(),
        dataIndex: 'description',
        width: Renderer.messageWidth,
        flex: 1
    }]
});
