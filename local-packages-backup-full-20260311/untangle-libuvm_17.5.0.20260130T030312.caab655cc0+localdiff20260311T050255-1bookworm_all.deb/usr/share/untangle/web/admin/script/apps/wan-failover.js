Ext.define('Ung.apps.wan-failover.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-wan-failover',
    controller: 'app-wan-failover',

    viewModel: {

        data: {
            autoReload: false,
            wanStatusData: [],
            pingListData: []
        },

        stores: {
            tests: {
                data: '{settings.tests.list}'
            },
            wanStatusStore: {
                data: '{wanStatusData}',
                fields: [{
                    name: 'systemName'
                },{
                    name: 'totalTestsPassed',
                    sortType: 'asInt'
                },{
                    name: 'totalTestsRun',
                    sortType: 'asInt'
                },{
                    name: 'online'
                },{
                    name: 'interfaceId',
                    sortType: 'asInt'
                },{
                    name: 'interfaceName'
                },{
                    name: 'totalTestsFailed',
                    sortType: 'asInt'
                }]
            },
            pingListStore: {
                fields: [ 'name' , 'addr' ],
                data: '{pingListData}'
            },
        },

    },

    items: [
        { xtype: 'app-wan-failover-status' },
        { xtype: 'app-wan-failover-tests' }
    ]

});
Ext.define('Ung.apps.wan-failover.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-wan-failover',

    control: {
        '#': {
            beforerender: 'getSettings'
        },
        '#status': {
            activate: 'getWanStatus'
        },
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            var testList = result.tests.list;

            // convert all milliseconds to seconds after load
            for (var i = 0 ; i < testList.length;i++) {
                test = testList[i];
                test.timeoutMilliseconds = (test.timeoutMilliseconds / 1000);
                test.delayMilliseconds = (test.delayMilliseconds / 1000);
            }

            vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        // convert all seconds to milliseconds before save
        var testStore = v.query('app-wan-failover-test-grid')[0].getStore();
        var tval,dval;

        testStore.each(function(record) {
            tval = record.get('timeoutMilliseconds');
            dval = record.get('delayMilliseconds');
            record.set('timeoutMilliseconds', tval * 1000);
            record.set('delayMilliseconds', dval * 1000);
        });

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    getWanStatus: function (cmp) {
        var v = this.getView(), vm = this.getViewModel(),
            grid = cmp.down('grid[itemId=wanStatus]') || cmp.up('grid[itemId=wanStatus]');

        grid.setLoading(true);
        Rpc.asyncData(v.appManager, 'getWanStatus')
        .then(function(result){
            if(Util.isDestroyed(vm, grid)){
                return;
            }
            var i;
            var list = [];
            for (i=0;i<result.list.length;i++) {
                if (result.list[i].systemName != null)
                    list.push(result.list[i]);
            }
            vm.set('wanStatusData', list);

            var testList = vm.get('settings.tests.list');
            var wanWarnings = [];
            var testMap = {};
            var test;

            // first build a map of all enabled tests
            if (testList) for (i = 0;i < testList.length;i++) {
                test = testList[i];
                if (test.enabled) testMap[test.interfaceId] = true;
            }

            // now make sure each wan interface has an enabled test
            Ext.Array.each(list, function (wan) {
                if (!testMap[wan.interfaceId]) {
                    wanWarnings.push('<li>'  + Ext.String.format('Warning: Interface <i>{0}</i> needs a test configured!'.t(), wan.interfaceName) + '</li>');
                }
            });

            vm.set('wanWarnings', wanWarnings.join(''));
            grid.setLoading(false);
        }, function(ex) {
            if(!Util.isDestroyed(vm, grid)){
                grid.setLoading(false);
            }
            Util.handleException(ex);
        });
    }
});

Ext.define('Ung.apps.wan-failover.SpecialController', {
    extend: 'Ung.cmp.GridController',
    alias: 'controller.app-wan-failover-special',

    generateSuggestions: function(btn) {
        var parent = btn.up('#tests');
        var vm = parent.getViewModel();
        var faceCombo = parent.down("[fieldIndex='interfaceCombo']");
        var pingCombo = parent.down("[fieldIndex='pingCombo']");
        var form = btn.up('form');

        form.setLoading('Generating Suggestions...'.t() );
        Rpc.asyncData(btn.up('apppanel').appManager, 'getPingableHosts', faceCombo.getValue() )
        .then(function(result){
            if(Util.isDestroyed(form, pingCombo, vm)){
                return;
            }

            var pingData = [];
            for(var i = 0 ; i < result.list.length ; i++) {
                pingData.push([result.list[i],result.list[i]]);
            }
            vm.set('pingListData', pingData);
            pingCombo.getStore().loadData(pingData);
            pingCombo.select(pingData[0][0]);

            form.setLoading(false);
        }, function(ex){
            if(!Util.isDestroyed(form)){
                form.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    runWanTest: function(btn) {
        var record = btn.up('panel').ownerCt.record.data;

        Rpc.asyncData(btn.up('apppanel').appManager, 'runTest', record )
        .then(function(result){
            Ext.MessageBox.alert('Test Results'.t(), result.t());
        }, function(ex){
            Util.handleException(ex);
        });
    }

});
Ext.define('Ung.apps.wan-failover.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wan-failover-status',
    itemId: 'status',
    title: 'Status'.t(),
    viewModel: true,
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/wan-failover.svg" width="80" height="80"/>' +
                '<h3>WAN Failover</h3>' +
                '<p>' + 'WAN Failover detects WAN outages and re-routes traffic to any other available WANs to maximize network uptime.'.t() + '</p>' +
                '<p>' + '<b>NOTE:</b> Tests must be configured using the <i>Tests</i> tab to determine the connectivity of each WAN.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'fieldset',
            title: '<i class="fa fa-clock-o"></i> ' + 'WAN Status'.t(),
            padding: 10,
            margin: '20 0',
            cls: 'app-section',

            layout: {
                type: 'vbox',
                align: 'stretch'
            },

            collapsed: true,
            disabled: true,
            bind: {
                collapsed: '{!state.on}',
                disabled: '{!state.on}'
            },
            items: [{
                xtype: 'component',
                html: '<i class="fa fa-exclamation-triangle fa-red fa-lg"></i> <strong>' + 'There are currently no tests configured. A test must be configured for each WAN.'.t() + '</strong>',
                margin: '0 0 10 0',
                hidden: true,
                bind: {
                    hidden: '{settings.tests.list.length > 0}'
                }
            }, {
                xtype: 'component',
                margin: '0 0 10 0',
                hidden: true,
                bind: {
                    html: '<ul style="margin: 0;">{wanWarnings}</ul>',
                    hidden: '{!wanWarnings}'
                }
            }, {
                xtype: 'ungrid',
                itemId: 'wanStatus',
                enableColumnHide: true,
                stateful: true,
                trackMouseOver: false,
                resizable: true,
                defaultSortable: true,

                flex: 1,

                emptyText: 'No External Interfaces'.t(),

                bind: {
                    store: '{wanStatusStore}'
                },

                plugins: ['gridfilters'],

                columns: [{
                    header: 'Interface ID'.t(),
                    dataIndex: 'interfaceId',
                    sortable: true,
                    width: Renderer.idWidth,
                    filter: Renderer.booleanFilter,
                }, {
                    header: 'Interface Name'.t(),
                    dataIndex: 'interfaceName',
                    sortable: true,
                    width: Renderer.idWidth,
                    flex: 1,
                    filter: Renderer.stringFilter,
                }, {
                    header: 'System Name'.t(),
                    dataIndex: 'systemName',
                    sortable: true,
                    width: Renderer.idWidth,
                    resizable: false,
                    filter: Renderer.stringFilter,
                }, {
                    header: 'Online Status',
                    dataIndex: 'online',
                    sortable: true,
                    width: Renderer.booeanWidth,
                    resizable: false,
                    filter: Renderer.booleanFilter,
                }, {
                    header: 'Current Tests Count'.t(),
                    dataIndex: 'totalTestsRun',
                    sortable: true,
                    width: Renderer.messageWidth,
                    resizable: false,
                    filter: Renderer.numericFilter,
                    renderer: Renderer.count
                }, {
                    header: 'Tests Passed'.t(),
                    dataIndex: 'totalTestsPassed',
                    sortable: true,
                    width: Renderer.sizeWidth,
                    resizable: false,
                    filter: Renderer.numericFilter,
                    renderer: Renderer.count
                }, {
                    header: 'Tests Failed'.t(),
                    sortable: true,
                    dataIndex: 'totalTestsFailed',
                    width: Renderer.sizeWidth,
                    filter: Renderer.numericFilter,
                    renderer: Renderer.count
                }],
                bbar: [ '@refresh', '@reset']
            }]
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        layout: 'fit',
        items: [{
            xtype: 'appmetrics'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]
});
Ext.define('Ung.apps.wan-failover.view.Tests', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-wan-failover-tests',
    itemId: 'tests',
    title: 'Tests'.t(),
    viewModel: true,
    scrollable: true,
    withValidation: false,
    tbar: [{
        xtype: 'tbtext',
        padding: '8 5',
        style: { fontSize: '12px', fontWeight: 600 },
        html: 'These tests control how each WAN interface is tested to ensure that it has connectivity to the Internet.'.t()
    }],

    items: [{
        xtype: 'displayfield',
        value: '<strong>' + 'Note'.t() + '</strong>' +
               '<ul>' +
               '<li>' + 'There should be one configured test per WAN interface.'.t() + '<BR>' +
               '<li>' + 'These rules require careful configuration. Poorly chosen tests will greatly reduce the effectiveness of WAN Failover.'.t() + '<BR>' +
               '<li>' + 'Press Help to see a further discussion about Failure Detection Tests.'.t() +
               '</ul>'
    },{
        xtype: 'app-wan-failover-test-grid',
        title: 'Failure Detection Tests'.t()
    }]

});

Ext.define('Ung.apps.wan-failover.view.TestGrid', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-wan-failover-test-grid',
    itemId: 'test-grid',
    controller: 'app-wan-failover-special',

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    emptyText: 'No Tests Defined'.t(),

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',
    listProperty: 'settings.tests.list',
    bind: '{tests}',
    emptyRow: {
        javaClass: 'com.untangle.app.wan_failover.WanTestSettings',
        'enabled': true,
        'description': '',
        'type': 'ping',
        'interfaceId': 1,
        'timeoutMilliseconds': 2,
        'delayMilliseconds': 5,
        'failureThreshold': 3,
        'pingHostname': '8.8.8.8',
        'httpUrl': 'http://1.2.3.4/',
        'testHistorySize': 10
    },

    extraValueCheckForCombo : { interfaceId : 1 },

    importValidationJavaClass: true,
    importValidationForComboBox: true,

    columns: [{
        xtype: 'checkcolumn',
        header: 'Enabled'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'enabled',
        resizable: false
    }, {
        header: 'Interface'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'interfaceId',
        renderer: Ung.util.Renderer.interface
    }, {
        header: 'Test Type'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'type',
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'description'
    }],

    editorFields: [{
        xtype: 'checkbox',
        fieldLabel: 'Enabled'.t(),
        bind: '{record.enabled}'
    }, {
        xtype: 'combobox',
        fieldLabel: 'Interface'.t(),
        fieldIndex: 'interfaceCombo',
        bind: {
            value: '{record.interfaceId}',
            store: '{wanStatusStore}'
        },
        allowBlank: false,
        editable: false,
        queryMode: 'local',
        displayField: 'interfaceName',
        valueField: 'interfaceId'
    }, {
        xtype: 'textfield',
        fieldLabel: 'Description'.t(),
        bind: '{record.description}'
    }, {
        xtype: 'numberfield',
        allowDecimals: false,
        minValue: 1,
        fieldLabel: 'Testing Interval (seconds)'.t(),
        bind: '{record.delayMilliseconds}'
    }, {
        xtype: 'numberfield',
        allowDecimals: false,
        minValue: 1,
        fieldLabel: 'Timeout (seconds)'.t(),
        bind: '{record.timeoutMilliseconds}'
    }, {
        xtype: 'combobox',
        fieldLabel: 'Failure Threshold'.t(),
        editable: false,
        bind: '{record.failureThreshold}',
        store: [['1','X1 of 10X'.t()],['2','X2 of 10X'.t()],['3','X3 of 10X'.t()],['4','X4 of 10X'.t()],['5','X5 of 10X'.t()],['6','X6 of 10X'.t()],['7','X7 of 10X'.t()],['8','X8 of 10X'.t()],['9','X9 of 10X'.t()],['10','X10 of 10X'.t()]]
    }, {
        xtype: 'combobox',
        fieldLabel: 'Test Type'.t(),
        editable: false,
        bind: '{record.type}',
        store: [['ping','Ping'.t()],['arp','ARP'.t()],['dns','DNS'.t()],['http','HTTP'.t()]]
    }, {
        xtype: 'fieldset',
        layout: 'column',
        border: false,
        anchor: '100%',
        hidden: true,
        bind: {
            hidden: '{record.type != "ping"}'
        },
        items: [{
            xtype: 'combobox',
            fieldLabel: 'IP'.t(),
            fieldIndex: 'pingCombo',
            labelAlign: 'right',
            labelWidth: 170,
            bind: {
                value: '{record.pingHostname}',
                store: '{pingListStore}'
            },
            allowBlank: false,
            editable: true,
            queryMode: 'local',
            displayField: 'name',
            valueField: 'addr'
        }, {
            xtype: 'button',
            text: 'Generate Suggestions'.t(),
            margin: '0 0 0 10',
            iconCls: 'fa fa-book',
            handler: function(btn) {
                this.up('grid').getController().generateSuggestions(btn);
            }
        }]
    }, {
        xtype: 'textfield',
        fieldLabel: 'URL'.t(),
        bind: {
            value: '{record.httpUrl}',
            hidden: '{record.type != "http"}'
        }
    }, {
        xtype: 'button',
        text: 'Run Test'.t(),
        iconCls: 'fa fa-play',
        anchor: 'left',
        margin: '10 0 0 185',
        width: 140,
        height: 30,
        handler: function(btn) {
            this.up('grid').getController().runWanTest(btn);
        },
    }]

});
