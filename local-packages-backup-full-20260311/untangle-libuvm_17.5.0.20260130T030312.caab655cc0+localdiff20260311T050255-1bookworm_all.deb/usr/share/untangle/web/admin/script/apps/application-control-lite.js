Ext.define('Ung.apps.applicationcontrollite.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-application-control-lite',
    controller: 'app-application-control-lite',

    viewModel: {

        stores: {
            signatureList: {
                data: '{settings.patterns.list}'
            }
        }
    },

    items: [
        { xtype: 'app-application-control-lite-status' },
        { xtype: 'app-application-control-lite-signatures' }
    ]

});
Ext.define('Ung.apps.applicationcontrollite.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-application-control-lite',

    control: {
        '#': {
            afterrender: 'getSettings'
        }
    },

    getSettings: function () {
        var v = this.getView(), vm = this.getViewModel();

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'getSettings')
        .then( function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            vm.set('settings', result);

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        },function(ex){
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);
        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    }

});
Ext.define('Ung.apps.applicationcontrollite.view.Signatures', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-application-control-lite-signatures',
    itemId: 'signatures',
    title: 'Signatures'.t(),
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'copy', 'delete'],
    copyAppendField: 'description',
    listProperty: 'settings.patterns.list',
    emptyRow: {
        javaClass: 'com.untangle.app.application_control_lite.ApplicationControlLitePattern',
        'protocol': '',
        'description': '',
        'category': '',
        'definition': '',
        'quality': '',
        'blocked': false,
        'alert': false,
        'log': false,
        },

    bind: '{signatureList}',

    emptyText: 'No Signatures Defined'.t(),

    extraColumnConfig: {
        block: { allowBlank: false, xtype: 'checkbox' },
        alert: { allowBlank: false, xtype: 'checkbox' },
        log: { allowBlank: false, xtype: 'checkbox' },
        id: { xtype: 'numberfield' },
    },

    columns: [{
        header: 'Protocol'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'protocol'
    }, {
        header: 'Category'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'category'
    }, {
        xtype: 'checkcolumn',
        header: 'Block'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'blocked'
    }, {
        xtype: 'checkcolumn',
        header: 'Log'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'log',
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        flex: 2,
        dataIndex: 'description',
    }],

    editorFields: [{
        xtype: 'textfield',
        bind: '{record.protocol}',
        fieldLabel: 'Protocol'.t()
    }, {
        xtype: 'textfield',
        bind: '{record.category}',
        fieldLabel: 'Category'.t()
    }, {
        xtype: 'checkbox',
        bind: '{record.blocked}',
        fieldLabel: 'Block'.t()
    }, {
        xtype: 'checkbox',
        bind: '{record.log}',
        fieldLabel: 'Log'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.description}',
        fieldLabel: 'Description'.t()
    }, {
        xtype: 'textarea',
        bind: '{record.definition}',
        fieldLabel: 'Signature'.t()
    }]
});
Ext.define('Ung.apps.applicationcontrollite.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-application-control-lite-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'border',
    items: [{
        region: 'center',
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/application-control-lite.svg" width="80" height="80"/>' +
                '<h3>Application Control Lite</h3>' +
                '<p>' + 'Application Control Lite identifies, logs, and blocks sessions based on the session content using manually added custom signatures.'.t() +
                '<br><br>' + 'Upgrade to Application Control to perform deep packet (DP) and deep flow (DF) inspection of network traffic, enabling you to block, flag or allow thousands of common applications.'.t() +
                ' <a target="_blank" href="' + rpc.uriManager.getUriWithPath('https://edge.arista.com/shop/Application-Control') + '">LEARN MORE<a/></p>'
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'appreports'
        }]
    }, {
        region: 'west',
        border: false,
        width: Math.ceil(Ext.getBody().getViewSize().width / 4),
        split: true,
        items: [{
            xtype: 'appsessions',
            region: 'north',
            height: 200,
            split: true
        }, {
            xtype: 'appmetrics',
            region: 'center',
            height: '40%'
        }],
        bbar: [{
            xtype: 'appremove',
            width: '100%'
        }]
    }]

});
