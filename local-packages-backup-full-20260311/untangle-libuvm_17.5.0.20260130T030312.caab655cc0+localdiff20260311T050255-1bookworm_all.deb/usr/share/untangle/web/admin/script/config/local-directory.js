Ext.define('Ung.config.local-directory.Main', {
    extend: 'Ung.cmp.ConfigPanel',
    alias: 'widget.config-local-directory',

    controller: 'config-local-directory',

    viewModel: {
        type: 'config-local-directory'
    },

    items: [
        { xtype: 'config-local-directory-users' },
        {
            xtype: 'config-local-directory-radius-server'
        },
        {
            xtype: 'config-local-directory-radius-proxy'
        },
        {
            xtype: 'config-local-directory-radius-log'
        }
    ]
});
Ext.define('Ung.config.local-directory.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.config-local-directory',
    alternateClassName: 'Ung.config.localdirectory.MainController',

    control: {
        '#': {
            beforerender: 'loadSettings'
        },
        '#radius-log': { afterrender: 'refreshRadiusLogFile' },
        '#radius-proxy': { afterrender: 'refreshRadiusProxyStatus' }
    },

    loadSettings: function () {
        var me = this, v = me.getView(), vm = me.getViewModel();

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.UvmContext.localDirectory.getUsers'),
            Rpc.asyncPromise('rpc.systemManager.getSettings')
        ], this)
        .then(function (result) {
            if(Util.isDestroyed(v, vm)){
                return;
            }
            // set the local record fields we use to deal with the expiration time and add vs edit logic
            var users = result[0];
                for(var i = 0 ; i < users.list.length ; i++) {
                    users.list[i].localEmpty = false;
                        if (users.list[i].expirationTime == 0) {
                            users.list[i].localExpires = new Date();
                            users.list[i].localForever = true;
                        } else {
                            users.list[i].localExpires = new Date(users.list[i].expirationTime);
                            users.list[i].localForever = false;
                        }
                }

            vm.set('usersData', users);
            vm.set('systemSettings', result[1]);
            me.getOrignalPasswd();
            v.setLoading(false);
            vm.set('panel.saveDisabled', false);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
        });
    },

    getOrignalPasswd: function() { 
        var vm = this.getViewModel();
        encryptedPassword = vm.get('systemSettings.radiusProxyEncryptedPassword');
        if(encryptedPassword != null && encryptedPassword != "")
        {
            password  = Util.getDecryptedPassword(encryptedPassword);
            vm.set('systemSettings.radiusProxyPassword', password);
        }
    },

    saveSettings: function () {
        var me = this, v = me.getView(), vm = me.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);
        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();

            /**
             * Important!
             * update custom grids only if are modified records or it was reordered via drag/drop
             */
            if (store.getModifiedRecords().length > 0 || store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        var userlist = vm.get('usersData');
        var user;

        for(var i = 0 ; i < userlist.list.length ; i++) {
            user = userlist.list[i];

            if(user.password == null) user.password = "";

            // calculate the passwordBase64Hash for any changed passwords and remove cleartext
            if(user.password.length > 0) {
                user.passwordBase64Hash = Util.base64encode(user.password);
                user.password = "";
            }

            // use localForever and localExpires to set the correct expirationTime
            if (user.localForever == true) {
                user.expirationTime = 0;
            } else {
                if (!(user.localExpires instanceof Date)) {
                    user.localExpires = new Date(user.localExpires);
                }
                user.expirationTime = user.localExpires.getTime();
            }
        }

        var dirtyRadiusFields = false;
        Ext.Array.each(v.query('field'), function (field) {
            if (!field._neverDirty && field._isChanged && !dirtyRadiusFields) {
                dirtyRadiusFields = true;
            }
        });

        // Make sure we set the userlist last because that function will generate
        // the user credentials and shared secret configs for the freeradius server
        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.systemManager.setSettings', vm.get('systemSettings'), dirtyRadiusFields),
            Rpc.asyncPromise('rpc.UvmContext.localDirectory.setUsers', userlist)
        ], this)
        .then(function (result) {
            if(Util.isDestroyed(v, me)){
                return;
            }
            var radiusProxyCheckbox = v.query('field')[2];
            v.setLoading(false);
            Ext.fireEvent('resetfields', v);
            me.loadSettings();
            v.setLoading(false);
            Util.successToast('Settings saved');

            //Disable Radius Proxy fieldsets if needed
            if (radiusProxyCheckbox.checked) {
                // After save, have to set original value to current value so isDirty() computes properly
                var radiusProxyTextFields = radiusProxyCheckbox.up('panel').query('fieldset')[0].query('textfield');
                radiusProxyTextFields.forEach(function(textField) {
                    textField.originalValue = textField.value;
                });

                //Disable fieldsetes if any field of AD server is disabled
                var emptyFields = me.checkDirtyOrEmpty(radiusProxyCheckbox);
                if (emptyFields) me.setDisabledForRadiusProxyFieldsets(radiusProxyCheckbox, true);
                else me.setDisabledForRadiusProxyFieldsets(radiusProxyCheckbox, false);
            }
        }, function (ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },
    configureCertificate: function (btn) {
        Ung.app.redirectTo("#config/administration/certificates");
    },

    refreshRadiusLogFile: function (cmp) {
        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var target = v.down('textarea');

        if (!target) {
            return;
        }

        v.setLoading(true);
        Rpc.asyncData('rpc.UvmContext.localDirectory.getRadiusLogFile')
        .then(function(result){
            if(Util.isDestroyed(v, target)){
                return;
            }
            target.setValue(result);
            v.setLoading(false);
        });
    },

    refreshRadiusProxyStatus: function (cmp) {
        var vm = this.getViewModel();
        if (vm.get('systemSettings.radiusProxyEnabled') !== true) {
            return;
        }

        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var target = v.down('textarea');

        if (!target) {
            return;
        }

        v.setLoading(true);
        Rpc.asyncData('rpc.UvmContext.localDirectory.getRadiusProxyStatus')
        .then(function(result){
            if(Util.isDestroyed(v, target)){
                return;
            }
            target.setValue(result);
            v.setLoading(false);
        });
    },

    createComputerAccount: function (cmp) {
        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var dirtyFields = false;

        Ext.Array.each(v.query('field'), function (field) {
            if (!field._neverDirty && field._isChanged && !dirtyFields) {
                dirtyFields = true;
            }
        });

        if (dirtyFields) {
            Ext.MessageBox.alert('Unsaved Changes'.t(), 'The settings must be saved before the computer account can be created.'.t());
            return;
        }

        v.setLoading(true);
        Rpc.asyncData('rpc.UvmContext.localDirectory.addRadiusComputerAccount')
        .then(function(result){
            v.setLoading(false);
            Ext.MessageBox.alert({ buttons: Ext.Msg.OK, maxWidth: 1024, title: 'Account Creation Status'.t(), msg: '<tt>' + result.output + '</tt>' });
        });
    },

    testRadiusProxyLogin: function (cmp) {
        var v = cmp.isXType('button') ? cmp.up('panel') : cmp;
        var testuser = v.down("[fieldIndex='testUsername']").getValue();
        var testpass = v.down("[fieldIndex='testPassword']").getValue();
        var testdom = v.down("[fieldIndex='adDomain']").getValue();
        var dirtyFields = false;

        Ext.Array.each(v.query('field'), function (field) {
            if (!field._neverDirty && field._isChanged && !dirtyFields) {
                dirtyFields = true;
            }
        });

        if (dirtyFields) {
            Ext.MessageBox.alert('Unsaved Changes'.t(), 'The settings must be saved before using the authentication test.'.t());
            return;
        }

        v.setLoading(true);
        Rpc.asyncData('rpc.UvmContext.localDirectory.testRadiusProxyLogin', testuser, testpass, testdom)
        .then(function(result){
            v.setLoading(false);
            Ext.MessageBox.alert({ buttons: Ext.Msg.OK, maxWidth: 1024, title: 'Test Authentication Result'.t(), msg: '<tt>' + result + '</tt>' });
        });
    },

    /**
     * Logic to handle showing/hiding password in the Radius Proxy UI
     * @param {button} button that user clicks to indicate if they want to hide/show the password
     */
    showOrHideRadiusPassword: function (button) {
        var isShowPassword = button.iconCls === 'fa fa-eye';
        button.setTooltip(isShowPassword ? 'Hide password' : 'Show password');
        button.setIconCls(isShowPassword ? 'fa fa-eye-slash' : 'fa fa-eye');
        button.prev().getEl().query('input', false)[0].set({'type':isShowPassword?'text':'password'});
    },

    /**
     * When a field changes, determine if should disable or enable the fieldsets
     * @param {field} field field being changed
     * @param {string} newVal new value of field
     * @param {string} oldVal old value of field
     */
    radiusProxyDirtyFieldsHandler: function(field, newVal, oldVal) {
        var me = this;

        //The first change occurs always when the value is binded, so set it to that value
        // so original value is correct
        if (field._onFirstChange) {
            field.originalValue = newVal;
        }
        // Determine if any field is empty
        var emptyOrDirtyFields = me.checkDirtyOrEmpty(field);

        //If the checkbox is false, fields are empty, or a non-checkbox is dirty, disable fields
        if (!newVal                                         ||
            emptyOrDirtyFields                              ||
            (field.xtype === 'checkbox' && !newVal)         ||
            (field.xtype !== 'checkbox' && field.isDirty()) ||
            (field.xtype !== 'checkbox' && !field.up('panel').query('checkbox')[0].checked)) {
            me.setDisabledForRadiusProxyFieldsets(field, true);
        } else {
            me.setDisabledForRadiusProxyFieldsets(field, false);
        }

        field._onFirstChange = false;
    },

    /**
     * Deteremine if any fields in Active Directory Server fieldset of Radius Proxy are empty or dirty
     * @param {field} field field used to find textfields of AD server to see if empty
     */
    checkDirtyOrEmpty: function(field) {
        var emptyOrDirtyFields = false;
        textFields = field.up('panel').query('fieldset')[0].query('textfield');
        textFields.forEach(function(textField) {
            //Use original value as the getValue() is unreliable with the password input
            if (textField.value === '' || textField.isDirty()) {
                emptyOrDirtyFields = true;
            }
        });
        return emptyOrDirtyFields;
    },

    /**
     * Enable/Disable the Active Directory Test and Active Directory Status of Radius Proxy
     * @param {field} field field to find the Active Directory Test and Active Directory Status fieldsets
     * @param {boolean} disabled boolean on if fieldsets should be disabled or not
     */
    setDisabledForRadiusProxyFieldsets: function(field, disabled) {
        field.up('panel').query('fieldset')[1].setDisabled(disabled);
        field.up('panel').query('fieldset')[2].setDisabled(disabled);
    },

    statics:{
        expirationRenderer: function( value ){
            var date;
            if (value > 0) {
                date = new Date(value);
                return Renderer.timestamp(Util.clientToServerDate(date).getTime());
            } else {
                return 'Never'.t();
            }
        }
    }

});
Ext.define('Ung.config.local-directory.MainModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.config-local-directory',

    data: {
        title: 'Local Directory'.t(),
        iconName: 'local-directory',

        usersData: null,
        systemSettings: null
    },

    stores: {
        users: {
            data: '{usersData.list}'
        }
    }
});
Ext.define('Ung.config.local-directory.view.RadiusLog', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-local-directory-radius-log',
    itemId: 'radius-log',
    title: 'RADIUS Log',
    scrollable: false,
    viewModel: true,
    withValidation: false,
    bodyPadding: 10,
    layout: 'fit',

    items: [{
        xtype: 'fieldset',
        padding: '10 20',
        itemId: 'radius-log',
        width: '100%',
        height: '100%',
        title: 'RADIUS Server Log'.t(),
        items: [{
            xtype: 'button',
            iconCls: 'fa fa-refresh',
            text: 'Refresh',
            target: 'radiusLogFile',
            handler: 'refreshRadiusLogFile'
        }, {
            xtype: 'textarea',
            itemId: 'radiusLogFile',
            spellcheck: false,
            padding: '5 0 5 0',
            border: true,
            width: '100%',
            height: '95%',
            _neverDirty: true,
            bind: '{radiusLogFile}',
            fieldStyle: {
                'fontFamily'   : 'courier new',
                'fontSize'     : '12px'
            }
        }]
    }]
});
Ext.define('Ung.config.local-directory.view.RadiusProxy', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-local-directory-radius-proxy',
    itemId: 'radius-proxy',
    title: 'RADIUS Proxy',
    scrollable: true,
    viewModel: true,
    withValidation: true,
    bodyPadding: 10,

    items: [{
        xtype: 'component',
        margin: '0 0 10 0',
        html: 'The RADIUS Proxy can be enabled to allow wireless clients to authenticate using account credentials stored in an Active Directory server.'.t()
    },{
        xtype: 'checkbox',
        reference: 'activeProxy',
        padding: '5 0',
        boxLabel: 'Enable Active Directory Proxy'.t(),
        _onFirstChange: true,
        bind: {
            value: '{systemSettings.radiusProxyEnabled}',
            disabled: '{!systemSettings.radiusServerEnabled}'
        },
        listeners: {
            change: 'radiusProxyDirtyFieldsHandler'
        }
    }, {
        xtype: 'fieldset',
        padding: '10 20',
        itemId: 'radius-proxy',
        width: 600,
        title: 'Active Directory Server'.t(),
        items: [{
            xtype: 'textfield',
            fieldLabel: 'AD Server'.t(),
            labelWidth: 120,
            width: '100%',
            allowBlank: false,
            vtype: 'hostName',
            _onFirstChange: true,
            bind: {
                value: '{systemSettings.radiusProxyServer}',
                disabled: '{!activeProxy.checked}'
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'AD Workgroup'.t(),
            labelWidth: 120,
            width: '100%',
            fieldStyle: 'text-transform:uppercase',
            allowBlank: false,
            _onFirstChange: true,
            bind: {
                value: '{systemSettings.radiusProxyWorkgroup}',
                disabled: '{!activeProxy.checked}'
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'AD Domain'.t(),
            labelWidth: 120,
            fieldIndex: 'adDomain',
            width: '100%',
            allowBlank: false,
            vtype: 'domainName',
            _onFirstChange: true,
            bind: {
                value: '{systemSettings.radiusProxyRealm}',
                disabled: '{!activeProxy.checked}'
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'AD Admin Username'.t(),
            labelWidth: 120,
            width: '100%',
            allowBlank: false,
            _onFirstChange: true,
            bind: {
                value: '{systemSettings.radiusProxyUsername}',
                disabled: '{!activeProxy.checked}'
            }
        }, {
            xtype: 'fieldcontainer',
            layout: 'hbox',
            width: '100%',
            items: [{
                xtype: 'textfield',
                fieldLabel: 'AD Admin Password'.t(),
                labelWidth: 120,
                width: '96%',
                allowBlank: false,
                inputType: 'password',
                _onFirstChange: true,
                bind: {
                    value: '{systemSettings.radiusProxyPassword}',
                    disabled: '{!activeProxy.checked}'
                },
                listeners: {
                    change: 'radiusProxyDirtyFieldsHandler',
                }
            }, {
                xtype: 'button',
                iconCls: 'fa fa-eye',
                tooltip: 'Show Password',
                handler: 'showOrHideRadiusPassword',
                bind: {
                    disabled: '{!activeProxy.checked}'
                }
            }]
        }],
        defaults: {
            listeners: {
                change: 'radiusProxyDirtyFieldsHandler',
            }
        },
    }, {
        xtype: 'fieldset',
        padding: '10 20',
        itemId: 'radius-test',
        width: 600,
        title: 'Active Directory Test'.t(),
        disabled: true,
        items: [{
            xtype: 'textfield',
            fieldLabel: 'Test Username'.t(),
            fieldIndex: 'testUsername',
            labelWidth: 120,
            width: '100%',
            allowBlank: true,
            _neverDirty: true,
        }, {
            xtype: 'fieldcontainer',
            layout: 'hbox',
            width: '100%',
            items: [{
                xtype: 'textfield',
                fieldLabel: 'Test Password'.t(),
                fieldIndex: 'testPassword',
                labelWidth: 120,
                width: '96%',
                allowBlank: true,
                _neverDirty: true,
                inputType: 'password',
            }, {
                xtype: 'button',
                iconCls: 'fa fa-eye',
                tooltip: 'Show Password',
                handler: 'showOrHideRadiusPassword',
            }]
        }, {
            xtype: 'button',
            iconCls: 'fa fa-cogs',
            text: 'Test Authentication',
            margin: '10, 0',
            handler: 'testRadiusProxyLogin'
        }]
    },
    {
        xtype: 'fieldset',
        padding: '10 20',
        itemId: 'radius-account',
        width: 600,
        disabled: true,
        title: 'Active Directory Status'.t(),
        items: [{
            xtype: 'button',
            iconCls: 'fa fa-refresh',
            text: 'Refresh AD Account Status',
            margin: '10, 0',
            target: 'radiusProxyStatus',
            handler: 'refreshRadiusProxyStatus'
        }, {
            xtype: 'button',
            iconCls: 'fa fa-link',
            text: 'Create AD Computer Account',
            margin: '10, 10',
            handler: 'createComputerAccount'
        }, {
            xtype: 'textarea',
            labelWidth: 120,
            width: '100%',
            allowBlank: true,
            readOnly: true,
        }]
    }]
});
Ext.define('Ung.config.local-directory.view.RadiusServer', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-local-directory-radius-server',
    itemId: 'radius-server',
    title: 'RADIUS Server',
    scrollable: true,
    viewModel: true,
    withValidation: true,
    bodyPadding: 10,

    items: [{
        xtype: 'component',
        margin: '0 0 10 0',
        html: 'The RADIUS Server can be enabled to allow wireless clients of 802.1x network access points to authenticate with their Local Directory username and password.'.t()
    }, {
        xtype: 'fieldset',
        padding: '10 20',
        itemId: 'radius-server',
        width: 600,
        title: 'Wi-Fi Authentication'.t(),
        items: [{
            xtype: 'checkbox',
            reference: 'externalAccess',
            padding: '5 0',
            boxLabel: 'Enable external access point authentication'.t(),
            bind: {
                value: '{systemSettings.radiusServerEnabled}'
            },
            listeners: {
                change: {
                    fn: function(box,nval,oval,opts) {
                        if (nval === false) {
                            vm = box.ownerCt.ownerCt.getViewModel();
                            vm.set('systemSettings.radiusProxyEnabled', false);
                        }
                    }
                }
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'RADIUS password'.t(),
            inputType: 'password',
            labelWidth: 120,
            width: '100%',
            allowBlank: false,
            bind: {
                value: '{systemSettings.radiusServerSecret}',
                disabled: '{!externalAccess.checked}'
            }
        }, {
            xtype: 'button',
            iconCls: 'fa fa-cog',
            text: 'Configure Server Certificate'.t(),
            margin: '10, 0',
            bind: {
                disabled: '{!systemSettings.radiusServerEnabled}',
            },
            handler: 'configureCertificate'
        }]
    }]
});
Ext.define('Ung.config.local-directory.view.Users', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-local-directory-users',
    itemId: 'local-users',
    title: 'Local Users'.t(),
    scrollable: true,
    withValidation: false,
    layout: 'fit',
    items: [{
        xtype: 'ungrid',
        border: false,
        title: 'Local Users'.t(),
        itemId: 'local-users-grid',

        emptyText: 'No Local Users defined'.t(),

        tbar: ['@add', '->', '@import', '@export'],
        recordActions: ['edit', 'delete'],

        listProperty: 'usersData.list',
        
        importValidationJavaClass: true,

        emptyRow: {
            username: '',
            firstName: '',
            lastName: '',
            email: '',
            encryptPassword: '',
            twofactorSecretKey: '',
            localExpires: Util.serverToClientDate(new Date()),
            localForever: true,
            localEmpty: true,
            mfaEnabled: false,
            expirationTime: 0,
            javaClass: 'com.untangle.uvm.LocalDirectoryUser'
        },

        bind: '{users}',

        columns: [{
            header: 'User/Login ID'.t(),
            width: Renderer.usernameWidth,
            dataIndex: 'username',
            editor: {
                xtype: 'textfield',
                allowBlank: false,
                emptyText: '[enter login]'.t(),
                regex: /^[\w\. ]+$/,
                regexText: 'The field user/login ID can have only alphanumeric characters.'.t()
            }
        }, {
            header: 'First Name'.t(),
            width: Renderer.messageWidth,
            dataIndex: 'firstName',
            editor: {
                xtype: 'textfield',
                emptyText: '[enter first name]'.t(),
                allowBlank: false
            }
        }, {
            header: 'Last Name'.t(),
            width: Renderer.messageWidth,
            dataIndex: 'lastName',
            editor: {
                xtype: 'textfield',
                emptyText: '[last name]'.t()
            }
        }, {
            header: 'Email Address'.t(),
            width: Renderer.emailWidth,
            dataIndex: 'email',
            flex: 1,
            editor: {
                xtype: 'textfield',
                emptyText: '[email address]'.t(),
                vtype: 'email'
            }
        }, {
            header: 'Password'.t(),
            width: Renderer.messageWidth,
            dataIndex: 'password',
            renderer: Ext.bind(function (value, metadata, record) {
                if (record.get("encryptedPassword") == null) return ('');
                if (Ext.isEmpty(value) && record.get("encryptedPassword").length > 0) return ('*** ' + 'Unchanged'.t() + ' ***');
                var result = "";
                for (var i = 0; value != null && i < value.length; i++) result = result + '*';
                return result;
            }, this)
        },
        {
            header: 'OpenVPN MFA secret'.t(),
            xtype: 'actioncolumn',
            width: Renderer.messageWidth,
            dataIndex: 'twofactorSecretKey',
            iconCls: 'fa fa-cog',
            align: 'center',
            tooltip: 'Enable/disable MFA by editting user.'.t(),
            getClass: function (value, metadata, record) {
                if (record.get("twofactorSecretKey") !== "") {
                    return 'fa fa-cog';
                }
                return 'fa fa-minus';
            },
            handler: function (unk1, unk2, unk3, event, unk5, record) {
                if (record.get('twofactorSecretKey') !== "") {
                    Rpc.asyncData('rpc.UvmContext.localDirectory.showSecretQR', record.get('username'), 'Untangle', record.get('twofactorSecretKey'))
                        .then(function (result) {
                            Ext.MessageBox.alert({ buttons: Ext.Msg.OK, maxWidth: 1024, title: 'Provide user with key or QR image.'.t(), msg: result });
                        });
                }
            },
            isDisabled: function (view, rowIndex, colIndex, item, record) {
                if (!record.get("mfaEnabled") || record.get("twofactorSecretKey") === "")
                    return true;
                return false;
            },
        }, {
            header: 'Expiration'.t(),
            dataIndex: 'expirationTime',
            width: Renderer.timestampWidth,
            resizable: false,
            renderer: Ung.config.localdirectory.MainController.expirationRenderer
        }],
        editorFields: [{
            xtype: 'textfield',
            fieldLabel: 'User/Login ID'.t(),
            bind: '{record.username}',
            emptyText: '[enter login]'.t(),
            allowBlank: false,
            regex: /^[\w\. ]+$/,
            regexText: 'The field user/login ID can have only alphanumeric character.'.t(),
        }, {
            xtype: 'textfield',
            fieldLabel: 'First Name'.t(),
            bind: '{record.firstName}',
            emptyText: '[enter first name]'.t(),
            allowBlank: false,
            width: 300
        }, {
            xtype: 'textfield',
            fieldLabel: 'Last Name'.t(),
            bind: '{record.lastName}',
            emptyText: '[last name]'.t(),
            width: 300
        }, {
            xtype: 'textfield',
            fieldLabel: 'Email Address'.t(),
            bind: '{record.email}',
            emptyText: '[email address]'.t(),
            vtype: 'email',
            width: 300
        }, {
            xtype: 'container',
            layout: 'column',
            items: [{
                xtype: 'textfield',
                fieldLabel: 'Password'.t(),
                labelAlign: 'right',
                labelWidth: 180,
                width: 300,
                inputType: 'password',
                allowBlank: true,
                bind: {
                    value: '{record.password}',
                    hidden: '{record.localEmpty}',
                    disabled: '{record.localEmpty}',
                },
            }, {
                xtype: 'textfield',
                fieldLabel: 'Password'.t(),
                labelAlign: 'right',
                labelWidth: 180,
                width: 300,
                inputType: 'password',
                allowBlank: false,
                bind: {
                    value: '{record.password}',
                    hidden: '{!record.localEmpty}',
                    disabled: '{!record.localEmpty}',
                },
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: '(leave empty to keep the current password unchanged)'.t(),
                bind: {
                    hidden: '{record.localEmpty}'
                }
            }, {
                xtype: 'displayfield',
                margin: '0 0 0 10',
                value: '',
                bind: {
                    hidden: '{!record.localEmpty}'
                }
            }]
        }, {
            xtype: 'checkbox',
            fieldLabel: 'Enable MFA for OpenVPN'.t(),
            bind: {
                value: '{record.mfaEnabled}',
                hidden: '{!record.username}'
            }
        }, {
            xtype: 'container',
            layout: 'column',
            items: [{
                xtype: 'textfield',
                fieldLabel: 'MFA Secret key'.t(),
                labelAlign: 'right',
                inputType: 'password',
                labelWidth: 180,
                width: 500,
                allowBlank: true,
                emptyText: '[Key not currently set]'.t(),
                bind: {
                    value: '{record.twofactorSecretKey}',
                    hidden: '{!record.username || !record.mfaEnabled}'
                },
            }, {
                xtype: 'button',
                text: 'Generate new key'.t(),
                bind: {
                    hidden: '{!record.username || !record.mfaEnabled}'
                },
                handler: function (btn) {
                    Rpc.asyncData('rpc.UvmContext.localDirectory.generateSecret')
                        .then(function (result) {
                            btn.lookupViewModel().get('record').set('twofactorSecretKey', result);
                        });
                }
            },
            {
                xtype: 'button',
                iconCls: 'fa fa-cog',
                align: 'center',
                bind: {
                    hidden: '{!record.twofactorSecretKey || !record.mfaEnabled}'
                },
                handler: function (btn) {
                    var record = btn.lookupViewModel().get('record');
                    Rpc.asyncData('rpc.UvmContext.localDirectory.showSecretQR', record.get('username'), 'Untangle', record.get('twofactorSecretKey'))
                        .then(function (result) {
                            Ext.MessageBox.alert({ buttons: Ext.Msg.OK, maxWidth: 1024, title: 'Provide user with key or QR image.'.t(), msg: result });
                        });
                }
            }]
        }, {
            xtype: 'numberfield',
            fieldIndex: 'expirationTime',
            hidden: true,
            bind: '{record.expirationTime}'
        }, {
            xtype: 'checkbox',
            fieldLabel: 'User Never Expires'.t(),
            fieldIndex: 'localForever',
            bind: '{record.localForever}',
            listeners: {
                change: function (cmp, nval, oval, opts) {
                    var target = this.ownerCt.down("[fieldIndex='expirationTime']");
                    if (nval == true) {
                        target.setValue(0);
                    } else {
                        var finder = this.ownerCt.down("[fieldIndex='DateTimePicker']");
                        target.setValue(finder.getValue().getTime());
                    }
                }
            }
        }, {
            xtype: 'datetimefield',
            fieldLabel: 'Expiration Date/Time'.t(),
            fieldIndex: 'DateTimePicker',
            format: 'timestamp_fmt'.t(),
            editable: false,
            bind: {
                value: '{record.localExpires}',
                hidden: '{record.localForever}',
                disabled: '{record.localForever}'
            },
            listeners: {
                change: function (cmp, nval, oval, opts) {
                    var finder = this.ownerCt.down("[fieldIndex='localForever']");
                    var target = this.ownerCt.down("[fieldIndex='expirationTime']");
                    if (finder.getValue() == false) target.setValue(nval.getTime());
                }
            }
        }]
    }]

});
