Ext.define('Ung.config.system.Main', {
    extend: 'Ung.cmp.ConfigPanel',
    alias: 'widget.config-system',
    itemId: 'system',
    layout: 'border',

    viewModel: {
        data: {
            title: 'System'.t(),
            iconName: 'system',
            vueMigrated: true
        }
    },

    listeners: {
        activate: function (panel) {
            var target = panel.down('#iframeHolder');
            Util.attachIframeToTarget(target, '/console/settings/system', false);
        }
    },

    items: [
        Field.iframeHolder
    ]

});
Ext.define('Ung.config.system.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.config-system',

    control: {
        '#': { afterrender: 'loadSettings' }
    },

    loadSettings: function () {
        var me = this, v= me.getView(), vm = me.getViewModel();

        var rpcSequence = [
            Rpc.asyncPromise('rpc.languageManager.getLanguageSettings'),
            Rpc.asyncPromise('rpc.systemManager.getSettings'),
            Rpc.directPromise('rpc.isExpertMode'),
        ];

        var dataNames = [
            'languageSettings',
            'systemSettings',
            'isExpertMode'
        ];

        v.setLoading(true);
        Ext.Deferred.sequence(rpcSequence, this)
        .then(function(result){
            if(Util.isDestroyed(vm, dataNames)){
                return;
            }


            // Massage language to include the appropriate source.
            var languageSettings = result[0];
            languageSettings['language'] = languageSettings['source'] + '-' + languageSettings['language'];

            dataNames.forEach(function(name, index) {
                if (name !== 'timeZonesList') {
                    vm.set(name, result[index]);
                }
            });

            vm.set('panel.saveDisabled', false);

            // Load language list.
            if(!vm.get('languagesList')){
                Rpc.asyncData('rpc.languageManager.getLanguagesList')
                    .then( function(result){
                        if(!Util.isDestroyed(v,vm)){
                            v.setLoading(false);
                            var languageList = [];
                            result["list"].forEach( function(language){
                                // Only add enabled languages
                                // OR if a disabled language matches the currently selected.
                                if(language["enabled"] === true || language["languageCode"] == languageSettings['language']){
                                    languageList.push(language);
                                }
                            });
                            vm.set('languagesList', {"list": languageList});
                        }
                    });
            }else{
                v.setLoading(false);
            }
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
        });
    },

    saveSettings: function () {
        var me = this, v = me.getView(),
            vm = me.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.setLoading(true);
        if (vm.get('languageSettings.regionalFormats') === 'default') {
            // reset overrides
            vm.set('languageSettings.overrideDateFmt', '');
            vm.set('languageSettings.overrideDecimalSep', '');
            vm.set('languageSettings.overrideThousandSep', '');
            vm.set('languageSettings.overrideTimestampFmt', '');
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        var languageSettings = vm.get('languageSettings');
        var languageSplit = languageSettings['language'].split('-');
        if(languageSplit[0] != 'official'){
            // Something bad has happened; referve to known good language.
            languageSplit[0] = "official";
            languageSplit[1] = "en";
        }
        languageSettings['source'] = languageSplit[0];
        languageSettings['language'] = languageSplit[1];

        var rpcSequence = [
            Rpc.asyncPromise('rpc.languageManager.setLanguageSettings', languageSettings),
            Rpc.asyncPromise('rpc.systemManager.setSettings', vm.get('systemSettings')),
        ];

        Ext.Deferred.sequence(rpcSequence, this)
        .then(function () {
            if(Util.isDestroyed(me, v, vm)){
                return;
            }
            Util.successToast('System settings saved!');
            if(vm.get('localizationChanged') == true){
                window.location.reload();
            }
            Ext.fireEvent('resetfields', v);
            v.setLoading(false);
            me.loadSettings();
        }, function (ex) {
            if(!Util.isDestroyed(v, vm)){
                v.setLoading(false);
                vm.set('panel.saveDisabled', true);
            }
        });
    },

    // Support methods
    downloadSystemLogs: function () {
        var downloadForm = document.getElementById('downloadForm');
        downloadForm.type.value = 'SystemSupportLogs';
        downloadForm.submit();
    }
});
Ext.define('Ung.config.system.MainModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.config-system',

    data: {
        title: 'System'.t(),
        iconName: 'system',

        languageSettings: null,
        systemSettings: null
    },
    formulas: {
        // used for setting the date/time
        manualDateFormat: function (get) { return get('languageSettings.overrideTimestampFmt') || 'timestamp_fmt'.t(); },
    }
});
Ext.define('Ung.config.system.view.Regional', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.config-system-regional',
    itemId: 'regional',
    viewModel: true,
    scrollable: true,
    withValidation: false,
    title: 'Regional'.t(),

    bodyPadding: 10,

    defaults: {
        xtype: 'fieldset',
        padding: 10
    },

    items: [{
        title: 'Time Settings'.t(),
        hidden: true,
        bind: {
            hidden: '{!(isExpertMode || systemSettings.timeSource === "manual" || !time)}'
        },
        items: [{
            xtype: 'radiogroup',
            columns: 1,
            vertical: true,
            simpleValue: true,
            bind: '{systemSettings.timeSource}',
            items: [{
                boxLabel: '<strong>' + 'Synchronize time automatically via NTP'.t() + '</strong>',
                inputValue: 'ntp'
            }, {
                xtype: 'fieldset',
                margin: 5,
                border: false,
                disabled: true,
                hidden: true,
                layout: {
                    type: 'hbox'
                },
                bind: {
                    disabled: '{systemSettings.timeSource !== "ntp"}',
                    hidden: '{systemSettings.timeSource !== "ntp"}'
                },
                items: [{
                    xtype: 'button',
                    margin: '0 10 0 0',
                    text: 'Synchronize Time'.t(),
                    iconCls: 'fa fa-refresh',
                    handler: 'syncTime'
                }, {
                    xtype: 'displayfield',
                    value: 'Click to force instant time synchronization.'.t()
                }]
            }, {
                boxLabel: '<strong>' + 'Set system clock manually'.t() + '</strong>',
                inputValue: 'manual'
            }, {
                xtype: 'datefield',
                width: 180,
                margin: '5 25',
                disabled: true,
                hidden: true,
                value: new Date(),
                format: 'timestamp_fmt'.t(),
                bind: {
                    value: '{manualDate}',
                    format: '{manualDateFormat}',
                    disabled: '{systemSettings.timeSource !== "manual"}',
                    hidden: '{systemSettings.timeSource !== "manual"}'
                }
            }]
        }]
    }]

});
