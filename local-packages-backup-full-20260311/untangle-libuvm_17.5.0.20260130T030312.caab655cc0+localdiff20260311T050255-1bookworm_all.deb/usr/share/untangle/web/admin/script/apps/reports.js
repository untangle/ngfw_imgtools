Ext.define('Ung.apps.reports.Main', {
    extend: 'Ung.cmp.AppPanel',
    alias: 'widget.app-reports',

    controller: 'app-reports',

    viewModel: {
        data: {
            googleDriveConfigured: false,
            reportQueueSize: 0
        },
        formulas: {
            driveConfiguredText: function (get) {
                return get('googleDriveConfigured') ? 'The Google Connector is configured'.t() : 'The Google Connector is unconfigured.'.t();
            },
            emailIntervals: function( get ){
                var availableIntervals = [];
                var dbRetentionTime = get('settings').dbRetention * 86400;
                for(var interval in Renderer.timeIntervalMap ){
                    if( interval <= dbRetentionTime ){
                        availableIntervals.push( [ Number(interval), Renderer.timeIntervalMap[interval] ] );
                    }
                }
                return availableIntervals;
            }
        },
        stores: {
            users: { data: '{settings.reportsUsers.list}' },
            hostnames: { data: '{settings.hostnameMap.list}' },
            emailTemplates: { data: '{settings.emailTemplates.list}' },
            reportEntries: { data: '{settings.reportEntries.list}' }
        }
    },

    items: [
        { xtype: 'app-reports-status' },
        { xtype: 'app-reports-allreports' },
        { xtype: 'app-reports-data' },
        { xtype: 'app-reports-emailtemplates' },
        { xtype: 'app-reports-users' },
        { xtype: 'app-reports-namemap' }
    ]

});
Ext.define('Ung.apps.reports.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-reports',

    control: {
        '#': {
            afterrender: 'getSettings',
            activate: 'checkGoogleDrive'
        },
        '#email-templates': {
            afterrender: 'emailTemplatesAfterRender'
        }
    },

    getSettings: function () {
        var me = this, v = me.getView(), vm = me.getViewModel();

        v.setLoading(true);
        Ext.Deferred.sequence([
            Rpc.directPromise('rpc.isExpertMode'),
            Rpc.asyncPromise(v.appManager, 'getSettings'),
            Rpc.asyncPromise(v.appManager, 'getFixedReportQueueSize'),
            Rpc.asyncPromise('rpc.UvmContext.googleManager.getAppSpecificGoogleDrivePath', null)
        ]).then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            vm.set('isExpertMode', result[0]);
            vm.set('settings', result[1]);
            vm.set('reportQueueSize', result[2]);
            vm.set('rootDirectory', result[3]);

            vm.set('panel.saveDisabled', false);
            vm.set('dbRetentionInDays', vm.get('settings').dbRetention > 0);
            v.setLoading(false);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    emailTemplatesAfterRender: function(){
        var me = this,
            v = me.getView(),
            vm = me.getViewModel();

        var dayOfWeekList = [];
        for( var i in Renderer.dayOfWeekMap ){
            dayOfWeekList.push( [Number(i) ,Renderer.dayOfWeekMap[i]] );
        }
        vm.set('dayOfWeekList', dayOfWeekList);

        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.reportsManager.getCurrentApplications'),
            Rpc.asyncPromise('rpc.reportsManager.fixedReportsAllowGraphs'),
            Rpc.asyncPromise('rpc.reportsManager.getRecommendedReportIds'),
        ]).then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }

            var appCategories = [];
            result[0].list.forEach( function( app ){
                appCategories.push( app.displayName );
            });

            vm.set({
                appCategories: appCategories,
                configCategories: ['Hosts', 'Devices', 'Network', 'Administration', 'Events', 'System', 'Shield'],
                fixedReportsAllowGraphs: result[1],
                emailRecommendedReportIds: result[2].list
            });

            vm.set('panel.saveDisabled', false);
            v.setLoading(false);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    setSettings: function () {
        var me = this, v = this.getView(), vm = this.getViewModel();

        if (!Util.validateForms(v)) {
            return;
        }

        v.query('ungrid').forEach(function (grid) {
            var store = grid.getStore();
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                store.each(function (record) {
                    if (record.get('markedForDelete')) {
                        record.drop();
                    }
                });
                store.isReordered = undefined;
                vm.set(grid.listProperty, Ext.Array.pluck(store.getRange(), 'data'));
            }
        });

        v.setLoading(true);

         if (vm.get('dbRetentionInDays')) {
            // We will be setting daily retention. Zero-out hourly retention so that it isn't set later.
            vm.set('settings.dbRetentionHourly', 0);
         } else {
            // using hourly retention instead of daily
            // We will be setting hourly retention. Zero-out daily retention so that it isn't set later.
            vm.set('settings.dbRetention', 0);
         }

        Rpc.asyncData(v.appManager, 'setSettings', vm.get('settings'))
        .then(function(result){
            if(Util.isDestroyed(v, vm)){
                return;
            }
            Util.successToast('Settings saved');
            vm.set('panel.saveDisabled', false);
            v.setLoading(false);

            me.getSettings();
            Ext.fireEvent('resetfields', v);
        }, function(ex) {
            if(!Util.isDestroyed(v, vm)){
                vm.set('panel.saveDisabled', true);
                v.setLoading(false);
            }
            Util.handleException(ex);
        });
    },

    checkGoogleDrive: function () {
        var vm = this.getViewModel();

        Ext.Deferred.sequence([
            Rpc.asyncPromise('rpc.UvmContext.googleManager.isGoogleDriveConnected')
        ]).then(function(result){
            if(Util.isDestroyed(vm)){
                return;
            }
            vm.set('googleDriveConfigured', result[0]);
        }, function(ex) {
            Util.handleException(ex);
        });
    },

    reportTypeRenderer: function (value) {
        switch (value) {
            case 'TEXT': return 'Text'.t();
            case 'TIME_GRAPH': return 'Time Graph'.t();
            case 'TIME_GRAPH_DYNAMIC': return 'Time Graph Dynamic'.t();
            case 'PIE_GRAPH': return 'Pie Graph'.t();
            case 'EVENT_LIST': return 'Event List'.t();
        }
    },

    isDisabledCategory: function (view, rowIndex, colIndex, item, record) {
        if (!Ext.getStore('categories').findRecord('displayName', record.get('category'))) {
            return true;
        }
        return false;
    },

    configureGoogleDrive: function () {
        Ung.app.redirectTo('#config/administration/google');
    },

    handleDeleteReports: function () {
        var me = this, v = me.getView(), vm = me.getViewModel();

        Ext.Msg.show({
            title: 'Delete All Reports Data!'.t(),
            msg: "You are about to delete all current reports data".t() + "<br/><br/>" + "Do you want to continue?".t(),
            buttons: Ext.Msg.YESNO,
            fn: function(btnId) {
                if (btnId === 'yes') {
                    Ext.MessageBox.wait( "Deleting reports data...".t(), "Delete Reports Data".t());
                    Ext.Deferred.sequence([
                        Rpc.asyncPromise('rpc.reportsManager.reinitializeDatabase'),
                    ]).then(function(result){
                        if(Util.isDestroyed(v, vm)){
                            return;
                        }
                        Ext.MessageBox.close();
                        return;
                    }, function(ex) {
                        Ext.MessageBox.close();
                        Util.handleException(ex);
                    });
                }
                else {
                    return;
                }
            },
            animEl: 'elId',
            icon: Ext.MessageBox.QUESTION
        });
    },

    onUpload: function (btn) {
        var formPanel = btn.up('form');
        formPanel.submit({
            waitMsg: 'Please wait while data is imported...'.t(),
            success: function () {
                if(!Util.isDestroyed(formpanel)){
                    formPanel.down('filefield').reset();
                }
                // Ext.MessageBox.alert('Succeeded'.t(), 'Upload Data Succeeded'.t());
                Util.successToast('Upload Data Succeeded'.t());
            },
            failure: function (form, action) {
                // var errorMsg = 'Upload Data Failed'.t() + ' ' + action.result;
                // Ext.MessageBox.alert('Failed'.t(), errorMsg);
                Util.handleException('Upload Data Failed'.t() + ' ' + action.result);
            }
        });
    },

});

Ext.define('Ung.apps.reports.cmp.EmailTemplatesGridController', {
    extend: 'Ung.cmp.GridController',

    alias: 'controller.unreportsemailtemplatesgrid',

    reportRenderer: function( value, metaData ){
        var me = this,
            vm = me.getViewModel(),
            reportNames = [],
            allAdded = false,
            typeAdded = [],
            reportEntries = vm.get('settings').reportEntries.list;

        value.list.forEach( function( reportId ){
            if( reportId == '_recommended' ){
                reportNames.push( 'Recommended'.t() );
            }else{
                reportEntries.forEach( function( reportEntry ){
                    if( reportEntry.uniqueId == reportId ){
                        reportNames.push( reportEntry.title );

                    }
                });
            }
        });

        if(reportNames.length == 0){
            reportNames.push( 'None'.t() );
        }
        value = reportNames.join(', ');
        metaData.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( value ) + '"';

        return value;
    },

    editorTitleChange: function( control, newValue, oldValue, eOpts, record ){
        var me = this,
            v = me.getView(),
            vm = me.getViewModel(),
            templates = vm.get('settings.emailTemplates.list');

        var currentRecord = (record === undefined) ? v.getSelectionModel().getSelection()[0] : record;
        var conflict = false;
        templates.forEach( function(template){
            if( template.templateId == currentRecord.get('templateId')){
                return;
            }
            if( template.title == newValue){
                conflict = true;
            }
        });
        if( conflict ){
            control.setValidation("Another Email Template has this title".t());
            return false;
        }
        control.setValidation(true);
    },

    sendReport: function(unk1, unk2, unk3, event, unk5, record){
        var v = this.getView();
        var dialog = v.add({
            xtype: 'app-reports-sendfixedreport',
            title: 'Send Email Report'.t(),
            record: record
        });
        dialog.setPosition(event.getXY());
        dialog.show();

    },

    sendDisabled: function(view, rowIndex, colIndex, item, record){
        return record.dirty;
    },

    runInterfaceTask: null,
    updateReportQueueSize: function(el){
        var me = this, vm = me.getViewModel();
        var queueSize = vm.get('reportQueueSize');
        if(queueSize > 0){
            var runInterfaceTaskDelay = 5000;
            if(me.runInterfaceTask == null){
                me.runInterfaceTask = new Ext.util.DelayedTask( Ext.bind(function(){
                    if(Util.isDestroyed(me, vm, el)){
                    return;
                    }
                    var queueSize = Rpc.directData(el.up('[itemId=appCard]').appManager, 'getFixedReportQueueSize');
                    vm.set('reportQueueSize', queueSize);
                    if(queueSize){
                        el.setHtml('Reports processing'.t() + ': ' + queueSize);
                        me.runInterfaceTask.delay( runInterfaceTaskDelay );
                        return;
                    }else{
                        el.setHtml('');
                        me.runInterfaceTask = null;
                    }
                }, me) );
                me.runInterfaceTask.delay( 100 );
            }
        }
    },

    statics: {
        intervalRender: function(value, cell, record){
            var renderedValue = Renderer.timeInterval(value);
            if(value == 604800 || value == 1 ){
                renderedValue += ' (' + Renderer.dayOfWeek(record.get('intervalWeekStart')) + ')';
            }
            return renderedValue;
        }
    }
});

Ext.define('Ung.apps.reports.cmp.UsersGridController', {
    extend: 'Ung.cmp.GridController',

    alias: 'controller.unreportsusersgrid',

    emailTemplatesRenderer: function (value) {
        var vm = this.getViewModel(),
            templates = vm.get('settings.emailTemplates.list');

        var titles = [];
        Ext.Array.each(templates, function (template) {
            if(value.list.indexOf(template.templateId) > -1){
                titles.push(template.title);
            }
        });

        return titles.join( ', ' );
    }

});

Ext.define ('Ung.model.EnabledReport', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'javaClass', type: 'string' },
        { name: 'list', type: 'auto' }
    ],
    proxy: {
        autoLoad: true,
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});

Ext.define('Ung.cmp.ReportTemplateSelectController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.unreportemplateselect',

    emailChartTypes: [
        'TEXT',
        'PIE_GRAPH',
        'TIME_GRAPH',
        'TIME_GRAPH_DYNAMIC'
    ],

    control: {
        '#': {
            reconfigure: 'onReconfigure',
            afterrender: 'onAfterRender',
        }
    },

    massageOut: function(){
        var me = this,
            v = this.getView(),
            vm = this.getViewModel();

        var store = v.getStore();
        var emailRecommendedReportIds = vm.get('emailRecommendedReportIds');
        var categories = vm.get(v.group + 'Categories' );

        var recommendedIds = [];
        vm.get('reportEntries').each(function(record ){
            var uniqueId = record.get('uniqueId');
            if( ( emailRecommendedReportIds.indexOf( uniqueId ) > -1 &&
                ( categories.indexOf(record.get('category') ) > -1 ) ) ){
                recommendedIds.push(uniqueId);
            }
        }, this, { filtered: true } );

        var selectedIds = [];
        store.each( function(record){
            selectedIds.push(record.get('uniqueId'));
        });
        var onlyRecommended = ( Ext.Array.intersect(selectedIds, recommendedIds).length == recommendedIds.length ) &&
                              ( Ext.Array.merge(selectedIds, recommendedIds).length == recommendedIds.length );

        if( onlyRecommended ){
            selectedIds = ['_recommended'];
        }

        if( ( Ext.Array.intersect(selectedIds, me.originalValues).length != me.originalValues.length ) ||
            ( Ext.Array.merge(selectedIds, me.originalValues).length != me.originalValues.length ) ){
            /* Only update if fields changed */
            var fieldValue = {
                javaClass: 'java.util.LinkedList',
                list: selectedIds
            };
            var bindPath = v.initialConfig.bind.split('.');
            var fieldName = bindPath[1];
            vm.get('record').set(fieldName, fieldValue);
        }
    },

    onReconfigure: function(){
        var me = this,
            v = me.getView(),
            vm = me.getViewModel();

        var store = v.getStore();

        var recommended = false;
        var uniqueIds = [];
        me.originalValues = [];
        store.each( function( record ) {
            var value = record.get('field1');
            if( value == '_recommended'){
                recommended = true;
            }else{
                uniqueIds.push( value );
            }
            me.originalValues.push( value );
        });

        store.removeAll();

        var emailRecommendedReportIds = vm.get('emailRecommendedReportIds');
        var categories = vm.get(v.group + 'Categories' );
        vm.get('reportEntries').each(function(record ){
            var uniqueId = record.get('uniqueId');
            if( ( recommended &&
                  ( emailRecommendedReportIds.indexOf( uniqueId ) > -1 &&
                    categories.indexOf(record.get('category') ) > -1 ) ) ||
                uniqueIds.indexOf( uniqueId ) > -1 ){
                store.add(record);
            }
        }, this, { filtered: true } );

        v.store.sort([{
            property: 'category',
            direction: 'ASC'
        },{
            property: 'displayOrder',
            direction: 'ASC'
        }]);
    },

    onAfterRender: function(){
        var me = this,
            v = this.getView(),
            vm = this.getViewModel();

        // when record is modified update conditions menu
        this.recordBind = vm.bind({
            bindTo: '{record}',
        }, this.setMenuReports, this);

        var reportEntries = vm.get('reportEntries');
        var fixedReportsAllowGraphs = vm.get('fixedReportsAllowGraphs');
        var categories = vm.get( v.group + 'Categories');

        reportEntries.clearFilter();
        if(reportEntries.getSorters().length == 0){
            reportEntries.sort('category');
        }
        reportEntries.filterBy( function(record){
            if( fixedReportsAllowGraphs == false &&
                record.get('type').indexOf("_GRAPH") != -1){
                /* System doesn't allow graphs */
                return false;
            }

            if( me.emailChartTypes.indexOf( record.get('type') ) == -1 ){
                return false;
            }

            if( categories.indexOf( record.get('category') ) == -1 ){
                return false;
            }

            return true;
        });

        var categoryMenu = {};
        reportEntries.each( function(record){
            var category = record.get('category');
            if( !categoryMenu[category] ){
                categoryMenu[category] = {
                    showSeparator: false,
                    plain: true,
                    items: [],
                    mouseLeaveDelay: 0,
                    listeners: {
                        click: 'addReport'
                    }
                };
            }
            categoryMenu[category].items.push({
                text: record.get('title'),
                value: record.get('uniqueId'),
                tooltip: me.getTooltip( record )
            });
        });
        var menu = [];
        for( var category in categoryMenu ){
            menu.push({
                text: category,
                menu: categoryMenu[category]
            });
        }

        v.down('#addReportBtn').setMenu({
            showSeparator: false,
            plain: true,
            items: menu,
            mouseLeaveDelay: 0,
            listeners: {
                click: 'addReport'
            }
        });
    },

    addReport: function( menu, item ){
        var me = this,
            v = me.getView(),
            vm = me.getViewModel();

        if(item){
            vm.get('reportEntries').each(function( record ){
                if( record.get('uniqueId') == item.value ){
                    v.getStore().add( record );
                }
            }, this, { filtered: true } );
            this.setMenuReports();
        }
    },

    /**
     * Removes a condition from the rule
     */
    removeReport: function (view, rowIndex, colIndex, item, e, record) {
        this.getView().getStore().remove( record );
        this.setMenuReports();
    },

    /**
     * Updates the disabled/enabled status of the conditions in the menu
     */
    setMenuReports: function () {
        var v = this.getView(),
            menu = v.down('#addReportBtn').getMenu(),
            store = v.getStore();

        menu.items.each(function (item) {
            if(item.menu){
                item.menu.items.each(function (subitem) {
                    subitem.setDisabled(store.findRecord('uniqueId', subitem.value) ? true : false);
                });
            }else{
                item.setDisabled(store.findRecord('uniqueId', item.value) ? true : false);
            }
        });
    },

    getTooltip: function(record){
        var description = [];
        description.push( 'Description'.t() + ': ' + record.get('description') );
        description.push( 'Type'.t() + ': ' + this.getView().up('app-reports').getController().reportTypeRenderer( record.get('type') ) );
        description.push( 'Units'.t() + ': ' + record.get('units') );
        description.push( 'Display Order'.t() + ': ' + record.get('displayOrder') );
        return description.join( "<br>" );
    },

    categoryRenderer: function( value, metaData, record ){
        metaData.tdAttr = 'data-qtip="' + this.getTooltip( record ) + '"';
        return record.get('category');
    },

    titleRenderer: function( value, metaData, record ){
        metaData.tdAttr = 'data-qtip="' + this.getTooltip( record ) + '"';
        return record.get('title');
    },

    typeRenderer: function( value, metaData, record ){
        metaData.tdAttr = 'data-qtip="' + this.getTooltip( record ) + '"';
        return this.getView().up('app-reports').getController().reportTypeRenderer( record.get('type') );
    }

});


Ext.define('Ung.cmp.ReportTemplateSelect', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.unreporttemplateselect',

    controller: 'unreportemplateselect',

    actions: {
        addReport: {
            itemId: 'addReportBtn',
            text: 'Add Report'.t(),
            iconCls: 'fa fa-plus'
        }
    },

    trackMouseOver: false,
    disableSelection: true,
    sortableColumns: false,
    enableColumnHide: false,
    padding: '10 0',
    tbar: ['@addReport'],

    columns: [{
        header: 'Category'.t(),
        menuDisabled: true,
        align: 'right',
        flex: 1,
        renderer: 'categoryRenderer'
    }, {
        header: 'Title'.t(),
        menuDisabled: true,
        align: 'right',
        flex: 1,
        renderer: 'titleRenderer'
    }, {
        header: 'Type'.t(),
        menuDisabled: true,
        align: 'right',
        flex: 1,
        renderer: 'typeRenderer'
    }, {
        xtype: 'actioncolumn',
        menuDisabled: true,
        sortable: false,
        width: 30,
        align: 'center',
        iconCls: 'fa fa-minus-circle fa-red',
        tdCls: 'action-cell-cond',
        handler: 'removeReport'
    }],

    massageOut: function(){
        return this.getController().massageOut();
    }

});

Ext.define('Ung.apps.reports.cmp.EmailTemplatesRecordEditor', {
    extend: 'Ung.cmp.RecordEditor',
    xtype: 'ung.cmp.unemailtemplatesrecordeditor',

    controller: 'unemailtemplatesrecordeditorcontroller'

});

Ext.define('Ung.apps.reports.cmp.EmailTemplatesRecordEditorController', {
    extend: 'Ung.cmp.RecordEditorController',
    alias: 'controller.unemailtemplatesrecordeditorcontroller',

    onApply: function () {
        var me = this,
            v = me.getView(),
            vm = me.getViewModel();

        v.query('unreporttemplateselect').forEach( function( selector ){
            selector.massageOut();
        });

        if (!this.action) {
            for (var fieldName in vm.get('record').modified) {
                v.record.set(fieldName, vm.get('record').get(fieldName));
            }
        }
        if (this.action === 'add') {
            this.mainGrid.getStore().add(v.record);
        }
        v.close();
    },

    editorTitleChange: function( me, newValue, oldValue, eOpts ){
        var vm = this.getViewModel();

        return this.getView().up('grid').getController().editorTitleChange( me, newValue, oldValue, eOpts, vm.get('record') );
    }

});

Ext.define('Ung.cmp.EmailTemplateSelectController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.unemailtemplateselect',

    control: {
        '#': {
            afterrender: 'onAfterRender',
        }
    },

    onAfterRender: function(){
        var v = this.getView(),
            vm = this.getViewModel();

        this.recordBind = vm.bind({
            bindTo: '{record}',
        }, this.setMenuTemplates, this);

        var emailTemplates = vm.get('emailTemplates');

        var menu = [];
        emailTemplates.each( function(record){
            menu.push({
                text: record.get('title'),
                value: record.get('templateId'),
            });
        });

        v.down('#addTemplateBtn').setMenu({
            showSeparator: false,
            plain: true,
            items: menu,
            mouseLeaveDelay: 0,
            listeners: {
                click: 'addTemplate'
            }
        });
    },

    addTemplate: function( menu, item ){
        var me = this,
            v = me.getView(),
            vm = me.getViewModel();

        if(item){
            vm.get('emailTemplates').each(function( record ){
                if( record.get('templateId') == item.value ){
                    v.getStore().add( {
                        field1: item.value
                    } );
                }
            }, this, { filtered: true } );
            this.setMenuTemplates();
        }
    },

    /**
     * Removes a condition from the rule
     */
    removeReport: function (view, rowIndex, colIndex, item, e, record) {
        this.getView().getStore().remove( record );
        this.setMenuTemplates();
    },

    /**
     * Updates the disabled/enabled status of the conditions in the menu
     */
    setMenuTemplates: function () {
        var v = this.getView(),
            vm = this.getViewModel(),
            menu = v.down('#addTemplateBtn').getMenu(),
            store = v.getStore();

        menu.items.each(function (item) {
            item.setDisabled(store.findRecord('field1', item.value) ? true : false);
        });

        var ids = [];
        store.each( function(record){
            ids.push( record.get('field1'));
        });
        var fieldValue = {
            javaClass: 'java.util.LinkedList',
            list: ids
        };
        var bindPath = v.initialConfig.bind.store.split('.');
        var fieldName = bindPath[1];
        vm.get('record').set(fieldName, fieldValue);

    },

    getTooltip: function(record){
        var vm = this.getViewModel(),
            emailTemplates = vm.get('emailTemplates');

        var emailTemplate = emailTemplates.findRecord('templateId', record.get('field1') );

        var description = [];
        description.push( 'Description'.t() + ': ' + emailTemplate.get('description') );
        return description.join( "<br>" );
    },

    templateRenderer: function( value, metaData, record ){
        var me = this,
            vm = me.getViewModel(),
            emailTemplates = vm.get('emailTemplates');

        metaData.tdAttr = 'data-qtip="' + this.getTooltip( record ) + '"';

        value = record.get('field1');
        var emailTemplate = emailTemplates.findRecord('templateId', value );

        return emailTemplate ? emailTemplate.get('title') : value;
    }
});


Ext.define('Ung.cmp.EmailTemplateSelect', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.unemailtemplateselect',

    controller: 'unemailtemplateselect',

    actions: {
        addTemplate: {
            itemId: 'addTemplateBtn',
            text: 'Add Email Template'.t(),
            iconCls: 'fa fa-plus'
        }
    },

    trackMouseOver: false,
    disableSelection: true,
    sortableColumns: false,
    enableColumnHide: false,
    padding: '10 0',
    tbar: ['@addTemplate'],

    columns: [{
        header: 'Email Template'.t(),
        menuDisabled: true,
        align: 'right',
        flex: 1,
        renderer: 'templateRenderer'
    }, {
        xtype: 'actioncolumn',
        menuDisabled: true,
        sortable: false,
        width: 30,
        align: 'center',
        iconCls: 'fa fa-minus-circle fa-red',
        tdCls: 'action-cell-cond',
        handler: 'removeReport'
    }],

});
Ext.define('Ung.apps.reports.view.SendFixedReport', {
    extend: 'Ext.window.Window',
    alias: 'widget.app-reports-sendfixedreport',
    renderTo: Ext.getBody(),
    constrain: true,

    scrollable: true,

    onEsc: Ext.emptyFn,
    closable: false,
    modal: true,

    controller: 'app-reports-sendfixedreport',

    viewModel:{
        data: {
            minDate: null,
            maxDate: null
        }
    },
    
    defaults: {
        bodyStyle: {
            background: 'transparent'
        },
        border: false,
    },

    items: [{
        xtype: 'panel',
        bodyStyle: {
            background: 'transparent'
        },
        border: false,
        items:[{
            xtype: 'container',
            layout: { 
                type: 'hbox', 
                align: 'stretch', 
                pack: 'end' 
            },
            border: false,
            items:[{
                xtype: 'container',
                border: false,
                items: [{               
                    xtype: 'toolbar',
                    docked: 'top',
                    height: 24,
                    style: { background: 'transparent' },
                    border: false,
                    items: [{
                        xtype: 'component',
                        html: '<strong>' + 'Since'.t() + '</strong>'
                    }]
                },{
                    xtype: 'datepicker',
                    itemId: 'startDate',
                    showToday: false,
                    listeners: {
                        select: 'datepickerselect',
                    },
                    bind:{
                        minDate: '{minDate}',
                        maxDate: '{maxDate}',
                        // disabledDates: '{startDisabledDates}',
                        // value: '{startDate}'
                    }
                }]
            },{
                xtype: 'container',
                border: false,
                disabled: true,
                hidden: true,
                bind:{
                    disabled: '{disableStopDate}',
                    hidden: '{disableStopDate}',
                },
                items: [{               
                    xtype: 'toolbar',
                    docked: 'top',
                    height: 24,
                    style: { background: 'transparent' },
                    border: false,
                    items: [{
                        xtype: 'component',
                        html: '<strong>' + 'Until'.t() + '</strong>'
                    }]
                },{     
                    xtype: 'datepicker',
                    itemId: 'stopDate',
                    showToday: false,
                    bind:{
                        minDate: '{minDate}',
                        maxDate: '{maxDate}'                    }
                }]
            }]
        }]
    }],

    buttons: [{
        text: 'Cancel'.t(),
        iconCls: 'fa fa-ban',
        handler: 'closeWindow'
    },{
        text: 'Send'.t(),
        iconCls: 'fa fa-envelope',
        handler: 'send'
    }],

    listeners: {
        afterrender: function(el){
            var vm = el.getViewModel();
            var record = el.record;

            vm.set( 'title', record.get('title') );
            vm.set( 'interval', Ung.apps.reports.cmp.EmailTemplatesGridController.intervalRender( record.get('interval'), null, record ) );
        }
    }

});
Ext.define('Ung.apps.reports.SendFixedReportController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.app-reports-sendfixedreport',

    control: {
        '#': {
            afterrender: 'afterrender'
        }
    },

    afterrender: function(view){
        var vm = this.getViewModel();

        var record = view.record;
        var dbRetention = view.up('[itemId=appCard]').getViewModel().get('settings.dbRetention');
        var intervalWeekStart = record.get('intervalWeekStart');

        var interval = record.get('interval');

        var showStopDate = interval <= 2;
        vm.set('disableStopDate', !showStopDate);

        var maxDate = new Date(Util.getMilliseconds());
        maxDate.setHours(0,0,0,0);
        var maxYear = maxDate.getFullYear();
        var maxMonth = maxDate.getMonth();
        var maxDateOfWeek = maxDate.getDay();

        var minDate = new Date(Util.getMilliseconds() - (86400000 * dbRetention) );
        minDate.setHours(0,0,0,0);
        var minYear = minDate.getFullYear();
        var minMonth = minDate.getMonth();
        var minDateOfWeek = minDate.getDay();

        var startDateValue = Util.serverToClientDate(maxDate);
        var stopDateValue = Util.serverToClientDate(maxDate);

        var startDateDisabledDates = [];
        var stopDateDisabledDates = [];

        var disabledDate = null;
        var disabledMonth = null;

        switch(interval){
            case 2419200:
            case 2:
                minDate = new Date(minYear, minMonth, 1);
                if(interval == 2419200){
                    startDateValue = new Date(maxYear, maxMonth > 0 ? maxMonth - 1 : 11, 1);
                    maxDate = new Date(startDateValue.getTime());
                }else{
                    startDateValue = new Date(maxYear, maxMonth, 1);
                }
                vm.set('minDate', minDate);
                vm.set('maxDate', maxDate);

                startDateDisabledDates = this.getMonthDisabledDates();

                if(interval == 2){
                    stopDateDisabledDates = this.getMonthDisabledDates(startDateValue);
                }
                break;

            case 604800:
            case 1:
                minDate.setHours( -24 * ( minDateOfWeek  - intervalWeekStart));

                startDateValue = new Date(maxDate.getTime());
                startDateValue.setHours( -24 * ( maxDateOfWeek  - intervalWeekStart));
                
                if(interval == 604800 || maxDateOfWeek < intervalWeekStart){
                    startDateValue.setHours(-24 * 7);
                    stopDateValue = new Date( startDateValue.getTime());
                    stopDateValue.setHours(24 * 7);
                }else{
                    stopDateValue = new Date(maxDate.getTime());
                }

                if(interval == 604800){
                    maxDate = new Date( startDateValue.getTime() );
                }
                vm.set('minDate', minDate);
                vm.set('maxDate', maxDate);

                startDateDisabledDates = this.getWeekDisabledDates();
                if(interval == 1){
                    stopDateDisabledDates = this.getWeekDisabledDates(startDateValue);
                }
                break;
            default:
                vm.set('minDate', minDate);
                vm.set('maxDate', maxDate);
        }
        var startDate = view.down('[itemId=startDate]');
        var stopDate = view.down('[itemId=stopDate]');

        if(startDateDisabledDates.length){
            startDate.setDisabledDates(startDateDisabledDates);
        }
        startDate.setValue(startDateValue);
        startDate.todayCls = '';

        if(stopDateDisabledDates.length){
            stopDate.setDisabledDates(stopDateDisabledDates);
        }
        stopDate.setValue(stopDateValue);
        stopDate.todayCls = '';

    },

    getMonthDisabledDates: function(startDay){
        var vm = this.getViewModel();
        var minDate = vm.get('minDate');
        var maxDate = vm.get('maxDate');

        var disabledDates = [];
        var disabledDate = new Date(minDate.getTime());
        var disabledMonth = disabledDate.getMonth();
        while(disabledDate < maxDate){
            if( typeof(startDay) !== 'undefined' ){
                if( startDay.getTime() != disabledDate.getTime()){
                    disabledDates.push( (disabledDate.getMonth() + 1) + '/[0-3][0-9]/' + disabledDate.getFullYear() );
                }else{
                    disabledDates.push( (disabledDate.getMonth() + 1) + '/01/' + disabledDate.getFullYear() );                    
                }
            }else{
                disabledDates.push( (disabledDate.getMonth() + 1) + '/[1-3][0-9]/' + disabledDate.getFullYear() );
                disabledDates.push( (disabledDate.getMonth() + 1) + '/[0][2-9]/' + disabledDate.getFullYear() );
            }
            disabledMonth++;
            if(disabledMonth == 12){
                disabledMonth = 0;
                disabledDate.setYear(disabledDate.getYear());
            }
            disabledDate.setMonth(disabledMonth);
        }

        return disabledDates;
    },

    getWeekDisabledDates: function(startDay){
        var vm = this.getViewModel();
        var minDate = vm.get('minDate');
        var maxDate = vm.get('maxDate');

        var disabledDates = [];
        var disabledDate = new Date(minDate.getTime());
        var i;
        var day;
        while(disabledDate <= maxDate){
            if( typeof(startDay) !== 'undefined' ){
                if( ( disabledDate.getTime() < ( startDay.getTime() + 86400000 ) ||
                    disabledDate.getTime() > ( startDay.getTime() + ( 86400000 * 7 ) ) ) ){
                    day = disabledDate.getDate();
                    disabledDates.push( (disabledDate.getMonth() + 1) + '/' + ( day < 10 ? '0' : '')  + day  + '/' + disabledDate.getFullYear() );
                }
            }else{
                for( i = 0; i < 6; i++){
                    disabledDate.setHours(24);
                    day = disabledDate.getDate();
                    disabledDates.push( (disabledDate.getMonth() + 1) + '/' + ( day < 10 ? '0' : '')  + day  + '/' + disabledDate.getFullYear() );
                }
            }
            disabledDate.setHours(24);
        }
        return disabledDates;
    },

    datepickerselect: function(el, startDate){
        var vm = el.up('window').getViewModel();
        var record = el.up('window').record;
        var interval = record.get('interval');
        var intervalWeekStart = record.get('intervalWeekStart');
        var stopDate = el.up('window').down('[itemId=stopDate]');
        var startDateValue = el.up('window').down('[itemId=startDate]').getValue();
        var maxDate = vm.get('maxDate');

        var stopDateValue = startDateValue;
        if(interval == 1){
            stopDate.setDisabledDates(this.getWeekDisabledDates(startDate));
            var maxDateOfWeek = maxDate.getDay();
            if( ( startDateValue.getTime() + ( 86400000 * 7) < maxDate.getTime() ) ||
                ( maxDateOfWeek < intervalWeekStart) ){
                stopDateValue = new Date( startDateValue.getTime());
                stopDateValue.setHours(24 * 7);
            }else{
                stopDateValue = new Date(maxDate.getTime());
            }
        }else if(interval === 2){
            stopDate.setDisabledDates(this.getMonthDisabledDates(startDate));
            var month = stopDate.getMonth();
            stopDateValue.setMonth( month == 0 ? 11 : month - 1);
            stopDateValue.setDay(-24);
        }
        stopDate.setValue(stopDateValue);
    },

    closeWindow: function (button) {
        button.up('window').close();
    },

    send: function (button) {
        var startDate = button.up('window').down('[itemId=startDate]').getValue().getTime(),
            stopDate = button.up('window').down('[itemId=stopDate]').getValue().getTime(),
            templateId = button.up('window').record.get('templateId');

        var dialog = button.up('window');
        dialog.setLoading(true);
        var app = button.up('window').up('[itemId=appCard]');
        Ext.Deferred.sequence([
            Rpc.asyncPromise(app.appManager, 'runFixedReport', templateId, startDate, stopDate),
            Rpc.asyncPromise(app.appManager, 'getFixedReportQueueSize')
        ]).then(function(result){
            if(Util.isDestroyed(button, dialog)){
                return;
            }
            app.getViewModel().set('reportQueueSize', result[1]);
            button.up('window').up('[itemId=email-templates]').getController().updateReportQueueSize(button.up('window').up('[itemId=email-templates]').down('[itemId=reportQueueSize]'));
            button.up('window').close();
        }, function(ex) {
            Ext.MessageBox.close();
            Util.handleException(ex);
            if(Util.isDestroyed(button)){
                return;
            }
            button.up('window').close();
        });
    }
});
Ext.define('Ung.apps.reports.view.AllReports', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.app-reports-allreports',
    itemId: 'all-reports',
    title: 'All Reports'.t(),
    scrollable: true,
    withValidation: false,
    store: 'reports',

    features: [{
        ftype: 'grouping',
        // groupHeaderTpl: 'Category: {category}'
        // startCollapsed: true
    }],

    columns: [{
        header: 'Title'.t(),
        width: 300,
        dataIndex: 'title',
        renderer: function (value, meta, record) {
            return '<i class="fa ' + record.get('icon') + ' fa-gray"></i> ' + record.get('localizedTitle');
        }
    }, {
        header: 'Type'.t(),
        width: 150,
        dataIndex: 'type',
        renderer: 'reportTypeRenderer'
    }, {
        header: 'Description'.t(),
        flex: 1,
        dataIndex: 'description',
        renderer: function (value, meta, record) {
            return record.get('localizedDescription');
        }
    }, {
        header: 'Units'.t(),
        width: 90,
        dataIndex: 'units'
    }, {
        header: 'Display Order'.t(),
        width: 90,
        dataIndex: 'displayOrder'
    }, {
        header: 'View'.t(),
        menuText: 'View'.t(),
        xtype: 'actioncolumn',
        width: 70,
        align: 'center',
        iconCls: 'fa fa-external-link-square',
        isDisabled: 'isDisabledCategory',
        handler: function (view, rowIndex, colIndex, item, e, record) {
            Ung.app.redirectTo('#reports?' + record.get('url'));
        }
    }]

});
Ext.define('Ung.apps.reports.view.Data', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-reports-data',
    itemId: 'data',
    title: 'Data'.t(),
    scrollable: true,
    withValidation: true,
    defaults: {
        xtype: 'fieldset',
        padding: 10,
        margin: 10
    },
    items: [{
        title: 'Data Retention'.t(),
        labelWidth: 150,
        items: [{
            xtype: 'component',
            margin: '0 0 5 0',
            html: 'Keep event data for this number of days or hours. The smaller the number the lower the disk space requirements.'.t()
        },{
            xtype: 'radiogroup',
            name: 'dbRetentionRb',
            bind: {
                value: '{dbRetentionInDays}'
            },
            simpleValue: true,
            layout: 'hbox',
            items: [{
                boxLabel: 'Days',
                inputValue: true,
                width: 70,
            }, {
                boxLabel: 'Hours',
                inputValue: false,
                width: 70,
            }]
        },{
            xtype: 'numberfield',
            bind: {
                value: '{settings.dbRetention}',
                hidden: '{!dbRetentionInDays}'
            },
            id: 'dbRetentionDailyValue',
            width: 200,
            allowDecimals: false,
            minValue: 1,
            maxValue: 366,
            allowBlank: false,
            fieldLabel: "Days".t(),
        },{
            xtype: 'numberfield',
            bind: {
                value: '{settings.dbRetentionHourly}',
                hidden: '{dbRetentionInDays}'
            },
            id: 'dbRetentionHourlyValue',
            width: 200,
            allowDecimals: false,
            minValue: 1,
            maxValue: 23,
            allowBlank: false,
            fieldLabel: "Hours".t(),
        },{
            xtype: 'button',
            text: 'Delete All Reports Data'.t(),
            margin: '10 0 10 0',
            handler: 'handleDeleteReports'
        }]
    },{
        title: 'Google Drive Backup'.t(),
        labelWidth: 150,
        items: [{
             xtype: 'container',
             margin: '5 0 15 0',
             html: 'If enabled, Configuration Backup uploads reports data backup files to Google Drive.'.t()
         }, {
             xtype: 'component',
             bind: {
                 html: '{driveConfiguredText}',
                 style: { color: '{googleDriveConfigured ? "green" : "red"}'}
             }
         }, {
             xtype: 'button',
             text: 'Configure Google Drive'.t(),
             margin: '10 0 15 0',
             handler: 'configureGoogleDrive'
         }, {
             xtype: 'checkbox',
             boxLabel: 'Upload Data to Google Drive'.t(),
             disabled: true,
             bind: {
                 value: '{settings.googleDriveUploadData}',
                 disabled: '{!googleDriveConfigured}'
             },
             listeners: {
                 render: function(obj) {
                     obj.getEl().set({'data-qtip': 'If enabled and configured Configuration Backup will upload backups to google drive.'.t()});
                 }
             }
         }, {
             xtype: 'checkbox',
             boxLabel: 'Upload CSVs to Google Drive'.t(),
             disabled: true,
             bind: {
                 value: '{settings.googleDriveUploadCsv}',
                 disabled: '{!googleDriveConfigured}'
             },
             listeners: {
                 render: function(obj) {
                     obj.getEl().set({'data-qtip': 'If enabled and configured Configuration Backup will upload backups to google drive.'.t()});
                 }
             }
         }, {
            xtype: 'fieldset',
            disabled: true,
            hidden: true,
            bind: {
                disabled: '{!googleDriveConfigured}',
                hidden: '{!googleDriveConfigured}'
            },
            layout: {
                type: 'hbox'
            },
            items: [{
                xtype: 'displayfield',
                margin: '10 0 10 10',
                fieldLabel: 'Google Drive Directory',
                labelWidth: 150,
                renderer: function() {
                    var rootDirectory = Rpc.directData('rpc.UvmContext.googleManager.getAppSpecificGoogleDrivePath', null);
                    if (!rootDirectory || rootDirectory.trim() === '')
                        return '';
                    return Ext.String.format('<strong><span class="cond-val">{0}</span></strong>', rootDirectory + " /");
                }
            },{
                xtype: 'textfield',
                margin: '10 10 10 0',
                regex: /^[\w\. \/]+$/,
                regexText: "The field can have only alphanumerics, spaces, or periods.".t(),
                bind: '{settings.googleDriveDirectory}',
                width: 200,
                emptyText: 'Enter folder name',
                autoEl: {
                    tag: 'div',
                    'data-qtip': "The destination directory in google drive.".t()
                }
            }]
        }
    ]
    }, {
        title: 'Import / Restore Data Backup Files'.t(),
        labelWidth: 150,
        items: [{
            xtype: 'form',
            url: 'upload',
            border: false,
            items: [{
                xtype: 'filefield',
                fieldLabel: 'File'.t(),
                name: 'uploadDataFile',
                width: 500,
                labelWidth: 50,
                validateOnBlur: false
            }, {
                xtype: 'button',
                text: 'Upload'.t(),
                formBind: true,
                handler: 'onUpload'
            }, {
                xtype: 'hidden',
                name: 'type',
                value: 'reportsDataRestore'
            }]
        }]
    }, {
        // fix isExpertMode
        title: 'Data'.t(),
        hidden: !Rpc.directData('rpc.isExpertMode'),
        items: [{
            xtype: 'textfield',
            fieldLabel: 'Host'.t(),
            width: 300,
            bind: '{settings.dbHost}',
            allowBlank: false,
            blankText: 'A Host must be specified.'.t()
        }, {
            xtype: 'numberfield',
            fieldLabel: 'Port'.t(),
            width: 200,
            bind: '{settings.dbPort}',
            allowDecimals: false,
            minValue: 0,
            allowBlank: false,
            blankText: 'You must provide a valid port.'.t(),
            vtype: 'port'
        }, {
            xtype: 'textfield',
            fieldLabel: 'User'.t(),
            width: 300,
            bind: '{settings.dbUser}',
            allowBlank: false,
            blankText: 'A User must be specified.'.t()
        }, {
            xtype: 'textfield',
            fieldLabel: 'Password'.t(),
            inputType: 'password',
            width: 300,
            bind: '{settings.dbPassword}',
            allowBlank: false,
            blankText: 'A Password must be specified.'.t()
        }, {
            xtype: 'textfield',
            fieldLabel: 'Name'.t(),
            width: 300,
            bind: '{settings.dbName}',
            allowBlank: false,
            blankText: 'A Name must be specified.'.t()
        }]
    }],
});
Ext.define('Ung.apps.reports.view.EmailTemplates', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-reports-emailtemplates',
    itemId: 'email-templates',
    title: 'Email Templates'.t(),
    withValidation: false,
    controller: 'unreportsemailtemplatesgrid',

    tbar: ['@add', '->', { 
        xtype: 'tbtext',
        itemId: 'reportQueueSize',
        listeners: {
            afterrender: 'updateReportQueueSize'
        }
    },'@import', '@export'],
    recordActions: ['edit', 'copy', 'delete'],
    copyId: 'templateId',
    copyAppendField: 'title',

    emptyRow: {
        javaClass: 'com.untangle.app.reports.EmailTemplate',
        title: '',
        description: '',
        interval: 86400,
        intervalWeekStart: 0,
        mobile: false,
        enabledConfigIds : {
            "javaClass": "java.util.LinkedList",
            "list": ['_recommended']
        },
        enabledAppIds : {
            "javaClass": "java.util.LinkedList",
            "list": ['_recommended']
        },
    },

    bind: '{emailTemplates}',

    emptyText: 'No Email Templates Defined'.t(),
    
    listProperty: 'settings.emailTemplates.list',

    importValidationJavaClass: true,
    importValidationForComboBox: true,
    importDirectComboValues: ["interval", "intervalWeekStart" ],
    checkIfAlreadyPresent: {"title" : "emailTemplates"},

    extraColumnConfig: {
        readOnly: { xtype: 'checkbox' },
        templateId: { xtype: 'numberfield' },
    },

    columns: [{
        header: 'Id'.t(),
        width: Renderer.idWidth,
        dataIndex: 'templateId',
        renderer: Renderer.id
    }, {
        header: 'Title'.t(),
        dataIndex: 'title',
        width: Renderer.messageWidth,
        flex: 1,
        editor: {
            xtype: 'textfield',
            emptyText: '[no title]'.t(),
            allowBlank: false,
            blankText: 'The title cannot be blank.'.t(),
            listeners: {
                change: 'editorTitleChange'
            }
        }
    }, {
        header: 'Description'.t(),
        width: Renderer.messageWidth,
        dataIndex: 'description',
        flex: 1,
        editor: {
            xtype:'textfield',
            emptyText: '[no description]'.t(),
            allowBlank: false,
            blankText: 'The description cannot be blank.'.t()
        },
    }, {
        header: 'Interval'.t(),
        width: Renderer.intervalWidth + 55,
        dataIndex: 'interval',
        renderer: Ung.apps.reports.cmp.EmailTemplatesGridController.intervalRender,
        editor: {
            xtype: 'combo',
            editable: false,
            queryMode: 'local',
            bind: {
                store: '{emailIntervals}'
            }
        }
    }, {
        header: 'Mobile'.t(),
        width: Renderer.booleanWidth,
        dataIndex: 'mobile',
        renderer: Renderer.boolean,
        editor: {
            xtype: 'checkbox',
            bind: '{record.mobile}'
        }
    }, {
        header: 'Config'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'enabledConfigIds',
        renderer: 'reportRenderer'
    }, {
        header: 'Apps'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'enabledAppIds',
        renderer: 'reportRenderer'
    }, {
        xtype: 'actioncolumn',
        header: 'Send'.t(),
        width: Renderer.actionWidth,
        iconCls: 'fa fa-envelope',
        align: 'center',
        handler: 'sendReport',
        isDisabled: 'sendDisabled'
    }],

    editorXtype: 'ung.cmp.unemailtemplatesrecordeditor',
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.title}',
        fieldLabel: 'Title'.t(),
        emptyText: '[no title]'.t(),
        width: 500,
        listeners: {
            change: 'editorTitleChange'
        }
    },{
        xtype: 'textfield',
        bind: '{record.description}',
        fieldLabel: 'Description'.t(),
        emptyText: '[no description]'.t(),
        width: 500
    },{
        xtype: 'container',
        layout: 'hbox',
        defaults: {
            anchor: '100%',
            labelWidth: 180,
            labelAlign : 'right',
        },
        items: [{
            xtype: 'combo',
            editable: false,
            fieldLabel: 'Interval'.t(),
            queryMode: 'local',
            bind: {
                value: '{record.interval}',
                store: '{emailIntervals}'
            }
        },{
            xtype: 'combo',
            editable: false,
            fieldLabel: 'Start of week'.t(),
            queryMode: 'local',
            hidden: true,
            disabled: true,
            bind: {
                value: '{record.intervalWeekStart}',
                store: '{dayOfWeekList}',
                hidden: '{record.interval != 604800 && record.interval != 1}',
                disabled: '{record.interval != 604800 && record.interval != 1}'
            }
        }]
    },{
        xtype: 'checkbox',
        editable: false,
        fieldLabel: 'Mobile'.t(),
        bind: '{record.mobile}'
    },{
        xtype: 'unreporttemplateselect',
        title: 'Config'.t(),
        group: 'config',
        bind: '{record.enabledConfigIds.list}'
    },{
        xtype: 'unreporttemplateselect',
        title: 'Apps'.t(),
        group: 'app',
        bind: '{record.enabledAppIds.list}'
    }]
});
Ext.define('Ung.apps.reports.view.NameMap', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-reports-namemap',
    itemId: 'name-map',
    title: 'Name Map'.t(),
    withValidation: false,
    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['edit', 'delete'],

    listProperty: 'settings.hostnameMap.list',
    emptyRow: {
        address: '1.2.3.4',
        hostname: '',
        javaClass: 'com.untangle.app.reports.ReportsHostnameMapEntry',
    },

    emptyText: 'No Names Defined'.t(),

    bind: '{hostnames}',

    columns: [{
        header: 'IP Address'.t(),
        width: Renderer.ipWidth,
        dataIndex: 'address',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter IP address]'.t(),
            allowBlank: false,
            vtype: 'ipAddress'
        }
    }, {
        header: 'Name'.t(),
        width: Renderer.usernameWidth,
        flex: 1,
        dataIndex: 'hostname',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter name]'.t(),
            regex: /^[^'"]+$/,
            regexText: 'Quotes and double quotes are not allowed'.t(),
            allowBlank: false
        }
    }],
    editorFields: [{
        xtype: 'textfield',
        bind: '{record.address}',
        fieldLabel: 'IP Address'.t(),
        emptyText: '[enter IP address]'.t(),
        allowBlank: false,
        width: 300,
        vtype: 'ipAddress',
        validator: function (val) {
            if (this.up('grid').getStore().findExact('address', val) >= 0) {
                return 'IP address is already defined in Name Map'.t();
            } else {
                return true;
            }
        }
    }, {
        xtype:'textfield',
        bind: '{record.hostname}',
        fieldLabel: 'Name'.t(),
        emptyText: '[enter name]'.t(),
        regex: /^[^'"]+$/,
        regexText: 'Quotes and double quotes are not allowed'.t(),
        allowBlank: false,
        width: 300
    }]

});
Ext.define('Ung.apps.reports.view.Status', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.app-reports-status',
    itemId: 'status',
    title: 'Status'.t(),
    scrollable: true,
    withValidation: false,
    viewModel: true,

    items: [{
        border: false,
        bodyPadding: 10,
        scrollable: 'y',
        items: [{
            xtype: 'component',
            cls: 'app-desc',
            html: '<img src="/icons/apps/reports.svg" width="80" height="80"/>' +
                '<h3>Reports</h3>' +
                '<p>' + 'Reports records network events to provide administrators the visibility and data necessary to investigate network activity.'.t() + '</p>'
        }, {
            xtype: 'applicense',
            hidden: true,
            bind: {
                hidden: '{!license || !license.trial}'
            }
        }, {
            xtype: 'appstate',
        }, {
            xtype: 'appremove'
        }]
    }]
});
Ext.define('Ung.apps.reports.view.Users', {
    extend: 'Ung.cmp.Grid',
    alias: 'widget.app-reports-users',
    itemId: 'reports-users',
    title: 'Reports Users'.t(),
    withValidation: false,
    controller: 'unreportsusersgrid',

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [{
            xtype: 'tbtext',
            padding: '8 5',
            style: { fontSize: '12px', fontWeight: 600 },
            html: 'Reports Users are users that can view reports and receive email reports but do not have administration privileges.'.t()
        }]
    }, {
        xtype: 'toolbar',
        dock: 'top',
        items: ['@add', '->', '@import', '@export']
    }],

    recordActions: ['changePassword', 'edit', 'delete'],

    listProperty: 'settings.reportsUsers.list',
    emptyRow: {
        emailAddress: '',
        emailSummaries: true,
        emailAlerts: false,
        emailTemplateIds: {
            javaClass: 'java.util.LinkedList',
            list: [1]
        },
        onlineAccess: false,
        password: null,
        passwordHashBase64: null,
        javaClass: 'com.untangle.app.reports.ReportsUser',
    },
    changePasswordOptions: {
        setRecordFields: {
            passwordHashBase64: null
        }
    },

    extraColumnConfig: {
        emailTemplateIds: { xtype: 'custom-combo', getData : function(me){
            return Ext.Array.pluck(me.getViewModel().get("emailTemplates").getRange(),"data");    
        }, compareToField : 'templateId'},
        onlineAccess: { xtype: 'checkbox' },
    },

    bind: '{users}',

    emptyText: 'No Names Defined'.t(),

    columns: [{
        header: 'Email Address (username)'.t(),
        width: Renderer.emailWidth,
        dataIndex: 'emailAddress',
        editor: {
            xtype: 'textfield',
            emptyText: '[enter email address]'.t(),
            allowOnlyWhitespace: false,
            blankText: 'The email address cannot be blank.'.t()
        }
    }, {
        xtype: 'checkcolumn',
        width: Renderer.idWidth,
        header: 'Email Alerts'.t(),
        dataIndex: 'emailAlerts',
        resizable: false
    }, {
        xtype: 'checkcolumn',
        width: Renderer.idWidth,
        header: 'Email Reports'.t(),
        dataIndex: 'emailSummaries',
        resizable: false
    }, {
        header: 'Email Templates'.t(),
        width: Renderer.messageWidth,
        flex: 1,
        dataIndex: 'emailTemplateIds',
        renderer: 'emailTemplatesRenderer'
    }, {
        xtype: 'checkcolumn',
        header: 'Online Access'.t(),
        width: Renderer.idWidth,
        dataIndex: 'onlineAccess',
        resizable: false
    }],

    editorFields: [{
        xtype: 'textfield',
        bind: '{record.emailAddress}',
        fieldLabel: 'Email Address (username)'.t(),
        emptyText: '[enter email address]'.t(),
        allowOnlyWhitespace: false,
        width: 300,
        blankText: 'The email address name cannot be blank.'.t(),
    }, {
        xtype: 'checkbox',
        bind: '{record.emailAlerts}',
        fieldLabel: 'Email Alerts'.t()
    }, {
        xtype: 'checkbox',
        bind: '{record.emailSummaries}',
        fieldLabel: 'Email Reports'.t()
    }, {
        xtype: 'unemailtemplateselect',
        bind: {
            store: '{record.emailTemplateIds.list}',
            disabled: '{record.emailSummaries == false}',
            hidden: '{record.emailSummaries == false}',
        },
        fieldLabel: 'Email Templates'.t(),
        disabled: true,
        hidden: true,
    }]
});
