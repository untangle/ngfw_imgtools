/**
 * contains methods for converting the column values to a different form
 * e.g. ids => strings found in mapping file
 * converters help with column sorting and filtering options
 * so instead of sorting by underlaying initial id value,
 * column will be sorted/filtered by converted string value
 */
Ext.define('Ung.util.Converter', {
    singleton: true,
    alternateClassName: 'Converter',

    mapValueFormat: '{0} [{1}]'.t(),

    timestamp: function (value) {
        if(Renderer.timestampOffset === null){
            Renderer.timestampOffset =  (new Date().getTimezoneOffset() * 60000) + rpc.timeZoneOffset;
        }
        if (!value) { return ''; }
        if ((typeof(value) === 'object') && value.time) { value = value.time; }
        if (value < 2696400000){ value *= 1000; }
        var date = new Date(value);
        date.setTime(value + Renderer.timestampOffset);
        return Ext.util.Format.date(date, 'timestamp_fmt'.t());
    },

    /**
     * This function is used to convert the unix timestamp date into date object,
     * also we are adjusting the offset to correctly render the time on UI 
     * and returning the date object which would be stored in the store in
     * JS date object format
     */
    convertDate: function (value) {
        if(Renderer.timestampOffset === null){
            Renderer.timestampOffset =  (new Date().getTimezoneOffset() * 60000) + rpc.timeZoneOffset;
        }
        if (!value || value == "0" || value == "") { return 0; }
        if ((typeof(value) === 'object') && value.time) { value = value.time; }
        if(value < 2696400000){ value *= 1000; }
        var date = new Date(value);
        date.setTime(value + Renderer.timestampOffset);
        return date;
    },

    interface: function (v) {
        return (Map.interfaces[v] || 'None'.t()) + ' [' + v + ']';
    },
    country: function (v) { return Map.countries[v] || v; },
    policy: function (v) { return Map.policies[v] || 'None'.t(); },
    webReason: function (v) { return Map.webReasons[v] || 'no rule applied'.t(); },
    webCategory: function (v) { return Map.webCategories[v] || v; },
    protocol: function (v) { return Map.protocols[v] || v; },

    icmp: function (v) { return Map.icmps[v] || 'Unasigned'.t(); },
    ipaddr: function (v) { return v || ''; },

    httpMethod: function (v) { return Map.httpMethods[v] || v; },
    loginReason: function (v) { return Map.loginReasons[v] || ''; },

    priority: function (v) { return Map.httpMethods[v] || v; },
    emailAction: function (v) { return Map.emailActions[v] || 'unknown action'.t(); },

    authType: function (v) {
        var types = {
            NONE: 'None'.t(),
            LOCAL_DIRECTORY: 'Local Directory'.t(),
            ACTIVE_DIRECTORY: 'Active Directory'.t(),
            RADIUS: 'RADIUS'.t(),
            GOOGLE: 'Google Account'.t(),
            MICROSOFT: 'Microsoft Account'.t(),
            CUSTOM: 'Custom'.t()
        };
        if (Ext.isEmpty(v)) { return ''; }
        return types[v] || 'Unknown'.t();
    },

    directoryConnectorAction: function (v) {
        var actions = {
            I: 'login'.t(),
            U: 'update'.t(),
            O: 'logout'.t(),
            A: 'authenticate'.t()
        };
        if (Ext.isEmpty(v)) { return ''; }
        return actions[v] || 'unknown'.t();
    },

    captivePortalEventInfo: function (v) {
        var events = {
            LOGIN: 'Login Success'.t(),
            FAILED: 'Login Failure'.t(),
            TIMEOUT: 'Session Timeout'.t(),
            INACTIVE: 'Idle Timeout'.t(),
            USER_LOGOUT: 'User Logout'.t(),
            ADMIN_LOGOUT: 'Admin Logout'.t(),
            HOST_CHANGE: 'Host Change Logout'.t(),
        };
        if (Ext.isEmpty(v)) { return ''; }
        return events[v] || 'Unknown'.t();
    },

    quotaAction: function (v) {
        var actions = {
            1: 'Given'.t(),
            2: 'Exceeded'.t()
        };
        if (Ext.isEmpty(v)) { return ''; }
        return actions[v] || 'Unknown'.t();
    },

    // login_type is a non existant field
    // directoryConnectorActionSource: function (v) {
    //     var sources = {
    //         W: 'client'.t(),
    //         A: 'active directory'.t(),
    //         R: 'radius'.t(),
    //         T: 'test'.t(),
    //     }
    //     if (Ext.isEmpty(v)) { return ''; }
    //     return sources[v] || 'unknown'.t();
    // },

    // not implemented, see old Renderer
    webRule: function () {},

    /**
     * This function is used to convert the field value string 
     * to html encoded string for preventing XSS or command injection
     */
    stringHtmlEncode: function(value) {
        // Decode any already-encoded characters
        var decodedValue = Ext.String.htmlDecode(value);

        // Encode the decoded value to ensure proper encoding
        return Ext.String.htmlEncode(decodedValue);
    }
});
Ext.define('Ung.util.Metrics', {
    alternateClassName: 'Metrics',
    singleton: true,
    frequency: 10000,
    interval: null,
    running: false,

    start: function () {
        var me = this;
        Ext.getStore('stats').loadRawData({});
        Ext.getStore('metrics').loadData({});
        me.stop();
        me.run();
        me.interval = window.setInterval(function () {
            me.run();
        }, me.frequency);
    },

    stop: function () {
        if (this.interval !== null) {
            window.clearInterval(this.interval);
        }
    },

    run: function () {
        var me = this;
        var data = [];
        Rpc.asyncData('rpc.metricManager.getMetricsAndStats')
        .then( function(result){
            if(Util.isDestroyed(data)){
                return;
            }
            data = [];

            Ext.getStore('stats').loadRawData(result.systemStats);

            for (var appId in result.metrics) {
                if (result.metrics.hasOwnProperty(appId)) {
                    data.push({
                        appId: appId,
                        metrics: result.metrics[appId]
                    });
                }
            }

            Ext.getStore('metrics').loadData(data);
        },function(ex){
            if (Util.isServerConnectionLost(ex)) {
                me.stop();
            }
            Util.handleException(ex);
        });
    }

});
/**
 * Should be replaced by the newer Rndr.js
 * still kept for now for backward compatibility reasons
 */

Ext.define('Ung.util.Renderer', {
    singleton: true,
    alternateClassName: 'Renderer',

    listKey: '__list__',

    // Format used when there is some value for the user knowing the subscripted value.
    // Not useful for index values that aren't visible to the user.
    mapValueFormat: '{0} [{1}]'.t(),

    /*
     * Common column widths
     */
    // Action
    actionWidth: 60,
    // Boolean
    booleanWidth: 60,
    // Comparator field
    comparatorWidth: 120,
    // Conditions
    conditionsWidth: 100,
    // Counter
    counterWidth: 80,
    // UTC-formatted Date
    dateWidth: 170,
    // Email address
    emailWidth: 150,
    // Hostname
    hostnameWidth: 120,
    // Numeric identifier
    idWidth: 80,
    // Icon
    iconWidth: 30,
    // Interval
    intervalWidth: 90,
    // IP Address
    ipWidth: 100,
    // Load measurement
    loadWidth: 50,
    // Latitude/longtitude
    locationWidth: 50,
    // MAC address
    macWidth: 120,
    // General purpose
    messageWidth: 120,
    // Network (ip/bit)
    networkWidth: 120,
    // Port
    portWidth: 70,
    // Network prefix
    prefixWidth: 50,
    // Priority
    prioritytWidth: 70,
    // Protocol
    protocolWidth: 70,
    // Data size
    sizeWidth: 90,
    // Tags
    tagsWidth: 200,
    // Timestamp
    timestampWidth: 135,
    // URI
    uriWidth: 200,
    // Username
    usernameWidth: 120,

    /**
     * Array store with renderers used in Reports Settings
     */
    forReports: [['', 'None'.t()], ['interface', 'Interface'], ['protocol', 'Protocol'.t()], ['policy_id', 'Policy'.t()]],

    /*
     * Grid filters
     */
    booleanFilter: {
        type: 'boolean',
        yesText: 'true'.t(),
        noText: 'false'.t()
    },

    numericFilter: {
        type: 'numeric'
    },

    stringFilter: {
        type: 'string'
    },

    timestampFilter: {
        type: 'date'
    },

    localize: function(value){
        return value.t();
    },

    boolean: function( value ){
        return ( value == true || value == 'true' ) ? 'true' : 'false';
    },

    /**
     * Determine width based on the size of the screen body and divide by the divisor.
     */
    calculateWith: function (divisor) {
        return Math.ceil(Ext.getBody().getViewSize().width / divisor) - 1;
    },

    timestampOffset: null,
    timestamp: function (value) {
        if(Renderer.timestampOffset === null){
            Renderer.timestampOffset =  (new Date().getTimezoneOffset() * 60000) + rpc.timeZoneOffset;
        }
        if (!value) { return ''; }
        if ((typeof(value) === 'object') && value.time) { value = value.time; }
        if(value < 2696400000){ value *= 1000; }
        var date = new Date(value);
        date.setTime(value + Renderer.timestampOffset);
        return Ext.util.Format.date(date, 'timestamp_fmt'.t());
    },

    timestampUnixRenderer:function(date){
        return Ext.util.Format.date(date, 'timestamp_fmt'.t());
    },

    timespanMap: [
        [ 604800, 'w'.t() ],
        [ 86400, 'd'.t() ],
        [ 3600, 'h'.t() ] ,
        [ 60, 'm'.t() ],
        [ 1, 's'.t() ]
    ],
    /**
     * From a value of seconds, return a text based span formatted like:
     * 6h, 2m, 3s.
     * @param {*} Value to convert to span in seconds.
     * @returns Text of span.
     */
    timespan: function(value){
        if( value === null){
            value = 0;
        }
        var span = [];
        value = parseInt( value, 10 );
        if(value == 0){
            /**
             * No span.
             */
            span.push('None'.t());
        }else{
            /**
             * Walk seconds and populate span.
             */
            var currentSpan;
            for( var i = 0; i < Ung.util.Renderer.timespanMap.length; i++){
                currentSpan = Ung.util.Renderer.timespanMap[i];
                if(value >= currentSpan[0]){
                    span.push(Math.floor(value / currentSpan[0]) + currentSpan[1]);
                    value = value % currentSpan[0];
                }
            }
        }
        return span.join(', ');
    },

    interfaceMap: null,
    interfaceLastUpdated: null,
    interfaceMaxAge: 30 * 1000,
    interface: function (value) {
        if (!Rpc.exists('rpc.reportsManager')) {
            return value.toString();
        }
        var currentTime = new Date().getTime();
        if (Ung.util.Renderer.interfaceMap === null ||
            Ung.util.Renderer.interfaceLastUpdated === null ||
            ( ( Ung.util.Renderer.interfaceLastUpdated + Ung.util.Renderer.interfaceMaxAge ) < currentTime ) ){
            var interfacesList = [], i;

            try {
                interfacesList = Rpc.directData('rpc.reportsManager.getInterfacesInfo').list;
            } catch (ex) {
                console.log(ex);
            }

            Ung.util.Renderer.interfaceMap = {};
            for (i = 0; i < interfacesList.length; i += 1) {
                Ung.util.Renderer.interfaceMap[interfacesList[i].interfaceId] = interfacesList[i].name + " [" + interfacesList[i].interfaceId + "]";
            }
            Ung.util.Renderer.interfaceLastUpdated = currentTime;
        }
        if(value == Renderer.listKey){
            return Ung.util.Renderer.interfaceMap;
        }else{
            return ( value && value != -1 ) ? Ung.util.Renderer.interfaceMap[value] || value.toString() : 'None'.t();
        }
    },

    tags: function (value, metaData) {
        if( value != null &&
            value != "" ){
            if( typeof(value) == 'string' ){
                value = Ext.decode( value );
            }
            if( value && value.list ) {
                var str = [], tip = [], name;
                Ext.Array.each(value.list, function (tag) {
                    name = Ext.String.htmlEncode(tag.name);
                    str.push('<div class="tag-item">' + name + '</div>');
                    if ( tag.expirationTime == 0 )
                        tip.push('<strong>' + name + '</strong> - ' + 'Never'.t());
                    else
                        tip.push('<strong>' + name + '</strong> - ' + Ext.Date.format(new Date(tag.expirationTime), 'timestamp_fmt'.t()));
                });
                if (metaData) {
                    metaData.tdAttr = 'data-qtip="' + tip.join('<br/>') + '"';
                    metaData.tdCls = 'tag-cell';
                }
                return '<div class="tagpicker">' + str.join('') + '</div>';
            }
        }
        return '';
    },

    datasizeMap: [
        [ 1125899906842624, 'PB'.t() ],
        [ 1099511627776, 'TB'.t() ],
        [ 1073741824, 'GB'.t() ],
        [ 1048576, 'MB'.t() ] ,
        [ 1024, 'KB'.t() ],
        [ 1, 'B'.t() ]
    ],
    datasize: function( value ){
        // walk map looking at key.  If larger then divide and use units
        if( value === null){
            value = 0;
        }
        value = parseInt( value, 10 );
        var size = Ung.util.Renderer.datasizeMap[Ung.util.Renderer.datasizeMap.length-1];
        for( var i = 0; i < Ung.util.Renderer.datasizeMap.length; i++){
            size = Ung.util.Renderer.datasizeMap[i];
            if( value >= size[0] || value <= (0-size[0])){
                break;
            }
        }
        if( ( value == 0 ) ||
            ( size[0] == 1 ) ){
            return value + ' ' + size[1];
        }else{
            var dividedValue = ( value / size[0] ).toFixed(2).toString();
            if(dividedValue.substring(dividedValue.length - 3) == '.00'){
                dividedValue = dividedValue.substring(0, dividedValue.length - 3);
            }
            return dividedValue + ' ' + size[1];
        }
    },

    datasizeoptional: function(value){
        if( value === 0 || value === '' ){
            return '';
        }
        return Renderer.datasize(value);
    },

    countMap: [
        [ 1125899906842624, 'P'.t() ],
        [ 1099511627776, 'T'.t() ],
        [ 1073741824, 'G'.t() ],
        [ 1048576, 'M'.t() ] ,
        [ 1024, 'K'.t() ],
        [ 1, '' ]
    ],
    count: function( value ){
        // walk map looking at key.  If larger then divide and use units
        if( value === null){
            value = 0;
        }
        value = parseInt( value, 10 );
        var size = Ung.util.Renderer.countMap[Ung.util.Renderer.countMap.length - 1];
        for( var i = 0; i < Ung.util.Renderer.countMap.length; i++){
            size = Ung.util.Renderer.countMap[i];
            if( value >= size[0] || value <= (0-size[0])){
                break;
            }
        }
        if( ( value == 0 ) ||
            ( size[0] == 1 ) ){
            return value + ' ' + size[1];
        }else{
            return ( value / size[0] ).toFixed(2) + ' ' + size[1];
        }
    },

    timeIntervalMap: {
        86400: 'Daily'.t(),
        604800: 'Weekly'.t(),
        1: 'Week to Date'.t(),
        2419200: 'Monthly'.t(),
        2: 'Month to Date'.t()
    },
    timeInterval: function ( value ){
        if(value == Renderer.listKey){
            return Renderer.timeIntervalMap;
        }
        if( value in Ung.util.Renderer.timeIntervalMap ){
            return Ung.util.Renderer.timeIntervalMap[value];
        }
        return value;
    },

    elapsedTime: function( value ){
        var total = parseInt(value / 1000,10);
        var days = (parseInt(total / (3600 * 24),10));
        var hours = (parseInt(total / 3600,10) % 24);
        var minutes = (parseInt(total / 60,10) % 60);
        var seconds = parseInt(total % 60,10);
        var result = (days > 0 ? ( days < 10 ? '0' + days : days) + ':' : '' ) + (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds  < 10 ? "0" + seconds : seconds);
        return result;
    },

    dayOfWeekMap: {
        0: 'Sunday'.t(),
        1: 'Monday'.t(),
        2: 'Tuesday'.t(),
        3: 'Wednesday'.t(),
        4: 'Thursday'.t(),
        5: 'Friday'.t(),
        6: 'Saturday'.t()
    },
    dayOfWeek: function( value ){
        if(value == Renderer.listKey){
            return Renderer.dayOfWeekMap;
        }
        if( value in Ung.util.Renderer.dayOfWeekMap ){
            return Ung.util.Renderer.dayOfWeekMap[value];
        }
        return value;
    },

    priorityMap: {
        0: '',
        1: 'Very High'.t(),
        2: 'High'.t(),
        3: 'Medium'.t(),
        4: 'Low'.t(),
        5: 'Limited'.t(),
        6: 'Limited More'.t(),
        7: 'Limited Severely'.t()
    },
    priority: function( value ){
        if (Ext.isEmpty(value)) {
            value = 0;
        }
        if(value == Renderer.listKey){
            return Renderer.priorityMap;
        }
        if( value in Ung.util.Renderer.priorityMap ){
            return Ung.util.Renderer.priorityMap[value];
        }
        return Ext.String.format('Unknown Priority: {0}'.t(), value);
    },

    mark: function( value ){
        if (value){
            return "0x" + value.toString(16);
        }
        return '';
    },

    protocolsMap: {
        0: 'HOPOPT [0]',
        1: 'ICMP [1]',
        2: 'IGMP [2]',
        3: 'GGP [3]',
        4: 'IP-in-IP [4]',
        5: 'ST [5]',
        6: 'TCP [6]',
        7: 'CBT [7]',
        8: 'EGP [8]',
        9: 'IGP [9]',
        10: 'BBN-RCC-MON [10]',
        11: 'NVP-II [11]',
        12: 'PUP [12]',
        13: 'ARGUS [13]',
        14: 'EMCON [14]',
        15: 'XNET [15]',
        16: 'CHAOS [16]',
        17: 'UDP [17]',
        18: 'MUX [18]',
        19: 'DCN-MEAS [19]',
        20: 'HMP [20]',
        21: 'PRM [21]',
        22: 'XNS-IDP [22]',
        23: 'TRUNK-1 [23]',
        24: 'TRUNK-2 [24]',
        25: 'LEAF-1 [25]',
        26: 'LEAF-2 [26]',
        27: 'RDP [27]',
        28: 'IRTP [28]',
        29: 'ISO-TP4 [29]',
        30: 'NETBLT [30]',
        31: 'MFE-NSP [31]',
        32: 'MERIT-INP [32]',
        33: 'DCCP [33]',
        34: '3PC [34]',
        35: 'IDPR [35]',
        36: 'XTP [36]',
        37: 'DDP [37]',
        38: 'IDPR-CMTP [38]',
        39: 'TP++ [39]',
        40: 'IL [40]',
        41: 'IPv6 [41]',
        42: 'SDRP [42]',
        43: 'IPv6-Route [43]',
        44: 'IPv6-Frag [44]',
        45: 'IDRP [45]',
        46: 'RSVP [46]',
        47: 'GRE [47]',
        48: 'MHRP [48]',
        49: 'BNA [49]',
        50: 'ESP [50]',
        51: 'AH [51]',
        52: 'I-NLSP [52]',
        53: 'SWIPE [53]',
        54: 'NARP [54]',
        55: 'MOBILE [55]',
        56: 'TLSP [56]',
        57: 'SKIP [57]',
        58: 'IPv6-ICMP [58]',
        59: 'IPv6-NoNxt [59]',
        60: 'IPv6-Opts [60]',
        62: 'CFTP [62]',
        64: 'SAT-EXPAK [64]',
        65: 'KRYPTOLAN [65]',
        66: 'RVD [66]',
        67: 'IPPC [67]',
        69: 'SAT-MON [69]',
        70: 'VISA [70]',
        71: 'IPCU [71]',
        72: 'CPNX [72]',
        73: 'CPHB [73]',
        74: 'WSN [74]',
        75: 'PVP [75]',
        76: 'BR-SAT-MON [76]',
        77: 'SUN-ND [77]',
        78: 'WB-MON [78]',
        79: 'WB-EXPAK [79]',
        80: 'ISO-IP [80]',
        81: 'VMTP [81]',
        82: 'SECURE-VMTP [82]',
        83: 'VINES [83]',
        84: 'TTP [84]',
        85: 'NSFNET-IGP [85]',
        86: 'DGP [86]',
        87: 'TCF [87]',
        88: 'EIGRP [88]',
        89: 'OSPF [89]',
        90: 'Sprite-RPC [90]',
        91: 'LARP [91]',
        92: 'MTP [92]',
        93: 'AX.25 [93]',
        94: 'IPIP [94]',
        95: 'MICP [95]',
        96: 'SCC-SP [96]',
        97: 'ETHERIP [97]',
        98: 'ENCAP [98]',
        100: 'GMTP [100]',
        101: 'IFMP [101]',
        102: 'PNNI [102]',
        103: 'PIM [103]',
        104: 'ARIS [104]',
        105: 'SCPS [105]',
        106: 'QNX [106]',
        107: 'A/N [107]',
        108: 'IPComp [108]',
        109: 'SNP [109]',
        110: 'Compaq-Peer [110]',
        111: 'IPX-in-IP [111]',
        112: 'VRRP [112]',
        113: 'PGM [113]',
        115: 'L2TP [115]',
        116: 'DDX [116]',
        117: 'IATP [117]',
        118: 'STP [118]',
        119: 'SRP [119]',
        120: 'UTI [120]',
        121: 'SMP [121]',
        122: 'SM [122]',
        123: 'PTP [123]',
        124: 'IS-IS [124]',
        125: 'FIRE [125]',
        126: 'CRTP [126]',
        127: 'CRUDP [127]',
        128: 'SSCOPMCE [128]',
        129: 'IPLT [129]',
        130: 'SPS [130]',
        131: 'PIPE [131]',
        132: 'SCTP [132]',
        133: 'FC [133]',
        134: 'RSVP-E2E-IGNORE [134]',
        135: 'Mobility [135]',
        136: 'UDPLite [136]',
        137: 'MPLS-in-IP [137]',
        138: 'manet [138]',
        139: 'HIP [139]',
        140: 'Shim6 [140]',
        141: 'WESP [141]',
        142: 'ROHC [142]',
        default: 'Unknown'.t()
    },

    protocol: function (value) {
        if(value == Renderer.listKey){
            return Renderer.protocolsMap;
        }else{
            return value ? Ung.util.Renderer.protocolsMap[value] || value.toString() : '';
        }
    },

    settingsFile: function( value ){
        value = value.replace( /^.*\/settings\//, '' );
        value = value.replace( /^.*\/conf\//, '' );
        return value;
    },

    id: function(value){
        return ( value < 0 || value === undefined ) ? 'new'.t() : value;
    },

    policiesMap: null,
    policy: function (value) {
        if(Renderer.policiesMap == null){
            Renderer.policiesMap = {};
            var policiesInfo = null;
            if(Rpc.exists('rpc.reportsManager')){
                policiesInfo = Rpc.directData('rpc.reportsManager.getPoliciesInfo');
            }else{
                policiesInfo = Rpc.directData('rpc.appManager').app('policy-manager').getPoliciesInfo();
            }
            if(policiesInfo && policiesInfo.list){
                policiesInfo.list.forEach(function(policy){
                    Renderer.policiesMap[policy.policyId] = policy.name;
                });
            }
        }
        if(value == Renderer.listKey){
            return Renderer.policiesMap;
        }
        if(value === 0){
            return 'None'.t();
        }
        if(!value || !( value in Renderer.policiesMap )){
            return '';
        }
        return Ext.String.format('{0} [{1}]'.t(), Renderer.policiesMap[parseInt(value, 10)] || value.toString(), value);
    },
    policy_id: function(value){
        return Renderer.policy(value);
    },

    httpReasonMap: {
        D: 'in Categories Block list'.t(),
        U: 'in Site Block list'.t(),
        T: 'in Search Term list'.t(),
        E: 'in File Block list'.t(),
        M: 'in MIME Types Block list'.t(),
        H: 'hostname is an IP address'.t(),
        I: 'in Site Pass list'.t(),
        R: 'referer in Site Pass list'.t(),
        C: 'in Clients Pass list'.t(),
        B: 'in Temporary Unblocked list'.t(),
        F: 'in Rules list'.t(),
        K: 'Kid-friendly redirect'.t(),
        default: 'no rule applied'.t()
    },
    httpReason: function( value, metaData ) {
        if(Ext.isEmpty(value)) {
            return '';
        }
        if(value == Renderer.listKey){
            return Renderer.httpReasonMap;
        }else{
            var renderValue = Ext.String.format(
                    Renderer.mapValueFormat,
                    ( value in Renderer.httpReasonMap ) ? Renderer.httpReasonMap[value] : Renderer.httpReasonMap['default'],
                    value
            );
            if (metaData) {
                metaData.tdAttr = 'data-qtip="' + renderValue + '"';
                metaData.tdCls = 'tag-cell';
            }
            return renderValue;
        }
    },

    webCategoryMap:{
        0: "Uncategorized",
        1: "Real Estate",
        2: "Computer and Internet Security",
        3: "Financial Services",
        4: "Business and Economy",
        5: "Computer and Internet Info",
        6: "Auctions",
        7: "Shopping",
        8: "Cult and Occult",
        9: "Travel",
        10: "Abused Drugs",
        11: "Adult and Pornography",
        12: "Home and Garden",
        13: "Military",
        14: "Social Networking",
        15: "Dead Sites",
        16: "Individual Stock Advice and Tools",
        17: "Training and Tools",
        18: "Dating",
        19: "Sex Education",
        20: "Religion",
        21: "Entertainment and Arts",
        22: "Personal sites and Blogs",
        23: "Legal",
        24: "Local Information",
        25: "Streaming Media",
        26: "Job Search",
        27: "Gambling",
        28: "Translation",
        29: "Reference and Research",
        30: "Shareware and Freeware",
        31: "Peer to Peer",
        32: "Marijuana",
        33: "Hacking",
        34: "Games",
        35: "Philosophy and Political Advocacy",
        36: "Weapons",
        37: "Pay to Surf",
        38: "Hunting and Fishing",
        39: "Society",
        40: "Educational Institutions",
        41: "Online Greeting Cards",
        42: "Sports",
        43: "Swimsuits and Intimate Apparel",
        44: "Questionable",
        45: "Kids",
        46: "Hate and Racism",
        47: "Personal Storage",
        48: "Violence",
        49: "Keyloggers and Monitoring",
        50: "Search Engines",
        51: "Internet Portals",
        52: "Web Advertisements",
        53: "Cheating",
        54: "Gross",
        55: "Web-based Email",
        56: "Malware Sites",
        57: "Phishing and Other Frauds",
        58: "Proxy Avoidance and Anonymizers",
        59: "Spyware and Adware",
        60: "Music",
        61: "Government",
        62: "Nudity",
        63: "News and Media",
        64: "Illegal",
        65: "Content Delivery Networks",
        66: "Internet Communications",
        67: "Bot Nets",
        68: "Abortion",
        69: "Health and Medicine",
        71: "SPAM URLs",
        74: "Dynamically Generated Content",
        75: "Parked Domains",
        76: "Alcohol and Tobacco",
        78: "Image and Video Search",
        79: "Fashion and Beauty",
        80: "Recreation and Hobbies",
        81: "Motor Vehicles",
        82: "Web Hosting",
        85: "Self Harm",
        86: "DNS Over HTTPS",
        87: "Low-THC Cannabis Products",
        88: "Generative AI"
    },
    webCategory: function(value, row, record){
        if(value == Renderer.listKey){
            var values = [];
            Object.values(Renderer.webCategoryMap).sort().forEach( function(value){
                for(var key in Renderer.webCategoryMap){
                    if(Renderer.webCategoryMap[key] == value){
                        values.push([key,value]);
                    }
                }
            });
            return values;
        }else{
            return Renderer.webCategoryMap[value];
        }
    },

    getReportInfo: function(record, apps, infoName){
        if(typeof apps == "string"){
            apps = [apps];
        }
        var reportInfo = null;
        var policyIds = [];
        var i;
        if( record && record.get && record.get('policy_id') ){
            var policyName = record.get('policy_id');
            for(var id in Map.policies){
                if(Map.policies.hasOwnProperty(id)){
                    if(Map.policies[id] == policyName){
                        policyIds = [id];
                    }
                }
            }
        }else{
            policyIds=[1];
        }

        var policies = Rpc.directData('rpc.reportsManager.getPoliciesInfo');
        var hasParent = false;
        if(policies != null){
            if(policyIds.length == 0){
                // We have no policy ids.  Search through all.
                for(i = 0; i < policies.list.length; i++){
                    policyIds.push(policies.list[i].policyId);
                }
            }else{
                policyIds.forEach( function(policyId){
                    policies.list.forEach( function(policy){
                        if(policy['policyId'] == policyId &&
                            ( 'parentId' in policy )){
                                hasParent = true;
                            }
                    });
                });
            }
        }
        var policyId = null;
        var parentPolicyId = null;
        for(i = 0; i < policyIds.length; i++){
            policyId = ( parentPolicyId != null) ? parentPolicyId : policyIds[i];

            for(j = 0; j < apps.length; j++){
                reportInfo = Rpc.directData('rpc.reportsManager.getReportInfo', apps[j], policyId, infoName);
                if(reportInfo != null){
                    break;
                }
            }
            if(reportInfo != null){
                break;
            }
            if(hasParent){
                policies.list.forEach( function(policy){
                    if(policy['policyId'] == policyId &&
                        ( 'parentId' in policy )){
                            parentPolicyId =policy['parentId'];
                            i--;
                        }
                });
            }
        }
        return reportInfo;
    },

    /**
     * The webfilter_rule_id is very overloaded with numeric indexes for:
     * -    Pass sites
     * -    Block sites
     * -    Pass clients
     * -    Filter rules
     *
     * The map is organized as:
     *     policy->source->key=value
     */
    webRuleMap: {},
    webRule: function(value, metaData, record){
        var id;
        var policyId = record && record.get && record.get('policy_id') ? record.get('policy_id') : 1;
        if(policyId != 1){
            for(id in Map.policies){
                if(Map.policies.hasOwnProperty(id)){
                    if(Map.policies[id] == policyId){
                        policyId = id;
                        break;
                    }
                }
            }
        }
        var webFilterReason = record && record.get && record.get('web_filter_reason') ? record.get('web_filter_reason') : 'N';
        if(webFilterReason != 'N'){
            for(id in Map.webReasons){
                if(Map.webReasons.hasOwnProperty(id)){
                    if(Map.webReasons[id] == webFilterReason){
                        webFilterReason = id;
                        if(webFilterReason == 'default'){
                            webFilterReason = 'N';
                        }
                        break;
                    }
                }
            }
        }

        var reasonSource = "categories";
        switch(webFilterReason){
            case 'D':
            case 'N':
            case 'K':
                return '';
            case 'U':
                reasonSource = "blockedUrls";
                break;
            case 'I':
            case 'R':
                reasonSource = "passedUrls";
                break;
            case 'C':
                reasonSource = "passedClients";
                break;
            case 'T':
                reasonSource = "searchTerms";
                break;
            case 'F':
                reasonSource = "filterRules";
                break;
        }

        if(!Renderer.webRuleMap[policyId] ||
            !Renderer.webRuleMap[policyId][reasonSource] ||
            (value != Renderer.listKey && !(value in Renderer.webRuleMap[policyId][reasonSource]))){
            if(!Renderer.webRuleMap[policyId]){
                Renderer.webRuleMap[policyId] = {};
            }
            if(!Renderer.webRuleMap[policyId][reasonSource]){
                Renderer.webRuleMap[policyId][reasonSource] = {};
            }

            var categoryInfo = Ung.util.Renderer.getReportInfo(record, ["web-filter", "web-monitor"], reasonSource);

            if(categoryInfo){
                categoryInfo.forEach( function(rule){
                    Renderer.webRuleMap[policyId][reasonSource][rule["id"] ? rule["id"] : rule["ruleId"]] = rule["description"] ? rule["description"] : rule["string"];
                });
            }
            if(!(value in Renderer.webRuleMap[policyId][reasonSource]) && (value != Renderer.listKey)){
                // If category cannot be found, don't just keep coming back for more.
                Renderer.webRuleMap[policyId][reasonSource][value] = 'Unknown'.t();
            }
        }
        if(value == Renderer.listKey){
            return Renderer.webRuleMap[policyId][reasonSource];
        }else{
            var renderValue = Renderer.webRuleMap[policyId][reasonSource][value];
                if (metaData) {
                    metaData.tdAttr = 'data-qtip="' + renderValue + '"';
                    metaData.tdCls = 'tag-cell';
                }
            return renderValue;
        }
    },

    sessionSpeed: function(value){
        return Math.round(value * 10 )/ 10;
    },

    icmpMap: {
        0: 'Echo Reply'.t(),
        1: 'Unassigned'.t(),
        2: 'Unassigned'.t(),
        3: 'Destination Unreachable'.t(),
        4: 'Source Quench (Deprecated)'.t(),
        5: 'Redirect'.t(),
        6: 'Alternate Host Address (Deprecated)'.t(),
        7: 'Unassigned'.t(),
        8: 'Echo'.t(),
        9: 'Router Advertisement'.t(),
        10: 'Router Solicitation'.t(),
        11: 'Time Exceeded'.t(),
        12: 'Parameter Problem'.t(),
        13: 'Timestamp'.t(),
        14: 'Timestamp Reply'.t(),
        15: 'Information Request (Deprecated)'.t(),
        16: 'Information Reply (Deprecated)'.t(),
        17: 'Address Mask Request (Deprecated)'.t(),
        18: 'Address Mask Reply (Deprecated)'.t(),
        19: 'Reserved (for Security)'.t(),
        20: 'Reserved (for Robustness Experiment)'.t(),
        21: 'Reserved (for Robustness Experiment)'.t(),
        22: 'Reserved (for Robustness Experiment)'.t(),
        23: 'Reserved (for Robustness Experiment)'.t(),
        24: 'Reserved (for Robustness Experiment)'.t(),
        25: 'Reserved (for Robustness Experiment)'.t(),
        26: 'Reserved (for Robustness Experiment)'.t(),
        27: 'Reserved (for Robustness Experiment)'.t(),
        28: 'Reserved (for Robustness Experiment)'.t(),
        29: 'Reserved (for Robustness Experiment)'.t(),
        30: 'Traceroute (Deprecated)'.t(),
        31: 'Datagram Conversion Error (Deprecated)'.t(),
        32: 'Mobile Host Redirect (Deprecated)'.t(),
        33: 'IPv6 Where-Are-You (Deprecated)'.t(),
        34: 'IPv6 I-Am-Here (Deprecated)'.t(),
        35: 'Mobile Registration Request (Deprecated)'.t(),
        36: 'Mobile Registration Reply (Deprecated)'.t(),
        37: 'Domain Name Request (Deprecated)'.t(),
        38: 'Domain Name Reply (Deprecated)'.t(),
        39: 'SKIP (Deprecated)'.t(),
        40: 'Photuris'.t(),
        41:  'ICMP messages utilized by experimental mobility protocols'.t(),
        default: 'Unassigned'.t(),
        253: 'RFC3692-style Experiment 1'.t(),
        254: 'RFC3692-style Experiment 2'.t(),
        255: 'Reserved'.t()
    },
    icmp: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return Ext.String.format(
                Renderer.mapValueFormat,
                ( value in Renderer.icmpMap ) ? Renderer.icmpMap[value] : Renderer.icmpMap['default'],
                value
        );
    },

    countryMap: {
        XU: 'Unknown'.t(),
        XL: 'Local'.t(),
        AF: 'Afghanistan'.t(),
        AX: 'Aland Islands'.t(),
        AL: 'Albania'.t(),
        DZ: 'Algeria'.t(),
        AS: 'American Samoa'.t(),
        AD: 'Andorra'.t(),
        AN: 'Netherlands Antilles'.t(),
        AO: 'Angola'.t(),
        AI: 'Anguilla'.t(),
        AQ: 'Antarctica'.t(),
        AG: 'Antigua and Barbuda'.t(),
        AR: 'Argentina'.t(),
        AM: 'Armenia'.t(),
        AW: 'Aruba'.t(),
        AU: 'Australia'.t(),
        AT: 'Austria'.t(),
        AZ: 'Azerbaijan'.t(),
        BS: 'Bahamas'.t(),
        BH: 'Bahrain'.t(),
        BD: 'Bangladesh'.t(),
        BB: 'Barbados'.t(),
        BY: 'Belarus'.t(),
        BE: 'Belgium'.t(),
        BZ: 'Belize'.t(),
        BJ: 'Benin'.t(),
        BM: 'Bermuda'.t(),
        BT: 'Bhutan'.t(),
        BO: 'Bolivia, Plurinational State of'.t(),
        BQ: 'Bonaire, Sint Eustatius and Saba'.t(),
        BA: 'Bosnia and Herzegovina'.t(),
        BW: 'Botswana'.t(),
        BV: 'Bouvet Island'.t(),
        BR: 'Brazil'.t(),
        IO: 'British Indian Ocean Territory'.t(),
        BN: 'Brunei Darussalam'.t(),
        BG: 'Bulgaria'.t(),
        BF: 'Burkina Faso'.t(),
        BI: 'Burundi'.t(),
        KH: 'Cambodia'.t(),
        CM: 'Cameroon'.t(),
        CA: 'Canada'.t(),
        CV: 'Cape Verde'.t(),
        KY: 'Cayman Islands'.t(),
        CF: 'Central African Republic'.t(),
        TD: 'Chad'.t(),
        CL: 'Chile'.t(),
        CN: 'China'.t(),
        CX: 'Christmas Island'.t(),
        CC: 'Cocos (Keeling) Islands'.t(),
        CO: 'Colombia'.t(),
        KM: 'Comoros'.t(),
        CG: 'Congo'.t(),
        CD: 'Congo, the Democratic Republic of the'.t(),
        CK: 'Cook Islands'.t(),
        CR: 'Costa Rica'.t(),
        CI: "Cote d'Ivoire".t(),
        HR: 'Croatia'.t(),
        CU: 'Cuba'.t(),
        CW: 'Curacao'.t(),
        CY: 'Cyprus'.t(),
        CZ: 'Czech Republic'.t(),
        DK: 'Denmark'.t(),
        DJ: 'Djibouti'.t(),
        DM: 'Dominica'.t(),
        DO: 'Dominican Republic'.t(),
        EC: 'Ecuador'.t(),
        EG: 'Egypt'.t(),
        SV: 'El Salvador'.t(),
        GQ: 'Equatorial Guinea'.t(),
        ER: 'Eritrea'.t(),
        EE: 'Estonia'.t(),
        ET: 'Ethiopia'.t(),
        FK: 'Falkland Islands (Malvinas)'.t(),
        FO: 'Faroe Islands'.t(),
        FJ: 'Fiji'.t(),
        FI: 'Finland'.t(),
        FR: 'France'.t(),
        GF: 'French Guiana'.t(),
        PF: 'French Polynesia'.t(),
        TF: 'French Southern Territories'.t(),
        GA: 'Gabon'.t(),
        GM: 'Gambia'.t(),
        GE: 'Georgia'.t(),
        DE: 'Germany'.t(),
        GH: 'Ghana'.t(),
        GI: 'Gibraltar'.t(),
        GR: 'Greece'.t(),
        GL: 'Greenland'.t(),
        GD: 'Grenada'.t(),
        GP: 'Guadeloupe'.t(),
        GU: 'Guam'.t(),
        GT: 'Guatemala'.t(),
        GG: 'Guernsey'.t(),
        GN: 'Guinea'.t(),
        GW: 'Guinea-Bissau'.t(),
        GY: 'Guyana'.t(),
        HT: 'Haiti'.t(),
        HM: 'Heard Island and McDonald Islands'.t(),
        VA: 'Holy See (Vatican City State)'.t(),
        HN: 'Honduras'.t(),
        HK: 'Hong Kong'.t(),
        HU: 'Hungary'.t(),
        IS: 'Iceland'.t(),
        IN: 'India'.t(),
        ID: 'Indonesia'.t(),
        IR: 'Iran, Islamic Republic of'.t(),
        IQ: 'Iraq'.t(),
        IE: 'Ireland'.t(),
        IM: 'Isle of Man'.t(),
        IL: 'Israel'.t(),
        IT: 'Italy'.t(),
        JM: 'Jamaica'.t(),
        JP: 'Japan'.t(),
        JE: 'Jersey'.t(),
        JO: 'Jordan'.t(),
        KZ: 'Kazakhstan'.t(),
        KE: 'Kenya'.t(),
        KI: 'Kiribati'.t(),
        KP: "Korea, Democratic People's Republic of".t(),
        KR: 'Korea, Republic of'.t(),
        KW: 'Kuwait'.t(),
        KG: 'Kyrgyzstan'.t(),
        LA: "Lao People's Democratic Republic".t(),
        LV: 'Latvia'.t(),
        LB: 'Lebanon'.t(),
        LS: 'Lesotho'.t(),
        LR: 'Liberia'.t(),
        LY: 'Libya'.t(),
        LI: 'Liechtenstein'.t(),
        LT: 'Lithuania'.t(),
        LU: 'Luxembourg'.t(),
        MO: 'Macao'.t(),
        MK: 'Macedonia, the Former Yugoslav Republic of'.t(),
        MG: 'Madagascar'.t(),
        MW: 'Malawi'.t(),
        MY: 'Malaysia'.t(),
        MV: 'Maldives'.t(),
        ML: 'Mali'.t(),
        MT: 'Malta'.t(),
        MH: 'Marshall Islands'.t(),
        MQ: 'Martinique'.t(),
        MR: 'Mauritania'.t(),
        MU: 'Mauritius'.t(),
        YT: 'Mayotte'.t(),
        MX: 'Mexico'.t(),
        FM: 'Micronesia, Federated States of'.t(),
        MD: 'Moldova, Republic of'.t(),
        MC: 'Monaco'.t(),
        MN: 'Mongolia'.t(),
        ME: 'Montenegro'.t(),
        MS: 'Montserrat'.t(),
        MA: 'Morocco'.t(),
        MZ: 'Mozambique'.t(),
        MM: 'Myanmar'.t(),
        NA: 'Namibia'.t(),
        NR: 'Nauru'.t(),
        NP: 'Nepal'.t(),
        NL: 'Netherlands'.t(),
        NC: 'New Caledonia'.t(),
        NZ: 'New Zealand'.t(),
        NI: 'Nicaragua'.t(),
        NE: 'Niger'.t(),
        NG: 'Nigeria'.t(),
        NU: 'Niue'.t(),
        NF: 'Norfolk Island'.t(),
        MP: 'Northern Mariana Islands'.t(),
        NO: 'Norway'.t(),
        OM: 'Oman'.t(),
        PK: 'Pakistan'.t(),
        PW: 'Palau'.t(),
        PS: 'Palestine, State of'.t(),
        PA: 'Panama'.t(),
        PG: 'Papua New Guinea'.t(),
        PY: 'Paraguay'.t(),
        PE: 'Peru'.t(),
        PH: 'Philippines'.t(),
        PN: 'Pitcairn'.t(),
        PL: 'Poland'.t(),
        PT: 'Portugal'.t(),
        PR: 'Puerto Rico'.t(),
        QA: 'Qatar'.t(),
        RE: 'Reunion'.t(),
        RO: 'Romania'.t(),
        RU: 'Russian Federation'.t(),
        RW: 'Rwanda'.t(),
        BL: 'Saint Barthelemy'.t(),
        SH: 'Saint Helena, Ascension and Tristan da Cunha'.t(),
        KN: 'Saint Kitts and Nevis'.t(),
        LC: 'Saint Lucia'.t(),
        MF: 'Saint Martin (French part)'.t(),
        PM: 'Saint Pierre and Miquelon'.t(),
        VC: 'Saint Vincent and the Grenadines'.t(),
        WS: 'Samoa'.t(),
        SM: 'San Marino'.t(),
        ST: 'Sao Tome and Principe'.t(),
        SA: 'Saudi Arabia'.t(),
        SN: 'Senegal'.t(),
        RS: 'Serbia'.t(),
        SC: 'Seychelles'.t(),
        SL: 'Sierra Leone'.t(),
        SG: 'Singapore'.t(),
        SX: 'Sint Maarten (Dutch part)'.t(),
        SK: 'Slovakia'.t(),
        SI: 'Slovenia'.t(),
        SB: 'Solomon Islands'.t(),
        SO: 'Somalia'.t(),
        ZA: 'South Africa'.t(),
        GS: 'South Georgia and the South Sandwich Islands'.t(),
        SS: 'South Sudan'.t(),
        ES: 'Spain'.t(),
        LK: 'Sri Lanka'.t(),
        SD: 'Sudan'.t(),
        SR: 'Suriname'.t(),
        SJ: 'Svalbard and Jan Mayen'.t(),
        SZ: 'Swaziland'.t(),
        SE: 'Sweden'.t(),
        CH: 'Switzerland'.t(),
        SY: 'Syrian Arab Republic'.t(),
        TW: 'Taiwan, Province of China'.t(),
        TJ: 'Tajikistan'.t(),
        TZ: 'Tanzania, United Republic of'.t(),
        TH: 'Thailand'.t(),
        TL: 'Timor-Leste'.t(),
        TG: 'Togo'.t(),
        TK: 'Tokelau'.t(),
        TO: 'Tonga'.t(),
        TT: 'Trinidad and Tobago'.t(),
        TN: 'Tunisia'.t(),
        TR: 'Turkey'.t(),
        TM: 'Turkmenistan'.t(),
        TC: 'Turks and Caicos Islands'.t(),
        TV: 'Tuvalu'.t(),
        UG: 'Uganda'.t(),
        UA: 'Ukraine'.t(),
        AE: 'United Arab Emirates'.t(),
        GB: 'United Kingdom'.t(),
        US: 'United States'.t(),
        UM: 'United States Minor Outlying Islands'.t(),
        UY: 'Uruguay'.t(),
        UZ: 'Uzbekistan'.t(),
        VU: 'Vanuatu'.t(),
        VE: 'Venezuela, Bolivarian Republic of'.t(),
        VN: 'Viet Nam'.t(),
        VG: 'Virgin Islands, British'.t(),
        VI: 'Virgin Islands, U.S.'.t(),
        WF: 'Wallis and Futuna'.t(),
        EH: 'Western Sahara'.t(),
        YE: 'Yemen'.t(),
        ZM: 'Zambia'.t(),
        ZW: 'Zimbabwe'.t(),
    },
    country: function( value ) {
        if(Ext.isEmpty(value)) {
            return '';
        }
        return Ext.String.format(
                Renderer.mapValueFormat,
                ( value in Renderer.countryMap ) ? Renderer.countryMap[value] : Renderer.countryMap['default'],
                value
        );
    },

    quotaActionMap: {
        1: 'Given'.t(),
        2: 'Exceeded'.t(),
        default: 'Unknown'.t()
    },
    quotaAction: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return Ext.String.format(
                Renderer.mapValueFormat,
                ( value in Renderer.quotaActionMap ) ? Renderer.quotaActionMap[value] : Renderer.quotaActionMap['default'],
                value
        );
    },

    captivePortalEventInfoMap: {
        LOGIN: 'Login Success'.t(),
        FAILED: 'Login Failure'.t(),
        TIMEOUT: 'Session Timeout'.t(),
        INACTIVE: 'Idle Timeout'.t(),
        USER_LOGOUT: 'User Logout'.t(),
        ADMIN_LOGOUT: 'Admin Logout'.t(),
        HOST_CHANGE: 'Host Change Logout'.t(),
        default: 'Unknown'.t()
    },
    captivePortalEventInfo: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return ( value in Renderer.captivePortalEventInfoMap ) ? Renderer.captivePortalEventInfoMap[value] : Renderer.captivePortalEventInfoMap['default'];
    },

    authTypeMap: {
        NONE: 'None'.t(),
        LOCAL_DIRECTORY: 'Local Directory'.t(),
        ACTIVE_DIRECTORY: 'Active Directory'.t(),
        RADIUS: 'RADIUS'.t(),
        GOOGLE: 'Google Account'.t(),
        MICROSOFT: 'Microsoft Account'.t(),
        CUSTOM: 'Custom'.t(),
        default: 'Unknown'.t()
    },
    authType: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return ( value in Renderer.authTypeMap ) ? Renderer.authTypeMap[value] : Renderer.authTypeMap['default'];
    },

    configurationBackupSuccessMap:{
        true: 'success'.t(),
        default: 'failed'.t()
    },
    configurationBackupSuccess: function( value ){
        return ( value in Renderer.configurationBackupSuccessMap ) ? Renderer.configurationBackupSuccessMap[value] : Renderer.configurationBackupSuccessMap['default'];
    },

    loginReasonMap : {
        U:'invalid username'.t(),
        P: 'invalid password'.t(),
        T: 'invalid TOTP'.t(),
        I: 'logged in successfully'.t(),
        O: 'logged out successfully'.t(),
        default: ''

    },
    loginReason: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return ( value in Renderer.loginReasonMap ) ? Renderer.loginReasonMap[value] : Renderer.loginReasonMap['default'];
    },

    loginSuccess: function( value ){
        return value ?  'success'.t() : 'failed'.t();
    },

    loginFrom: function( value ){
        return value ?  'local'.t() : 'remote'.t();
    },

    directoryConnectorActionMap: {
        I: 'login'.t(),
        U: 'update'.t(),
        O: 'logout'.t(),
        A: 'authenticate'.t(),
        default: 'unknown'.t()

    },
    directoryConnectorAction: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return ( value in Renderer.directoryConnectorActionMap ) ? Renderer.directoryConnectorActionMap[value] : Renderer.directoryConnectorActionMap['default'];
    },

    directoryConnectorActionSourceMap: {
        W: 'client'.t(),
        A: 'active directory'.t(),
        R: 'radius'.t(),
        T: 'test'.t(),
        default: 'unknown'.t()

    },
    directoryConnectorActionSource: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return ( value in Renderer.directoryConnectorActionSourceMap ) ? Renderer.directoryConnectorActionSourceMap[value] : Renderer.directoryConnectorActionSourceMap['default'];
    },

    adBlockerActionMap:{
        B: 'block'.t(),
        default: 'pass'.t()
    },
    adBlockerAction: function( value ){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return ( value in Renderer.adBlockerActionMap ) ? Renderer.adBlockerActionMap[value] : Renderer.adBlockerActionMap['default'];
    },

    bandwidthControlRule: function( value ){
        return Ext.isEmpty(value) ? 'none'.t() : value;
    },

    emailActionMap: {
        P: 'pass message'.t(),
        M: 'mark message'.t(),
        D: 'drop message'.t(),
        B: 'block message'.t(),
        Q: 'quarantine message'.t(),
        S: 'pass safelist message'.t(),
        Z: 'pass oversize message'.t(),
        O: 'pass outbound message'.t(),
        F: 'block message (scan failure)'.t(),
        G: 'pass message (scan failure)'.t(),
        Y: 'block message (greylist)'.t(),
        default:  'unknown action'.t()
    },
    emailAction: function(value){
        if(Ext.isEmpty(value)) {
            return '';
        }
        return Ext.String.format(
                Renderer.mapValueFormat,
                ( value in Renderer.emailActionMap ) ? Renderer.emailActionMap[value] : Renderer.emailActionMap['default'],
                value
        );
    },
    tagsFilterText: function(tags){
        if(tags.list && tags.list.length > 0){
            var tagsList = [];
            tagsList = Ext.Array.map(tags.list, function (tag){
                return tag.name.trim() ? tag.name.trim() : "";
            });
            return tagsList.length > 0 ? tagsList.join(" ") : "";
        }
        return "";
    },
    renderBps : function(val, metaData, record) {
        if(val && val > 0){
            var value = Util.bytesRenderer(val,true);
            metaData.tdAttr = 'data-qtip="' + value + '"';
            return value;
        }
        return '<span style="color: #CCC">0</span>';
    } 
});
/**
 * new renderer Class
 * should replace the current Renderer.js (still kept for backward compatibility)
 *
 * renderers are used when a specific value needs to be represented in a different way
 * or some styles/markup are applied to the value
 * e.g. bytes rendered as Kb, Mb etc...
 * the sorting/filtering still remains done by the bytes value,
 * the value is just represented in a more user readable way
 */
Ext.define('Ung.util.Rndr', {
    singleton: true,
    alternateClassName: 'Rndr',

    // predefine columns widths, to add more
    colW: {
        boolean: 80
    },

    // columns filter types
    filters: {
        boolean: { type: 'boolean', yesText: 'true'.t(), noText: 'false'.t() },
        numeric: { type: 'numeric' },
        string: { type: 'string' },
        date: { type: 'date' },
    },


    boolean: function (value) {
        return (value == true || value == 'true') ? 'true' : 'false';
    },

    memory: function (value) {
        var meg = value/1024/1024;
        return (Math.round( meg*10 )/10).toString() + ' MB';
    },

    disk: function (value) {
        var gig = value/1024/1024/1024;
        return (Math.round( gig*10 )/10).toString() + ' GB';
    },

    localLogin: function (value) {
        return value ? 'local'.t() : 'remote'.t();
    },

    successLogin: function (value) {
        return value ? 'success'.t() : 'failed'.t();
    },

    settingsFile: function (value) {
        value = value.replace( /^.*\/settings\//, '' );
        value = value.replace( /^.*\/conf\//, '' );
        return value;
    },

    adBlockerAction: function (value) {
        if (Ext.isEmpty(value)) { return ''; }
        if (value === 'B') {
            return 'block'.t();
        }
        return 'pass'.t();
    },

    // use renderer because have to be sorted by value and not by text
    priority: function (value) {
        return Map.priorities[value] || value;
    },

    bandwidthControlRule: function (value) {
        return value || 'none'.t();
    },

    datasize: function (value) {
        var sizes = [
                [ 1125899906842624, 'PB'.t() ],
                [ 1099511627776, 'TB'.t() ],
                [ 1073741824, 'GB'.t() ],
                [ 1048576, 'MB'.t() ] ,
                [ 1024, 'KB'.t() ],
                [ 1, 'B'.t() ]
            ],
            size = sizes[sizes.length-1];

        if (value === null) { value = 0; }
        value = parseInt( value, 10 );
        for (var i = 0; i < sizes.length; i++){
            size = sizes[i];
            if (value >= size[0] || value <= (0-size[0])){
                break;
            }
        }
        if ((value == 0 ) || (size[0] == 1)){
            return value + ' ' + size[1];
        } else {
            var dividedValue = (value / size[0]).toFixed(2).toString();
            if (dividedValue.substring(dividedValue.length - 3) == '.00') {
                dividedValue = dividedValue.substring(0, dividedValue.length - 3);
            }
            return dividedValue + ' ' + size[1];
        }
    },


});
/**
 * Rpc connectivity brain
 */
Ext.define('Ung.util.Rpc', {
    alternateClassName: 'Rpc',
    singleton: true,

    /**
     * With the full rpc path and arguments, verify that each node and the target method exists.
     *
     * The first argument can be an already resolved RPC path.  If this is the case, then the
     * second argument is the string path and subsequent arguments are arguments to that path mthod.
     *
     * If path does not exist, return null.
     * Otherwise, return an object containing:
     *  context The object to execute.
     *  args    Arguments to execute in the context.
     */
    getCommand: function() {
        var path = arguments[0],
            args, nodes,
            method = null, context,
            result = {
                context: null,
                args: null,
                error: null
            };

        if(path === undefined){
            result.error = "Null path or rpc object";
            return result;
        }else if(typeof(path) === 'object'){
            args = [].slice.call(arguments).splice(2);
            context = arguments[0];
            path = arguments[1];
        }else{
            args = [].slice.call(arguments).splice(1);
            context = window;
        }
        nodes = path.split('.');
        method = nodes.pop();

        if ( context == null || arguments[0] == null ) {
            result.error = "Invalid RPC path: '" + path + "'";
            return result;
        }

        var len = nodes.length;
        for (var i = 0; i < len ; i++) {
            if (context == null ){
                break;
            }
            var node = nodes[i];

            if(node.indexOf('(') > -1 && node.indexOf(')') > -1){
                // Handle this context with arguments, such as finding an app by its name.

                // Extract argument list from within parens.
                var cargsList=node.substring(node.indexOf('(') + 1, node.indexOf(')') ).split(',');
                var cargs = [];
                cargsList.forEach(function(carg){
                    if(carg[0] == '"' && carg[carg.length-1] == '"'){
                        // Strip quotes around argument.
                        carg=carg.substring(1,carg.length-1);
                    }
                    if(carg.trim().length > 0){
                        cargs.push(carg);
                    }
                });

                // Pull the method.
                node = node.substring(0, node.indexOf('('));
                if(context[node] == null){
                    break;
                }
                context = context[node].apply(null,cargs);
            }else{
                if(Ext.isFunction(context[node])){
                    context = context[node].apply(null,null);
                }else{
                    context = context[node];
                }
            }
            if(context == null){
                result.error = "Invalid RPC path: '" + path + "' Attribute '" + node + "' is null";
                return result;
            }
        }

        if (method && !context.hasOwnProperty(method) ){
            result.error = "No such RPC property or method: '" + path + "'";
            return result;
        }else if(method && !Ext.isFunction(context[method]) && args.length > 0){
            result.error = "RPC property requsted but arguments : '" + path + "'";
            return result;
        }else if(method){
            result.context = context[method];
            result.args = args;
        }else{
            result.context = context;
            result.args = args;
        }

        return result;
    },

    /**
     * If we get an exception from within a deferred, we need to handlee it manually
     * here.
     *
     * Also look for certain known JSONRpc exceptions that we just cand do from getCommand
     * and try to clarify them:
     *     -    "method not found" almost certainly means that we have an argument mismatch.
     *
     * @param  dfrd Deferred object.
     * @param  ex   Exception.
     */
    processException: function(dfrd, ex, handle){
        if( typeof(ex) == 'object'){
            if(ex.message && ex.message.indexOf("method not found") > -1){
                ex.message = "possible argument count mis-match: " + ex.message;
            }
        }
        if(dfrd){
            dfrd.reject(ex);
        }
        if(handle){
            console.log(ex);
            Util.handleException(ex.toString());
        }
    },

    exists: function(){
        var commandResult = this.getCommand.apply(null, arguments);
        if(commandResult.context == null || commandResult.context.error){
            return false;
        }
        return true;
    },

    /**
     * Make RPC call as a deferred function and return promise.
     */
    asyncData: function() {
        var commandResult = this.getCommand.apply(null, arguments);
        if(commandResult.context != null && !Ext.isFunction(commandResult.context)){
            // Asynchronously getting a property doesn't make any sense without writing
            // an anonymoys function to handle it.  Don't allow it.
            return Ext.Deferred.rejected("Path '" + arguments[0] + "' is not a function, use a direct method instead");
        }

        if(commandResult.context == null){
            return Ext.Deferred.rejected(commandResult.error);
        }else{
            var dfrd = new Ext.Deferred();
            commandResult.args.unshift(function (result, ex) {
                if (ex) {
                    Rpc.processException(dfrd, ex, true);
                }
                dfrd.resolve(result);
            });

            commandResult.context.apply(null, commandResult.args);
            return dfrd.promise;
        }
    },

    /**
     * Make RPC call and return the results.
     */
    directData: function() {
        var commandResult = this.getCommand.apply(null, arguments);
        if(commandResult.context == null){
            Util.handleException(commandResult.error.toString());
            throw(commandResult.error);
        }

        try {
            return  Ext.isFunction(commandResult.context) ? commandResult.context.apply(null, commandResult.args) : commandResult.context;
        } catch (ex) {
            Rpc.processException(null, ex, true);
        }
        return null;
    },

    /**
     * Return a function containing the RPC call in a deferred function that will return a promise.
     * Suitable for calling in a sequence.
     */
    asyncPromise: function() {
        var commandResult = this.getCommand.apply(null, arguments);

        if(commandResult.context != null && !Ext.isFunction(commandResult.context)){
            // Asynchronously getting a property doesn't make any sense without writing
            // an anonymous function to handle it.  Don't allow it.
            return Ext.Deferred.rejected("Path '" + arguments[0] + "' is not a function, use a direct method instead");
        }

        if(commandResult.context == null){
            return Ext.Deferred.rejected(commandResult.error);
        }else{
            return function() {
                var dfrd = new Ext.Deferred();
                commandResult.args.unshift(function (result, ex) {
                    if (ex) {
                        Rpc.processException(dfrd, ex, true);
                    }
                    dfrd.resolve(result);
                });
                commandResult.context.apply(null, commandResult.args);
                return dfrd.promise;
            };
        }
    },

    /**
     * Return a function containing the RPC call in a deferred function that will return a promise.
     * Suitable for calling in a sequence.
     */
    directPromise: function() {
        var commandResult = this.getCommand.apply(null, arguments);
        if(commandResult.context == null){
            return Ext.Deferred.rejected(commandResult.error);
        }else{
            return function() {
                var dfrd = new Ext.Deferred();
                try {
                    dfrd.resolve( Ext.isFunction(commandResult.context) ? commandResult.context.apply(null, commandResult.args) : commandResult.context );
                } catch (ex) {
                    Rpc.processException(dfrd, ex, false);
                }
                return dfrd.promise;
            };
        }
    }
});
Ext.define('Ung.util.Util', {
    alternateClassName: 'Util',
    singleton: true,
    ignoreExceptions: false,

    ACTION_EVENTS: {
        REFRESH_NETWORK_SETTINGS: 'REFRESH_NETWORK_SETTINGS',
        REFRESH_SYSTEM_SETTINGS: 'REFRESH_SYSTEM_SETTINGS'
    },

    // defaultColors: ['#7cb5ec', '#434348', '#90ed7d', '#f7a35c', '#8085e9', '#f15c80', '#e4d354', '#2b908f', '#f45b5b', '#91e8e1'],
    defaultColors: ['#00b000', '#3030ff', '#009090', '#00ffff', '#707070', '#b000b0', '#fff000', '#b00000', '#ff0000', '#ff6347', '#c0c0c0'], // from old UI

    baseCategories: [
        { name: 'hosts', type: 'system', displayName: 'Hosts', viewPosition: 1 },
        { name: 'devices', type: 'system', displayName: 'Devices', viewPosition: 2 },
        { name: 'users', type: 'system', displayName: 'Users', viewPosition: 3 },
        { name: 'network', type: 'system', displayName: 'Network', viewPosition: 4 },
        { name: 'administration', type: 'system', displayName: 'Administration', viewPosition: 5 },
        { name: 'events', type: 'system', displayName: 'Events', viewPosition: 6 },
        { name: 'system', type: 'system', displayName: 'System',  viewPosition: 7 },
        { name: 'shield', type: 'system', displayName: 'Shield', viewPosition: 8 }
    ],

    appStorage: { },

    appDescription: {
        'web-filter': 'Web Filter scans and categorizes web traffic to monitor and enforce network usage policies.'.t(),
        'web-monitor': 'Web monitor scans and categorizes web traffic to monitor and enforce network usage policies.'.t(),
        'virus-blocker': 'Virus Blocker detects and blocks malware before it reaches users desktops or mailboxes.'.t(),
        'virus-blocker-lite': 'Virus Blocker Lite detects and blocks malware before it reaches users desktops or mailboxes.'.t(),
        'spam-blocker': 'Spam Blocker detects, blocks, and quarantines spam before it reaches users mailboxes.'.t(),
        'spam-blocker-lite': 'Spam Blocker Lite detects, blocks, and quarantines spam before it reaches users mailboxes.'.t(),
        'phish-blocker': 'Phish Blocker detects and blocks phishing emails using signatures.'.t(),
        'web-cache': 'Web Cache stores and serves web content from local cache for increased speed and reduced bandwidth usage.'.t(),
        'bandwidth-control': 'Bandwidth Control monitors, manages, and shapes bandwidth usage on the network'.t(),
        'ssl-inspector': 'SSL Inspector allows for full decryption of HTTPS and SMTPS so that other applications can process the encrypted streams.'.t(),
        'application-control': 'Application Control scans sessions and identifies the associated applications allowing each to be flagged and/or blocked.'.t(),
        'application-control-lite': 'Application Control Lite identifies, logs, and blocks sessions based on the session content using custom signatures.'.t(),
        'captive-portal': 'Captive Portal allows administrators to require network users to complete a defined process, such as logging in or accepting a network usage policy, before accessing the internet.'.t(),
        'firewall': 'Firewall is a simple application that flags and blocks sessions based on rules.'.t(),
        'threat-prevention': 'Threat Prevention flags and blocks sessions based on rules that match IP address and URL historical statistics.'.t(),
        'ad-blocker': 'Ad Blocker blocks advertising content and tracking cookies for scanned web traffic.'.t(),
        'reports': 'Reports records network events to provide administrators the visibility and data necessary to investigate network activity.'.t(),
        'policy-manager': 'Policy Manager enables administrators to create different policies and handle different sessions with different policies based on rules.'.t(),
        'directory-connector': 'Directory Connector allows integration with external directories and services, such as Active Directory, RADIUS, or Google.'.t(),
        'wan-failover': 'WAN Failover detects WAN outages and re-routes traffic to any other available WANs to maximize network uptime.'.t(),
        'wan-balancer': 'WAN Balancer spreads network traffic across multiple internet connections for better performance.'.t(),
        'ipsec-vpn': 'IPsec VPN provides secure network access and tunneling to remote users and sites using IPsec, GRE, L2TP, Xauth, and IKEv2 protocols.'.t(),
        'wireguard-vpn': 'WireGuard VPN provides secure network access and tunneling to remote users and sites using the WireGuard VPN protocol.'.t(),
        'openvpn': 'OpenVPN provides secure network access and tunneling to remote users and sites using the OpenVPN protocol.'.t(),
        'tunnel-vpn': 'Tunnel VPN provides connectivity through encrypted tunnels to remote VPN servers and services.'.t(),
        'dynamic-blocklists': 'Dynamic Blocklists provides blocking on added urls which have IPS.'.t(),
        'intrusion-prevention': 'Intrusion Prevention blocks scans, detects, and blocks attacks and suspicious traffic using signatures.'.t(),
        'configuration-backup': 'Configuration Backup automatically creates backups of settings uploads them to My Account and Google Drive.'.t(),
        'branding-manager': 'The Branding Settings are used to set the logo and contact information that will be seen by users (e.g. reports).'.t(),
        'live-support': 'Live Support provides on-demand help for any technical issues.'.t()
    },

    // adds timezone computation to ensure dates showing in UI are showing actual server date
    serverToClientDate: function (serverDate) {
        if (!serverDate) { return null; }
        return Ext.Date.add(serverDate, Ext.Date.MINUTE, new Date().getTimezoneOffset() + rpc.timeZoneOffset / 60000);
    },

    // extracts the timezone computation from UI dates before requesting new data from server
    clientToServerDate: function (clientDate) {
        if (!clientDate) { return null; }
        return Ext.Date.subtract(clientDate, Ext.Date.MINUTE, new Date().getTimezoneOffset() + rpc.timeZoneOffset / 60000);
    },

    getDecryptedPassword: function(encryptedPassword){ 
        return rpc.systemManager.getDecryptedPassword(encryptedPassword);
    },

    // returns milliseconds depending of the servlet ADMIN or REPORTS
    getMilliseconds: function () {
        // UvmContext
        if(Rpc.exists('rpc.systemManager')){
            return Rpc.directData('rpc.systemManager.getMilliseconds');
        }
        // ReportsContext
        if(Rpc.exists('rpc.ReportsContext')){
            return Rpc.directData('rpc.ReportsContext.getMilliseconds');
        }
        // otherwise return client millis
        return new Date().getTime();
    },

    humanReadableMap: {
        'P': 1125899906842624,
        'T': 1099511627776,
        'G': 1073741824,
        'M': 1048576,
        'K': 1024
    },
    regexHumanReadable: /([-+]?[0-9]*\.?[0-9]+)\s*(.)/,
    humanReadabletoBytes: function(value){
        var bytes = 0;
        if(this.regexHumanReadable.test(value)){
            var matches = this.regexHumanReadable.exec(value);
            matches[2] = matches[2].toUpperCase();
            if(matches[2] in this.humanReadableMap){
                bytes = parseFloat(matches[1]) * this.humanReadableMap[matches[2].toUpperCase()];
            }
        }
        return bytes;
    },

    bytesToHumanReadable: function (bytes, si) {
        var thresh = si ? 1000 : 1024;
        if(Math.abs(bytes) < thresh) {
            return bytes + ' B';
        }
        var units = si ? ['kB','MB','GB','TB','PB','EB','ZB','YB'] : ['KiB','MiB','GiB','TiB','PiB','EiB','ZiB','YiB'];
        var u = -1;
        do {
            bytes /= thresh;
            ++u;
        } while(Math.abs(bytes) >= thresh && u < units.length - 1);
        return bytes.toFixed(1)+' '+units[u];
    },

    formatBytes: function (bytes, decimals) {
        if (bytes === 0) {
            return '0';
        }
        //bytes = bytes * 1000;
        var k = 1000, // or 1024 for binary
            dm = decimals || 3,
            sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
            i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    },

    bytesRenderer: function(bytes, perSecond) {
        var units = (!perSecond) ? ['bytes'.t(), 'Kbytes'.t(), 'Mbytes'.t(), 'Gbytes'.t(), 'Tbytes'.t(), 'Pbytes'.t(), 'Ebytes'.t(), 'Zbytes'.t(), 'Ybytes'.t()] :
            ['bytes/s'.t(), 'Kbytes/s'.t(), 'Mbytes/s'.t(), 'Gbytes/s'.t(), 'Tbytes/s'.t(), 'Pbytes/s'.t(), 'Ebytes/s'.t(), 'Zbytes/s'.t(), 'Ybytes/s'.t()];
        var units_itr = 0;
        while ((bytes >= 1000 || bytes <= -1000) && units_itr < 8) {
            bytes = bytes/1000;
            units_itr++;
        }
        bytes = Math.round(bytes*100)/100;
        return bytes + ' ' + units[units_itr];
    },
    bytesRendererCompact: function(bytes) {
        var units = ['', 'K', 'M', 'G'];
        var units_itr = 0;
        while ((bytes >= 1000 || bytes <= -1000) && units_itr < 3) {
            bytes = bytes/1000;
            units_itr++;
        }
        bytes = Math.round(bytes*100)/100;
        return bytes + ' ' + units[units_itr];
    },

    successToast: function (message) {
        Ext.toast({
            html: '<i class="fa fa-check fa-lg"></i> ' + message,
            // minWidth: 200,
            bodyPadding: '12 12 12 40',
            baseCls: 'toast',
            border: false,
            bodyBorder: false,
            // align: 'b',
            align: 'br',
            autoCloseDelay: 5000,
            slideInAnimation: 'easeOut',
            slideInDuration: 300,
            hideDuration: 0,
            paddingX: 10,
            paddingY: 50
        });
    },

    showWarningMessage:function(message, details, errorHandler) {
        var wnd = Ext.create('Ext.window.Window', {
            title: 'Warning'.t(),
            modal:true,
            closable:false,
            layout: "fit",
            setSizeToRack: function () {
                if(Ung.Main && Ung.Main.viewport) {
                    var objSize = Ung.Main.viewport.getSize();
                    objSize.height = objSize.height - 66;
                    this.setPosition(0, 66);
                    this.setSize(objSize);
                } else {
                    this.maximize();
                }
            },
            doSize: function() {
                var detailsComp = this.down('fieldset[name="details"]');
                if(!detailsComp.isHidden()) {
                    this.setSizeToRack();
                } else {
                    this.center();
                }
            },
            items: {
                xtype: "panel",
                minWidth: 350,
                autoScroll: true,
                defaults: {
                    border: false
                },
                items: [{
                    xtype: "fieldset",
                    padding: 10,
                    items: [{
                        xtype: "label",
                        html: message,
                    }]
                }, {
                    xtype: "fieldset",
                    hidden: (typeof(interactiveMode) != "undefined" && interactiveMode == false),
                    items: [{
                        xtype: "button",
                        name: "details_button",
                        text: "Show details".t(),
                        hidden: details==null,
                        handler: function() {
                            var detailsComp = wnd.down('fieldset[name="details"]');
                            var detailsButton = wnd.down('button[name="details_button"]');
                            if(detailsComp.isHidden()) {
                                wnd.initialHeight = wnd.getHeight();
                                wnd.initialWidth = wnd.getWidth();
                                detailsComp.show();
                                detailsButton.setText('Hide details'.t());
                                wnd.setSizeToRack();
                            } else {
                                detailsComp.hide();
                                detailsButton.setText('Show details'.t());
                                wnd.restore();
                                wnd.setHeight(wnd.initialHeight);
                                wnd.setWidth(wnd.initialWidth);
                                wnd.center();
                            }
                        },
                        scope : this
                    }]
                }, {
                    xtype: "fieldset",
                    name: "details",
                    hidden: true,
                    html: details!=null ? details : ''
                }]
            },
            buttons: [{
                text: 'OK'.t(),
                hidden: (typeof(interactiveMode) != "undefined" && interactiveMode == false),
                handler: function() {
                    if ( errorHandler) {
                        errorHandler();
                    } else {
                        wnd.close();
                    }
                }
            }]
        });
        wnd.show();
        if(Ext.MessageBox.rendered) {
            Ext.MessageBox.hide();
        }
    },

    goToStartPage: function () {
        Ext.MessageBox.wait("Redirecting to the start page...".t(), "Please wait".t());
        location.reload();
    },

    isServerConnectionLost: function (exception) {
        return exception.code == 550 || exception.code == 12029 || exception.code == 12019 || exception.code == 0 ||
        /* handle connection lost (this happens on windows only for some reason) */
        (exception.name == 'JSONRpcClientException' && exception.fileName != null && exception.fileName.indexOf('jsonrpc') != -1) ||
        /* special text for "method not found" and "Service Temporarily Unavailable" */
        (exception.message && exception.message.indexOf('method not found') != -1) ||
        (exception.message && exception.message.indexOf('Service Unavailable') != -1) ||
        (exception.message && exception.message.indexOf('Service Temporarily Unavailable') != -1) ||
        (exception.message && exception.message.indexOf('This application is not currently available') != -1);
    },

    handleException: function (exception) {
        if (Util.ignoreExceptions)
            return;

        var message = null;
        var details = "";

        if ( !exception ) {
            console.error("Null Exception!");
            return;
        } else {
            console.error(exception);
            if( typeof exception == "object" ){
                if(Rpc.exists('rpc.UvmContext')){
                    // This is the best way to log exceptions.  Sending through the Rpc object
                    // would require a special case to not show the exception again.
                    rpc.UvmContext.logJavascriptException(function (result, ex) {}, JSON.parse(JSON.stringify(exception, Object.getOwnPropertyNames(exception))));
                }
            }
        }

        if ( exception.javaStack )
            exception.name = exception.javaStack.split('\n')[0]; //override poor jsonrpc.js naming
        if ( exception.name )
            details += "<b>" + "Exception name".t() +":</b> " + exception.name + "<br/><br/>";
        if ( exception.code )
            details += "<b>" + "Exception code".t() +":</b> " + exception.code + "<br/><br/>";
        if ( exception.message )
            details += "<b>" + "Exception message".t() + ":</b> " + exception.message.replace(/\n/g, '<br/>') + "<br/><br/>";
        if ( exception.javaStack )
            details += "<b>" + "Exception java stack".t() +":</b> " + exception.javaStack.replace(/\n/g, '<br/>') + "<br/><br/>";
        if ( exception.stack )
            details += "<b>" + "Exception js stack".t() +":</b> " + exception.stack.replace(/\n/g, '<br/>') + "<br/><br/>";
        if ( rpc.fullVersionAndRevision != null )
            details += "<b>" + "Build".t() +":&nbsp;</b>" + rpc.fullVersionAndRevision + "<br/><br/>";
        details +="<b>" + "Timestamp".t() +":&nbsp;</b>" + (new Date()).toString() + "<br/><br/>";
        if ( exception.response )
            details += "<b>" + "Exception response".t() +":</b> " + Ext.util.Format.stripTags(exception.response).replace(/\s+/g,'<br/>') + "<br/><br/>";

        /* handle authorization lost */
        if( exception.response && exception.response.includes("loginPage") ) {
            message  = "Session timed out.".t() + "<br/>";
            message += "Press OK to return to the login page.".t() + "<br/>";
            Util.ignoreExceptions = true;
            Util.showWarningMessage(message, details, Util.goToStartPage);
            return;
        }

        /* handle connection lost */
        if( Util.isServerConnectionLost(exception)) {
            message  = "The connection to the server has been lost.".t() + "<br/>";
            message += "Press OK to return to the login page.".t() + "<br/>";
            Util.ignoreExceptions = true;
            Util.showWarningMessage(message, details, Util.goToStartPage);
            return;
        }

        Util.exceptionToast(exception);
    },

    exceptionToast: function (ex) {
        var msg = [];
        if (typeof ex === 'object') {
            if (ex.name && ex.code) {
                msg.push('<strong>Name:</strong> ' + ex.name + ' (' + ex.code + ')');
            }
            if (ex.ex) {
                msg.push('<strong>Error:</strong> ' + ex.ex);
            }
            if (ex.message) {
                msg.push('<strong>Message:</strong> ' + ex.message);
            }
        } else {
            msg = [ex];
        }
        Ext.toast({
            html: '<i class="fa fa-exclamation-triangle fa-lg"></i> <span style="font-weight: bold; color: yellow;">Exception!</span><br/>' + msg.join('<br/>'),
            bodyPadding: '10 10 10 45',
            baseCls: 'toast',
            cls: 'exception',
            border: false,
            bodyBorder: false,
            align: 'br',
            autoCloseDelay: 5000,
            slideInAnimation: 'easeOut',
            slideInDuration: 300,
            hideDuration: 0,
            paddingX: 10,
            paddingY: 50
        });
    },

    invalidFormToast: function (fields) {
        if (!fields || fields.length === 0) {
            return;
        }

        var str = [];
        fields.forEach(function (field) {
            str.push('<span class="field-name">' + field.label + '</span>: <br/> <span class="field-error">' + field.error.replace(/<\/?[^>]+(>|$)/g, '') + '</span>');
        });

        // var store = [];
        // fields.forEach(function (field) {
        //     console.log(field);
        //     store.push({ label: field.getFieldLabel(), error: field.getActiveError().replace(/<\/?[^>]+(>|$)/g, ''), field: field });
        // });

        Ext.toast({
            html: '<i class="fa fa-exclamation-triangle fa-lg"></i> <span style="font-weight: bold; font-size: 14px; color: yellow;">Check invalid fields!</span><br/><br/>' + str.join('<br/>'),
            bodyPadding: '10 10 10 45',
            baseCls: 'toast-invalid-frm',
            border: false,
            bodyBorder: false,
            align: 'br',
            autoCloseDelay: 5000,
            slideInAnimation: 'easeOut',
            slideInDuration: 300,
            hideDuration: 0,
            paddingX: 10,
            paddingY: 50
            // items: [{
            //     xtype: 'dataview',
            //     store: {
            //         data: store
            //     },
            //     tpl:     '<tpl for=".">' +
            //         '<div style="margin-bottom: 10px;">' +
            //         '<span class="field-name">{label}</span>:' +
            //         '<br/><span>{error}</span>' +
            //         '</div>' +
            //     '</tpl>',
            //     itemSelector: 'div',
            //     listeners: {
            //         select: function (el, field) {
            //             field.get('field').focus();
            //         }
            //     }
            // }]
        });
    },

    // This is called a lot of times when initializing condition sets for rules.
    // Previously we loaded network settings for each call.  Now we do it once and
    // only refresh after 30 seconds since the last build.
    interfaceList: null,
    interfaceLastUpdated: null,
    interfaceMaxAge: 30 * 1000,
    getInterfaceList: function (wanMatchers, anyMatcher) {

        var currentTime = new Date().getTime();
        if (this.interfaceList === null ||
            this.interfaceLastUpdated === null ||
            ( ( this.interfaceLastUpdated + this.interfaceMaxAge ) < currentTime ) ){
            this.interfaceLastUpdated = currentTime;
            var networkSettings = Rpc.directData('rpc.networkSettings'),
                data = [];

            // Note: using strings as keys instead of numbers, needed for the checkboxgroup column widget component to function
            networkSettings.interfaces.list.forEach( function(intf){
                data.push([intf.interfaceId.toString(), intf.name]);
            });
            networkSettings.virtualInterfaces.list.forEach( function(intf){
                data.push([intf.interfaceId.toString(), intf.name]);
            });
            data.push(['ipsec', "IPsec VPN".t()]);
            this.interfaceList = data;
        }
        var interfaces = Ext.clone(this.interfaceList);

        if (wanMatchers) {
            interfaces.unshift(['wan', 'Any WAN'.t()]);
            interfaces.unshift(['non_wan', 'Any Non-WAN'.t()]);
        }
        if (anyMatcher) {
            interfaces.unshift(['any', 'Any'.t()]);
        }
        return interfaces;
    },

    /**
     * Method to get list of LAN Interface IP's
     * @return List of LAN IP's from network settings based on onlyTcpUdp flag value.
     */
    lanIpList: null,
    lanIpLastUpdated: null,
    lanIpMaxAge: 30 * 1000,
    getLanIpAddrs: function() {
        var currentTime = new Date().getTime();
        
        if (this.lanIpList === null ||
            this.lanIpLastUpdated === null ||
            ((this.lanIpLastUpdated + this.lanIpMaxAge) < currentTime)){
                this.lanIpLastUpdated = currentTime;
                var networkSettings = Rpc.directData('rpc.networkSettings'),
                    data = [];

                networkSettings.interfaces.list.forEach( function(intf){
                    if(!intf.isWan && intf.v4StaticAddress) {
                        data.push(intf.v4StaticAddress);
                    }
                });
                networkSettings.virtualInterfaces.list.forEach( function(intf){
                    if(!intf.isWan && intf.v4StaticAddress) {
                        data.push(intf.v4StaticAddress);
                    }
                });
                this.lanIpList = data;
        }
        var lanIps = Ext.clone(this.lanIpList);
        return lanIps;
    },

    bytesToMBs: function(value) {
        return Math.round(value/10000)/100;
    },

    urlValidator: function (val) {
        var res = val.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,63}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
        return res ? true : 'Url missing or in wrong format!'.t();
    },

    ipValidator: function (val) {
        var res = val.match(/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/);
        return res ? true : 'Url missing or in wrong format!'.t();
    },

    networkValidator: function (value){
        return value == '0.0.0.0/0' ? "Invalid Network".t() : true;
    },

    urlIpValidator: function (val) {
        if (Util.urlValidator(val) === true) {
            return true;
        } else {
            if (Util.ipValidator(val) === true) {
                return true;
            }
        }
        return 'Url missing or in wrong format!'.t();
    },

    /**
     * Helper method that lists the order in which classes are loaded
     */
    getClassOrder: function () {
        var classes = [], extClasses = [];

        Ext.Loader.history.forEach(function (cls) {
            if (cls.indexOf('Ung') === 0) {
                classes.push(cls.replace('Ung', 'app').replace(/\./g, '/') + '.js');
            } else {
                extClasses.push(cls);
            }
        });

        classes.pop();

        Ext.create('Ext.Window', {
            title: 'Untangle Classes Load Order',
            width: 600,
            height: 600,

            // Constraining will pull the Window leftwards so that it's within the parent Window
            modal: true,
            draggable: false,
            resizable: false,
            layout: {
                type: 'hbox',
                align: 'stretch',
                pack: 'end'
            },
            items: [{
                xtype: 'textarea',
                border: false,
                flex: 1,
                editable: false,
                fieldStyle: {
                    background: '#FFF',
                    fontSize: '11px'
                },
                value: classes.join('\r\n')
            }, {
                xtype: 'textarea',
                border: false,
                flex: 1,
                editable: false,
                fieldStyle: {
                    background: '#FFF',
                    fontSize: '11px'
                },
                value: extClasses.join('\r\n')
            }]
        }).show();
    },

    getV4NetmaskList: function(includeNull, excludeZero) {
        var data = [];
        if (includeNull) {
            data.push( [null,'\u00a0'] );
        }
        data.push( [32,'/32 - 255.255.255.255'] );
        data.push( [31,'/31 - 255.255.255.254'] );
        data.push( [30,'/30 - 255.255.255.252'] );
        data.push( [29,'/29 - 255.255.255.248'] );
        data.push( [28,'/28 - 255.255.255.240'] );
        data.push( [27,'/27 - 255.255.255.224'] );
        data.push( [26,'/26 - 255.255.255.192'] );
        data.push( [25,'/25 - 255.255.255.128'] );
        data.push( [24,'/24 - 255.255.255.0'] );
        data.push( [23,'/23 - 255.255.254.0'] );
        data.push( [22,'/22 - 255.255.252.0'] );
        data.push( [21,'/21 - 255.255.248.0'] );
        data.push( [20,'/20 - 255.255.240.0'] );
        data.push( [19,'/19 - 255.255.224.0'] );
        data.push( [18,'/18 - 255.255.192.0'] );
        data.push( [17,'/17 - 255.255.128.0'] );
        data.push( [16,'/16 - 255.255.0.0'] );
        data.push( [15,'/15 - 255.254.0.0'] );
        data.push( [14,'/14 - 255.252.0.0'] );
        data.push( [13,'/13 - 255.248.0.0'] );
        data.push( [12,'/12 - 255.240.0.0'] );
        data.push( [11,'/11 - 255.224.0.0'] );
        data.push( [10,'/10 - 255.192.0.0'] );
        data.push( [9,'/9 - 255.128.0.0'] );
        data.push( [8,'/8 - 255.0.0.0'] );
        data.push( [7,'/7 - 254.0.0.0'] );
        data.push( [6,'/6 - 252.0.0.0'] );
        data.push( [5,'/5 - 248.0.0.0'] );
        data.push( [4,'/4 - 240.0.0.0'] );
        data.push( [3,'/3 - 224.0.0.0'] );
        data.push( [2,'/2 - 192.0.0.0'] );
        data.push( [1,'/1 - 128.0.0.0'] );
        if(!excludeZero) {
            data.push( [0,'/0 - 0.0.0.0'] );
        }

        return data;
    },

    getV4NetmaskMap: function() {
        var map = {}, data = this.getV4NetmaskList();
        data.forEach(function(element) {
            map[element[0]] = element[1].split('-')[1].trim();
        });
        return map;
    },

    validateForms: function (view) {
        var invalidFields = [];

        view.query('[withValidation=true]').forEach(function (form) {
            form.query('field').forEach(function (field) {
                if(field.isHidden()){
                    return;
                }
                if(field.up('*{isHidden()==true}')){
                    return;
                }
                if(field.up().tab && field.up().tab.isHidden() == true ){
                    return;
                }
                if(field.initialConfig.bind && field.$hasBinds == undefined){
                    return;
                }
                if( field.isValid() == false){
                    invalidFields.push({ label: field.getFieldLabel(), error: field.getActiveError() });
                }
            });
        });

        if (invalidFields.length > 0) {
            Util.invalidFormToast(invalidFields);
            return false;
        }
        return true;
    },

    urlValidator2: function (url) {
        if (url.match(/^([^:]+):\/\// ) !== null) {
            return 'Site cannot contain URL protocol.'.t();
        }
        if (url.match(/^([^:]+):\d+\// ) !== null) {
            return 'Site cannot contain port.'.t();
        }
        // strip "www." from beginning of rule
        if (url.indexOf('www.') === 0) {
            url = url.substr(4);
        }
        // strip "*." from beginning of rule
        if (url.indexOf('*.') === 0) {
            url = url.substr(2);
        }
        // strip "/" from the end
        if (url.indexOf('/') === url.length - 1) {
            url = url.substring(0, url.length - 1);
        }
        if (url.trim().length === 0) {
            return 'Invalid URL specified'.t();
        }
        return true;
    },

    // formats a timestamp - expects a timestamp integer or an onject literal with 'time' property
    timestampFormat: function(v) {
        if (!v || typeof v === 'string') {
            return 0;
        }
        var date = new Date();
        if (typeof v === 'object' && v.time) {
            date.setTime(v.time);
        } else {
            date.setTime(v);
        }
        return Ext.util.Format.date(date, 'timestamp_fmt'.t());
    },

    // formats a timestamp as a date
    dateFormat: function(v) {
        if (!v || typeof v === 'string') {
            return 0;
        }
        var date = new Date();
        if (typeof v === 'object' && v.time) {
            date.setTime(v.time);
        } else {
            date.setTime(v);
        }
        return Ext.util.Format.date(date, 'date_fmt'.t());
    },

    getStoreUrl: function(){
        // non API store URL used for links like: My Account, Forgot Password
        return Rpc.directData('rpc.storeUrl').replace('/api/v1', '/store/open.php');
    },

    about: null,
    getAbout: function (forceReload) {
        if (this.about === null) {
            this.about = [
                'uid=' + Rpc.directData('rpc.serverUID'),
                "version=" + Rpc.directData('rpc.fullVersion'),
                "webui=true",
                "lang=" + Rpc.directData('rpc.languageSettings.language'),
                "applianceModel=" + Rpc.directData('rpc.applianceModel'),
                "installType=" + Rpc.directData('rpc.installType')
            ].join('&');
        }
        return this.about;
    },

    weekdaysMap: {
        '1': 'Sunday'.t(),
        '2': 'Monday'.t(),
        '3': 'Tuesday'.t(),
        '4': 'Wednesday'.t(),
        '5': 'Thursday'.t(),
        '6': 'Friday'.t(),
        '7': 'Saturday'.t()
    },

    keyStr : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",

    base64encode: function(input) {
        if (typeof(base64encode) === 'function') {
            return base64encode(input);
        }
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = Util.utf8Encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
            Util.keyStr.charAt(enc1) + Util.keyStr.charAt(enc2) +
            Util.keyStr.charAt(enc3) + Util.keyStr.charAt(enc4);
        }
        return output;
    },

    utf8Encode : function (string) {
        string = string.replace(/\r\n/g,"\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
        }
        return utftext;
    },

    getLicenseMessage: function (license) {
        var message = '';
        if (!license) {
            return message;
        }
        if (license.trial) {
            if(license.expired) {
                message = 'Free trial expired!'.t();
            } else if (license.daysRemaining < 2) {
                message = 'Free trial.'.t() + ' ' + 'Expires today.'.t();
            } else if (license.daysRemaining < 32) {
                message = 'Free trial.'.t() + ' ' + Ext.String.format('{0} ', license.daysRemaining) + 'days remain.'.t();
            } else {
                message = 'Free trial.'.t();
            }
        } else if (!license.valid) {
            message = license.status;
        }
        return message;
    },

    reloadLicenses: function() {
        Rpc.directData('rpc.UvmContext.licenseManager.reloadLicenses', true);

        Ext.fireEvent('loadUserLicenseMessages');
    },

    activeClone: function(source) {
        // clone the source record which will usually be emptyRow
        var target = Ext.clone(source);
        // look at each item in the source record
        Ext.iterate(source, function(key, value) {
            // look for items in the record that are arrays
            if ( (value !== null) && (typeof(value) === 'object') && (value.length) && (value.length === 2) && (typeof(value[0] === 'string')) ) {
                // found an array so evaluate first string as the function with the second string as the argument and put result in target record
                target[key] = eval(value[0] + "('" + value[1] + "')");
            }
        });
        return(target);
    },

    getAppStorageValue: function(itemName) {
        var data = Ung.util.Util.appStorage[itemName];
        return(data);
    },

    setAppStorageValue: function(itemName, itemValue) {
        Ung.util.Util.appStorage[itemName] = itemValue;
    },

    /**
     * When we make an delayed or async call and then try to manipulate an object in the post-call
     * method, there's a possibility the object will exist but will have been destroyed.
     * For example, go to a form and quickly click away while an RPC call is going on but before
     * the resulting method has been called.  Or just very long backend calls that the user clicks away
     * from out of impatience.  Without this check, subsequent calls to the scoped variables will fail
     * and won't be apparent unless the user has a developer console enabled.
     * This method us used to test any number of objects for the destroyed proprty and returns true if any are.
     */
    isDestroyed: function(){
        for( var i = 0; i < arguments.length; i++){
            if(typeof(arguments[i]) == 'object'){
                if(arguments[i].destroyed){
                    return true;
                }
            }
        }
        return false;
    },

    /**
     * We'd like to have url components encoded so that as much of the original value remains in ASCII
     * format with the following exceptions:
     * 
     * *    spaces replaced with dashes.  Yes, we know this means collisions with legit dashes.
     * *    All other non-ASCII characters url encoded.
     *
     * These are typically specialized cases like report category and titles.
     * 
     * @param  url Url component to ncode.
     * @return url returned as described above.
     */
    urlEncode: function(url){
        var encodedUrl = url.replace(/\s+/g, '-').toLowerCase();
        encodedUrl = Ext.Object.toQueryString({'':encodedUrl}).substr(1);
        return encodedUrl;
    },

    /**
     * Determine if passed IP matches network & netmask.
     * @param  string ip      IP address to test.
     * @param  string network Network in CIDR notation or prefix
     * @param  string netmask Netmask in CIDR notation.
     * @return boolean         true if IP is on network, otherwise false.
     */
    ipMatchesNetwork: function(ip, network, netmask){
        var dots;
        var netmaskInteger = 0;
        if(Number.isInteger(netmask)){
            netmaskInteger = Math.pow(2, 32) - Math.pow(2, 32 - netmask);
        }else{
            dots = netmask.split('.');
            netmaskInteger = ((((((+dots[0])*256)+(+dots[1]))*256)+(+dots[2]))*256)+(+dots[3]);
        }
        dots = network.split('.');
        var networkInteger = ((((((+dots[0])*256)+(+dots[1]))*256)+(+dots[2]))*256)+(+dots[3]);
        dots = ip.split('.');
        var ipInteger = ((((((+dots[0])*256)+(+dots[1]))*256)+(+dots[2]))*256)+(+dots[3]);
        return ((ipInteger & netmaskInteger) == (networkInteger & netmaskInteger) );
    },

    /**
     * Define the styling for global entries. 
     *
     * @param record  The grid record to evaluate.
     * @return Style to apply on global fields.
     */
    getGlobalRowClass: function(record) {
        if (record.phantom === false && record.dirty && !record.get('markedForNew') && record.get('markedForDelete')) {
            return 'mark-delete';
        }
        if (record.get('isGlobal') === true) {
            return 'row-global-locked';
        }
    },

    /**
     * Determines whether the global checkbox for a given grid record should be clickable.
     *
     * @param column  checkBox global column
     * @param rowIndex index of global field
     * @return boolean  Returns false if the 'isGlobal' field is true (i.e., the record is global and should not be edited).
     *                  Returns true if 'isGlobal' is false or not set (i.e., the checkbox can be clicked).
     */
    canToggleGlobalCheckbox: function (column, rowIndex) {
        var grid = column.up('grid');
        var store = column.getGridStore ? column.getGridStore() : grid.getStore();
        var record = store.getAt(rowIndex);
        if (!record) return true;
    
        var modified = record.modified || {};
        var originalValue = modified.hasOwnProperty('isGlobal') ? !record.get('isGlobal') : record.get('isGlobal');
        var canToggleIsGlobal = !(originalValue === true && !modified.hasOwnProperty('isGlobal'));
        if (!canToggleIsGlobal && !record.get('markedForNew')) {
            Ext.MessageBox.alert('Info', '<strong> Global Field </strong> cannot be edited!');
            return false;
        } else {
            return true;
        }
    },

    /**
     * Checks whether a given CIDR block belongs to a private IP address space.
     *
     * Private IP ranges (as defined in RFC 1918) include:
     * - 10.0.0.0/8
     * - 172.16.0.0/12
     * - 192.168.0.0/16
     *
     * @param {string} cidr - The CIDR notation string (e.g., "192.168.1.0/24") to validate.
     * @returns {boolean} - Returns true if the CIDR is within a private IP range; false otherwise.
     *
     * @example
     * isPrivateCIDR("192.168.1.0/24"); // true
     * isPrivateCIDR("8.8.8.0/24");     // false
     */
    isPrivateCIDR: function(cidr) {
        try {
            var parts = cidr.split('/');
            var ip = parts[0].split('.');
            if (ip.length !== 4) return false;
    
            for (var i = 0; i < ip.length; i++) {
                var num = parseInt(ip[i], 10);
                if (isNaN(num) || num < 0 || num > 255) return false;
                ip[i] = num; // Convert to integer for next checks
            }
    
            if (ip[0] === 10) return true;
            if (ip[0] === 172 && ip[1] >= 16 && ip[1] <= 31) return true;
            if (ip[0] === 192 && ip[1] === 168) return true;
    
            return false; // Not private
        } catch (e) {
            return false;
        }
    },
    

    isIPInRange: function (ip, network, netmask) {
        // Split the IP address into octets
        var nextPoolOctets = ip.split('.');
        var networkOctets = network.split('.');
        var netMaskOctets = netmask.split('.');

        // Convert octets to integers
        var networkInt = networkOctets.map(function(octet) { return parseInt(octet, 10); });
        var netmaskInt = netMaskOctets.map(function(octet) { return parseInt(octet, 10); });

        // Calculate the the broadcast address
        var broadcastAddr = networkInt.map(function(octet, index) { return (octet & netmaskInt[index]) | (~netmaskInt[index] & 255); }).join('.');

        // Convert IP addresses to decimals
        var ipInt = Util.convertIPIntoDecimalForEachOctet(ip);
        var broadcastAddress =  Util.convertIPIntoDecimalForEachOctet(broadcastAddr);
        var networkAddress =  Util.convertIPIntoDecimalForEachOctet(network);

        return ipInt > networkAddress && ipInt < broadcastAddress;
    },

    convertIPIntoDecimalForEachOctet: function(ip) {
    
        var octets = ip.split(".");
    
        var decimalValue = 0;
        var powers = [16777216, 65536, 256, 1]; // Powers of 256
    
        for (var i = 0; i < 4; i++) {
            var octet = parseInt(octets[i], 10);
           
            decimalValue += octet * powers[i];
        }
    
        return decimalValue;
    },

    getUnusedPoolAddr: function(addressPool, store, field){
        netMask = Util.getV4NetmaskMap()[addressPool.split('/')[1] ? addressPool.split('/')[1] : 32];
        network = Util.getNetwork(addressPool.split('/')[0], netMask); 
        var nextPoolAddr = Util.incrementIpAddr(addressPool.split('/')[0], 2);
        if(store !==undefined){
            while (Util.isAddrUsed(nextPoolAddr, store, field)) {
                nextPoolAddr = Util.incrementIpAddr(nextPoolAddr, 1);
            }         
        }
        return Util.isIPInRange(nextPoolAddr, network, netMask)? nextPoolAddr : '';
    },

    

    /**
     * From the specified IP address and netmask, return the network.
     * For example, 192.168.1.1/255.255.255.0 returns 192.168.1.0
     * @param {*} ip
     * @param {*} netmask
     */
    getNetwork: function(ip, netmask){
        var dots = netmask.split('.');
        var netmaskInteger = ((((((+dots[0])*256)+(+dots[1]))*256)+(+dots[2]))*256)+(+dots[3]);
        dots = ip.split('.');
        var ipInteger = ((((((+dots[0])*256)+(+dots[1]))*256)+(+dots[2]))*256)+(+dots[3]) & netmaskInteger;
        return ( (ipInteger>>>24) +'.' + (ipInteger>>16 & 255) +'.' + (ipInteger>>8 & 255) +'.' + (ipInteger & 255) );
    },

    /**
     * From the specified IP address and netmask, return the broadcast.
     * For example, 192.168.1.1/255.255.255.0 returns 192.168.1.255
     * @param {*} ip
     * @param {*} netmask
     */
    getBroadcast: function(ip, netmask){
        var network = this.getNetwork(ip, netmask);
        var networkOctets = network.split('.');
        var netMaskOctets = netmask.split('.');

        // Convert octets to integers
        var networkInt = networkOctets.map(function(octet) { return parseInt(octet, 10); });
        var netmaskInt = netMaskOctets.map(function(octet) { return parseInt(octet, 10); });

        // Calculate the the broadcast address
        var broadcastOctets = networkInt.map(function(octet, index) { return (octet & netmaskInt[index]) | (~netmaskInt[index] & 255); });
    
        // Format the broadcast address
        var broadcastAddr = broadcastOctets.join('.');
        return broadcastAddr;
    },

    /**
     * From the specified IP address and netmask, validate the ip.
     * @param {*} ip
     * @param {*} prefix
     */
    isNetworkOrBroadcast: function(ip, prefix) {
        if (prefix === 31) return false;
        var netmask = Util.getV4NetmaskMap()[prefix];
        return ip === Util.getNetwork(ip, netmask) || ip === Util.getBroadcast(ip, netmask);
    },

    /**
     * Increment the passed IP
     * @param  string ip      IP address to increment.
     * @param  int inc        Number to increment by.
     * @return string         Incremented IP address.
     */
    incrementIpAddr: function(ip, inc){
        var dots = ip.split('.');
        var ipInteger = ((((((+dots[0])*256)+(+dots[1]))*256)+(+dots[2]))*256)+(+dots[3])+inc;
        dots = [];
        dots.push(ipInteger >>> 24);
        dots.push((ipInteger >>> 16) % 256);
        dots.push((ipInteger >>> 8) % 256);
        dots.push(ipInteger % 256);
        return dots.join('.');
    },

    /**
     * Loop through the stored records to see if the passed ip address is already used
     * @param  string ip      IP address to be checked.
     * @param  int store      ExtJs store of records
     * @param  int dataIndex  ExtJs dataIndex property of records
     * @return boolean        Returns true if ip already present in dataIndex field of store record.
     */
    isAddrUsed: function(ip, store, dataIndex) {
        var ret = false;
        store.each(function(record,idx) {
            if( record.get(dataIndex) == ip ){
                ret = true;
            }
        });
        return ret;
    },

    /**
     * From the specified store, get modified records and sort any into
     * a changes object that tracks added/deleted records using the specified
     * idField.  Also uses enabledField value to determine.
     * @param store ExtJs store of records.
     * @param string idField Name of identifier field.  Defaults to 'id'
     * @param string enabledField Name of enabled field.  Defaults to 'enabled'.
     * @return object containing arrays of added and deleted records as json strings
     */
    storeGetChangedRecords: function(store, idField, enabledField){
        if(idField == undefined){
            enabledField = 'id';
        }
        if(enabledField == undefined){
            enabledField = 'enabled';
        }
        var changes = {
            added: [],
            deleted: []
        };

        store.getModifiedRecords().forEach(function(record){
            // Get changed and added entries
            var id = record.get(idField);
            var jsonRecord = JSON.stringify(record.data);
            // Build previous record using previous values.
            var jsonPreviousRecord = JSON.parse(JSON.stringify(record.data));
            Ext.Object.each(record.previousValues, function(key, value){
                jsonPreviousRecord[key] = value;
            });
            jsonPreviousRecord = JSON.stringify(jsonPreviousRecord);

            if(id != -1 && changes.deleted.indexOf(jsonPreviousRecord) == -1){
                changes.deleted.push(jsonPreviousRecord);
            }
            if( record.get(enabledField) &&
                ( id == -1 ||
                  changes.added.indexOf(jsonRecord) == -1)){
                changes.added.push(jsonRecord);
            }
        });
        store.getRemovedRecords().forEach(function(record){
            // Deleted entries
            var jsonRecord = JSON.stringify(record.data);
            if(changes.deleted.indexOf(jsonRecord) == -1){
                changes.deleted.push(jsonRecord);
            }
        });
        return changes;
    },

    /**
     * Analyze changes from components with stores (like grids) and return list of 
     * changed values into keys by the components listProperty value.
     * @param Array components  Array of components to review.
     * @param Object viewModel  Object listProperty grouping with objects that contain result from storeGetChangedRecords.
     * @param listFields Object of list key to override id and enabled like {'settings.tunnels.list': { 'enabledField': 'active' } }
     */
    updateListStoresToSettings: function( components, viewModel, listFields){
        var changes = {};
        components.forEach(function(component) {
            var store = component.getStore();
            var listId = component.listProperty;
            // Clear any filters applied on store
            var filters = store.getFilters().clone();
            store.clearFilter(true);
            if(listId == null){
                return;
            }
            var idField = 'id';
            var enabledField = 'enabled';
            if(listFields != undefined){
                if(listId in listFields){
                    if('idField' in listFields[listId]){
                        idField = listFields[listId]['idField'];
                    }
                    if('enabledField' in listFields[listId]){
                        enabledField = listFields[listId]['enabledField'];
                    }
                }
            }
            var values = Ext.Array.pluck(component.getBind().store.getDataObject().getRange(), 'data');
            if (store.getModifiedRecords().length > 0 ||
                store.getNewRecords().length > 0 ||
                store.getRemovedRecords().length > 0 ||
                store.isReordered) {
                var deleted = false;
                store.each(function(record) {
                    if(record.get('peerAddress') === '') {
                        record.set('markedForDelete', true);
                    }

                    if (record.get('markedForDelete')) {
                        record.drop();
                        deleted = true;
                    }
                });
                if(deleted){
                    // Need to pull values again if records were dropped.
                    values = Ext.Array.pluck(component.getBind().store.getDataObject().getRange(), 'data');
                }
                store.isReordered = undefined;
                if(listId == 'settings.tunnels.list' ){
                    // Determine what tunnels have changed.
                    changes[listId] = Util.storeGetChangedRecords(store, idField, enabledField);
                }
            }
            // Strip out ExtJs fields for comparision.
            values.forEach(function(row){
                Ext.Object.each(row, function(key){
                    if(key == '_id'){
                        delete row[key];
                    }
                });
            });
            viewModel.set(listId, values);
            // restore filters after data is processed
            filters.each( function(filter){
                store.addFilter(filter);
            });
        });
        return changes;
    },

    /**
     * From original and current settings objects, determine if settings have changed.
     * If ignoreKeys is non-empty, ignore these fields for the purpsoes of considering the change.
     * @param object originalSettings Original settings.
     * @param object settings current settings
     * @return true if changes, false if nto.
     */
    isSettingsChanged: function(originalSettings, settings, ignoreKeys){
        if(ignoreKeys == undefined){
            ignoreKeys = [];
        }
        var changed = true;
        var compareOriginalSettings = {};
        Ext.Object.each(originalSettings, function(key, value){
            if(ignoreKeys.indexOf(key) == -1){
                compareOriginalSettings[key] = value;
            }
        });
        var compareSettings = {};
        Ext.Object.each(settings, function(key, value){
            if(ignoreKeys.indexOf(key) == -1){
                compareSettings[key] = value;
            }
        });
        return JSON.stringify(compareSettings) != JSON.stringify(compareOriginalSettings);
    },

    /**
     * To compare two IP addresses we need to convert into decimal values,
     * Maximum it can go upto 255 so we will be converting it based upon that
    */
    convertIPIntoDecimal: function (ip) {
        if (!ip) return 0;
        var total = 0;
        var ipElements = ip.split(".");

        for (var i = 0; i < ipElements.length; i++) {
            var octet = parseInt(ipElements[i], 10); // Parse each octet as an integer
            total = total * 256 + octet;
        }

        return total >>> 0; // Ensure the result is an unsigned 32-bit integer
    },

    /**
     * This method finds if any conflict is present in currentIp 
     * with all the existing Ip addresses and returns true or error msg
    */
    findIpPoolConflict:function(currentIpAddress, ipAddressPool, context, currentIpDirtyCheck){
        try{
            var currentFieldIp = currentIpAddress,
                localNetworkStore = ipAddressPool,
                netSpaceAddr = currentFieldIp.split('/')[0],
                netSpacePrefix = currentFieldIp.split('/')[1] ? currentFieldIp.split('/')[1] : 32,
                recValue, recAddr, recPrefix, network, netMask;

            var index = Ext.Array.findBy(localNetworkStore,function(networkRecord) {
                recValue = networkRecord.split('/');
                recAddr = recValue[0]; 
                recPrefix = recValue[1];

                if(netSpacePrefix == recPrefix && netSpaceAddr == recAddr) return true;
                else if(Number(recPrefix) > Number(netSpacePrefix)) {
                    netMask = Util.getV4NetmaskMap()[netSpacePrefix];
                    network = Util.getNetwork(netSpaceAddr, netMask);
                    return Util.ipMatchesNetwork(recAddr, network, netMask);
                } 
                else {
                    netMask = Util.getV4NetmaskMap()[recPrefix];
                    network = Util.getNetwork(recAddr, netMask); 
                    return Util.ipMatchesNetwork(netSpaceAddr, network, netMask);
                }
            });

            if(index !== null) return "Address pool conflict".t();
            //NGFW-14533
            // validation as per fields should be:
            // Peer IP Address Field : Address should not be conflicts with any existing network registrations
            // Local Network Address : Address should not be conflicts with existing address present in list and with Peer IP Address.        
            // Added additional check  (context.xtype === "textarea" ) to verify import, remote networks field 
            if((context.dirty && context.ui === "default") || context.xtype === "textarea" ) {
                var ntwkSpace=null;
                if(currentIpDirtyCheck){
                    ntwkSpace = rpc.UvmContext.netspaceManager().isNetworkAvailable('wireguard-vpn', currentFieldIp.trim());   
                    return !ntwkSpace ? true : "Address pool conflict".t();
                }else{
                    ntwkSpace = null;
                    for(var i=0;i<ipAddressPool.length;i++){
                        ntwkSpace = rpc.UvmContext.netspaceManager().isNetworkAvailable('wireguard-vpn', ipAddressPool[i].trim());
                        if(ntwkSpace){
                            break;
                        }   
                    }
                    return !ntwkSpace ? true : "Address pool conflict".t();
                }
            } else return true;
        }catch(err){
            throw err;
        }
    },

    /**
     * Method to get list of supported protocols
     * @param boolean onlyTcpUdp True if only TCP and UDP traffic is supported.
     * @return List of protocols based on onlyTcpUdp flag value.
     */
    getProtocolList: function(onlyTcpUdp) {
        if(onlyTcpUdp) {
            return [[
                "TCP","TCP"
            ],[
                "UDP","UDP"
            ]];
        } else {
            return [[
                "TCP","TCP"
            ],[
                "UDP","UDP"
            ],[
                "ICMP","ICMP"
            ],[
                "GRE","GRE"
            ],[
                "ESP","ESP"
            ],[
                "AH","AH"
            ],[
                "SCTP","SCTP"
            ],[
                "OSPF","OSPF"
            ]];
        }
    },

    /**
     * Method to check if new value is not exists in current store
     * @param value that has to check for uniqueness.
     * @param form tab for which error has to be shown.
     * @param field against which value has to be validated.
     * @param component current object.
     * @param query grid name to fetch the value of grid.
     * @return boolean if value is validated else error for invalid value.
     */
    isUnique: function(value, form, field, component, query) {
        var currentRecord ;
        if(component.getId().indexOf('textfield') !== -1){
        if(component.up('window')!=undefined)
            currentRecord = component.up('window').getViewModel().data.record.get(field);
        if (value === currentRecord) {
            return true;
        }
        //Return true if editable field peerAddress in grid is not modified
        if(!component.dirty && field === 'peerAddress') {
            return true; 
        }
        }
        var grid = Ext.ComponentQuery.query(query)[0];
        var store = grid.getStore();

        var isNameUnique = store.findBy(function(record) {
            return record.get(field) === value;
        }) === -1;
        
        return isNameUnique? true : Ext.String.format('A {0} with this {1} already exists.'.t(), form, field);
    },

    /**
     * Method to get list of ip addresses and netmasks from remote networks seprated by comma
     * @param remoteNetworks networks in CIDR format seprated by comma.
     * @return List of objects containg Ip and subnetMask of individual network.
     */
    getParsedAddresses: function(remoteNetworks){
        var parsedAddresses = [];
        // Split remoteNetworks by commas to handle multiple networks
        var addresses = remoteNetworks.split(',');
        addresses.forEach(function (address) {
            // Trim each address to remove leading/trailing spaces
            address = address.trim();
            // Split the address into IP and subnet mask
            var parts = address.split('/');
            var ip = parts[0];
            var subnetMask = parseInt(parts[1], 10); // Specify radix as 10

            parsedAddresses.push({
                ip: ip,
                subnetMask: subnetMask
            });
        });

        return parsedAddresses;
    },

    /**
     * Method to check if two IP ranges overlap
     * @param address1 first object containg ip address and subnet mask.
     * @param address2 second object containg ip address and subnet mask.
     * @return boolean, true if both value overlap else false.
     */
    doRangesOverlap: function(address1, address2) {

        // Extract network from addresses and subnet masks
        var network1 = Util.convertIPIntoDecimalForEachOctet(address1.ip) & (0xFFFFFFFF << (32 - address1.subnetMask));
        var network2 = Util.convertIPIntoDecimalForEachOctet(address2.ip) & (0xFFFFFFFF << (32 - address2.subnetMask));
    
        // Check if the network addresses are the same and if they intersect
        return network1 === network2;
    },

    /**
     * Method to validate network intersection
     * @param value that has to check for uniqueness.
     * @param form tab for which error has to be shown.
     * @param field against which value has to be validated.
     * @param component current object.
     * @param query grid name to fetch the value of grid.
     * @return boolean if value is validated else error for invalid value.
     */
    isIpIntersects: function(value, form, field, component, query) {
        var grid = Ext.ComponentQuery.query(query)[0];
        var store = grid.getStore();
    
        var parsedAddresses;
        // Array to store parsed new IP addresses with subnet masks
        if(value !== null && value !== "")
            parsedAddresses = Util.getParsedAddresses(value);
       
        // Fetch already stored values
        var allStoredAddresses = [];

        store.each(function(record) {
            var fieldValue = record.get(field);
            if (fieldValue != null) {
                allStoredAddresses.push(Util.getParsedAddresses(fieldValue));
            }
        });
        // For edit grid, check only for newly added values
        if (component.getId().indexOf('textfield') !== -1 && component.bind !== null && component.bind.value.lastValue !== undefined) {

            if(component.bind.value.lastValue !== null){
                // Fetch previous value stored in grid
                var currentStoredValueInGrid = component.bind.value.lastValue;
                // Current parsed addresses with subnet masks in editor grid
                var currentParsedAddresses = Util.getParsedAddresses(currentStoredValueInGrid);
        
                // Check for intersection between new IP ranges and already stored values in current record
                var newlyAddedValue = parsedAddresses.filter(function(parsedAddress) {
                    return !currentParsedAddresses.some(function(currentAddress) {
                        return Util.doRangesOverlap(parsedAddress, currentAddress);
                    });
                });
        
                // Check for intersection between new IP ranges within the same record
                if (parsedAddresses.some(function(parsedAddress, k) {
                    return parsedAddresses.slice(k + 1).some(function(nextParsedAddress) {
                        return Util.doRangesOverlap(parsedAddress, nextParsedAddress);
                    });
                })) {
                    return Ext.String.format('The {0} values intersect with each other.'.t(), form);
                }
                parsedAddresses = newlyAddedValue;
            }
        }

        // Check if parsedAddresses is defined and not empty
        if (parsedAddresses && parsedAddresses.length > 0) {
            // Check for intersection between new IP ranges and stored values
            if (allStoredAddresses.some(function(storedAddressesArray) {
                return storedAddressesArray.some(function(storedAddress) {
                    return parsedAddresses.some(function(parsedAddress) {
                        return Util.doRangesOverlap(storedAddress, parsedAddress);
                    });
                });
            })) {
                return Ext.String.format('The {0} values intersect with already stored values in {1} records.'.t(), field, form);
            }
        }
    
        // If no intersection found, return true
        return true;
    },

    /**
     * Attaches a global iframe panel (`Ung.AppIframe`) to the specified container,
     * reusing or recreating it if necessary, and updates the iframe's URL.
     *
     * @param {Ext.container.Container} target - The ExtJS container (usually a panel) where the iframe panel should be added.
     * @param {String} url - The URL to load in the iframe.
     * @param {Boolean} - Flag to indicate whether the iframe should initially be hidden.
     */
    attachIframeToTarget: function (target, url, hidden) {
        var iframePanel = Ung.AppIframe;
        
        // Recreate iframePanel if it's null or destroyed
        if (!iframePanel || iframePanel.isDestroyed) {
            iframePanel = Ext.create('Ung.view.main.IframePanel');
            Ung.AppIframe = iframePanel;
        }

        // Detach from old parent if needed
        if (iframePanel.ownerCt) {
            iframePanel.ownerCt.remove(iframePanel, false);
        }

        // Add iframe to target
        if (target) {
            target.add(iframePanel);
            iframePanel.updateIframe(url, hidden);
        }
    }
});
/**
 * contains all the necessary mappings
 * _ (underscore) naming in front of the files required when minified to be concatenated last
 *
 */
Ext.define('Ung.util.Map', {
    singleton: true,
    alternateClassName: 'Map',

    policies: {
        1: 'Default'
    },

    init: function () {
        this.buildInterfacesMap();
        this.buildPoliciesMap();
    },

    buildInterfacesMap: function () {
        var interfaces, map = {};
        if (rpc.reportsManager) {
            interfaces = Rpc.directData('rpc.reportsManager.getInterfacesInfo').list;
            Ext.Array.each(interfaces, function (intf) {
                map[intf.interfaceId] = intf.name;
            });
        }
        this.interfaces = map;
    },

    buildPoliciesMap: function () {
        var policies,
            map = { 1: 'Default' };

        if (rpc.reportsManager) {
            policies = Rpc.directData('rpc.reportsManager.getPoliciesInfo');
            if (policies && policies['list']) {
                Ext.Array.each(policies['list'], function (policy) {
                    map[policy.policyId] = policy.name;
                });
            }
        }
        this.policies = map;
    },

    /**
     * all possible fields matching all possible db tables fields
     * having a grid column definition (col) and a store field definition (fld)
     * field_id: {
     *      col: {
     *          text: 'Column header text'.t(),
     *          filter: Rndr.filters.numeric, // the filter type e.g. 'numeric'/ 'boolean', defaults to 'string'
     *          width: 100, // the column width
     *          renderer: Rndr.boolean // the renderer method if needed, see Rndr class,
     *          dataIndex: // matching field_id and set in grid setup
     *          hidden: // true or false depending if found in report defaultColumns (not set here)
     *      },
     *      fld: {
     *          type: 'string', // model field type
     *          convert: Converter.icmp // the converter method if needed, see Converter class,
     *          sortType: 'asIp', // if requires a specific sort type
     *          name: // matching field_id and set in grid setup
     *      }
     * }
     *
     * This definitions are used when setting up grid for a specific report
     * applying a store model matching report entry db table reference
     * and setting corresponding grid columns based on that
     */
    fields: {
        action: {
            col: { text: 'Action'.t(), width: 100 },
            fld: { type: 'string' }
        },
        action_quotas: {
            col: { text: 'Action'.t(), dataIndex: 'action', width: 100 },
            fld: { name: 'action', type: 'string', convert: Converter.quotaAction }
        },
        active_hosts: {
            col: { text: 'Active Hosts'.t(), filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'integer' }
        },
        addr: {
            col: { text: 'Receiver'.t(), width: 120 },
            fld: { type: 'string' }
        },
        addr_kind: {
            col: { text: 'Address Kind'.t(), width: 120 },
            fld: { type: 'string' }
        },
        addr_name: {
            col: { text: 'Address Name'.t(), width: 120 },
            fld: { type: 'string' }
        },
        address: {
            col: { text: 'Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        auth_type: {
            col: { text: 'Auth Type'.t(), width: 120 },
            fld: { type: 'string', convert: Converter.authType }
        },
        blocked: {
            col: { text: 'Blocked'.t(), filter: Rndr.filters.boolean, width: Rndr.colW.boolean,  renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        bypassed: {
            col: { text: 'Bypassed'.t(), filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        bypasses: {
            col: { text: 'Bypass Count'.t(), filter: Rndr.filters.numeric, width: 80 },
            fld: { type: 'integer' }
        },
        c2p_bytes: {
            col: { text: 'From-Client Bytes'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right', renderer: Renderer.datasize },
            fld: { type: 'number' }
        },
        c2s_bytes: {
            col: { text: 'From-Client Bytes'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right', renderer: Renderer.datasize },
            fld: { type: 'number' }
        },
        c2s_content_length: {
            col: { text: 'Upload Content Length'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        c_client_addr: {
            col: { text: 'Client'.t(), filter: Rndr.filters.string, width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        c_client_port: {
            col: { text: 'Client Port'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        c_server_addr: {
            col: { text: 'Original Server'.t(), filter: Rndr.filters.string, width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        c_server_port: {
            col: { text: 'Original Server Port'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        category: {
            col: { text: 'Category'.t(), width: 100 },
            fld: { type: 'string' }
        },
        classtype: {
            col: { text: 'Classtype'.t(), width: 100 },
            fld: { type: 'string' }
        },
        class_id: {
            col: { text: 'Cid'.t(), filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'integer' }
        },
        client_addr: {
            col: { text: 'Client Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        client_address: {
            col: { text: 'Client Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        client_country: {
            col: { text: 'Client Country'.t(), width: 120 }, // converter
            fld: { type: 'string', convert: Converter.country }
        },
        client_intf: {
            col: { text: 'Client Interface'.t(), width: 100 }, // converter
            fld: { type: 'integer', convert: Converter.interface }
        },
        client_latitude: {
            col: { text: 'Client Latitude'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        client_longitude: {
            col: { text: 'Client Longitude'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        client_name: {
            col: { text: 'Client Name'.t(), width: 120 },
            fld: { type: 'string' }
        },
        client_protocol: {
            col: { text: 'Client Protocol'.t(), width: 120 },
            fld: { type: 'string' }
        },
        client_username: {
            col: { text: 'Client Username'.t(), width: 120 },
            fld: { type: 'string' }
        },
        connect_stamp: {
            col: { text: 'Login Time'.t(), filter: Rndr.filters.date, renderer: Renderer.timestampUnixRenderer, width: 120 },
            fld: { type: 'integer', convert: Converter.convertDate }
        },
        cpu_system: {
            col: { text: 'CPU System Utilization'.t(), filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'number' }
        },
        cpu_user: {
            col: { text: 'CPU User Utilization'.t(), filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'number' }
        },
        description: {
            col: { text: 'Description'.t(), width: 200 }, // multiple column names!!!
            fld: { type: 'string' }
        },
        destination: {
            col: { text: 'Destination'.t(), width: 200 },
            fld: { type: 'string' }
        },
        dest_addr: {
            col: { text: 'Destination Address'.t(), width: 200 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        dest_port: {
            col: { text: 'Destination Port'.t(), filter: Rndr.filters.numeric, width: 200 },
            fld: { type: 'integer' }
        },
        disk_free: {
            col: { text: 'Disk Free'.t(), filter: Rndr.filters.numeric, width: 100, align: 'right', renderer: Rndr.disk },
            fld: { type: 'number' }
        },
        disk_total: {
            col: { text: 'Disk Total'.t(), filter: Rndr.filters.numeric, width: 100, align: 'right', renderer: Rndr.disk },
            fld: { type: 'number' }
        },
        domain: {
            col: { text: 'Domain'.t(), width: 120, flex: 1 },
            fld: { type: 'string' }
        },
        elapsed_time: {
            col: { text: 'Elapsed'.t(), width: 160 },
            fld: { type: 'string' }
        },
        end_time: {
            col: { text: 'End Time'.t(), filter: Rndr.filters.date, renderer: Renderer.timestampUnixRenderer, width: 160 }, // converter
            fld: { type: 'integer', convert: Converter.convertDate }
        },
        entitled: {
            col: { text: 'Entitled'.t(), filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        entity: {
            col: { text: 'Address'.t(), width: 80 },
            fld: { type: 'string' }
        },
        event_id: {
            col: { text: 'Event Id'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        event_info: {
            col: { text: 'Event Info'.t(), width: 120 },
            fld: { type: 'string', convert: Converter.captivePortalEventInfo }
        },
        event_type: {
            col: { text: 'Type'.t(), width: 120 },
            fld: { type: 'string' }
        },
        filter_prefix: {
            col: { text: 'Filter Prefix'.t(), width: 80 },
            fld: { type: 'string' }
        },
        flagged: {
            col: { text: 'Flagged'.t(), filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        gen_id: {
            col: { text: 'Gid'.t(), filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'integer' }
        },
        goodbye_stamp: {
            col: { text: 'Logout Time'.t(), filter: Rndr.filters.date, renderer: Renderer.timestampUnixRenderer, width: 100 },
            fld: { type: 'integer', convert: Converter.convertDate }
        },
        hits: {
            col: { text: 'Hit Count'.t(), filter: Rndr.filters.numeric, width: 250 },
            fld: { type: 'integer' }
        },
        hit_bytes: {
            col: { text: 'Hit Bytes'.t(), filter: Rndr.filters.numeric, width: 250 },
            fld: { type: 'number' }
        },
        host: {
            col: { text: 'Host'.t(), width: 250 },
            fld: { type: 'string' }
        },
        hostname: {
            col: { text: 'Hostname'.t(), width: 120 },
            fld: { type: 'string' }
        },
        icmp_type: {
            col: { text: 'ICMP Type'.t(), width: 150 },
            fld: { type: 'integer', convert: Converter.icmp }
        },
        in_bytes: {
            col: { text: 'In Bytes'.t(), filter: Rndr.filters.numeric, width: 200 },
            fld: { type: 'number' }
        },
        interface_id: {
            col: { text: 'Interface'.t(), width: 100 },
            fld: { type: 'integer', convert: Converter.interface }
        },
        ipaddr: {
            col: { text: 'Sender'.t(), width: 200 },
            fld: { type: 'string' }
        },
        json: {
            col: { text: 'JSON'.t(), flex: 1 },
            fld: { type: 'string' }
        },
        key: {
            col: { text: 'Key'.t(), width: 120 },
            fld: { type: 'string' }
        },
        load_1: {
            col: { text: 'Load (1-minute)'.t(), filter: Rndr.filters.numeric, width: 100, align: 'right' },
            fld: { type: 'number' }
        },
        load_5: {
            col: { text: 'Load (5-minute)'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right' },
            fld: { type: 'number' }
        },
        load_15: {
            col: { text: 'Load (15-minute)'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right' },
            fld: { type: 'number' }
        },
        local: {
            col: { text: 'Local'.t(), filter: Rndr.filters.boolean, width: 100, renderer: Rndr.localLogin },
            fld: { type: 'boolean' }
        },
        local_addr: {
            col: { text: 'Local Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        local_address: {
            col: { text: 'Local Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        login: {
            col: { text: 'Login'.t(), width: 100},
            fld: { type: 'string' }
        },
        login_name: {
            col: { text: 'Login'.t(), width: 100},
            fld: { type: 'string' }
        },
        mac_address: {
            col: { text: 'MAC Address'.t(), width: 120},
            fld: { type: 'string' }
        },
        mem_free: {
            col: { text: 'Memory Free'.t(), filter: Rndr.filters.numeric, width: 100, align: 'right', renderer: Rndr.memory },
            fld: { type: 'number' }
        },
        mem_total: {
            col: { text: 'Memory Total'.t(), filter: Rndr.filters.numeric, width: 100, align: 'right', renderer: Rndr.memory },
            fld: { type: 'number' }
        },
        method: {
            col: { text: 'Method'.t(), width: 120 }, // converter
            fld: { type: 'string', convert: Converter.httpMethod }
        },
        misses: {
            col: { text: 'Miss Count'.t(), filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'number' }
        },
        miss_bytes: {
            col: { text: 'Miss Bytes'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        msg: {
            col: { text: 'Msg'.t(), width: 120 },
            fld: { type: 'string' }
        },
        msg_id: {
            col: { text: 'Message Id'.t(), width: 120 },
            fld: { type: 'string' }
        },
        name: {
            col: { text: 'Interface Name'.t(), width: 120 },
            fld: { type: 'string' }
        },
        net_interface: {
            col: { text: 'Interface'.t(), width: 120 },
            fld: { type: 'string' }
        },
        net_process: {
            col: { text: 'Process'.t(), width: 120 },
            fld: { type: 'string' }
        },
        old_value: {
            col: { text: 'Old Value'.t(), width: 120 },
            fld: { type: 'string' }
        },
        os_name: {
            col: { text: 'Interface OS'.t(), width: 120 },
            fld: { type: 'string' }
        },
        out_bytes: {
            col: { text: 'Out Bytes'.t(), filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'number' }
        },
        operation: {
            col: { text: 'Operation'.t(), width: 200, renderer: Rndr.operation },
            fld: { type: 'string' }
        },
        p2c_bytes: {
            col: { text: 'To-Client Bytes'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right', renderer: Renderer.datasize },
            fld: { type: 'number' }
        },
        p2s_bytes: {
            col: { text: 'To-Server Bytes'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right', renderer: Renderer.datasize },
            fld: { type: 'number' }
        },
        policy_id: {
            col: { text: 'Policy Id'.t(), width: 120},
            fld: { type: 'integer', convert: Converter.policy }
        },
        policy_rule_id: {
            col: { text: 'Policy Rule'.t(), width: 100},
            fld: { type: 'integer' }
        },
        pool_address: {
            col: { text: 'Pool Address'.t(), width: 100},
            fld: { type: 'string', sortType: 'asIp' }
        },
        protocol: {
            col: { text: 'Protocol'.t(), width: 80 },
            fld: { type: 'integer', convert: Converter.protocol }
        },
        protocol_name: {
            col: { text: 'Protocol'.t(), width: 80 },
            fld: { type: 'string'}
        },
        component: {
            col: { text: 'Component'.t(), width: 100 },
            fld: { type: 'string' }
        },
        message: {
            col: { text: 'Message'.t(), width: 200 },
            fld: { type: 'string' }
        },
        problem: {
            col: { text: 'Problem'.t(), width: 200 },
            fld: { type: 'string' }
        },
        reason: {
            col: { text: 'Reason'.t(), width: 200 },
            fld: { type: 'string' }
        },
        reason_admin_logins: {
            col: { text: 'Reason'.t(), dataIndex: 'reason', width: 100, flex: 1 },
            fld: { name: 'reason', type: 'string', convert: Converter.loginReason }
        },
        receiver: {
            col: { text: 'Receiver'.t(), width: 100 },
            fld: { type: 'string' }
        },
        referer: {
            col: { text: 'Referrer'.t(), width: 120 },
            fld: { type: 'string' }
        },
        remote_addr: {
            col: { text: 'Remote Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        remote_address: {
            col: { text: 'Remote Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        remote_port: {
            col: { text: 'Remote Port'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        request_id: {
            col: { text: 'Request Id'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        rid: {
            col: { text: 'Rid'.t(), width: 120 },
            fld: { type: 'string' }
        },
        rule_id: {
            col: { text: 'Rule Id'.t(), width: 120 },
            fld: { type: 'string' }
        },
        rx_bytes: {
            col: { text: 'RX Bytes'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        rx_rate: {
            col: { text: 'RX Rate'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        s2c_bytes: {
            col: { text: 'From-Server Bytes'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right', renderer: Renderer.datasize },
            fld: { type: 'number' }
        },
        s2c_content_filename: {
            col: { text: 'Content Filename'.t(), width: 160 },
            fld: { type: 'string' }
        },
        s2c_content_length: {
            col: { text: 'Download Content Length'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        s2c_content_type: {
            col: { text: 'Content Type'.t(), width: 120 },
            fld: { type: 'string' }
        },
        s2p_bytes: {
            col: { text: 'From-Server Bytes'.t(), filter: Rndr.filters.numeric, width: 80, align: 'right', renderer: Renderer.datasize },
            fld: { type: 'number' }
        },
        s_client_addr: {
            col: { text: 'New Client'.t(), filter: Rndr.filters.string, width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        s_client_port: {
            col: { text: 'New Client Port'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        s_server_addr: {
            col: { text: 'Server'.t(), filter: Rndr.filters.string, width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        s_server_port: {
            col: { text: 'Server Port'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        sender: {
            col: { text: 'Sender', width: 100 },
            fld: { type: 'string' }
        },
        server_address: {
            col: { text: 'Server Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        server_country: {
            col: { text: 'Server Country'.t(), width: 120 }, // converter
            fld: { type: 'string', convert: Converter.country }
        },
        server_intf: {
            col: { text: 'Server Interface'.t(), width: 100 }, // converter
            fld: { type: 'integer', convert: Converter.interface }
        },
        server_latitude: {
            col: { text: 'Server Latitude'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        server_longitude: {
            col: { text: 'Server Longitude'.t(), filter: Rndr.filters.numeric, width: 120},
            fld: { type: 'number' }
        },
        session_id: {
            col: { text: 'Session Id'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        settings_file: {
            col: { text: 'Settings File'.t(), width: 200, renderer: Rndr.settingsFile },
            fld: { type: 'string' }
        },
        sig_id: {
            col: { text: 'Sid', filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'integer' }
        },
        size: {
            col: { text: 'Size', filter: Rndr.filters.numeric, width: 100 },
            fld: { type: 'number' }
        },
        source_addr: {
            col: { text: 'Source Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        source_port: {
            col: { text: 'Source Port'.t(), filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        start_time: {
            col: { text: 'Start Time'.t(), filter: Rndr.filters.date, renderer: Renderer.timestampUnixRenderer, width: 160 }, // converter
            fld: { type: 'integer', convert: Converter.convertDate }
        },
        subject: {
            col: { text: 'Subject'.t(), width: 120 },
            fld: { type: 'string' }
        },
        succeeded: {
            col: { text: 'Succeeded'.t(), filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.successLogin },
            fld: { type: 'boolean' }
        },
        success: {
            col: { text: 'Success'.t(), filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        summary_text: {
            col: { text: 'Summary'.t(), width: 200 },
            fld: { type: 'string' }
        },
        swap_free: {
            col: { text: 'Swap Free'.t(), filter: Rndr.filters.numeric, width: 100, align: 'right', renderer: Rndr.memory },
            fld: { type: 'number' }
        },
        swap_total: {
            col: { text: 'Swap Total'.t(), filter: Rndr.filters.numeric, width: 100, align: 'right', renderer: Rndr.memory },
            fld: { type: 'number' }
        },
        systems: {
            col: { text: 'System Count'.t(), filter: Rndr.filters.numeric, width: 160 },
            fld: { type: 'integer' }
        },
        tags: {
            col: { text: 'Tags'.t(), width: 160, renderer: Renderer.tagsFilterText },
            fld: { type: 'string' }
        },
        term: {
            col: { text: 'Query Term'.t(), width: 160 },
            fld: { type: 'string' }
        },
        time_stamp: {
            col: { text: 'Timestamp'.t(), filter: Rndr.filters.date, renderer: Renderer.timestampUnixRenderer, width: 160 }, // converter
            fld: { type: 'auto', convert: Converter.convertDate }
        },
        tunnel_description: {
            col: { text: 'Tunnel Description'.t(), width: 160 },
            fld: { type: 'string' }
        },
        tunnel_name: {
            col: { text: 'Tunnel Name'.t(), width: 160 },
            fld: { type: 'string' }
        },
        peer_address: {
            col: { text: 'Source Address'.t(), width: 120 },
            fld: { type: 'string', sortType: 'asIp' }
        },
        tx_bytes: {
            col: { text: 'TX Bytes'.t(), filter: Rndr.filters.numeric, width: 80 },
            fld: { type: 'number' }
        },
        tx_rate: {
            col: { text: 'TX Rate'.t(), filter: Rndr.filters.numeric, width: 80 },
            fld: { type: 'number' }
        },
        type: {
            col: { text: 'Type'.t(), width: 160 },
            fld: { type: 'string' }
        },
        type_directory_connector: {
            col: { text: 'Action'.t(), dataIndex: 'type', width: 160 },
            fld: { name: 'type', type: 'string', convert: Converter.directoryConnectorAction }
        },
        uri: {
            col: { text: 'URI'.t(), width: 120 },
            fld: { type: 'string' }
        },
        username: {
            col: { text: 'Username'.t(), width: 120 },
            fld: { type: 'string' }
        },
        value: {
            col: { text: 'Value'.t(), width: 120 },
            fld: { type: 'string' }
        },
        vendor_name: {
            col: { text: 'Vendor Name'.t(), width: 200 },
            fld: { type: 'string' }
        },

        // applications related columns
        ad_blocker_action: {
            col: { text: 'Action'.t() +  ' (Ad Blocker)', width: 80, renderer: Rndr.adBlockerAction },
            fld: { type: 'string' }
        },
        ad_blocker_cookie_ident: {
            col: { text: 'Blocked Cookie'.t() + ' (Ad Blocker)', width: 120 },
            fld: { type: 'string' }
        },
        application_control_application: {
            col: { text: 'Application'.t() + ' (Application Control)', width: 120 },
            fld: { type: 'string' }
        },
        application_control_blocked: {
            col: { text: 'Blocked'.t() + ' (Application Control)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        application_control_category: {
            col: { text: 'Category'.t() + ' (Application Control)', width: 120 },
            fld: { type: 'string' }
        },
        application_control_confidence: {
            col: { text: 'Confidence'.t() + ' (Application Control)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        application_control_detail: {
            col: { text: 'Detail'.t() + ' (Application Control)', width: 120 },
            fld: { type: 'string' }
        },
        application_control_flagged: {
            col: { text: 'Flagged'.t() + ' (Application Control)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean },
            fld: { type: 'boolean' }
        },
        application_control_protochain: {
            col: { text: 'Protochain'.t() + ' (Application Control)', width: 120 },
            fld: { type: 'string' }
        },
        application_control_ruleid: {
            col: { text: 'Rule'.t() + ' (Application Control)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        application_control_lite_blocked: {
            col: { text: 'Blocked'.t() + ' (Application Control Lite)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        application_control_lite_protocol: {
            col: { text: 'Protocol'.t() + ' (Application Control Lite)', width: 120 },
            fld: { type: 'string' } // ??? why text/string
        },
        bandwidth_control_priority: {
            col: { text: 'Priority'.t() + ' (Bandwidth Control)', width: 120, renderer: Rndr.priority },
            fld: { type: 'integer' }
        },
        bandwidth_control_rule: {
            col: { text: 'Rule'.t() + ' (Bandwidth Control)', width: 120, renderer: Rndr.bandwidthControlRule },
            fld: { type: 'integer' }
        },
        captive_portal_blocked: {
            col: { text: 'Blocked'.t() + ' (Captive Portal)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        captive_portal_rule_index: {
            col: { text: 'Rule Id'.t() + ' (Captive Portal)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        firewall_blocked: {
            col: { text: 'Blocked'.t() + ' (Firewall)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        firewall_flagged: {
            col: { text: 'Flagged'.t() + ' (Firewall)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        firewall_rule_index: {
            col: { text: 'Rule'.t() + ' (Firewall)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        phish_blocker_action: {
            col: { text: 'Action'.t() + ' (Phish Blocker)', width: 120 }, // converter
            fld: { type: 'string', convert: Converter.emailAction }
        },
        phish_blocker_is_spam: {
            col: { text: 'Is Spam'.t() + ' (Phish Blocker)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        phish_blocker_score: {
            col: { text: 'Score'.t() + ' (Phish Blocker)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        phish_blocker_tests_string: {
            col: { text: 'Detail'.t() + ' (Phish Blocker)', width: 120 },
            fld: { type: 'string' }
        },
        spam_blocker_action: {
            col: { text: 'Action'.t() + ' (Spam Blocker)', width: 120 },
            fld: { type: 'string', convert: Converter.emailAction }
        },
        spam_blocker_is_spam: {
            col: { text: 'Is Spam'.t() + ' (Spam Blocker)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        spam_blocker_score: {
            col: { text: 'Spam Score'.t() + ' (Spam Blocker)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        spam_blocker_tests_string: {
            col: { text: 'Detail'.t() + ' (Spam Blocker)', width: 120 },
            fld: { type: 'string' }
        },
        spam_blocker_lite_action: {
            col: { text: 'Action'.t() + ' (Spam Blocker Lite)', width: 120},
            fld: { type: 'string', convert: Converter.emailAction }
        },
        spam_blocker_lite_is_spam: {
            col: { text: 'Is Spam'.t() + ' (Spam Blocker Lite)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        spam_blocker_lite_score: {
            col: { text: 'Spam Score'.t() + ' (Spam Blocker Lite)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'number' }
        },
        spam_blocker_lite_tests_string: {
            col: { text: 'Detail'.t() + ' (Spam Blocker Lite)', width: 120 },
            fld: { type: 'string' }
        },
        ssl_inspector_detail: {
            col: { text: 'Detail'.t() + ' (SSL Inspector)', width: 120 },
            fld: { type: 'string' }
        },
        ssl_inspector_ruleid: {
            col: { text: 'Rule Id'.t() + ' (SSL Inspector)', filter: Rndr.filters.numeric, width: 120 },
            fld: { type: 'integer' }
        },
        ssl_inspector_status: {
            col: { text: 'Status'.t() + ' (SSL Inspector)', width: 120 },
            fld: { type: 'string' }
        },
        // threat_prevention_blocked: {
        //     col: { text: 'Blocked'.t() + ' (Threat Prevention)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
        //     fld: { type: 'boolean' }
        // },
        // threat_prevention_categories: {
        //     col: { text: 'Categories'.t() + ' (Threat Prevention)', width: 120 },
        //     fld: { type: 'integer' }
        // },
        // threat_prevention_client_categories: {
        //     col: { text: 'Client Categories'.t() + ' (Threat Prevention)', width: 100 },
        //     fld: { type: 'integer' }
        // },
        // threat_prevention_client_reputation: {
        //     col: { text: 'Client Reputation'.t() + ' (Threat Prevention)', width: 100 },
        //     fld: { type: 'integer' }
        // },
        // threat_prevention_flagged: {
        //     col: { text: 'Flagged'.t() + ' (Threat Prevention)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
        //     fld: { type: 'boolean' }
        // },
        // threat_prevention_reason: {
        //     col: { text: 'Reason'.t() + ' (Threat Prevention)', width: 100 },
        //     fld: { type: 'string' }
        // },
        // threat_prevention_reputation: {
        //     col: { text: 'Reputation'.t() + ' (Threat Prevention)', width: 120 },
        //     fld: { type: 'integer' }
        // },
        // threat_prevention_rule_id: {
        //     col: { text: 'Rule Id'.t() + ' (Threat Prevention)', width: 120 },
        //     fld: { type: 'integer' }
        // },
        // threat_prevention_server_categories: {
        //     col: { text: 'Server Categories'.t() + ' (Threat Prevention)', width: 100 },
        //     fld: { type: 'integer' }
        // },
        // threat_prevention_server_reputation: {
        //     col: { text: 'Server Reputation'.t() + ' (Threat Prevention)', width: 100 },
        //     fld: { type: 'integer' }
        // },
        virus_blocker_clean: {
            col: { text: 'Clean'.t() + ' (Virus Blocker)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        virus_blocker_name: {
            col: { text: 'Name'.t() + ' (Virus Blocker)', width: 120 },
            fld: { type: 'string' }
        },
        virus_blocker_lite_clean: {
            col: { text: 'Clean'.t() + ' (Virus Blocker Lite)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        virus_blocker_lite_name: {
            col: { text: 'Name'.t() + ' (Virus Blocker Lite)', width: 120 },
            fld: { type: 'string' }
        },
        web_filter_blocked: {
            col: { text: 'Blocked'.t() + ' (Web Filter)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        web_filter_category_id: {
            col: { text: 'Web Category'.t() + ' (Web Filter)', width: 250 }, // converter
            fld: { type: 'integer', convert: Converter.webCategory }
        },
        web_filter_flagged: {
            col: { text: 'Flagged'.t() + ' (Web Filter)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
            fld: { type: 'boolean' }
        },
        web_filter_reason: {
            col: { text: 'Reason For Action'.t() + ' (Web Filter)', width: 120 },
            fld: { type: 'string', convert: Converter.webReason }
        },
        web_filter_rule_id: {
            col: { text: 'Web Rule'.t() + ' (Web Filter)', width: 120, renderer: Renderer.webRule }, // converter not implemented
            fld: { type: 'integer' }
        },

        /**
         * non table specific column
         * used in Settings Changes Events listing
         */
        differences: {
            col: {
                text: "Differences".t(),
                dataIndex: 'settings_file',
                width: Renderer.actionWidth,
                xtype: 'actioncolumn',
                align: 'center',
                tdCls: 'action-cell',
                hideable: false,
                sortable: false,
                hidden: false,
                menuDisabled: true,
                iconCls: 'fa fa-search fa-black',
                tooltip: "Show difference between previous version".t(),
                handler: function(view, rowIndex, colIndex, item, e, record) {
                    if( !this.diffWindow ) {
                        var columnRenderer = function(value, meta, record) {
                            var action = record.get("action");
                            if( action == 3){
                                meta.style = "background-color:#ffff99";
                            }else if(action == 2) {
                                meta.style = "background-color:#ffdfd9";
                            }else if(action == 1) {
                                meta.style = "background-color:#d9f5cb";
                            }
                            return value;
                        };
                        this.diffWindow = Ext.create('Ext.window.Window',{
                            name: 'diffWindow',
                            title: 'Settings Difference'.t(),
                            closeAction: 'hide',
                            width: Ext.getBody().getViewSize().width - 20,
                            height:Ext.getBody().getViewSize().height - 20,
                            layout: 'fit',
                            items: [{
                                xtype: 'ungrid',
                                name: 'gridDiffs',
                                initialLoad: function() {},
                                cls: 'diff-grid',
                                reload: function(handler) {
                                    this.getStore().getProxy().setData([]);
                                    this.getStore().load();
                                    rpc.settingsManager.getDiff(Ext.bind(function(result,exception) {
                                        var diffWindow = this.up("window[name=diffWindow]");
                                        if (diffWindow ==null || !diffWindow.isVisible()) {
                                            return;
                                        }
                                        if(exception) {
                                            this.getView().setLoading(false);
                                            Util.handleException(exception);
                                            return;
                                        }
                                        var diffData = [];
                                        var diffLines = result.split("\n");
                                        var action;
                                        for( var i = 0; i < diffLines.length; i++) {
                                            var previousAction = diffLines[i].substr(0,1);
                                            var previousLine = diffLines[i].substr(1,510);
                                            var currentAction = diffLines[i].substr(511,1);
                                            var currentLine = diffLines[i].substr(512);

                                            if( previousAction != "<" && previousAction != ">") {
                                                previousLine = previousAction + previousLine;
                                            }
                                            if( currentAction != "<" && currentAction != ">" && currentAction != "|"){
                                                currentLine = currentAction + currentLine;
                                                currentAction = -1;
                                            }

                                            if( currentAction == "|" ) {
                                                action = 3;
                                            } else if(currentAction == "<") {
                                                action = 2;
                                            } else if(currentAction == ">") {
                                                action = 1;
                                            } else {
                                                action = 0;
                                            }

                                            diffData.push({
                                                line: (i + 1),
                                                previous: previousLine.replace(/\s+$/,"").replace(/\s/g, "&nbsp;"),
                                                current: currentLine.replace(/\s+$/,"").replace(/\s/g, "&nbsp;"),
                                                action: action
                                            });
                                        }
                                        this.getStore().loadRawData(diffData);
                                    },this), this.fileName);
                                },
                                fields: [{
                                    name: "line"
                                }, {
                                    name: "previous"
                                }, {
                                    name: "current"
                                }, {
                                    name: "action"
                                }],
                                columnsDefaultSortable: false,
                                columns:[{
                                    text: "Line".t(),
                                    dataIndex: "line",
                                    renderer: columnRenderer
                                },{
                                    text: "Previous".t(),
                                    flex: 1,
                                    dataIndex: "previous",
                                    renderer: columnRenderer
                                },{
                                    text: "Current".t(),
                                    flex: 1,
                                    dataIndex: "current",
                                    renderer: columnRenderer
                                }]
                            }],
                            buttons: [{
                                text: "Close".t(),
                                handler: Ext.bind(function() {
                                    this.diffWindow.hide();
                                }, this)
                            }],
                            update: function(fileName) {
                                var grid = this.down("grid[name=gridDiffs]");
                                grid.fileName = fileName;
                                grid.reload();
                            },
                            doSize : function() {
                                this.maximize();
                            }
                        });
                        this.on("beforedestroy", Ext.bind(function() {
                            if(this.diffWindow) {
                                Ext.destroy(this.diffWindow);
                                this.diffWindow = null;
                            }
                        }, this));
                    }
                    this.diffWindow.show();
                    this.diffWindow.update(record.get("settings_file"));
                }
            },
            fld: { type: 'auto' }
        }

        /**
         * NOT USED, kept just for future references/improvement needs
         * merged sessions related fields definition which are not defined above
         * this are "-" dash separated instead of "_"
         * this are used in the record detauls view so they do not require but human readable text
         */
        // 'application-control-application': {
        //     col: { text: 'Application'.t() }
        // }

    },

    /**
     * all tables with corresponding fields as defined in db
     * the fields are used to determine the store model field and the grid column defined above
     * if there are tables having same field name but with different meaning,
     * than use a different mapping for each and not the exact field name
     *
     * !!! Note, all the below columns for table can be fetched using
     * rpc.reportsManager.getColumnsForTable(<table_name>)
     */
    tables: {
        admin_logins: [
            'time_stamp',
            'login',
            'local',
            'client_addr',
            'succeeded',
            'reason_admin_logins' // original: reason
        ],
        alerts: [
            'time_stamp',
            'description',
            'summary_text',
            'json'
        ],
        captive_portal_user_events: [
            'time_stamp',
            'policy_id',
            'event_id',
            'login_name',
            'event_info',
            'auth_type',
            'client_addr'
        ],
        configuration_backup_events: [
            'time_stamp',
            'success',
            'description',
            'destination',
            'event_id'
        ],
        device_table_updates: [
            'time_stamp',
            'mac_address',
            'key',
            'value',
            'old_value'
        ],
        directory_connector_login_events: [
            'time_stamp',
            'login_name',
            'domain',
            'type_directory_connector', // original = type
            'client_addr'
        ],
        ftp_events: [
            'time_stamp',
            'event_id',
            'session_id',
            'client_intf',
            'server_intf',
            'c_client_addr',
            's_client_addr',
            'c_server_addr',
            's_server_addr',
            'policy_id',
            'username',
            'hostname',
            'request_id',
            'method',
            'uri'
        ],
        host_table_updates: [
            'time_stamp',
            'address',
            'key',
            'value',
            'old_value'
        ],
        interface_stat_events: [
            'time_stamp',
            'interface_id',
            'rx_rate',
            'rx_bytes',
            'tx_rate',
            'tx_bytes'
        ],
        ipsec_user_events: [
            'event_id',
            'time_stamp',
            'connect_stamp',
            'goodbye_stamp',
            'client_address',
            'client_protocol',
            'client_username',
            'net_process',
            'net_interface',
            'elapsed_time',
            'rx_bytes',
            'tx_bytes'
        ],
        ipsec_vpn_events: [
            'event_id',
            'time_stamp',
            'local_address',
            'remote_address',
            'tunnel_description',
            'event_type'
        ],
        ipsec_tunnel_stats: [
            'time_stamp',
            'tunnel_name',
            'in_bytes',
            'out_bytes',
            'event_id'
        ],
        wireguard_vpn_stats: [
            'time_stamp',
            'tunnel_name',
            'peer_address',
            'in_bytes',
            'out_bytes',
            'event_id'
        ],
        wireguard_vpn_events: [
            'event_id',
            'time_stamp',
            'tunnel_name',
            'event_type'
        ],
        intrusion_prevention_events: [
            'time_stamp',
            'sig_id',
            'gen_id',
            'class_id',
            'source_addr',
            'source_port',
            'dest_addr',
            'dest_port',
            'protocol_name',
            'blocked',
            'category',
            'classtype',
            'msg',
            'rid',
            'rule_id'
        ],
        openvpn_events: [
            'time_stamp',
            'remote_address',
            'pool_address',
            'client_name',
            'type'
        ],
        openvpn_stats: [
            'time_stamp',
            'start_time',
            'end_time',
            'rx_bytes',
            'tx_bytes',
            'remote_address',
            'pool_address',
            'remote_port',
            'client_name',
            'event_id'
        ],
        quotas: [
            'time_stamp',
            'entity',
            'action_quotas', // original: action
            'size',
            'reason'
        ],
        server_events: [
            'time_stamp',
            'load_1',
            'load_5',
            'load_15',
            'cpu_user',
            'cpu_system',
            'mem_total',
            'mem_free',
            'disk_total',
            'disk_free',
            'swap_total',
            'swap_free',
            'active_hosts'
        ],
        settings_changes: [
            'time_stamp',
            'settings_file',
            'username',
            'hostname',
            'differences' // custom non sql table field
        ],
        system_operations: [
            'time_stamp',
            'operation',
            'username',
            'hostname'
        ],
        critical_alerts: [
            'time_stamp',
            'component',
            'message',
            'problem'
        ],
        smtp_tarpit_events: [
            'time_stamp',
            'ipaddr',
            'hostname',
            'policy_id',
            'vendor_name',
            'event_id'
        ],
        tunnel_vpn_events: [
            'event_id',
            'time_stamp',
            'tunnel_name',
            'server_address',
            'local_address',
            'event_type'
        ],
        tunnel_vpn_stats: [
            'time_stamp',
            'tunnel_name',
            'in_bytes',
            'out_bytes',
            'event_id'
        ],
        user_table_updates: [
            'time_stamp',
            'username',
            'key',
            'value',
            'old_value'
        ],
        wan_failover_action_events: [
            'time_stamp',
            'interface_id',
            'action',
            'os_name',
            'name',
            'event_id'
        ],
        wan_failover_test_events: [
            'time_stamp',
            'interface_id',
            'name',
            'description',
            'success',
            'event_id'
        ],
        web_cache_stats: [
            'time_stamp',
            'hits',
            'misses',
            'bypasses',
            'systems',
            'hit_bytes',
            'miss_bytes',
            'event_id'
        ],
        http_events: [
            'request_id',
            'time_stamp',
            'session_id',
            'client_intf',
            'server_intf',
            'c_client_addr',
            's_client_addr',
            'c_server_addr',
            's_server_addr',
            'c_client_port',
            's_client_port',
            'c_server_port',
            's_server_port',
            'client_country',
            'client_latitude',
            'client_longitude',
            'server_country',
            'server_latitude',
            'server_longitude',
            'policy_id',
            'username',
            'hostname',
            'method',
            'host',
            'uri',
            'domain',
            'referer',
            'c2s_content_length',
            's2c_content_length',
            's2c_content_type',
            's2c_content_filename',
            'ad_blocker_cookie_ident',
            'ad_blocker_action',
            'web_filter_reason',
            'web_filter_category_id',
            'web_filter_rule_id',
            'web_filter_blocked',
            'web_filter_flagged',
            'virus_blocker_lite_clean',
            'virus_blocker_lite_name',
            'virus_blocker_clean',
            'virus_blocker_name'
            // 'threat_prevention_blocked',
            // 'threat_prevention_flagged',
            // 'threat_prevention_rule_id',
            // 'threat_prevention_reputation',
            // 'threat_prevention_categories'
        ],
        http_query_events: [
            'event_id',
            'time_stamp',
            'session_id',
            'client_intf',
            'server_intf',
            'c_client_addr',
            's_client_addr',
            'c_server_addr',
            's_server_addr',
            'c_client_port',
            's_client_port',
            'c_server_port',
            's_server_port',
            'policy_id',
            'username',
            'hostname',
            'request_id',
            'method',
            'term',
            'host',
            'uri',
            'c2s_content_length',
            's2c_content_length',
            's2c_content_type',
            'blocked',
            'flagged',
            'web_filter_reason'
        ],
        mail_addrs: [
            'time_stamp',
            'session_id',
            'server_intf',
            'c_client_addr',
            'c_server_addr',
            'c_client_port',
            'c_server_port',
            's_client_addr',
            's_server_addr',
            's_client_port',
            's_server_port',
            'policy_id',
            'username',
            'msg_id',
            'subject',
            'addr',
            'addr_name',
            'addr_kind',
            'hostname',
            'event_id',
            'sender',
            'virus_blocker_lite_clean',
            'virus_blocker_lite_name',
            'virus_blocker_clean',
            'virus_blocker_name',
            'spam_blocker_lite_score',
            'spam_blocker_lite_is_spam',
            'spam_blocker_lite_action',
            'spam_blocker_lite_tests_string',
            'spam_blocker_score',
            'spam_blocker_is_spam',
            'spam_blocker_action',
            'spam_blocker_tests_string',
            'phish_blocker_score',
            'phish_blocker_is_spam',
            'phish_blocker_tests_string',
            'phish_blocker_action'
        ],
        mail_msgs: [
            'time_stamp',
            'session_id',
            'server_intf',
            'c_client_addr',
            's_server_addr',
            'c_client_port',
            's_server_port',
            'policy_id',
            'username',
            'msg_id',
            'subject',
            'hostname',
            'event_id',
            'sender',
            'receiver',
            'virus_blocker_lite_clean',
            'virus_blocker_lite_name',
            'virus_blocker_clean',
            'virus_blocker_name',
            'spam_blocker_lite_score',
            'spam_blocker_lite_is_spam',
            'spam_blocker_lite_tests_string',
            'spam_blocker_lite_action',
            'spam_blocker_score',
            'spam_blocker_is_spam',
            'spam_blocker_tests_string',
            'spam_blocker_action',
            'phish_blocker_score',
            'phish_blocker_is_spam',
            'phish_blocker_tests_string',
            'phish_blocker_action',
        ],
        session_minutes: [
            'session_id',
            'time_stamp',
            'c2s_bytes',
            's2c_bytes',
            'start_time',
            'end_time',
            'bypassed',
            'entitled',
            'protocol',
            'icmp_type',
            'hostname',
            'username',
            'policy_id',
            'policy_rule_id',
            'local_addr',
            'remote_addr',
            'c_client_addr',
            'c_server_addr',
            'c_client_port',
            'c_server_port',
            's_client_addr',
            's_server_addr',
            's_client_port',
            's_server_port',
            'client_intf',
            'server_intf',
            'client_country',
            'client_latitude',
            'client_longitude',
            'server_country',
            'server_latitude',
            'server_longitude',
            'filter_prefix',
            'firewall_blocked',
            'firewall_flagged',
            'firewall_rule_index',
            // 'threat_prevention_blocked',
            // 'threat_prevention_flagged',
            // 'threat_prevention_reason',
            // 'threat_prevention_rule_id',
            // 'threat_prevention_client_reputation',
            // 'threat_prevention_client_categories',
            // 'threat_prevention_server_reputation',
            // 'threat_prevention_server_categories',
            'application_control_lite_protocol',
            'application_control_lite_blocked',
            'captive_portal_blocked',
            'captive_portal_rule_index',
            'application_control_application',
            'application_control_protochain',
            'application_control_category',
            'application_control_blocked',
            'application_control_flagged',
            'application_control_confidence',
            'application_control_ruleid',
            'application_control_detail',
            'bandwidth_control_priority',
            'bandwidth_control_rule',
            'ssl_inspector_ruleid',
            'ssl_inspector_status',
            'ssl_inspector_detail',
            'tags'
        ],
        sessions: [
            'session_id',
            'time_stamp',
            'end_time',
            'bypassed',
            'entitled',
            'protocol',
            'icmp_type',
            'hostname',
            'username',
            'policy_id',
            'policy_rule_id',
            'local_addr',
            'remote_addr',
            'c_client_addr',
            'c_server_addr',
            'c_client_port',
            'c_server_port',
            's_client_addr',
            's_server_addr',
            's_client_port',
            's_server_port',
            'client_intf',
            'server_intf',
            'client_country',
            'client_latitude',
            'client_longitude',
            'server_country',
            'server_latitude',
            'server_longitude',
            'c2p_bytes',
            'p2c_bytes',
            's2p_bytes',
            'p2s_bytes',
            'filter_prefix',
            'firewall_blocked',
            'firewall_flagged',
            'firewall_rule_index',
            // 'threat_prevention_blocked',
            // 'threat_prevention_flagged',
            // 'threat_prevention_reason',
            // 'threat_prevention_rule_id',
            // 'threat_prevention_client_reputation',
            // 'threat_prevention_client_categories',
            // 'threat_prevention_server_reputation',
            // 'threat_prevention_server_categories',
            'application_control_lite_protocol',
            'application_control_lite_blocked',
            'captive_portal_blocked',
            'captive_portal_rule_index',
            'application_control_application',
            'application_control_protochain',
            'application_control_category',
            'application_control_blocked',
            'application_control_flagged',
            'application_control_confidence',
            'application_control_ruleid',
            'application_control_detail',
            'bandwidth_control_priority',
            'bandwidth_control_rule',
            'ssl_inspector_ruleid',
            'ssl_inspector_status',
            'ssl_inspector_detail',
            'tags'
        ]
    },

    listeners: {
        sessions: {},
        http_events: {}
    },


    webReasons: {
        D: 'in Categories Block list'.t(),
        U: 'in Site Block list'.t(),
        T: 'in Search Term list'.t(),
        E: 'in File Block list'.t(),
        M: 'in MIME Types Block list'.t(),
        H: 'hostname is an IP address'.t(),
        I: 'in Site Pass list'.t(),
        R: 'referer in Site Pass list'.t(),
        C: 'in Clients Pass list'.t(),
        B: 'in Temporary Unblocked list'.t(),
        F: 'in Rules list'.t(),
        K: 'Kid-friendly redirect'.t(),
        default: 'no rule applied'.t()
    },

    webCategories: {
        0: 'Uncategorized',
        1: 'Real Estate',
        2: 'Computer and Internet Security',
        3: 'Financial Services',
        4: 'Business and Economy',
        5: 'Computer and Internet Info',
        6: 'Auctions',
        7: 'Shopping',
        8: 'Cult and Occult',
        9: 'Travel',
        10: 'Abused Drugs',
        11: 'Adult and Pornography',
        12: 'Home and Garden',
        13: 'Military',
        14: 'Social Networking',
        15: 'Dead Sites',
        16: 'Individual Stock Advice and Tools',
        17: 'Training and Tools',
        18: 'Dating',
        19: 'Sex Education',
        20: 'Religion',
        21: 'Entertainment and Arts',
        22: 'Personal sites and Blogs',
        23: 'Legal',
        24: 'Local Information',
        25: 'Streaming Media',
        26: 'Job Search',
        27: 'Gambling',
        28: 'Translation',
        29: 'Reference and Research',
        30: 'Shareware and Freeware',
        31: 'Peer to Peer',
        32: 'Marijuana',
        33: 'Hacking',
        34: 'Games',
        35: 'Philosophy and Political Advocacy',
        36: 'Weapons',
        37: 'Pay to Surf',
        38: 'Hunting and Fishing',
        39: 'Society',
        40: 'Educational Institutions',
        41: 'Online Greeting Cards',
        42: 'Sports',
        43: 'Swimsuits and Intimate Apparel',
        44: 'Questionable',
        45: 'Kids',
        46: 'Hate and Racism',
        47: 'Personal Storage',
        48: 'Violence',
        49: 'Keyloggers and Monitoring',
        50: 'Search Engines',
        51: 'Internet Portals',
        52: 'Web Advertisements',
        53: 'Cheating',
        54: 'Gross',
        55: 'Web-based Email',
        56: 'Malware Sites',
        57: 'Phishing and Other Frauds',
        58: 'Proxy Avoidance and Anonymizers',
        59: 'Spyware and Adware',
        60: 'Music',
        61: 'Government',
        62: 'Nudity',
        63: 'News and Media',
        64: 'Illegal',
        65: 'Content Delivery Networks',
        66: 'Internet Communications',
        67: 'Bot Nets',
        68: 'Abortion',
        69: 'Health and Medicine',
        71: 'SPAM URLs',
        74: 'Dynamically Generated Content',
        75: 'Parked Domains',
        76: 'Alcohol and Tobacco',
        78: 'Image and Video Search',
        79: 'Fashion and Beauty',
        80: 'Recreation and Hobbies',
        81: 'Motor Vehicles',
        82: 'Web Hosting',
        85: "Self Harm",
        86: "DNS Over HTTPS",
        87: "Low-THC Cannabis Products",
        88: "Generative AI"
    },

    protocols: {
        0: 'HOPOPT [0]',
        1: 'ICMP [1]',
        2: 'IGMP [2]',
        3: 'GGP [3]',
        4: 'IP-in-IP [4]',
        5: 'ST [5]',
        6: 'TCP [6]',
        7: 'CBT [7]',
        8: 'EGP [8]',
        9: 'IGP [9]',
        10: 'BBN-RCC-MON [10]',
        11: 'NVP-II [11]',
        12: 'PUP [12]',
        13: 'ARGUS [13]',
        14: 'EMCON [14]',
        15: 'XNET [15]',
        16: 'CHAOS [16]',
        17: 'UDP [17]',
        18: 'MUX [18]',
        19: 'DCN-MEAS [19]',
        20: 'HMP [20]',
        21: 'PRM [21]',
        22: 'XNS-IDP [22]',
        23: 'TRUNK-1 [23]',
        24: 'TRUNK-2 [24]',
        25: 'LEAF-1 [25]',
        26: 'LEAF-2 [26]',
        27: 'RDP [27]',
        28: 'IRTP [28]',
        29: 'ISO-TP4 [29]',
        30: 'NETBLT [30]',
        31: 'MFE-NSP [31]',
        32: 'MERIT-INP [32]',
        33: 'DCCP [33]',
        34: '3PC [34]',
        35: 'IDPR [35]',
        36: 'XTP [36]',
        37: 'DDP [37]',
        38: 'IDPR-CMTP [38]',
        39: 'TP++ [39]',
        40: 'IL [40]',
        41: 'IPv6 [41]',
        42: 'SDRP [42]',
        43: 'IPv6-Route [43]',
        44: 'IPv6-Frag [44]',
        45: 'IDRP [45]',
        46: 'RSVP [46]',
        47: 'GRE [47]',
        48: 'MHRP [48]',
        49: 'BNA [49]',
        50: 'ESP [50]',
        51: 'AH [51]',
        52: 'I-NLSP [52]',
        53: 'SWIPE [53]',
        54: 'NARP [54]',
        55: 'MOBILE [55]',
        56: 'TLSP [56]',
        57: 'SKIP [57]',
        58: 'IPv6-ICMP [58]',
        59: 'IPv6-NoNxt [59]',
        60: 'IPv6-Opts [60]',
        62: 'CFTP [62]',
        64: 'SAT-EXPAK [64]',
        65: 'KRYPTOLAN [65]',
        66: 'RVD [66]',
        67: 'IPPC [67]',
        69: 'SAT-MON [69]',
        70: 'VISA [70]',
        71: 'IPCU [71]',
        72: 'CPNX [72]',
        73: 'CPHB [73]',
        74: 'WSN [74]',
        75: 'PVP [75]',
        76: 'BR-SAT-MON [76]',
        77: 'SUN-ND [77]',
        78: 'WB-MON [78]',
        79: 'WB-EXPAK [79]',
        80: 'ISO-IP [80]',
        81: 'VMTP [81]',
        82: 'SECURE-VMTP [82]',
        83: 'VINES [83]',
        84: 'TTP [84]',
        85: 'NSFNET-IGP [85]',
        86: 'DGP [86]',
        87: 'TCF [87]',
        88: 'EIGRP [88]',
        89: 'OSPF [89]',
        90: 'Sprite-RPC [90]',
        91: 'LARP [91]',
        92: 'MTP [92]',
        93: 'AX.25 [93]',
        94: 'IPIP [94]',
        95: 'MICP [95]',
        96: 'SCC-SP [96]',
        97: 'ETHERIP [97]',
        98: 'ENCAP [98]',
        100: 'GMTP [100]',
        101: 'IFMP [101]',
        102: 'PNNI [102]',
        103: 'PIM [103]',
        104: 'ARIS [104]',
        105: 'SCPS [105]',
        106: 'QNX [106]',
        107: 'A/N [107]',
        108: 'IPComp [108]',
        109: 'SNP [109]',
        110: 'Compaq-Peer [110]',
        111: 'IPX-in-IP [111]',
        112: 'VRRP [112]',
        113: 'PGM [113]',
        115: 'L2TP [115]',
        116: 'DDX [116]',
        117: 'IATP [117]',
        118: 'STP [118]',
        119: 'SRP [119]',
        120: 'UTI [120]',
        121: 'SMP [121]',
        122: 'SM [122]',
        123: 'PTP [123]',
        124: 'IS-IS [124]',
        125: 'FIRE [125]',
        126: 'CRTP [126]',
        127: 'CRUDP [127]',
        128: 'SSCOPMCE [128]',
        129: 'IPLT [129]',
        130: 'SPS [130]',
        131: 'PIPE [131]',
        132: 'SCTP [132]',
        133: 'FC [133]',
        134: 'RSVP-E2E-IGNORE [134]',
        135: 'Mobility [135]',
        136: 'UDPLite [136]',
        137: 'MPLS-in-IP [137]',
        138: 'manet [138]',
        139: 'HIP [139]',
        140: 'Shim6 [140]',
        141: 'WESP [141]',
        142: 'ROHC [142]',
        default: 'Unknown'.t()
    },

    httpMethods: {
        'O': 'OPTIONS (O)',
        'G': 'GET (G)',
        'H': 'HEAD (H)',
        'P': 'POST (P)',
        'U': 'PUT (U)',
        'D': 'DELETE (D)',
        'T': 'TRACE (T)',
        'C': 'CONNECT (C)',
        'X': 'NON-STANDARD (X)'
    },

    emailActions: {
        'P': 'pass message'.t(),
        'M': 'mark message'.t(),
        'D': 'drop message'.t(),
        'B': 'block message'.t(),
        'Q': 'quarantine message'.t(),
        'S': 'pass safelist message'.t(),
        'Z': 'pass oversize message'.t(),
        'O': 'pass outbound message'.t(),
        'F': 'block message (scan failure)'.t(),
        'G': 'pass message (scan failure)'.t(),
        'Y': 'block message (greylist)'.t()
    },

    priorities: {
        0: '',
        1: 'Very High'.t(),
        2: 'High'.t(),
        3: 'Medium'.t(),
        4: 'Low'.t(),
        5: 'Limited'.t(),
        6: 'Limited More'.t(),
        7: 'Limited Severely'.t()
    },

    loginReasons: {
        U: 'invalid username'.t(),
        P: 'invalid password'.t(),
        T: 'invalid TOTP'.t(),
        I: 'logged in successfully'.t(),
        O: 'logged out successfully'.t()
    },

    icmps: {
        0: 'Echo Reply'.t(),
        1: 'Unassigned'.t(),
        2: 'Unassigned'.t(),
        3: 'Destination Unreachable'.t(),
        4: 'Source Quench (Deprecated)'.t(),
        5: 'Redirect'.t(),
        6: 'Alternate Host Address (Deprecated)'.t(),
        7: 'Unassigned'.t(),
        8: 'Echo'.t(),
        9: 'Router Advertisement'.t(),
        10: 'Router Solicitation'.t(),
        11: 'Time Exceeded'.t(),
        12: 'Parameter Problem'.t(),
        13: 'Timestamp'.t(),
        14: 'Timestamp Reply'.t(),
        15: 'Information Request (Deprecated)'.t(),
        16: 'Information Reply (Deprecated)'.t(),
        17: 'Address Mask Request (Deprecated)'.t(),
        18: 'Address Mask Reply (Deprecated)'.t(),
        19: 'Reserved (for Security)'.t(),
        20: 'Reserved (for Robustness Experiment)'.t(),
        21: 'Reserved (for Robustness Experiment)'.t(),
        22: 'Reserved (for Robustness Experiment)'.t(),
        23: 'Reserved (for Robustness Experiment)'.t(),
        24: 'Reserved (for Robustness Experiment)'.t(),
        25: 'Reserved (for Robustness Experiment)'.t(),
        26: 'Reserved (for Robustness Experiment)'.t(),
        27: 'Reserved (for Robustness Experiment)'.t(),
        28: 'Reserved (for Robustness Experiment)'.t(),
        29: 'Reserved (for Robustness Experiment)'.t(),
        30: 'Traceroute (Deprecated)'.t(),
        31: 'Datagram Conversion Error (Deprecated)'.t(),
        32: 'Mobile Host Redirect (Deprecated)'.t(),
        33: 'IPv6 Where-Are-You (Deprecated)'.t(),
        34: 'IPv6 I-Am-Here (Deprecated)'.t(),
        35: 'Mobile Registration Request (Deprecated)'.t(),
        36: 'Mobile Registration Reply (Deprecated)'.t(),
        37: 'Domain Name Request (Deprecated)'.t(),
        38: 'Domain Name Reply (Deprecated)'.t(),
        39: 'SKIP (Deprecated)'.t(),
        40: 'Photuris'.t(),
        41:  'ICMP messages utilized by experimental mobility protocols'.t(),
        253: 'RFC3692-style Experiment 1'.t(),
        254: 'RFC3692-style Experiment 2'.t(),
        255: 'Reserved'.t()
    },

    countries: {
        XU: 'Unknown'.t(),
        XL: 'Local'.t(),
        AF: 'Afghanistan'.t(),
        AX: 'Aland Islands'.t(),
        AL: 'Albania'.t(),
        DZ: 'Algeria'.t(),
        AS: 'American Samoa'.t(),
        AD: 'Andorra'.t(),
        AO: 'Angola'.t(),
        AI: 'Anguilla'.t(),
        AQ: 'Antarctica'.t(),
        AG: 'Antigua and Barbuda'.t(),
        AR: 'Argentina'.t(),
        AM: 'Armenia'.t(),
        AW: 'Aruba'.t(),
        AU: 'Australia'.t(),
        AT: 'Austria'.t(),
        AZ: 'Azerbaijan'.t(),
        BS: 'Bahamas'.t(),
        BH: 'Bahrain'.t(),
        BD: 'Bangladesh'.t(),
        BB: 'Barbados'.t(),
        BY: 'Belarus'.t(),
        BE: 'Belgium'.t(),
        BZ: 'Belize'.t(),
        BJ: 'Benin'.t(),
        BM: 'Bermuda'.t(),
        BT: 'Bhutan'.t(),
        BO: 'Bolivia, Plurinational State of'.t(),
        BQ: 'Bonaire, Sint Eustatius and Saba'.t(),
        BA: 'Bosnia and Herzegovina'.t(),
        BW: 'Botswana'.t(),
        BV: 'Bouvet Island'.t(),
        BR: 'Brazil'.t(),
        IO: 'British Indian Ocean Territory'.t(),
        BN: 'Brunei Darussalam'.t(),
        BG: 'Bulgaria'.t(),
        BF: 'Burkina Faso'.t(),
        BI: 'Burundi'.t(),
        KH: 'Cambodia'.t(),
        CM: 'Cameroon'.t(),
        CA: 'Canada'.t(),
        CV: 'Cape Verde'.t(),
        KY: 'Cayman Islands'.t(),
        CF: 'Central African Republic'.t(),
        TD: 'Chad'.t(),
        CL: 'Chile'.t(),
        CN: 'China'.t(),
        CX: 'Christmas Island'.t(),
        CC: 'Cocos (Keeling) Islands'.t(),
        CO: 'Colombia'.t(),
        KM: 'Comoros'.t(),
        CG: 'Congo'.t(),
        CD: 'Congo, the Democratic Republic of the'.t(),
        CK: 'Cook Islands'.t(),
        CR: 'Costa Rica'.t(),
        CI: "Cote d'Ivoire".t(),
        HR: 'Croatia'.t(),
        CU: 'Cuba'.t(),
        CW: 'Curacao'.t(),
        CY: 'Cyprus'.t(),
        CZ: 'Czech Republic'.t(),
        DK: 'Denmark'.t(),
        DJ: 'Djibouti'.t(),
        DM: 'Dominica'.t(),
        DO: 'Dominican Republic'.t(),
        EC: 'Ecuador'.t(),
        EG: 'Egypt'.t(),
        SV: 'El Salvador'.t(),
        GQ: 'Equatorial Guinea'.t(),
        ER: 'Eritrea'.t(),
        EE: 'Estonia'.t(),
        ET: 'Ethiopia'.t(),
        FK: 'Falkland Islands (Malvinas)'.t(),
        FO: 'Faroe Islands'.t(),
        FJ: 'Fiji'.t(),
        FI: 'Finland'.t(),
        FR: 'France'.t(),
        GF: 'French Guiana'.t(),
        PF: 'French Polynesia'.t(),
        TF: 'French Southern Territories'.t(),
        GA: 'Gabon'.t(),
        GM: 'Gambia'.t(),
        GE: 'Georgia'.t(),
        DE: 'Germany'.t(),
        GH: 'Ghana'.t(),
        GI: 'Gibraltar'.t(),
        GR: 'Greece'.t(),
        GL: 'Greenland'.t(),
        GD: 'Grenada'.t(),
        GP: 'Guadeloupe'.t(),
        GU: 'Guam'.t(),
        GT: 'Guatemala'.t(),
        GG: 'Guernsey'.t(),
        GN: 'Guinea'.t(),
        GW: 'Guinea-Bissau'.t(),
        GY: 'Guyana'.t(),
        HT: 'Haiti'.t(),
        HM: 'Heard Island and McDonald Islands'.t(),
        VA: 'Holy See (Vatican City State)'.t(),
        HN: 'Honduras'.t(),
        HK: 'Hong Kong'.t(),
        HU: 'Hungary'.t(),
        IS: 'Iceland'.t(),
        IN: 'India'.t(),
        ID: 'Indonesia'.t(),
        IR: 'Iran, Islamic Republic of'.t(),
        IQ: 'Iraq'.t(),
        IE: 'Ireland'.t(),
        IM: 'Isle of Man'.t(),
        IL: 'Israel'.t(),
        IT: 'Italy'.t(),
        JM: 'Jamaica'.t(),
        JP: 'Japan'.t(),
        JE: 'Jersey'.t(),
        JO: 'Jordan'.t(),
        KZ: 'Kazakhstan'.t(),
        KE: 'Kenya'.t(),
        KI: 'Kiribati'.t(),
        KP: "Korea, Democratic People's Republic of".t(),
        KR: 'Korea, Republic of'.t(),
        KW: 'Kuwait'.t(),
        KG: 'Kyrgyzstan'.t(),
        LA: "Lao People's Democratic Republic".t(),
        LV: 'Latvia'.t(),
        LB: 'Lebanon'.t(),
        LS: 'Lesotho'.t(),
        LR: 'Liberia'.t(),
        LY: 'Libya'.t(),
        LI: 'Liechtenstein'.t(),
        LT: 'Lithuania'.t(),
        LU: 'Luxembourg'.t(),
        MO: 'Macao'.t(),
        MK: 'Macedonia, the Former Yugoslav Republic of'.t(),
        MG: 'Madagascar'.t(),
        MW: 'Malawi'.t(),
        MY: 'Malaysia'.t(),
        MV: 'Maldives'.t(),
        ML: 'Mali'.t(),
        MT: 'Malta'.t(),
        MH: 'Marshall Islands'.t(),
        MQ: 'Martinique'.t(),
        MR: 'Mauritania'.t(),
        MU: 'Mauritius'.t(),
        YT: 'Mayotte'.t(),
        MX: 'Mexico'.t(),
        FM: 'Micronesia, Federated States of'.t(),
        MD: 'Moldova, Republic of'.t(),
        MC: 'Monaco'.t(),
        MN: 'Mongolia'.t(),
        ME: 'Montenegro'.t(),
        MS: 'Montserrat'.t(),
        MA: 'Morocco'.t(),
        MZ: 'Mozambique'.t(),
        MM: 'Myanmar'.t(),
        NA: 'Namibia'.t(),
        NR: 'Nauru'.t(),
        NP: 'Nepal'.t(),
        NL: 'Netherlands'.t(),
        NC: 'New Caledonia'.t(),
        NZ: 'New Zealand'.t(),
        NI: 'Nicaragua'.t(),
        NE: 'Niger'.t(),
        NG: 'Nigeria'.t(),
        NU: 'Niue'.t(),
        NF: 'Norfolk Island'.t(),
        MP: 'Northern Mariana Islands'.t(),
        NO: 'Norway'.t(),
        OM: 'Oman'.t(),
        PK: 'Pakistan'.t(),
        PW: 'Palau'.t(),
        PS: 'Palestine, State of'.t(),
        PA: 'Panama'.t(),
        PG: 'Papua New Guinea'.t(),
        PY: 'Paraguay'.t(),
        PE: 'Peru'.t(),
        PH: 'Philippines'.t(),
        PN: 'Pitcairn'.t(),
        PL: 'Poland'.t(),
        PT: 'Portugal'.t(),
        PR: 'Puerto Rico'.t(),
        QA: 'Qatar'.t(),
        RE: 'Reunion'.t(),
        RO: 'Romania'.t(),
        RU: 'Russian Federation'.t(),
        RW: 'Rwanda'.t(),
        BL: 'Saint Barthelemy'.t(),
        SH: 'Saint Helena, Ascension and Tristan da Cunha'.t(),
        KN: 'Saint Kitts and Nevis'.t(),
        LC: 'Saint Lucia'.t(),
        MF: 'Saint Martin (French part)'.t(),
        PM: 'Saint Pierre and Miquelon'.t(),
        VC: 'Saint Vincent and the Grenadines'.t(),
        WS: 'Samoa'.t(),
        SM: 'San Marino'.t(),
        ST: 'Sao Tome and Principe'.t(),
        SA: 'Saudi Arabia'.t(),
        SN: 'Senegal'.t(),
        RS: 'Serbia'.t(),
        SC: 'Seychelles'.t(),
        SL: 'Sierra Leone'.t(),
        SG: 'Singapore'.t(),
        SX: 'Sint Maarten (Dutch part)'.t(),
        SK: 'Slovakia'.t(),
        SI: 'Slovenia'.t(),
        SB: 'Solomon Islands'.t(),
        SO: 'Somalia'.t(),
        ZA: 'South Africa'.t(),
        GS: 'South Georgia and the South Sandwich Islands'.t(),
        SS: 'South Sudan'.t(),
        ES: 'Spain'.t(),
        LK: 'Sri Lanka'.t(),
        SD: 'Sudan'.t(),
        SR: 'Suriname'.t(),
        SJ: 'Svalbard and Jan Mayen'.t(),
        SZ: 'Swaziland'.t(),
        SE: 'Sweden'.t(),
        CH: 'Switzerland'.t(),
        SY: 'Syrian Arab Republic'.t(),
        TW: 'Taiwan, Province of China'.t(),
        TJ: 'Tajikistan'.t(),
        TZ: 'Tanzania, United Republic of'.t(),
        TH: 'Thailand'.t(),
        TL: 'Timor-Leste'.t(),
        TG: 'Togo'.t(),
        TK: 'Tokelau'.t(),
        TO: 'Tonga'.t(),
        TT: 'Trinidad and Tobago'.t(),
        TN: 'Tunisia'.t(),
        TR: 'Turkey'.t(),
        TM: 'Turkmenistan'.t(),
        TC: 'Turks and Caicos Islands'.t(),
        TV: 'Tuvalu'.t(),
        UG: 'Uganda'.t(),
        UA: 'Ukraine'.t(),
        AE: 'United Arab Emirates'.t(),
        GB: 'United Kingdom'.t(),
        US: 'United States'.t(),
        UM: 'United States Minor Outlying Islands'.t(),
        UY: 'Uruguay'.t(),
        UZ: 'Uzbekistan'.t(),
        VU: 'Vanuatu'.t(),
        VE: 'Venezuela, Bolivarian Republic of'.t(),
        VN: 'Viet Nam'.t(),
        VG: 'Virgin Islands, British'.t(),
        VI: 'Virgin Islands, U.S.'.t(),
        WF: 'Wallis and Futuna'.t(),
        EH: 'Western Sahara'.t(),
        YE: 'Yemen'.t(),
        ZM: 'Zambia'.t(),
        ZW: 'Zimbabwe'.t(),
    },
});
Ext.syncRequire('Ung.common.threatprevention');
Ext.define('TableConfig', {
    alternateClassName: 'TableConfig',
    singleton: true,

    tableConfig: {},

    initialize: function() {
        var me = this;

        /**
         * attach extra tables configuration
         * e.g. thareat prevention info
         */
        Ext.Object.each(Ung.common.TableConfig, function(key) {
            Ung.common.TableConfig[key].initialize(me.tableConfig);
        });

        /**
         * generate the tables fields, columns configurations used for reports grids
         * this replaces the older TableConfig.tableConfig definitions
         */
        Ext.Object.each(Map.tables, function (table, fields) {
            var tFields = [], tColumns = [];

            Ext.Array.each(fields, function (key) {
                var field = Map.fields[key].fld;
                var column = Map.fields[key].col;

                column.dataIndex = column.dataIndex || key;
                if (!column.filter) { column.filter = Rndr.filters.string; }
                tColumns.push(column);

                field.name = field.name || key;
                tFields.push(field);
            });

            TableConfig.tableConfig[table] = {
                fields: tFields,
                columns: tColumns
            };
        });

        Ext.Object.each(Map.listeners, function (table, listeners) {
            TableConfig.tableConfig[table].listeners = listeners;
        });
    },

    getConfig: function(tableName) {
        if(TableConfig.validated == false){
            TableConfig.validate();
        }
        return TableConfig.tableConfig[tableName];
    },

    checkHealth: function() {
        if(!rpc.reportsManager) {
            console.info('Reports not installed!');
            return;
        }
        var i, table, column, systemColumns, systemColumnsMap, tableConfigColumns, tableConfigColumnsMap;
        var systemTables = rpc.reportsManager.getTables();
        var systemTablesMap={};
        var missingTables = [];
        for(i=0; i<systemTables.length;i++) {
            systemTablesMap[systemTables[i]] = true;

            if(!this.tableConfig[systemTables[i]]) {

                // ignore 'totals' tables (from old reports and will be deprecated soon)
                if ( systemTables[i].indexOf('totals') !== -1 ) {
                    continue;
                }
                // ignore 'mail_msgs' table (will be deprecated soon)
                if ( systemTables[i].indexOf('mail_msgs') !== -1 ) {
                    continue;
                }
                missingTables.push(systemTables[i]);
            }
        }
        if(missingTables.length>0) {
            console.log('Warning: Missing tables: ' + missingTables.join(', '));
        }
        var extraTables = [];
        for (table in this.tableConfig) {
            if (this.tableConfig.hasOwnProperty(table)) {
                if(!systemTablesMap[table]) {
                    extraTables.push(table);
                }
            }
        }
        if (extraTables.length > 0) {
            console.log('Warning: Extra tables: ' + extraTables.join(', '));
        }

        for (table in this.tableConfig) {
            tableConfigColumns = this.tableConfig[table].columns;
            if(systemTablesMap[table]) {
                systemColumns = rpc.reportsManager.getColumnsForTable(table);
                systemColumnsMap = {};
                tableConfigColumnsMap = {};
                for(i=0;i<tableConfigColumns.length; i++) {
                    tableConfigColumnsMap[tableConfigColumns[i].dataIndex] = tableConfigColumns[i];
                }
                var missingColumns = [];
                for(i=0;i<systemColumns.length; i++) {
                    systemColumnsMap[systemColumns[i]] = true;
                    var columnConfig = tableConfigColumnsMap[systemColumns[i]];
                    if ( columnConfig === null ) {
                        missingColumns.push(systemColumns[i]);
                    } else {
                        if (! columnConfig.width ) {
                            console.log('Warning: Table "' + table + '" Columns: "' + columnConfig.dataIndex + '" missing width');
                        }
                    }
                }
                if (missingColumns.length > 0) {
                    console.log('Warning: Table "' + table + '" Missing columns: ' + missingColumns.join(', '));
                }

                var extraColumns = [];
                for (column in tableConfigColumnsMap) {
                    if (!systemColumnsMap[column]) {
                        extraColumns.push(column);
                    }
                }
                if (extraColumns.length > 0) {
                    console.log('Warning: Table "' + table + '" Extra columns: ' + extraColumns.join(', '));
                }

            }
        }

    },

    getColumnsForTable: function(table, store) {
        if(table !== null) {
            var tableConfig = this.getConfig(table);
            var columns = [], col;
            if(tableConfig !== null && Ext.isArray(tableConfig.columns)) {
                for(var i = 0; i<tableConfig.columns.length; i++) {
                    col = tableConfig.columns[i];
                    var name = col.header;
                    columns.push({
                        dataIndex: col.dataIndex,
                        header: name
                    });
                }
            }

            store.loadData(columns);
        }
    },

    getColumnHumanReadableName: function(columnName) {
        /**
         * NGFW-12862
         * if somehow columnName is not found in Map (it should be defined)
         * than return it as is ('some_column_name' => 'some column name')
         */
        return Map.fields[columnName] ? Map.fields[columnName].col.text : columnName.replace(/_/g,' ');
    },

    // new methods .........
    generate: function (table) {
        var checkboxes = [], comboItems = [];
        var tableConfig = this.tableConfig[table];

        if (!tableConfig) {
            console.log('Table not found!');
            return;
        }

        // generate checkboxes and menu
        Ext.Array.each(tableConfig.columns, function (column) {
            checkboxes.push({ boxLabel: column.text, inputValue: column.dataIndex, name: 'cbGroup' });
            comboItems.push({
                text: column.text,
                value: column.dataIndex
            });
        });
        tableConfig.checkboxes = checkboxes;
        tableConfig.comboItems = comboItems;

        return tableConfig;
    },

    validated: false,
    validate: function(){
        for(var table in TableConfig.tableConfig){
            if(table == 'syslog'){
                continue;
            }
            TableConfig.tableConfig[table].fields.forEach( function( field ){
                // if(!field.type &&
                //     ( !field.sortType ||
                //       field.sortType != 'asTimestamp' ) ){
                //     console.log(table + ": field=" + field.name + ", missing type" );
                // }
            });
            TableConfig.tableConfig[table].columns.forEach( function( column ){
                if(column.width === undefined){
                    console.log(table + ":" + column.text + ", no width");
                }
                if(!column.filter &&
                    ( !column.xtype || column.xtype != "actioncolumn") ){
                    console.log(table + ": column=" + column.text + ", no filter");
                }
            });
        }
        TableConfig.validated = true;
    },

    // end new methods

    // checks if a table contains at least one of the columns passed as param
    containsColumns: function (table, columns) {
        var contains = false, fields = TableConfig.tableConfig[table].fields;
        Ext.Array.each(fields, function (field) {
            Ext.Array.each(columns, function (col) {
                if (field.name === col) {
                    contains = true;
                }
            });
        });
        return contains;
    },

    getTableField: function(table, name){
        var tableField = null;
        if(TableConfig.tableConfig[table] &&
            TableConfig.tableConfig[table]['fields']){
            TableConfig.tableConfig[table]['fields'].forEach( function(field){
                if(field['name'] == name){
                    tableField = field;
                }
            });
        }
        return tableField;
    },

    /**
     * Add table fields to a table's field object.
     * @param String identifier of table.
     * @param Object (or Array of objects) of fields to add.
     */
    setTableField: function(table, field){
        Ext.Array.push(
            TableConfig.tableConfig[table]['fields'],
            field
        );
    },

    getFromType: function(table, name){
        var fromType = null;
        if(TableConfig.tableConfig[table] &&
            TableConfig.tableConfig[table]['fields']){
            TableConfig.tableConfig[table]['fields'].forEach( function(field){
                if( ( field['name'] == name ) &&
                    field['fromType'] &&
                    TableConfig.fromTypes[field['fromType']]){
                    fromType = TableConfig.fromTypes[field['fromType']];
                }
            });
        }
        return fromType;
    },

    /**
     * Set from type for fields.
     * @param Object of fromTypes to add.
     */
    setFromType: function(fromTypes){
        Ext.Object.each( fromTypes, function(key, value){
            TableConfig.fromTypes[key] = value;
        });
    },

    getTableColumn: function(table, name){
        var tableColumn = null;
        if(table == null){
            table = TableConfig.getFirstTableFromField(name);
        }
        if(TableConfig.tableConfig[table] &&
            TableConfig.tableConfig[table]['columns']){
            TableConfig.tableConfig[table]['columns'].forEach( function(column){
                if(column['dataIndex'] == name){
                    tableColumn = column;
                }
            });
        }
        return tableColumn;
    },

    setTableListener: function(table, listener){
        if(!("listeners" in TableConfig.tableConfig[table])){
            TableConfig.tableConfig[table]["listeners"] = {};
        }
        Ext.Object.each( listener, function(key, value){
            TableConfig.tableConfig[table]["listeners"][key] = value;
        });
    },

    getFirstTableFromField: function(fieldName){
        var table = null;
        Ext.Object.each(TableConfig.tableConfig, function(tableName, tableValues){
            tableValues['fields'].forEach(function(field){
                if(field['name'] == fieldName){
                    table = tableName;
                    return false;
                }
            });
            if(table != null){
                return false;
            }
        });
        return table;
    },

    getDisplayValue: function(value, table, field, record){
        if(arguments[6]){
            var column = arguments[6].getGridColumns()[arguments[4]];
            table = column.table;
            field = column.field;
        }
        var tableField = TableConfig.getTableField(table, field);
        var tableColumn = TableConfig.getTableColumn(table, field);
        if(tableField && tableField['convert']){
            value = tableField['convert'](value, null, record);
        }
        if(tableColumn && tableColumn['renderer']){
            value = tableColumn['renderer'](value, null, record);
        }
        return value;
    },

    getValues: function( table, field, record){
        var values = [];
        var tableColumn = TableConfig.getTableColumn(table, field);
        if(tableColumn && tableColumn['renderer']){
            var rendererValues = tableColumn['renderer'](Renderer.listKey, null, record);
            if(Array.isArray(rendererValues)){
                values = rendererValues;
            }else if(typeof rendererValues === 'object'){
                for(var key in rendererValues){
                    if(rendererValues.hasOwnProperty(key)){
                        values.push([String(key), rendererValues[key]]);
                    }
                }
            }
        }
        return values;
    },

    fromTypes: {},

});
TableConfig.initialize();
