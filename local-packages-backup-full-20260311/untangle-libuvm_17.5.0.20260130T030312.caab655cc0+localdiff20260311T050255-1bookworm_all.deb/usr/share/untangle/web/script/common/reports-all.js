Ext.define('Ung.reports.cmp.ColorsPicker', {
    extend: 'Ext.form.field.Picker',
    alias: 'widget.colorspicker',

    baseCls: 'colorpicker',

    twoWayBindable: ['value'],
    publishes: ['value'],

    fields: ['color'],

    displayField: false,
    valueField: false,
    // matchFieldWidth: false,

    editable: false,
    hideTrigger: true,

    colorsStore: [],

    colorPalette: [
        // red
        'B71C1C', 'C62828', 'D32F2F', 'E53935', 'F44336', 'EF5350', 'E57373', 'EF9A9A',
        // pink
        '880E4F', 'AD1547', 'C2185B', 'D81B60', 'E91E63', 'EC407A', 'F06292', 'F48FB1',
        // purple
        '4A148C', '6A1B9A', '7B1FA2', '8E24AA', '9C27B0', 'AB47BC', 'BA68C8', 'CE93D8',
        // blue
        '0D47A1', '1565C0', '1976D2', '1E88E5', '2196F3', '42A5F5', '64B5F6', '90CAF9',
        // teal`
        '004D40', '00695C', '00796B', '00897B', '009688', '26A69A', '4DB6AC', '80CBC4',
        // green
        '1B5E20', '2E7D32', '388E3C', '43A047', '4CAF50', '66BB6A', '81C784', 'A5D6A7',
        // limE
        '827717', '9E9D24', 'AFB42B', 'C0CA33', 'CDDC39', 'D4E157', 'DCE775', 'E6EE9C',
        // yellow
        'F57F17', 'F9A825', 'FBC02D', 'FDD835', 'FFEB3B', 'FFEE58', 'FFF176', 'FFF59D',
        // orange
        'E65100', 'EF6C00', 'F57C00', 'FB8C00', 'FF9800', 'FFA726', 'FFB74D', 'FFCC80',
        // brown
        '3E2723', '4E342E', '5D4037', '6D4C41', '795548', '8D6E63', 'A1887F', 'BCAAA4',
        // grey
        '212121', '424242', '616161', '757575', '9E9E9E', 'BDBDBD', 'E0E0E0', 'EEEEEE',
    ],

    fieldSubTpl: [
        // listWrapper div is tabbable in Firefox, for some unfathomable reason
        '<div id="{cmpId}-listWrapper" data-ref="listWrapper"' + (Ext.isGecko ? ' tabindex="-1"' : ''),
        '<tpl foreach="ariaElAttributes"> {$}="{.}"</tpl>',
        ' class="' + Ext.baseCSSPrefix + 'tagfield {fieldCls} {typeCls} {typeCls}-{ui}"<tpl if="wrapperStyle"> style="{wrapperStyle}"</tpl>>',
        '<span id="{cmpId}-selectedText" data-ref="selectedText" aria-hidden="true" class="' + Ext.baseCSSPrefix + 'hidden-clip"></span>',
        '<ul id="{cmpId}-itemList" data-ref="itemList" role="presentation" class="' + Ext.baseCSSPrefix + 'tagfield-list{itemListCls}">',
        '<li id="{cmpId}-inputElCt" data-ref="inputElCt" role="presentation" class="' + Ext.baseCSSPrefix + 'tagfield-input">',
        '<input id="{cmpId}-inputEl" data-ref="inputEl" type="{type}" ',
        '<tpl foreach="inputElAriaAttributes"> {$}="{.}"</tpl>',
        'class="' + Ext.baseCSSPrefix + 'tagfield-input-field {inputElCls} {emptyCls}" autocomplete="off">',
        '</li>',
        '</ul>',
        '<ul id="{cmpId}-ariaList" data-ref="ariaList" role="listbox"',
        '<tpl if="ariaSelectedListLabel"> aria-label="{ariaSelectedListLabel}"</tpl>',
        '<tpl if="multiSelect"> aria-multiselectable="true"</tpl>',
        ' class="' + Ext.baseCSSPrefix + 'tagfield-arialist">',
        '</ul>',
        '</div>',
        {
            disableFormats: true
        }
    ],

    childEls: [
        'listWrapper', 'itemList', 'inputEl', 'inputElCt', 'selectedText', 'ariaList'
    ],

    initComponent: function() {
        this.callParent(arguments);
    },

    createPicker: function() {
        var me = this;
        me.grid = Ext.create('Ext.grid.Panel', {
            renderTo: Ext.getBody(),
            // width: this.bodyEl.getWidth(),
            scrollable: true,
            floating: true,
            minHeight: 200,
            width: 150,
            disableSelection: true,
            enableColumnHide: false,
            hideHeaders: true,
            emptyText: '<p style="text-align: center; margin: 0; line-height: 2;"><i class="fa fa-info-circle fa-lg"></i> No Colors!</p>',
            viewConfig: {
                stripeRows: false,
                trackOver: false
            },
            // plugins: [{
            //     ptype: 'cellediting',
            //     clicksToEdit: 1
            // }],
            store: {
                data: me.colorsStore,
                fields: ['color'],
                listeners: {
                    datachanged: function (store) {
                        var colors = [];
                        store.each(function (rec) {
                            colors.push(rec.get('color'));
                        });
                        me.setValue(colors);
                    },
                    update: function (store) {
                        var colors = [];
                        store.each(function (rec) {
                            colors.push(rec.get('color'));
                        });
                        me.setValue(colors);
                    }
                }
            },
            columns: [{
                xtype: 'widgetcolumn',
                width: 120,
                widget: {
                    xtype: 'button',
                    bind: {
                        text: '<i class="fa fa-square" style="color: {record.color}"></i> {record.color}',
                    },
                    style: {
                        textAlign: 'left'
                    },
                    menu: {
                        xtype: 'colormenu',
                        colors: me.colorPalette,
                        minHeight: 200,
                        listeners: {
                            select: function (menu, color) {
                                menu.up('button').getViewModel().set('record.color', '#' + color);
                            }
                        }
                    }
                }
            }, {
                xtype: 'actioncolumn',
                width: 30,
                resizable: false,
                sortable: false,
                menuDisabled: true,
                align: 'center',
                iconCls: 'fa fa-times',
                handler: me.removeColor,
                scope: me
            }, {
                flex: 1
            }],
            bbar: [{
                xtype: 'button',
                itemId: 'addbtn',
                text: 'Add'.t(),
                iconCls: 'fa fa-plus-circle',
                handler: me.addColor,
                scope: me
            }, '->', {
                xtype: 'button',
                text: 'Remove All (Use Default)'.t(),
                handler: me.removeAll,
                scope: me
            }, {
                xtype: 'button',
                text: 'Done'.t(),
                iconCls: 'fa fa-check',
                handler: me.finish,
                scope: me
            }],
            listeners: {
                afterrender: function (grid) {
                    grid.getStore().loadData(Ext.Array.map(me.value, function (color) { return { color: color }; }));
                },
                show: function (grid) {
                    grid.getStore().loadData(Ext.Array.map(me.value, function (color) { return { color: color }; }));
                }
            }
        });

        return me.grid;
    },

    addColor: function (btn) {
        this.grid.getStore().add({
            color: '#' + this.colorPalette[Ext.Number.randomInt(0, this.colorPalette.length - 1)]
        });
        // limit amount of colors to max 8
        if (this.grid.getStore().count() >= 8 ) {
            btn.setDisabled(true);
        }
    },

    removeColor: function (view, rowIndex, colIndex, item, e, record) {
        view.focus(); // important to move the focus on the grid so the picker does not collapse
        record.drop();
        if (this.grid.getStore().count() < 8 ) {
            this.grid.down('#addbtn').setDisabled(false);
        }
    },

    removeAll: function () {
        this.grid.getStore().loadData([]);
        this.grid.down('#addbtn').setDisabled(false);
        this.finish();
    },

    finish: function () {
        this.collapse();
    },

    listeners: {
        collapse: function () {
            this.publishValue();
            this.grid.getStore().commitChanges();
        }
    },

    getValue: function () {
        return this.value;
    },

    setValue: function (value) {
        var me = this, render = [];
        me.value = value || [];

        // if (me.grid) {
        //     me.grid.getStore().loadData(Ext.Array.map(me.value, function (color) { return { color: color }; }));
        // }
        me.colorsStore = Ext.Array.map(me.value, function (color) { return { color: color }; });

        if (me.value.length === 0) {
            render.push('<li class="no-colors" style="color: #999;">Using the default colors!</li>');
        }

        Ext.Array.each(me.value, function(color) {
            render.push('<li class="color-item" style="background-color: ' + color + '"></li>');
        });

        me.itemList.select('.color-item').destroy();
        me.itemList.select('.no-colors').destroy();
        me.inputElCt.insertHtml('beforeBegin', render.join(''));

        if (render.length === 0) {
            me.inputElCt.insertHtml('beforeBegin', '<li class="no-colors"><em>' + '</em></li>');
        }
    }
});
/**
 * Override needed so when month/year is changed via menus, the select event to be fired
 */
Ext.define('Ung.reports.cmp.DatePicker', {
    extend: 'Ext.picker.Date',
    alias: 'widget.datepicker-conditions',

    onOkClick: function(picker, value) {
        var me = this,
            month = value[0],
            year = value[1],
            date = new Date(year, month, me.getActive().getDate());

        if (date.getMonth() !== month) {
            // 'fix' the JS rolling date conversion if needed
            date = Ext.Date.getLastDateOfMonth(new Date(year, month, 1));
        }
        me.setValue(date);
        me.fireEvent('select', me, me.value);
        me.hideMonthPicker();
    },

    showPrevMonth: function(e) {
        var me = this,
            date = Ext.Date.add(me.activeDate, Ext.Date.MONTH, -1);
        me.setValue(date);
        me.fireEvent('select', me, me.value);
    },

    showNextMonth: function(e) {
        var me = this,
            date = Ext.Date.add(me.activeDate, Ext.Date.MONTH, 1);
        me.setValue(date);
        me.fireEvent('select', me, me.value);
    },

    showPrevYear: function() {
        var me = this,
            date = Ext.Date.add(me.activeDate, Ext.Date.YEAR, -1);
        me.setValue(date);
        me.fireEvent('select', me, me.value);
    },

    showNextYear: function() {
        var me = this,
            date = Ext.Date.add(me.activeDate, Ext.Date.YEAR, 1);
        me.setValue(date);
        me.fireEvent('select', me, me.value);
    }
});
/**
 * Reports Global Conditions used in Reports or Dashboard
  */
Ext.define('Ung.reports.cmp.GlobalConditions', {
    extend: 'Ext.container.Container',
    alias: 'widget.globalconditions',

    // context: 'REPORTS', // can be 'REPORTS' or 'DASHBOARD'

    viewModel: true,

    layout: {
        type: 'hbox',
        align: 'middle'
    },

    items: [{
        xtype: 'component',
        margin: '0 5',
        style: {
            fontSize: '11px'
        },
        html: '<strong>' + 'Conditions:'.t() + '</strong>'
    }, {
        xtype: 'container',
        layout: 'hbox'
    }, {
        xtype: 'button',
        text: 'Add'.t(),
        iconCls: 'fa fa-plus-circle',
        focusable: false,
        menu: {
            plain: true,
            showSeparator: false,
            mouseLeaveDelay: 0,
            items: [{
                xtype: 'radiogroup',
                itemId: 'add_column',
                simpleValue: true,
                reference: 'rg',
                publishes: 'value',
                fieldLabel: '<strong>' + 'Choose Column'.t() + '</strong>',
                labelAlign: 'top',
                columns: 1,
                vertical: true,
                items: [
                    { boxLabel: 'Username'.t(), name: 'col', inputValue: 'username' },
                    { boxLabel: 'Protocol'.t(), name: 'col', inputValue: 'protocol' },
                    { boxLabel: 'Hostname'.t(), name: 'col', inputValue: 'hostname' },
                    { boxLabel: 'Client'.t(), name: 'col', inputValue: 'c_client_addr' },
                    { boxLabel: 'Server'.t(), name: 'col', inputValue: 's_server_addr' },
                    { boxLabel: 'Server Port'.t(), name: 'col', inputValue: 's_server_port' },
                    { boxLabel: 'Policy Id'.t(), name: 'col', inputValue: 'policy_id' }
                ],
                listeners: {
                    change: function(el, newValue, oldValue){
                        var valueText = el.up('menu').down('#add_value_text');
                        var valueCombo =  el.up('menu').down('#add_value_combo');

                        var table = TableConfig.getFirstTableFromField(newValue);
                        var values = TableConfig.getValues(table, newValue);
                        if(values.length){
                            valueCombo.setDisabled(false);
                            valueCombo.setHidden(false);
                            valueCombo.getStore().loadData(values);
                            valueCombo.setValue(valueCombo.getValue() !== null ? valueCombo.getValue() : values[0][0]);
                            valueText.setDisabled(true);
                            valueText.setHidden(true);
                        }else{
                            valueCombo.setDisabled(true);
                            valueCombo.setHidden(true);
                            valueText.setDisabled(false);
                            valueText.setHidden(false);
                        }
                    }
                }
            }, '-', {
                xtype: 'combobox',
                itemId: 'add_operator',
                fieldLabel: '<strong>' + 'Operator'.t() + '</strong>',
                labelAlign: 'top',
                editable: false,
                queryMode: 'local',
                disabled: true,
                bind: {
                    disabled: '{!rg.value}'
                },
                value: '=',
                store: [
                    ['=', 'equals [=]'.t()],
                    ['!=', 'not equals [!=]'.t()],
                    ['>', 'greater than [>]'.t()],
                    ['<', 'less than [<]'.t()],
                    ['>=', 'greater or equal [>=]'.t()],
                    ['<=', 'less or equal [<=]'.t()],
                    ['like', 'like'.t()],
                    ['not like', 'not like'.t()],
                    ['is', 'is'.t()],
                    ['is not', 'is not'.t()],
                    ['in', 'in'.t()],
                    ['not in', 'not in'.t()]
                ]
            }, {
                xtype: 'checkbox',
                itemId: 'add_fmt',
                boxLabel: 'AutoFormat Value'.t(),
                value: true,
                disabled: true,
                bind: {
                    disabled: '{!rg.value}'
                }
            }, '-', {
                xtype: 'container',
                layout: {
                    type: 'hbox',
                    align: 'stretch'
                },
                margin: '5 5',
                defaults: {
                    disabled: true,
                    bind: {
                        disabled: '{!rg.value}'
                    },
                },
                items: [{
                    xtype: 'textfield',
                    itemId: 'add_value_text',
                    enableKeyEvents: true,
                    flex: 1,
                    listeners: {
                        keyup: function (el, e) {
                            if (e.keyCode === 13) {
                                el.up('menu').hide();
                            }
                        }
                    }
                }, {
                    xtype: 'combo',
                    itemId: 'add_value_combo',
                    queryMode: 'local',
                    hidden: true,
                    disabled: true,
                    store: new Ext.data.ArrayStore({
                        fields: ['value', 'display'],
                        data: []
                    }),
                    emptyText: 'Select value'.t(),
                    displayField: 'display',
                    valueField: 'value',
                    allowBlank: false,
                    editable: false
                }, {
                    xtype: 'button',
                    text: 'OK'.t(),
                    iconCls: 'fa fa-check',
                    margin: '0 0 0 5',
                    listeners: {
                        click: function (el) {
                            el.up('menu').hide();
                        }
                    }
                }]
            }, '-', {
                text: '<strong>' + 'More conditions ...'.t() + '</strong>',
                handler: 'onMoreConditions'
            }],
            listeners: {
                hide: 'onAddConditionHide'
            }
        }
    }],

    controller: {

        listen: {
            global: {
                initialload: 'onInitialLoad',
                addglobalcondition: 'onAddGlobalCondition'
            }
        },

        /**
         * When all the app data is ready (e.g. reports store is populated)
         */
        onInitialLoad: function () {
            var me = this, view = me.getView(), vm = me.getViewModel(),
                conditionsHolder = view.down('container'), // container in which conditions are rendered
                conditionsButtons = []; // array of conditions components

            /**
             * When query is changed, update the conditions toolbar
             */
            vm.bind('{query}', function (query) {
                conditionsButtons = [];
                conditionsHolder.removeAll(); // remove all conditions buttons

                var data = {};
                if(query.conditions){
                    query.conditions.forEach( function(condition){
                        data[condition.get("column")] = condition.get("value");
                    });
                }
                var renderRecord = new Ext.data.Model(data);

                Ext.Array.each(query.conditions, function (condition, idx) {
                    // condition button
                    var firstTable = TableConfig.getFirstTableFromField(condition.get('column'));
                    conditionsButtons.push({
                        xtype: 'segmentedbutton',
                        allowToggle: false,
                        margin: '0 5',
                        items: [{
                            text: TableConfig.getColumnHumanReadableName(condition.get('column')) +
                                ' <span style="font-weight: bold; margin: 0 3px;">' +
                                    condition.get('operator') + '</span> ' +
                                    TableConfig.getDisplayValue(condition.get('value'), condition.get('table') ? condition.get('table') : firstTable, condition.get('column'), renderRecord),
                            menu: {
                                plain: true,
                                showSeparator: false,
                                mouseLeaveDelay: 0,
                                condition: condition,
                                items: [{
                                    xtype: 'combobox',
                                    itemId: 'add_operator',
                                    fieldLabel: '<strong>' + 'Operator'.t() + '</strong>',
                                    labelAlign: 'top',
                                    editable: false,
                                    queryMode: 'local',
                                    value: condition.get('operator'),
                                    store: [
                                        ['=', 'equals [=]'.t()],
                                        ['!=', 'not equals [!=]'.t()],
                                        ['>', 'greater than [>]'.t()],
                                        ['<', 'less than [<]'.t()],
                                        ['>=', 'greater or equal [>=]'.t()],
                                        ['<=', 'less or equal [<=]'.t()],
                                        ['like', 'like'.t()],
                                        ['not like', 'not like'.t()],
                                        ['is', 'is'.t()],
                                        ['is not', 'is not'.t()],
                                        ['in', 'in'.t()],
                                        ['not in', 'not in'.t()]
                                    ],
                                    listeners: {
                                        change: function (rg, val) {
                                            condition.set('operator', val);
                                            me.redirect();
                                        }
                                    }
                                }, '-', {
                                    xtype: 'checkbox',
                                    boxLabel: 'AutoFormat Value'.t(),
                                    margin: 5,
                                    value: condition.get('autoFormatValue'),
                                    listeners: {
                                        change: function (el, val) {
                                            condition.set('autoFormatValue', val);
                                            me.redirect();
                                        }
                                    }
                                }, '-', {
                                    xtype: 'container',
                                    name: 'values',
                                    layout: {
                                        type: 'hbox',
                                        align: 'stretch'
                                    },
                                    margin: '5 5',
                                    items: [{
                                        xtype: 'textfield',
                                        name: 'valueText',
                                        enableKeyEvents: true,
                                        flex: 1,
                                        value: condition.get('value'),
                                        listeners: {
                                            keyup: function (el, e) {
                                                if (e.keyCode === 13) {
                                                    el.up('menu').hide();
                                                }
                                            }
                                        }
                                    }, {
                                        xtype: 'combo',
                                        name: 'valueCombo',
                                        queryMode: 'local',
                                        store: new Ext.data.ArrayStore({
                                            fields: ['value', 'display'],
                                            data: []
                                        }),
                                        emptyText: 'Select value'.t(),
                                        displayField: 'display',
                                        valueField: 'value',
                                        allowBlank: false,
                                        editable: false,
                                        value: condition.get('value'),
                                    }, {
                                        xtype: 'button',
                                        name: 'okButton',
                                        text: 'OK'.t(),
                                        iconCls: 'fa fa-check',
                                        margin: '0 0 0 5',
                                        listeners: {
                                            click: function (el) {
                                                el.up('menu').hide();
                                            }
                                        }
                                    }]
                                }],
                                listeners: {
                                    beforeshow: function(menu){
                                        var valueText = menu.down('[name=valueText]');
                                        var valueCombo =  menu.down('[name=valueCombo]');
                                        var values = TableConfig.getValues(menu.condition.get('table') ? menu.condition.get('table') : firstTable, menu.condition.get('column'), renderRecord);
                                        if(values.length){
                                            valueCombo.setDisabled(false);
                                            valueCombo.setHidden(false);
                                            valueCombo.getStore().loadData(values);
                                            valueCombo.setValue(valueCombo.getValue());
                                            valueText.setDisabled(true);
                                            valueText.setHidden(true);
                                        }else{
                                            valueCombo.setDisabled(true);
                                            valueCombo.setHidden(true);
                                            valueText.setDisabled(false);
                                            valueText.setHidden(false);
                                        }
                                    },
                                    show: function(menu){
                                        menu.down("[name=valueCombo]").setWidth(menu.up().getWidth() - menu.down("[name=okButton]").getWidth());
                                    },
                                    beforehide: function (menu) {
                                        var valueText = menu.down('[name=valueText]');
                                        var valueCombo =  menu.down('[name=valueCombo]');

                                        if(valueCombo.isVisible() == true){
                                            menu.condition.set('value', valueCombo.getValue());
                                        }else{
                                            menu.condition.set('value', valueText.getValue());
                                        }
                                    },
                                    hide: function () {
                                        me.redirect();
                                    }
                                }
                            }
                        }, {
                            // removes a condition
                            iconCls: 'fa fa-times',
                            condIndex: idx,
                            handler: function (el) {
                                Ext.Array.removeAt(query.conditions, el.condIndex);
                                me.redirect();
                            }
                        }]
                    });
                });

                conditionsHolder.add(conditionsButtons); // updates the conditions buttons
            });
        },

        /**
         * Add a new global condition from menu when menu closes
         */
        onAddConditionHide: function (menu) {
            var me = this, vm = me.getViewModel(),
                conditions = vm.get('query.conditions'),
                column = menu.down('#add_column').getValue(),
                operator = menu.down('#add_operator').getValue(),
                value = menu.down('#add_value_text').getValue() || menu.down('#add_value_combo').getValue() ,
                autoFormatValue = menu.down('#add_fmt').getValue();

            menu.down('#add_column').reset();
            menu.down('#add_operator').setValue('=');
            menu.down('#add_value_text').setValue('');
            menu.down('#add_value_combo').setValue('');
            menu.down('#add_fmt').setValue(true);

            if (!column || !operator || !value) {
                return;
            }

            conditions.push( new Ung.model.ReportCondition({
                column: column,
                operator: operator,
                value: value,
                autoFormatValue: autoFormatValue,
            }));
            me.redirect();
        },

        /**
         * Create new route based on new global conditions, and redirect to the new location
         */
        redirect: function () {
            var me = this,
                vm = me.getViewModel(),
                queryContext = '',
                queryArguments = [],
                route,
                conditions = vm.get('query.conditions');

            // view.context refers to dashboard or reports in admin servlet
            // app.context refers to admin or reports servlet
            if (Ung.app.conditionsContext === 'REPORTS') {
                queryContext = (Ung.app.context === 'REPORTS') ? '' : '#reports';
                route = vm.get('query.route');
                if (route.cat) {
                    queryArguments.push('cat=' + route.cat);
                }

                if (route.rep) {
                    queryArguments.push('rep=' + route.rep);
                }
            }

            if (Ung.app.conditionsContext === 'DASHBOARD') {
                queryContext = '#dashboard';
            }

            Ung.app.redirectTo(
                queryContext + 
                ( queryArguments.length && conditions.length ? '?' : '' ) +
                queryArguments.join("&") + Ung.model.ReportCondition.getAllQueries(vm.get('query.conditions'), queryArguments.length ? '&' : '')
            );
        },

        /**
         * Manages all possible conditions, besides those predefined in the Add menu,
         * Shows a dialog with all available tables/columns from which to add/remove conditions
         */
        onMoreConditions: function () {
            var me = this, vm = me.getViewModel();
            var tablesComboStore = [], columnsComboStore = [];

            Ext.Object.each(TableConfig.tableConfig, function (table) {
                tablesComboStore.push([table, table]);
            });

            Ext.Array.each(TableConfig.tableConfig['sessions'].columns, function (column) {
                columnsComboStore.push([column.dataIndex, column.text + ' [' + column.dataIndex + ']']);
            });

            var dialog = me.getView().add({
                xtype: 'window',
                renderTo: Ext.getBody(),
                modal: true,
                draggable: false,
                resizable: false,
                width: 800,
                height: 400,
                title: 'Global Conditions'.t(),
                layout: 'fit',
                items: [{
                    xtype: 'grid',
                    sortableColumns: false,
                    enableColumnHide: false,
                    dockedItems: [{
                        xtype: 'toolbar',
                        dock: 'top',
                        ui: 'footer',
                        items: [{
                            xtype: 'combo',
                            width: 250,
                            fieldLabel: 'Select Table'.t(),
                            labelAlign: 'top',
                            queryMode: 'local',
                            store: tablesComboStore,
                            emptyText: 'Select Table'.t(),
                            allowBlank: false,
                            editable: false,
                            value: 'sessions',
                            listeners: {
                                change: function (el, table) {
                                    var columns = TableConfig.tableConfig[table].columns, store = [];
                                    Ext.Array.each(columns, function (column) {
                                        store.push([column.dataIndex, column.text + ' [' + column.dataIndex + ']']);
                                    });
                                    el.nextNode().setStore(store);
                                    el.nextNode().setValue(store[0]);
                                }
                            }
                        }, {
                            xtype: 'combo',
                            fieldLabel: 'Select Column'.t(),
                            emptyText: 'Select Column'.t(),
                            flex: 1,
                            labelAlign: 'top',
                            queryMode: 'local',
                            editable: false,
                            allowBlank: false,
                            store: columnsComboStore,
                            value: columnsComboStore[0]
                        }, {
                            text: 'Add Column'.t(),
                            scale: 'large',
                            handler: function (el) {
                                var tbar = el.up('toolbar'),
                                    col = tbar.down('combo').nextNode().getValue();
                                    // store = el.up('grid').getStore();

                                // if (store.find('column', col) >= 0) {
                                //     Ext.Msg.alert('Info ...', 'Column <strong>' + col + '</strong> is already added!');
                                //     return;
                                // }

                                el.up('grid').getStore().add({
                                    column: col,
                                    value: '',
                                    operator: '=',
                                    autoFormatValue: true,
                                    javaClass: 'com.untangle.app.reports.SqlCondition'
                                });
                            }
                        }]
                    }],
                    bind: {
                        store: {
                            data: '{query.conditions}'
                        }
                    },
                    border: false,
                    columns: [{
                        text: 'Column'.t(),
                        dataIndex: 'column',
                        flex: 1,
                        renderer: function (val) {
                            return TableConfig.getColumnHumanReadableName(val) +  ' [' + val + ']';
                        }
                    }, {
                        xtype: 'widgetcolumn',
                        text: 'Operator'.t(),
                        width: 200,
                        dataIndex: 'operator',
                        widget: {
                            xtype: 'combo',
                            editable: false,
                            queryMode: 'local',
                            bind: '{record.operator}',
                            store: [
                                ['=', 'equals [=]'.t()],
                                ['!=', 'not equals [!=]'.t()],
                                ['>', 'greater than [>]'.t()],
                                ['<', 'less than [<]'.t()],
                                ['>=', 'greater or equal [>=]'.t()],
                                ['<=', 'less or equal [<=]'.t()],
                                ['like', 'like'.t()],
                                ['not like', 'not like'.t()],
                                ['is', 'is'.t()],
                                ['is not', 'is not'.t()],
                                ['in', 'in'.t()],
                                ['not in', 'not in'.t()]
                            ]
                        }
                    }, {
                        xtype: 'widgetcolumn',
                        text: 'Value'.t(),
                        width: 200,
                        widget: {
                            xtype: 'container',
                            layout: 'fit'
                        },
                        onWidgetAttach: 'onValueWidgetAttach'
                    }, {
                        xtype: 'checkcolumn',
                        text: 'AutoFormat'.t(),
                        width: 70,
                        dataIndex: 'autoFormatValue'
                    }, {
                        xtype: 'actioncolumn',
                        width: 40,
                        align: 'center',
                        resizable: false,
                        tdCls: 'action-cell',
                        iconCls: 'fa fa-trash-o',
                        menuDisabled: true,
                        hideable: false,
                        handler: function (view, rowIndex, colIndex, item, e, record) {
                            record.drop();
                        }
                    }]
                }],
                buttons: [{
                    text: 'Cancel'.t(),
                    iconCls: 'fa fa-ban',
                    handler: function (el) {
                        el.up('window').hide();
                    }
                }, {
                    text: 'Apply'.t(),
                    iconCls: 'fa fa-check',
                    handler: function (el) {
                        var win = el.up('window'), store = win.down('grid').getStore();
                        var conditions = [];
                        Ext.Array.pluck(store.getRange(), 'data').forEach( function(data){
                            conditions.push(new Ung.model.ReportCondition(data) );
                        });
                        vm.set('query.conditions', conditions);
                        win.hide();
                        me.redirect();
                    }
                }]
            });

            dialog.show();
        },

        onValueWidgetAttach: function (column, container, record) {
            var me = this, vm = me.getViewModel();

            var data = {};
            vm.get('query.conditions').forEach( function(condition){
                data[condition.get("column")] = condition.get("value");
            });
            var renderRecord = new Ext.data.Model(data);

            var firstTable = TableConfig.getFirstTableFromField(record.get('column'));
            var values = TableConfig.getValues(record.get('table') ? record.get('table') : firstTable, record.get('column'), renderRecord);

            container.removeAll(true);

            if(values.length > 0){
                container.add({
                    xtype: 'combo',
                    queryMode: 'local',
                    store: new Ext.data.ArrayStore({
                        fields: ['value', 'display'],
                        data: values
                    }),
                    emptyText: 'Select value'.t(),
                    displayField: 'display',
                    valueField: 'value',
                    allowBlank: false,
                    editable: false,
                    bind: {
                        value: '{record.value}'
                    },
                });

            }else{
                container.add({
                    xtype: 'textfield',
                    bind: {
                        value: '{record.value}'
                    },
                });
            }
        },

        /**
         * Handles the addglobalcondition event
         * used when adding a new condition from a PIE_GRAPH Data View grid
         */
        cTest: [],
        onAddGlobalCondition: function (table, record, value) {
            var me = this, vm = me.getViewModel(),
                conditions = vm.get('query.conditions');

            var data = {};
            if(typeof(record) != 'object'){
                data[record] = value;
                record = new Ext.data.Model(data);
            }

            var newConditions = [];
            var msgConditions = [];
            data = record.getData();
            for(var field in data){
                if( TableConfig.getTableField(table, field) ){
                    newConditions.push( new Ung.model.ReportCondition({
                        column: field,
                        operator: '=',
                        value: data[field],
                        autoFormatValue: true,
                        table: table
                    }));
                    msgConditions.push(
                        '<strong>' + TableConfig.getColumnHumanReadableName(field) + ' [' + field + '] = ' + TableConfig.getDisplayValue(data[field], table, field, record) + '</strong>'
                    );
                }
            }
            if (!conditions) { return; }

            Ext.Msg.show({
                title: 'Add Global Condition'.t(),
                message: 'Add the following the Global Conditions?'.t() +
                        '<br/><br/>' +
                        msgConditions.join('<br>'),
                buttons: Ext.Msg.YESNO,
                icon: Ext.Msg.QUESTION,
                fn: function (btn) {
                    if (btn === 'yes') {
                        newConditions.forEach( function(condition){
                            conditions.push(condition);
                        });
                        me.redirect();
                    }
                }
            });
        },

        /**
         * Checks if global conditions have effect on selected report,
         * and shows a dialog message, then redirect to Reports home
         */
        checkDisabledSelection: function () {
            var me = this, vm = me.getViewModel(),
                selection = vm.get('selection'), conds = [], msg;

            if (!selection || !selection.get('disabled')) {
                return;
            }

            Ext.Array.each(vm.get('query.conditions'), function (c) {
                conds.push('<li><strong>' + TableConfig.getColumnHumanReadableName(c.column) + ' [' + c.column + '] ' + c.operator + ' ' + TableConfig.getDisplayValue(c.value, c.table, c.column) + '</strong></li>');
            });

            if (selection.isLeaf()) {
                msg = '<strong>' + selection.get('text') + '</strong> report!';
            } else {
                msg = '<strong>' + selection.get('text') + '</strong> category!';
            }

            Ext.Msg.show({
                renderTo: Ext.getBody(),
                width: 500,
                height: 200,
                title: 'Info',
                message: 'Global Conditions: <ul>' + conds.join('') + '</ul>do not apply on ' + msg + '<br/><p>Redirecting to Reports home!</p>',
                buttons: Ext.Msg.OK,
                icon: Ext.Msg.INFO,
                fn: function () {
                    vm.set('query.route', {});
                    me.redirect();
                }
            });
        }
    }
});
Ext.define('Ung.reports.cmp.ImportDialog', {
    extend: 'Ext.window.Window',
    alias: 'widget.importdialog',
    width: 1000,
    height: 500,
    modal: true,
    title: 'Import Reports'.t(),

    layout: 'fit',

    viewModel: {
        data: { reports: [] }
    },

    items: [{
        xtype: 'form',
        url: 'gridSettings',
        border: false,
        layout: 'fit',
        tbar: [{
            xtype: 'filefield',
            reference: 'filefield',
            publishes: 'value',
            margin: 5,
            flex: 1,
            fieldLabel: 'Select File'.t(),
            labelAlign: 'right',
            allowBlank: false,
            listeners: {
                afterrender: 'onAfterRenderField'
            }
        }],

        fbar: [{
            xtype: 'checkbox',
            reference: 'replaceAllCk',
            boxLabel: '<strong>' + 'Replace ALL existing reports'.t() + '</strong>',
            listeners: {
                change: function (ck) {
                    ck.up('window').down('grid').getView().refresh();
                }
            }
        }, '->', {
            text: 'Cancel'.t(),
            iconCls: 'fa fa-ban fa-lg',
            scale: 'medium',
            handler: function (btn) {
                btn.up('window').close();
            }
        }, {
            text: 'Import Selected'.t(),
            iconCls: 'fa fa-arrow-down',
            scale: 'medium',
            disabled: true,
            bind: {
                disabled: '{!reportsGrid.selection}'
            },
            handler: 'doImport'
        }],

        items: [{
            xtype: 'grid',
            reference: 'reportsGrid',
            enableColumnHide: false,
            hideHeaders: true,
            dockedItems: [{
                xtype: 'component',
                margin: 10,
                html: '<i class="fa fa-info-circle fa-lg"></i> ' + 'Select which Reports to import. Red Titles have to be renamed to avoid conflicts with existing records.'.t(),
                hidden: true,
                bind: {
                    hidden: '{!filefield.value}'
                }
            }],
            viewConfig: {
                emptyText: '<p style="text-align: center; margin: 20px; font-size: 14px;"><i class="fa fa-info-circle fa-gray fa-lg"></i> ' + 'Select a file from which to import data!'.t() + '</p>'
            },
            // features: [{
            //     ftype: 'grouping',
            // }],
            plugins: [{
                ptype: 'cellediting',
                clicksToEdit: 1
            }],
            selModel: {
                selType: 'checkboxmodel',
                checkOnly: true
            },
            bind: {
                hideHeaders: '{!filefield.value}',
                store: {
                    data: '{reports}',
                    model: 'Ung.model.Report'
                    // groupField: 'category',
                    // sorters: [{
                    //     property: 'category',
                    //     direction: 'ASC'
                    // }]
                }
            },
            columns: [{
                header: 'Title'.t(),
                dataIndex: 'title',
                width: 200,
                renderer: 'titleRenderer',
                editor: {
                    xtype: 'textfield',
                    allowBlank: false
                }
            }, {
                header: 'Category'.t(),
                dataIndex: 'category',
                width: 150
            }, {
                header: 'ReadOnly'.t(),
                width: 70,
                xtype: 'checkcolumn',
                dataIndex: 'readOnly'
            }, {
                header: 'Description'.t(),
                dataIndex: 'description',
                flex: 1,
                editor: {
                    xtype: 'textfield'
                }
            }, {
                header: 'Type'.t(),
                dataIndex: 'type',
                width: 120,
                renderer: function (val, meta, record) {
                    var str = '<i class="fa ' + record.get('icon') + ' fa-gray" style="font-size: 14px;"></i> ';
                    switch (val) {
                    case 'TEXT': str += 'Text'.t(); break;
                    case 'PIE_GRAPH': str += 'Pie Graph'.t(); break;
                    case 'TIME_GRAPH': str += 'Time Graph'.t(); break;
                    case 'TIME_GRAPH_DYNAMIC': str += 'Time Graph Dynamic'.t(); break;
                    case 'EVENT_LIST': str += 'Event List'.t(); break;
                    }
                    return str;
                }
            }]
        }, {
            xtype: 'hidden',
            name: 'type',
            value: 'import'
        }, {
            xtype: 'hidden',
            name: 'importMode',
            value: 'replace'
        }]

    }],

    controller: {
        onAfterRenderField: function (el) {
            var vm = this.getViewModel();
            if (!window.FileReader) {
                console.info('Browser is not supporting FileReader!');
                return;
            }
            // add change event to underlaying dom file field
            el.getEl().dom.addEventListener('change', function (e) {
                var reader = new FileReader();
                reader.addEventListener('loadend', function () {
                    vm.set('reports', Ext.JSON.decode(reader.result));
                });
                reader.readAsText(e.target.files[0]);
            });
        },

        control: {
            '#': {
                afterrender: 'onAfterRender',
            }
        },

        onAfterRender: function () {
            // build existing reports names list
            var reportTitles = [];
            Ext.getStore('reports').each(function (report) {
                reportTitles.push(report.get('title'));
            });
            this.titles = reportTitles;
        },

        titleRenderer: function (value, metaData) {
            var me = this;
            if (Ext.Array.contains(this.titles, value) && !me.lookup('replaceAllCk').getValue()) {
                metaData.tdStyle = 'color: red';
            }
            return value;
        },

        doImport: function (btn) {
            var me = this, vm = me.getViewModel();
            Rpc.asyncData( 'rpc.appManager.app("reports").getSettings')
            .then(function(result){
                if(Util.isDestroyed(me, vm)){
                    return;
                }

                var reportsSettings = result,
                    selection = me.lookup('reportsGrid').getSelection(),
                    reports = [],
                    titleConflict = false;

                Ext.Array.each(selection, function (record) {
                    if (Ext.Array.contains(me.titles, record.get('title')) && !me.lookup('replaceAllCk').getValue() && !titleConflict) {
                        titleConflict = true;
                    }
                });

                if (titleConflict) {
                    Ext.MessageBox.alert('Warning'.t(), 'There are some report titles conflicts. Make sure selected reports have unique name!'.t());
                    return;
                }

                Ext.Array.each(selection, function (record) {
                    var rep = record.getData();
                    delete rep._id;
                    delete rep.localizedTitle;
                    delete rep.localizedDescription;
                    delete rep.slug;
                    delete rep.categorySlug;
                    delete rep.url;
                    delete rep.icon;

                    // if appending check uniqueId conflit and generate another
                    if (!rep.uniqueId || (!me.lookup('replaceAllCk').getValue() && Ext.getStore('reports').find('uniqueId', rep.uniqueId) > 0)) {
                        rep.uniqueId = 'report-' + Math.random().toString(36).substr(2);
                    }
                    reports.push(rep);
                });

                // if replace all
                if (me.lookup('replaceAllCk').getValue()) {
                    reportsSettings.reportEntries.list = reports;
                } else {
                    // append
                    Ext.Array.push(reportsSettings.reportEntries.list, reports);
                }

                Rpc.asyncData( 'rpc.appManager.app("reports").setSettings', reportsSettings)
                .then(function(result){
                    Rpc.asyncData( 'rpc.appManager.app("reports").getSettings' )
                    .then(function(settings){
                        Ext.getStore('reports').loadData(settings.reportEntries.list);
                        Ext.getStore('reportstree').build();
                        btn.up('window').close();
                        Ung.app.redirectTo('#reports');
                        Ext.MessageBox.alert('Import done!'.t(), reports.length + ' ' + 'Report(s) imported!'.t());
                        if(reports && reports.length){
                            var url = '#reports?cat=' + reports[0].category.replace(/ /g, '-').toLowerCase();
                            if(reports.length == 1){
                                url += '&rep=' + reports[0].title.replace(/ /g, '-').toLowerCase();
                            }
                            Ung.app.redirectTo(url);
                        }
                    },function(ex){
                        Util.handleException(ex);
                    });
                }, function(ex) {
                    Util.handleException(ex);
                });
            }, function(ex) {
                Util.handleException(ex);
            });
        }
    }

});
Ext.define('Ung.reports.cmp.ReportData', {
    extend: 'Ext.grid.Panel',
    alias: 'widget.reportdata',

    viewModel: true,

    store: { data: [] },
    columns: [],
    bbar: ['->', {
        itemId: 'exportGraphData',
        text: 'Export Data'.t(),
        iconCls: 'fa fa-external-link-square',
        handler: 'exportGraphData'
    }],

    controller: {
        control: {
            '#': {
                afterrender: 'onAfterRender',
                deactivate: 'onDeactivate',
                cellclick: 'onCellClick'
            }
        },

        viewModel: true,

        onAfterRender: function () {
            var me = this, vm = me.getViewModel();
            vm.bind('{entry}', function () {
                me.getView().setColumns([]);
                me.getView().getStore().loadData([]);
            });

            vm.bind('{fetching}', function (value) {
                me.getView().setLoading(value);
            });
            vm.bind('{reportData}', function (data) {
                switch (vm.get('entry.type')) {
                case 'TEXT':               me.formatTextData(data); break;
                case 'PIE_GRAPH':          me.formatPieData(data); break;
                case 'TIME_GRAPH':         me.formatTimeData(data); break;
                case 'TIME_GRAPH_DYNAMIC': me.formatTimeDynamicData(data); break;
                }
            });
        },

        onDeactivate: function () {
            // this.getView().setHtml('');
        },

        formatTextData: function (data) {
            var vm = this.getViewModel(),
                entry = vm.get('eEntry') || vm.get('entry'), i, column;

            this.getView().setColumns([{
                dataIndex: 'data',
                header: 'data'.t(),
                flex: 1
            }, {
                dataIndex: 'value',
                header: 'value'.t(),
                width: 200
            }]);

            var reportData = [], value;
            if (data.length > 0 && entry.get('textColumns') !== null) {
                for (i = 0; i < entry.get('textColumns').length; i += 1) {
                    column = entry.get('textColumns')[i].split(' ').splice(-1)[0];
                    value = Ext.isEmpty(data[0][column]) ? 0 : data[0][column];
                    reportData.push({data: column, value: value});
                }
            }
            // vm.set('_currentData', reportData);
            this.getView().getStore().loadData(reportData);
        },

        formatTimeData: function (data) {
            var me = this, vm = this.getViewModel(),
                entry = vm.get('eEntry') || vm.get('entry'), i, column, title;

            var reportDataColumns = [{
                dataIndex: 'time_trunc',
                header: 'Timestamp'.t(),
                width: 130,
                flex: 1,
                renderer: Renderer.timestamp,
                sortable: true
            }];
            var reportDataFields = [
                { name: 'time_trunc', sortType: 'asTimestamp' }
            ];

            for (i = 0; i < entry.get('timeDataColumns').length; i += 1) {
                column = entry.get('timeDataColumns')[i].split(' ').splice(-1)[0];
                title = column;
                reportDataColumns.push({
                    dataIndex: column,
                    header: title,
                    width: entry.get('timeDataColumns').length > 2 ? 60 : 90,
                    renderer: function (val) {
                        return val !== undefined ? val : '-';
                    },
                    sortable: true
                });
                reportDataFields.push({
                    name: column, sortType: 'asFloat'
                });
            }

            me.getView().setColumns(reportDataColumns);
            me.getView().getStore().setFields(reportDataFields);
            me.getView().getStore().loadData(data);
        },

        formatTimeDynamicData: function (data) {
            var vm = this.getViewModel(),
                entry = vm.get('entry'),
                timeDataColumns = [], i, column;


            for (i = 0; i < data.length; i += 1) {
                for (var _column in data[i]) {
                    if (data[i].hasOwnProperty(_column) && _column !== 'time_trunc' && _column !== 'time' && timeDataColumns.indexOf(_column) < 0) {
                        timeDataColumns.push(_column);
                    }
                }
            }

            var reportDataColumns = [{
                dataIndex: 'time_trunc',
                header: 'Timestamp'.t(),
                width: 130,
                flex: 1,
                renderer: Renderer.timestamp
            }];
            var seriesRenderer = null, title;
            if (!Ext.isEmpty(entry.get('seriesRenderer'))) {
                seriesRenderer = Renderer[entry.get('seriesRenderer')];
            }

            for (i = 0; i < timeDataColumns.length; i += 1) {
                column = timeDataColumns[i];
                title = seriesRenderer ? seriesRenderer(column) + ' [' + column + ']' : column;
                // storeFields.push({name: timeDataColumns[i], type: 'integer'});
                reportDataColumns.push({
                    dataIndex: column,
                    header: title,
                    width: timeDataColumns.length > 2 ? 60 : 90
                });
            }

            this.getView().setColumns(reportDataColumns);
            this.getView().getStore().loadData(data);
            // vm.set('_currentData', data);
        },

        formatPieData: function (data) {
            var me = this, vm = me.getViewModel(),
                entry = vm.get('eEntry') || vm.get('entry');

            var header = '<strong>' + TableConfig.getColumnHumanReadableName(entry.get('pieGroupColumn')) + '</strong> <span style="float: right;">[' + entry.get('pieGroupColumn') + ']</span>';

            me.getView().setColumns([{
                dataIndex: entry.get('pieGroupColumn'),
                header: header,
                flex: 1,
                // NGFW-12881 - disable clickable anchor style for threat prevention reputation
                tdCls: entry.get('pieGroupColumn') !== 'threat_prevention_reputation' ? 'anchor' : '',
                field: entry.get('pieGroupColumn'),
                table: entry.get('table'),
                renderer: Renderer[entry.get('pieGroupColumn')] || TableConfig.getDisplayValue
            }, {
                dataIndex: 'value',
                header: 'value'.t(),
                width: 200,
                renderer: function (value) {
                    if (entry.get('units') === 'bytes' || entry.get('units') === 'bytes/s') {
                        return Util.bytesToHumanReadable(value, true);
                    } else {
                        return value;
                    }
                }
            }]);
            me.getView().getStore().loadData(data);
        },

        /**
         * exports graph data
         */
        exportGraphData: function (btn) {
            var me = this, vm = me.getViewModel(), entry = vm.get('entry').getData(), columns = [], headers = [], j;
            if (!entry) { return; }

            var grid = btn.up('grid'), csv = [];

            if (!grid) {
                console.log('Grid not found');
                return;
            }

            var processRow = function (row) {
                var data = [], j, innerValue;
                for (j = 0; j < row.length; j += 1) {
                    innerValue = !row[j] ? '' : row[j].toString();
                    data.push('"' + innerValue.replace(/"/g, '""') + '"');
                }
                return data.join(',') + '\r\n';
            };

            Ext.Array.each(grid.getColumns(), function (col) {
                if (col.dataIndex && !col.hidden) {
                    columns.push(col.dataIndex);
                    headers.push(col.text);
                }
            });
            csv.push(processRow(headers));

            grid.getStore().each(function (row) {
                var r = [];
                for (j = 0; j < columns.length; j += 1) {
                    if (columns[j] === 'time_trunc') {
                        r.push(Renderer.timestamp(row.get('time_trunc')));
                    } else {
                        r.push(row.get(columns[j]));
                    }
                }
                csv.push(processRow(r));
            });

            me.download(csv.join(''), (entry.category + '-' + entry.title + '-' + Ext.Date.format(new Date(), 'd.m.Y-Hi')).replace(/ /g, '_') + '.csv', 'text/csv');
        },

        download: function(content, fileName, mimeType) {
            var a = document.createElement('a');
            mimeType = mimeType || 'application/octet-stream';

            if (navigator.msSaveBlob) { // IE10
                return navigator.msSaveBlob(new Blob([ content ], {
                    type : mimeType
                }), fileName);
            } else if ('download' in a) { // html5 A[download]
                a.href = 'data:' + mimeType + ',' + encodeURIComponent(content);
                a.setAttribute('download', fileName);
                document.body.appendChild(a);
                setTimeout(function() {
                    a.click();
                    document.body.removeChild(a);
                }, 100);
                return true;
            } else { //do iframe dataURL download (old ch+FF):
                var f = document.createElement('iframe');
                document.body.appendChild(f);
                f.src = 'data:' + mimeType + ',' + encodeURIComponent(content);
                setTimeout(function() {
                    document.body.removeChild(f);
                }, 400);
                return true;
            }

        },
        /**
         * used for applying/replace new global condition
         */
        onCellClick: function (cell, td, cellIndex, record, tr, rowIndex) {
            var me = this, entry = me.getViewModel().get('entry'), grid = me.getView(), column, value;

            // works only for PIE_GRAPH Data View
            if (entry.get('type') !== 'PIE_GRAPH') {
                return;
            }

            if (cellIndex === 0) {
                /**
                 * for Threat Prevention reputation pie charts disable click
                 * because the point value cannot represent a range of values
                 * NGFW-12881
                 */                
                if (entry.get('pieGroupColumn') === 'threat_prevention_reputation') {
                    return;
                }

                // fire event to add global condition, implemented in GlobalConditions.js controller section
                Ext.fireEvent('addglobalcondition', entry.get('table'), entry.get('pieGroupColumn'), record.get(entry.get('pieGroupColumn')));
            }
        }

    }

});
Ext.define('Ung.reports.Theme', {
    alternateClassName: 'Theme',
    singleton: true,

    DEFAULT: {
        colors: ['#00b000', '#3030ff', '#009090', '#00ffff', '#707070', '#b000b0', '#fff000', '#b00000', '#ff0000', '#ff6347', '#c0c0c0'],
        chart: {
            backgroundColor: '#FFFFFF'
        },
        xAxis: {
            lineColor: '#C0D0E0',
            tickColor: '#C0D0E0',
            labels: {
                style: {
                    color: '#777'
                }
            },
            crosshair: {
                color: 'rgba(192, 208, 224, 0.5)'
            }
        },
        yAxis: {
            lineColor: '#C0D0E0',
            tickColor: '#C0D0E0',
            gridLineColor: '#EEE',
            labels: {
                style: {
                    color: '#777'
                }
            },
            title: {
                style: {
                    color: '#777'
                }
            }
        },
        plotOptions: {
            series: {
                tooltip: {
                    headerFormat: '<span style="font-size: 14px; color: #333;">{point.key}</span><br/>'
                },
                dataLabels: {
                    color: '#555555'
                }
            },
            pie: {
                borderColor: '#FFF',
                edgeColor: '#FFF'
            },
            column: {
                borderColor: '#EEE'
            }
        },
        tooltip: {
            backgroundColor: 'rgba(247, 247, 247, 0.95)',
            style: {
                color: '#333'
            }
        },
        legend: {
            title: {
                style: {
                    color: '#000'
                }
            },
            itemStyle: {
                color: '#333'
            },
            itemHoverStyle: {
                color: '#000'
            }
        },
        loading: {
            labelStyle: {
                color: '#777'
            },
            style: {
                backgroundColor: 'rgba(255, 255, 255, 0.3)'
            }
        }
    },

    DARK: {
        colors: ['#2b908f', '#90ee7e', '#f45b5b', '#7798BF', '#aaeeee', '#ff0066', '#eeaaee', '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
        chart: {
            backgroundColor: {
                linearGradient: { x1: 0, y1: 1, x2: 0, y2: 1 },
                stops: [
                   [0, '#2a2a2b'],
                   [1, '#3e3e40']
                ]
            }
        },
        xAxis: {
            lineColor: '#707073',
            tickColor: '#707073',
            labels: {
                style: {
                    color: '#CCC'
                }
            },
            crosshair: {
                color: 'rgba(112, 112, 115, 0.5)'
            }
        },
        yAxis: {
            lineColor: '#707073',
            tickColor: '#707073',
            gridLineColor: '#444',
            labels: {
                style: {
                    color: '#CCC'
                }
            },
            title: {
                style: {
                    color: '#CCC'
                }
            }
        },
        plotOptions: {
            series: {
                tooltip: {
                    headerFormat: '<span style="font-size: 14px; color: #FFF;">{point.key}</span><br/>'
                },
                dataLabels: {
                    color: '#B0B0B3'
                }
            },
            pie: {
                borderColor: '#333',
                edgeColor: '#333',
            },
            column: {
                borderColor: '#333'
            }
        },
        tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.85)',
            style: {
                color: '#FFF'
            }
        },
        legend: {
            title: {
                style: {
                    color: '#FFFFFF'
                }
            },
            itemStyle: {
                color: '#DDD'
            },
            itemHoverStyle: {
                color: '#FFF'
            }
        },
        loading: {
            labelStyle: {
                color: '#999'
            },
            style: {
                backgroundColor: 'rgba(0, 0, 0, 0.3)'
            }
        }
    },

    SAND: {
        colors: ['#f45b5b', '#8085e9', '#8d4654', '#7798BF', '#aaeeee', '#ff0066', '#eeaaee', '#55BF3B', '#DF5353', '#7798BF', '#aaeeee'],
        chart: {
            backgroundColor: null
        },
        xAxis: {
            lineColor: '#C0D0E0',
            tickColor: '#C0D0E0',
            labels: {
                style: {
                    color: '#777'
                }
            },
            crosshair: {
                color: 'rgba(192, 208, 224, 0.5)'
            }
        },
        yAxis: {
            lineColor: '#C0D0E0',
            tickColor: '#C0D0E0',
            gridLineColor: '#DDD',
            labels: {
                style: {
                    color: '#777'
                }
            },
            title: {
                style: {
                    color: '#777'
                }
            }
        },
        plotOptions: {
            series: {
                tooltip: {
                    headerFormat: '<span style="font-size: 14px; color: #555;">{point.key}</span><br/>'
                },
                dataLabels: {
                    color: '#555'
                }
            },
            pie: {
                borderColor: '#FFF',
                edgeColor: '#FFF',
            },
            column: {
                borderColor: '#EEE'
            }
        },
        tooltip: {
            backgroundColor: 'rgba(247, 247, 247, 0.95)',
            style: {
                color: '#333'
            }
        },
        legend: {
            title: {
                style: {
                    color: '#333'
                }
            },
            itemStyle: {
                color: '#333'
            },
            itemHoverStyle: {
                color: '#000'
            }
        },
        loading: {
            labelStyle: {
                color: '#777'
            },
            style: {
                backgroundColor: 'rgba(255, 255, 255, 0.3)'
            }
        }
    }
});
/**
 * Reports Timerange Conditions used in Reports
  */
Ext.define('Ung.reports.cmp.TimeConditions', {
    extend: 'Ext.container.Container',
    alias: 'widget.timeconditions',

    publishes: 'range',
    margin: '0 5',

    layout: {
        type: 'hbox',
        align: 'middle'
    },

    config: {
        range: null,
        since: null, // initial since today
        until: null
    },

    ranges: [
        { text: '1 Hour ago'.t(), value: { since: Ext.Date.subtract(Util.serverToClientDate(new Date()), Ext.Date.HOUR, 1), until: null } },
        { text: '6 Hours ago', value: { since: Ext.Date.subtract(Util.serverToClientDate(new Date()), Ext.Date.HOUR, 6), until: null } },
        // { text: '12 Hours ago', value: { since: Ext.Date.subtract(new Date(), Ext.Date.HOUR, 12), until: null } },
        { text: 'Today', value: { since: Ext.Date.clearTime(Util.serverToClientDate(new Date())), until: null } },
        // { text: '24 Hours ago', value: { since: Ext.Date.subtract(new Date(), Ext.Date.HOUR, 24), until: null } },
        { text: 'Yesterday', value: { since: Ext.Date.subtract(Ext.Date.clearTime(Util.serverToClientDate(new Date())), Ext.Date.DAY, 1), until: null } },
        { text: 'This Week', value: { since: Ext.Date.subtract(Ext.Date.clearTime(Util.serverToClientDate(new Date())), Ext.Date.DAY, (Util.serverToClientDate(new Date())).getDay()), until: null } },
        { text: 'Last Week', value: { since: Ext.Date.subtract(Ext.Date.clearTime(Util.serverToClientDate(new Date())), Ext.Date.DAY, (Util.serverToClientDate(new Date())).getDay() + 7), until: null } },
        { text: 'This Month', value: { since: Ext.Date.getFirstDateOfMonth(Util.serverToClientDate(new Date())), until: null } }
    ],

    rangeHistory: [],

    controller: {
        listen: {
            global: {
                timerangechange: 'onTimeRangeChange'
            }
        },
        // applies timerange from zoomed in time reports
        onTimeRangeChange: function (range) {
            if (!range) { return; }
            var me = this,
                start = Util.serverToClientDate(new Date(range.min)),
                end = Util.serverToClientDate(new Date(range.max));

            // round dates to 10 minutes itervals
            start.setMinutes(Math.floor(start.getMinutes()/10) * 10, 0, 0);
            end.setMinutes(Math.ceil(end.getMinutes()/10) * 10, 0, 0);

            me.getView().setRange({
                since: start,
                until: end
            }, true);
        }
    },

    items: [{
        xtype: 'component',
        margin: '0 5 0 0',
        style: {
            fontSize: '11px'
        },
        html: '<strong>' + 'Since:'.t() + '</strong>'
    }, {
        xtype: 'button',
        // iconCls: 'fa fa-calendar',
        iconCls: 'fa fa-clock-o',
        text: 'Today'.t(),
        focusable: false,
        menu: {
            plain: true,
            showSeparator: false,
            mouseLeaveDelay: 0,
            listeners: {
                click: function (menu, item) {
                    if (item.type === 'range') {
                        menu.up('timeconditions').setCustomRange();
                        return;
                    }
                    if (item.type === 'rangehistory') {
                        return;
                    }
                    menu.up('timeconditions').setRange(item.value);
                }
            }
        }
    }],

    /** Updates the since/until dates and publishes into viewmodel */
    setRange: function (val, addToHistory) {
        var me = this, btnText;
        this.range = val;

        var existingRange = Ext.Array.findBy(me.ranges, function (r) {
            return Ext.Date.isEqual(r.value.since, me.getRange().since);
        });

        if (existingRange && !this.range.until) {
            btnText = existingRange.text;
        } else {
            var timestampFormat = Rpc.directData('rpc.translations.timestamp_fmt');
            btnText = Ext.Date.format(this.range.since, timestampFormat);
            if (this.range.until) {
                btnText += ' \u0020\u2794\u0020 ' + Ext.Date.format(this.range.until, timestampFormat);
            }
            if (addToHistory) {
                if (me.rangeHistory.length >= 5) {
                    Ext.Array.removeAt(me.rangeHistory, me.rangeHistory.length - 1);
                }
                me.rangeHistory.unshift({
                    text: btnText,
                    inHistory: true,
                    value: Ext.clone(val)
                });
            }
            me.setRangeHistory();
        }

        this.down('component').setHtml('<strong>' + (this.range.until ? 'Time Range'.t() : 'Since'.t()) + ':</strong>');
        this.down('button').setText(btnText);
        this.publishState();
    },

    /** Sets the menu item default ranges */
    setRangeHistory: function () {
        var me = this, menu = this.down('button').getMenu(), rangeMenuItems = [];

        if (menu.down('#historyItem')) {
            menu.remove(menu.down('#historyItem'));
        }
        if (this.rangeHistory.length > 0) {
            rangeMenuItems = Ext.clone(this.rangeHistory);
            rangeMenuItems.push({
                xtype: 'menuseparator'
            }, {
                text: 'Clear History'.t(),
                iconCls: 'fa fa-eraser'
            });
            menu.add({
                text: 'Time Range History'.t(),
                itemId: 'historyItem',
                iconCls: 'fa fa-history',
                type: 'rangehistory',
                menu: {
                    plain: true,
                    showSeparator: false,
                    mouseLeaveDelay: 0,
                    items: rangeMenuItems,
                    listeners: {
                        click: function (menu, item) {
                            if (item.value) {
                                me.setRange(item.value, false);
                            } else {
                                me.rangeHistory = [];
                                me.setRangeHistory();
                            }
                        }
                    }
                }
            });
        }
    },


    afterRender: function () {
        var menu = this.down('button').getMenu();
        this.callParent(arguments);
        this.setRange({
            since: Ext.Date.clearTime(Util.serverToClientDate(new Date())),
            until: null
        }); // initially loads today data

        menu.add(this.ranges);
        menu.add({
            xtype: 'menuseparator'
        }, {
            text: 'Time Range...',
            iconCls: 'fa fa-calendar',
            type: 'range'
        });
    },

    /**
     * shows a dialog to setup some specific date/time range
     */
    setCustomRange: function () {
        var me = this, range = this.getRange(), d = Util.serverToClientDate(new Date()),
            since, until;

        d.setMinutes(Math.floor(d.getMinutes()/10) * 10, 0, 0); // round new date to 10 mminutes interval

        since = Ext.Date.clone(range.since);
        until = range.until ? Ext.Date.clone(range.until) : d; // until needs to be a date in this range picker

        if (me.dialog) {
            me.dialog.down('#startDate').setValue(since);
            me.dialog.down('#startTime').setValue(since);
            me.dialog.down('#endDate').setValue(until);
            me.dialog.down('#endTime').setValue(until);
            me.dialog.showBy(me.down('button'), 'tl-bl?');
            return;
        }

        me.dialog = me.add({
            xtype: 'window',
            renderTo: Ext.getBody(),
            modal: true,
            draggable: false,
            resizable: false,
            closable: false,
            header: {
                title: 'Select Date/Time range'.t(),
                iconCls: 'fa fa-calendar'
            },
            layout: {
                type: 'hbox',
                align: 'end'
            },
            frame: false,
            border: false,
            bodyBorder: false,
            defaults: {
                bodyStyle: {
                    background: 'transparent'
                },
                border: false,
            },
            items: [{
                xtype: 'panel',
                margin: '0 2 0 0',
                layout: { type: 'vbox', align: 'stretch', pack: 'end' },
                dockedItems: [{
                    xtype: 'toolbar',
                    docked: 'top',
                    height: 24,
                    style: { background: 'transparent' },
                    border: false,
                    items: [{
                        xtype: 'component',
                        html: '<strong>' + 'Since'.t() + '</strong>'
                    }]
                }],
                items: [{
                    xtype: 'datepicker-conditions',
                    itemId: 'startDate',
                    value: since,
                    showToday: false,
                    maxDate: Util.serverToClientDate(new Date(Util.getMilliseconds())),
                    listeners: {
                        select: function (el, date) {
                            since.setFullYear(date.getFullYear(), date.getMonth(), date.getDate());
                        }
                    }
                }, {
                    xtype: 'timefield',
                    itemId: 'startTime',
                    value: since,
                    width: 100,
                    margin: '5 5 0 5',
                    increment: 10,
                    editable: false,
                    fieldLabel: 'Start Time'.t(),
                    labelWidth: 'auto',
                    labelAlign: 'right',
                    format: 'h:i A',
                    listeners: {
                        change: function (el, date) {
                            since.setHours(date.getHours(), date.getMinutes(), 0, 0);
                            // me.setValue();
                        }
                    }
                }]
            }, {
                xtype: 'panel',
                margin: '0 0 0 2',
                // border: false,
                // bodyBorder: false,
                layout: { type: 'vbox', align: 'stretch', pack: 'end' },
                dockedItems: [{
                    xtype: 'toolbar',
                    docked: 'top',
                    border: false,
                    height: 24,
                    style: { background: 'transparent' },
                    items: [{
                        xtype: 'component',
                        html: '<strong>' + 'Until'.t() + '</strong>'
                    }, '->', {
                        xtype: 'checkbox',
                        itemId: 'untilNow',
                        boxLabel: 'Now'.t(),
                        value: !me.getUntil(),
                        listeners: {
                            change: function (el, val) {
                                var ed = el.up('panel').down('datepicker'),
                                    et = el.up('panel').down('timefield');
                                ed.setDisabled(val);
                                et.setDisabled(val);
                            }
                        }
                    }]
                }],

                items: [{
                    xtype: 'datepicker-conditions',
                    itemId: 'endDate',
                    value: until,
                    showToday: false,
                    maxDate: Util.serverToClientDate(new Date(Util.getMilliseconds())),
                    disabled: !me.getUntil(),
                    listeners: {
                        select: function (el, date) {
                            until.setFullYear(date.getFullYear(), date.getMonth(), date.getDate());
                        }
                    }
                }, {
                    xtype: 'timefield',
                    itemId: 'endTime',
                    disabled: !me.getUntil(),
                    value: until,
                    width: 100,
                    margin: '5 5 0 0',
                    increment: 10,
                    editable: false,
                    fieldLabel: 'End Time'.t(),
                    labelWidth: 'auto',
                    labelAlign: 'right',
                    format: 'h:i A',
                    listeners: {
                        change: function (el, date) {
                            until.setHours(date.getHours(), date.getMinutes(), 0, 0);
                        }
                    }
                }]
            }],
            buttons: [{
                text: 'Cancel'.t(),
                iconCls: 'fa fa-ban',
                handler: function (el) {
                    el.up('window').hide();
                }
            }, {
                text: 'Apply'.t(),
                iconCls: 'fa fa-check',
                handler: function () {
                    var toHistory = !me.dialog.down('#untilNow').getValue();
                    me.setRange({
                        since: since,
                        until: toHistory ? until : null
                    }, toHistory);
                    me.dialog.hide();
                }
            }]
        });

        me.dialog.showBy(me.down('button'), 'tl-bl?');
    }
});
Ext.define ('Ung.model.Category', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'categoryName', type: 'string' },
        { name: 'displayName', type: 'string' },
        { name: 'icon', type: 'string' },
        {
            name: 'slug',
            calculate: function (cat) {
                return cat.categoryName.replace(/ /g, '-').toLowerCase();
            }
        },
    ],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});
Ext.define ('Ung.model.Report', {
    extend: 'Ext.data.Model' ,
    fields: [
        { name: 'approximation', type: 'string', defaultValue: '' },
        { name: 'category', type: 'string', defaultValue: '' },
        { name: 'colors', type: 'auto', defaultValue: null },
        { name: 'conditions', type: 'auto', defaultValue: null },
        { name: 'defaultColumns' }, //???
        { name: 'description', type: 'string', defaultValue: '' },
        { name: 'displayOrder', type: 'int' },
        { name: 'enabled', type: 'boolean', defaultValue: true },
        { name: 'javaClass', type: 'string', defaultValue: 'com.untangle.app.reports.ReportEntry' },
        { name: 'orderByColumn', type: 'string', defaultValue: null },
        { name: 'orderDesc', type: 'boolean', defaultValue: false },
        { name: 'pieGroupColumn', type: 'string', defaultValue: null },
        { name: 'pieNumSlices', type: 'int', defaultValue: 10 },
        { name: 'pieStyle' },
        { name: 'pieSumColumn', type: 'string', defaultValue: null },
        { name: 'readOnly', type: 'boolean', defaultValue: false },
        { name: 'seriesRenderer', type: 'string', defaultValue: '' },
        { name: 'table', type: 'string', defaultValue: null },
        { name: 'textColumns', type: 'auto', defaultValue: null },
        { name: 'textString', type: 'string', defaultValue: '' },
        { name: 'timeDataColumns', type: 'auto', defaultValue: null },
        { name: 'timeDataDynamicAggregationFunction', type: 'string', defaultValue: '' },
        { name: 'timeDataDynamicAllowNull', type: 'boolean', defaultValue: false },
        { name: 'timeDataDynamicColumn', type: 'string', defaultValue: '' },
        { name: 'timeDataDynamicLimit', type: 'int', defaultValue: 0 },
        { name: 'timeDataDynamicValue', type: 'string', defaultValue: '' },
        { name: 'timeDataInterval' },
        { name: 'timeStyle' },
        { name: 'title', type: 'string', defaultValue: '' },
        { name: 'type', type: 'string', defaultValue: 'TEXT' }, // TEXT, PIE_GRAPH, TIME_GRAPH, TIME_GRAPH_DYNAMIC, EVENT_LIST
        { name: 'uniqueId', type: 'string', defaultValue: null },
        { name: 'units', type: 'string', defaultValue: null },

        // computed fields
        {
            name: 'localizedTitle',
            calculate: function (entry) {
                return entry.readOnly ? entry.title.t() : entry.title;
            }
        },
        {
            name: 'localizedDescription',
            calculate: function (entry) {
                return entry.readOnly ? entry.description.t() : entry.description;
            }
        },
        {
            name: 'slug',
            calculate: function (entry) {
                var slug = '';
                if (entry.title) {
                    slug = Util.urlEncode(entry.title);
                }
                return slug;
            }
        },
        {
            name: 'categorySlug',
            calculate: function (entry) {
                return Util.urlEncode(entry.category);
            }
        },
        {
            name: 'url',
            calculate: function (entry) {
                return 'cat=' + entry.categorySlug + '&rep=' + entry.slug;
            }
        },
        {
            name: 'icon',
            calculate: function (entry) {
                var icon;
                switch (entry.type) {
                case 'TEXT':
                    icon = 'fa-align-left';
                    break;
                case 'EVENT_LIST':
                    icon = 'fa-list-ul';
                    break;
                case 'PIE_GRAPH':
                    icon = 'fa-pie-chart';
                    if (entry.pieStyle === 'COLUMN' || entry.pieStyle === 'COLUMN_3D') {
                        icon = 'fa-bar-chart';
                    } else {
                        if (entry.pieStyle === 'DONUT' || entry.pieStyle === 'DONUT_3D') {
                            icon = 'fa-pie-chart';
                        }
                    }
                    break;
                case 'TIME_GRAPH':
                case 'TIME_GRAPH_DYNAMIC':
                    icon = 'fa-line-chart';
                    if (!entry.timeStyle) { return icon; }
                    if (entry.timeStyle.indexOf('BAR') >= 0) {
                        icon = 'fa-bar-chart';
                    } else {
                        if (entry.timeStyle.indexOf('AREA') >= 0) {
                            icon = 'fa-area-chart';
                        }
                    }
                    break;
                default:
                    icon = 'fa-align-left';
                }
                return icon;
            }
        }
    ],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
            //rootProperty: 'list'
        }
    }
});
Ext.define ('Ung.model.ReportCondition', {
    extend: 'Ext.data.Model' ,
    fields: [{
        name: 'column',
        type: 'string'
    },{
        name: 'operator',
        type: 'string'
    },{
        name: 'value',
        type: 'string'
    },{
        name: 'autoFormatValue',
        type: 'boolean'
    },{
        name: 'table',
        type: 'string'
    },{
        name: 'javaClass',
        type: 'string',
        defaultValue: 'com.untangle.app.reports.SqlCondition'
    }],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    },

    getQuery: function(){
        return encodeURIComponent(this.get('column')) + ':' + encodeURIComponent(this.get('operator')) +  ':' + (this.get('autoFormatValue') === true ? 1 : 0) + ':' + encodeURIComponent(this.get('table'))  + ':' + encodeURIComponent(this.get('value'));
    },

    statics:{
        collect: function(conditions){
            return conditions ? Ext.Array.map(conditions, function(condition){
                return condition.getData();
            }) : null;
        },
        getAllQueries: function(conditions, prefix){
            return conditions ? ( conditions.length ? ( prefix !== undefined? prefix : '&') + Ext.Array.map(conditions, function(condition){
                                return condition.getQuery();
                                }).join("&") : '' ) : '';
        }
    }
});
Ext.define('Ung.store.Categories', {
    extend: 'Ext.data.Store',
    storeId: 'categories',

    fields: [{
        name: 'displayName', type: 'string'
    }, {
        name: 'name', type: 'string'
    }, {
        name: 'type', type: 'string', defaultValue: 'app'
    }, {
        name: 'icon', type: 'string',
        calculate: function (cat) {
            if (cat.type === 'system') {
                return '/icons/config/' + cat.name + '.svg';
            }
            return '/icons/apps/' + cat.name + '.svg';
        }
    }, {
        name: 'slug', type: 'string',
        calculate: function (cat) { return cat.name; }
    }],
    proxy: {
        type: 'memory',
        reader: {
            type: 'json'
        }
    }
});
Ext.define('Ung.store.Reports', {
    extend: 'Ext.data.Store',
    alias: 'store.reports',
    storeId: 'reports',
    model: 'Ung.model.Report',
    groupField: 'category',
    sorters: [{
        property: 'displayOrder',
        direction: 'ASC'
    }]
});
Ext.define('Ung.store.ReportsTree', {
    extend: 'Ext.data.TreeStore',
    alias: 'store.reportstree',
    storeId: 'reportstree',
    filterer: 'bottomup',
    sorters: [{
        property: 'viewPosition',
        direction: 'ASC'
    }],

    // initialize the root which will be overriden later
    root: {
        text: 'All Reports'.t(),
        expanded: true,
        children: [{
            text: 'Loading...'.t(),
            icon: 'fa-spinner fa-spin',
            leaf: true
        }]
    },

    build: function () {
        var me = this, nodes = [], storeCat, category;
        Ext.Array.each(Ext.getStore('reports').getGroups().items, function (group) {
            storeCat = Ext.getStore('categories').findRecord('displayName', group._groupKey, 0, false, true, true);

            if (!storeCat) { return; }

            // create category node
            category = {
                text: group._groupKey,
                slug: storeCat.get('slug'),
                type: storeCat.get('type'), // app or system
                icon: storeCat.get('icon'),
                cls: 'x-tree-category',
                url: 'cat=' + storeCat.get('slug'),
                children: [],
                viewPosition: storeCat.get('viewPosition'),
                disabled: false
                // expanded: group._groupKey === vm.get('category.categoryName')
            };
            // add reports to each category
            Ext.Array.each(group.items, function (entry) {
                if(entry.removedFrom){
                    return;
                }

                category.children.push({
                    text: entry.get('localizedTitle'),
                    cat: storeCat.get('slug'),
                    slug: entry.get('slug'),
                    url: entry.get('url'),
                    uniqueId: entry.get('uniqueId'),
                    type: entry.get('type'),
                    readOnly: entry.get('readOnly'),
                    iconCls: 'fa ' + entry.get('icon'),
                    cls: 'x-tree-report',
                    table: entry.get('table'),
                    disabled: false,
                    leaf: true
                    // selected: uniqueId === vm.get('entry.uniqueId')
                });
            });
            nodes.push(category);
        });

        me.setRoot({
            text: 'All reports'.t(),
            slug: '/reports/',
            expanded: true,
            disabled: false, // !important
            children: nodes
        });
    }

});
Ext.define('Ung.view.reports.Entry', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.entry',

    controller: 'entry',
    viewModel: {
        type: 'entry'
    },

    requires: ['Ext.ux.exporter.Exporter'],

    layout: 'fit',

    items: [{
        /**
         * using a formpanel to help validate when editing entry settings
         */
        xtype: 'form',
        layout: 'border',
        border: false,
        bodyBorder: false,
        dockedItems: [{
            /**
             * top toolbar containing report entry available actions
             */
            xtype: 'toolbar',
            dock: 'top',
            border: false,
            cls: 'report-header',
            padding: '5 10',
            style: { background: '#FFF' },
            ui: 'footer',
            defaults: {
                focusable: false
            },
            items: [{
                xtype: 'component',
                hidden: true,
                bind: {
                    html: '<h2><span>{entry.category} /</span> {entry.title}</h2><p>{entry.description}</p>',
                    hidden: '{eEntry}'
                }
            }, {
                xtype: 'component',
                hidden: true,
                bind: {
                    html: '<h2><span>{eEntry.category || "category"} /</span> {eEntry.title || "title"}</h2><p>{eEntry.description}</p>',
                    hidden: '{!eEntry}'
                }
            }, {
                xtype: 'component',
                html: '<i class="fa fa-spinner fa-spin fa-fw fa-lg"></i>',
                hidden: true,
                bind: {
                    hidden: '{!fetching}'
                }
            }, '->', {
                text: 'Refresh'.t(),
                iconCls: 'fa fa-refresh',
                itemId: 'refreshBtn',
                handler: 'refresh',
                disabled: true,
                bind: {
                    disabled: '{r_autoRefreshBtn.pressed || fetching}'
                }
            }, {
                xtype: 'container',
                layout: 'hbox',
                defaults: {
                    xtype: 'button',
                    margin: '0 2'
                },
                plugins: 'responsive',
                responsiveConfig: {
                    'width >= 800': { hidden: false },
                    'width < 800': { hidden: true }
                },
                items: [{
                    text: 'Auto'.t() + ' (5 sec)',
                    reference: 'r_autoRefreshBtn',
                    enableToggle: true,
                    publishes: 'pressed',
                    bind: {
                        iconCls: '{r_autoRefreshBtn.pressed ? "fa fa-check-square-o" : "fa fa-square-o"}',
                    }
                    // handler: 'setAutoRefresh'
                }, {
                    xtype: 'tbseparator'
                }, {
                    // xtype: 'checkbox',
                    text: 'Data View'.t(),
                    reference: 'dataCk',
                    enableToggle: true,
                    hidden: true,
                    disabled: true,
                    bind: {
                        iconCls: '{dataCk.pressed ? "fa fa-check-square-o" : "fa fa-square-o"}',
                        hidden: '{!entry || entry.type === "EVENT_LIST" || eEntry}',
                        disabled: '{fetching}'
                    }
                }, {
                    // todo:add resetView
                    text: 'Reset View'.t(),
                    iconCls: 'fa fa-refresh',
                    itemId: 'resetBtn',
                    handler: 'resetView',
                    hidden: true,
                    disabled: true,
                    bind: {
                        // hidden: '{!entry || entry.type !== "EVENT_LIST" || eEntry}',
                        // disabled: '{fetching}'
                    }
                }, {
                    xtype: 'combo',
                    itemId: 'eventsLimitSelector',
                    hidden: true,
                    disabled: true,
                    bind: {
                        hidden: '{entry.type !== "EVENT_LIST"}',
                        disabled: '{fetching}'
                    },
                    editable: false,
                    value: 1000,
                    store: [
                        [100, '100 ' + 'Events'.t()],
                        [500, '500 ' + 'Events'.t()],
                        [1000, '1000 ' + 'Events'.t()],
                        [5000, '5000 ' + 'Events'.t()],
                        [10000, '10000 ' + 'Events'.t()],
                        [50000, '50000 ' + 'Events'.t()],
                    ],
                    queryMode: 'local',
                    listeners: {
                        change: 'refresh'
                    }
                }, {
                    itemId: 'dashboardBtn',
                    hidden: true,
                    disabled: true,
                    bind: {
                        iconCls: 'fa {widget ? "fa-minus-circle" : "fa-plus-circle" }',
                        text: '{widget ? "Remove from " : "Add to "}' + ' Dashboard',
                        hidden: '{context !== "ADMIN" || eEntry}',
                        disabled: '{fetching}'
                    },
                    handler: 'dashboardAddRemove'
                }, {
                    xtype: 'button',
                    text: 'Export Data (csv)'.t(),
                    itemId: 'exportData',
                    iconCls: 'fa fa-external-link-square',
                    menu: {
                        plain: true,
                        showSeparator: false,
                        items: [{
                            itemId: 'exportDatabase',
                            text: 'Export All Events'.t(),
                            handler: 'exportEventsHandler',
                            hidden: false,
                            disabled: false,
                        }, {
                            text: 'Export Displayed Events'.t(),
                            itemId: 'exportCsv',
                            hidden: false,
                            disabled: false,
                            component: this,
                            store: this,
                            format: 'csv',
                            remote: false,
                            title: 'export',
                            onClick: function(e) {
                                var me = this,
                                   blobURL = "",
                                   format = me.format,
                                   remote = me.remote,
                                   title = me.title,
                                   dt = new Date(),
                                   link = me.el.dom.children[0],
                                   res, filename;

                                res = Ext.ux.exporter.Exporter.exportAny(me.component, me.store, format, { title : title });
                                filename = title + "_" + Ext.Date.format(dt, "Y-m-d h:i:s") + "." + res.ext;
                                Ext.ux.exporter.FileSaver.saveAs(res.data, res.mimeType, res.charset, filename, link, remote, me.onComplete, me);
                            },
                            onComplete: function() {
                                this.fireEvent('complete', this);
                                this.blur();
                            }
                        }],
                    },
                    hidden: false,
                    disabled: false,
                    bind: {
                        hidden: '{entry.type !== "EVENT_LIST" || eEntry}',
                        disabled: '{fetching}'
                    }
                }, {
                    text: 'Settings'.t(),
                    reference: 'settingsBtn',
                    // enableToggle: true,
                    iconCls: 'fa fa-cog',
                    hidden: true,
                    disabled: true,
                    bind: {
                        hidden: '{!entry || eEntry || context !== "ADMIN"}',
                        disabled: '{fetching}'
                    },
                    handler: 'editEntry'
                }]
            }]
        }, {
            xtype: 'toolbar',
            dock: 'top',
            border: false,
            hidden: true,
            bind: {
                hidden: '{!entry || entry.type !== "EVENT_LIST"}'
            },
            items: [{
                xtype: 'ungridfilter'
            }]
        }],
        items: [{
            /**
             * cards region containing the actual report (text, graph, events, invalid report message)
             */
            region: 'center',
            border: false,
            itemId: 'reportCard',
            layout: 'card',
            items: [{
                xtype: 'graphreport',
                itemId: 'graphreport',
                renderInReports: true
            }, {
                xtype: 'eventreport',
                itemId: 'eventreport',
                renderInReports: true
            }, {
                xtype: 'textreport',
                itemId: 'textreport',
                renderInReports: true
            }, {
                // itemId: 'invalidreport',
                xtype: 'component',
                cls: 'invalidreport',
                // border: false,
                // layout: 'center',
                // items: [{
                //     xtype: 'component',
                html: '<i class="fa fa-exclamation-triangle fa-2x fa-orange"></i><p>Fill all the required settings then click "Preview/Refresh"!</p>',
                bind: {
                    userCls: '{!validForm ? "invalid" : ""}'
                }
                // }]
            }],

            dockedItems: [{
                /**
                 * Notification for readonly or custom report
                 */
                xtype: 'component',
                dock: 'top',
                padding: '10',
                hidden: true,
                style: {
                    background: '#F9FFA8'
                },
                bind: {
                    hidden: '{!eEntry.readOnly}'
                },
                html: '<i class="fa fa-info-circle fa-lg"></i> ' + 'This is a default <strong>read-only</strong> report. Any changes can be saved as a New Report with a different title.'
            }]
        }, {
            /**
             * east border ragion with entry editing fields
             */
            region: 'east',
            title: '<i class="fa fa-cog"></i> ' + 'Settings'.t(),
            width: 400,
            minWidth: 390,
            weight: 20,
            split: true,
            scrollable: true,
            hidden: true,
            bind: {
                hidden: '{!eEntry}'
            },
            border: false,
            bodyBorder: false,
            bodyPadding: 10,
            defaults: {
                labelAlign: 'right',
                anchor: '100%',
                labelWidth: 120,
                // labelStyle: 'font-weight: bold;'
            },
            layout: 'anchor',
            bbar: [{
                text: 'Preview/Refresh'.t(),
                iconCls: 'fa fa-refresh',
                handler: 'resetAndReload',
                formBind: true
            }, '->', {
                text: 'Export Settings'.t(),
                iconCls: 'fa fa-external-link-square',
                handler: 'exportSettings',
                formBind: true
            }],
            items: [{
                xtype: 'textfield',
                itemId: 'report_title',
                fieldLabel: '<strong>' + 'Title'.t() + '</strong>',
                anchor: '100%',
                hidden: true,
                bind: {
                    value: '{eEntry.title}',
                    hidden: '{!eEntry}'
                },
                valuePublishEvent: 'blur', // update binding on blur only
                allowBlank: false,
                emptyText: 'Enter Report Title ...'.t()
            }, {
                xtype: 'combo',
                itemId: 'categoryCombo',
                editable: false,
                fieldLabel: '<strong>' + 'Category'.t() + '</strong>',
                anchor: '100%',
                displayField: 'displayName',
                tpl: '<ul class="x-list-plain"><tpl for=".">' +
                        '<li role="option" class="x-boundlist-item"><img src="{icon}" style="width: 16px; height: 16px; vertical-align: middle;"> {displayName}</li>' +
                        '</tpl></ul>',
                store: 'categories',
                queryMode: 'local',
                allowBlank: false,
                emptyText: 'Select a Category ...'.t(),
                hidden: true,
                bind: {
                    value: '{eEntry.category}',
                    hidden: '{!eEntry}'
                }
            }, {
                xtype: 'textarea',
                grow: true,
                fieldLabel: '<strong>' + 'Description'.t() + '</strong>',
                anchor: '100%',
                hidden: true,
                // allowBlank: false,
                emptyText: 'Add a description ...'.t(),
                valuePublishEvent: 'blur',
                bind: {
                    value: '{eEntry.description}',
                    hidden: '{!eEntry}'
                }
            }, {
                xtype: 'combo',
                fieldLabel: '<strong>' + 'Report Type'.t() + '</strong>',
                anchor: '100%',
                publishes: 'value',
                editable: false,
                queryMode: 'local',
                displayField: 'name',
                valueField: 'value',
                allowBlank: false,
                emptyText: 'Select Report Type ...'.t(),
                store: {
                    data: [
                        { name: 'Text'.t(), value: 'TEXT' },
                        { name: 'Pie Graph'.t(), value: 'PIE_GRAPH' },
                        { name: 'Time Graph'.t(), value: 'TIME_GRAPH' },
                        { name: 'Time Graph Dynamic'.t(), value: 'TIME_GRAPH_DYNAMIC' },
                        { name: 'Event List'.t(), value: 'EVENT_LIST' },
                    ]
                },
                hidden: true,
                bind: {
                    value: '{eEntry.type}',
                    hidden: '{!eEntry}'
                }
            }, {
                // TEXT
                xtype: 'textarea',
                anchor: '100%',
                fieldLabel: 'Text String'.t(),
                bind: {
                    value: '{eEntry.textString}',
                    hidden: '{eEntry.type !== "TEXT"}',
                    disabled: '{eEntry.type !== "TEXT"}'
                },
                allowBlank: false
            },

            /** PIE_GRAPH settings down */
            {
                xtype: 'combo',
                fieldLabel: 'Pie Group Column'.t(),
                margin: '5 0',
                typeAhead: true,
                hideTrigger: true,
                displayField: 'value',
                valueField: 'value',
                bind: {
                    store: { data: '{f_tableColumns}' },
                    value: '{eEntry.pieGroupColumn}',
                    hidden: '{eEntry.type !== "PIE_GRAPH"}',
                    disabled: '{eEntry.type !== "PIE_GRAPH"}'
                },
                queryMode: 'local',
                allowBlank: false,
                emptyText: 'Column Id or custom value'.t()
            }, {
                xtype: 'combo',
                fieldLabel: 'Pie Sum Column'.t(),
                margin: '5 0',
                typeAhead: true,
                hideTrigger: true,
                displayField: 'value',
                valueField: 'value',
                bind: {
                    store: { data: '{f_tableColumns}' },
                    value: '{eEntry.pieSumColumn}',
                    hidden: '{eEntry.type !== "PIE_GRAPH"}',
                    disabled: '{eEntry.type !== "PIE_GRAPH"}'
                },
                queryMode: 'local',
                allowBlank: false,
                emptyText: 'Column Id or custom value (e.g. count(*))'.t()
            }, {
                xtype: 'fieldcontainer',
                fieldLabel: 'Order By Column'.t(),
                allowBlank: false,
                bind: {
                    hidden: '{eEntry.type !== "PIE_GRAPH"}',
                    disabled: '{eEntry.type !== "PIE_GRAPH"}'
                },
                layout: { type: 'hbox', align: 'middle' },
                items: [{
                    xtype: 'textfield',
                    flex: 1,
                    emptyText: 'Column Id or custom value',
                    allowBlank: false,
                    bind: {
                        value: '{eEntry.orderByColumn}'
                    }
                }, {
                    xtype: 'segmentedbutton',
                    margin: '0 0 0 5',
                    items: [
                        { text: 'Asc'.t(), iconCls: 'fa fa-arrow-up', value: true },
                        { text: 'Desc'.t(), iconCls: 'fa fa-arrow-down' , value: false }
                    ],
                    bind: {
                        value: '{eEntry.orderDesc}'
                    }
                }]
            }, {
                xtype: 'combo',
                fieldLabel: 'Graph Style'.t(),
                editable: false,
                store: [
                    ['PIE', 'Pie'.t()],
                    ['PIE_3D', 'Pie 3D'.t()],
                    ['DONUT', 'Donut'.t()],
                    ['DONUT_3D', 'Donut 3D'.t()],
                    ['COLUMN', 'Column'.t()],
                    ['COLUMN_3D', 'Column 3D'.t()]
                ],
                queryMode: 'local',
                bind: {
                    value: '{eEntry.pieStyle}',
                    hidden: '{eEntry.type !== "PIE_GRAPH"}',
                    disabled: '{eEntry.type !== "PIE_GRAPH"}'
                },
                allowBlank: false,
                emptyText: 'Select Style ...'.t()
            }, {
                // PIE_GRAPH
                xtype: 'fieldcontainer',
                fieldLabel: 'Pie Slices Number'.t(),
                layout: {
                    type: 'hbox',
                    align: 'middle'
                },
                items: [{
                    xtype: 'slider',
                    flex: 1,
                    reference: 'pieNumSlices',
                    minValue: 1,
                    maxValue: 25,
                    increment: 1,
                    publishes: 'value',
                    publishOnComplete: false,
                    bind: {
                        value: '{eEntry.pieNumSlices}',
                    },
                    tipText: function (thumb) {
                        return String(thumb.value) + ' ' + 'slices'.t();
                    }
                }, {
                    xtype: 'component',
                    width: 80,
                    margin: '0 0 0 10',
                    bind: {
                        html: '<strong>{pieNumSlices.value} ' + 'slices'.t() + '</strong>'
                    }
                }],
                bind: {
                    hidden: '{eEntry.type !== "PIE_GRAPH"}',
                    disabled: '{eEntry.type !== "PIE_GRAPH"}'
                }
            },
            /** PIE_GRAPH settings up */

            /** TIME_GRAPH_DYNAMIC settings down */
            {
                xtype: 'combo',
                fieldLabel: 'Dynamic Column'.t(),
                // margin: '5 0',
                publishes: 'value',
                allowBlank: false,
                emptyText: 'Select Column ...'.t(),
                editable: false,
                queryMode: 'local',
                displayField: 'value',
                valueField: 'value',
                bind: {
                    store: { data: '{f_tableColumns}' },
                    value: '{eEntry.timeDataDynamicColumn}',
                    hidden: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                },
                displayTpl: '<tpl for=".">{text} [{value}]</tpl>',
                listConfig: {
                    itemTpl: ['<div data-qtip="{value}"><strong>{text}</strong> <span style="float: right;">[{value}]</span></div>']
                }
            }, {
                xtype: 'combo',
                fieldLabel: 'Dynamic Value'.t(),
                margin: '5 0',
                typeAhead: true,
                hideTrigger: true,
                displayField: 'value',
                valueField: 'value',
                bind: {
                    store: { data: '{f_tableColumns}' },
                    value: '{eEntry.timeDataDynamicValue}',
                    hidden: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                },
                queryMode: 'local',
                allowBlank: false,
                emptyText: 'Column Id or custom value'
            }, {
                xtype: 'fieldcontainer',
                fieldLabel: 'Dynamic Limit'.t(),
                layout: { type: 'hbox', align: 'middle' },
                items: [{
                    xtype: 'numberfield',
                    width: 70,
                    allowBlank: false,
                    disabled: true,
                    bind: {
                        value: '{eEntry.timeDataDynamicLimit}',
                        disabled: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                    }
                }, {
                    xtype: 'component',
                    padding: '0 5',
                    html: '<i class="fa fa-info-circle fa-gray" data-qtip="e.g. 10"></i>'
                }],
                disabled: false,
                bind: {
                    hidden: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                }
            }, {
                xtype: 'combo',
                fieldLabel: 'Aggregation Function'.t(),
                store: [
                    ['avg', 'Average'.t()],
                    ['count', 'Count'.t()],
                    ['sum', 'Sum'.t()],
                    ['min', 'Min'.t()],
                    ['max', 'Max'.t()]
                ],
                editable: false,
                allowBlank: false,
                emptyText: 'Select Aggregation Method ...'.t(),
                queryMode: 'local',
                bind: {
                    value: '{eEntry.timeDataDynamicAggregationFunction}',
                    hidden: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                }
            }, {
                // TIME_GRAPH, TIME_GRAPH_DYNAMIC
                xtype: 'combo',
                fieldLabel: 'Graph Style'.t(),
                editable: false,
                store: [
                    ['LINE', 'Line'.t()],
                    ['AREA', 'Area'.t()],
                    ['AREA_STACKED', 'Stacked Area'.t()],
                    ['BAR', 'Column'.t()],
                    ['BAR_OVERLAPPED', 'Overlapped Columns'.t()],
                    ['BAR_STACKED', 'Stacked Columns'.t()]
                ],
                queryMode: 'local',
                bind: {
                    value: '{eEntry.timeStyle}',
                    hidden: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                },
                allowBlank: false,
                emptyText: 'Select Style ...'.t()
            }, {
                // TIME_GRAPH, TIME_GRAPH_DYNAMIC
                xtype: 'combo',
                fieldLabel: 'Time Data Interval'.t(),
                editable: false,
                store: [
                    ['AUTO', 'Auto'.t()],
                    ['SECOND', 'Second'.t()],
                    ['MINUTE', 'Minute'.t()],
                    ['HOUR', 'Hour'.t()],
                    ['DAY', 'Day'.t()],
                    ['WEEK', 'Week'.t()],
                    ['MONTH', 'Month'.t()]
                ],
                queryMode: 'local',
                bind: {
                    value: '{eEntry.timeDataInterval}',
                    hidden: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                },
                allowBlank: false,
                emptyText: 'Select the Time Interval ...'.t()
            }, {
                // TIME_GRAPH, TIME_GRAPH_DYNAMIC
                xtype: 'combo',
                fieldLabel: 'Approximation'.t(),
                editable: false,
                store: [
                    ['average', 'Average'.t()],
                    ['high', 'High'.t()],
                    ['low', 'Low'.t()],
                    ['sum', 'Sum'.t() + ' (' + 'default'.t() + ')'] // default
                ],
                queryMode: 'local',
                bind: {
                    value: '{f_approximation}',
                    hidden: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                },
                allowBlank: false,
                emptyText: 'Select Approximation ...'.t()
            },
            /** TIME_GRAPH_DYNAMIC settings up */

            /** ALL GRAPHS settings down */
            {
                xtype: 'textfield',
                fieldLabel: 'Units'.t(),
                allowBlank: false,
                emptyText: 'Enter Units ... (e.g. sessions, bytes/s)'.t(),
                bind: {
                    value: '{eEntry.units}',
                    hidden: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC" && eEntry.type !== "PIE_GRAPH"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC" && eEntry.type !== "PIE_GRAPH"}'
                }
            }, {
                xtype: 'combo',
                fieldLabel: 'Series Renderer'.t(),
                store: Renderer.forReports,
                editable: false,
                queryMode: 'local',
                bind: {
                    value: '{eEntry.seriesRenderer}',
                    hidden: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC" && eEntry.type !== "PIE_GRAPH"}',
                    disabled: '{eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC" && eEntry.type !== "PIE_GRAPH"}'
                }
            }, {
                // PIE_GRAPH, TIME_GRAPH, TIME_GRAPH_DYNAMIC
                xtype: 'colorspicker',
                fieldLabel: 'Colors'.t(),
                pickerAlign: 'bl-tl',
                emptyText: 'Using default colors'.t(),
                bind: {
                    value: '{eEntry.colors}',
                    hidden: '{eEntry.type !== "PIE_GRAPH" && eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}',
                    disabled: '{eEntry.type !== "PIE_GRAPH" && eEntry.type !== "TIME_GRAPH" && eEntry.type !== "TIME_GRAPH_DYNAMIC"}'
                }
            }, {
                xtype: 'numberfield',
                fieldLabel: 'Display Order'.t(),
                anchor: '50%',
                bind: '{eEntry.displayOrder}',
                hidden: false,
                disabled: false
            }, {
                xtype: 'component',
                margin: '15 0',
                style: {
                    textAlign: 'center'
                },
                html: '<i class="fa fa-info-circle fa-lg fa-gray"></i> ' + 'Select default columns to show from the "Data Source" panel'.t(),
                disabled: false,
                bind: {
                    hidden: '{eEntry.type !== "EVENT_LIST"}',
                }
            }, {
                // used for validating text columns
                xtype: 'textfield',
                hidden: true,
                bind: {
                    value: '{textColumnsCount}',
                    disabled: '{eEntry.type !== "TEXT"}'
                },
                validator: function(val) {
                    return val > 0;
                }
            }, {
                // used for validating time columns
                xtype: 'textfield',
                hidden: true,
                bind: {
                    value: '{timeDataColumnsCount}',
                    disabled: '{eEntry.type !== "TIME_GRAPH"}'
                },
                validator: function(val) {
                    return val > 0;
                }
            }],
            dockedItems: [{
                xtype: 'toolbar',
                dock: 'bottom',
                ui: 'footer',
                defaults: {
                    xtype: 'button',
                    scale: 'medium'
                },
                items: [{
                    text: 'Cancel'.t(),
                    iconCls: 'fa fa-ban fa-lg',
                    handler: 'cancelEdit'
                }, '->' , {
                    iconCls: 'fa fa-trash fa-red fa-lg',
                    text: 'Delete'.t(),
                    handler: 'removeReport',
                    hidden: true,
                    bind: {
                        hidden: '{eEntry.readOnly || !eEntry.uniqueId}'
                    }
                }, {
                    text: 'Update'.t(),
                    iconCls: 'fa fa-floppy-o fa-lg',
                    formBind: true,
                    handler: 'updateReport',
                    hidden: true,
                    bind: {
                        hidden: '{eEntry.readOnly || !eEntry.uniqueId}'
                    }
                }, {
                    text: 'Create New'.t(),
                    iconCls: 'fa fa-floppy-o fa-lg',
                    formBind: true,
                    handler: 'saveNewReport'
                }]
            }]
        }, {
            /**
             * south border region width entry data source and sql conditions etc...
             */
            region: 'south',
            height: 300,
            split: true,
            layout: 'border',
            hidden: true,
            bind: {
                hidden: '{!eEntry}'
            },
            defaults: {
                border: false
            },
            items: [{
                region: 'west',
                itemId: 'tableColumns',
                xtype: 'grid',
                weight: 25,
                title: '<i class="fa fa-database"></i> ' + 'Data Source'.t(),
                width: 350,
                split: true,
                sortableColumns: false,
                disableSelection: true,
                enableColumnHide: false,
                columnLines: true,
                viewConfig: {
                    enableTextSelection: true,
                    stripeRows: false
                },
                // selType: 'checkboxmodel',
                bind: {
                    store: {
                        data: '{f_tableColumns}',
                        listeners: {
                            update: function (grid, column) {
                                Ext.fireEvent('defaultcolumnschange', column);
                            }
                        }
                    }
                },
                columns: [{
                    xtype: 'checkcolumn',
                    header: '',
                    dataIndex: 'isDefault',
                    width: 25,
                    hidden: true,
                    bind: {
                        hidden: '{eEntry.type !== "EVENT_LIST"}'
                    }
                }, {
                    header: 'Column Name [Column Id]'.t(),
                    dataIndex: 'value',
                    flex: 1,
                    renderer: function (val, meta, record) {
                        return record.get('text') + ' [<strong>' + val + '</strong>]';
                    }
                }],
                dockedItems: [{
                    // ALL
                    xtype: 'toolbar',
                    dock: 'top',
                    padding: 5,
                    // ui: 'footer',
                    border: '1 1 0 1',
                    items: [{
                        xtype: 'combo',
                        flex: 1,
                        fieldLabel: 'Data Table'.t(),
                        fieldStyle: 'font-weight: bold',
                        labelAlign: 'right',
                        bind: {
                            value: '{eEntry.table}',
                            store: '{tables}'
                        },
                        editable: false,
                        queryMode: 'local',
                        allowBlank: false,
                        emptyText: 'Select Table ...'.t()
                    }]
                }, {
                    xtype: 'toolbar',
                    dock: 'bottom',
                    padding: 5,
                    items: [{
                        xtype: 'component',
                        html: ' <i class="fa fa-level-down fa-rotate-180 fa-lg"></i> ' + 'Select the default columns to show in report'.t()
                    }],
                    hidden: true,
                    bind: {
                        hidden: '{eEntry.type !== "EVENT_LIST"}'
                    }
                }]
            }, {
                region: 'north',
                title: '<i class="fa fa-columns"></i> ' + '<strong>' + 'Text Data Columns'.t() + '</strong>',
                height: '50%',
                split: true,
                xtype: 'grid',
                itemId: 'textColumnsGrid',
                sortableColumns: false,
                enableColumnResize: false,
                enableColumnMove: false,
                enableColumnHide: false,
                disableSelection: true,
                hideHeaders: true,
                border: false,
                viewConfig: {
                    emptyText: '<p style="text-align: center; margin: 0; line-height: 2; font-size: 12px; color: red;"><i class="fa fa-exclamation-triangle fa-lg fa-orange"></i><br/>' + 'Text Columns are required for the report!'.t() + '</p>',
                },
                tbar: [{
                    xtype: 'button',
                    text: 'Add'.t(),
                    iconCls: 'fa fa-plus-circle',
                    handler: function (btn) {
                        btn.up('grid').getStore().add({ str: '' });
                    }
                }],
                plugins: [{
                    ptype: 'cellediting',
                    clicksToEdit: 1
                }],
                disabled: false,
                bind: {
                    store: '{textColumnsStore}',
                    hidden: '{eEntry.type !== "TEXT"}'
                },
                columns: [{
                    xtype: 'rownumberer',
                    // title: 'Value Mask'.t(),
                    width: 40,
                    renderer: function (value, metaData, record, rowIdx) { return '{' + rowIdx + '}'; }
                }, {
                    dataIndex: 'str',
                    flex: 1,
                    editor: 'textfield',
                    renderer: function (val) {
                        return val ? '<strong>' + val + '</strong>' : '<em>Click to insert column value ...</em>';
                    }
                }, {
                    xtype: 'actioncolumn',
                    width: 40,
                    align: 'center',
                    resizable: false,
                    tdCls: 'action-cell',
                    iconCls: 'fa fa-times',
                    // handler: function (view, rowIndex, colIndex, item, e, record) {
                    //     record.drop();
                    // },
                    handler: 'removeTextColumn',
                    menuDisabled: true,
                    hideable: false
                }]
            }, {
                region: 'north',
                title: '<i class="fa fa-columns"></i> ' + '<strong>' + 'Time Data Columns'.t() + '</strong>',
                split: true,
                height: '50%',
                xtype: 'grid',
                itemId: 'timeDataColumnsGrid',
                sortableColumns: false,
                enableColumnResize: false,
                enableColumnMove: false,
                enableColumnHide: false,
                disableSelection: true,
                border: false,
                viewConfig: {
                    emptyText: '<p style="text-align: center; margin: 0; line-height: 2; font-size: 12px; color: red;"><i class="fa fa-exclamation-triangle fa-lg fa-orange"></i><br/>' + 'Time Data Columns are required for the graph!'.t() + '</p>',
                },
                tbar: [{
                    xtype: 'button',
                    text: 'Add'.t(),
                    iconCls: 'fa fa-plus-circle',
                    handler: function (btn) {
                        btn.up('grid').getStore().add({ str: '' });
                    }
                }],
                plugins: [{
                    ptype: 'cellediting',
                    clicksToEdit: 1
                }],
                disabled: false,
                bind: {
                    store: '{timeDataColumnsStore}',
                    hidden: '{eEntry.type !== "TIME_GRAPH"}'
                },
                columns: [{
                    dataIndex: 'str',
                    flex: 1,
                    editor: 'textfield',
                    renderer: function (val) {
                        return val ? '<strong>' + val + '</strong>' : '<em>Click to insert column value ...</em>';
                    }
                }, {
                    xtype: 'actioncolumn',
                    width: 40,
                    align: 'center',
                    resizable: false,
                    tdCls: 'action-cell',
                    iconCls: 'fa fa-times',
                    handler: 'removeTimeDataColumn',
                    // handler: function (view, rowIndex, colIndex, item, e, record) {
                    //     record.drop();
                    //     record.commit();
                    // },
                    menuDisabled: true,
                    hideable: false
                }]
            }, {
                region: 'center',
                title: '<i class="fa fa-filter"></i> ' + 'SQL Conditions'.t(),
                xtype: 'grid',
                itemId: 'sqlConditions',
                sortableColumns: false,
                enableColumnResize: false,
                enableColumnMove: false,
                enableColumnHide: false,
                // hideHeaders: true,
                disableSelection: true,
                viewConfig: {
                    emptyText: '<p style="text-align: center; margin: 0; line-height: 2;"><i class="fa fa-info-circle fa-lg"></i> ' + 'No Conditions'.t() + '</p>',
                    stripeRows: false,
                },
                fields: ['column', 'operator', 'value'],
                disabled: true,
                bind: {
                    disabled: '{!f_tableColumns}',
                    store: {
                        data: '{_sqlConditions}'
                    }
                },
                dockedItems: [{
                    xtype: 'toolbar',
                    dock: 'top',
                    layout: {
                        type: 'hbox',
                        align: 'stretch'
                    },
                    items: [{
                        xtype: 'combo',
                        emptyText: 'Select Column ...',
                        flex: 1,
                        itemId: 'sqlConditionsCombo',
                        reference: 'sqlConditionsCombo',
                        publishes: 'value',
                        value: '',
                        editable: false,
                        queryMode: 'local',
                        displayField: 'text',
                        valueField: 'value',
                        fieldStyle: 'font-weight: bold',
                        bind: {
                            store: {
                                data: '{f_tableColumns}'
                            }
                        },
                        displayTpl: '<tpl for=".">{text} [{value}]</tpl>',
                        listConfig: {
                            itemTpl: ['<div data-qtip="{value}">{text} <span style="font-weight: bold; float: right;">[{value}]</span></div>']
                        },
                    }, {
                        xtype: 'button',
                        text: 'Add',
                        iconCls: 'fa fa-plus-circle',
                        disabled: true,
                        bind: {
                            disabled: '{!sqlConditionsCombo.value}'
                        },
                        handler: 'addSqlCondition'
                    }]
                }],
                columns: [{
                    header: 'Column'.t(),
                    dataIndex: 'column',
                    renderer: 'sqlColumnRenderer',
                    width: 300
                }, {
                    header: 'Operator'.t(),
                    xtype: 'widgetcolumn',
                    width: 82,
                    align: 'center',
                    widget: {
                        xtype: 'combo',
                        width: 80,
                        bind: '{record.operator}',
                        store: ['=', '!=', '>', '<', '>=', '<=', 'like', 'not like', 'is', 'is not', 'in', 'not in'],
                        editable: false,
                        queryMode: 'local'
                    }

                }, {
                    header: 'Value'.t(),
                    xtype: 'widgetcolumn',
                    flex: 1,
                    widget: {
                        xtype: 'container',
                        layout: 'fit'
                    },
                    onWidgetAttach: 'onValueWidgetAttach'
                }, {
                    header: 'Auto Format'.t(),
                    xtype: 'checkcolumn',
                    dataIndex: 'autoFormatValue',
                    width: 80
                }, {
                    xtype: 'actioncolumn',
                    width: 22,
                    align: 'center',
                    iconCls: 'fa fa-times',
                    handler: 'removeSqlCondition'
                }]
            }]
        }, {
            region: 'east',
            xtype: 'reportdata',
            split: true,
            width: 400,
            minWidth: 400,
            bind: {
                hidden: '{!dataCk.pressed || eEntry}',
            }
        }]

    }]
});
Ext.define('Ung.view.reports.EntryController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.entry',

    control: {
        '#': {
            afterrender: 'onAfterRender',
            deactivate: 'onDeactivate'
        }
    },

    refreshTimeout: null,

    onDeactivate: function () {
        this.reset();
        this.getViewModel().set({
            entry: null,
            eEntry: null
        });
    },

    onAfterRender: function () {
        var me = this, vm = this.getViewModel();

        /**
         * each time report selection changes
         */
        vm.bind('{entry}', function (entry) {
            if (!entry) { return; }

            vm.set('eEntry', null);
            me.setReportCard(entry.get('type'));

            me.reload(true); // important to fetch data in reports view

            me.lookup('dataCk').setPressed(false); // close the data panel if open

            // check if widget in admin context
            if (Ung.app.context === 'ADMIN') {
                vm.set('widget', Ext.getStore('widgets').findRecord('entryId', entry.get('uniqueId')));
            }
        });

        vm.bind('{entry.table}', function (table) {
            vm.set('f_tableconfig', table ? TableConfig.generate(table) : []);
        });

        // each time the eEntry changes by selecting 'Settings'
        vm.bind('{eEntry}', function (eEntry) {
            me.getView().up('#reports').getViewModel().set('editing', eEntry ? true : false);

            if (!vm.get('entry')) { return; }

            if (!eEntry) { return; }

            // if not defaultColumns initialize with [] to avoid editing errors
            if (!eEntry.get('defaultColumns')) {
                eEntry.set('defaultColumns', []);
            }

            // transform eEntry text and time data columns to usable data for the stores
            vm.set('textColumns', Ext.Array.map(eEntry.get('textColumns') || [], function (col) { return { str: col }; }));
            vm.set('timeDataColumns', Ext.Array.map(eEntry.get('timeDataColumns') || [], function (col) { return { str: col }; }));
        });

        // each time the eEntry type is changed check if editing form is valid
        // vm.bind('{eEntry.type}', function (type) {

        //     if (!type) { return; }
        //     me.setReportCard(type);
        //     // defer needed for form validation
        //     Ext.defer(function () {
        //         if (me.getView().down('form').isValid()) {
        //             vm.set('validForm', true);
        //             me.reload(true);
        //         } else {
        //             vm.set('validForm', false);
        //             me.reset();
        //         }
        //     }, 100);
        // });

        // watch since date switching and reload the report
        vm.bind('{sinceDate.value}', function () {
            me.reload();
        });

        // watch auto refresh button switch on/off
        vm.bind('{r_autoRefreshBtn.pressed}', function (pressed) {
            if (pressed) {
                me.reload();
            } else {
                if (me.refreshTimeout) {
                    clearTimeout(me.refreshTimeout);
                    me.refreshTimeout = null;
                }
            }
        });

        /**
         * When query string changes, reload the chart data with the new conditions
         */
        vm.bind('{query.string}', function (conditionsQuery) {
            if (!me.conditionsQuery || me.conditionsQuery !== conditionsQuery) {
                me.conditionsQuery = conditionsQuery;
                me.reload();
            }
        });

        /**
         * When time range changes reload report
         */
        vm.bind('{time.range}', function () {
            me.reload();
        });

    },

    /**
     * sets active card based on report type
     */
    setReportCard: function (type) {
        var me = this, reportCard = '';
        switch(type) {
        case 'TEXT': reportCard = 'textreport'; break;
        case 'PIE_GRAPH':
        case 'TIME_GRAPH':
        case 'TIME_GRAPH_DYNAMIC': reportCard = 'graphreport'; break;
        case 'EVENT_LIST': reportCard = 'eventreport'; break;
        }
        me.getView().down('#reportCard').setActiveItem(reportCard);
    },

    filterData: function (min, max) {
        // aply filtering only on timeseries
        if (this.getViewModel().get('entry.type').indexOf('TIME_GRAPH') >= 0) {
            this.getView().down('#currentData').getStore().clearFilter();
            this.getView().down('#currentData').getStore().filterBy(function (point) {
                var t = point.get('time_trunc').time;
                return t >= min && t <= max ;
            });
        }
    },

    /**
     * reloads the reports
     * reset = false just fetches the data
     */
    reload: function (reset) {
        var me = this, vm = me.getViewModel(),
            entry = vm.get('eEntry') || vm.get('entry'), ctrl;

        if (!entry) { return; }

        vm.set('validForm', true); // te remove the valid warning

        me.setReportCard(entry.get('type'));

        switch(entry.get('type')) {
        case 'TEXT': ctrl = me.getView().down('textreport').getController(); break;
        case 'EVENT_LIST': ctrl = me.getView().down('eventreport').getController(); break;
        default: ctrl = me.getView().down('graphreport').getController();
        }

        if (!ctrl) {
            console.error('Entry controller not found!');
            return;
        }

        if (reset) {
            me.reset();
        }

        // if (reps) { reps.getViewModel().set('fetching', true); }
        ctrl.fetchData(reset, function (data) {
            // if (reps) { reps.getViewModel().set('fetching', false); }
            // if autorefresh enabled refetch data in 5 seconds
            vm.set('reportData', data);

            if (vm.get('r_autoRefreshBtn.pressed')) {
                me.refreshTimeout = setTimeout(function () {
                    me.reload();
                }, 5000);
            }
        });
    },

    reset: function () {
        var me = this, vm = me.getViewModel(),
            entry = vm.get('eEntry') || vm.get('entry'), ctrl;

        if (!entry) { return; }

        switch(entry.get('type')) {
        case 'TEXT': ctrl = me.getView().down('textreport').getController(); break;
        case 'EVENT_LIST': ctrl = me.getView().down('eventreport').getController(); break;
        default: ctrl = me.getView().down('graphreport').getController();
        }

        if (!ctrl) {
            console.error('Entry controller not found!');
            return;
        }
        if (Ext.isFunction(ctrl.reset)) {
            ctrl.reset();
        }
    },

    refresh: function () {
        this.getView().down('eventreport').fireEvent('refresh');
        this.reload(false);
    },

    resetAndReload: function () {
        this.reload(true);
    },

    // resetView: function(){
    //     var grid = this.getView().down('grid');
    //     Ext.state.Manager.clear(grid.stateId);
    //     grid.filters.clearFilters();
    //     grid.reconfigure(null, grid.tableConfig.columns);

    //     grid.getColumns().forEach( function(column){
    //         if( column.xtype == 'actioncolumn'){
    //             return;
    //         }
    //         column.setHidden( Ext.Array.indexOf(grid.visibleColumns, column.dataIndex) < 0 );
    //         if( column.columns ){
    //             column.columns.forEach( Ext.bind( function( subColumn ){
    //                 subColumn.setHidden( Ext.Array.indexOf(grid.visibleColumns, column.dataIndex) < 0 );
    //             }, this ) );
    //         }
    //     });
    // },


    // TABLE COLUMNS / CONDITIONS

    addSqlCondition: function () {
        var me = this, vm = me.getViewModel(),
            conds = vm.get('_sqlConditions') || [];

        conds.push({
            autoFormatValue: true,
            column: me.getView().down('#sqlConditionsCombo').getValue(),
            javaClass: 'com.untangle.app.reports.SqlCondition',
            operator: '=',
            value: ''
        });

        me.getView().down('#sqlConditionsCombo').setValue(null);

        vm.set('_sqlConditions', conds);
        me.getView().down('#sqlConditions').getStore().reload();
    },

    removeSqlCondition: function (table, rowIndex) {
        var me = this, vm = me.getViewModel(),
            conds = vm.get('_sqlConditions');
        Ext.Array.removeAt(conds, rowIndex);
        vm.set('_sqlConditions', conds);
        me.getView().down('#sqlConditions').getStore().reload();
    },

    sqlColumnRenderer: function (val) {
        return '<strong>' + TableConfig.getColumnHumanReadableName(val) + '</strong> <span style="float: right;">[' + val + ']</span>';
    },

    onValueWidgetAttach: function (column, container, record) {
        var me = this;

        var firstTable = TableConfig.getFirstTableFromField(record.get('column'));
        var values = TableConfig.getValues(record.get('table') ? record.get('table') : firstTable, record.get('column'));

        container.removeAll(true);

        if(values.length > 0){
            container.add({
                xtype: 'combo',
                queryMode: 'local',
                store: new Ext.data.ArrayStore({
                    fields: ['value', 'display'],
                    data: values
                }),
                emptyText: 'Select value'.t(),
                displayField: 'display',
                valueField: 'value',
                allowBlank: false,
                editable: false,
                bind: {
                    value: '{record.value}'
                },
            });

        }else{
            container.add({
                xtype: 'textfield',
                bind: {
                    value: '{record.value}'
                },
            });
        }
    },

    // TABLE COLUMNS / CONDITIONS END


    // // DASHBOARD ACTION
    dashboardAddRemove: function () {
        var me = this, vm = me.getViewModel(), widget = vm.get('widget'), entry = vm.get('entry');

        if (!widget) {
            widget = Ext.create('Ung.model.Widget', {
                displayColumns: entry.get('defaultColumns'),
                enabled: true,
                entryId: entry.get('uniqueId'),
                javaClass: 'com.untangle.uvm.DashboardWidgetSettings',
                refreshIntervalSec: 60,
                timeframe: '',
                type: 'ReportEntry'
            });

            Ext.getStore('widgets').add(widget);
            vm.set('widget', widget);
        } else {
            var records = Ext.getStore('widgets').queryRecords('entryId', entry.get('uniqueId'));
            Ext.getStore('widgets').remove(records);
            vm.set('widget', null);
        }
    },


    validateTitle: function (entry, action) {
        var me = this, field = me.getView().down('#report_title'),
            foundEntry = Ext.getStore('reports').findRecord('title', entry.get('title').trim(), 0, false, false, true);

        // if not entry found than title is unique
        if (!foundEntry) {
            return true;
        }

        // on creating a new one
        if (action === 'create') {
            field.markInvalid('Choose a unique report title!'.t());
            return false;
        }

        // on update existing custom one
        if (foundEntry.get('uniqueId') === entry.get('uniqueId')) {
            return true;
        } else {
            field.markInvalid('Choose a unique report title!'.t());
            return false;
        }
    },

    /**
     * updates an existing custom report
     */
    updateReport: function () {
        var me = this,
            v = me.getView(),
            vm = me.getViewModel(),
            entry = vm.get('entry'),
            eEntry = vm.get('eEntry'), tdcg, tdc = [];

        if (!me.validateTitle(eEntry, 'update')) {
            return;
        }

        // update timeDataColumns or textColumns
        if (eEntry.get('type') === 'TIME_GRAPH') {
            tdcg = v.down('#timeDataColumnsGrid');
            tdcg.getStore().each(function (col) { tdc.push(col.get('str')); });
            eEntry.set('timeDataColumns', tdc);
        }
        if (eEntry.get('type') === 'TEXT') {
            tdcg = v.down('#textColumnsGrid');
            tdcg.getStore().each(function (col) { tdc.push(col.get('str')); });
            eEntry.set('textColumns', tdc);
        }

        v.setLoading(true);
        Rpc.asyncData('rpc.reportsManager.saveReportEntry', eEntry.getData())
            .then(function() {
                if(Util.isDestroyed(v, vm, me)){
                    return;
                }
                v.setLoading(false);

                var modFields = entry.copyFrom(eEntry);

                // NGFW-11362 - update report icon on graph style change
                if (Ext.Array.contains(modFields, 'icon')) {
                    var node = Ext.getStore('reportstree').findNode('uniqueId', entry.get('uniqueId'));
                    if (!node) { return; }
                    node.set('iconCls', 'fa ' + entry.get('icon'));
                }

                // if title or category changed, update route
                if (Ext.Array.contains(modFields, 'category') || Ext.Array.contains(modFields, 'title')) {
                    if (Ext.Array.contains(modFields, 'category') ){
                        var oldIndex = Ext.getStore('reports').find('uniqueId', entry.get('uniqueId'));
                        Ext.getStore('reports').removeAt(oldIndex);
                        Ext.getStore('reports').add(eEntry);
                    }
                    Ext.getStore('reportstree').build();
                    Ung.app.redirectTo('#reports?cat=' + Util.urlEncode(entry.get('category')) + '&rep=' + Util.urlEncode(entry.get('title')));
                }

                vm.set('eEntry', null);
                vm.notify();

                me.reload(true);

                Util.successToast('<span style="color: yellow; font-weight: 600;">' + vm.get('entry.title') + '</span> report updated!');
            });
    },

    /**
     * creates a new report
     */
    saveNewReport: function () {
        var me = this,
            v = this.getView(),
            vm = this.getViewModel(),
            entry = vm.get('eEntry'), tdcg, tdc = [];

        if (!me.validateTitle(entry, 'create')) {
            return;
        }

        entry.set('uniqueId', 'report-' + Math.random().toString(36).substr(2));
        entry.set('readOnly', false);

        // update timeDataColumns or textColumns
        if (entry.get('type') === 'TIME_GRAPH') {
            tdcg = v.down('#timeDataColumnsGrid');
            tdcg.getStore().each(function (col) { tdc.push(col.get('str')); });
            entry.set('timeDataColumns', tdc);
        }
        if (entry.get('type') === 'TEXT') {
            tdcg = v.down('#textColumnsGrid');
            tdcg.getStore().each(function (col) { tdc.push(col.get('str')); });
            entry.set('textColumns', tdc);
        }

        v.setLoading(true);
        Rpc.asyncData('rpc.reportsManager.saveReportEntry', entry.getData())
            .then(function() {
                if(Util.isDestroyed(v, me)){
                    return;
                }
                v.setLoading(false);
                Ext.getStore('reports').add(entry);
                Util.successToast('<span style="color: yellow; font-weight: 600;">' + entry.get('title') + ' report added!');
                Ung.app.redirectTo('#reports?cat=' + Util.urlEncode(entry.get('category')) + '&rep=' + Util.urlEncode(entry.get('title')));

                Ext.getStore('reportstree').build(); // rebuild tree after save new
                me.reload();
            });
    },

    /**
     * removes a custom created report
     */
    removeReport: function () {
        var me = this, vm = this.getViewModel(),
            entry = vm.get('entry');

        Ext.MessageBox.confirm('Warning'.t(),
            'Deleting this report will also remove Dashboard widgets containing this report!'.t() + '<br/><br/>' +
            'Do you want to continue?'.t(),
            function (btn) {
                if(Util.isDestroyed(vm, me)){
                    return;
                }
                if (btn === 'yes') {
                    if (vm.get('widget')) {
                        var records = Ext.getStore('widgets').queryRecords('entryId', entry.get('uniqueId'));
                        Ext.getStore('widgets').remove(records);
                    }
                    me.removeReportAction(entry.getData());
                }
            });

    },

    removeReportAction: function (entry) {
        var vm = this.getViewModel();
        Rpc.asyncData('rpc.reportsManager.removeReportEntry', entry)
            .then(function () {
                if(Util.isDestroyed(vm)){
                    return;
                }
                Ung.app.redirectTo('#reports?cat=' + Util.urlEncode(entry.category));
                Util.successToast(entry.title + ' ' + 'deleted successfully'.t());
                vm.set('eEntry', null);
                var removableRec = Ext.getStore('reports').findRecord('uniqueId', entry.uniqueId);
                if (removableRec) {
                    Ext.getStore('reports').remove(removableRec); // remove record
                    Ext.getStore('reportstree').build(); // rebuild tree after save new
                }
            }, function (ex) {
                Util.handleException(ex);
            });
    },

    /**
     * exports Events list from an Event Report
     */
    exportEventsHandler: function () {
        var me = this, vm = me.getViewModel(), entry = vm.get('entry').getData(), columns = [], startDate, endDate;
        if (!entry) { return; }

        var grid = me.getView().down('eventreport > ungrid');

        if (!grid) {
            console.log('Grid not found');
            return;
        }

        Ext.Array.each(grid.getColumns(), function (col) {
            if (col.dataIndex && !col.hidden) {
                columns.push(col.dataIndex);
            }
        });

        // startDate converted from UI to server date
        startDate = Util.clientToServerDate(vm.get('time.range.since'));
        // endDate converted from UI to server date
        endDate = Util.clientToServerDate(vm.get('time.range.until'));

        Ext.MessageBox.wait('Exporting Events...'.t(), 'Please wait'.t());
        var downloadForm = document.getElementById('downloadForm');
        downloadForm['type'].value = 'eventLogExport';
        downloadForm['arg1'].value = (entry.category + '-' + entry.title + '-' + Ext.Date.format(startDate, 'd.m.Y-H:i') + '-' + Ext.Date.format(endDate || Util.clientToServerDate(new Date()), 'd.m.Y-H:i')).replace(/ /g, '_');
        downloadForm['arg2'].value = Ext.encode(entry);
        downloadForm['arg3'].value = Ext.encode(Ung.model.ReportCondition.collect(vm.get('query.conditions')));
        downloadForm['arg4'].value = columns.join(',');
        downloadForm['arg5'].value = startDate ? startDate.getTime() : -1;
        downloadForm['arg6'].value = endDate ? endDate.getTime() : -1;
        downloadForm.submit();
        Ext.MessageBox.hide();
    },

    editEntry: function (newEntry) {
        var me = this, vm = me.getViewModel(), eEntry, conditions, newConditions = [];

        if (newEntry === true) { // important true check
            // if it's a new report start with a blank entry
            eEntry = Ext.create('Ung.model.Report');
            eEntry.set('conditions', null);
            me.reset(); // reset graph
        } else {
            // otherwise edit existing one
            eEntry = vm.get('entry').copy(null);
            conditions = eEntry.get('conditions');

            // NGFW-11484 - clone conditions objects to avoid issues when creating new reports
            if (Ext.isArray(conditions)) {
                Ext.Array.each(conditions, function (cond) {
                    newConditions.push(Ext.clone(cond));
                });
            }
            eEntry.set('conditions', newConditions.length > 0 ? newConditions : null);
        }

        vm.set('eEntry', eEntry);
        vm.notify();
    },

    cancelEdit: function () {
        var me = this, vm = me.getViewModel();

        if (!vm.get('entry')) {
            // when canceling from creating a brand new report
            me.getView().up('#cards').setActiveItem('category');
        }

        vm.set('eEntry', null);
        vm.set('validForm', true);
        vm.notify();

        // go back if returning from create new report
        if (location.hash === '#reports/create') {
            Ext.util.History.back();
            return;
        }
        // reload the current entry as it was before editing
        me.reload(true);
    },

    onTextColumnsChanged: function (store) {
        var vm = this.getViewModel(), tdc = [];
        // update validation counter
        vm.set('textColumnsCount', store.getCount());
        // update the actual entry
        store.each(function (col) { tdc.push(col.get('str')); });
        vm.set('eEntry.textColumns', tdc);
    },

    onTimeDataColumnsChanged: function (store) {
        var vm = this.getViewModel(), tdc = [];
        // update validation counter
        vm.set('timeDataColumnsCount', store.getCount());
        // update the actual entry
        store.each(function (col) { tdc.push(col.get('str')); });
        vm.set('eEntry.timeDataColumns', tdc);
    },

    removeTextColumn: function (view, rowIndex, colIndex, item, e, record) {
        var store = view.getStore(), tdc = [];
        store.remove(record);
        view.refresh();
    },

    removeTimeDataColumn: function (view, rowIndex, colIndex, item, e, record) {
        view.getStore().remove(record);
    },

    exportSettings: function () {
        var me = this, vm = me.getViewModel(),
            rep = vm.get('entry').getData();

        delete rep._id;
        delete rep.localizedTitle;
        delete rep.localizedDescription;
        delete rep.slug;
        delete rep.categorySlug;
        delete rep.url;
        delete rep.icon;

        var exportForm = document.getElementById('exportGridSettings');
        exportForm.gridName.value = 'Report-' + rep.title.replace(/ /g, '_');
        exportForm.gridData.value = Ext.encode([rep]);
        exportForm.submit();
    }
});
Ext.define('Ung.view.reports.EntryModel', {
    extend: 'Ext.app.ViewModel',
    alias: 'viewmodel.entry',

    data: {
        eEntry: null, // editable entry, copy of the selected entry
        reportData: [],
        _currentData: [],

        tableColumns: [],

        textColumns: [],
        textColumnsCount: 0, // used for grids validation
        timeDataColumns: [],
        timeDataColumnsCount: 0, // used for grids validation

        validForm: true
    },

    stores: {
        textColumnsStore: {
            data: '{textColumns}',
            listeners: {
                datachanged: 'onTextColumnsChanged',
                update: 'onTextColumnsChanged'
            }
        },
        timeDataColumnsStore: {
            data: '{timeDataColumns}',
            listeners: {
                datachanged: 'onTimeDataColumnsChanged',
                update: 'onTimeDataColumnsChanged'
            }
        }
    },

    formulas: {

        f_tableColumns: function (get) {
            var table = get('eEntry.table'), tableConfig, defaultColumns;

            if (!table) { return []; }

            tableConfig = TableConfig.generate(table);

            if (get('eEntry.type') !== 'EVENT_LIST') {
                return tableConfig.comboItems;
            }

            // initially set none as default
            Ext.Array.each(tableConfig.comboItems, function (item) {
                item.isDefault = false;
            });

            Ext.Array.each(get('eEntry.defaultColumns'), function (defaultColumn) {
                var col = Ext.Array.findBy(tableConfig.comboItems, function (item) {
                    return item.value === defaultColumn;
                });
                // remove default columns if not in TableConfig
                if (col) {
                    // Set it as default
                    col.isDefault = true;
                }
            });
            return tableConfig.comboItems;
        },

        f_textColumnsCount: function (get) {
            return get('textColumns').length;
        },

        f_approximation: {
            get: function (get) {
                return get('eEntry.approximation') || 'sum';
            },
            set: function (value) {
                this.set('eEntry.approximation', value !== 'sum' ? value : null);
            }
        },

        _sqlConditions: {
            get: function (get) {
                return get('eEntry.conditions') || [];
            },
            set: function (value) {
                this.set('eEntry.conditions', value);
            },
        },

        // _props: function (get) {
        //     return get('entry').getData();
        // },

        f_tableColumnsSource: function (get) {
            var columns = get('tableColumns'), source = {};
            if (!columns || columns.length === 0) { return {}; }
            Ext.Array.each(columns, function (column) {
                source[column.text] = column.value;
            });
            return source;
        }
    }

});
Ext.define('Ung.view.reports.EventReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.eventreport',

    config: {
        widget: null
    },

    layout: 'border',

    border: false,
    bodyBorder: false,

    defaults: {
        border: false
    },

    items: [{
        xtype: 'ungrid',
        stateful: true,
        itemId: 'eventsGrid',
        reference: 'masterGrid',
        region: 'center',
        store: { data: [] },
        plugins: ['gridfilters'],
        selModel: {
            type: 'rowmodel'
        },
        // emptyText: '<p style="text-align: center; margin: 0; line-height: 2;"><i class="fa fa-info-circle fa-2x"></i> <br/>No Records!</p>',
        enableColumnHide: true,
        listeners: {
            select: 'onEventSelect',
            columnsChanged: 'onColumnsChanged'
        }
    }, {
        xtype: 'unpropertygrid',
        itemId: 'eventsProperties',
        reference: 'eventsProperties',
        features: [{
            ftype: 'grouping',
            groupHeaderTpl: ['{name}']
        }],
        region: 'east',
        title: 'Details'.t(),
        collapsible: true,
        collapsed: true,
        bind: {
            hidden: '{isWidget}'
        },
        animCollapse: false,
        titleCollapse: true,
    }],

    controller: {
        control: {
            '#': {
                afterrender: 'onAfterRender',
                deactivate: 'onDeactivate',
                refresh: 'onRefresh'
            }
        },

        listen: {
            global: {
                defaultcolumnschange: 'onDefaultColumn'
            }
        },

        onAfterRender: function (view) {
            var me = this, vm = this.getViewModel(),
                store = view.down('grid').getStore();

            // find and set the widget component if report is rendered inside a widget
            view.setWidget(view.up('reportwidget'));

            // add store datachange listener here, as it won't work in view definition
            store.on('datachanged', function () { me.onDataChanged(); } );

            // hide property grid if rendered inside widget
            if (view.getWidget() || view.up('new-widget')) {
                vm.set('isWidget', true);
            }

            vm.bind('{entry}', function (entry) {
                if(Util.isDestroyed(me, view)){
                    return;
                }

                // clear grid data on report change
                store.setData([]);
                // clear sorters
                if (store.sorters) {
                    store.sorters.clear();
                }

                if (!entry || entry.get('type') !== 'EVENT_LIST') {
                    return;
                }

                /**
                 * store table info, and update the grid settings
                 * only on initialization and when the default columns are different than shown
                 */

                // This component query will find displayed columns on current grid display, and convert them into an array of dataindexes
                var currentCols = this.getView().down('grid').query('gridcolumn:not([hidden])').map(function(item){return item.dataIndex;});

                if (!me.table || me.table !== entry.get('table') || !Ext.Array.equals(entry.get('defaultColumns'), currentCols)) {
                    me.table = entry.get('table');
                    me.setupGrid();
                }

                // if rendered in creating new widget dialog, fetch data
                if (view.up('new-widget')) {
                    me.fetchData(true);
                }
            });
        },

        /**
         * Reconfigures the grid by setting new model fields and grid columns
         */
        setupGrid: function () {
            var me = this,
                vm = me.getViewModel(),
                grid = me.getView().down('grid'),
                model = grid.getStore().getModel(),
                entry = vm.get('eEntry') || vm.get('entry'),
                defaultColumns; // default columns to show for report

            if (!entry) { return; }

            defaultColumns = entry.get('defaultColumns');

            // keep this for backward compatibility
            if (me.getView().up('reportwidget')) {
                me.isWidget = true;
            }

            var tableConfig = TableConfig.tableConfig[me.table];

            // hide non default columns
            Ext.Array.each(tableConfig.columns, function (column) {
                column.hidden = !Ext.Array.contains(defaultColumns, column.dataIndex);
            });

            // see how to update fields, even if it works still as it is
            model.removeFields(Ext.Array.remove(Ext.Object.getKeys(model.getFieldsMap()), '_id'));
            model.addFields(tableConfig.fields);
            grid.reconfigure(tableConfig.columns);
        },

        onDefaultColumn: function (defaultColumn) {
            var me = this, vm = me.getViewModel(),
                grid = me.getView().down('ungrid'),
                entry = vm.get('eEntry');
            if (!entry) { return; }
            Ext.Array.each(grid.getColumns(), function (column) {
                if (column.dataIndex === defaultColumn.get('value')) {
                    column.setHidden(!defaultColumn.get('isDefault'));
                    if (defaultColumn.get('isDefault')) {
                        entry.get('defaultColumns').push(column.dataIndex);
                    } else {
                        Ext.Array.remove(entry.get('defaultColumns'), column.dataIndex);
                    }

                }
            });
        },

        onDeactivate: function () {
            this.modFields = { uniqueId: null };
            this.getView().down('grid').getStore().loadData([]);
            this.getView().down('grid').getSelectionModel().deselectAll();
        },

        onRefresh: function(){
            if(this.tableConfig && this.tableConfig.refresh){
                this.tableConfig.refresh();
            }
        },

        fetchData: function (reset, cb) {
            var me = this,
                vm = me.getViewModel(),
                entry = vm.get('eEntry') || vm.get('entry'),
                reps = me.getView().up('#reports'),
                startDate, endDate;

            if (!entry) { return; }

            // if (reset) {
            //     me.getView().down('grid').getStore().loadData([]);
            //     me.setupGrid();
            // }


            var limit = 1000;
            if (me.getView().up('entry')) {
                limit = me.getView().up('entry').down('#eventsLimitSelector').getValue();
            }

            // date range setup
            if (!me.getView().renderInReports) {
                // if not rendered in reports than treat as widget so from server startDate is extracted the timeframe
                startDate = new Date(Util.getMilliseconds() - (Ung.dashboardSettings.timeframe * 3600 || 3600) * 1000);
                endDate = null;
            } else {
                // if it's a report, convert UI client start date to server date
                startDate = Util.clientToServerDate(vm.get('time.range.since'));
                endDate = Util.clientToServerDate(vm.get('time.range.until'));
            }

            me.getView().setLoading(true);
            if (reps) { reps.getViewModel().set('fetching', true); }

            Rpc.asyncData('rpc.reportsManager.getEventsForDateRangeResultSet',
                entry.getData(), // entry
                Ung.model.ReportCondition.collect(vm.get('query.conditions')),
                limit,
                startDate,
                endDate)
                .then(function(result) {
                    if(Util.isDestroyed(me)){
                        return;
                    }
                    me.getView().setLoading(false);
                    if (reps) {
                        reps.getViewModel().set('fetching', false);
                    }
                    me.loadResultSet(result);
                })
                .always(function () { // NGFW-11467
                    if(Util.isDestroyed(me)){
                        return;
                    }
                    if (cb) {
                        cb();
                    }
                    me.getView().setLoading(false);
                    if (reps) {
                        reps.getViewModel().set('fetching', false);
                    }
                });
        },

        loadResultSet: function (reader) {
            var me = this, grid = me.getView().down('grid');

            this.getView().setLoading(true);
            // grid.getStore().setFields( me.tableConfig.fields );
            var eventData = [];
            var result = [];
            while( true ){
                result = reader.getNextChunk(1000);
                if(result && result.list && result.list.length){
                    result.list.forEach(function(value){
                        eventData.push(value);
                    });
                    continue;
                }
                break;
            }
            reader.closeConnection();
            grid.getStore().loadData(eventData);
        },

        onEventSelect: function (el, record) {
            var me = this, vm = this.getViewModel(), propsData = [];

            if (me.isWidget) { return; }

            // when selecting an event hide Settings if open
            if (me.getView().up('entry')) {
                me.getView().up('entry').lookupReference('settingsBtn').setPressed(false);
            }

            // if(me.tableConfig.listeners && me.tableConfig.listeners.select){
            //     me.tableConfig.listeners.select.apply(me, arguments);
            // }
        },

        onDataChanged: function(){
            var me = this,
                v = me.getView(),
                vm = me.getViewModel();

            if( vm.get('eventProperty') == null ){
                v.down('grid').getSelectionModel().select(0);
            }

            this.bindExportButtons();
        },

        onColumnsChanged: function() {
            this.bindExportButtons();
        },

        /**
         * bindExportButtons handles the binding of the ungrid component and store to the exportCsv button
         * Within this functionality we create an Ext.js default grid panel and set the current columns and store to the grid.
         * The grid is not rendered, but passed directly into the Exporter tools, which handle proper exporting of the data.
         *
         * This binding is quite inefficient because it runs whenever data or columns are changed
         * todo: trigger binding only when export button is pressed
         */
        bindExportButtons: function() {
            var me = this,
            entry = me.getViewModel().get('entry'),
            export_title = 'export', // default export title
            csvButton,
            exportButton = me.getView().up().up().down('#exportData');
            grid = me.getView().down('grid');

            if (!exportButton || !grid) { return; }

            csvButton = exportButton.down('#exportCsv');

            if (!csvButton) { return; }

            if (entry) {
                export_title = (entry.get('category') + '-' + entry.get('title')).replace(/ /g, '_');
            }

            /**
             * exporterbutton uses the `title` prop to set the filename
             * given that the title is altered so it contains the report entry category/title
             */
            csvButton.title = export_title;

            /**
             * it is necessary to generate a different grid which is decoupled from original one
             * because of the formula injections preventions which strips some special characters from values
             *
             * record.set(field, value) would trigger the renderer and converter methods
             * and it will fail with exception as the value has already been converted from id to string
             */

            var originalStore = grid.getStore(),
                originalVisibleColumns = grid.getVisibleColumns(),
                originalFields = originalStore.getModel().fields,
                dataIndexes = Ext.Array.pluck(originalVisibleColumns, 'dataIndex'),

                exportColumns = [],
                exportFields = [],
                exportData = [];

            originalVisibleColumns.forEach(function (column) {
                exportColumns.push({
                    text: column.text,
                    dataIndex: column.dataIndex
                });
            });

            originalFields.forEach(function (field) {
                if (!Ext.Array.contains(dataIndexes, field.name)) {
                    return;
                }
                exportFields.push({
                    type: field.type,
                    name: field.name
                });
            });

            originalStore.each(function(record) {
                var recordData = {};
                record.fields.forEach(function (field) {
                    var fieldName = field.name,
                        fieldValue = record.get(fieldName);

                    if (!Ext.Array.contains(dataIndexes, fieldName)) {
                        return;
                    }

                    /**
                     * For any strings, first unescape any html and then
                     * remove any commas in the string, and escape leading -, ", @, +, and =
                     * with a single quote to prevent formula injections
                     * This was moved from the ReportsApp toCSV java function
                     */
                    if (typeof fieldValue  === 'string') {

                        /**
                         * Unescape any html
                         */
                        var txt = document.createElement('textarea');
                        txt.innerHTML = fieldValue;
                        fieldValue = txt.value;

                        fieldValue = fieldValue.replace(new RegExp(",", 'gi'), "").replace(new RegExp("(^|,)([-\"@+=])", 'gi'), "$1'$2");
                    }
                    recordData[fieldName] = fieldValue;
                });
                exportData.push(recordData);
            });

            // Build an exportGrid object to use with the csv/xls export buttons
            var exportStore = Ext.create('Ext.data.Store', {
                data: exportData,
                model: Ext.create('Ext.data.Model', {
                    fields: exportFields
                })
            });
            var exportGrid = Ext.create('Ext.grid.Panel', {
                store: exportStore,
                columns: exportColumns
            });

            csvButton.component = exportGrid;

            csvButton.store = exportStore;
        }
    },
    statics:{
        renderer: function(value, meta, record, x,y, z, table){
            meta.tdAttr = 'data-qtip="' + Ext.String.htmlEncode( value ) + '"';
            return value;
        },

    }
});
Ext.define('Ung.view.reports.GraphReport', {
    extend: 'Ext.Component',
    alias: 'widget.graphreport',

    viewModel: true,

    border: false,
    bodyBorder: false,

    margin: '0 0 0 5px',

    listeners: {
        afterrender: 'onAfterRender',
        resize: 'onResize',
        deactivate: 'reset'
    },

    config: {
        widget: null,
        chart: null
    },

    controller: {

        onAfterRender: function (view) {
            var me = this,
                vm = me.getViewModel();

            // initialize an empty chart (once)
            me.initChart();
            // find and set the widget component if report is rendered inside a widget
            view.setWidget(view.up('reportwidget'));
            // if it's a widget, than fetch data after the report entry is binded to it
            vm.bind('{entry}', function (entry) {
                if(Util.isDestroyed(me, view)){
                    return;
                }
                if (!entry ||
                    ( entry.get('type') !== 'PIE_GRAPH' &&
                      entry.get('type') !== 'TIME_GRAPH' &&
                      entry.get('type') !== 'TIME_GRAPH_DYNAMIC') ) {
                    return;
                }

                // if rendered as widget, add to dashboard queue
                // if (view.getWidget()) {
                //     // console.log('aaa');
                //     DashboardQueue.addFirst(view.getWidget());
                // }

                // if rendered in creating new widget dialog, fetch data
                if (view.up('new-widget') || view.itemId == 'fixedChart') {
                    me.fetchData(true);
                }
            });

            // when editing entry update graph styles on the fly
            vm.bind('{eEntry.pieStyle}', function (pieStyle) {
                if(Util.isDestroyed(me)){
                    return;
                }
                if (!pieStyle) { return; }
                me.setStyles();
            });

            vm.bind('{eEntry.timeStyle}', function (timeStyle) {
                if(Util.isDestroyed(me)){
                    return;
                }
                if (!timeStyle) { return; }
                me.setStyles();
            });
        },

        /**
         * initializes an empty chart (no data) and adds it to the container (this is done once)
         */
        initChart: function () {
            var me = this, isWidget = me.getView().isWidget;

            me.chart = new Highcharts.stockChart(me.getView().getEl().dom, {
                chart: {
                    // type: 'spline',
                    // animation: false,
                    marginRight: isWidget ? undefined : 20,
                    spacing: isWidget ? [5, 5, 10, 5] : [30, 10, 15, 10],
                    style: { fontFamily: 'Roboto Condensed', fontSize: '10px' },
                    backgroundColor: 'transparent',
                    selectedrange: null,
                    events: {
                        selection: function (event) {
                            if (isWidget) { return; } // applies only when viewing the report
                            if (event.resetSelection) {
                                me.chart.update({
                                    exporting: {
                                        buttons: {
                                            timerangeButton: {
                                                enabled: false
                                            }
                                        }
                                    }
                                });
                                me.chart.selectedrange = null;
                            } else {
                                me.chart.update({
                                    exporting: {
                                        buttons: {
                                            timerangeButton: {
                                                enabled: true
                                            }
                                        }
                                    }
                                });
                                me.chart.selectedrange = {
                                    min: event.xAxis[0].min,
                                    max: event.xAxis[0].max
                                };
                            }
                        }
                    }
                },
                exporting: {
                    enabled: true,
                    buttons: {
                        contextButton: {
                            enabled: false // disable default contextButton
                        },
                        timerangeButton: {
                            text: 'Apply this timerange'.t(),
                            align: 'center',
                            enabled: false, // this updates based on zoom selection
                            y: 10,
                            onclick: function() {
                                Ext.fireEvent('timerangechange', me.chart.selectedrange);
                            }
                        }
                    }
                },
                navigator: { enabled: false },
                rangeSelector : { enabled: false },
                scrollbar: { enabled: false },
                credits: { enabled: false },
                title: {
                    text: null,
                    useHtml: true,
                    align: 'left'
                },
                subtitle: {
                    align: 'left',
                    useHtml: true
                },
                noData: {
                    position: {
                        y: -20
                    },
                    style: {
                        fontSize: '16px',
                        fontWeight: 'normal',
                        color: '#555',
                        textAlign: 'center'
                    }
                },

                // colors: (me.entry.get('colors') !== null && me.entry.get('colors') > 0) ? me.entry.get('colors') : me.defaultColors,

                xAxis: {
                    // alternateGridColor: 'rgba(220, 220, 220, 0.1)',
                    lineWidth: 1,
                    tickLength: 5,
                    // gridLineWidth: 1,
                    // gridLineDashStyle: 'dash',
                    // gridLineColor: '#EEE',
                    tickPixelInterval: isWidget ? 80 : 120,
                    labels: {
                        style: {
                            color: '#777',
                            fontSize: isWidget ? '11px' : '12px',
                            fontWeight: 600
                        },
                        // y: isWidget ? 15 : 20,
                        autoRotation: [-25]
                    },
                    maxPadding: 0,
                    minPadding: 0,
                    events: {
                        // afterSetExtremes: function () {
                        //     // filters the current data grid based on the zoom range
                        //     if (me.getView().up('entry')) {
                        //         me.getView().up('entry').getController().filterData(this.getExtremes().min, this.getExtremes().max);
                        //     }
                        // }
                    }
                },
                yAxis: {
                    allowDecimals: true,
                    min: 0,
                    lineWidth: 1,
                    // gridLineWidth: 1,
                    gridLineDashStyle: 'dash',
                    // gridLineColor: '#EEE',
                    //tickPixelInterval: 50,
                    tickLength: 5,
                    tickWidth: 1,
                    showFirstLabel: false,
                    showLastLabel: true,
                    endOnTick: true,
                    // tickInterval: entry.get('units') === 'percent' ? 20 : undefined,
                    maxPadding: 0,
                    opposite: false,
                    labels: {
                        align: 'right',
                        useHTML: true,
                        padding: 0,
                        style: {
                            color: '#777',
                            fontSize: isWidget ? '11px' : '12px',
                            fontWeight: 600
                        },
                        x: -10,
                        y: 4
                    },
                    title: {
                        align: 'high',
                        offset: -10,
                        y: 3,
                        rotation: 0,
                        textAlign: 'left',
                        style: {
                            color: '#555',
                            fontSize: isWidget ? '12px' : '14px',
                            fontWeight: 600
                        }
                    }
                },
                tooltip: {
                    enabled: true,
                    animation: false,
                    shared: true,
                    followPointer: true,
                    split: false,
                    // distance: 30,
                    padding: 10,
                    hideDelay: 0,
                    backgroundColor: 'rgba(247, 247, 247, 0.95)',
                    useHTML: true,
                    style: {
                        fontSize: isWidget ? '12px' : '14px'
                    },
                    headerFormat: '<p style="margin: 0 0 5px 0; color: #555;">{point.key}</p>'
                },
                plotOptions: {
                    column: {
                        depth: 25,
                        edgeWidth: 1,
                        edgeColor: '#FFF',
                        events: {
                            click: function(event) {
                                // call this way to be able to access viewmodel
                                me.onPointClick(event);
                            }
                        }
                    },
                    areaspline: {
                        lineWidth: 1,
                        events: {
                            click: function(event) {
                                // call this way to be able to access viewmodel
                                me.onPointClick(event);
                            }
                        }
                    },
                    spline: {
                        lineWidth: 2,
                        events: {
                            click: function(event) {
                                // call this way to be able to access viewmodel
                                me.onPointClick(event);
                            }
                        }
                    },
                    pie: {
                        allowPointSelect: false,
                        cursor: 'pointer',
                        center: ['50%', '50%'],
                        showInLegend: true,
                        colorByPoint: true,

                        depth: isWidget ? 25 : 35,
                        minSize: 150,
                        borderWidth: 1,
                        edgeWidth: 1,
                        dataLabels: {
                            enabled: true,
                            distance: 5,
                            padding: 0,
                            reserveSpace: false,
                            formatter: function () {
                                if (this.point.percentage < 2) {
                                    return null;
                                }
                                var name = this.point.name;
                                if (name.length > 25) {
                                    name = name.substring(0, 25) + '...';
                                }
                                return name + ' (' + this.point.percentage.toFixed(2) + '%)';
                            }
                        },
                        events: {
                            click: function(event) {
                                // call this way to be able to access viewmodel
                                me.onPointClick(event);
                            }
                        }
                    },
                    series: {
                        dataLabels: {
                            style: {
                                fontSize: isWidget ? '10px' : '12px'
                            }
                        },
                        animation: true,
                        states: {
                            hover: {
                                lineWidthPlus: 0
                            }
                        },
                        marker: {
                            radius: 2,
                        }
                    }
                },
                legend: {
                    margin: 0,
                    y: isWidget ? 5 : 10,
                    // useHTML: true,
                    lineHeight: 12,
                    itemDistance: 10,
                    itemStyle: {
                        fontSize: '12px',
                        fontWeight: 600,
                        width: '120px',
                        whiteSpace: 'nowrap',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis'
                    },
                    symbolHeight: 8,
                    symbolWidth: 8,
                    symbolRadius: 4
                },
                loading: {
                    style: {
                        opacity: 1
                    }
                },
                series: []
            });
        },

        /**
         * returns the chart type (e.g. line, areaspline, column etc...) based on entry type and style
         */
        getChartType: function (entry) {
            var type;

            if (entry.get('type') === 'TIME_GRAPH' || entry.get('type') === 'TIME_GRAPH_DYNAMIC') {
                switch (entry.get('timeStyle')) {
                case 'LINE':
                    type = 'spline';
                    break;
                case 'AREA':
                case 'AREA_STACKED':
                    type = 'areaspline';
                    break;
                case 'BAR':
                case 'BAR_3D':
                case 'BAR_OVERLAPPED':
                case 'BAR_3D_OVERLAPPED':
                case 'BAR_STACKED':
                    type = 'column';
                    break;
                default:
                    type = 'areaspline';
                }
            }
            if (entry.get('type') === 'PIE_GRAPH') {
                if (entry.get('pieStyle') && entry.get('pieStyle').indexOf('COLUMN') >= 0) {
                    type = 'column';
                } else {
                    type = 'pie';
                }
            }
            return type;
        },

        /**
         * fetches the report data
         */
        fetchData: function (reset, cb) {
            var me = this,
                vm = this.getViewModel(),
                entry = vm.get('eEntry') || vm.get('entry'),
                reps = me.getView().up('#reports'),
                startDate, endDate;

            if (!entry) { return; }

            // disable this reset because it fires second time and may cause browser freeze NGFW-11306
            // if (reset) { me.reset(); }

            vm.set('eError', false);

            if (reps) { reps.getViewModel().set('fetching', true); }

            // date range setup
            if (!me.getView().renderInReports) {
                // if not rendered in reports than treat as widget so from server startDate is extracted the timeframe
                startDate = new Date(Util.getMilliseconds() - (Ung.dashboardSettings.timeframe * 3600 || 3600) * 1000);
                endDate = null;
            } else {
                // if it's a report, convert UI client start date to server date
                startDate = Util.clientToServerDate(vm.get('time.range.since'));
                endDate = Util.clientToServerDate(vm.get('time.range.until'));
            }

            // if (reset) { me.reset(); }
            me.chart.hideNoData();
            me.chart.showLoading('<i class="fa fa-spinner fa-spin fa-fw fa-lg"></i>');

            // get extra selects based on controlling field
            var tableField = null;
            if( ( entry.get('type') === 'TIME_GRAPH') ||
                (entry.get('type') === 'TIME_GRAPH_DYNAMIC') ){
                tableField = TableConfig.getTableField(entry.get('table'), entry.get('timeDataDynamicColumn'));
            }else if(entry.get('type') === 'PIE_GRAPH'){
                tableField = TableConfig.getTableField(entry.get('table'), entry.get('pieGroupColumn'));
            }
            var extraSelects = (tableField && tableField.referenceFields) ? tableField.referenceFields: null;

            var fromType = null;
            if( ( entry.get('type') === 'TIME_GRAPH') ||
                (entry.get('type') === 'TIME_GRAPH_DYNAMIC') ){
                fromType = TableConfig.getFromType(entry.get('table'), entry.get('timeDataDynamicColumn'));
            }else if(entry.get('type') === 'PIE_GRAPH'){
                fromType = TableConfig.getFromType(entry.get('table'), entry.get('pieGroupColumn'));
            }

            Rpc.asyncData('rpc.reportsManager.getDataForReportEntry',
                entry.getData(), // entry
                startDate,
                endDate,
                extraSelects,
                Ung.model.ReportCondition.collect(vm.get('query.conditions')),
                fromType,
                -1) 
                .then(function (result) {
                    if(Util.isDestroyed(me)){
                        return;
                    }
                    me.data = result.list;

                    me.setSeries();
                    if (cb) { cb(me.data); }
                }, function () {
                    if(Util.isDestroyed(vm)){
                        return;
                    }
                    if (cb) { cb(); }
                    vm.set('eError', true);
                })
                .always(function () {
                    if(Util.isDestroyed(me)){
                        return;
                    }
                    if (reps) { reps.getViewModel().set('fetching', false); }
                    if( me.chart.noDataLabel === undefined){
                        me.chart.zoomOut();
                    }
                    me.chart.hideLoading();
                });
        },

        /**
         * used to refresh the chart when it's container size changes
         */
        onResize: function (el, width, height) {
            var me = this;
            // explicitly set size of the chart to avoid cutoffs
            if (me.chart) {
                // me.chart.setSize(width, height, false);
                me.chart.reflow();
            }
        },


        reset: function () {
            var me = this;
            while(me.chart.series.length > 0) {
                me.chart.series[0].remove(true);
            }
            me.chart.update({
                xAxis: { visible: false },
                yAxis: { visible: false },
                legend: {
                    enabled: false
                }
            });
            me.chart.redraw();
            me.chart.zoomOut();
        },

        /**
         * sets the data series for graph reports
         */
        setSeries: function () {
            var me = this, vm = this.getViewModel(), entry = vm.get('eEntry') || vm.get('entry'),
                seriesRenderer = ( entry && entry.get('seriesRenderer') ) ? Renderer[entry.get('seriesRenderer')] : null,
                table = entry.get('table'),
                seriesData,
                seriesName,
                rowRecord = null;

            // remove any existing series
            while (me.chart.series.length > 0) {
                me.chart.series[0].remove(false);
            }

            if (!me.data || (Ext.isArray(me.data) && me.data.length === 0)) {
                me.chart.showNoData('No Data!');
                return;
            }

            if ( entry && ( entry.get('type') === 'TIME_GRAPH' || entry.get('type') === 'TIME_GRAPH_DYNAMIC') ){
                var dataColumns = [], units = entry.get('units');

                // get or generate series names based on timeDataColumns for TIME_GRAPH or data form TIME_GRAPH_DYNAMIC
                if (entry.get('type') === 'TIME_GRAPH') {
                    Ext.Array.each(entry.get('timeDataColumns'), function (column) {
                        dataColumns.push(column.split(' ').splice(-1)[0]);
                    });
                }

                if (entry.get('type') === 'TIME_GRAPH_DYNAMIC') {
                    Ext.Array.each(me.data, function (row) {
                        // rowRecord = new Ext.data.Model(row);
                        Ext.Object.each(row, function (key) {
                            if (row.hasOwnProperty(key) && key !== 'time_trunc' && key !== 'time' && dataColumns.indexOf(key) < 0) {
                                dataColumns.push(key);
                            }
                        });
                    });
                }

                Ext.Array.each(dataColumns, function (column) {
                    // set series data
                    seriesData = [];
                    Ext.Array.each(me.data, function (row) {
                        seriesData.push([
                            ( row.time_trunc && row.time_trunc.time ) || row.time_trunc, // for sqlite is time_trunc, for postgres is time_trunc.time
                            row[column] || 0
                        ]);
                    });
                    // set series name
                    seriesName = column;
                    if (seriesRenderer) {
                        seriesName = seriesRenderer(parseInt(column, 10));
                        if (seriesName.substr(-1) != ']') {
                            seriesName += ' [' + column + ']';
                        }
                    }else{
                        seriesName = column !== undefined ? TableConfig.getDisplayValue(column, table, entry.get('timeDataDynamicColumn')) : 'None'.t();
                    }

                    me.chart.addSeries({
                        name: seriesName,
                        data: seriesData,
                        tooltip: {
                            pointFormatter: function () {
                                var str = '<span style="color: ' + this.color + '; font-weight: bold;">' + this.series.name + '</span>';
                                if (units === 'bytes' || units === 'bytes/s') {
                                    str += ': <b>' + Util.bytesRenderer(this.y) + '</b>';
                                } else {
                                    str += ': <b>' + this.y + '</b> ' + units;
                                }
                                return str + '<br/>';
                            }
                        }
                    }, false, false);
                });
            }

            if (entry && ( entry.get('type') === 'PIE_GRAPH') ){
                var othersValue = 0, colVal, colField; // needed for global conditions from pies which have seriesRendered defined (altered) e.g. protocol
                seriesData = [];

                /** 
                 * NGFW-12881
                 * special treatement for threat prevention reputation range values 
                 * by grouping same reputation hits in a single series (pie slice)
                */
                if (entry.get('pieGroupColumn') === 'threat_prevention_reputation') {
                    var newData = [];
                    /**
                     * helper object to cumulate hits of same reputation
                     * each value key represents the final series options having extra
                     * - disableClickEvent: to avoid showing Add Condition modal
                     * - color: for pie slice based on risk (green -> low to red -> high)
                     * - reputation: unique number set as the highest range, used for data displayed in the Data Table grid
                     */
                    var hits = { 
                        trustworthy: { name: 'Trustworthy', y: 0, color: '#00ac00', disableClickEvent: true, reputation: 100 },
                        low_risk: { name: 'Low Risk', y: 0, color: '#7fd500', disableClickEvent: true, reputation: 80 },
                        moderate_risk: { name: 'Moderate Risk', y: 0, color: '#fff001', disableClickEvent: true, reputation: 60 },
                        suspicious: { name: 'Suspicious', y: 0, color: '#f57e00', disableClickEvent: true, reputation: 40 },
                        high_risk: { name: 'High Risk', y: 0, color: '#f20000', disableClickEvent: true, reputation: 20 }
                    };
                    Ext.Array.each(me.data, function (row, idx) {
                        var reputation = row['threat_prevention_reputation'];
                        // see threat-prevention/js/common/References.js
                        if (reputation >= 81 && reputation <= 100) { hits.trustworthy.y += row.value; }
                        if (reputation >= 61 && reputation <= 80)  { hits.low_risk.y += row.value; }
                        if (reputation >= 41 && reputation <= 60)  { hits.moderate_risk.y += row.value; }
                        if (reputation >= 21 && reputation <= 40)  { hits.suspicious.y += row.value; }
                        if (reputation >= 0 && reputation <= 20)   { hits.high_risk.value += row.value; }
                    });
                    
                    // set series only for those who have hits
                    Ext.Object.each(hits, function (key, hit) {
                        if (hit.y > 0) {
                            seriesData.push(hit);
                        }
                    });

                    /**
                     * debatable
                     * sort by number of hits or leave them order by risk (low to high)
                     */
                    // Ext.Array.sort(seriesData, function (a, b) {
                    //     if (a.y < b.y) { return 1; }
                    //     if (a.y > b.y) { return -1; }
                    //     return 0;
                    // });

                    // process also data which will be shown in side Data Table View
                    var tableData = [];
                    Ext.Array.each(seriesData, function (row) {
                        tableData.push({
                            threat_prevention_reputation: row.reputation, // as number
                            value: row.y
                        });
                    });

                    // apply new data 
                    me.data = tableData;
                } else {
                    Ext.Array.each(me.data, function (row, idx) {
                        colField = entry.get('pieGroupColumn');
                        colVal = row[colField];
                        rowRecord = new Ext.data.Model(row);
    
                        if (seriesRenderer) {
                            seriesName = seriesRenderer(parseInt(colVal, 10));
                        } else {
                            seriesName = !colVal ? 'None'.t() : TableConfig.getDisplayValue(colVal, table, colField, rowRecord);
                        }
    
                        var tableColumn = null;
                        var expandedInformation = {};
                        for(var field in row){
                            if(field == colField){
                                continue;
                            }
                            // below tableColumn seem to be null all the time
                            tableColumn =  TableConfig.getTableColumn(table, field);
                            if(tableColumn && tableColumn.text){
                                expandedInformation[tableColumn.text] = 
                                    TableConfig.getDisplayValue(row[field], table, field, rowRecord);
                            }
                        }
    
                        if (idx < entry.get('pieNumSlices')) {
                            seriesData.push({
                                name: seriesName,
                                value: colVal,
                                y: row.value,
                                expandedInformation: expandedInformation,
                                rowRecord: rowRecord
                            });
                        } else {
                            othersValue += row.value;
                        }
                    });                    
                }

                // add the rest of the values as Others slice
                if (othersValue > 0) {
                    seriesData.push({
                        name: 'Others'.t(),
                        color: '#DDD',
                        y: othersValue
                    });
                }

                me.chart.addSeries({
                    name: entry.get('units').t(),
                    data: seriesData,
                    tooltip: {
                        pointFormatter: function () {
                            var str = "";
                            if(this.series.data[this.index]){
                                for(var field in this.series.data[this.index].expandedInformation){
                                    str += field + ":" + this.series.data[this.index].expandedInformation[field] + "<br/>";
                                }
                            }
                            str += '<span style="color: ' + this.color + '; font-weight: bold;">' + this.series.name + '</span>';
                            if (entry.get('units') === 'bytes' || entry.get('units') === 'bytes/s') {
                                str += ': <b>' + Util.bytesRenderer(this.y) + '</b>';
                            } else {
                                str += ': <b>' + this.y + '</b>';
                            }
                            return str + '<br/>';
                        }
                    }
                }, false, false);
            }
            // me.chart.redraw();
            // reload styles
            me.setStyles();
        },


        /**
         * sets/updates the chart styles based on entry and data
         */
        setStyles: function () {
            var me = this, vm = me.getViewModel(), entry = vm.get('eEntry') || vm.get('entry'), colors,
                isWidget = me.getView().isWidget, plotLines = [],

                isColumnStacked = false, isColumnOverlapped = false,
                isPieColumn = false, isDonut = false, isPie = false, is3d = false;

            if (!entry) { return; }

            // NGFW-11448 - apply 12/24 time format on graphs
            var timeLabelFormats;
            var timestampFormat = Rpc.directData('rpc.translations.timestamp_fmt');
            if (timestampFormat && timestampFormat.indexOf('h:i:s a') >= 0 ) {
                // 12 hours format
                timeLabelFormats = {
                    xAxis: {
                        second: '%l:%M:%S %p',
                        minute: '%l:%M %p',
                        hour: '%l:%M %p',
                        day: '%Y-%m-%d'
                    },
                    tooltip: {
                        second: '%Y-%m-%d, %l:%M:%S %p, %l:%M:%S %p',
                        minute: '%Y-%m-%d, %l:%M %p',
                        hour: '%Y-%m-%d, %l:%M %p',
                        day: '%Y-%m-%d'
                    },
                    dataGrouping: {
                        millisecond: ['%Y-%m-%d, %l:%M:%S %p', '%Y-%m-%d, %l:%M:%S %p', '-%l:%M:%S %p'],
                        second: ['%Y-%m-%d, %l:%M:%S %p', '%Y-%m-%d, %l:%M:%S %p', '-%l:%M:%S %p'],
                        minute: ['%Y-%m-%d, %l:%M %p', '%Y-%m-%d, %l:%M %p', '-%l:%M %p'],
                        hour: ['%Y-%m-%d, %l:%M %p', '%Y-%m-%d, %l:%M %p', '%Y-%m-%d, %l:%M %p'],
                        day: ['%Y-%m-%d']
                    }
                };
            } else {
                // 24 hours format
                timeLabelFormats = {
                    xAxis: {
                        second: '%H:%M:%S',
                        minute: '%H:%M',
                        hour: '%H:%M',
                        day: '%Y-%m-%d'
                    },
                    tooltip: {
                        second: '%Y-%m-%d, %H:%M:%S, %H:%M:%S',
                        minute: '%Y-%m-%d, %H:%M',
                        hour: '%Y-%m-%d, %H:%M',
                        day: '%Y-%m-%d'
                    },
                    dataGrouping: {
                        millisecond: ['%Y-%m-%d, %H:%M:%S', '%Y-%m-%d, %H:%M:%S', '-%H:%M:%S'],
                        second: ['%Y-%m-%d, %H:%M:%S', '%Y-%m-%d, %H:%M:%S', '-%H:%M:%S'],
                        minute: ['%Y-%m-%d, %H:%M', '%Y-%m-%d, %H:%M', '-%H:%M'],
                        hour: ['%Y-%m-%d, %H:%M', '%Y-%m-%d, %H:%M', '%Y-%m-%d, %H:%M'],
                        day: ['%Y-%m-%d']
                    }
                };
            }

            var isPieGraph = entry.get('type') === 'PIE_GRAPH';
            var isTimeGraph = entry.get('type').indexOf('TIME_GRAPH') >= 0;

            if (isTimeGraph) {
                isColumnStacked = entry.get('timeStyle').indexOf('STACKED') >= 0;
                isColumnOverlapped = entry.get('timeStyle').indexOf('OVERLAPPED') >= 0;
            }

            if (isPieGraph) {
                isPieColumn = entry.get('pieStyle').indexOf('COLUMN') >= 0;
                isPie = entry.get('pieStyle').indexOf('COLUMN') < 0;
                isDonut = entry.get('pieStyle').indexOf('DONUT') >= 0;
                is3d = entry.get('pieStyle').indexOf('3D') >= 0;
            }

            if (isWidget) {
                if (Ung.dashboardSettings.theme === 'DEFAULT' && Ext.isArray(entry.get('colors')) && entry.get('colors').length > 0) {
                    colors = Ext.clone(entry.get('colors'));
                } else {
                    colors = Ext.clone(Theme[Ung.dashboardSettings.theme].colors);
                }
            } else {
                if (!entry.get('colors') || entry.get('colors').length === 0) {
                    colors = Ext.clone(Theme.DEFAULT.colors);
                } else {
                    colors = Ext.clone(entry.get('colors'));
                }
            }

            // add gradient
            if ((isPie || isDonut) && !is3d) {
                colors = Highcharts.map( colors, function (color) {
                    return {
                        radialGradient: {
                            cx: 0.5,
                            cy: 0.5,
                            r: 0.7
                        },
                        stops: [
                            [0, Highcharts.Color(color).setOpacity((isWidget && Ung.dashboardSettings.theme === 'DARK') ? 0.9 : 0.4).get('rgba')],
                            [1, Highcharts.Color(color).setOpacity((isWidget && Ung.dashboardSettings.theme === 'DARK') ? 0.3 : 0.8).get('rgba')]
                        ]
                    };
                });
            }

            if (isColumnOverlapped) {
                for (var i = 0; i < colors.length; i += 1) {
                    colors[i] = new Highcharts.Color(colors[i]).setOpacity(0.5).get('rgba');
                }
            }

            if (isTimeGraph) {
                Ext.Array.each(me.chart.series, function (serie, idx) {
                    serie.update({
                        color: colors[idx],
                        lineColor: colors[idx],
                        fillColor: {
                            linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                            stops: [
                                [0, Highcharts.Color(colors[idx]).setOpacity(0.7).get('rgba')],
                                [1, Highcharts.Color(colors[idx]).setOpacity(0.1).get('rgba')]
                            ]
                        },
                        pointPadding: isColumnOverlapped ? 0.1 * idx : 0.1
                    }, false);
                });

                Ext.Array.each(me.data, function (row) {
                    var t;
                    if(row.time_trunc){
                        if(row.time_trunc.time){
                            t = row.time_trunc.time;
                        }else{
                            t = row.time_trunc;
                        }
                    }
                    if (t && t % (24 * 3600 * 1000) === 0) {
                        var d = Util.clientToServerDate(new Date(t));
                        d = Ext.Date.add(d, Ext.Date.MINUTE, d.getTimezoneOffset());
                        plotLines.push({
                            value: d,
                            width: 1,
                            dashStyle: 'Dash',
                            color: isWidget ? (Ung.dashboardSettings.theme !== 'DARK' ? '#EEE' : '#444') : '#EEE',
                            label: {
                                text: Ext.Date.format(d, 'Y-m-d'),
                                y: 15,
                                style: {
                                    fontSize: '12px',
                                    color: '#999'
                                }
                            }
                        });
                    }
                });
            }

            var settings = {
                exporting: {
                    chartOptions: {
                        title: {
                            text: '<span style="color: #999;">' + entry.get('category') + '/</span>' + entry.get('title')
                        },
                        subtitle: {
                            text: entry.get('description')
                        }
                    }
                },
                chart: {
                    type: me.getChartType(entry),
                    zoomType: isTimeGraph ? 'x' : undefined,
                    panning: isTimeGraph,
                    panKey: 'ctrl',
                    options3d: {
                        enabled: is3d,
                        alpha: isPieColumn ? 30 : 50,
                        beta: isPieColumn ? 5 : 0
                    }
                },
                subtitle: {
                    text: null
                },
                colors: colors,
                // scrollbar: {
                //     enabled: isTimeGraph
                // },
                plotOptions: {
                    series: {
                        stacking: isColumnStacked ? 'normal' : undefined
                    },
                    // pie graphs
                    pie: {
                        innerSize: isDonut ? '40%' : 0,
                        colors: colors
                        //borderColor: '#666666'
                    },
                    // time graphs
                    spline: {
                        shadow: true,
                        dataGrouping: {
                            groupPixelWidth: 8,
                            approximation: entry.get('approximation') || 'sum',
                            dateTimeLabelFormats: timeLabelFormats.dataGrouping
                        },
                    },
                    // time graphs
                    areaspline: {
                        // shadow: true,
                        // fillOpacity: 0.3,
                        dataGrouping: {
                            groupPixelWidth: 8,
                            approximation: entry.get('approximation') || 'sum',
                            dateTimeLabelFormats: timeLabelFormats.dataGrouping
                        },
                    },
                    column: {
                        borderWidth: isColumnOverlapped ? 1 : 0,
                        pointPlacement: isTimeGraph ? 'on' : null, // time
                        // pointPadding: 0.01,
                        colorByPoint: isPieColumn, // pie
                        grouping: !isColumnOverlapped,
                        groupPadding: isColumnOverlapped ? 0.1 : 0.15,
                        // shadow: !isColumnOverlapped,
                        dataGrouping: isTimeGraph ? 50 : undefined
                    }
                },
                xAxis: {
                    visible: !isPie,
                    minRange: !isPieColumn ? 10 * 60 * 1000 : undefined, // minzoom = 10 minutes
                    // tickPixelInterval: 50,
                    type: isTimeGraph ? 'datetime' : 'category',
                    crosshair: isTimeGraph ? {
                        width: 1,
                        dashStyle: 'ShortDot'
                    } : false,
                    plotLines: plotLines,
                    dateTimeLabelFormats: timeLabelFormats.xAxis
                },
                yAxis: {
                    visible: !isPie,
                    minRange: entry.get('units') === 'percent' ? 100 : 1,
                    maxRange: entry.get('units') === 'percent' ? 100 : undefined,
                    labels: {
                        formatter: function() {
                            var finalVal = this.value;

                            if (entry.get('units') === 'bytes' || entry.get('units') === 'bytes/s') {
                                finalVal = Util.bytesToHumanReadable(this.value, true);
                                /*
                                if (this.isLast) {
                                    return '<span style="color: #555; font-size: 12px;"><strong>' + finalVal + '</strong> (per second)</span>';
                                }
                                */
                            } else {
                                /*
                                if (this.isLast) {
                                    return '<span style="color: #555; font-size: 12px;"><strong>' + this.value + '</strong> (' + entry.get('units') + ')</span>';
                                }
                                */
                            }
                            return finalVal;
                        }
                    },
                    title: {
                        text: entry.get('units')
                    }
                },
                legend: {
                    title: {
                        text: (!isWidget && isPie && isPieGraph) ? (TableConfig.getColumnHumanReadableName(entry.get('pieGroupColumn')) + '<br/> <span style="font-size: 12px;">[' + entry.get('pieGroupColumn') + '] by ' + entry.get('units') + '</span>') : null,
                        style: { fontSize: '18px', fontWeight: 400 }
                    },
                    enabled: !(isWidget && isPieGraph),
                    layout: (isPieGraph && isPie) ? 'vertical' : 'horizontal',
                    align: (isPieGraph && isPie) ? 'left' : 'center',
                    verticalAlign: (isPieGraph && isPie) ? 'top' : 'bottom'
                },
                tooltip: {
                    split: ((isWidget && me.chart.series.length <= 3) || !isWidget) && isTimeGraph,
                    dateTimeLabelFormats: timeLabelFormats.tooltip
                }
            };

            Highcharts.merge(true, settings, isWidget ? Theme[Ung.dashboardSettings.theme] : Theme.DEFAULT);
            me.chart.update(settings, true);

            // force redraw for column charts, NGFW-11349
            if (isPieColumn) { me.chart.redraw(); }
        },

        onPointClick: function (event) {
            var me = this, vm = me.getViewModel(),
                entry = vm.get('entry'),
                value = event.point.value;

            /**
             * for Threat Prevention reputation pie charts disable click
             * because the point value cannot represent a range of values
             * NGFW-12881
             */
            if (event.point.disableClickEvent) {
                return;
            }

            var rowRecord = null;
            if(event.point.rowRecord){
                rowRecord = event.point.rowRecord;
                Ext.fireEvent('addglobalcondition', entry.get('table'), rowRecord);
            }else if(value == undefined && event.point.series && event.point.series.name){
                var values = TableConfig.getValues(entry.get('table'), entry.get('timeDataDynamicColumn'));
                if(values.length){
                    Ext.Array.forEach(values, function(valueSet){
                        if(valueSet[1] == event.point.series.name){
                            value = valueSet[0];
                        }
                    });
                }else{
                    value = event.point.series.name;
                    
                    // We render these values either as-is (e.g.,"value") or with "human" label and the 
                    // value inside square brackets (e.g.,"value [2]").  If we see brackets in the name, 
                    // assume that to be the actual value to use for database queries to add to conditions and such.
                    if (value.includes('[') && value.includes(']') && value.indexOf('[') < value.indexOf(']')) {
                        value = value.split('[')[1].split(']')[0];
                    }
                }
                Ext.fireEvent('addglobalcondition', entry.get('table'), entry.get('timeDataDynamicColumn'), value);
            }
        }
    }
});
Ext.define('Ung.view.reports.Main', {
    extend: 'Ext.panel.Panel',
    xtype: 'ung.reports',
    itemId: 'reports',

    layout: 'card',

    controller: 'reports',

    viewModel: {
        data: {
            context: null,
            fetching: false,
            selection: null,
            editing: false,
            query: {}
        },
        formulas: {
            conditionsText: function (get) {
                var conds = get('query.conditions'), html = [];
                Ext.Array.each(conds, function (cond) {
                    html.push(TableConfig.getColumnHumanReadableName(cond.get('column')) + ' ' + cond.get('operator') + ' ' + cond.get('value'));
                });
                if (html.length === 0) { return; }
                return 'Reports for: ' + html.join(', ');
            }
        }
    },

    border: false,

    items: [{
        /**
         * component shown just when loading directly reports route
         * aftre route is loaded component is removed
         */
        itemId: 'loader',
        xtype: 'container',
        layout: 'center',
        items: [{
            xtype: 'component',
            html: '<i class="fa fa-spinner fa-spin fa-lg"></i>'
        }]
    }, {/**
         * component active when Reports App is not installed or disabled
         */
        itemId: 'noreports',
        xtype: 'noreports',
    }, {
        /**
         * the actual reports view
         */
        layout: 'border',
        dockedItems: [{
            // Global Conditions & Timerange
            xtype: 'toolbar',
            dock: 'top',
            ui: 'footer',
            style: { background: '#D8D8D8' },
            items: [{
                xtype: 'globalconditions'
            }, {
                xtype: 'timeconditions',
                reference: 'time'
            }]
        }, {
            // Breadcrumbs
            xtype: 'toolbar',
            dock: 'top',
            style: {
                zIndex: 9997
            },

            padding: 5,
            plugins: 'responsive',
            items: [{
                xtype: 'breadcrumb',
                reference: 'breadcrumb',
                store: 'reportstree',
                useSplitButtons: false,
                listeners: {
                    selectionchange: 'onSelectReport'
                }
            }],
            responsiveConfig: {
                'width >= 800': { hidden: true },
                'width < 800': { hidden: false }
            }
        }],

        items: [{
            /**
             * the reports tree
             */
            xtype: 'treepanel',
            reference: 'tree',
            width: 250,
            region: 'west',
            split: true,
            border: false,
            bodyBorder: false,
            singleExpand: true,
            useArrows: true,
            rootVisible: false,
            plugins: 'responsive',
            store: 'reportstree',

            // comment out so it does not affect the responsiveConfig
            // bind: {
            //     width: '{editing ? 0 : 250}'
            // },

            viewConfig: {
                selectionModel: {
                    type: 'treemodel',
                    pruneRemoved: false
                },
                getRowClass: function(node) {
                    if (node.get('disabled')) {
                        return 'disabled';
                    }
                }
            },

            dockedItems: [{
                xtype: 'toolbar',
                dock: 'bottom',
                ui: 'footer',
                items: [{
                    xtype: 'textfield',
                    emptyText: 'Filter reports ...',
                    enableKeyEvents: true,
                    flex: 1,
                    triggers: {
                        clear: {
                            cls: 'x-form-clear-trigger',
                            hidden: true,
                            handler: 'onTreeFilterClear'
                        }
                    },
                    listeners: {
                        change: 'filterTree',
                        buffer: 100
                    }
                }, {
                    xtype: 'button',
                    iconCls: 'fa fa-plus-circle',
                    text: 'Add/Import'.t(),
                    hidden: true,
                    bind: {
                        hidden: '{context !== "ADMIN"}'
                    },
                    menu: {
                        plain: true,
                        mouseLeaveDelay: 0,
                        items: [{
                            text: 'Create New'.t(),
                            iconCls: 'fa fa-plus fa-lg',
                            handler: 'newReport'
                        }, {
                            text: 'Import'.t(),
                            iconCls: 'fa fa-download',
                            handler: 'newImport'
                        }]
                    }
                }]
            }],

            columns: [{
                xtype: 'treecolumn',
                flex: 1,
                dataIndex: 'text',
                // scope: 'controller',
                renderer: 'treeNavNodeRenderer'
            }],

            listeners: {
                // prevent node selection if disabled
                beforeselect: function (el, node) {
                    if (node.get('disabled')) { return false; }
                },
                // prevent node expand if disabled
                beforeitemexpand: function (node) {
                    if (node.get('disabled')) { return false; }
                },
                select: 'onSelectReport'
            },

            responsiveConfig: {
                'width >= 800': { width: 250 },
                'width < 800': { width: 0 }
            }
        }, {
            /**
             * the reports rendering component
             */
            region: 'center',
            itemId: 'cards',
            reference: 'cards',
            border: false,
            bodyBorder: false,
            layout: 'card',
            cls: 'reports-all',
            defaults: {
                border: false,
                bodyBorder: false
            },
            items: [{
                itemId: 'category',
                layout: { type: 'vbox', align: 'middle' },
                items: [{
                    xtype: 'component',
                    padding: '20px 0',
                    cls: 'charts-bar',
                    html: '<i class="fa fa-area-chart fa-2x"></i>' +
                        '<i class="fa fa-line-chart fa-2x"></i>' +
                        '<i class="fa fa-pie-chart fa-2x"></i>' +
                        '<i class="fa fa-bar-chart fa-2x"></i>' +
                        '<i class="fa fa-list-ul fa-2x"></i>' +
                        '<i class="fa fa-align-left fa-2x"></i>'
                }, {
                    xtype: 'component',
                    margin: '0 0 20 0',
                    bind: {
                        html: '{conditionsText}'
                    }
                }, {
                    xtype: 'container',
                    cls: 'stats',
                    layout: { type: 'hbox', pack: 'center' },
                    defaults: {
                        xtype: 'component',
                        cls: 'stat'
                    },
                    items: [{
                        hidden: true,
                        bind: {
                            hidden: '{selection}',
                            html: '<h1>{stats.categories.total}</h1>categories <p><span>{stats.categories.app} apps</span></p>'
                        }
                    }, {
                        hidden: true,
                        bind: {
                            hidden: '{!selection}',
                            html: '<img src="{selection.icon}"><br/> {selection.text}'
                        }
                    }, {
                        bind: {
                            html: '<h1>{stats.reports.total}</h1>reports' +
                                '<p><span>{stats.reports.chart} charts</span><br/>' +
                                '<span>{stats.reports.event} event lists</span><br/>' +
                                '<span>{stats.reports.info} summaries</span><br/>' +
                                '<span>{stats.reports.custom} custom reports</span></p>'

                        }
                    }]
                }, {
                    xtype: 'component',
                    cls: 'pls',
                    html: 'select a report from a category',
                    bind: {
                        html: 'select a report from {selection.text || "a category"}'
                    }
                }, {
                    xtype: 'button',
                    iconCls: 'fa fa-external-link-square fa-lg',
                    margin: 20,
                    scale: 'medium',
                    handler: 'exportCategoryReports',
                    text: 'Export All Reports'.t(),
                    hidden: true,
                    bind: {
                        text: 'Export All'.t() + ' <strong>{selection.text}</strong> ' + 'Reports'.t(),
                        hidden: '{context !== "ADMIN"}'
                    }
                }]
            }, {
                xtype: 'entry',
                itemId: 'report'
            }]
        }]
    }]
});
Ext.define('Ung.view.reports.MainController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.reports',

    control: {
        '#': {
            deactivate: 'resetView'
        }
    },

    listen: {
        global: {
            initialload: 'onInitialLoad'
        }
    },

    onInitialLoad: function () {
        var me = this, vm = me.getViewModel(),
            view = me.getView(),
            tree = me.lookup('tree');

        Map.init(); // init map

        // me.getView().setLoading(false);
        // set the reports view context (ADMIN or REPORTS)
        vm.set('context', Ung.app.context);
        me.buildTablesStore();

        /**
         * When Reports App is installed/removed or enabled/disabled
         * show appropriate card
         */
        vm.bind('{reportsAppStatus}', function (status) {
            if(Util.isDestroyed(me, view)){
                return;
            }
            view.remove(view.down('#loader'));
            if (status.installed && status.enabled) {
                view.getLayout().setActiveItem(1);
                me.buildStats();
            } else {
                view.getLayout().setActiveItem(0);
            }
        });

        /**
         * While fetching report data show loading indicators
         */
        vm.bind('{fetching}', function (val) {
            if (!val) { Ext.MessageBox.hide(); } // hide any loading message box
        });


        /**
         * When query route changes select report path
         */
        vm.bind('{query.route}', function (route) {
            if(Util.isDestroyed(me)){
                return;
            }
            var path = (route.cat || '') + (route.rep ? ('/' + route.rep) : '');
            if (!path) {
                tree.collapseAll();
                tree.setSelection(null);
                me.showNode(tree.getStore().getRoot());
            }

            me.lookup('tree').selectPath(path, 'slug', '/', function (success, lastNode) {
                if (!success) {
                    if (!success) {
                        // the route do not match any cat/report selection
                        if (path !== '') { Ext.fireEvent('invalidquery'); }
                        return;
                    }
                }
                if (!lastNode.isLeaf()) {
                    lastNode.expand();
                }
            }, me);
        });

        /**
         * When conditions query string changes,
         * enable/disable reports tree nodes for which conditions do not apply
         */
        vm.bind('{query.conditions}', function (conditions) {
            if(Util.isDestroyed(me)){
                return;
            }
            var root = Ext.getStore('reportstree').getRoot(), disabledCategory;

            root.eachChild(function (catNode) {
                disabledCategory = true;
                catNode.eachChild(function (repNode) { // report node
                    if (conditions.length > 0) {
                        if (TableConfig.containsColumns(
                                repNode.get('table'),
                                Ext.Array.map(conditions, function(condition){
                                    return condition.get('column');
                                })
                            )) {
                            repNode.set('disabled', false);
                            disabledCategory = false;
                        } else {
                            repNode.set('disabled', true);
                        }
                    } else {
                        repNode.set('disabled', false);
                        disabledCategory = false;
                    }
                });
                catNode.set('disabled', disabledCategory);
            });
            me.buildStats();
        });
    },

    /**
     * Redirects (updates route) based on selected reports tree node or breadcrumb node
     */
    onSelectReport: function (el, node) {
        var me = this, vm = me.getViewModel();

        if (!node.get('url')) { return; }

        var url = "";
        if (Ung.app.context !== 'REPORTS') {
            url += "#reports?";
        }
        Ung.app.redirectTo(
            url + node.get('url') +
            Ung.model.ReportCondition.getAllQueries(vm.get('query.conditions'))
        );

        me.showNode(node);
    },

    /**
     * Adds table confinguration to the view model,
     * and it's used in editing report settings
     */
    buildTablesStore: function () {
        if (!rpc.reportsManager) { return; }
        var me = this, vm = me.getViewModel();
        Rpc.asyncData('rpc.reportsManager.getTables').then(function (result) {
            vm.set('tables', result);
        });
    },

    /**
     * Applies node selection to the entry
     */
    showNode: function (node) {
        var me = this, record;

        me.getViewModel().set('selection', node.isRoot() ? null : node);

        if (node.isLeaf()) {
            // report node
            record = Ext.getStore('reports').findRecord('url', node.get('url'), 0, false, true, true);
            if (record) {
                me.getView().down('entry').getViewModel().set({
                    entry: record
                });
            }
            me.lookup('cards').setActiveItem('report');
        } else {
            me.lookup('cards').setActiveItem('category');
            // me.buildStats(node);
            node.expand();
        }
    },


    /**
     * Tree item renderer used after filtering tree
     */
    treeNavNodeRenderer: function(value) {
        return this.rendererRegExp ? value.replace(this.rendererRegExp, '<span style="font-weight: bold; background: #EEE; color: #000; border-bottom: 1px #000 solid;">$1</span>') : value;
    },

    /**
     * Filters the tree
     */
    filterTree: function (field, value) {
        var me = this, tree = me.lookup('tree');
        me.rendererRegExp = new RegExp('(' + value + ')', 'gi');

        if (!value) {
            tree.getStore().clearFilter();
            tree.collapseAll();
            field.getTrigger('clear').hide();
            return;
        }

        tree.getStore().getFilters().replaceAll({
            property: 'text',
            value: new RegExp(Ext.String.escape(value), 'i')
        });
        tree.expandAll();
        field.getTrigger('clear').show();
    },

    onTreeFilterClear: function () {
        this.lookup('tree').down('textfield').setValue();
    },

    /**
     * Resets the view to an initial state
     */
    resetView: function () {
        var me = this, tree = me.lookup('tree'), breadcrumb = me.lookup('breadcrumb');
        tree.collapseAll();
        tree.getSelectionModel().deselectAll();
        tree.getStore().clearFilter();
        tree.down('textfield').setValue('');

        breadcrumb.setSelection('root');

        if (me.getViewModel().get('hash') !== 'create') {
            me.buildStats();
            me.lookup('cards').setActiveItem('category');
            me.getViewModel().set('selection', null);
            me.getViewModel().set('hash', null);
        }
    },

    /**
     * Builds statistics for categories, based on global conditions
     */
    buildStats: function () {
        var me = this, vm = me.getViewModel(),
            node = vm.get('selection'),
            stats = {
                set: false,
                reports: {
                    total: 0,
                    custom: 0,
                    chart: 0,
                    event: 0,
                    info: 0
                },
                categories: {
                    total: 0,
                    app: 0
                }
            };

        if (!node) { node = Ext.getStore('reportstree').getRoot(); }

        node.cascade(function (n) {
            if (n.isRoot() || n.get('disabled')) { return; }
            if (n.isLeaf()) {
                stats.reports.total += 1;
                if (!n.get('readOnly')) { stats.reports.custom += 1; }
                switch(n.get('type')) {
                case 'TIME_GRAPH':
                case 'TIME_GRAPH_DYNAMIC':
                case 'PIE_GRAPH':
                    stats.reports.chart += 1; break;
                case 'EVENT_LIST':
                    stats.reports.event += 1; break;
                case 'TEXT':
                    stats.reports.info += 1; break;
                }
            } else {
                stats.categories.total += 1;
                if (n.get('type') === 'app') {
                    stats.categories.app += 1;
                }
            }
        });
        vm.set('stats', stats);
    },

    // get the entry controller and edit a new blank entry
    newReport: function () {
        var me = this, entryCtrl = me.getView().down('entry').getController();
        if (entryCtrl) {
            entryCtrl.editEntry(true); // true = new report entry
            // activate the report card if not yet activated
            me.lookup('cards').setActiveItem('report');
        }
    },

    // show import dialog on import
    newImport: function () {
        var me = this;
        var dialog = me.getView().add({
            xtype: 'importdialog'
        });
        dialog.show();
    },

    // exports categories
    exportCategoryReports: function () {
        var me = this, vm = me.getViewModel(), reportsArr = [], category, reports;

        if (vm.get('selection')) {
            category = vm.get('selection.text'); // selected category
            reports = Ext.getStore('reports').query('category', category, false, true, true);
        } else {
            // export all
            reports = Ext.getStore('reports').getData();
        }

        Ext.Array.each(reports.items, function (report) {
            var rep = report.getData();
            // remove extra custom fields
            delete rep._id;
            delete rep.localizedTitle;
            delete rep.localizedDescription;
            delete rep.slug;
            delete rep.categorySlug;
            delete rep.url;
            delete rep.icon;
            reportsArr.push(rep);
        });

        Ext.MessageBox.wait('Exporting Settings...'.t(), 'Please wait'.t());
        var exportForm = document.getElementById('exportGridSettings');
        exportForm.gridName.value = 'AllReports'.t() + (category ? '_' + category.replace(/ /g, '_') : ''); // used in exported file name
        exportForm.gridData.value = Ext.encode(reportsArr);
        exportForm.submit();
        Ext.MessageBox.hide();
    }


});
/**
 * This shows when Reports App is not installed or is disabled
 * From here user can install or enable the Reports App
 */
Ext.define('Ung.view.reports.NoReports', {
    extend: 'Ext.container.Container',
    alias: 'widget.noreports',

    layout: {
        type: 'vbox',
        align: 'middle'
    },

    margin: 20,
    items: [{
        xtype: 'component',
        style: {
            textAlign: 'center',
            color: '#555',
            fontFamily: '"Roboto Condensed", sans-serif',
        },
        padding: 20,
        bind: {
            html: '<img src="/icons/apps/reports.svg" width=150 height=150/> <br/><br/> <h1 style="font-weight: 100;">' +
                  '{!reportsAppStatus.installed ? "' + 'Reports App is not installed!'.t() + '" : "' + 'Reports App is disabled!'.t() + '"}'.t() +
                  '</h1>'
        }
    }, {
        xtype: 'button',
        scale: 'medium',
        focusable: false,
        iconCls: 'fa fa-download fa-lg',
        text: '<strong>' + 'Install Reports'.t() + '</strong>',
        handler: 'installReports',
        hidden: true,
        bind: { hidden: '{reportsAppStatus.installed}' }
    }, {
        xtype: 'button',
        scale: 'medium',
        focusable: false,
        iconCls: 'fa fa-check fa-lg',
        text: '<strong>' + 'Enable Reports'.t() + '</strong>',
        handler: 'enableReports',
        hidden: true,
        bind: { hidden: '{!reportsAppStatus.installed || reportsAppStatus.enabled}' }
    }, {
        xtype: 'component',
        itemId: 'wait',
        style: {
            textAlign: 'center'
        },
        html: '<i class="fa fa-spinner fa-spin fa-lg"></i> <br/><br/> Please wait ...',
        hidden: true
    }],

    controller: {
        installReports: function (btn) {
            var wait = this.getView().down('#wait');

            btn.setHidden(true);
            wait.setHidden(false);
            Rpc.asyncData('rpc.appManager.instantiate', 'reports')
                .then(function (result, ex) {
                    if (ex) {
                        Ext.Msg.alert('Error', ex.message);
                        return;
                    }
                    if(Util.isDestroyed(wait)){
                        return;
                    }

                    Ung.app.reportscheck();

                    // refresh apps
                    rpc.appsViews = rpc.appManager.getAppsViews();
                    Ext.getStore('policies').loadData(rpc.appsViews);
                    Ung.app.getGlobalController().getAppsView().getController().getApps();

                    wait.setHidden(true);

                });
        },

        enableReports: function (btn) {
            var wait = this.getView().down('#wait'),
                appManager = rpc.appManager.app('reports');
            btn.setHidden(true);
            wait.setHidden(false);

            var runStateWantState = 'RUNNING',
                runStateWait = 10000,
                runStateDelay = 100,
                runStateTask = null;

            runStateTask = new Ext.util.DelayedTask(function() {
                appManager.getRunState(function (result, ex) {
                    if (ex) {
                        Util.handleException(ex);
                        return false;
                    }
                    if(Util.isDestroyed(wait)){
                        return;
                    }
                    runStateWait = runStateWait - runStateDelay;
                    if (result !== runStateWantState){
                        runStateTask.delay(runStateDelay);
                    } else {
                        Ung.app.reportscheck();

                        // refresh apps
                        rpc.appsViews = rpc.appManager.getAppsViews();
                        Ext.getStore('policies').loadData(rpc.appsViews);
                        Ung.app.getGlobalController().getAppsView().getController().getApps();

                        wait.setHidden(true);
                    }
                });
            });

            appManager.start(function (result, ex) {
                if (ex) {
                    Ext.Msg.alert('Error', ex.message);
                    runStateWantState = 'INITIALIZED';
                    runStateTask.delay(runStateDelay);
                    return;
                }
                runStateTask.delay( this.runStateDelay );
            });
        }
    }
});
Ext.define('Ung.view.reports.TextReport', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.textreport',

    viewModel: true,

    border: false,
    bodyBorder: false,

    padding: '50 10',

    bodyStyle: {
        fontFamily: 'Roboto Condensed, Arial, sans-serif',
        textAlign: 'center',
        fontSize: '16px'
    },

    config: {
        widget: null
    },

    controller: {
        control: {
            '#': {
                afterrender: 'onAfterRender',
                deactivate: 'onDeactivate'
            }
        },

        onAfterRender: function (view) {
            var me = this, vm = this.getViewModel();

            // find and set the widget component if report is rendered inside a widget
            view.setWidget(view.up('reportwidget'));

            // if it's a widget, than fetch data after the report entry is binded to it
            vm.bind('{entry}', function (entry) {
                if(Util.isDestroyed(view)){
                    return;
                }
                if (!entry || entry.get('type') !== 'TEXT') { 
                    return; 
                }

                // if rendered in creating new widget dialog, fetch data
                if (view.up('new-widget')) {
                    me.fetchData(true);
                }
            });
            
            // needed on Create New

            // vm.bind('{eEntry.type}', function (type) {
            //     if (type !== 'TEXT') { return; }
            //     Ext.defer(function () {
            //         me.fetchData(true);
            //     }, 300);
            // });

        },

        onDeactivate: function () {
            this.getView().setHtml('');
        },

        fetchData: function (reset, cb) {
            var me = this, vm = this.getViewModel(), reps = me.getView().up('#reports'), startDate, endDate;
            var entry = vm.get('eEntry') || vm.get('entry');

            if (reps) { reps.getViewModel().set('fetching', true); }

            // date range setup
            if (!me.getView().renderInReports) {
                // if not rendered in reports than treat as widget so from server startDate is extracted the timeframe
                startDate = new Date(Util.getMilliseconds() - (Ung.dashboardSettings.timeframe * 3600 || 3600) * 1000);
                endDate = null;
            } else {
                // if it's a report, convert UI client start date to server date
                startDate = Util.clientToServerDate(vm.get('time.range.since'));
                endDate = Util.clientToServerDate(vm.get('time.range.until'));
            }

            me.getView().setLoading(true);
            Rpc.asyncData('rpc.reportsManager.getDataForReportEntry',
                entry.getData(), // entry
                startDate,
                endDate,
                null,
                Ung.model.ReportCondition.collect(vm.get('query.conditions')),
                null,
                -1)
                .then(function(result) {
                    if(Util.isDestroyed(me)){
                        return;
                    }
                    me.getView().setLoading(false);
                    if (reps) { reps.getViewModel().set('fetching', false); }
                    me.processData(result.list);

                    if (cb) { cb(result.list); }

                }, function () {
                    if (cb) { cb(); }
                })
                .always(function() {
                    if(Util.isDestroyed(me)){
                        return;
                    }
                    me.getView().setLoading(false);
                    if (reps) { reps.getViewModel().set('fetching', false); }
                });
        },

        processData: function (data) {

            var v = this.getView(),
                vm = this.getViewModel(),
                entry = vm.get('eEntry') || vm.get('entry'),
                textColumns = entry.get('textColumns'), columnName, values = [];

            if (data.length > 0 && textColumns && textColumns.length > 0) {
                Ext.Array.each(textColumns, function (column) {
                    columnName = column.split(' ').splice(-1)[0];
                    values.push(data[0][columnName] || 0);
                });

                v.setHtml(Ext.String.format.apply(Ext.String.format, [entry.get('textString')].concat(values)));
                // todo: send data to the datagrid for TEXT report
            }
        }
    }
});
