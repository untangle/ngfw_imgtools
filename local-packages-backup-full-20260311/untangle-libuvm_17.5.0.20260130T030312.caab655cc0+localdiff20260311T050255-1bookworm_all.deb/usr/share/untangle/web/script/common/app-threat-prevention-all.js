Ext.define('Ung.common.Converter.threatprevention', {
    singleton: true,

    reason: function (v) { return Map.webReasons[v] || 'no rule applied'.t(); },

    ruleIdMap: {},
    ruleId: function (value, record) {
        if (value == 0) {
            return '';
        }
        var policyId = record && record.get && record.get('policy_id') ? record.get('policy_id') : 1;
        var reason = record && record.get && record.get('threat_prevention_reason') ? record.get('threat_prevention_reason') : 'N';
        if(reason != 'N'){
            for(var id in Map.webReasons){
                if(Map.webReasons.hasOwnProperty(id)){
                    if(Map.webReasons[id] == reason){
                        reason = id;
                        if(reason == 'default'){
                            reason = 'N';
                        }
                        break;
                    }
                }
            }
        }
        if(!Ung.common.Renderer.threatprevention.ruleIdMap[policyId] ||
            !Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason] ||
            (value != Renderer.listKey && !(value in Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason]))){
            if(!Ung.common.Renderer.threatprevention.ruleIdMap[policyId]){
                Ung.common.Renderer.threatprevention.ruleIdMap[policyId] = {};
            }
            if(!Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason]){
                Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason] = {};
            }

            var ruleInfo = Renderer.getReportInfo(record, ["threat-prevention"], reason == 'I' ? "passSites" : "rules");
            if(ruleInfo){
                ruleInfo.forEach( function(rule){
                    Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason][rule["id"] ? rule["id"] : rule["ruleId"]] = rule["description"] ? rule["description"] : rule["string"];
                });
            }
            if(!(value in Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason]) && (value != Renderer.listKey)){
                // If category cannot be found, don't just keep coming back for more.
                Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason][value] = 'Unknown'.t();
            }
        }
        if (value == Renderer.listKey) {
            return Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason] + ' [' + value + ']';
        } else {
            return Ung.common.Renderer.threatprevention.ruleIdMap[policyId][reason][value] + ' [' + value + ']';
        }
    },

    categoryMap:{
        0: 'Spam Sources'.t(),
        1: 'Windows Exploits'.t(),
        2: 'Web Attacks'.t(),
        3: 'Botnets'.t(),
        4: 'Scanners'.t(),
        5: 'Denial of Service'.t(),
        6: 'Reputation'.t(),
        7: 'Phishing'.t(),
        8: 'Proxy'.t(),
        11: 'Mobile Threats'.t(),
        13: 'Tor Proxy'.t(),
        16: 'Keyloggers'.t(),
        17: 'Malware'.t(),
        18: 'Spyware'.t()
    },
    category: function(value){
        if (value == 0){
            return '';
        }
        var descriptions = [];
        var threatBits = Object.keys(Ung.common.Renderer.threatprevention.categoryMap);
        for(var i = 0; i < threatBits.length; i++){
            if(Math.pow(2,threatBits[i]) & value){
                descriptions.push(Ung.common.Renderer.threatprevention.categoryMap[threatBits[i]]);
            }
        }
        return descriptions.join(', ');
    },

    /**
     * converts the reputation value to readable string
     * @param {int} value - the reputation score
     */
    reputation: function(value) {
        return value ? Ung.common.threatprevention.references.getReputationLevel(value).get('description') : '';
    },
});
Ext.define('Ung.common.threatprevention.references', {
    singleton: true,

    reputations: Ext.create('Ext.data.ArrayStore', {
        fields: [ 'color', 'rangeBegin', 'rangeEnd', 'description', 'details' ],
        sorters: [{
            property: 'rangeBegin',
            direction: 'DESC'
        }],
        data: [
        [ '408740', 81, 100, 'Trustworthy'.t(), 'These are clean IPs that have not been tied to a security risk. There is a very low predictive risk that your infrastructure and endpoints will be exposed to attack.'.t() ],
        [ '68af68', 61, 80, 'Low Risk'.t(), 'These are benign IPs and rarely exhibit characteristics that expose your infrastructure and endpoints to security risks. There is a low predictive risk of attack.'.t() ],
        [ 'ff9a22', 41, 60, 'Moderate Risk'.t(), 'These are generally benign IPs, but have exhibited some potential risk characteristics. There is some predictive risk that these IPs will deliver attacks to our infrastructure and endpoints.'.t() ],
        [ 'e8580c', 21, 40, 'Suspicious'.t(), 'These are suspicious IPs. There is a higher than average predictive risk that these IPs will deliver attacks to your infrastructure and endpoints.'.t() ],
        [ 'e51313', 1,  20, 'High Risk'.t(), 'These are high risk IP addresses. There is a high predictive risk that these IPs will deliver attacks - such as malicious payloads, DoS attacks, or others - to your infrastructure and endpoints.'.t() ],
        ]
    }),

    reputationRenderer: function(value, meta, record){
        return Ext.String.format("{0} ({1})".t(), record.get('description'), record.get('details'));
    },

    reputatationConditionValues: function(){
        values = [];
        Ung.common.threatprevention.references.reputations.each(function(record){
            values.push([
                record.get('rangeBegin') + '-' + record.get('rangeEnd'),
                record.get('description'),
                record.get('details')
            ]);
        });
        return values;
    },

    /**
     * getReputationLevel returns the reputation store item record within the Reputation Score's level range
     * 
     * @param {int} repScore - The reputation score
     * @returns {reputations store item} - The reputation store item
     */
    getReputationLevel: function(repScore) {
        var repLevel = null;

        Ung.common.threatprevention.references.reputations.each(function(record){
            if(repScore >= record.get('rangeBegin') && repScore <= record.get('rangeEnd')) {
                repLevel = record;
            }
        });

        return repLevel;
    },

    // Move to renders
    threats: Ext.create('Ext.data.ArrayStore', {
        fields: [ 'bit', 'description', 'details' ],
        sorters: [{
            property: 'bit',
            direction: 'ASC'
        }],
        data: [
            // ["0", 'Any'.t(), 'Any threat'.t()],
            ["1", 'Spam Sources'.t(), 'IP addresses from rogue SMTP server connection attempts, anomalous mail activity detected on network sensors, and IPs correlated with known email and forum spammers.'.t() ],
            ["2", 'Windows Exploits'.t(), 'IP addresses participating in distribution of malware or malware attacks, protocol exploits, recorded login attempts, information stealing and other advanced or nefarious shell code, rootkits, worms or virus-related activity.'.t() ],
            ["3", 'Web Attacks'.t(), 'IP addresses using cross-site scripting, iFrame injection, SQL injection, cross-domain injection, domain password brute force attacks to target vulnerabilities on a web server, and malicious automated web activity.'.t()],
            ["4", 'Botnets'.t(), 'IP addresses acting as botnet Command and Control (C&C) centers, infected zombie machines controlled by the C&C servers, botnet hosts distributing malware, cobalt beacons, suspicious fast flux activity, and ransomware reported C&C.'.t() ],
            ["5", 'Scanners'.t(), 'IP addresses involved in unauthorized reconnaissance activities such as probing, host scanning, port scanning, and brute force login attempts, as well as repetitive and suspicious programmatic behavior observed in regular time intervals.'.t() ],
            ["6", 'Denial of Service'.t(), 'Scanners category includes all reconnaissance such as probes, host scan, domain scan and password brute force attack.'.t() ],
            ["7", 'Reputation'.t(), 'IP addresses with a low Reputation Index score. IP addresses in this category have a higher than average risk of hosting and/or distributing malicious content or files.'.t() ],
            ["8", 'Phishing'.t(), 'IP addresses that are hosting phishing sites or initiating suspicious entrapment activities through malicious ads, web email POST forms, and click fraud.'.t() ],
            ["9", 'Proxy'.t(), 'IP addresses offering anonymization services, as well as those known to have been associated with open web proxy, VPN, or suspicious proxy chains.'.t() ],
            ["12", 'Mobile Threats'.t(), 'IP addresses associated with malicious mobile application distribution or with attacks initiating from a mobile device.'.t() ],
            ["14", 'Tor Proxy'.t(), 'IP addresses associated with Tor Proxy activity such as exit nodes or suspicious IPs associated with Tor activity.'.t() ],
            ['17', 'Keyloggers'.t(), "Downloads and discussion of software agents that track a user's keystrokes or monitor their web surfing habits.".t()],
            ['18', 'Malware'.t(), "Malicious content including executables, drive-by infection sites, malicious scripts, viruses, trojans, and code.".t()],
            ['19', 'Spyware'.t(), "Spyware or Adware sites that provide or promote information gathering or tracking that is unknown to, or without the explicit consent of, the end user or the organization, also unsolicited advertising popups and programs that may be installed on a user's computer.".t()]
        ]
    }),

    threatsRenderer: function(value, meta, record){
        return record.get('description');
    },

    threatsConditionValues: function(){
        values = [];
        Ung.common.threatprevention.references.threats.each(function(record){
            if(record.get('bit') != 0){
                values.push([
                    record.get('bit'),
                    record.get('description'),
                    record.get('details')
                ]);
            }
        });
        return values;
    },


    actions: Ext.create('Ext.data.ArrayStore', {
        fields: [ 'value', 'description'],
        sorters: [{
            property: 'value',
            direction: 'ASC'
        }],
        data: [
            ["block", 'Block'.t()],
            ["pass", 'Pass'.t()]
        ]
    })
});
Ext.define('Ung.common.Renderer.threatprevention', {
    singleton: true,

    ruleIdMap: {},
    ruleId: function(value, row, record){
        if(value == 0){
            return;
        }
        var policyId = record && record.get && record.get('policy_id') ? record.get('policy_id') : 1;
        if(!Ung.common.Renderer.threatprevention.ruleIdMap[policyId] ||
            !Ung.common.Renderer.threatprevention.ruleIdMap[policyId] ||
            (value != Ung.common.Renderer.threatprevention.listKey && !(value in Ung.common.Renderer.threatprevention.ruleIdMap[policyId]))){
            if(!Ung.common.Renderer.threatprevention.ruleIdMap[policyId]){
                Ung.common.Renderer.threatprevention.ruleIdMap[policyId] = {};
            }
            var ruleInfo = Renderer.getReportInfo(record, ["threat-prevention"], "rules");

            if(ruleInfo){
                ruleInfo.forEach( function(rule){
                    Ung.common.Renderer.threatprevention.ruleIdMap[policyId][rule["ruleId"]] = rule["description"];
                });
            }
            if(!(value in Ung.common.Renderer.threatprevention.ruleIdMap[policyId]) && (value != Ung.common.Renderer.threatprevention.listKey)){
                // If category cannot be found, don't just keep coming back for more.
                Ung.common.Renderer.threatprevention.ruleIdMap[policyId][value] = 'Unknown'.t();
            }
        }
        if(value == Renderer.listKey){
            return Ung.common.Renderer.threatprevention.ruleIdMap[policyId] + ' [' + value + ']';
        }else{
            return Ung.common.Renderer.threatprevention.ruleIdMap[policyId][value] + ' [' + value + ']';
        }
    },

    /**
     * reputation renderer will display the reputation level of the value
     * @param {int} value - the reputation score
     */
    reputation: function(value) {
        return value ? Ung.common.threatprevention.references.getReputationLevel(value).get('description') : '';
    },

    /**
     * reputationDetails renderer displays the details of a reputation level
     * @param {int} value - the Reputation score to retrieve the threat level details for
     */
    reputationDetails: function(value) {
        return value ? Ung.common.threatprevention.references.getReputationLevel(value).get('details') : '';
    },

    /**
     * age renderer displays the age in months
     *
     * @param {int} value - the number of months the renderer should display
     */
    age: function(value) {
        return Ext.String.format('{0} months'.t(), value);
    },

    /**
     * recentOccurrences render displays the number of occurrences the threat has occurred
     *
     * @param {int} value - the number of recent occurrences
     */
    recentOccurrences: function(value){
        return Ext.String.format('{0} occurrences'.t(), value > Ung.common.TableConfig.threatprevention.maxKeyIndex ? Ung.common.TableConfig.threatprevention.maxKeyIndex : value);
    },

    /**
     * webCategories renderer displays the category and confidence % associated with that category
     *
     * @param {Array} values - An array of JSON objects with category IDs to display the category and confidence levels
     */
    webCategories: function(values) {
        if(values == 0 || values == null){
            return null;
        }

        if(Array.isArray(values)) {
            var currentCategories = [];

            for(var i in values) {
                var shortDesc = Renderer.webCategory(values[i].catid);
                var conf = " (" + values[i].conf + " % Confidence)";

                currentCategories.push(shortDesc + conf);
            }

            return currentCategories.join(", ");
        }

        return null;
    },

    /**
     * reputationHistory displays the history of a threat
     *
     * @param {Array} values - An array of reputation history items to display
     */
    reputationHistory: function(values) {
        if(values == 0 || values == null){
            return null;
        }

        if(Array.isArray(values)) {

            var dates = [];
            for(var i in values) {
                if(i <= Ung.common.TableConfig.threatprevention.maxKeyIndex) {
                    dates.push(Renderer.timestamp(values[i].timestamp));
                } else {
                    break;
                }
            }

            return dates.join(", ");
        }

        return null;
    },

    categoryMap:{
        0: 'Spam Sources'.t(),
        1: 'Windows Exploits'.t(),
        2: 'Web Attacks'.t(),
        3: 'Botnets'.t(),
        4: 'Scanners'.t(),
        5: 'Denial of Service'.t(),
        6: 'Reputation'.t(),
        7: 'Phishing'.t(),
        8: 'Proxy'.t(),
        11: 'Mobile Threats'.t(),
        13: 'Tor Proxy'.t(),
        16: 'Keyloggers'.t(),
        17: 'Malware'.t(),
        18: 'Spyware'.t()
    },
    category: function(value){
        if(value == 0){
            return null;
        }
        var descriptions = [];
        var threatBits = Object.keys(Ung.common.Renderer.threatprevention.categoryMap);
        for(var i = 0; i < threatBits.length; i++){
            if(Math.pow(2,threatBits[i]) & value){
                descriptions.push(Ung.common.Renderer.threatprevention.categoryMap[threatBits[i]]);
            }
        }
        return descriptions.join(', ');
    },

    ipPopularityMap:{
        1: 'Top 100,000'.t(),
        2: 'Top 1M'.t(),
        3: 'Top 10M'.t(),
        4: 'Lower than 10M'.t(),
        5: 'Unranked'.t()
    },

    /**
     * ipPopularity will return the IP popularity that should be displayed
     *
     * @param {int} value - The popularity ID to be looked up in the popularity map
     */
    ipPopularity: function(value){
        if(value == 0){
            return null;
        }
        return Ext.String.format(
                Renderer.mapValueFormat,
                ( value in Ung.common.Renderer.threatprevention.ipPopularityMap ) ? Ung.common.Renderer.threatprevention.ipPopularityMap[value] : Ung.common.Renderer.threatprevention.ipPopularity[5],
                value
        );
    }
});
Ext.define('Ung.common.TableConfig.threatprevention', {
    singleton: true,
    initialized: false,

    /**
     * extra map with fields, columns tables
     * used to inject threat prevention info
     * into sessions and http_events tables
     */
    map: {
        fields: {
            threat_prevention_blocked: {
                col: { text: 'Blocked'.t() + ' (Threat Prevention)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
                fld: { type: 'boolean' }
            },
            threat_prevention_client_categories: {
                col: { text: 'Client Categories'.t() + ' (Threat Prevention)', width: 150 },
                fld: { type: 'integer', convert: Ung.common.Converter.threatprevention.category }
            },
            threat_prevention_client_reputation: {
                col: { text: 'Client Reputation'.t() + ' (Threat Prevention)', width: 150 },
                fld: { type: 'integer', convert: Ung.common.Converter.threatprevention.reputation }
            },
            threat_prevention_flagged: {
                col: { text: 'Flagged'.t() + ' (Threat Prevention)', filter: Rndr.filters.boolean, width: Rndr.colW.boolean, renderer: Rndr.boolean },
                fld: { type: 'boolean' }
            },
            threat_prevention_reason: {
                col: { text: 'Reason'.t() + ' (Threat Prevention)', width: 100 },
                fld: { type: 'string', convert: Ung.common.Converter.threatprevention.reason }
            },
            threat_prevention_rule_id: { // should use converter instead
                col: { text: 'Rule Id'.t() + ' (Threat Prevention)', width: 120 },
                fld: { type: 'integer', convert: Ung.common.Converter.threatprevention.ruleId }
            },
            threat_prevention_server_categories: {
                col: { text: 'Server Categories'.t() + ' (Threat Prevention)', width: 150 },
                fld: { type: 'integer', convert: Ung.common.Converter.threatprevention.category }
            },
            threat_prevention_server_reputation: {
                col: { text: 'Server Reputation'.t() + ' (Threat Prevention)', width: 150 },
                fld: { type: 'integer', convert: Ung.common.Converter.threatprevention.reputation }
            }
        },

        tables: {
            sessions: [
                'threat_prevention_blocked',
                'threat_prevention_flagged',
                'threat_prevention_reason',
                'threat_prevention_rule_id',
                'threat_prevention_client_reputation',
                'threat_prevention_client_categories',
                'threat_prevention_server_reputation',
                'threat_prevention_server_categories'
            ],
            http_events: [
                'threat_prevention_blocked',
                'threat_prevention_flagged',
                'threat_prevention_reason',
                'threat_prevention_rule_id',
                'threat_prevention_client_reputation',
                'threat_prevention_client_categories',
                'threat_prevention_server_reputation',
                'threat_prevention_server_categories'
            ]
        }
    },

    initialize: function() {
        var me = this, _map = me.map;

        /**
         * Set From types
         */
        TableConfig.setFromType({
            threat_reputation: {
                type: 'RANGE',
                rangeValues: [
                    [1,20],
                    [21,40],
                    [41,60],
                    [61,80],
                    [81,100]
                ]
            },
            threat_category: {
                type: 'BITMASK',
                length: 31
            }
        });

        /**
         * Add threat prevention fields and tables configuration
         * to the main Map
         */
        Ext.apply(Map.fields, this.map.fields);
        Ext.Object.each(this.map.tables, function (table, fields) {
            Ext.Array.push(Map.tables[table], fields);
        });

        Map.listeners['sessions'] = {
            select: Ung.common.TableConfig.threatprevention.getIpDetails
        };
        Map.listeners['http_events'] = {
            select: Ung.common.TableConfig.threatprevention.getHttpDetails
        };


    },

    /**
     * Detail property details API fields and renderers.
     * NOTE: Keys are flattened.
     */
    detailMaps: {
        getrepinfo: {
            name: 'Domain Reputation History'.t(),
            fields: {
                age: {
                    name: 'Age'.t(),
                    renderer: Ung.common.Renderer.threatprevention.age
                },
                country: {
                    name: 'Country'.t()
                },
                popularity: {
                    name: 'Popularity'.t(),
                    renderer: Ung.common.Renderer.threatprevention.ipPopularity
                },
                threathistory: {
                    name: 'Most Recent Threat History'.t(),
                    renderer: Ung.common.Renderer.threatprevention.recentOccurrences
                },
                reputation: {
                    name: 'Reputation (Parent Domain)'.t(),
                    renderer: Ung.common.Renderer.threatprevention.reputation
                }
            }
        },
        geturlhistory:{
            name: 'Category History'.t(),
            fields:{
                current_categorization: {
                    name: 'Current Categorization'.t(),
                    fields:{
                        url: {
                            name: 'URL'
                        },
                        categories:{
                            name: 'Cateories'.t(),
                            fields: {
                                catid: {
                                    name: 'Category'.t(),
                                    renderer: function(value, metaData){
                                        return Renderer.webCategory(value);
                                    }
                                },
                                conf: {
                                    name: 'Confidence'.t(),
                                    renderer: function(value, metaData){
                                        return value + '%';
                                    }
                                }
                            }
                        }
                    }
                },
                security_history: {
                    name: 'Security History'.t(),
                    fields:{
                        categories: {
                            name: 'Categories'.t(),
                            fields: {
                                catid: {
                                    name: 'Category'.t(),
                                    renderer: function(value, metaData){
                                        return Renderer.webCategory(value);
                                    }
                                },
                                conf: {
                                    name: 'Confidence'.t(),
                                    renderer: function(value, metaData){
                                        return value + '%';
                                    }
                                }
                            }
                        },
                        timestamp: {
                            name: 'Timestamp'.t(),
                            renderer: Renderer.timestamp
                        }
                    }
                },
                url: {
                    name: 'URL'.t()
                }
            }
        },
        getrephistory: {
            name: 'Reputation History'.t(),
            fields: {
                max_reputation: {
                    name: 'Maximum Reputation'.t(),
                    renderer: Ung.common.Renderer.threatprevention.reputation
                },
                min_reputation: {
                    name: 'Minimum Reputation'.t(),
                    renderer: Ung.common.Renderer.threatprevention.reputation
                },
                avg_reputation: {
                    name: 'Average Reputation'.t(),
                    renderer: Ung.common.Renderer.threatprevention.reputation
                },
                history_count: {
                    name: 'Most Recent Reputation History'.t(),
                    renderer: function(value){
                        return Ext.String.format('{0} occurrences'.t(), value > Ung.common.TableConfig.threatprevention.maxKeyIndex ? Ung.common.TableConfig.threatprevention.maxKeyIndex : value);
                    }
                },
                history: {
                    name: 'History'.t(),
                    fields: {
                        reputation:{
                            name: 'Reputation'.t(),
                            renderer: Ung.common.Renderer.threatprevention.reputation
                        },
                        ts:{
                            name: 'Timestamp'.t(),
                            renderer: Renderer.timestamp
                        }
                    }
                },
            }
        },
        getthreathistory: {
            name: 'Category History'.t(),
            fields: {
                history: {
                    name: 'History'.t(),
                    fields: {
                        is_threat: {
                            name: 'Threat?'.t(),
                            renderer: function(value){
                                return value ? 'Yes'.t() : 'No'.t();
                            }
                        },
                        threat_types: {
                            name: 'Threat Categories'.t(),
                            renderer: function(value){
                                if(value.indexOf("org.json") > -1){
                                    return 'None'.t();
                                }else{
                                    return value;
                                }
                            }
                        },
                        ts: {
                            name: 'Timestamp'.t(),
                            renderer: Renderer.timestamp
                        }
                    }
                },
                threat_count: {
                    name: 'Threat Count'.t()
                }
            }
        },
        getipevidence: {
            name: 'Evidence History'.t(),
            fields: {
                ipint: {
                    name: 'IP Address'.t(),
                    renderer: function(value){
                        return ( (value>>>24) +'.' + (value>>16 & 255) +'.' + (value>>8 & 255) +'.' + (value & 255) );
                    }
                },
                evidence: {
                    name: 'Evidence'.t(),
                    fields:{
                        is_threat: {
                            name: 'Threat?'.t(),
                            renderer: function(value){
                                return value ? 'Yes'.t() : 'No'.t();
                            }
                        },
                        event_type: {
                            name: 'Event Type'.t(),
                            renderer: function(value){
                                if(value.indexOf("org.json") > -1){
                                    return 'None'.t();
                                }else{
                                    return value;
                                }
                            }
                        },
                        convicted_time: {
                            name: 'Convinced Timestamp'.t(),
                            renderer: Renderer.timestamp
                        },
                        incidents: {
                            name: 'Incidents'.t(),
                            fields: {
                                start_time: {
                                    name: 'Timestamp'.t(),
                                    renderer: Renderer.timestamp
                                },
                                event_desc: {
                                    name: 'Event Description'.t()
                                },
                                event_type: {
                                    name: 'Event Type'.t()
                                },
                                number_of_attempts: {
                                    name: 'History: Attempt Count'.t()
                                },
                                threat_type: {
                                    name: 'History: Threat Type'.t()
                                },
                                timespan: {
                                    name: 'History: Time Span'.t(),
                                    renderer: Renderer.timespan
                                },
                                details: {
                                    name: 'Details'.t(),
                                    fields: {
                                        sources: {
                                            name: 'History: Sources'.t()
                                        },
                                        total_attacks: {
                                            name: 'History: Attack Count'.t()
                                        },
                                        events: {
                                            name: 'History: Events'.t()
                                        },
                                        exploits: {
                                            name: 'History: Exploits'.t()
                                        },
                                        hosted_urls: {
                                            name: 'History: Hosted Urls'.t()
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    },

    /**
     * Build url-address based property records for reputation detail apis.
     *
     * @param {*} element Currently selected grid row
     * @param {*} record Current grid row record
     */
    getHttpDetails: function(record, cb) {
        var uriAddress = record.get('host'),
            reputation = record.get('threat_prevention_server_reputation'),
            clientIpAddress = record.get('c_client_addr'),
            clientReputation = record.get('threat_prevention_client_reputation'),
            ipAddresses = [];

        if (!reputation && !clientReputation) { return; }

        if (uriAddress != undefined) {
            uriAddress += record.get('uri');
        }

        if(reputation){
            Ext.Deferred.sequence([
                Rpc.asyncPromise(
                    'rpc.reportsManager.getReportInfo',
                    'threat-prevention',
                    -1,
                    'getUrlHistory',
                    [uriAddress])
            ], this)
            .then(function(results) {
                var propertyRecord = [];
                var propertyCategory = null;
                results.forEach( function(result){
                    if(result != null){
                        result.forEach( function(answer){
                            /**
                             * Walk detail maps for this answer.  Each call can make multiple API queries.
                             */
                            Ext.Object.each(
                                Ung.common.TableConfig.threatprevention.detailMaps,
                                function(detail, detailMap){
                                    if(detail in answer['queries']){
                                        propertyCategory = Ext.String.format('Threat Prevention: {0}: {1}'.t(), detailMap.name, 'Server'.t());
                                        Ung.common.TableConfig.threatprevention.toPropertyRecord(propertyRecord, propertyCategory, detailMap['fields'], answer['queries'][detail]);
                                    }
                                }
                            );
                        });
                    }
                });
                cb(propertyRecord);
            }, function(ex) {
                cb();
                console.log(ex);
            });
        }

        if(clientReputation){
            ipAddresses.push(clientIpAddress);
            Ext.Deferred.sequence([
                Rpc.asyncPromise(
                    'rpc.reportsManager.getReportInfo',
                    'threat-prevention',
                    -1,
                    'getIpHistory',
                    ipAddresses)
            ], this)
             .then(function(results){
                var propertyRecord = [];
                var propertyCategory = null;
                results.forEach( function(result){
                    if(result != null){
                        result.forEach( function(answer){
                            /**
                             * Walk detail maps for this answer.  Each call can make multiple API queries.
                             */
                            Ext.Object.each(
                                Ung.common.TableConfig.threatprevention.detailMaps,
                                function(detail, detailMap){
                                    if(detail in answer['queries']){
                                        var ipAddress = "ip" in answer ? answer["ip"] : answer["value"];
                                        propertyCategory = Ext.String.format('Threat Prevention: {0}: {1}'.t(), detailMap.name, 'Client'.t());
                                        Ung.common.TableConfig.threatprevention.toPropertyRecord(propertyRecord, propertyCategory, detailMap['fields'], answer['queries'][detail]);
                                    }
                                }
                            );
                        });
                    }
                });
                cb(propertyRecord);
            }, function(ex) {
                cb();
                console.log(ex);
            });
        }
    },

    /**
     * Build IP-address based property records for reputation detail apis.
     * @param {*} record Current grid row record
     */
    getIpDetails: function(record, cb) {
        var clientIpAddress = record.get('c_client_addr'),
            serverIpAddress = record.get('s_server_addr'),
            clientReputation = record.get('threat_prevention_client_reputation'),
            serverReputation = record.get('threat_prevention_server_reputation'),
            ipAddresses = [];

        if (clientReputation) {
            Ext.Deferred.sequence([
                Rpc.asyncPromise(
                    'rpc.reportsManager.getReportInfo',
                    'threat-prevention',
                    -1,
                    'getIpHistory',
                    [clientIpAddress])
            ], this)
            .then(function(results){
                var propertyRecord = [];
                var propertyCategory = null;
                results.forEach( function(result){
                    if(result != null){
                        result.forEach( function(answer){
                            /**
                             * Walk detail maps for this answer.  Each call can make multiple API queries.
                             */
                            Ext.Object.each(
                                Ung.common.TableConfig.threatprevention.detailMaps,
                                function(detail, detailMap){
                                    if(detail in answer['queries']){
                                        var ipAddress = "ip" in answer ? answer["ip"] : answer["value"];
                                        propertyCategory = Ext.String.format('Threat Prevention: {0}: {1}'.t(), detailMap.name, ipAddress == serverIpAddress ? 'Server'.t() : 'Client'.t());
                                        Ung.common.TableConfig.threatprevention.toPropertyRecord(propertyRecord, propertyCategory, detailMap['fields'], answer['queries'][detail]);
                                    }
                                }
                            );
                        });
                    }
                });
                cb(propertyRecord);
            }, function(ex) {
                cb();
                console.log(ex);
            });
        }
        if (serverReputation != null) {
            Ext.Deferred.sequence([
                Rpc.asyncPromise(
                    'rpc.reportsManager.getReportInfo',
                    'threat-prevention',
                    -1,
                    'getUrlHistory',
                    [serverIpAddress])
            ], this)
            .then(function(results) {
                var propertyRecord = [];
                var propertyCategory = null;
                results.forEach( function(result){
                    if(result != null){
                        result.forEach( function(answer){
                            /**
                             * Walk detail maps for this answer.  Each call can make multiple API queries.
                             */
                            Ext.Object.each(
                                Ung.common.TableConfig.threatprevention.detailMaps,
                                function(detail, detailMap){
                                    if(detail in answer['queries']){
                                        propertyCategory = Ext.String.format('Threat Prevention: {0}: {1}'.t(), detailMap.name, 'Server'.t());
                                        Ung.common.TableConfig.threatprevention.toPropertyRecord(propertyRecord, propertyCategory, detailMap['fields'], answer['queries'][detail]);
                                    }
                                }
                            );
                        });
                    }
                });
                cb(propertyRecord);
            }, function(ex) {
                cb();
                console.log(ex);
            });
        }
    },

    /*
     * Convert multi-level json object into a single-level key-pair flattened json object.
     */
    maxKeyIndex: 9,
    toPropertyRecord: function(propertyRecord, propertyCategory, fields, obj, fieldPath, namePath, currentIndex) {
        fieldPath = fieldPath || [];
        namePath = namePath || [];

        if(currentIndex != undefined &&
            (currentIndex + 1) > Ung.common.TableConfig.threatprevention.maxKeyIndex){
            return propertyRecord;
        }

        if (typeof (obj) === 'object' && obj !== null) {
            Ext.Object.each(obj, function(key, value){
                if(Array.isArray(obj)){
                    var newName = namePath[namePath.length - 1];
                    var keyIndex = parseInt(key,10);
                    if(obj.length > 1){
                        newName += ' ' + ( keyIndex + 1 );
                    }
                    Ung.common.TableConfig.threatprevention.toPropertyRecord(propertyRecord, propertyCategory, fields, value, fieldPath, namePath.slice(0,namePath.length-1).concat(newName), keyIndex);
                }else{
                    Ung.common.TableConfig.threatprevention.toPropertyRecord(propertyRecord, propertyCategory, fields[key] && 'fields' in fields[key] ? fields[key]['fields'] : fields, value, fieldPath.concat(key), namePath.concat(fields[key] && 'name' in fields[key] ? fields[key]['name'] : key));
                }
            });
        } else {
            var field = fieldPath[fieldPath.length - 1];
            var addProperty = true;
            if(field == 'javaClass'){
                addProperty = false;
            }
            if(addProperty == true){
                propertyRecord.push({
                    category: propertyCategory,
                    name: namePath.join(': '),
                    value: field in fields && fields[field]['renderer'] ? fields[field]['renderer'].call(this,obj) : obj
                });
            }
        }

        return propertyRecord;
    }
});
