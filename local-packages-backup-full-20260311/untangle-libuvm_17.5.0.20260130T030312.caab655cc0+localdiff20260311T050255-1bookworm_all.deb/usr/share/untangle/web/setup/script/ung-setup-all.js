Ext.define('Ung.Setup.Main', {
    extend: 'Ext.container.Viewport',

    viewModel: {
        data: {
            resuming: false,
            remoteReachable: null
        }
    },
    layout: 'center',
    padding: 20,
    items: [{
        xtype: 'container',
        itemId: 'intro',
        baseCls: 'intro',
        padding: '0 0 300 0',
        layout: {
            type: 'vbox',
            align: 'center'
        },
        items: [{
            xtype: 'component',
            style: { textAlign: 'center' },
            html: '<img src="images/BrandingLogo.png?' + (new Date()).getTime() + '" height=48/><h1>' + Ext.String.format('Thanks for choosing {0}!'.t(), rpc.oemShortName) + '</h1>'
        }]
    }],
    listeners: {
        afterrender: 'onAfterRender'
    },
    controller: {

        onAfterRender: function () {
            var me = this,
                view = me.getView(),
                vm = me.getViewModel(),
                items = [];

            // Configure main based on remote.
            if(!rpc.remote){
                // Local Setup Wizard configuration
                items.push({
                    xtype: 'component',
                    margin: '0 0 20 0',
                    style: { textAlign: 'center' },
                    html: Ext.String.format('A wizard will guide you through the initial setup and configuration of the {0}.'.t(), rpc.oemProductName)
                });
                items.push({
                    xtype: 'container',
                    layout: {
                        type: 'hbox',
                        align: 'center'
                    },
                    defaults: {
                        xtype: 'button',
                        scale: 'medium',
                        focusable: false,
                        margin: 5
                    },
                    items: [{
                        iconCls: 'fa fa-play fa-lg',
                        text: 'Resume Setup Wizard'.t(),
                        hidden: true,
                        bind: {
                            hidden: '{!resuming}'
                        },
                        handler: 'resumeWizard'
                    }, {
                        bind: {
                            iconCls: 'fa {!resuming ? "fa-play" : "fa-refresh" } fa-lg',
                            text: '{!resuming ? "Run Setup Wizard" : "Restart"}'.t(),
                        },
                        handler: 'resetWizard'
                    }]
                });
            }else{
                items.push({
                    xtype: 'component',
                    margin: '0 0 20 0',
                    html: '<i class="fa fa-spinner fa-spin fa-lg fa-fw"></i>' + 'Checking Internet connectivity'.t(),
                    hidden: false,
                    bind: {
                        hidden: '{remoteReachable != null}'
                    }
                },{
                    xtype: 'component',
                    margin: '0 0 20 0',
                    style: { textAlign: 'center' },
                    html: 'To continue, you must log in using your ETM Dashboard account. If you do not have one, you can create a free account.'.t(),
                    hidden: true,
                    bind: {
                        hidden: '{remoteReachable == false || remoteReachable == null}'
                    }
                },{
                    xtype: 'container',
                    hidden: true,
                    bind: {
                        hidden: '{remoteReachable == false || remoteReachable == null}'
                    },
                    items: [{
                        xtype: 'button',
                        width: 332,
                        margin: '0 0 10 0',
                        text: '<div style="color:white;">' + 'Log In'.t() + '</div>',
                        baseCls: 'command-center-login-button',
                        handler: function(){
                            window.location = rpc.remoteUrl + "appliances/add/" + rpc.serverUID;
                        }
                    },{
                        xtype: 'button',
                        width: 332,
                        text: '<div style="color:white;">' + 'Create Account'.t() + '</div>',
                        baseCls: 'command-center-create-button',
                        handler: function(){
                            window.location = rpc.remoteUrl + "login/create-account/add-appliance/" + rpc.serverUID;
                        }
                    }]
                },{
                    xtype: 'component',
                    margin: '0 0 20 0',
                    style: { textAlign: 'center' },
                    html: '<p>' + 'To continue, you must connect to ETM Dashboard which is currently unreachable from this device.'.t() + '<br/>' +
                            '<p>' + 'You must configure Internet connectivity to ETM Dashboard to continue.'.t() + '<br/>',
                    hidden: true,
                    bind: {
                        hidden: '{remoteReachable == true || remoteReachable == null}'
                    }
                },{
                    xtype: 'container',
                    layout: {
                        type: 'hbox',
                        align: 'center'
                    },
                    defaults: {
                        xtype: 'button',
                        scale: 'medium',
                        focusable: false,
                        margin: 5
                    },
                    hidden: true,
                    bind: {
                        hidden: '{remoteReachable == true || remoteReachable == null}'
                    },
                    items: [{
                        iconCls: 'fa fa-play fa-lg',
                        text: 'Configure Internet'.t(),
                        handler: 'resetWizard'
                    }]
                });
            }
            view.down('[itemId=intro]').add(items);

            // fadein
            Ext.defer(function () {
                me.getView().down('container').addCls('fadein');
            }, 100);

            Ext.defer(function () {
                var remoteReachable = rpc.setup.getRemoteReachable();
                vm.set("remoteReachable", remoteReachable);
            }, 500);

            // check if resuming
            if (!rpc.wizardSettings.wizardComplete && rpc.wizardSettings.completedStep != null) {
                vm.set('resuming', true);
            }
        },

        resetWizard: function() {
            var me = this;
            if(rpc.remote && !rpc.remoteReachable){
                if(Util.setRpcJsonrpc("admin") == true){
                    me.resetWizardContinue();
                }else{
                    Util.authenticate("passwd", function (isNonDefaultPassword) {
                        if (isNonDefaultPassword) {
                            var msg = Ext.create('Ext.window.MessageBox');
                            msg.textField.inputType = 'password';
                            msg.prompt(
                                'Authentication required'.t(),
                                'Please enter admin password'.t(), function(btn, p) {
                                    if (btn === 'ok') {
                                        Util.authenticate(p, function (flag) {
                                            me.resetWizardContinue();
                                        });
                                    }
                                }
                            );
                        } else {
                            me.resetWizardContinue();
                        }
                    });
                }
            }else{
                me.resetWizardContinue();
            }
        },

        resetWizardContinue: function(){
            var me = this, vm = me.getViewModel();

            vm.set('resuming', false);

            rpc.wizardSettings.completedStep = null;
            rpc.wizardSettings.wizardComplete = false;
            me.openSetup();

        },

        resumeWizard: function () {
            var me = this, msg = Ext.create('Ext.window.MessageBox');
            msg.textField.inputType = 'password';

            msg.prompt(
                'Authentication required'.t(),
                'Please enter admin password'.t(), function(btn, p) {
                    if (btn === 'ok') {
                        Util.authenticate(p, function () {
                            me.openSetup();
                        });
                    }
                }
            );
        },

        openSetup: function () {
            var me = this;
            me.getView().removeAll();
            me.getView().setStyle({
                background: '#F5F5F5'
            });
            me.getView().add({
                xtype: 'container',
                width: '100%',
                layout: {
                    type: 'hbox',
                    align: 'stretch'
                },
                items: [{
                    xtype: 'component',
                    plugins: 'responsive',
                    responsiveConfig: {
                        'width >= 840': { flex: 1 },
                        'width < 840': { flex: 0 }
                    }
                }, {
                    xtype: 'setupwizard',
                    height: 600,
                    flex: 1,
                    plugins: 'responsive',
                    responsiveConfig: {
                        'width >= 840': { width: 800, flex: 0 },
                        'width < 840': { flex: 1 }
                    },
                }, {
                    xtype: 'component',
                    plugins: 'responsive',
                    responsiveConfig: {
                        'width >= 840': { flex: 1 },
                        'width < 840': { flex: 0 }
                    }
                }]

            });
        }
    }

});
Ext.define('Ung.Setup.Util', {
    alternateClassName: 'Util',
    singleton: true,

    setRpcJsonrpc: function(root){
        var setupInfo, success = true;
        try {
            rpc.jsonrpc = new JSONRpcClient('/' + root + '/JSON-RPC');
            setupInfo = rpc.jsonrpc.UvmContext ? rpc.jsonrpc.UvmContext.getSetupStartupInfo() : rpc.jsonrpc.SetupContext.getSetupWizardStartupInfo();
        } catch (e) {
            success = false;
            // Util.handleException(e);
        }
        Ext.applyIf(rpc, setupInfo);
        return success;
    },

    authenticate: function (password, cb) {
        // Ung.app.loading('Authenticating...'.t());
        Ext.Ajax.request({
            url: '/auth/login?url=/admin&realm=Administrator',
            params: {
                username: 'admin',
                password: password
            },
            // If it uses the default type then this will not work
            // because the authentication handler does not like utf8
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            success: function (response) {
                // Ung.app.loading(false);
                if (response.responseText && response.responseText.indexOf('loginPage') != -1) {
                    //Check default password, if true callback otherwise existing flow
                    if (password == "passwd") {
                        cb(true);
                        return;
                    } else {
                        Ext.MessageBox.alert('Authentication failed'.t(), 'Invalid password.'.t());
                        return;
                    }
                }

                Util.setRpcJsonrpc("admin");

                rpc.tolerateKeepAliveExceptions = false;
                rpc.keepAlive = function() {
                    rpc.jsonrpc.UvmContext.getFullVersion(function (result, exception) {
                        if (!rpc.tolerateKeepAliveExceptions) {
                            if (exception) { Util.handleException(exception); return; }
                            // if (Ung.Util.handleException(exception)) { return; }
                        }
                        Ext.defer(rpc.keepAlive, 300000);
                    });
                };
                rpc.keepAlive();
                cb();
            },
            failure: function (response) {
                // Ung.app.loading(false);
                console.log(response);
                Ext.MessageBox.alert('Authenticatication failed'.t(), 'The authentication request has failed.'.t());
            }
        });
    },

    v4NetmaskList: [
        [32, '/32 - 255.255.255.255'],
        [31, '/31 - 255.255.255.254'],
        [30, '/30 - 255.255.255.252'],
        [29, '/29 - 255.255.255.248'],
        [28, '/28 - 255.255.255.240'],
        [27, '/27 - 255.255.255.224'],
        [26, '/26 - 255.255.255.192'],
        [25, '/25 - 255.255.255.128'],
        [24, '/24 - 255.255.255.0'],
        [23, '/23 - 255.255.254.0'],
        [22, '/22 - 255.255.252.0'],
        [21, '/21 - 255.255.248.0'],
        [20, '/20 - 255.255.240.0'],
        [19, '/19 - 255.255.224.0'],
        [18, '/18 - 255.255.192.0'],
        [17, '/17 - 255.255.128.0'],
        [16, '/16 - 255.255.0.0'],
        [15, '/15 - 255.254.0.0'],
        [14, '/14 - 255.252.0.0'],
        [13, '/13 - 255.248.0.0'],
        [12, '/12 - 255.240.0.0'],
        [11, '/11 - 255.224.0.0'],
        [10, '/10 - 255.192.0.0'],
        [9, '/9 - 255.128.0.0'],
        [8, '/8 - 255.0.0.0'],
        [7, '/7 - 254.0.0.0'],
        [6, '/6 - 252.0.0.0'],
        [5, '/5 - 248.0.0.0'],
        [4, '/4 - 240.0.0.0'],
        [3, '/3 - 224.0.0.0'],
        [2, '/2 - 192.0.0.0'],
        [1, '/1 - 128.0.0.0'],
        [0, '/0 - 0.0.0.0']
    ],

    handleException: function (exception) {
        if (Util.ignoreExceptions)
            return;

        var message = null;
        var details = '';

        if ( !exception ) {
            console.error('Null Exception!');
            return;
        } else {
            console.error(exception);
        }

        if ( exception.javaStack )
            exception.name = exception.javaStack.split('\n')[0]; //override poor jsonrpc.js naming
        if ( exception.name )
            details += '<b>' + 'Exception name'.t() +':</b> ' + exception.name + '<br/><br/>';
        if ( exception.code )
            details += '<b>' + 'Exception code'.t() +':</b> ' + exception.code + '<br/><br/>';
        if ( exception.message )
            details += '<b>' + 'Exception message'.t() + ':</b> ' + exception.message.replace(/\n/g, '<br/>') + '<br/><br/>';
        if ( exception.javaStack )
            details += '<b>' + 'Exception java stack'.t() +':</b> ' + exception.javaStack.replace(/\n/g, '<br/>') + '<br/><br/>';
        if ( exception.stack )
            details += '<b>' + 'Exception js stack'.t() +':</b> ' + exception.stack.replace(/\n/g, '<br/>') + '<br/><br/>';
        if ( rpc.fullVersionAndRevision != null )
            details += '<b>' + 'Build'.t() +':&nbsp;</b>' + rpc.fullVersionAndRevision + '<br/><br/>';
        details +='<b>' + 'Timestamp'.t() +':&nbsp;</b>' + (new Date()).toString() + '<br/><br/>';
        if ( exception.response )
            details += '<b>' + 'Exception response'.t() +':</b> ' + Ext.util.Format.stripTags(exception.response).replace(/\s+/g,'<br/>') + '<br/><br/>';

        /* handle authorization lost */
        if( exception.response && exception.response.includes('loginPage') ) {
            message  = 'Session timed out.'.t() + '<br/>';
            message += 'Press OK to return to the login page.'.t() + '<br/>';
            Util.ignoreExceptions = true;
            Util.showWarningMessage(message, details, Util.goToStartPage);
            return;
        }

        /* handle connection lost */
        if( exception.code==550 || exception.code == 12029 || exception.code == 12019 || exception.code == 0 ||
            /* handle connection lost (this happens on windows only for some reason) */
            (exception.name == 'JSONRpcClientException' && exception.fileName != null && exception.fileName.indexOf('jsonrpc') != -1) ||
            /* special text for "method not found" and "Service Temporarily Unavailable" */
            (exception.message && exception.message.indexOf('method not found') != -1) ||
            (exception.message && exception.message.indexOf('Service Unavailable') != -1) ||
            (exception.message && exception.message.indexOf('Service Temporarily Unavailable') != -1) ||
            (exception.message && exception.message.indexOf('This application is not currently available') != -1)) {
            message  = 'The connection to the server has been lost.'.t() + '<br/>';
            message += 'Press OK to return to the login page.'.t() + '<br/>';
            Util.ignoreExceptions = true;
            Util.showWarningMessage(message, details, Util.goToStartPage);
            return;
        }

        if (typeof exception === 'string') {
            this.showWarningMessage(exception, '', this.goToStartPage);
        } else {
            this.showWarningMessage(exception.message, details, this.goToStartPage);
        }
    },

    showWarningMessage: function(message, details, errorHandler) {
        var wnd = Ext.create('Ext.window.Window', {
            title: 'Warning'.t(),
            modal:true,
            closable:false,
            layout: 'fit',
            setSizeToRack: function () {
                if(Ung.Main && Ung.Main.viewport) {
                    var objSize = Ung.Main.viewport.getSize();
                    objSize.height = objSize.height - 66;
                    this.setPosition(0, 66);
                    this.setSize(objSize);
                } else {
                    this.maximize();
                }
            },
            doSize: function() {
                var detailsComp = this.down('fieldset[name="details"]');
                if(!detailsComp.isHidden()) {
                    this.setSizeToRack();
                } else {
                    this.center();
                }
            },
            items: {
                xtype: 'panel',
                minWidth: 350,
                autoScroll: true,
                defaults: {
                    border: false
                },
                items: [{
                    xtype: 'fieldset',
                    padding: 10,
                    items: [{
                        xtype: 'label',
                        html: message,
                    }]
                }, {
                    xtype: 'fieldset',
                    hidden: (typeof(interactiveMode) != 'undefined' && interactiveMode == false),
                    items: [{
                        xtype: 'button',
                        name: 'details_button',
                        text: 'Show details'.t(),
                        hidden: details==null,
                        handler: function() {
                            var detailsComp = wnd.down('fieldset[name="details"]');
                            var detailsButton = wnd.down('button[name="details_button"]');
                            if(detailsComp.isHidden()) {
                                wnd.initialHeight = wnd.getHeight();
                                wnd.initialWidth = wnd.getWidth();
                                detailsComp.show();
                                detailsButton.setText('Hide details'.t());
                                wnd.setSizeToRack();
                            } else {
                                detailsComp.hide();
                                detailsButton.setText('Show details'.t());
                                wnd.restore();
                                wnd.setHeight(wnd.initialHeight);
                                wnd.setWidth(wnd.initialWidth);
                                wnd.center();
                            }
                        },
                        scope : this
                    }]
                }, {
                    xtype: 'fieldset',
                    name: 'details',
                    hidden: true,
                    html: details!=null ? details : ''
                }]
            },
            buttons: [{
                text: 'OK'.t(),
                hidden: (typeof(interactiveMode) != 'undefined' && interactiveMode == false),
                handler: function() {
                    if ( errorHandler) {
                        errorHandler();
                    } else {
                        wnd.close();
                    }
                }
            }]
        });
        wnd.show();
        if(Ext.MessageBox.rendered) {
            Ext.MessageBox.hide();
        }
    },

    goToStartPage: function () {
        Ext.MessageBox.wait('Redirecting to the start page...'.t(), 'Please wait'.t());
        location.reload();
    },
});
Ext.define('Ung.Setup.Wizard', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.setupwizard',

    viewModel: {
        data: {
            activeStepDesc: '',
            activeStep: null,
            intfListLength: 0, // used for next button disable/enable
            nextDisabled: false,
            interfacesForceContinue: false
        },
        formulas: {
            nextButtonDisabled: function(get){
                // Not easy to manage next button disabled mode with conditions in a bind.
                if(get('nextDisabled')){
                    // Always disable.
                    return true;
                }
                // Disable if on Interfaces card and less than 2 interfaces.
                return get('activeStep') === "Interfaces" && get('intfListLength') < 2 && !get('interfacesForceContinue');
            }
        }
    },

    frame: true,
    header: false,
    border: false,
    bodyBorder: false,
    bodyPadding: 0,
    layout: 'card',
    padding: 0,

    bodyStyle: {
        background: '#FFF',
        border: 0
    },

    defaults: {
        border: false,
        bodyBorder: false,
        bodyPadding: 0,
        padding: 20,
        cls: 'step',
        header: false
    },

    dockedItems: [{
        xtype: 'component',
        cls: 'step-title',
        padding: '20 20 0 20',
        dock: 'top',
        html: '&nbsp;',
        bind: {
            html: '{activeStepDesc}'
        }
    }, {
        xtype: 'toolbar',
        dock: 'top',
        hidden: true,
        defaults: {
            xtype: 'component'
        },
        items: [{
            bind: {
                html: '{activeStep}'
            }
        }]
    }, {
        xtype: 'toolbar',
        dock: 'bottom',
        border: false,
        layout: {
            type: 'hbox',
            align: 'stretch'
        },
        hidden: true,
        bind: {
            hidden: '{!nextStep}'
        },
        defaults: {
            scale: 'medium',
            focusable: false
        },
        items: [{
            itemId: 'prevBtn',
            iconCls: 'fa fa-chevron-circle-left fa-lg',
            hidden: true,
            handler: 'onPrev',
            bind: {
                hidden: '{!prevStep}',
                text: '{prevStep}'
            }
        }, {
            xtype: 'component',
            itemId: 'stepIndicator',
            cls: 'steps',
            width: 200,
            padding: '7 0 0 0',
            html: ''
        }, '->', {
            itemId: 'nextBtn',
            iconCls: 'fa fa-chevron-circle-right fa-lg',
            iconAlign: 'right',
            handler: 'onNext',
            hidden: true,
            disabled: false,
            bind: {
                hidden: '{!nextStep}',
                text: '{nextStep}',
                disabled: '{nextButtonDisabled}'
            }
        }]
    }],

    items:[],

    listeners: {
        afterrender: 'onAfterRender',
        syncsteps: 'onSyncSteps'
    },

    controller: {
        onAfterRender: function (view) {

            // Populate steps from wizard settings.
            var steps = [];
            rpc.wizardSettings.steps.forEach( function(stepName){
                if( Ext.ClassManager.getByAlias('widget.' + stepName) ){
                    view.add({xtype: stepName});
                }
            });
            view.getLayout().next();

            var me = this, vm = me.getViewModel(), cardIndex;
            if (!rpc.wizardSettings.wizardComplete && rpc.wizardSettings.completedStep !== null) {
                cardIndex = Ext.Array.indexOf(rpc.wizardSettings.steps, rpc.wizardSettings.completedStep);

                // if resuming from a step after Network Cards settings, need to fetch network settings
                cardIndex--;
                if (cardIndex >= 2) {
                    Ung.app.loading('Loading interfaces...'.t());
                    rpc.networkManager.getNetworkSettings(function (result, ex) {
                        Ung.app.loading(false);
                        if (ex) { Util.handleException('Unable to load interfaces.'.t()); return; }

                        vm.set({
                            networkSettings: result,
                            intfListLength: result.interfaces.list.length
                        });

                        // update the steps based on interfaces
                        me.onSyncSteps(cardIndex);
                    });
                } else {
                    view.setActiveItem(cardIndex + 1);
                    me.updateNav();
                }
            } else {
                me.updateNav();
            }
        },

        onPrev: function () {
            var me = this;
            me.getView().getLayout().prev();
            me.updateNav();
        },

        onNext: function () {
            var me = this, layout = me.getView().getLayout();

            // save wizard settings
            layout.getActiveItem().fireEvent('save', function () {
                if (!rpc.wizardSettings.wizardComplete) {
                    rpc.wizardSettings.completedStep = layout.getActiveItem().getXType();
                    if(rpc.jsonrpc.UvmContext){
                        rpc.jsonrpc.UvmContext.setWizardSettings(function (result, ex) {
                            if (ex) { Util.handleException(ex); return; }
                        }, rpc.wizardSettings);
                    }
                }
                layout.next(); // move to next step
                me.updateNav(); // update navigation
            });
        },

        updateNav: function () {
            var me = this, view = me.getView(), vm = me.getViewModel(),

                layout = me.getView().getLayout(),
                prevStep = layout.getPrev(),
                nextStep = layout.getNext(),

                activeItem = layout.getActiveItem(),
                activeIndex = activeItem ? Ext.Array.indexOf(view.steps, activeItem.getXType()) : -1,

                stepInd = view.down('#stepIndicator'),
                stepIndHtml = '';

            if(activeItem &&
                activeItem.getViewModel() &&
                activeItem.getViewModel().get('nextStep') !== null){
                nextStep = activeItem.getViewModel().get('nextStep');
            }

            vm.set({
                activeStep: activeItem && activeItem.getXType(),
                activeStepDesc: activeItem && activeItem.description,
                prevStep: prevStep ? prevStep.getTitle() : null,
                nextStep: nextStep ? nextStep.getTitle() : null
            });

            Ext.Array.each(view.steps, function (step, idx) {
                if (idx < activeIndex) {
                    stepIndHtml += '<i class="done"></i>';
                    return;
                }
                if (idx === activeIndex) {
                    stepIndHtml += '<i class="active"></i>';
                    return;
                }
                stepIndHtml += '<i></i>';
            });
            stepInd.setHtml(stepIndHtml);

            if (rpc.jsonrpc) {
                if(view.steps && view.steps.length > 0){
                    rpc.wizardSettings.steps = view.steps;
                }
                rpc.wizardSettings.completedStep = prevStep ? prevStep.getXType() : null;
                rpc.wizardSettings.wizardComplete = nextStep ? false : true;

                if(rpc.jsonrpc.UvmContext){
                    rpc.jsonrpc.UvmContext.setWizardSettings(function (result, ex) {
                        if (ex) { Util.handleException(ex); return; }
                    }, rpc.wizardSettings);
                }
            }
        },

        /**
         * called after the network settings were fetched,
         * updates the wizard steps depending on available
         * interfaces.
         */
        onSyncSteps: function (activeItemIdx) {
            if(rpc.remote){
                // Only for local.
                return;
            }
            var me = this, vm = me.getViewModel(),
                wizard = me.getView(),

                interfaces = vm.get('networkSettings.interfaces.list'),
                firstWan = Ext.Array.findBy(interfaces, function (intf) {
                    return (intf.isWan && intf.configType !== 'DISABLED');
                }),
                firstNonWan = Ext.Array.findBy(interfaces, function (intf) {
                    return !intf.isWan;
                }),
                firstWireless = Ext.Array.findBy(interfaces, function (intf) {
                    return intf.isWirelessInterface;
                });

            wizard.steps = ['License', 'ServerSettings', 'Interfaces'];

            if (firstWan) {
                wizard.steps.push('Internet');
            }
            if (firstNonWan) {
                wizard.steps.push('InternalNetwork');
            }
            if (firstWireless) {
                wizard.steps.push('Wireless');
            }

            wizard.steps.push('AutoUpgrades');
            wizard.steps.push('Complete');

            // remove any nonwanted step if exists
            Ext.Array.each(wizard.items.items, function (card) {
                if(card){
                    if (!Ext.Array.contains(wizard.steps, card.getXType())) {
                        wizard.remove(card);
                    }
                }
            });

            // add steps based on found interfaces
            Ext.Array.each(wizard.steps, function (step) {
                if (!wizard.down(step)) {
                    wizard.add( { xtype: step } );
                }
            });

            // used when resuming the setup
            if (Ext.isNumber(activeItemIdx)) {
                wizard.setActiveItem(activeItemIdx + 1);
            }

            me.updateNav();
        }
    }

});
Ext.define('Ung.Setup.AutoUpgrades', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.AutoUpgrades',

    title: 'Auto Upgrades'.t(),
    description: rpc.isCCHidden ? "Automatic Upgrades".t() : 'Automatic Upgrades and ETM Dashboard Access'.t(),

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    items: [{
        xtype: 'container',
        items: [{
            xtype: 'checkbox',
            boxLabel: '<strong>' + 'Automatically Install Upgrades'.t() + '</strong>',
            bind: { value: '{systemSettings.autoUpgrade}' }
        }, {
            xtype: 'component',
            margin: '0 0 0 20',
            html: 'Automatically install new versions of the software when available.'.t() + '<br/>' +
                'This is the recommended choice for most sites.'.t()
        }]
    }, {
        xtype: 'container',
        margin: '20 0 0 0',
        items: [{
            xtype: 'checkbox',
            boxLabel: '<strong>' + 'Connect to ETM Dashboard'.t() + '</strong>',
            bind: { value: '{systemSettings.cloudEnabled}' }
        }, {
            xtype: 'component',
            margin: '0 0 0 20',
            html: Ext.String.format('Remain securely connected to the ETM Dashboard for cloud management, hot fixes, and support access.'.t(), rpc.oemName) + '<br/>' +
                'This is the recommended choice for most sites.'.t()
        }],
        hidden: false,
        bind: {
            hidden: '{isCCHidden}'
        }
    }],

    listeners: {
        activate: 'getSettings',
        save: 'onSave'
    },

    controller: {

        getSettings: function () {
            var me = this, vm = me.getViewModel();

            Ung.app.loading('Loading Automatic Upgrades Settings'.t());
            rpc.systemManager.getSettings(function (result, ex) {
                Ung.app.loading(false);
                if (ex) { Util.handleException(ex); return; }
                vm.set('systemSettings', result);

                // keep initial values for checking changes
                me.initialValues = {
                    autoUpgrade: result.autoUpgrade,
                    cloudEnabled: result.cloudEnabled
                };

                if (rpc.isCCHidden) {
                    vm.set('isCCHidden', true);
                    me.initialValues.cloudEnabled = false;
                    me.getView().description = "Automatic Upgrades";
                }
            });
        },

        onSave: function (cb) {
            var me = this, vm = me.getViewModel();
            // if no changes skip to next step
            if (
                me.initialValues.autoUpgrade === vm.get('systemSettings.autoUpgrade') &&
                me.initialValues.cloudEnabled === vm.get('systemSettings.cloudEnabled')
            ) { cb(); return; }

            // if cloud enabled, enable support also
            if (vm.get('systemSettings.cloudEnabled')) {
                vm.set('systemSettings.supportEnabled', true);
            }

            Ung.app.loading('Saving Settings ...'.t());
            rpc.systemManager.setSettings(function (result, ex) {
                Ung.app.loading(false);
                if (ex) { Util.handleException(ex); return; }
                cb();
            }, vm.get('systemSettings'));
        }
    }
});
Ext.define('Ung.Setup.Complete', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.Complete',

    title: 'Finish'.t(),
    description: '',

    layout: 'center',
    items: [{
        xtype: 'container',
        itemId: 'complete',
        layout: {
            type: 'vbox',
            align: 'middle'
        },
        items: []
    }],
    listeners: {
        afterrender: 'onAfterRender',
        activate: 'onActivate'
    },
    controller: {

        onAfterRender: function () {
            var me = this,
                view = me.getView(),
                vm = me.getViewModel(),
                items = [];

            // Configure main based on remote.
            if(!rpc.remote){
                // Local Setup Wizard configuration
                items.push({
                    xtype: 'component',
                    style: { textAlign: 'center' },
                    html: '<h1 style="margin: 0;">' + Ext.String.format('The {0} is now configured.', rpc.oemProductName) + '</h1><br/><br/>You are now ready to configure the applications.'.t()
                });
                items.push({
                    xtype: 'button',
                    margin: '30 0 0 0',
                    scale: 'medium',
                    text: 'Go to Dashboard'.t(),
                    iconCls: 'fa fa-check',
                    handler: function () {
                        Ext.MessageBox.wait('Loading User Interface...'.t(), 'Please Wait'.t());
                        //and set a flag so the wizard wont run again
                        rpc.jsonrpc.UvmContext.wizardComplete(function (result, ex) {
                            if (ex) { Util.handleException(ex); return; }
                            window.location.href = '/admin/index.do';
                        });
                    }
                });
            }else{
                // Can get to remote server
                items.push({
                    xtype: 'component',
                    style: { textAlign: 'center' },
                    html: '<img src="images/BrandingLogo.png?' + (new Date()).getTime() + '" height=48/><h1>' + Ext.String.format('Thanks for choosing {0}!'.t(), rpc.oemName) + '</h1>'
                });
                items.push({
                    xtype: 'component',
                    margin: '0 0 20 0',
                    style: { textAlign: 'center' },
                    html: 'To continue, you must log in using your ETM Dashboard account.  If you do not have one, you can create a free account.'.t()
                });
                items.push({
                    xtype: 'container',
                    items: [{
                        xtype: 'button',
                        width: 332,
                        margin: '0 0 10 0',
                        text: '<div style="color:white;">' + 'Log In'.t() + '</div>',
                        baseCls: 'command-center-login-button',
                        handler: function(){
                            window.location = rpc.remoteUrl + "appliances/add/" + rpc.serverUID;
                        }
                    },{
                        xtype: 'button',
                        width: 332,
                        text: '<div style="color:white;">' + 'Create Account'.t() + '</div>',
                        baseCls: 'command-center-create-button',
                        handler: function(){
                            window.location = rpc.remoteUrl + "login/create-account/add-appliance/" + rpc.serverUID;
                        }
                    }]
                });
            }
            view.down('[itemId=complete]').add(items);
        },

        onActivate: function(){
            if(!rpc.remote){
                // In local mode, mark wizard completed so apps can start being populated.
                rpc.jsonrpc.UvmContext.wizardComplete();
            }
        }
    }
});
Ext.define('Ung.Setup.Interfaces', {
    extend: 'Ext.panel.Panel',
    alias: 'widget.Interfaces',
    title: 'Network Cards'.t(),
    description: 'Identify Network Cards'.t(),

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    items: [{
        xtype: 'component',
        html: 'This step identifies the external, internal, and other network cards.'.t() + '<br/><br/>' +
            '<strong>' + 'Step 1:'.t() + '</strong> ' +
            'Plug an active cable into one network card to determine which network card it is.'.t() + '<br/>' +
            '<strong>' + 'Step 2:'.t() + '</strong> ' +
            '<em>' + 'Drag and drop'.t() + '</em> ' + 'the network card to map it to the desired interface.'.t() + '<br/>' +
            '<strong>' + 'Step 3:'.t() + '</strong> ' +
            'Repeat steps 1 and 2 for each network card and then click <i>Next</i>.'.t()
    }, {
        xtype: 'grid',
        margin: '20 0 0 0',
        flex: 1,
        sortableColumns: false,
        enableColumnResize: true,
        enableColumnHide: false,
        enableColumnMove: false,
        plugins: {
            ptype: 'cellediting',
            clicksToEdit: 1
        },
        store: {
            data: []
        },

        viewConfig: {
            plugins: {
                ptype: 'gridviewdragdrop',
                dragText: 'Drag and drop to reorganize'.t(),
                dragZone: {
                    onBeforeDrag: function (data, e) {
                        return Ext.get(e.target).hasCls('fa-arrows');
                    }
                }
            },
            listeners: {
                beforedrop: 'onBeforeDrop'
            }
        },
        columns: [{
            header: 'Name'.t(),
            dataIndex: 'name',
            sortable: false,
            width: 110,
            renderer: function (value) {
                return value.t();
            }
        }, {
            xtype: 'gridcolumn',
            header: '<i class="fa fa-sort"></i>',
            align: 'center',
            width: 30,
            resizable: false,
            tdCls: 'action-cell',
            renderer: function() {
                return '<i class="fa fa-arrows" style="cursor: move;"></i>';
            }
        }, {
            header: 'Device'.t(),
            tooltip: 'Click on a Device to open a combo and choose the desired Device from a list. When anoter Device is selected the 2 Devices are swithced.'.t(),
            tooltipType: 'title',
            width: 80,
            dataIndex: 'deviceName',
            editor: {
                xtype: 'combo',
                bind: {
                    store: '{deviceStore}'
                },
                // store: physicalDevsStore,
                editable: false,
                valueField: 'physicalDev',
                displayField: 'physicalDev',
                queryMode: 'local',
                listeners: {
                    change: 'setInterfacesMap'
                }
            }
        }, {
            dataIndex: 'connected',
            sortable: false,
            resizable: false,
            width: 30,
            align: 'center',
            renderer: function (value) {
                switch (value) {
                case 'CONNECTED': return '<i class="fa fa-circle fa-green"></i>';
                case 'DISCONNECTED': return '<i class="fa fa-circle fa-gray"></i>';
                case 'MISSING': return '<i class="fa fa-exclamation-triangle fa-orange"></i>';
                default: return '<i class="fa fa-question-circle fa-gray"></i>';
                }
            }
        }, {
            header: 'Status'.t(),
            dataIndex: 'connected',
            sortable: false,
            flex: 1,
            renderer: function (value, metadata, record) {
                var connected = record.get('connected'),
                    mbit = record.get('mbit'),
                    duplex = record.get('duplex'),
                    vendor = record.get('vendor'),
                    connectedStr = (connected == 'CONNECTED') ? 'connected'.t() : (connected == 'DISCONNECTED') ? 'disconnected'.t() : 'unknown'.t(),
                    duplexStr = (duplex == 'FULL_DUPLEX') ? 'full-duplex'.t() : (duplex == 'HALF_DUPLEX') ? 'half-duplex'.t() : 'unknown'.t();
                return connectedStr + ' ' + mbit + ' ' + duplexStr + ' ' + vendor;
            }
        }, {
            header: 'MAC Address'.t(),
            dataIndex: 'macAddress',
            sortable: false,
            width: 120
            // renderer: function (value, metadata, record, rowIndex, colIndex, store, view) {
            //     var text = '';
            //     if (value && value.length > 0) {
            //         // Build the link for the mac address
            //         text = '<a target="_blank" href="http://standards.ieee.org/cgi-bin/ouisearch?' +
            //             value.substring(0, 8).replace(/:/g, '') + '">' + value + '</a>';
            //     }
            //     return text;
            // }
        }]
    }, {
        xtype: 'container',
        layout: {
            type: 'hbox',
            align: 'stretch'
        },
        cls: 'inline-warning',
        margin: '10 0 0 0',
        padding: '20 20 10 20',

        // publishes: 'hidden',
        hidden: true,
        bind: {
            hidden: '{networkSettings.interfaces.list.length > 1}'
        },

        items: [{
            xtype: 'component',
            margin: '0 20 0 0',
            html: '<i class="fa fa-exclamation-triangle fa-orange fa-3x"></i>'
        }, {
            xtype: 'container',
            flex: 1,
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            items: [{
                xtype: 'component',
                html: '<p style="float: left; margin: 0;">' + 'Untangle must be installed "in-line" as a gateway. <br/>This usually requires at least 2 network cards (NICs) and fewer than 2 NICs were detected.'.t() + '</p>'
            }, {
                xtype: 'checkbox',
                margin: '5 0',
                boxLabel: '<strong>' + 'Continue anyway'.t() + '</strong>',
                value: 1,
                bind:{
                    value: '{interfacesForceContinue}'
                }
            }]
        }]
    }],

    listeners: {
        activate: 'onActivate',
        deactivate: 'onDeactivate',
        save: 'onSave'
    },

    controller: {

        onActivate: function () {
            var me = this;
            me.getSettings();
            me.enableAutoRefresh = true;
            Ext.defer(me.autoRefreshInterfaces, 3000, me); // refreshes interfaces every 3 seconds
        },

        onDeactivate: function () {
            var me = this;
            me.enableAutoRefresh = false;
        },

        getSettings: function () {
            var me = this, vm = me.getViewModel(),
                grid = me.getView().down('grid');

            me.physicalDevsStore = [];
            me.intfOrderArr = [];

            Ung.app.loading('Loading interfaces...'.t());
            rpc.networkManager.getNetworkSettings(function (result, ex) {
                Ung.app.loading(false);
                if (ex) { Util.handleException('Unable to load interfaces.'.t()); return; }

                vm.set({
                    networkSettings: result,
                    intfListLength: result.interfaces.list.length
                });

                var interfaces = [], devices = [];

                Ext.Array.each(result.interfaces.list, function (intf) {
                    if (!intf.isVlanInterface) {
                        interfaces.push(intf);
                        devices.push({physicalDev: intf.physicalDev});
                    }
                });

                rpc.networkManager.getDeviceStatus(function (result2, ex2) {
                    if (ex2) { Util.handleException(ex2); return; }
                    var deviceStatusMap = Ext.Array.toValueMap(result2.list, 'deviceName');
                    Ext.Array.forEach(interfaces, function (intf) {
                        Ext.applyIf(intf, deviceStatusMap[intf.physicalDev]);
                    });

                    // store data is not binded, so grid changes are not affecting the network settings
                    grid.getStore().loadData(Ext.clone(interfaces));
                    grid.getStore().commitChanges(); // so the grid is not dirty after initial data load

                    Ext.Array.each(interfaces, function (intf) {
                        me.physicalDevsStore.push([intf.physicalDev, intf.physicalDev]);
                        // me.intfOrderArr.push(Ext.clone(intf));
                    });
                    vm.set('deviceStore', me.physicalDevsStore);
                });

                // update the steps based on interfaces
                me.getView().up('setupwizard').fireEvent('syncsteps');

            });
        },

        autoRefreshInterfaces: function () {
            var me = this, store = me.getView().down('grid').getStore(),
                vm = me.getViewModel();

            if (!me.enableAutoRefresh) { return; }

            rpc.networkManager.getNetworkSettings(function (result, ex) {
                if (ex) { Util.handleException('Unable to refresh the interfaces.'.t()); return; }
                var interfaces = [];

                vm.set('intfListLength', result.interfaces.list.length);

                Ext.Array.each(result.interfaces.list, function (intf) {
                    if (!intf.isVlanInterface) {
                        interfaces.push(intf);
                    }
                });

                if (interfaces.length !== store.getCount()) {
                    Ext.MessageBox.alert('New interfaces'.t(), 'There are new interfaces, please restart the wizard.', '');
                    return;
                }

                rpc.networkManager.getDeviceStatus(function (result2, ex2) {
                    if (ex2) { Util.handleException(ex); return; }
                    if (result === null) { return; }

                    var deviceStatusMap = Ext.Array.toValueMap(result2.list, 'deviceName');
                    store.each(function (row) {
                        var deviceStatus = deviceStatusMap[row.get('physicalDev')];
                        if (deviceStatus !== null) {
                            row.set('connected', deviceStatus.connected);
                        }
                    });
                    if (me.enableAutoRefresh) {
                        Ext.defer(me.autoRefreshInterfaces, 3000, me);
                    }
                });

            });
        },

        // use the same mechanism as for drop downs
        onBeforeDrop: function (node, data, overModel, dropPosition, dropHandlers) {
            dropHandlers.wait = true;

            var sourceRecord = data.records[0],
                targetRecord = overModel;

            if (sourceRecord === null || targetRecord === null) {
                dropHandlers.cancelDrop();
                return;
            }

            // clone phantom records to manipulate (switch) data properly
            var sourceRecordCopy = sourceRecord.copy(null),
                targetRecordCopy = targetRecord.copy(null);

            sourceRecord.set({
                deviceName: targetRecordCopy.get('deviceName'),
                physicalDev: targetRecordCopy.get('physicalDev'),
                // systemDev:   targetRecordCopy.get('systemDev'),
                // symbolicDev: targetRecordCopy.get('symbolicDev'),
                macAddress:  targetRecordCopy.get('macAddress'),
                duplex:      targetRecordCopy.get('duplex'),
                vendor:      targetRecordCopy.get('vendor'),
                mbit:        targetRecordCopy.get('mbit'),
                connected:   targetRecordCopy.get('connected')
            });
            targetRecord.set({
                deviceName: sourceRecordCopy.get('deviceName'),
                physicalDev: sourceRecordCopy.get('physicalDev'),
                // systemDev:   sourceRecordCopy.get('systemDev'),
                // symbolicDev: sourceRecordCopy.get('symbolicDev'),
                macAddress:  sourceRecordCopy.get('macAddress'),
                duplex:      sourceRecordCopy.get('duplex'),
                vendor:      sourceRecordCopy.get('vendor'),
                mbit:        sourceRecordCopy.get('mbit'),
                connected:   sourceRecordCopy.get('connected')
            });
            dropHandlers.cancelDrop(); // cancel drop as we do not want to reorder rows but just to set physicalDev
        },

        // used when mapping from comboboxes
        setInterfacesMap: function (elem, newValue, oldValue) {
            var sourceRecord = null, targetRecord = null, grid = this.getView().down('grid');

            grid.getStore().each( function( currentRow ) {
                if (oldValue === currentRow.get('physicalDev')) {
                    sourceRecord = currentRow;
                } else if (newValue === currentRow.get('physicalDev')) {
                    targetRecord = currentRow;
                }
            });
            // make sure sourceRecord & targetRecord are defined
            if (sourceRecord === null || targetRecord === null || sourceRecord === targetRecord) {
                return;
            }

            // clone phantom records to manipulate (switch) data properly
            var sourceRecordCopy = sourceRecord.copy(null),
                targetRecordCopy = targetRecord.copy(null);

            // switch data between records (interfaces) - remapping
            sourceRecord.set({
                deviceName: newValue,
                physicalDev: targetRecordCopy.get('physicalDev'),
                // systemDev:   targetRecordCopy.get('systemDev'),
                // symbolicDev: targetRecordCopy.get('symbolicDev'),
                macAddress:  targetRecordCopy.get('macAddress'),
                duplex:      targetRecordCopy.get('duplex'),
                vendor:      targetRecordCopy.get('vendor'),
                mbit:        targetRecordCopy.get('mbit'),
                connected:   targetRecordCopy.get('connected')
            });
            targetRecord.set({
                deviceName: oldValue,
                physicalDev: sourceRecordCopy.get('physicalDev'),
                // systemDev:   sourceRecordCopy.get('systemDev'),
                // symbolicDev: sourceRecordCopy.get('symbolicDev'),
                macAddress:  sourceRecordCopy.get('macAddress'),
                duplex:      sourceRecordCopy.get('duplex'),
                vendor:      sourceRecordCopy.get('vendor'),
                mbit:        sourceRecordCopy.get('mbit'),
                connected:   sourceRecordCopy.get('connected')
            });
        },

        onSave: function (cb) {
            var me = this, vm = me.getViewModel(),
                grid = me.getView().down('grid'), interfacesMap = {};

            // if no changes/remapping skip this step
            if (grid.getStore().getModifiedRecords().length === 0) { cb(); return; }

            grid.getStore().each(function (currentRow) {
                interfacesMap[currentRow.get('interfaceId')] = currentRow.get('physicalDev');
            });

            // apply new physicalDev for each interface from initial Network Settings
            Ext.Array.each(vm.get('networkSettings.interfaces.list'), function (intf) {
                if (!intf.isVlanInterface) {
                    intf.physicalDev = interfacesMap[intf.interfaceId];
                }
            });

            Ung.app.loading('Saving Settings ...'.t());
            rpc.networkManager.setNetworkSettings(function (result, ex) {
                Ung.app.loading(false);
                if (ex) { Util.handleException(ex); return; }
                cb();
            }, vm.get('networkSettings'));
        }
    }
});
Ext.define('Ung.Setup.InternalNetwork', {
    extend: 'Ext.form.Panel',
    alias: 'widget.InternalNetwork',

    title: 'Internal Network'.t(),
    description: 'Configure the Internal Network Interface'.t(),

    layout: {
        type: 'vbox',
        align: 'stretch'
    },

    defaults: {
        hidden: true,
        bind: {
            hidden: '{!internal}'
        }
    },

    items: [{
        xtype: 'container',
        layout: {
            type: 'column',
        },
        items: [{
            xtype: 'container',
            columnWidth: 0.7,
            defaults: {
                padding: '0 0 0 10'
            },
            items: [{
                xtype: 'radio',
                reference: 'routerRadio',
                name: 'configType',
                inputValue: 'ROUTER',
                boxLabel: '<strong>' + 'Router'.t() + '</strong>',
                padding: 0,
                bind: {
                    value: '{internal.configType !== "BRIDGED"}'
                },
                listeners: {
                    change: 'setConfigType'
                }
            }, {
                xtype: 'component',
                margin: '0 0 10 0',
                html: 'This is recommended if the external port is plugged into the internet connection. This enables NAT and DHCP.'.t()
            }, {
                xtype: 'textfield',
                labelWidth: 150,
                width: 350,
                labelAlign: 'right',
                fieldLabel: 'Internal Address'.t(),
                vText: 'Please enter a valid Network  Address'.t(),
                vtype: 'ipAddress',
                allowBlank: false,
                msgTarget: 'side',
                maskRe: /(\d+|\.)/,
                disabled: true,
                value: '192.168.1.1',
                validationEvent: 'blur',
                bind: { value: '{internal.v4StaticAddress}', disabled: '{!routerRadio.checked}' }
            }, {
                labelWidth: 150,
                width: 350,
                labelAlign: 'right',
                fieldLabel: 'Internal Netmask'.t(),
                xtype: 'combo',
                store: Util.v4NetmaskList,
                queryMode: 'local',
                triggerAction: 'all',
                disabled: true,
                editable: false,
                bind: { value: '{internal.v4StaticPrefix}', disabled: '{!routerRadio.checked}' }
            }, {
                disabled: true,
                fieldLabel: 'DHCP Server'.t(),
                xtype: 'radiogroup',
                id: 'DhcpServer',
                labelWidth: 150,
                labelAlign: 'right',
                width: 350,
                layout: { type: 'vbox' },
                simpleValue: true,
                bind: {
                    value: '{internal.dhcpType}', 
                    disabled: '{!routerRadio.checked}'
                },
                items: [
                    { boxLabel: 'Enabled'.t(),  inputValue: 'SERVER' },
                    { boxLabel: 'Disabled'.t(), inputValue: 'DISABLED' }
                ]
            }]
        }, {
            xtype: 'component',
            columnWidth: 0.3,
            margin: 20,
            html: '<img src="/skins/' + rpc.skinName + '/images/admin/wizard/router.png"/>'
        }]
    }, {
        xtype: 'container',
        margin: '10 0 0 0',
        layout: {
            type: 'column',
        },
        items: [{
            xtype: 'container',
            columnWidth: 0.7,
            defaults: {
                padding: '0 0 0 10'
            },
            items: [{
                xtype: 'radio',
                reference: 'bridgeRadio',
                name: 'configType',
                inputValue: 'BRIDGED',
                boxLabel: '<strong>' + 'Transparent Bridge'.t() + '</strong>',
                padding: 0,
                bind: {
                    value: '{internal.configType === "BRIDGED"}'
                },
                listeners: {
                    change: 'setConfigType'
                }
            }, {
                xtype: 'component',
                margin: '0 0 10 0',
                html: 'This is recommended if the external port is plugged into a firewall/router. This bridges Internal and External and disables DHCP.'.t()
            }]
        }, {
            xtype: 'component',
            columnWidth: 0.3,
            margin: 20,
            html: '<img src="/skins/' + rpc.skinName + '/images/admin/wizard/bridge.png"/>'
        }]
    }],

    listeners: {
        activate: 'getInterface',
        save: 'onSave'
    },

    controller: {
        getInterface: function () {
            var me = this, vm = me.getViewModel(),
                interfaces = vm.get('networkSettings.interfaces.list'),
                // first nonWAN is internal interface
                internal = Ext.Array.findBy(interfaces, function (intf) {
                    return !intf.isWan;
                });

            if (!internal) {
                Ext.Msg.show({
                    title: 'Warning!',
                    message: 'No internal interfaces found. Do you want to continue the setup?',
                    buttons: Ext.Msg.YESNO,
                    icon: Ext.Msg.QUESTION,
                    fn: function (btn) {
                        if (btn === 'yes') {
                            me.getView().up('setupwizard').down('#nextBtn').click();
                        } else {
                            // if no is pressed
                        }
                    }
                });
            } else {
                me.initialConfigType = internal.configType;
                me.initialv4Address = internal.v4StaticAddress;
                me.initialv4Prefix = internal.v4StaticPrefix;
                me.initialDhcpType = internal.dhcpType;
            }
            vm.set('internal', internal);
        },

        setConfigType: function (radio) {
            var me = this, vm = me.getViewModel();
            if (radio.checked) {
                if (radio.inputValue === 'BRIDGED') {
                    vm.set('internal.configType', 'BRIDGED');
                } else {
                    vm.set('internal.configType', 'ADDRESSED');
                    vm.set('internal.v4configType', 'STATIC');
                }
            }
        },

        warnAboutDisappearingAddress: function() {
            var me = this, vm = me.getViewModel();
            var firstWan, firstWanStatus, newSetupLocation;

            // get firstWan settings & status
            firstWan = Ext.Array.findBy(vm.get('networkSettings.interfaces.list'), function (intf) {
                return intf.isWan && intf.configType !== 'DISABLED';
            });

            // firstWan must exist
            if (!firstWan || !firstWan.interfaceId) { return; }

            try {
                firstWanStatus = rpc.networkManager.getInterfaceStatus(firstWan.interfaceId);
            } catch (e) {
                Util.handleException(e);
            }

            // and the first WAN has a address
            if (!firstWanStatus || !firstWanStatus.v4Address) { return; }

            //Use Internal Address instead of External Address
            newSetupLocation = window.location.href.replace(vm.get('internal.v4StaticAddress'), firstWanStatus.v4Address);
            rpc.keepAlive = function () {}; // prevent keep alive
            Ext.MessageBox.wait('Saving Internal Network Settings'.t() + '<br/><br/>' +
                                'The Internal Address is no longer accessible.'.t() + '<br/>' +
                                Ext.String.format('You will be redirected to the new setup address: {0}'.t(), '<a href="' + newSetupLocation + '">' + newSetupLocation + '</a>') + '<br/><br/>' +
                                'If the new location is not loaded after 30 seconds please reinitialize your local device network address and try again.'.t(), 'Please Wait'.t());
            Ext.defer(function () {
                window.location.href = newSetupLocation;
            }, 30000);
        },

        warnAboutChangingAddress: function() {
            var me = this, vm = me.getViewModel();
            var newSetupLocation;

            newSetupLocation = window.location.href.replace(me.initialv4Address, vm.get('internal.v4StaticAddress'));
            rpc.keepAlive = function () {}; // prevent keep alive
            Ext.MessageBox.wait('Saving Internal Network Settings'.t() + '<br/><br/>' +
                                Ext.String.format('The Internal Address is changed to: {0}'.t(), vm.get('internal.v4StaticAddress')) + '<br/>' +
                                Ext.String.format('The changes are applied and you will be redirected to the new setup address: {0}'.t(), '<a href="' + newSetupLocation + '">' + newSetupLocation + '</a>') + '<br/><br/>' +
                                'If the new location is not loaded after 30 seconds please reinitialize your local device network address and try again.'.t(), 'Please Wait'.t());
            Ext.defer(function () {
                window.location.href = newSetupLocation;
            }, 30000);

        },

        onSave: function (cb) {
            var me = this, vm = me.getViewModel();

            // if settings are invalid do not save
            if (!me.getView().isValid()) { return; }

            // no changes made - continue to next step
            if ( me.initialConfigType === vm.get('internal.configType') &&
                 me.initialv4Address === vm.get('internal.v4StaticAddress') &&
                 me.initialv4Prefix === vm.get('internal.v4StaticPrefix') &&
                 me.initialDhcpType === vm.get('internal.dhcpType')) {
                cb();
                return;
            }

            // BRIDGED (bridge mode)
            if (vm.get('internal.configType') === 'BRIDGED') {
                //If using internal address - redirect to external since internal address is vanishing
                if (window.location.hostname === vm.get('internal.v4StaticAddress')) {
                    me.warnAboutDisappearingAddress();
                }
            } else { // ADDRESSED (router)
                // set these to null so new values will automatically be calculated based on current address
                vm.set('internal.dhcpRangeStart', null);
                vm.set('internal.dhcpRangeEnd', null);
                //If using internal address and it is changed in this step redirect to new internal address
                if (window.location.hostname == me.initialv4Address && me.initialv4Address != vm.get('internal.v4StaticAddress')) {
                    me.warnAboutChangingAddress();
                }
            }

            // save settings and continue to next step
            Ung.app.loading('Saving Internal Network Settings'.t());
            rpc.networkManager.setNetworkSettings(function (result, ex) {
                Ung.app.loading(false);
                if (ex) { Util.handleException(ex); return; }
                cb();
            }, vm.get('networkSettings'));
        }
    }
});
Ext.define('Ung.Setup.Internet', {
    extend: 'Ext.form.Panel',
    alias: 'widget.Internet',

    title: 'Internet Connection'.t(),
    description: 'Configure the Internet Connection'.t(),

    layout: {
        type: 'vbox',
        align: 'stretch',
    },

    border: 1,
    items: [{
        xtype: 'component',
        margin: '0 0 10 0',
        hidden: rpc.setup.getRemoteReachable(),
        html: '<p>' + "No Internet Connection..! Click on 'Test Connectivity' to verify.".t() + '</p>'
    }, {
        xtype: 'container',
        layout: {
            type: 'hbox',
        },
        items:[{
            xtype: 'container',
            // margin: '50 20 0 0',
            width: 300,
            layout: {
                type: 'vbox',
                align: 'stretch'
            },
            hidden: true,
            bind: {
                hidden: '{!wan}'
            },
            items: [{
                xtype: 'component',
                cls: 'sectionheader',
                margin: '0 0 10 0',
                html: 'Configuration Type'.t()
            }, {
                xtype: 'radiogroup',
                // fieldLabel: 'Configuration Type'.t(),
                // labelWidth: 160,
                labelAlign: 'right',
                simpleValue: true,
                layout: { type: 'hbox' },
                defaults: { padding: '1 15 1 0' },
                items: [
                    { boxLabel: '<strong>' + 'Auto (DHCP)'.t() + '</strong>', inputValue: 'AUTO' },
                    { boxLabel: '<strong>' + 'Static'.t() + '</strong>', inputValue: 'STATIC' },
                    { boxLabel: '<strong>' + 'PPPoE'.t() + '</strong>', inputValue: 'PPPOE' }
                ],
                bind: {
                    value: '{wan.v4ConfigType}'
                }
            }, {
                xtype: 'button',
                margin: 10,
                text: 'Renew DHCP'.t(),
                iconCls: 'fa fa-refresh',
                handler: 'renewDhcp', // renew DHCP and refresh status
                bind: {
                    hidden: '{wan.v4ConfigType !== "AUTO"}'
                }
            }, {
                xtype: 'container',
                width: 200,
                margin: '0 10',
                layout: {
                    type: 'vbox',
                    align: 'stretch'
                },
                hidden: true,
                bind: {
                    hidden: '{wan.v4ConfigType !== "STATIC"}'
                },
                defaults: {
                    xtype: 'textfield',
                    labelAlign: 'top',
                    msgTarget: 'side',
                    validationEvent: 'blur',
                    maskRe: /(\d+|\.)/,
                    vtype: 'ip4Address',
                    disabled: true,
                    bind: {
                        disabled: '{wan.v4ConfigType !== "STATIC"}'
                    }
                },
                items: [{
                    fieldLabel: 'IP Address'.t(),
                    allowBlank: false,
                    bind: { value: '{wan.v4StaticAddress}' }
                }, {
                    fieldLabel: 'Netmask'.t(),
                    xtype: 'combo',
                    store: Util.v4NetmaskList,
                    queryMode: 'local',
                    triggerAction: 'all',
                    value: 24,
                    bind: { value: '{wan.v4StaticPrefix}' },
                    editable: false,
                    allowBlank: false,
                    vtype: 'ipAddress'
                }, {
                    fieldLabel: 'Gateway'.t(),
                    allowBlank: false,
                    bind: { value: '{wan.v4StaticGateway}' }
                }, {
                    fieldLabel: 'Primary DNS'.t(),
                    allowBlank: false,
                    bind: { value: '{wan.v4StaticDns1}' }
                }, {
                    xtype: 'textfield',
                    vtype: 'ipAddress',
                    name: 'dns2',
                    fieldLabel: 'Secondary DNS (optional)'.t(),
                    allowBlank: true,
                    bind: { value: '{wan.v4StaticDns2}' }
                }]
            }, {
                xtype: 'container',
                width: 200,
                margin: '0 10',
                layout: {
                    type: 'vbox',
                    align: 'stretch'
                },
                hidden: true,
                bind: {
                    hidden: '{wan.v4ConfigType !== "PPPOE"}'
                },
                defaults: {
                    xtype: 'textfield',
                    labelAlign: 'top',
                    allowBlank: false,
                    disabled: true,
                    bind: {
                        disabled: '{wan.v4ConfigType !== "PPPOE"}'
                    }
                },
                items: [{
                    fieldLabel: 'Username'.t(),
                    bind: { value: '{wan.v4PPPoEUsername}' }
                }, {
                    inputType: 'password',
                    fieldLabel: 'Password'.t(),
                    bind: { value: '{wan.v4PPPoEPassword}' }
                }]
            }]
        }, {
            xtype: 'container',
            margin: '50 20 0 0',
            width: 300,
            hidden: true,
            bind: {
                hidden: '{!wan}'
            },
            layout: {
                type: 'vbox',
                // align: 'stretch'
            },
            defaults: {
                xtype: 'displayfield',
                // labelWidth: 170,
                // labelAlign: 'right',
                // margin: 0
            },
            items: [{
                xtype: 'component',
                cls: 'sectionheader',
                margin: '0 0 10 0',
                html: 'Status'.t()
            }, {
                fieldLabel: 'IP Address'.t(),
                bind: { value: '{wanStatus.v4Address}' }
            }, {
                fieldLabel: 'Netmask'.t(),
                bind: { value: '/{wanStatus.v4PrefixLength} - {wanStatus.v4Netmask}' }
            }, {
                fieldLabel: 'Gateway'.t(),
                bind: { value: '{wanStatus.v4Gateway}' }
            }, {
                fieldLabel: 'Primary DNS'.t(),
                bind: { value: '{wanStatus.v4Dns1}' }
            }, {
                fieldLabel: 'Secondary DNS'.t(),
                bind: { value: '{wanStatus.v4Dns2}' }
            }, {
                xtype: 'button',
                text: 'Test Connectivity'.t(),
                margin: '10 0 0 0',
                iconCls: 'fa fa-globe',
                handler: 'onSave'
            }]
        }]
    },{
        // In Remote mode, allow Local as a backup if Internet fails.  Disabled by default.
        xtype: 'container',
        margin: '50 0 0 0',
        layout: {
            type: 'vbox',
            align: 'center'
        },
        hidden: true,
        bind: {
            hidden: '{remoteTestPassed}'
        },
        items: [{
            xtype: 'component',
            html: 'You may continue configuring your Internet connection or run the Setup Wizard locally.'.t()
        },{
            xtype: 'button',
            scale: 'medium',
            focusable: false,
            margin: '10 0 0 0',
            iconCls: 'fa fa-play fa-lg',
            text: "Run Setup Wizard Locally".t(),
            handler: 'resetWizard',
        }]
    }],

    listeners: {
        activate: 'getSettings',
        save: 'onSave',
    },

    controller: {

        getSettings: function () {
            var me = this, vm = me.getViewModel(),
                firstWan = null;

            if(rpc.remote){
                // If remote and we are here, disable the next button.
                vm.set('nextDisabled', true);
                vm.set('remoteTestPassed', true);
            }

            rpc.networkManager.getNetworkSettings(function (settings, ex) {
                if (ex) { Util.handleException('Unable to fetch Network Settings.'.t()); return; }
                vm.set('networkSettings', settings);

                // get the first wan
                firstWan = Ext.Array.findBy(settings.interfaces.list, function (intf) {
                    return (intf.isWan && intf.configType !== 'DISABLED');
                });
                vm.set('wan', firstWan);
                if (!firstWan) { return; }
                me.getInterfaceStatus();
            });
        },

        getInterfaceStatus: function () {
            var me = this, vm = me.getViewModel(),
                wan = vm.get('wan');

            rpc.networkManager.getInterfaceStatus(function (status, ex) {
                if (ex) { Util.handleException('Unable to get WAN status.'.t()); return; }
                vm.set('wanStatus', status);
            }, wan.interfaceId);
        },

        renewDhcp: function () {
            var me = this, vm = me.getViewModel(),
                wan = vm.get('wan');
            // save settings before
            Ung.app.loading('Saving settings ...'.t());
            rpc.networkManager.setNetworkSettings(function (response, ex) {
                if (ex) { Util.handleException('Unable to set Network Settings.'.t()); return; }
                // then force the DHCP lease renew just in case
                // setNetworkSettings is not guaranteed to restart networking
                Ung.app.loading('Renewing DHCP Lease...'.t());
                rpc.networkManager.renewDhcpLease(function (r, e) {
                    if (e) { Util.handleException(e); return; }
                    Ung.app.loading(false);
                    me.getSettings();
                }, wan.interfaceId);
            }, vm.get('networkSettings'));
        },

        testConnectivity: function (testType, cb) {
            var me = this,
                vm = me.getViewModel(),
                remote = rpc.remote;

            Ung.app.loading('Testing Connectivity...'.t());

            rpc.connectivityTester.getStatus(function (result, ex) {
                Ung.app.loading(false);
                if (ex) {
                    Ext.MessageBox.show({
                        title: 'Network Settings'.t(),
                        msg: 'Unable to complete connectivity test, please try again.'.t(),
                        width: 300,
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.INFO
                    });
                    return;
                }

                // build test fail message if any
                var message = null;
                var nextDisabled = true;
                if (result.tcpWorking === false  && result.dnsWorking === false) {
                    message = 'Warning! Internet tests and DNS tests failed.'.t();
                } else if (result.tcpWorking === false) {
                    message = 'Warning! DNS tests succeeded, but Internet tests failed.'.t();
                } else if (result.dnsWorking === false) {
                    message = 'Warning! Internet tests succeeded, but DNS tests failed.'.t();
                } else {
                    if(remote){
                        Util.setRpcJsonrpc("setup");
                        var remoteReachable = rpc.setup.getRemoteReachable();
                        Util.setRpcJsonrpc("admin");
                        if(remoteReachable == false){
                            message = 'Unable to reach ETM Dashboard!'.t();
                        }else{
                            nextDisabled = false;
                        }
                    }else{
                        message = null;
                        nextDisabled = false;
                    }
                }
                if(remote){
                    vm.set('nextDisabled', nextDisabled);
                }
                if(remote && message != null){
                    vm.set('remoteTestPassed', false);
                    message += '<br/><br/><br/>' +
                    'You may continue configuring your Internet connection or run the Setup Wizard locally.'.t();
                }

                if (testType === 'manual') {
                    // on manual test just show the message
                    Ext.MessageBox.show({
                        title: 'Internet Status'.t(),
                        msg: message || 'Success!'.t(),
                        width: 300,
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.INFO
                    });
                } else {
                    // on next step just move forward if no failures
                    if (!message) {
                        cb();
                        return;
                    }

                    // otherwise show a warning message
                    var warningText = message + '<br/><br/>' + 'It is recommended to configure valid Internet settings before continuing. Try again?'.t();
                    Ext.Msg.confirm('Warning:'.t(), warningText, function (btn) {
                        if (btn === 'yes') {
                            return;
                        }
                        cb();
                    });
                }

                me.getInterfaceStatus();
            });
        },

        // ??? move to util?
        resetWizard: function() {
            var me = this, vm = me.getViewModel();

            rpc.wizardSettings.steps = [];
            rpc.jsonrpc.UvmContext.setRemoteSetup(false);
            rpc.jsonrpc.UvmContext.setWizardSettings(function (result, ex) {
                if (ex) { Util.handleException(ex); return; }
                window.location.href = '/setup/index.do';
            }, rpc.wizardSettings);
        },

        onSave: function (cb) {
            var me = this, vm = this.getViewModel(),
                wan = vm.get('wan');

            if (!wan) { cb(); return; }

            // validate any current form first
            if (!me.getView().isValid()) {
                Ext.MessageBox.alert('Invalid settings'.t(), 'Some fields have invalid values.'.t());
                return;
            }

            if (wan.v4ConfigType === 'AUTO' || wan.v4ConfigType === 'PPPOE') {
                wan.v4StaticAddress = null;
                wan.v4StaticPrefix = null;
                wan.v4StaticGateway = null;
                wan.v4StaticDns1 = null;
                wan.v4StaticDns2 = null;
            }
            if (wan.v4ConfigType === 'STATIC') {
                wan.v4NatEgressTraffic = true;
            }
            if (wan.v4ConfigType === 'PPPOE') {
                wan.v4NatEgressTraffic = true;
                wan.v4PPPoEUsePeerDns = true;
            }

            // save
            Ung.app.loading('Saving settings ...'.t());
            rpc.networkManager.setNetworkSettings(function (response, ex) {
                if (ex) { Util.handleException(ex); return; }
                me.testConnectivity(Ext.isFunction(cb) ? 'auto' : 'manual', function () {
                    cb();
                });
            }, vm.get('networkSettings'));
        }
    }





});
Ext.define('Ung.Setup.License', {
    extend: 'Ext.form.Panel',
    alias: 'widget.License',

    title: 'License'.t(),
    description: 'License'.t(),

    layout: {
        type: 'vbox',
        align: 'middle'
    },

    defaults: {
        layout: {
            type: 'vbox',
            align: 'stretch',
        }
    },

    viewModel: {
        data: {
            nextStep: null,
            remoteEulaSrc: '',
        }
    },

    items: [{
        xtype: 'container',
        width: 600,
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        items: [{
            xtype: 'component',
            style: { 
                "word-wrap": 'break-word',
                "text-align": "center",
                "margin-bottom": '5px'
            },
            html: '<p>' + "To continue installing and using this software, you must agree to the terms and conditions of the software license agreement. Please review the whole license agreement by navigating to the provided website link and scrolling through to the end of the agreement.".t()+'</p>'
        }, {
            xtype: 'component',
            style: { 
                "margin-top": '5px',
                "word-wrap": 'break-word',
                "text-align": "center"
            },
            // NOTE: These placeholder urls are filled in for uri translations in afterRender.
            html: '<p>' + Ext.String.format('The license is available at {0}'.t(), '<a style="color: blue;" id="licenseUrl" href="https://edge.arista.com/legal" target="_blank">https://edge.arista.com/legal</a>') + '</p>'
        }, {
            xtype: 'component',
            style: { 
                "margin-top": '5px',
                "word-wrap": 'break-word',
                "text-align": "center",
                "font-weight": "bold"
            },
            html: '<p>' + "After completing the setup, legal links can also be viewed from the About page.".t() + '</p>'
        }, {
            xtype: 'container',
            margin: '8 0',
            layout: {
                type: 'hbox',
                pack: 'middle'
            },
            defaults: {
                xtype: 'button',
                margin: 8
            },
            items: [{
                text: 'Disagree',
                handler: 'onDisagree'
            }, {
                text: 'Agree',
                handler: 'onContinue'
            }]
        }]
    }],

    listeners: {
        save: 'onSave'
    },

    controller: {
        onSave: function(cb){
            Util.setRpcJsonrpc("setup");
            cb();
        },

        timer: null,
        clearTimer: function(){
            if (this.timer) {
                clearTimeout(this.timer);
                this.timer = null;
            }
        },

        handleFail: function(){
            this.onload = this.onabort = this.onerror = function() {};
            this.ownerCmp.clearTimer();
        },
        afterRender: function(){
            this.remoteEulaSrc = rpc.licenseAgreementUrl;
            this.remoteImage = rpc.licenseTestUrl;
            var me = this,
                vm = this.getViewModel(),
                hyperlink = document.getElementById('licenseUrl'),
                img = new Image(0,0);
            
            hyperlink.href = this.remoteEulaSrc;
            hyperlink.innerText = this.remoteEulaSrc;

            img.ownerCmp = me;
            vm.set('nextStep', "");

            img.onerror = img.onabort = me.handleFail;
            img.onload = function(){
                me.clearTimer();
            };
            img.src = me.remoteImage;
            me.timer = setTimeout( function(image){
                return function(){
                    me.handleFail.call(image);
                };
            }(img), 1000);
        },
        onContinue: function(){
            this.getView().up('setupwizard').getController().onNext();
        },
        onDisagree: function(){
            window.location.reload();
        }
    }

});
Ext.define('Ung.Setup.ServerSettings', {
    extend: 'Ext.form.Panel',
    alias: 'widget.ServerSettings',

    title: 'Server Settings'.t(),
    description: 'Configure the Server'.t(),

    layout: {
        type: 'hbox',
        align: 'begin',
        pack: 'center'
    },

    defaults: {
        layout: {
            type: 'vbox',
            align: 'stretch',
        }
    },

    items: [{
        xtype: 'container',
        margin: '100 20 0 0',
        width: 200,
        defaults: {
            labelAlign: 'top'
        },
        items: [{
            xtype: 'component',
            cls: 'sectionheader',
            // margin: '30 0 0 0',
            html: 'Admin account'.t()
        }, {
            xtype: 'label',
            margin: '5 0',
            style: { color: '#999' },
            html: 'Choose a password for the <strong>admin</strong> account'.t()
        }, {
            xtype: 'textfield',
            inputType: 'password',
            fieldLabel: 'Password'.t(),
            name: 'password',
            id: 'settings_password',
            allowBlank: false,
            minLength: 3,
            minLengthText: Ext.String.format('The password is shorter than the minimum {0} characters.'.t(), 3)
        }, {
            xtype: 'textfield',
            inputType: 'password',
            fieldLabel: 'Confirm Password'.t(),
            name: 'confirmPassword',
            allowBlank: false,
            comparePasswordField: 'settings_password',
            vtype: 'passwordConfirmCheck'
        }, {
            xtype: 'textfield',
            inputType: 'text',
            name: 'adminEmail',
            fieldLabel: 'Admin Email'.t(),
            allowBlank: true,
            vtype: 'email',
            value: rpc.adminEmail
        }, {
            xtype: 'label',
            style: { color: '#999', fontSize: '11px' },
            html: 'Administrators receive email alerts and report summaries.'.t()
        }]
    }, {
        xtype: 'container',
        width: 300,
        margin: '100 0 0 20',
        defaults: {
            labelAlign: 'top'
        },
        items: [{
            xtype: 'component',
            cls: 'sectionheader',
            html: 'Install Type'.t()
        }, {
            xtype: 'label',
            margin: '5 0',
            style: { color: '#999' },
            html: 'Install type determines the optimal default settings for this deployment.'.t()
        }, {
            xtype: 'combo',
            name: 'installType',
            value: '',
            allowBlank: false,
            fieldLabel: 'Choose Type'.t(),
            emptyText: 'Select'.t(),
            editable: false,
            queryMode: 'local',
            store: [
                ['school', 'School'.t()],
                ['college', 'Higher Education'.t()],
                ['government', 'State & Local Government'.t()],
                ['fedgovernment', 'Federal Government'.t()],
                ['nonprofit', 'Nonprofit'.t()],
                ['retail', 'Hospitality & Retail'.t()],
                ['healthcare', 'Healthcare'.t()],
                ['financial', 'Banking & Financial'.t()],
                ['home', 'Home'.t()],
                ['student', 'Student'.t()],
                ['other', 'Other'.t()]
            ]
        }, {
            xtype: 'component',
            cls: 'sectionheader',
            margin: '30 0 0 0',
            html: 'Timezone'.t()
        }, {
            xtype: 'combo',
            name: 'timezone',
            editable: false,
            store: rpc.timezones,
            margin: '5 0',
            queryMode: 'local',
            value: rpc.timezoneID
        }]
    }],

    listeners: {
        save: 'onSave'
    },

    controller: {
        onSave: function (cb) {
            var me = this, form = me.getView(), values = form.getValues();

            if (!form.isValid()) { return; }

            Ung.app.loading('loading');
            rpc.setup = new JSONRpcClient('/setup/JSON-RPC').SetupContext; // to avoid invalid security nonce

            // set timezone
            if (rpc.timezoneID !== values.timezone) {
                rpc.setup.setTimeZone(function (result, ex) {
                    if (ex) { Ung.app.loading(false); Util.handleException(ex); return; }
                    rpc.timezoneID = values.timezone;
                    me.saveAdminPassword(function () { cb(); });
                }, values.timezone);
            } else {
                me.saveAdminPassword(function () { cb(); });
            }
        },

        saveAdminPassword: function (cb) {
            var values = this.getView().getValues();
            rpc.setup.setAdminPassword(function (result, ex) {
                if (ex) { Util.handleException(ex); return; } // Unable to save the admin password
                Util.authenticate(values.password, function () { cb(); });
            }, values.password, values.adminEmail, values.installType);
        }
    }





});
Ext.define('Ung.Setup.Wireless', {
    extend: 'Ext.form.Panel',
    alias: 'widget.Wireless',
    withValidation: false,
    title: 'Wireless Settings'.t(),
    description: 'Configure Wireless Settings'.t(),

    layout: {
        type: 'center'
    },
    items: [{
        xtype: 'container',
        width: 200,
        padding: '0 0 100 0',
        layout: {
            type: 'vbox',
            align: 'stretch'
        },
        defaults: {
            labelAlign: 'top',
            msgTarget: 'side',
            validationEvent: 'blur'
        },
        hidden: true,
        bind: {
            hidden: '{!wirelessSettings}'
        },
        items: [{
            xtype: 'component',
            cls: 'sectionheader',
            // margin: '30 0 0 0',
            html: 'Settings'.t()
        }, {
            xtype: 'textfield',
            fieldLabel: 'Network Name (SSID)'.t(),
            width: 350,
            maxLength: 30,
            maskRe: /[a-zA-Z0-9\-_=]/,
            bind: {
                value: '{wirelessSettings.ssid}'
            },
            allowBlank: false
        }, {
            xtype: 'combo',
            fieldLabel: 'Encryption'.t(),
            width: 300,
            editable: false,
            store: [['NONE', 'None'.t()], ['WPA1', 'WPA'.t()], ['WPA12', 'WPA / WPA2'.t()], ['WPA2', 'WPA2'.t()]],
            bind: {
                value: '{wirelessSettings.encryption}'
            }
        }, {
            xtype: 'textfield',
            fieldLabel: 'Password'.t(),
            inputType: 'password',
            width: 350,
            maxLength: 63,
            minLength: 8,
            maskRe: /[a-zA-Z0-9~@#%_=,\!\-\/\?\(\)\[\]\\\^\$\+\*\.\|]/,
            disabled: true,
            bind: {
                value: '{wirelessSettings.password}',
                disabled: '{wirelessSettings.encryption === "NONE"}'
            },
            validator: function (val) {
                if (!val || val.length < 8) {
                    return 'The wireless password must be at least 8 characters.'.t();
                }
                if (val === '12345678') {
                    return 'You must choose a new and different wireless password.'.t();
                }
                return true;
            },
            listeners: {
                disable: function (el) {
                    el.setValue('');
                }
            }
        }]
    }],

    listeners: {
        activate: 'getSettings',
        save: 'onSave'
    },

    controller: {

        getSettings: function () {
            var me = this, vm = me.getViewModel(),
                interfaces = vm.get('networkSettings.interfaces.list'),
                // first wireless interface
                wireless = Ext.Array.findBy(interfaces, function (intf) {
                    return intf.isWirelessInterface;
                });

            if (!wireless) {
                Ext.Msg.show({
                    title: 'Warning!',
                    message: 'No wireless interfaces found. Do you want to continue the setup?',
                    buttons: Ext.Msg.YESNO,
                    icon: Ext.Msg.QUESTION,
                    fn: function (btn) {
                        if (btn === 'yes') {
                            me.getView().up('setupwizard').down('#nextBtn').click();
                        } else {
                            // if no is pressed
                        }
                    }
                });
                return;
            }

            Ung.app.loading('Loading Wireless Settings ...');
            Ext.Deferred.sequence([
                me.getSsid,
                me.getEncryption,
                me.getPassword
            ]).then(function (result) {
                vm.set('wirelessSettings', {
                    ssid: result[0] || '',
                    encryption: result[1] || 'NONE',
                    password: (!result[2] || result[2] === '12345678') ? '' : result[2]
                });

                me.initialSettings = Ext.clone(vm.get('wirelessSettings'));

            }, function (ex) {
                Util.handleException(ex);
            }).always(function(){
                Ung.app.loading(false);
            });
        },

        getSsid: function () {
            var deferred = new Ext.Deferred();
            rpc.networkManager.getWirelessSsid(function (result, ex) {
                if (ex) { deferred.reject(ex); }
                deferred.resolve(result);
            });
            return deferred.promise;
        },

        getEncryption: function () {
            var deferred = new Ext.Deferred();
            rpc.networkManager.getWirelessEncryption(function (result, ex) {
                if (ex) { deferred.reject(ex); }
                deferred.resolve(result);
            });
            return deferred.promise;
        },

        getPassword: function () {
            var deferred = new Ext.Deferred();
            rpc.networkManager.getWirelessPassword(function (result, ex) {
                if (ex) { deferred.reject(ex); }
                deferred.resolve(result);
            });
            return deferred.promise;
        },

        onSave: function (cb) {
            var me = this, form = me.getView(), vm = me.getViewModel();

            // if invalid form show invalid fields
            if (!form.isValid()) { return; }

            // if valid but no changes made just move to next step
            if (Ext.Object.equals(me.initialSettings, vm.get('wirelessSettings'))) {
                cb(); return;
            }

            // otherwise save settings
            Ung.app.loading('Saving Settings'.t());
            rpc.networkManager.setWirelessSettings(function (result, ex) {
                Ung.app.loading(false);
                if (ex) { Util.handleException(ex); return; }
                cb();
            }, vm.get('wirelessSettings.ssid'),
            vm.get('wirelessSettings.encryption'),
            vm.get('wirelessSettings.password'));
        }
    }
});
// Legacy Setup Wizard application
Ext.define('Ung.Setup', {
    extend: 'Ext.app.Application',
    namespace: 'Ung',
    autoCreateViewport: false,
    name: 'Ung',
    rpc: null,
    mainView: 'Ung.Setup.Main',

    loading: function (msg) {
        this.getMainView().down('setupwizard').setLoading(msg);
    },

    launch: function () {
        // Configure steps if they're not defined.

        if (!rpc.wizardSettings.steps || rpc.wizardSettings.steps.length == 0) {
            // Wizard steps not defined.
            if(!rpc.remote){
                // Local configuration
                rpc.wizardSettings.steps = ['Welcome', 'License', 'ServerSettings', 'Interfaces', 'Internet', 'InternalNetwork', 'Wireless', 'AutoUpgrades', 'Complete'];
            }else{
                rpc.wizardSettings.steps = ['Welcome', 'Internet', 'Complete'];
            }
        }
        Ext.apply(Ext.form.field.VTypes, {
            ipAddress: function (val) {
                return val.match(this.ipAddressRegex);
            },
            ipAddressText: 'Please enter a valid IP Address',
            ipAddressRegex: /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/,

            passwordConfirmCheck: function (val, field) {
                var pass_original = Ext.getCmp(field.comparePasswordField);
                return val === pass_original.getValue();
            },
            passwordConfirmCheckText: 'Passwords do not match'.t(),

            ip4Address: function (val) {
                return val.match(this.ip4AddressRegex);
            },
            ip4AddressText: 'Invalid IPv4 Address.'.t(),
            ip4AddressRegex: /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
        });
    }
});

// New Setup Wizard application
Ext.define('Ung.SetupWizard', {
    extend: 'Ext.container.Viewport',

    viewModel: {
        data: {
            resuming: false,
            remoteReachable: null
        }
    },
    layout: 'fit',
    padding: 20,
    listeners: {
        afterrender: function (view) {
            view.setHtml('<iframe src="/console/setup/" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;"></iframe>');
        },
    }

});
