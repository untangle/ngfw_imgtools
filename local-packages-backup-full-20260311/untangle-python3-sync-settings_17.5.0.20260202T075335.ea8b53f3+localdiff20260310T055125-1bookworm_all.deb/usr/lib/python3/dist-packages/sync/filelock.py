import fcntl
import os
import time
from weakref import WeakValueDictionary


class FileLock:
    """
    Create a file lock. This file should only be used as a file lock.
    An advantage of using flock is that the lock is automatically released when the process ends.
    """

    _instances = WeakValueDictionary()
    _default_instance = None  # strong reference for the default

    def __new__(cls, file_lock_path="", singleton=True, default_lock=False):
        """
        Get the global lock file.

        :param str file_lock_path: should be in /var/lock/ and end with ".lock". an empty string will return the default lock
        :param bool singleton: Get a singleton instance of the lockfile
        :param bool default_lock: setting this to True will make this lock the one returned when called with and empty path
        """
        if not singleton:
            lock = super().__new__(cls)
            lock._init_fields(file_lock_path)
            return lock
        if not cls._instances:
            cls._instances = WeakValueDictionary()
        instance = cls._instances.get(str(file_lock_path))
        if not instance:
            instance = super().__new__(cls)
            instance._init_fields(file_lock_path)
            cls._instances[str(file_lock_path)] = instance
        if default_lock:
            # Make this the new default lock
            cls._instances[""] = instance
            cls._default_instance = instance
        return instance

    def _init_fields(self, file_lock_path="") -> None:
        """initialize fields"""
        self.file_lock_path = file_lock_path
        self.locked = False
        self.fd = 0

    def acquire(self, timeout=60) -> None:
        """
        Acquire the lock on the given file.
        The lock file can be created with this function.
        """
        dir_path = os.path.dirname(self.file_lock_path)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
        # Try to acquire the lock. On a failure, retry if not timed out.
        start_time = time.time()
        while True:
            fd = os.open(self.file_lock_path, os.O_RDWR | os.O_CREAT | os.O_TRUNC)
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self.locked = True
                self.fd = fd
                os.write(fd, self._content_str().encode())
                return
            except OSError:
                os.close(fd)
                if (time.time() - start_time) > timeout:
                    raise
                # Wait before retrying to acquire the lock
                time.sleep(1)

    def release(self) -> None:
        """
        Release the file lock on the file when locked.
        In this implementation, the file is only released by the process
        and not deleted (which is not necessary for this implementation).
        Deleting the file would require handling an OS race condition and
        would be non-atomic with the current acquire method.
        """
        if self.locked:
            self.locked = False
            fcntl.flock(self.fd, fcntl.LOCK_UN)
            os.close(self.fd)

    def __del__(self) -> None:
        """Release the file lock when this object is destroyed."""
        self.release()

    def _content_str(self) -> str:
        """
        lock file contents specified by
        https://refspecs.linuxfoundation.org/FHS_3.0/fhs/ch05s09.html
        """
        return f"{os.getpid():>10}\n"
