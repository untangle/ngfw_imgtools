import copy
import json
from uuid import uuid4

from sync import nftables_util


class RuleManager:
    """
    Used by a table manager to generate rules for a subsystem (eg.,ipsec, wireguard)
    """

    # Full settings path such as wan/policy_chains/name=user-wan-rules/rules
    # NOTE: IT should NOT contain search filters.
    settings_path = ""

    def get_settings_path(self):
        """
        Used by the manager caller to retrieve the rule list.
        """
        return self.settings_path

    def is_managed(self, rule_settings, settings_file):
        """
        Based on "ruleManager" value, match against derived class name.
        If matches, return True, otherwise return False.
        """
        match = False

        if "ruleManager" in rule_settings:
            match = rule_settings.get("ruleManager") == self.__class__.__name__

        return match

    def set_manager(self, rule_settings) -> None:
        """ """
        rule_settings["ruleManager"] = self.__class__.__name__

    def get_required_rules_list():
        """
        This method is a stub method and the child classes of the RuleManager should implement there own version of
        this mthod that should be used by create_or_update_rules method
        """
        return []

    def create_or_update_rules(self, settings_file) -> None:
        """
        Get current rules and build new rules from the rule manager.
        Strip all ruleId information and compare.  Then process as follows:
        Deletion
        -   If rule reference matches, and current rule is not found in new set, delete that rule from settings.
        Addition
        -   If new rule is not found in current rules, provide rule id, add the new rule to the appropriate path.
        If there is no change, don't make change.
        """
        # Get current settings
        current_rules_settings = settings_file.get_settings_by_path(self.get_settings_path())
        current_rules_stripped_settings = copy.deepcopy(current_rules_settings)
        self.strip_rule_ids_settings(current_rules_stripped_settings)

        # Build new settings
        new_rules_settings = self.get_required_rules_list(settings_file)
        new_rules_stripped_settings = copy.deepcopy(new_rules_settings)
        self.strip_rule_ids_settings(new_rules_stripped_settings)

        new_rules_insert_stripped_settings = copy.deepcopy(new_rules_settings)
        self.strip_rule_ids_settings(new_rules_insert_stripped_settings, preserve_enabled=True)

        deleted_rules_indexes = []
        for index, current_rule_settings in enumerate(current_rules_stripped_settings):
            if self.is_managed(current_rule_settings, settings_file) is False:
                # Only consider for deletion if its reference matches the manager
                continue

            found = False
            for new_rule_settings in new_rules_stripped_settings:
                found = json.dumps(current_rule_settings, sort_keys=True) == json.dumps(
                    new_rule_settings, sort_keys=True
                )
                if found is True:
                    break

            if found is False:
                deleted_rules_indexes.append(index)

        deleted_rules_indexes.reverse()
        for index in deleted_rules_indexes:
            del current_rules_settings[index]

        add_rules_settings = []
        for index, new_rule_settings in enumerate(new_rules_stripped_settings):
            found = False
            for current_index, current_rule_settings in enumerate(current_rules_stripped_settings):
                found = json.dumps(current_rule_settings, sort_keys=True) == json.dumps(
                    new_rule_settings, sort_keys=True
                )
                if found is True:
                    # Change to reflect generated enabled flag.  This is important
                    # because that is where attributes like enabled/disabled are determined
                    if current_index < len(current_rules_settings) and index < len(
                        new_rules_insert_stripped_settings
                    ):
                        current_rules_settings[current_index]["enabled"] = (
                            new_rules_insert_stripped_settings[index]["enabled"]
                        )
                    break
            if found is False:
                add_rules_settings.append(new_rules_insert_stripped_settings[index])

        add_rules_settings.reverse()
        self.add_rule_ids_settings(add_rules_settings)
        for rule_settings in add_rules_settings:
            current_rules_settings.insert(0, rule_settings)

    def strip_rule_ids_settings(self, rules, preserve_enabled=False, current_rule_id=None) -> None:
        """ """
        if current_rule_id is not None:
            current_nft_rule_id = nftables_util.format_guid_for_nft(current_rule_id)
        else:
            current_nft_rule_id = None

        if isinstance(rules, list):
            for rule in rules:
                self.strip_rule_ids_settings(rule, preserve_enabled, current_rule_id)
        elif isinstance(rules, dict):
            if "enabled" in rules and preserve_enabled is not True:
                # Disable enabled to be "neutral" for the purposes of comparison.
                # Without it we'll not preserve rule order.
                rules["enabled"] = None
            if "ruleId" in rules:
                if (
                    rules["ruleId"] is not None
                    and rules["ruleId"] != ""
                    and rules["ruleId"] != "__rule_id__"
                ):
                    current_rule_id = rules["ruleId"]
                    current_nft_rule_id = nftables_util.format_guid_for_nft(current_rule_id)
                else:
                    rules["ruleId"] = "__rule_id__"

            for key, value in rules.items():
                if isinstance(value, (dict, list)):
                    self.strip_rule_ids_settings(value, preserve_enabled, current_rule_id)
                elif isinstance(value, str):
                    if current_rule_id is not None:
                        value = value.replace(current_rule_id, "__rule_id__")
                    if current_nft_rule_id is not None:
                        value = value.replace(current_nft_rule_id, "__nft_rule_id__")
                    rules[key] = value

    def add_rule_ids_settings(self, rules, current_rule_id=None) -> None:
        """
        Walk through single or list of rules and update with rule id fields.
        """
        if current_rule_id is not None:
            current_nft_rule_id = nftables_util.format_guid_for_nft(current_rule_id)
        else:
            current_nft_rule_id = None

        if isinstance(rules, list):
            for rule in rules:
                self.add_rule_ids_settings(rule, current_rule_id)
        elif isinstance(rules, dict):
            if "ruleId" in rules:
                current_rule_id = rules["ruleId"]
                if current_rule_id is None or current_rule_id in ("", "__rule_id__"):
                    # Empty or with template name; populate with new id
                    current_rule_id = uuid4().__str__()
                    current_nft_rule_id = nftables_util.format_guid_for_nft(current_rule_id)
                    rules["ruleId"] = current_rule_id

            for key, value in rules.items():
                if isinstance(value, (dict, list)):
                    self.add_rule_ids_settings(value, current_rule_id)
                elif isinstance(value, str):
                    if current_rule_id is not None:
                        value = value.replace("__rule_id__", current_rule_id)
                    if current_nft_rule_id is not None:
                        value = value.replace("__nft_rule_id__", current_nft_rule_id)
                    rules[key] = value
