import os

from sync import Manager, registrar
from sync.common import Logger
from sync.hosts_util import HostsUtil
from sync.resolver_util import ResolverUtil

logger = Logger.getInstance()


class SystemManager(Manager):
    resolv_filename = "/etc/resolv.conf"
    cont_env_file = "/run/.containerenv"
    waf_install_file = "/usr/share/untangle/waf/instance"
    waf_install_type = ""
    hostname_filename = "/etc/hostname"
    pre_network_hook_filename = "/etc/untangle/pre-network-hook.d/001-sethostname"

    def initialize(self) -> None:
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.cont_env_file, None, self)
        registrar.register_file(self.resolv_filename, None, self)
        registrar.register_file(self.hostname_filename, "update-hostname", self)
        registrar.register_file(self.pre_network_hook_filename, "restart-networking", self)
        with open(self.waf_install_file) as file:
            self.waf_install_type = file.read()

    def sanitize_settings(self, settings_file):
        """sanitizes settings for system manager"""
        logger.info("Sanitizing settings")
        if "hostName" not in settings_file.settings:
            settings_file.settings["hostName"] = "untangle-waf"
        if self.waf_install_type.startswith("docker"):
            self.write_cont_env(self.cont_env_file)
        return super().sanitize_settings(settings_file)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """Sync settings for system manager"""
        logger.info("Syncing settings")

        ResolverUtil.write_resolve_file(
            self.resolv_filename,
            prefix,
            None,
            settings_file.settings["server"]["advancedOptions"]["dnsServer"]["value"],
            True,
        )
        HostsUtil.write_hostname_file(self.hostname_filename, settings_file.settings, prefix)
        HostsUtil.write_pre_network_hook_file(
            self.pre_network_hook_filename, settings_file.settings, prefix
        )

    def write_cont_env(self, file) -> None:
        filename = file
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        file = open(filename, "w+")
        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))


registrar.register_manager(SystemManager())
