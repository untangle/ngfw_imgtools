"""This class is responsible for writing out the Error handling conf file"""

import os

from sync import Manager, registrar
from sync.common import Logger

logger = Logger.getInstance()


class ErrorsManager(Manager):
    errors_conf = "/etc/modsecurity.d/errors.conf"

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.errors_conf, "restart-nginx", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        self.create_error_page_settings(settings_file)

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings for ip lists"""
        logger.info("Sanitizing settings")
        if "errorPages" not in settings_file.settings:
            settings_file = self.create_error_page_settings(settings_file)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """sync settings"""
        self.write_errors_to_conf(settings_file, prefix)

    def create_error_page_settings(self, settings_file):
        """create errorPages settings in settings_file. Empty object with custom html paths"""
        """
        This is a placeholder for custom 403 (or other) pages
        errorPages = {
            403: '/custom_403.html'
        }
        """
        error_pages = {}
        settings_file.settings["errorPages"] = error_pages
        return settings_file

    def write_errors_to_conf(self, settings_file, prefix) -> None:
        """write error handlging to errors.conf"""
        filename = prefix + self.errors_conf
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n\n\n")

        self.write_50xerror_to_conf(settings_file, file)
        self.write_403error_to_conf(settings_file, file)

        file.write("\n\n")
        file.flush()
        file.close()

    def write_403error_to_conf(self, settings_file, conf_file) -> None:
        """write 403 error handling"""
        # todo write custom 403 page to /403.html
        conf_file.write("error_page 403 = @403;\n")
        conf_file.write("location @403 {\n")
        conf_file.write('\tset $args "?";\n')
        conf_file.write("\tset $args $args&ip=$remote_addr;\n")
        conf_file.write("\tset $args $args&url=$scheme://$host$request_uri;\n")
        conf_file.write("\tproxy_pass http://127.0.0.1:8585/error/403$args;\n")
        conf_file.write("}\n\n")

    def write_50xerror_to_conf(self, settings_file, conf_file) -> None:
        """write 50x error handling"""
        conf_file.write("error_page 500 502 503 504  /50x.html;\n")
        conf_file.write("location = /50x.html {\n")
        conf_file.write("\troot /usr/share/nginx/html;\n")
        conf_file.write("}\n\n")


registrar.register_manager(ErrorsManager())
