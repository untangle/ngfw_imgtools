import os

from sync import Manager, network_util, registrar
from sync.common import Logger

logger = Logger.getInstance()


class IptablesManager(Manager):
    """
    Manage iptables rules
    """

    initalized = False

    # Paths for files
    iptables_rules_path = "/etc/untangle/waf/iptables-rules.d/"

    # 8585 is UI admin port.
    # 22 is for SSH.
    admin_ports = [8585, 22]

    # iptables commands by IP family
    # These are written as variables that are set from the calling script
    iptables_commands = {"ipv4": "${IPTABLES}", "ipv6": "${IP6TABLES}"}

    @classmethod
    def static_init(cls) -> None:
        """
        Create static class filename variables from paths
        """
        IptablesManager.initialized = True
        IptablesManager.flush_rules_filename = IptablesManager.iptables_rules_path + "010-flush"
        IptablesManager.listener_rules_filename = (
            IptablesManager.iptables_rules_path + "240-listener"
        )

    def initialize(self) -> None:
        """
        Initialize
        """
        registrar.register_settings_file("settings", self)
        registrar.register_file(IptablesManager.flush_rules_filename, "restart-iptables", self)
        registrar.register_file(IptablesManager.listener_rules_filename, "restart-iptables", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Sync settings
        """
        self.write_flush_rules(settings_file.settings, prefix)
        self.write_listener_rules(settings_file.settings, prefix)

    def write_flush_rules(self, settings, prefix) -> None:
        """
        Create iptables flush rules to clear all tables, chains, rules, etc.
        """
        filename = prefix + IptablesManager.flush_rules_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        for ip_family in network_util.ip_families:
            file.write(f"## Flush all {ip_family} rules\n")
            file.write(f"{IptablesManager.iptables_commands[ip_family]} -F INPUT" + "\n")
            file.write(f"{IptablesManager.iptables_commands[ip_family]} -F OUTPUT" + "\n")
            file.write(f"{IptablesManager.iptables_commands[ip_family]} -F FORWARD" + "\n")
            file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_listener_rules(self, settings, prefix) -> None:
        """
        Create iptables listener rules
        """
        filename = prefix + IptablesManager.listener_rules_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        system_interfaces = network_util.get_system_interfaces()

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        # Build list of allowed ports from settings
        allowed_ports = []
        for listener in settings["server"]["upstreamBackend"]["listenerPorts"]:
            if listener["listenerPort"] not in allowed_ports:
                allowed_ports.append(listener["listenerPort"])

        for ip_family in network_util.ip_families:
            file.write(f"## {ip_family} listener rules\n")
            file.write(
                f"{IptablesManager.iptables_commands[ip_family]} -A INPUT -i lo -j ACCEPT" + "\n"
            )

            #
            # INPUT table
            #
            if len(allowed_ports) > 0:
                # Add web server listener ports from anyone
                file.write(
                    f"{IptablesManager.iptables_commands[ip_family]} -A INPUT -p tcp -m multiport --dports "
                    + ",".join(allowed_ports)
                    + " -j ACCEPT"
                    + "\n"
                )

            for interface in system_interfaces:
                for network in interface["networks"][ip_family]:
                    # Only allow access to admin ports from direct LAN access
                    file.write(
                        f"{IptablesManager.iptables_commands[ip_family]} -A INPUT -p tcp -m multiport --source {network['network']}/{network['prefix']} --dports "
                        + ",".join([str(port) for port in IptablesManager.admin_ports])
                        + " -j ACCEPT"
                        + "\n"
                    )

            # Allow established traffic to flow
            file.write(
                f"{IptablesManager.iptables_commands[ip_family]} -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"
                "\n"
            )
            file.write(
                f"{IptablesManager.iptables_commands[ip_family]} -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT"
                "\n"
            )
            file.write(
                f"{IptablesManager.iptables_commands[ip_family]} -A INPUT -m conntrack --ctstate INVALID -j DROP"
                "\n"
            )

            # Drop anything else
            file.write(f"{IptablesManager.iptables_commands[ip_family]} -A INPUT -j DROP" + "\n")
            file.write("\n")

            #
            # OUTPUT table
            #
            for interface in system_interfaces:
                # Allow all traffic coming from our networks generated internally to pass
                file.write(
                    f"{IptablesManager.iptables_commands[ip_family]} -A OUTPUT -o {interface['name']} -j ACCEPT"
                    "\n"
                )

            # Allow established traffic to flow
            file.write(
                f"{IptablesManager.iptables_commands[ip_family]} -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT"
                "\n"
            )
            file.write(
                f"{IptablesManager.iptables_commands[ip_family]} -A OUTPUT -m state --state ESTABLISHED,RELATED -j ACCEPT"
                "\n"
            )

            # Drop anything else
            file.write(f"{IptablesManager.iptables_commands[ip_family]} -A OUTPUT -j DROP" + "\n")
            file.write("\n")

            #
            # FORWARD table
            #

            # Allow established traffic to flow
            file.write(
                f"{IptablesManager.iptables_commands[ip_family]} -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT"
                "\n"
            )

            # Drop anything else
            file.write(f"{IptablesManager.iptables_commands[ip_family]} -A FORWARD -j DROP" + "\n")
            file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))


if IptablesManager.initalized is False:
    IptablesManager.static_init()

registrar.register_manager(IptablesManager())
