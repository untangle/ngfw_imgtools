"""This class is responsible for managing the nginx configuration for WAF"""

import os
import random
import stat

from sync import Manager, registrar
from sync.common import Logger

logger = Logger.getInstance()


class CronManager(Manager):
    """CronManager manages the cron file for waf"""

    cron_filename = "/etc/crontab"
    upload_backup_file = "/usr/bin/untangle-waf-upload-backup"
    update_crs_rulesets_file = "/usr/bin/waf-update-crs-rulesets.py"
    appliance_upgrade_file = "/usr/bin/ut-upgrade.py --no-depmod"

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.cron_filename, "restart-cron", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["cron"] = {}
        settings_file.settings["cron"]["autoBackup"] = {
            "hourOfDay": "-1",
            "minuteOfHour": "-1",
            "enabled": True,
            "month": "*",
            "dayOfWeek": "*",
            "dayOfMonth": "*",
        }
        settings_file.settings["cron"]["autoUpdateRules"] = {
            "hourOfDay": "-1",
            "minuteOfHour": "-1",
            "enabled": True,
            "month": "*",
            "dayOfWeek": "*",
            "dayOfMonth": "*",
        }
        settings_file.settings["cron"]["autoUpgrade"] = {
            "hourOfDay": "-1",
            "minuteOfHour": "-1",
            "enabled": True,
            "month": "*",
            "dayOfWeek": "*",
            "dayOfMonth": "*",
        }

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings for cron manager"""
        logger.info("Sanitizing settings")

        # create cron settings if missing
        if "cron" not in settings_file.settings:
            settings_file.settings["cron"] = {}

        # santize auto backup settings
        if "autoBackup" not in settings_file.settings["cron"]:
            settings_file.settings["cron"]["autoBackup"] = {
                "hourOfDay": "-1",
                "minuteOfHour": "-1",
                "enabled": True,
                "month": "*",
                "dayOfWeek": "*",
                "dayOfMonth": "*",
            }

        if "autoUpdateRules" not in settings_file.settings["cron"]:
            settings_file.settings["cron"]["autoUpdateRules"] = {
                "hourOfDay": "-1",
                "minuteOfHour": "-1",
                "enabled": True,
                "month": "*",
                "dayOfWeek": "*",
                "dayOfMonth": "*",
            }

        if "autoUpgrade" not in settings_file.settings["cron"]:
            settings_file.settings["cron"]["autoUpgrade"] = {
                "hourOfDay": "-1",
                "minuteOfHour": "-1",
                "enabled": True,
                "month": "*",
                "dayOfWeek": "*",
                "dayOfMonth": "*",
            }

        self.randomize_cron_job_times(settings_file)

    def randomize_cron_job_times(self, settings_file) -> None:
        """
        randomize_cron_job_times reads the settings file param and checks for all tasks
        within the cron json object, if any of them have '-1' as the hour or minute, we randomize
        that number between 0-5 AM for hours, and 0-59 for minutes of the hour
        """
        for cron_task in settings_file.settings.get("cron"):
            task_settings = settings_file.settings.get("cron").get(cron_task)
            # randomize hourOfDay and minuteOfHour times, and assign
            if task_settings["hourOfDay"] == "-1":
                # randomize hours between 12 AM and 5 AM
                task_settings["hourOfDay"] = str(random.randint(0, 5))
            if task_settings["minuteOfHour"] == "-1":
                # randomize minutes of the hour between 0 and 60 minutes
                task_settings["minuteOfHour"] = str(random.randint(0, 59))

            # Add month, dayOfWeek, dayOfMonth properties
            if task_settings.get("hourOfDay") is None or task_settings.get("hourOfDay") == "":
                task_settings["hourOfDay"] = "*"

            if (
                task_settings.get("minuteOfHour") is None
                or task_settings.get("minuteOfHour") == ""
            ):
                task_settings["minuteOfHour"] = "*"

            if task_settings.get("month") is None or task_settings.get("month") == "":
                task_settings["month"] = "*"

            if task_settings.get("dayOfWeek") is None or task_settings.get("dayOfWeek") == "":
                task_settings["dayOfWeek"] = "*"

            if task_settings.get("dayOfMonth") is None or task_settings.get("dayOfMonth") == "":
                task_settings["dayOfMonth"] = "*"

            # reassign this crontask back to the settings file
            settings_file.settings["cron"][cron_task] = task_settings

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Syncing settings")

        # create and open file
        filename = prefix + self.cron_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")

        # write out default cron tab values
        self.write_default_cron_vals(file)

        # auto backup
        self.write_cron_line(
            file, settings_file.settings.get("cron").get("autoBackup"), self.upload_backup_file
        )

        # auto update rulesets
        self.write_cron_line(
            file,
            settings_file.settings.get("cron").get("autoUpdateRules"),
            self.update_crs_rulesets_file,
        )

        # auto update
        self.write_cron_line(
            file,
            settings_file.settings.get("cron").get("autoUpgrade"),
            self.appliance_upgrade_file,
        )

        # Add in CMD cron entries
        if os.path.exists("/etc/cron.d/cmd"):
            with open("/etc/cron.d/cmd") as f:
                file.writelines(f)
            f.close()

        # write out file
        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_default_cron_vals(self, file) -> None:
        """
        write_default_cron_vals writes out the default cron values, including examples and autogenerated text
        """
        # fmt: off
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n\n")
        file.write("# write out default crontab settings\n")
        file.write("# /etc/crontab: system-wide crontab\n")
        file.write("# Unlike any other crontab you don't have to run the `crontab'\n")
        file.write("# command to install the new version when you edit this file\n")
        file.write("# and files in /etc/cron.d. These files also have username fields,\n")
        file.write("# that none of the other crontabs do.\n")
        file.write("\n")
        file.write("SHELL=/bin/sh\n")
        file.write("PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin\n")
        file.write("\n")
        file.write("# Example of job definition:\n")
        file.write("# .---------------- minute (0 - 59)\n")
        file.write("# |  .------------- hour (0 - 23)\n")
        file.write("# |  |  .---------- day of month (1 - 31)\n")
        file.write("# |  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ...\n")
        file.write("# |  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat\n")
        file.write("# |  |  |  |  |\n")
        file.write("# *  *  *  *  * user-name command to be executed\n")
        file.write("17 *	* * *	root    cd / && run-parts --report /etc/cron.hourly\n")
        file.write("25 6	* * *	root	test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.daily )\n")
        file.write("47 6	* * 7	root	test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.weekly )\n")
        file.write("52 6	1 * *	root	test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.monthly )\n")
        # fmt: on

    def write_cron_line(self, file, cron_settings, execution_command) -> None:
        """
        write_cron_lines will write a line into the crontab file using the generic cron settings format
        we've used for other scheduled tasks, and the execution_command for what to run on the interval
        """
        hour = 0
        minute = 0
        dayOfWeek = "*"
        month = "*"
        dayOfMonth = "*"

        if cron_settings is not None:
            if cron_settings.get("enabled") is None or cron_settings.get("enabled") is False:
                return
            if cron_settings.get("hourOfDay") is not None:
                hour = cron_settings.get("hourOfDay")
            if cron_settings.get("minuteOfHour") is not None:
                minute = cron_settings.get("minuteOfHour")
            if cron_settings.get("dayOfWeek") is not None:
                dayOfWeek = cron_settings.get("dayOfWeek")
            if cron_settings.get("dayOfMonth") is not None:
                dayOfMonth = cron_settings.get("dayOfMonth")
            if cron_settings.get("month") is not None:
                month = cron_settings.get("month")

            file.write(
                f"{minute} {hour} {dayOfMonth!s} {month!s} {dayOfWeek!s} root {execution_command} >/dev/null 2>&1\n"
            )


registrar.register_manager(CronManager())
