import os
import stat
from typing import Optional

from sync import Manager, registrar
from sync.common import Logger
from sync.uri_util import UriUtil

logger = Logger.getInstance()


class AptManager(Manager):
    """
    Build system apt sources list, accomodating customizations for oems.
    """

    default_update_uri = "http://updates.edge.arista.com/"

    debian_version_file_name = "/etc/debian_version"
    platforms = {"debian": {10: "buster", 11: "bullseye"}}

    apt_sources_untangle_file_name = "/etc/apt/sources.list.d/untangle-waf.list"
    apt_auth_untangle_file_name = "/etc/apt/auth.conf.d/untangle-waf-auth.conf"

    apt_sources_template = "deb %uri%%debian_code_name% %distribution% %components%"
    apt_sources_src_template = "deb-src %uri%%debian_code_name% %distribution% %components%"

    parameters = {
        "update_parameters": {
            "default_uri": default_update_uri,
            "uri": None,
            "debian_code_name": None,
            "distribution": "waf-%pubversion%",
            "components": "main non-free",
            "pubversion": None,
            "deb_src": True,
            "username": None,
            "password": None,
            "write_out": True,
            "hostname": None,
        },
        "influx_parameters": {
            "default_uri": default_update_uri,
            "uri": None,
            "debian_code_name": None,
            "distribution": "influxdb-stable",
            "components": "stable",
            "pubversion": "",
            "deb_src": False,
            "username": None,
            "password": None,
            "write_out": False,
            "hostname": None,
        },
    }

    def initialize(self) -> None:
        """
        Initialize
        """
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.apt_sources_untangle_file_name, "apt-update", self)
        registrar.register_file(self.apt_auth_untangle_file_name, "apt-update", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Generate our apt sources file
        """
        # Build parameter list
        if self.build_all_parameters(settings_file) is False:
            # Unable to build neccessary parameters
            return

        self.write_apt_sources(prefix)
        self.write_apt_auth(prefix)

        return

    def write_apt_sources(self, prefix) -> Optional[bool]:
        """
        Write out the sources file out
        """
        # Create sources file
        out_sources_file_name = prefix + self.apt_sources_untangle_file_name
        out_sources_file_dir = os.path.dirname(out_sources_file_name)
        if not os.path.exists(out_sources_file_dir):
            # Create directory
            os.makedirs(out_sources_file_dir)

        try:
            out_sources_file = open(out_sources_file_name, "w+")
            out_sources_file.write("## Auto Generated\n")
            out_sources_file.write("## DO NOT EDIT. Changes will be overwritten.\n\n")
            for param in self.parameters:
                if self.parameters[param]["write_out"]:
                    self.write_apt_sources_lines(
                        self.parameters[param], out_sources_file, out_sources_file_name
                    )
                    out_sources_file.write("\n\n")

            out_sources_file.flush()
            out_sources_file.close()
            os.chmod(out_sources_file_name, os.stat(out_sources_file_name).st_mode | stat.S_IEXEC)
        except Exception:
            logger.exception("Unable to write source file %s", str(out_sources_file_name))
            return False

        logger.info("Wrote %s", str(out_sources_file_name))
        return None

    def write_apt_sources_lines(self, params, out_sources_file, out_sources_file_name) -> None:
        """
        Write out the deb and deb-src lines of a given apt source
        """
        # Build apt_sources from parameters
        apt_sources = self.expand_parameter_value(self.apt_sources_template, params)
        apt_sources_src = self.expand_parameter_value(self.apt_sources_src_template, params)

        try:
            out_sources_file.write(f"{apt_sources}\n")
            if not params["deb_src"]:
                out_sources_file.write("##")
            out_sources_file.write(f"{apt_sources_src}\n")
        except Exception:
            logger.exception("Unable to write source file %s", str(out_sources_file_name))

    def write_apt_auth(self, prefix) -> Optional[bool]:
        """
        Write out the sources auth file out
        """
        # Create sources file
        out_auth_file_name = prefix + self.apt_auth_untangle_file_name
        out_auth_file_dir = os.path.dirname(out_auth_file_name)
        if not os.path.exists(out_auth_file_dir):
            # Create directory
            os.makedirs(out_auth_file_dir)

        auth_creds = self.create_auth_creds()

        try:
            out_auth_file = open(out_auth_file_name, "w+")
            out_auth_file.write("## Auto Generated\n")
            out_auth_file.write("## DO NOT EDIT. Changes will be overwritten.\n\n")
            out_auth_file.write(f"{auth_creds}")

            out_auth_file.flush()
            out_auth_file.close()
            os.chmod(out_auth_file_name, os.stat(out_auth_file_name).st_mode | stat.S_IEXEC)
        except Exception:
            logger.exception("Unable to write source file %s", str(out_auth_file_name))
            return False

        logger.info("Wrote %s", str(out_auth_file_name))
        return None

    def create_auth_creds(self):
        """
        Determine the auth creds for apt needed
        """
        auth_creds = {}
        for param_name in self.parameters:
            params = self.parameters[param_name]
            if "password" in params and "username" in params:
                password = params["password"]
                username = params["username"]
                hostname = params["hostname"]
                if password is not None and username is not None:
                    auth_creds[params["uri"]] = {
                        "password": password,
                        "username": username,
                        "host": hostname,
                    }

        auth_creds_str = ""
        for uri in auth_creds:
            auth_creds_str = (
                "machine "
                + auth_creds[uri]["host"]
                + " login "
                + auth_creds[uri]["username"]
                + " password "
                + auth_creds[uri]["password"]
                + "\n"
            )

        return auth_creds_str

    def build_all_parameters(self, settings_file) -> bool:
        """
        Populate parameter dictionary
        """
        for param_name in self.parameters:
            old_params = self.parameters[param_name]
            default_uri = old_params["default_uri"]
            new_params, success = self.build_parameters(settings_file, old_params, default_uri)
            if not success:
                return False

            # don't write out params if using updates.untangle
            if param_name == "influx_parameters" and "updates.untangle" not in new_params["uri"]:
                new_params["write_out"] = True

            self.parameters[param_name] = new_params

        return True

    def build_parameters(self, settings_file, orig_params, uri_name):
        params = orig_params
        # Debian code name
        params["debian_code_name"] = self.get_debian_code_name()
        if params["debian_code_name"] is None:
            logger.warning("Unable to determine debian_code_name")
            return params, False

        # WAF pubversion
        if params["pubversion"] is None:
            if "DIST" in os.environ:
                dist_env = os.environ["DIST"]
                if dist_env is not None:
                    params["pubversion"] = dist_env
                    params["distribution"] = dist_env
                else:
                    params["pubversion"] = settings_file.settings["version"]
            else:
                params["pubversion"] = settings_file.settings["version"]

        # URI components
        uri, username, password = self.get_uri_and_auth(settings_file, uri_name)
        if uri is None:
            return params, False
        params["uri"] = uri.url
        params["username"] = username
        params["password"] = password
        params["hostname"] = uri.hostname

        # Expand all parameters.
        while True:
            parameter_count = 0
            for key in params:
                parameter = f"%{key}%"
                for key_sub in params:
                    value = params[key_sub]
                    if value is not None and not isinstance(value, bool) and parameter in value:
                        # At least one in this round
                        parameter_count += 1
                        params[key_sub] = self.expand_parameter_value(value, params)
            if parameter_count == 0:
                # Finished expanding
                break

        return params, True

    def get_debian_code_name(self):
        """
        Get debian code name
        """
        debian_code_name = None

        try:
            with open(self.debian_version_file_name) as debian_version_file:
                debian_version = int(debian_version_file.readline().strip().split(".")[0])
        except Exception:
            logger.exception(
                "Unable to read debian version %s", str(self.debian_version_file_name)
            )
            return None

        debian_platforms = self.platforms["debian"]
        if debian_version in debian_platforms:
            debian_code_name = debian_platforms[debian_version]

        return debian_code_name

    def get_uri_and_auth(self, settings_file, uri_name):
        """
        Get updates URI
        """
        uri = None

        uri_settings = settings_file.settings["uris"]["uriTranslations"][uri_name]

        uri = UriUtil.build_uri(AptManager.default_update_uri, uri_settings)

        password = None
        username = None
        if "password" in uri_settings:
            password = uri_settings["password"]
        if "username" in uri_settings:
            username = uri_settings["username"]

        return uri, username, password

    def expand_parameter_value(self, value, params):
        """
        For a given value walk down parameter list and perform search/replace on parameters
        """
        for key in params:
            # Look for parameter enclosed in % characters like %key%
            parameter = f"%{key}%"
            if parameter in value:
                value = value.replace(parameter, params[key])
        return value


registrar.register_manager(AptManager())
