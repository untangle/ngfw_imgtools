import sync.registrar

sync.registrar.register_operation("restart-nginx", None, ["nginx -s reload"], 2, None)
sync.registrar.register_operation("restart-cron", [""], ["cat /etc/crontab | crontab - "], 3, None)
sync.registrar.register_operation("apt-update", None, ["apt-get update"], 1, None)
sync.registrar.register_operation(
    "restart-iptables",
    None,
    ["/etc/untangle/waf/post-network-hook.d/960-iptables", "sleep .5"],
    50,
    None,
)
sync.registrar.register_operation(
    "update-hostname", None, ["hostname -F /etc/hostname"], 1, "restart-networking"
)
sync.registrar.register_operation(
    "restart-networking", ["ifdown -a -v --exclude=lo"], ["ifup -a -v --exclude=lo"], 10, None
)
