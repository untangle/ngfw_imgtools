"""This class is responsible for managing URI translation settings"""

import os

from sync import Manager, registrar
from sync.common import Logger

logger = Logger.getInstance()


class UriManager(Manager):
    uid_file_name = "/usr/share/untangle/waf/conf/uid"
    default_update_uri = "https://updates.edge.arista.com/"
    default_update_host = "updates.edge.arista.com"

    def initialize(self) -> None:
        """
        Initialize module
        """
        registrar.register_settings_file("settings", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """
        Create default URI translation settings
        """
        logger.info("Initializing settings")

        # Default URIs

        settings_file.settings["uris"] = self.default_settings()

    def default_settings(self):
        return {
            "uriTranslations": {
                "https://downloads.edge.arista.com/download.php": {},
                "https://queue.edge.arista.com/v1/put": {},
                "https://edge.arista.com/store/open.php": {},
                "https://auth.edge.arista.com/v1/CheckTokenAccess": {},
                "https://database.edge.arista.com/v1/put": {},
                "https://edge.arista.com/cmd/account/": {},
                "https://edge.arista.com/legal": {},
                "https://support.edge.arista.com/hc": {},
                "https://license.edge.arista.com/license.php": {},
                "https://updates.edge.arista.com/": {},
                "https://boxbackup.edge.arista.com/boxbackup/backup.php": {},
            }
        }

    def sanitize_settings(self, settings_file) -> None:
        """
        Sanitizes settings
        """
        logger.info("Sanitizing settings")
        uris_settings = settings_file.settings.get("uris")

        # Missing URI settings
        if uris_settings is None:
            settings_file.settings["uris"] = {}
            settings_file.settings["uris"] = self.default_settings()

        settings_file.settings["uris"]["uriTranslations"][self.default_update_uri] = (
            self.create_update_params()
        )

    def create_update_params(self):
        params = {}
        dist_host = self.default_update_host
        if "DIST_URL" in os.environ:
            dist_host = os.environ["DIST_URL"]
        params["scheme"] = "http"
        params["host"] = dist_host

        if "updates.untangle" in dist_host:
            # UID for user name
            try:
                with open(UriManager.uid_file_name) as uid_file_name_file:
                    params["username"] = uid_file_name_file.readline().strip()
            except Exception:
                logger.exception("Unable to read uid file %s", str(UriManager.uid_file_name))
                return False
            params["password"] = "untangle"

        return params


registrar.register_manager(UriManager())
