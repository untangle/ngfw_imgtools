"""Manager helper functions"""

import os
import traceback

from . import registrar


def managers_init() -> int:
    """
    Call init() on all managers
    """
    for manager in registrar.managers:
        try:
            manager.initialize()
        except:
            traceback.print_exc()
            return 1
    return 0


def sanitize_settings(settings_file) -> None:
    """
    Run the modules sanitizeor on the settings
    If the settings change, save them
    """
    # Pre sanitize
    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            manager.sanitize_settings_pre(settings_file)
    # Sanitize
    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            manager.sanitize_settings(settings_file)
    # Post sanitize
    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            manager.sanitize_settings_post(settings_file)


def validate_settings(settings_file) -> None:
    """
    Validate the settings
    """
    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            manager.validate_settings(settings_file)


def archive_settings(settings_file) -> None:
    """
    Archive settings for future reference of the current settings.
    """
    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            manager.archive_settings(settings_file)


def upgrade_settings(settings_file) -> None:
    """
    Upgrade settings.
    """
    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            manager.upgrade_settings(settings_file)


def sync_to_tmpdirs(settings_file, tmpdir, tmpdir_delete) -> int:
    """
    Call sync_settings() on all managers
    """
    delete_list = []
    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            try:
                manager.sync_settings(settings_file, tmpdir, delete_list)
            except:
                traceback.print_exc()
                return 1

    for filename in delete_list:
        path = tmpdir_delete + filename
        file_dir = os.path.dirname(path)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        file = open(path, "w+")
        file.write("\n\n")
        file.flush()
        file.close()

    return 0


def create_settings_in_tmpdir(settings_file, tmpdir, tmpdir_delete, templates_path) -> int:
    """
    Call create_settings() on all managers
    """
    delete_list = []

    for manager in registrar.managers:
        if registrar.check_registrar_settings_file(settings_file.id, manager):
            try:
                manager.create_settings(
                    settings_file, tmpdir, delete_list, settings_file.file_name
                )
            except:
                traceback.print_exc()
                return 1
    # Merge templates
    settings_file.merge_templates(templates_path)
    # Save to target
    settings_file.save_settings(tmpdir)

    for filename in delete_list:
        path = tmpdir_delete + filename
        file_dir = os.path.dirname(path)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        file = open(path, "w+")
        file.write("\n\n")
        file.flush()
        file.close()

    return 0
