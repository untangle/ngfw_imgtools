"""network utilities"""

from __future__ import annotations

import ipaddress
import json
import logging
import socket
import subprocess
from dataclasses import dataclass
from pathlib import Path, PurePath
from typing import Any, Union

import pyroute2

logger = logging.getLogger(__name__)

from sync import board_util
from sync.board_util import BoardUtil
from sync.nftables_util import INTERFACE_TYPES
from sync.perms_util import regain_permissions
from sync.settings_file import SettingsFile

SFA_FRU_PLUGIN_DEVICES_FILE = "/var/run/sfaFruPluginDevices.json"


class NetworkUtil:
    """
    This class is a utility class with utility functions providing
    useful tools for dealing with iptables rules
    """

    settings = {}

    @staticmethod
    def interface_list():
        """
        returns a list of the interfaceId's extracted from the settings
        """
        settings = NetworkUtil.settings
        ret = []

        if settings is None or "interfaces" not in settings:
            return ret

        for intf in settings["interfaces"]:
            if "interfaceId" not in intf:
                continue
            ret.append(int(intf["interfaceId"]))
        return ret

    @staticmethod
    def wan_list():
        """
        returns a list of the interfaceId's for WANS extracted from the settings
        """
        settings = NetworkUtil.settings
        ret = []

        if settings is None or settings.get("interfaces") is None:
            return ret

        for intf in settings["interfaces"]:
            if intf.get("interfaceId") is None:
                continue
            if intf.get("configType") == "ADDRESSED" and intf.get("isWan"):
                ret.append(int(intf["interfaceId"]))

        for intf in settings["virtualInterfaces"]:
            if intf.get("interfaceId") is None:
                continue
            if intf.get("isWan"):
                ret.append(int(intf["interfaceId"]))
        return ret

    @staticmethod
    def non_wan_list():
        """
        returns a list of the interfaceId's for non-WANS extracted from the settings
        """
        settings = NetworkUtil.settings
        ret = []

        if settings is None or settings.get("interfaces") is None:
            return ret

        for intf in settings["interfaces"]:
            if intf.get("interfaceId") is None:
                continue
            if intf.get("configType") == "ADDRESSED" and intf.get("isWan"):
                continue
            ret.append(int(intf["interfaceId"]))
        for intf in settings["virtualInterfaces"]:
            if intf.get("interfaceId") is None:
                continue
            if intf.get("isWan"):
                continue
            ret.append(int(intf["interfaceId"]))
        return ret


CIDR_MAP = {
    1: "128.0.0.0",
    2: "192.0.0.0",
    3: "224.0.0.0",
    4: "240.0.0.0",
    5: "248.0.0.0",
    6: "252.0.0.0",
    7: "254.0.0.0",
    8: "255.0.0.0",
    9: "255.128.0.0",
    10: "255.192.0.0",
    11: "255.224.0.0",
    12: "255.240.0.0",
    13: "255.248.0.0",
    14: "255.252.0.0",
    15: "255.254.0.0",
    16: "255.255.0.0",
    17: "255.255.128.0",
    18: "255.255.192.0",
    19: "255.255.224.0",
    20: "255.255.240.0",
    21: "255.255.248.0",
    22: "255.255.252.0",
    23: "255.255.254.0",
    24: "255.255.255.0",
    25: "255.255.255.128",
    26: "255.255.255.192",
    27: "255.255.255.224",
    28: "255.255.255.240",
    29: "255.255.255.248",
    30: "255.255.255.252",
    31: "255.255.255.254",
    32: "255.255.255.255",
}


def ipv4_prefix_to_netmask(prefix):
    """prefix to netmask string"""
    if prefix < 0 or prefix > 32:
        return None
    return CIDR_MAP.get(prefix)


def is_bridge_interface(settings, interface) -> bool:
    """
    returns true if interface has any other interfaces bridged to it
    If it does this interface is definitionally a "bridge group"
    """
    interfaces = settings.get("network", {}).get("interfaces", [])
    for intf in interfaces:
        if (
            intf.get("enabled")
            and intf.get("configType") == "BRIDGED"
            and intf.get("bridgedTo") == interface.get("interfaceId")
        ):
            return True
    return False


def get_interface_by_id(settings, interfaceId):
    """returns interface with the given interfaceId"""
    interfaces = settings.get("network", {}).get("interfaces", [])
    for intf in interfaces:
        if intf.get("interfaceId") == interfaceId:
            return intf
    return None


def get_interface_by_ip(settings, ip):
    """It iterates through non WAN interfaces static IP(including IP aliases) settings
    and returns interface with the given ip address"""
    if settings.get("network", {}).get("interfaces") is None:
        return None
    interfaces = settings["network"]["interfaces"]
    return get_interface_by_ip_and_interfaces(interfaces, ip)


def get_interface_by_ip_and_interfaces(interfaces, ip):
    """It iterates through non WAN interfaces static IP(including IP aliases) settings
    and returns interface with the given ip address"""
    if interfaces is None:
        return None
    parsed_addr = ipaddress.ip_address(ip)
    for intf in interfaces:
        if intf.get("v4StaticAddress") is not None and intf.get("v4StaticPrefix") is not None:
            net_address = intf["v4StaticAddress"] + "/" + str(intf["v4StaticPrefix"])
            if parsed_addr in ipaddress.ip_network(net_address, strict=False):
                return intf
        # check for ip aliases
        if intf.get("v4Aliases") is not None:
            for alias in intf.get("v4Aliases"):
                net_address = alias["v4Address"] + "/" + str(alias["v4Prefix"])
                if parsed_addr in ipaddress.ip_network(net_address, strict=False):
                    return intf

    return None


def get_interface_by_device(settings, device):
    """returns interface with the given device"""
    interfaces = settings.get("network", {}).get("interfaces", [])
    # By actual device name
    for intf in interfaces:
        if intf.get("device") == device:
            return intf
    # Check for names that are part of the device name like PPPoE types.
    for intf in interfaces:
        if intf.get("name") in device:
            return intf
    return None


def get_virtual_interface_by_id(settings, interfaceId):
    """returns virtual interface with the given interfaceId"""
    virtualInterfaces = settings.get("network").get("virtualInterfaces")
    if virtualInterfaces is None:
        return None
    for intf in virtualInterfaces:
        if intf.get("interfaceId") == interfaceId:
            return intf
    return None


def get_is_wireguard(settings, interfaceId) -> bool:
    """determine if interface is a wireguard interface"""
    checkInterface = get_virtual_interface_by_id(settings, interfaceId)
    return bool(checkInterface is not None and checkInterface.get("name") == "WireGuard VPN")


def get_policy_by_id(settings, policyId):
    """
    @param settings - The Settings json
    @param policyId - The policy ID to load the full policy JSON for
    returns interface with the given policyId
    """
    policies = settings["wan"].get("policies")
    for pol in policies:
        if pol.get("policyId") == policyId:
            return pol
    return None


def get_policy_description(settings, policyId):
    """
    @param settings - The settings json
    @param policyId - the policy ID
    returns the policy description, or just the policy ID if not found
    """
    load_pol = get_policy_by_id(settings, policyId)
    if load_pol is None:
        return policyId
    return load_pol.get("description")


def get_interface_name_confirm(settings, interfaceId):
    """
    @param settings - the settings json
    @param interfaceId - the interface ID
    returns the interface name, or just the interface ID if not found
    """
    load_intf = get_interface_by_id(settings, interfaceId)
    if load_intf is None:
        return interfaceId
    return load_intf.get("name")


def get_interface_name(settings, intf, family):
    """
    @param settings - the Settings json
    @param intf - the interface we wish to retrieve the name from
    @param family - the ip family we are checking against (ipv4 or ipv6)
    returns the interface name as it would appear in /etc/config/network
    """
    interface_name = ""
    if is_bridge_interface(settings, intf):
        interface_name = "b_"

    if intf.get("name"):
        interface_name = interface_name + intf.get("name")

    if intf.get("type") == "IPSEC":
        return intf.get("logical_name")
    if (
        intf.get("type") == "OPENVPN"
        or intf.get("type") == "WIREGUARD"
        or intf.get("type") == "WWAN"
    ):
        return interface_name
    # Does it make sense to check the "ConfigType" if we have to specify family in the util call anyway?
    if family == "ipv4" and intf.get("v4ConfigType") != "DISABLED":
        interface_name = interface_name + "4"
    if family == "ipv6" and intf.get("v6ConfigType") != "DISABLED":
        interface_name = interface_name + "6"

    return interface_name


def get_vpn_interface_family_and_name(settings, interface):
    """
    Determine ip family for VPN and return as a family, name tuple
    @param settings - the Settings json
    @param interface - interface to examine.
    Returns a tuple containing vpn type, address type, and system device (OpenWrt) such as ("IPSEC", "ipv4", "ipsec0")
    """
    if interface is not None:
        type = interface.get("type")
        if type == "IPSEC":
            return (type, interface.get("family"), interface.get("device"))
        # For OpenVPN and Wireguard - use the interface name
        return (type, interface.get("family"), interface.get("name"))

    return (None, None, None)


def get_bridge_name(settings, interface, family):
    """
    returns the name of the bridge that this interface is a part of
    as it would appear in /etc/config/network
    """
    interfaces = settings["network"]["interfaces"]
    for intf in interfaces:
        if intf.get("configType") == "BRIDGED" and interface.get("interfaceId") in intf.get(
            "bridgedInterfaces", []
        ):
            bridge_interface_name = "b_" + intf.get("name")
            if family == "ipv4" and interface.get("v4ConfigType") != "DISABLED":
                bridge_interface_name = bridge_interface_name + "4"
            if family == "ipv6" and intf.get("v6ConfigType") != "DISABLED":
                bridge_interface_name = bridge_interface_name + "6"
            return bridge_interface_name
    return ""


def get_intf_ipv4_from_startup_config(ifname: str) -> Union[ipaddress.IPv4Interface, None]:
    """
    Get an interface's static ipv4 address from the startup config.

    Returns the address in 'address/prefix' format (e.g., '192.168.1.1/24').
    Returns None if the interface is not found, has no static ipv4 address,
    or is configured for DHCP.
    """
    try:
        intf_str = get_intf_from_startup_config(ifname)
        if intf_str:
            for line in intf_str.split("\n"):
                if "ip address " in line and "dhcp" not in line:
                    # Expects a line like: '   ip address 192.168.1.1/24'
                    return ipaddress.IPv4Interface(line.split()[2])
    except ipaddress.AddressValueError as e:
        print(e)
    return None


def get_intf_ipv6_from_startup_config(ifname: str) -> Union[ipaddress.IPv6Interface, None]:
    """
    Get an interface's static ipv6 address from the startup config.

    Returns the address in 'address/prefix' format.
    Returns None if the interface is not found or has no static ipv6 address.
    """
    try:
        intf_str = get_intf_from_startup_config(ifname)
        if intf_str:
            for line in intf_str.split("\n"):
                if "ipv6 address " in line:
                    # Expects a line like: '   ipv6 address fdfd:5c41:712d:e0d2::af0:cfc8/64'
                    parts = line.split()
                    address_with_prefix = parts[2]
                    return ipaddress.IPv6Interface(address_with_prefix)
    except ipaddress.AddressValueError as e:
        print(e)
    return None


def get_intf_from_startup_config(ifname) -> Union[str, None]:
    """
    Get an interface's information from the startup config. Returns None if the
    interface is not present in the startup-config
    """
    try:
        # grep for interface name and following lines which begin with spaces
        # (configuration for that interface). '!' delimiter not present in
        # startup-config at this time
        eos_ifname = translate_mfw_interface_name_to_eos(ifname)
        conf_file = "/mnt/flash/startup-config"
        return subprocess.check_output(
            rf"/usr/bin/grep -Pzo 'interface {eos_ifname}.*\n( +.*\n)*' {conf_file}",
            shell=True,
            stderr=subprocess.DEVNULL,
        ).decode("ascii")
    except subprocess.SubprocessError as e:
        print(e)
    return None


def enabled_wan(intf) -> bool:
    """returns true if the interface is an enabled wan"""
    if intf is None:
        return False

    return bool(intf.get("enabled") and intf.get("wan") and intf.get("configType") == "ADDRESSED")


def enabled_management(intf) -> bool:
    """returns true if the interface is an enabled management"""
    if intf is None:
        return False

    return bool(
        intf.get("enabled") and intf.get("management") and intf.get("configType") == "ADDRESSED"
    )


def get_ip_address_version(address):
    """
    From the specified address, return an integer value of the ip address type.
    If unable to parse, None is returned.
    @param address  IP address to parse.

    returns integer values of 4 or 6.  If could not determine None.
    """
    try:
        ip_interface = ipaddress.ip_interface(address)
    except:
        # Unable to parse version
        return None

    return ip_interface.version


# IP address family keys for result of get_system_interfaces()
ip_families = ["ipv4", "ipv6"]


def get_system_interfaces():
    """
    Use netlink link to get list of interface information for consumption by other routines.

    NOTE: You should generally not rely on this from within sync_settings calls since
    its unlikely that settings values have been written to system configuration and
    networking restarted for netfilter to have an accurate view of what is really live.

    Each entry contains an interface dictionary with the following information:
    index       netlink integer index
    name        interface name
    networks    IP family lists of networks

    The "networks" key contains a list of ipv4/ipv6 dictionaries, each dictionary containing
    the following keypairs:
    prefix      Prefix number (e.g., 24)
    address     IP address
    network     Network address
    broadcast   Broadcast address

    Example:
    [{
        'index': 1,
        'name': 'lo'
        'networks': {
            'ipv4': [{
                'prefix': 8,
                'address': '127.0.0.1',
                'network': '127.0.0.0',
                'broadcast': '127.255.255.255'
                }],
            'ipv6': [{
                'prefix': 128,
                'address': '::1',
                'network': '::1',
                'broadcast': '::1'
                }
        ]},
    },{
        ...
    }]

    """
    interfaces = []

    ip = pyroute2.IPRoute()
    addresses = ip.get_addr()

    # Walk interfaces
    for link in ip.get_links():
        interface = {"index": link["index"], "networks": {"ipv4": [], "ipv6": []}}
        for k, v in link["attrs"]:
            if k == "IFLA_IFNAME":
                # Get name
                interface["name"] = v

        # Walk addresses to find those associated with this interface.
        for address in addresses:
            family = "ipv6" if address["family"] == socket.AF_INET6 else "ipv4"
            network = {"prefix": address["prefixlen"]}
            if address["index"] != interface["index"]:
                # Ignore if not same name
                continue

            unknown_family = False
            for ak, av in address["attrs"]:
                if ak == "IFA_ADDRESS":
                    network["address"] = av
                    if address["family"] == socket.AF_INET:
                        ip_address = ipaddress.IPv4Interface(av + "/" + str(address["prefixlen"]))
                    elif address["family"] == socket.AF_INET6:
                        ip_address = ipaddress.IPv6Interface(av + "/" + str(address["prefixlen"]))
                    else:
                        unknown_family = True
                        break

                    network["network"] = str(ip_address.network.network_address)
                    network["broadcast"] = str(ip_address.network.broadcast_address)

            if unknown_family is False:
                interface["networks"][family].append(network)

        interfaces.append(interface)

    return interfaces


def get_devices_matching_glob(glob):
    """get devices matching the specified glob"""
    device_list = []
    if BoardUtil.is_platform_os_eos():
        devices = []
        # Interfaces may not be fully up by the time we start.
        # EOS uses the the sfaFruPluginDevices file so why not us?
        sfaFruPluginDevicesFile = Path(SFA_FRU_PLUGIN_DEVICES_FILE)
        if sfaFruPluginDevicesFile.exists():
            try:
                with open(SFA_FRU_PLUGIN_DEVICES_FILE) as f:
                    sfaFruPluginDevices = json.load(f)
                    for device in sfaFruPluginDevices["device"]:
                        if PurePath(device).match(glob):
                            devices.append(device)
            except:
                pass
        if len(devices) == 0:
            # Fallback to system defined interfaces (for example management1)
            devices = (
                subprocess.check_output(
                    f"find /proc/sys/net/ipv4/conf/ -name '{glob}' | sed -e 's|/proc/sys/net/ipv4/conf/||' | sort",
                    shell=True,
                )
                .decode("ascii")
                .splitlines()
            )
        for dev in devices:
            # EOS default startup config dont have ethX interface config. So skip adding to sync-settings interface config.
            # skip adding sub-interfaces, since sub-interfaces in EOS have phy_int.vlanid
            if dev and "eth" not in dev and "." not in dev:
                device_list.append(dev)
    else:
        devices = subprocess.check_output(
            f"find /sys/class/net -type l -name '{glob}' | sed -e 's|/sys/class/net/||' | sort",
            shell=True,
        ).decode("ascii")
        for dev in devices.splitlines():
            if dev:
                device_list.append(dev)
    return device_list


def get_devices():
    """get devices"""
    device_list = []
    if BoardUtil.is_platform_os_eos():
        device_list.extend(get_devices_matching_glob("et*"))
        device_list.extend(get_devices_matching_glob("ma*"))
    else:
        device_list.extend(get_devices_matching_glob("eth*"))
        device_list.extend(get_devices_matching_glob("lan*"))
        device_list.extend(get_devices_matching_glob("wan*"))
        device_list.extend(get_devices_matching_glob("wwan*"))
        device_list.extend(get_wireless_devices())
    return device_list


def get_wireless_devices():
    """get wireless devices"""
    device_list = []
    devices = subprocess.check_output(
        "find /sys/class/ieee80211 -type l -name 'phy*' | sed -e 's|/sys/class/ieee80211/||' | sort",
        shell=True,
    ).decode("ascii")
    for dev in devices.splitlines():
        if dev:
            device_list.append(dev.replace("phy", "wlan"))
    return device_list


def interface_exists(ifname) -> bool:
    """Check if the specified network interface exists"""
    try:
        output = subprocess.check_output(["ip", "link", "show", "dev", ifname]).decode("utf-8")
        return ifname in output
    except subprocess.CalledProcessError:
        return False


def management_interface_exists() -> bool:
    """Checks if a management interface exists on the system"""
    return interface_exists(board_util.get_management_interface())


def is_management_interface(intf: dict[str, Any]) -> bool:
    """
    Returns true if the provided interface(a JSON dict)
    is a management interface.
    """
    if intf is None:
        return False

    device: str = intf.get("device")

    # Prevent returning True if the device string is empty
    # or there is no management port
    if not device:
        return False

    return is_management_device_name(device)


def is_management_device_name(device_name: str) -> bool:
    """Returns True if the device name provided matches a management device"""
    # Guard against two empty strings being compared
    if not device_name:
        return False

    return device_name == board_util.get_management_interface()


def get_ip_type(address) -> int:
    """get the type of address or raise exception if address is neither ipv4 or ipv6 valid"""
    try:
        ip = ipaddress.ip_address(address)

        if isinstance(ip, ipaddress.IPv4Address):
            return 4
        if isinstance(ip, ipaddress.IPv6Address):
            return 6
    except ValueError:
        return -1


def get_bridged_interfaces(interfaces):
    """
    Return list of interfaces which have been added to a bridge interface
    """
    bridged_interfaces = []
    for interface in interfaces:
        bridged_interfaces.extend(interface.get("bridgedInterfaces", []))
    return bridged_interfaces


def get_local_interfaces(settings):
    """
    Return LAN interfaces which have an IP address
    """
    local_interfaces = []
    interfaces = settings["network"]["interfaces"]
    bridged_interfaces = get_bridged_interfaces(interfaces)
    for interface in interfaces:
        if (
            interface["wan"] is False
            and interface["enabled"] is True
            and interface.get("v4StaticAddress", "") != ""
            and interface["interfaceId"] not in bridged_interfaces
        ):
            local_interfaces.append(interface["v4StaticAddress"])

    return local_interfaces


def translate_eos_interface_name_to_mfw(eos_interface: str) -> str:
    """
    translate the interface name from EOS to the MFW naming:
    Ethernet1/1 -> et1_1
    Et1/1 -> et1_1
    Management1/1 -> ma1_1
    Ma1/1 -> ma1_1
    """
    return (
        eos_interface.replace("Ethernet", "et")
        .replace("Et", "et")
        .replace("Management", "ma")
        .replace("Ma", "ma")
        .replace(
            "/",
            "_",
        )
    )


def translate_mfw_interface_name_to_eos(interface: str) -> str:
    """
    translate the interface name from mfw to the EOS naming:
    et1_1 -> Ethernet1/1
    ma1_1 -> Management1/1
    """
    return (
        interface.replace("et", "Ethernet")
        .replace("ma", "Management")
        .replace("lo", "Loopback")
        .replace(
            "_",
            "/",
        )
    )


def is_valid_ipv4(ip: str) -> bool:
    """
    Verifies if the provided input is a valid IPv4 address
    """
    try:
        ip = ipaddress.ip_address(ip)
    except ValueError:
        return False
    else:
        return ip.version == 4


def is_valid_ipv6(ip: str) -> bool:
    """
    Verifies if the provided input is a valid IPv6 address
    """
    try:
        ip = ipaddress.ip_address(ip)
    except ValueError:
        return False
    else:
        return ip.version == 6


def is_valid_ip(ip: str) -> bool:
    """
    Verifies if the provided input is a valid IP address
    """
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        return False
    else:
        return True


def is_valid_network_cidr(network_string: str) -> bool:
    """
    Verifies if the provided input is a valid network in CIDR notation
    """
    try:
        ipaddress.ip_network(network_string, strict=False)
    except ValueError:
        return False
    else:
        return True


def get_interface_names_from_type(
    settings_file: SettingsFile,
    interface_type: int = 0,
) -> list:
    """For specified interface type, get active interface names.

    Keyword arguments:
    settings_file -- settings file to search
    interface_type -- Numeric identifier of type from INTERFACE_TYPES.
    """
    names = []
    # INTERFACE_TYPE maps name to type
    inverse_types = {v: k for k, v in INTERFACE_TYPES.items()}

    for interface in settings_file.settings.get("network", {}).get("interfaces", []):
        if interface.get("enabled") is False:
            continue

        if interface.get("management"):
            if inverse_types[interface_type] == "management":
                names.append(interface.get("name"))
            continue

        if (inverse_types[interface_type] == "wan" and interface.get("wan")) or (
            inverse_types[interface_type] == "lan" and interface.get("wan") is False
        ):
            names.append(interface.get("name"))

    return names


def get_destination_networks_from_interfaces(
    settings_file: SettingsFile,
    interface_names: list[str],
    ip_class: str = "v4",
) -> list:
    """For specified interface names, return a list of get associated destination networks for enabled interfaces.
    The returned values are the IP address(es) of the interface such as 192.168.1.1/32.

    NOTE: it is possible for this list to be empty, such as the case of a DHCP interface

    At this time, the return list includes:
    -   ipv4 static address

    Keyword arguments:
    settings_file -- settings file to search
    interface_names -- list of names to match
    ip_class -- Class of ip addresses to pull, defaults to v4.
    """
    networks = []

    for interface in settings_file.settings.get("network", {}).get("interfaces", []):
        if interface.get("name") not in interface_names:
            continue
        if interface.get("enabled") is False:
            continue
        if interface.get(f"{ip_class}ConfigType") != "STATIC":
            continue
        static_address = interface.get(f"{ip_class}StaticAddress")
        networks.append(f"{static_address}/32")

    return networks


def get_source_networks_from_interfaces(
    settings_file: SettingsFile,
    interface_names: list[str],
    ip_class: str = "v4",
) -> list:
    """For specified interface names, return a list of associated destination networks for enabled interfaces.  With rare excptions this is the IP address of the interface

    NOTE: it is possible for this list to be empty, such as the case of a DHCP interface

    At this time, the return list includes:
    -   ipv4 static network for the interface
    -   static route networks that can route via a host on the interface's network

    Keyword arguments:
    settings_file -- settings file to search
    interface_names -- list of names to match
    ip_class -- Class of ip addresses to pull, defaults to v4.
    """
    networks = []

    static_routes = []
    routes_all = settings_file.settings.get("routes", [])
    for routes_for_vrf in routes_all:
        static_routes.extend(routes_for_vrf.get("routes", []))

    for interface in settings_file.settings.get("network", {}).get("interfaces", []):
        if interface.get("name") not in interface_names:
            continue
        if interface.get("enabled") is False:
            continue
        if interface.get(f"{ip_class}ConfigType") != "STATIC" or not (
            interface.get(f"{ip_class}StaticAddress") and interface.get(f"{ip_class}StaticPrefix")
        ):
            continue
        static_address = interface.get(f"{ip_class}StaticAddress")
        static_prefix = interface.get(f"{ip_class}StaticPrefix")
        network = ipaddress.ip_network(f"{static_address}/{static_prefix}", strict=False)
        networks.append(str(network))

        # Look for static routes with a nexthop on this network
        for route in static_routes:
            if route.get("enabled") is False:
                continue
            route_nexthop = ipaddress.ip_network(route.get("nextHop"), strict=False)
            if route_nexthop.overlaps(network):
                route_network = ipaddress.ip_network(route.get("network"), strict=False)
                networks.append(str(route_network))

    return networks


def get_interface_networks(
    intf: dict,
    ip_class: str = "v4",
) -> list[str]:
    """Get interface networks for an interface.

    At this time, the return list includes:
    -   ipv4 static network for the interface

    Keyword arguments:
    intf -- interface dictionary
    ip_class -- Class of ip addresses to pull, defaults to v4.
    """
    networks = []
    if (
        intf.get("enabled")
        and intf.get("v4ConfigType") == "STATIC"
        and intf.get("v4StaticAddress")
    ):
        static_address = intf.get(f"{ip_class}StaticAddress")
        static_prefix = intf.get(f"{ip_class}StaticPrefix")
        network = ipaddress.ip_network(f"{static_address}/{static_prefix}", strict=False)
        networks.append(str(network))
    return networks


def get_wan_interfaces_from_startup_config() -> list[str]:
    """
    Get WAN interfaces from the EOS startup-config by parsing the 'group interface WAN' block.

    Returns a list of MFW interface names (e.g., ['et1_5', 'et1_7', 'et1_8']).
    Returns an empty list if:
    - The startup-config file doesn't exist
    - No WAN group is configured
    - An error occurs during parsing

    Uses line-by-line parsing to handle:
    - CRLF and LF line endings
    - Tab or space indentation
    - Empty lines within blocks
    """
    try:
        conf_file = "/mnt/flash/startup-config"
        # Escalate privileges to read startup-config
        with regain_permissions(), open(conf_file) as f:
            content = f.read()

        # Normalize line endings (handle CRLF)
        content = content.replace("\r\n", "\n").replace("\r", "\n")

        wan_interfaces = []
        in_wan_group = False

        for line in content.split("\n"):
            stripped = line.strip()

            # Skip empty lines
            if not stripped:
                continue

            # Check for WAN group start
            if stripped == "group interface WAN":
                in_wan_group = True
                continue

            # Check for block end
            if stripped == "!" and in_wan_group:
                break

            # Parse interface lines within WAN group
            if in_wan_group:
                if stripped.startswith("no interface"):
                    continue
                if stripped.startswith("interface ") and not stripped.startswith("interface vlan"):
                    # Extract the interface name (e.g., "Ethernet1/5" or "Et1/5")
                    parts = stripped.split()
                    if len(parts) >= 2:
                        eos_intf_name = parts[1]
                        mfw_intf_name = translate_eos_interface_name_to_mfw(eos_intf_name)
                        if mfw_intf_name:
                            wan_interfaces.append(mfw_intf_name)

        return wan_interfaces
    except FileNotFoundError:
        # File doesn't exist - this is normal on non-EOS platforms
        return []
    except Exception as e:
        # Log the actual error for debugging (including permission errors)
        print(f"Error parsing WAN interfaces from startup-config: {e}")
        return []


@dataclass
class InterfaceIPConfig:
    """Represents IP configuration parsed from startup-config."""

    is_switchport: bool = True  # Default L2 mode
    v4_type: str | None = None  # "STATIC", "DHCP", "DISABLED"
    v4_address: str | None = None
    v4_prefix: int | None = None
    v6_type: str | None = None  # "STATIC", "SLAAC", "DISABLED"
    v6_address: str | None = None
    v6_prefix: int | None = None


def _process_interface_block(eos_intf_name: str, lines: list[str]) -> dict[str, InterfaceIPConfig]:
    """Process a single interface block and return its IP config.

    Args:
        eos_intf_name: EOS interface name (e.g., "Ethernet1/1")
        lines: List of stripped lines within the interface block

    Returns:
        Dict with single entry {mfw_intf_name: config} for all interfaces:
        - L3 interfaces ('no switchport'): IP settings from startup-config
        - L2 interfaces (switchport): v4/v6ConfigType set to DISABLED
    """
    mfw_intf_name = translate_eos_interface_name_to_mfw(eos_intf_name)

    # Check for "no switchport" to distinguish L3 vs L2 interfaces
    has_no_switchport = any(line.split() == ["no", "switchport"] for line in lines)

    if not has_no_switchport:
        # L2 interface - return DISABLED config for both IPv4 and IPv6
        config = InterfaceIPConfig()
        config.is_switchport = True
        config.v4_type = "DISABLED"
        config.v6_type = "DISABLED"
        return {mfw_intf_name: config}

    config = InterfaceIPConfig()
    config.is_switchport = False

    for line in lines:
        parts = line.split()

        # IPv4
        if parts == ["ip", "address", "dhcp"]:
            config.v4_type = "DHCP"
        elif len(parts) == 3 and parts[:2] == ["ip", "address"]:
            # Static IP: "ip address 192.168.1.1/24"
            try:
                ip_intf = ipaddress.IPv4Interface(parts[2])
                config.v4_type = "STATIC"
                config.v4_address = str(ip_intf.ip)
                config.v4_prefix = ip_intf.network.prefixlen
            except ValueError:
                pass
        elif parts == ["no", "ip", "address"]:
            config.v4_type = "DISABLED"

        # IPv6
        if parts == ["ipv6", "address", "auto-config"]:
            config.v6_type = "SLAAC"
        elif len(parts) == 3 and parts[:2] == ["ipv6", "address"]:
            # Static IPv6: "ipv6 address 2001:db8::1/64"
            try:
                ip_intf = ipaddress.IPv6Interface(parts[2])
                config.v6_type = "STATIC"
                config.v6_address = str(ip_intf.ip)
                config.v6_prefix = ip_intf.network.prefixlen
            except ValueError:
                pass
        elif parts == ["no", "ipv6", "address"]:
            config.v6_type = "DISABLED"

    return {mfw_intf_name: config}


def get_interface_ip_config_from_startup_config() -> dict[str, InterfaceIPConfig]:
    """
    Parse interface IP configuration from EOS startup-config.

    Returns dict mapping MFW interface names (e.g., 'et1_1') to InterfaceIPConfig.
    Includes ALL interfaces from startup-config:
    - L3 interfaces ('no switchport'): IP settings from startup-config
    - L2 interfaces (switchport): v4ConfigType and v6ConfigType set to DISABLED

    Uses line-by-line parsing to handle:
    - CRLF and LF line endings
    - Tab or space indentation
    - Empty lines within interface blocks
    - Trailing whitespace
    Skips comment lines (starting with '!').
    """
    try:
        conf_file = "/mnt/flash/startup-config"
        # Escalate privileges to read startup-config
        with regain_permissions(), open(conf_file) as f:
            content = f.read()

        # Normalize line endings (handle CRLF)
        content = content.replace("\r\n", "\n").replace("\r", "\n")

        result: dict[str, InterfaceIPConfig] = {}
        current_intf: str | None = None
        intf_lines: list[str] = []
        in_group_block = False  # Track if inside a "group interface" block

        for line in content.split("\n"):
            stripped = line.strip()

            # Handle block terminator "!" - process previous interface if any
            if stripped == "!":
                if in_group_block:
                    in_group_block = False
                    continue
                if current_intf:
                    result.update(_process_interface_block(current_intf, intf_lines))
                    current_intf = None
                    intf_lines = []
                continue

            # Skip empty lines and comment lines (lines that start with !)
            if not stripped or stripped.startswith("!"):
                continue

            # Check for group interface block start (e.g., "group interface WAN")
            # Interface references inside these blocks should be skipped
            if stripped.startswith("group interface"):
                in_group_block = True
                continue

            # Skip all lines inside group blocks
            if in_group_block:
                continue

            # Check for interface start (handles both "Ethernet" and abbreviated "Et")
            if stripped.startswith("interface Ethernet") or stripped.startswith("interface Et"):
                # Save previous interface if any (handles missing "!" between blocks)
                if current_intf:
                    result.update(_process_interface_block(current_intf, intf_lines))
                # Parse interface name: "interface Ethernet1/1" or "interface Et1/1"
                parts = stripped.split()
                if len(parts) >= 2:
                    current_intf = parts[1]  # e.g., "Ethernet1/1" or "Et1/1"
                    intf_lines = []
            elif current_intf:
                # Collect interface block lines (already stripped)
                intf_lines.append(stripped)

        # Handle last interface if file doesn't end with "!"
        if current_intf:
            result.update(_process_interface_block(current_intf, intf_lines))

        return result
    except FileNotFoundError:
        return {}
    except PermissionError as e:
        logger.error(f"Permission denied reading startup-config: {e}")
        return {}
    except Exception as e:
        logger.error(f"Error reading interface IP config from startup-config: {e}")
        return {}
