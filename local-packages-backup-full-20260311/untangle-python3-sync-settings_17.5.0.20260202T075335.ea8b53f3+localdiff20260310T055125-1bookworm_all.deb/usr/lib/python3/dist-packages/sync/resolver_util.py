import os

from sync.common import Logger

logger = Logger.getInstance()


class ResolverUtil:
    @staticmethod
    def write_resolve_file(file, prefix, domainName, dnsServer, preserveOptions) -> None:
        existing_options = None

        # extract existing options before we rewrite the whole thing
        if preserveOptions and os.path.exists(file):
            os_file = open(file)
            for line in os_file:
                if line.startswith("options"):
                    existing_options = line
            os_file.close()

        filename = prefix + file
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")

        file.write("\n")
        if dnsServer is not None:
            file.write(f"nameserver {dnsServer}\n")

        if domainName is not None:
            file.write(f"search {domainName}\n")

        if existing_options is not None:
            file.write(f"{existing_options}\n")

        file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))
