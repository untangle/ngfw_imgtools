"""nftables_util provides nftable utility functions"""

import contextlib
import copy
import re
from typing import Optional
from uuid import uuid4

import sync.network_util
import sync.registrar
from sync.board_util import BoardUtil
from sync.settings_exception import SettingsException

# long functions (case statements etc)


# long argument lists


PROTOCOL_MAP = {
    "1": "icmp",
    "6": "tcp",
    "17": "udp",
    "33": "dccp",
    "132": "sctp",
    "136": "udplite",
}

SET_MEMBERSHIP_TRANSLATION = {
    "SOURCE_ADDRESS": "ip saddr",
    "DESTINATION_ADDRESS": "ip daddr",
    "IP_PROTOCOL . SOURCE_ADDRESS": "ip protocol . ip saddr",
    "IP_PROTOCOL . DESTINATION_ADDRESS": "ip protocol . ip daddr",
}


class NonsensicalException(Exception):
    """
    This exception is thrown when creating a rule command of a non-sensical rule

    This is used in cases like a user wants to create a rule to block when
    dns_prediction == netflix.com and source_address == 192.168.1.100
    In this case we'll add this rule to both the ip and ip6 tables, but in the ip6 table
    this makes no sense and we just want this rule silently ignored without an error.
    """


def sanitize_condition(condition):
    """
    Sanitize a condition by correcting the types
    """
    condtype = condition.get("type")
    op = condition.get("op")
    value = condition.get("value")
    unit = condition.get("rate_unit")
    burst_unit = condition.get("burst_unit")

    if condtype is None:
        raise SettingsException(
            message_str="Condition missing type: " + str(condition.get("ruleId"))
        )
    if value is None:
        raise SettingsException(
            message_str="Condition missing value: " + str(condition.get("ruleId"))
        )
    if op is None:
        raise SettingsException(
            message_str="Condition missing op: " + str(condition.get("ruleId"))
        )

    condition["type"] = str(condtype)  # change all types to string
    condition["op"] = str(op)  # change all types to string
    condition["value"] = str(value)  # change all types to string
    condition["unit"] = str(unit)  # change all types to string
    condition["burst_unit"] = str(burst_unit)  # change all types to string

    if '"' in condition.get("value"):
        raise SettingsException(
            message_str="Invalid character in condition value: " + str(condition.get("value"))
        )

    return condition


def validate_shaping_rule(conditions, action) -> None:
    """
    Validate the rule action corresponding to condition type and operator  within the shaping rule.
    Case 1: If the condition is 'Limit Rate' and op is '<' then action should be 'Set Priority'.
    Case 2: If the condition is 'Limit Rate' and op is '>' then action should be 'Limit Exceed Action'.
    Case 3: If 'Limit Rate' is not one of the conditions in the rule, then 'Limit Exceed Action' is not allowed.
    """
    limit_option = False
    if conditions is None:
        return
    check_action(action)

    action_type = action.get("type")
    if action_type not in ["SET_PRIORITY", "LIMIT_EXCEED_ACTION"]:
        return

    for condition in conditions:
        condition_type = condition.get("type")
        op = condition.get("op")
        if condition_type == "LIMIT_RATE":
            limit_option = True
            if op == ">" and action_type != "LIMIT_EXCEED_ACTION":
                raise SettingsException(message_str="Select 'Limit Exceed Action' action")
            if op == "<" and action_type != "SET_PRIORITY":
                raise SettingsException(message_str="Select 'Set Priority' action")
            break

    # The 'return' action in a base chain is equivalent to 'accept'. However, 'prioritization-rules' is not a base chain.
    # So for 'Limit Rate' condition write 'accept' instead of 'return' in the nft rule.
    # In rule_expression() return_action is set to True for prioritization-rules chain. hemce resetting it.
    if limit_option is True:
        action["return_action"] = False

    if limit_option is False and action_type == "LIMIT_EXCEED_ACTION":
        raise SettingsException(
            message_str="'Limit Exceed Action' is supported when 'Limit Rate' is configured with op '>'"
        )

    return


def check_operation(op, array) -> None:
    """Utility function to check that op is in array"""
    if op not in array:
        raise SettingsException(message_str="Unsupported operation " + str(op))


def check_val_is_string(val) -> bool:
    """
    Utility function to check if the value's contents is a string
    :param val (string) - The value data
    """

    return re.search("[a-zA-Z]", val) is not None


def op_str(op) -> Optional[str]:
    """
    Returns a command-line safe version of the operation
    Appends spaces to the beginning and end
    """
    if op == "==":
        return " "
    if op == "!=":
        return " != "
    if op == "<":
        return " < "
    if op == ">":
        return " > "
    if op == "<=":
        return " <= "
    if op == ">=":
        return " >= "
    return None


def ip_protocol_number_to_str(ip_protocol):
    """
    Converts 6, 17, 33, 132, 136 to the proper ip protocol supported for sport/dport nft conditions
    All other values unchanged
    """
    return PROTOCOL_MAP.get(str(ip_protocol), ip_protocol)


def value_str(value):
    """
    Returns a nft formatted value
    If the string contains a comma, it separates into nft list
    """
    if len(value.split(",")) < 2:
        return '"' + value + '"'
    return '"{' + value + '}"'


def numerical_val(value):
    """
    numerical_val returns an NFT formatted value representing an IP address
    or port value.  If the value contains a comma, the results are split
    into an NFT list
    """
    if len(value.split(",")) < 2:
        return value
    return "{" + value + "}"


def selector_expression(typ, family, ip_protocol=None):
    """generic helper function to build a basic nftables selector expression"""
    if typ == "IP_PROTOCOL":
        return "meta l4proto"
    if typ == "SOURCE_ADDRESS":
        if family not in ["ip", "inet"]:
            msg = f"Ignore IPv4 family: {family}"
            raise NonsensicalException(msg)
        return "ip saddr"
    if typ == "DESTINATION_ADDRESS":
        if family not in ["ip", "inet"]:
            msg = f"Ignore IPv4 family: {family}"
            raise NonsensicalException(msg)
        return "ip daddr"
    if typ == "SOURCE_ADDRESS_V6":
        if family not in ["ip6", "inet"]:
            msg = f"Ignore IPv6 family: {family}"
            raise NonsensicalException(msg)
        return "ip6 saddr"
    if typ == "DESTINATION_ADDRESS_V6":
        if family not in ["ip6", "inet"]:
            msg = f"Ignore IPv6 family: {family}"
            raise NonsensicalException(msg)
        return "ip6 daddr"
    if typ == "SOURCE_PORT":
        if ip_protocol is None:
            raise SettingsException(message_str="Undefined protocol with port condition")
        return ip_protocol_number_to_str(ip_protocol) + " sport"
    if typ == "DESTINATION_PORT":
        if ip_protocol is None:
            raise SettingsException(message_str="Undefined protocol with port condition")
        return ip_protocol_number_to_str(ip_protocol) + " dport"

    raise SettingsException(message_str="Unsupported selector type " + typ)


def condition_dict_expression(table, key, field, typ, op, value):
    """A generic helper funciton to build a basic nftables dict expression"""
    if table is None:
        raise SettingsException(message_str="Invalid table: " + str(table))
    if key is None:
        raise SettingsException(message_str="Invalid key: " + str(key))
    if field is None:
        raise SettingsException(message_str="Invalid field: " + str(field))
    if typ in ["long_string", "bool"] and op not in ("==", "!="):
        raise SettingsException(
            message_str="Unsupported operation " + str(op) + " for type " + typ
        )
    if typ in ["ipv4_addr", "ipv6_addr", "int"]:
        val = numerical_val(value)
        if "-" in val:
            ##
            ## Treat a range as a concatenation of two greater-than and less-than
            ## dict expressions which act as an AND.
            ##
            if op == "!=":
                # Converse is non-inclusive of start/end values.
                op = "<"
                right_op = ">"
            else:
                # Equal is inclusive of start/end values.
                op = ">="
                right_op = "<="
            vals = val.split("-")
            val = (
                vals[0]
                + " "
                + condition_dict_expression(table, key, field, typ, right_op, vals[1])
            )
    else:
        val = value_str(value)

    return (
        "dict "
        + table.strip()
        + " "
        + key.strip()
        + " "
        + field.strip()
        + " "
        + typ.strip()
        + op_str(op)
        + val
    )


##
## Named interface types and their numeric identifiers
##
INTERFACE_TYPES = {"unset": 0, "wan": 1, "lan": 2, "management": 3}


def condition_interface_type_expression(
    mark_exp, intf_type_mask, intf_type_shift, value, op
) -> str:
    """A generic helper for generating interface type expressions"""
    if op not in ("==", "!="):
        raise SettingsException(message_str="Unsupported operation " + str(op))

    for type_id, type_mark in INTERFACE_TYPES.items():
        if value == type_id or value == str(type_mark):
            op_match = "!= " if op != "==" else ""

            if type_mark == 0:
                mark_match = format(0, "#010x")
            else:
                mark_match = format((type_mark << intf_type_shift), "#010x")

            return f"{mark_exp} and {intf_type_mask} {op_match}{mark_match}"

    raise SettingsException(message_str="Invalid interface type expression: " + value)


def condition_interface_zone_expression(mark_exp, intf_mask, val_shift, value, op):
    """A generic helper for generating zone expressions"""
    if op not in ("==", "!="):
        raise SettingsException(message_str="Unsupported operation " + str(op))

    try:
        if op == "==":
            return mark_exp + " and " + intf_mask + " " + format(int(value) << val_shift, "#010x")
        return mark_exp + " and " + intf_mask + " != " + format(int(value) << val_shift, "#010x")
    except ValueError:
        raise SettingsException(message_str="Invalid interface condition value: " + str(value))


def condition_v4address_expression(addr_str, value, op, family):
    """Generic helper for making address expressions"""
    if family not in ["ip", "inet"]:
        msg = f"Ignore IPv4 family: {family}"
        raise NonsensicalException(msg)
    if ":" in value:
        raise SettingsException(message_str="Invalid IPv4 value: " + str(value))
    return "ip " + addr_str + op_str(op) + numerical_val(value)


def condition_address_type_expression(addr_str, value, op, family):
    """Generic helper for making destination_type expressions"""
    if family not in ["ip", "ip6", "inet"]:
        msg = f"Ignore family: {family}"
        raise NonsensicalException(msg)
    if value not in [
        "unspec",
        "unicast",
        "local",
        "broadcast",
        "anycast",
        "multicast",
        "blackhole",
        "unreachable",
        "prohibit",
    ]:
        raise SettingsException(message_str="Invalid address type value: " + str(value))
    return "fib " + addr_str + " type" + op_str(op) + value_str(value)


def condition_v6address_expression(addr_str, value, op, family):
    """Generic helper for making address expressions"""
    if family not in ["ip6", "inet"]:
        msg = f"Ignore IPv6 family: {family}"
        raise NonsensicalException(msg)
    if "." in value:
        raise SettingsException(message_str="Invalid IPv6 value: " + str(value))
    return "ip6 " + addr_str + op_str(op) + numerical_val(value)


def condition_port_expression(port_str, ip_protocol, value, op):
    """Generic helper for making port expressions"""
    if ip_protocol is None:
        raise SettingsException(
            message_str="Undefined protocol with port condition (missing port_protocol field)"
        )
    # If this is passed in here as a list, only take the first element. This occurs because we switched the UI element to a multiselect
    if isinstance(ip_protocol, list):
        ip_protocol = ip_protocol[0]

    return (
        ip_protocol_number_to_str(ip_protocol) + " " + port_str + op_str(op) + numerical_val(value)
    )


def condition_ct_state_expression(value, op):
    """Generic helper for making port expressions"""
    if "," in value:
        for val in value.split(","):
            if val not in ["established", "related", "new", "invalid"]:
                raise SettingsException(message_str=f"Invalid ct state value: {val}")
    elif value not in ["established", "related", "new", "invalid"]:
        raise SettingsException(message_str=f"Invalid ct state value: {value}")
    return "ct state " + op_str(op) + " " + value


def condition_ct_mark_expression(value, op):
    """Generic helper for making ct mark expressions"""
    check_mark(value)
    check_operation(op, ["==", "!="])
    return "ct mark & " + value + " " + str(op) + " " + value


def condition_mark_expression(mask_value, value, op):
    """
    Generic helper for making mark expressions. ANDs
    the mark with the given mask_value, and compares it against
    the given value with the op provided
    """
    check_mark(mask_value)
    check_operation(op, ["==", "!="])

    if not value.isdigit():
        raise SettingsException(message_str="Unsupported value " + str(value))

    return "meta mark & " + mask_value + " " + str(op) + " " + value


def condition_limit_rate_expression(value, op, rate_unit) -> str:
    """Generic helper for limit rate expressions"""
    if rate_unit is None:
        raise SettingsException(message_str="Limit rate expressions require rate_unit")
    rate_int = int(value)
    if op == "<":
        return "limit rate %d%s" % (rate_int, get_limit_rate_unit_string(rate_unit))
    return "limit rate over %d%s" % (rate_int, get_limit_rate_unit_string(rate_unit))


def condition_limit_rate_burst_expression(value, op, burst_unit) -> str:
    """Generic helper for limit rate burst expressions"""
    if burst_unit is None:
        raise SettingsException(message_str="Limit rate burst expressions require burst_unit")
    burst_int = int(value)
    return "burst %d%s" % (burst_int, get_limit_burst_unit_string(burst_unit))


def match_zone_intf_str_to_id(value, settings_file):
    settings = None
    if settings_file is None:
        settings_file = sync.registrar.get_main_settings()
    if settings_file is not None:
        settings = sync.SettingsFile(settings_file)
        settings.update_settings()
    if settings is None:
        return None
    # find the interfaceID of $value
    intf = sync.network_util.get_interface_by_device(settings.settings, value)
    if intf is None:
        return None
    return intf["interfaceId"]


def handle_membership_check_for_set_expression(condtype, membership_check_for_set, op, ruleId):
    """
    This function translates expressions like "<element> exists in nft set" or "<element> does not exist in nft set"
    :param condtype: (str) Element (some value of the packet) to be checked in the nft set. This can be a single value or
    a combination of values that could exist together as a single element in the nft set.
    :param membership_check_for_set: (set) Name of the nft set for which we are checking the membership of a particular element
    :param op: (str) == (Equals) or != (not equals) operator
    :param ruleId: (str) RuleId of this nft rule, used while raising exceptions
    :return: (str) nft expression for the json rule of the form: '<element> @membership_check_for_set" or "<element> != @membership_check_for_set'
    """
    if concat_str := SET_MEMBERSHIP_TRANSLATION.get(condtype):
        equality = " @"
        if op == "!=":
            equality = " !=" + equality
        return concat_str + equality + membership_check_for_set
    raise SettingsException(
        message_str="Unsupported condition type "
        + condtype
        + " in a set membership check "
        + str(ruleId)
    )


def condition_expression(condition, family, multi_type=None, multi_iter=None, settings_file=None):
    """Build nft expressions from the JSON condition object"""
    condition = sanitize_condition(condition)
    condtype = condition.get("type")
    membership_check_for_set = condition.get("membership_check_for_set")
    op = condition.get("op")
    value = condition.get("value")
    unit = condition.get("rate_unit")
    burst_unit = condition.get("burst_unit")
    mask_value = condition.get("mask_value")

    # With membership_check_for_set we can test if a particular element or concatenation of elements is a member of the nft set.
    if membership_check_for_set:
        return handle_membership_check_for_set_expression(
            condtype, membership_check_for_set, op, condition.get("ruleId")
        )
    if condtype == "IP_PROTOCOL":
        check_operation(op, ["==", "!="])
        if check_val_is_string(value):
            return "meta l4proto" + op_str(op) + value_str(value.lower())
        return "meta l4proto" + op_str(op) + numerical_val(value.lower())
    if condtype == "SOURCE_INTERFACE_ZONE":
        if check_val_is_string(value):
            # Find the interface ID
            intfId = match_zone_intf_str_to_id(value, settings_file)
            if intfId is None:
                return ""
            return condition_interface_zone_expression("mark", "0x000000ff", 0, intfId, op)
        return condition_interface_zone_expression("mark", "0x000000ff", 0, value, op)
    if condtype == "DESTINATION_INTERFACE_ZONE":
        if check_val_is_string(value):
            # Find the interface ID
            intfId = match_zone_intf_str_to_id(value, settings_file)
            if intfId is None:
                return ""
            return condition_interface_zone_expression("mark", "0x0000ff00", 8, intfId, op)
        return condition_interface_zone_expression("mark", "0x0000ff00", 8, value, op)
    if condtype == "SOURCE_INTERFACE_TYPE":
        return condition_interface_type_expression("mark", "0x03000000", 24, value, op)
    if condtype == "DESTINATION_INTERFACE_TYPE":
        return condition_interface_type_expression("mark", "0x0c000000", 26, value, op)
    if condtype == "SOURCE_INTERFACE_NAME":
        check_operation(op, ["==", "!="])
        return "iifname" + op_str(op) + value_str(value)
    if condtype == "DESTINATION_INTERFACE_NAME":
        check_operation(op, ["==", "!="])
        return "oifname" + op_str(op) + value_str(value)
    if condtype == "SOURCE_ADDRESS":
        return condition_v4address_expression("saddr", value, op, family)
    if condtype == "SOURCE_ADDRESS_TYPE":
        return condition_address_type_expression("saddr", value, op, family)
    if condtype == "DESTINATION_ADDRESS":
        return condition_v4address_expression("daddr", value, op, family)
    if condtype == "DESTINATION_ADDRESS_TYPE":
        return condition_address_type_expression("daddr", value, op, family)
    if condtype == "SOURCE_LOCAL":
        return condition_address_type_expression("saddr", "local", op, family)
    if condtype == "DESTINED_LOCAL":
        return condition_address_type_expression("daddr", "local", op, family)
    if condtype == "SOURCE_ADDRESS_V6":
        return condition_v6address_expression("saddr", value, op, family)
    if condtype == "DESTINATION_ADDRESS_V6":
        return condition_v6address_expression("daddr", value, op, family)
    if condtype == "SOURCE_PORT":
        if multi_type is not None and multi_iter is not None and multi_type == "port_protocol":
            return condition_port_expression("sport", multi_iter, value, op)
        return condition_port_expression("sport", condition.get("port_protocol"), value, op)
    if condtype == "DESTINATION_PORT":
        if multi_type is not None and multi_iter is not None and multi_type == "port_protocol":
            return condition_port_expression("dport", multi_iter, value, op)
        return condition_port_expression("dport", condition.get("port_protocol"), value, op)
    if condtype == "CLIENT_INTERFACE_ZONE":
        if check_val_is_string(value):
            # Find the interface ID
            intfId = match_zone_intf_str_to_id(value, settings_file)
            if intfId is None:
                return ""
            return condition_interface_zone_expression("ct mark", "0x000000ff", 0, intfId, op)
        return condition_interface_zone_expression("ct mark", "0x000000ff", 0, value, op)
    if condtype == "SERVER_INTERFACE_ZONE":
        if check_val_is_string(value):
            # Find the interface ID
            intfId = match_zone_intf_str_to_id(value, settings_file)
            if intfId is None:
                return ""
            return condition_interface_zone_expression("ct mark", "0x0000ff00", 8, intfId, op)
        return condition_interface_zone_expression("ct mark", "0x0000ff00", 8, value, op)
    if condtype == "CLIENT_INTERFACE_TYPE":
        return condition_interface_type_expression("ct mark", "0x03000000", 24, value, op)
    if condtype == "SERVER_INTERFACE_TYPE":
        return condition_interface_type_expression("ct mark", "0x0c000000", 26, value, op)
    if condtype == "CLIENT_ADDRESS":
        return condition_dict_expression(
            "sessions", "ct id", "client_address", "ipv4_addr", op, value
        )
    if condtype == "SERVER_ADDRESS":
        return condition_dict_expression(
            "sessions", "ct id", "server_address", "ipv4_addr", op, value
        )
    if condtype == "LOCAL_ADDRESS":
        return condition_dict_expression(
            "sessions", "ct id", "local_address", "ipv4_addr", op, value
        )
    if condtype == "REMOTE_ADDRESS":
        return condition_dict_expression(
            "sessions", "ct id", "remote_address", "ipv4_addr", op, value
        )
    if condtype == "CLIENT_ADDRESS_V6":
        return condition_dict_expression(
            "sessions", "ct id", "client_address", "ipv6_addr", op, value
        )
    if condtype == "SERVER_ADDRESS_V6":
        return condition_dict_expression(
            "sessions", "ct id", "server_address", "ipv6_addr", op, value
        )
    if condtype == "LOCAL_ADDRESS_V6":
        return condition_dict_expression(
            "sessions", "ct id", "local_address", "ipv6_addr", op, value
        )
    if condtype == "REMOTE_ADDRESS_V6":
        return condition_dict_expression(
            "sessions", "ct id", "remote_address", "ipv6_addr", op, value
        )
    if condtype == "CLIENT_PORT":
        return condition_dict_expression("sessions", "ct id", "client_port", "int", op, value)
    if condtype == "SERVER_PORT":
        return condition_dict_expression("sessions", "ct id", "server_port", "int", op, value)
    if condtype == "LOCAL_PORT":
        return condition_dict_expression("sessions", "ct id", "local_port", "int", op, value)
    if condtype == "REMOTE_PORT":
        return condition_dict_expression("sessions", "ct id", "remote_port", "int", op, value)
    if condtype == "CLIENT_HOSTNAME":
        return condition_dict_expression(
            "sessions", "ct id", "client_hostname", "long_string", op, value
        )
    if condtype == "SERVER_HOSTNAME":
        return condition_dict_expression(
            "sessions", "ct id", "server_hostname", "long_string", op, value
        )
    if condtype == "LOCAL_HOSTNAME":
        return condition_dict_expression(
            "sessions", "ct id", "local_hostname", "long_string", op, value
        )
    if condtype == "REMOTE_HOSTNAME":
        return condition_dict_expression(
            "sessions", "ct id", "remote_hostname", "long_string", op, value
        )
    if condtype == "CLIENT_USERNAME":
        return condition_dict_expression(
            "sessions", "ct id", "client_username", "long_string", op, value
        )
    if condtype == "CLIENT_DNS_HINT":
        return condition_dict_expression(
            "sessions", "ct id", "client_dns_hint", "long_string", op, value
        )
    if condtype == "SERVER_USERNAME":
        return condition_dict_expression(
            "sessions", "ct id", "server_username", "long_string", op, value
        )
    if condtype == "SERVER_DNS_HINT":
        return condition_dict_expression(
            "sessions", "ct id", "server_dns_hint", "long_string", op, value
        )
    if condtype == "LOCAL_USERNAME":
        return condition_dict_expression(
            "sessions", "ct id", "local_username", "long_string", op, value
        )
    if condtype == "REMOTE_USERNAME":
        return condition_dict_expression(
            "sessions", "ct id", "remote_username", "long_string", op, value
        )
    if condtype == "APPLICATION_ID":
        return condition_dict_expression(
            "sessions", "ct id", "application_id", "long_string", op, value
        )
    if condtype == "APPLICATION_NAME":
        return condition_dict_expression(
            "sessions", "ct id", "application_name", "long_string", op, value
        )
    if condtype == "APPLICATION_CONFIDENCE":
        return condition_dict_expression(
            "sessions", "ct id", "application_confidence", "int", op, value
        )
    if condtype == "APPLICATION_PROTOCHAIN":
        return condition_dict_expression(
            "sessions", "ct id", "application_protochain", "long_string", op, value
        )
    if condtype == "APPLICATION_DETAIL":
        return condition_dict_expression(
            "sessions", "ct id", "application_detail", "long_string", op, value
        )
    if condtype == "APPLICATION_PRODUCTIVITY":
        return condition_dict_expression(
            "sessions", "ct id", "application_productivity", "int", op, value
        )
    if condtype == "APPLICATION_RISK":
        return condition_dict_expression("sessions", "ct id", "application_risk", "int", op, value)
    if condtype == "APPLICATION_CATEGORY":
        return condition_dict_expression(
            "sessions", "ct id", "application_category", "long_string", op, value
        )
    if condtype == "APPLICATION_ID_INFERRED":
        return condition_dict_expression(
            "sessions", "ct id", "application_id_inferred", "long_string", op, value
        )
    if condtype == "APPLICATION_NAME_INFERRED":
        return condition_dict_expression(
            "sessions", "ct id", "application_name_inferred", "long_string", op, value
        )
    if condtype == "APPLICATION_CONFIDENCE_INFERRED":
        return condition_dict_expression(
            "sessions", "ct id", "application_confidence_inferred", "int", op, value
        )
    if condtype == "APPLICATION_PROTOCHAIN_INFERRED":
        return condition_dict_expression(
            "sessions", "ct id", "application_protochain_inferred", "long_string", op, value
        )
    if condtype == "APPLICATION_PRODUCTIVITY_INFERRED":
        return condition_dict_expression(
            "sessions", "ct id", "application_productivity_inferred", "int", op, value
        )
    if condtype == "APPLICATION_RISK_INFERRED":
        return condition_dict_expression(
            "sessions", "ct id", "application_risk_inferred", "int", op, value
        )
    if condtype == "APPLICATION_CATEGORY_INFERRED":
        return condition_dict_expression(
            "sessions", "ct id", "application_category_inferred", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_CN":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_cn", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_SN":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_sn", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_C":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_c", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_O":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_o", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_OU":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_ou", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_L":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_l", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_P":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_p", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_SA":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_sa", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_PC":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_pc", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_SAN":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_subject_san", "long_string", op, value
        )
    if condtype == "CERT_SUBJECT_DNS":
        return condition_dict_expression(
            "sessions", "ct id", "cert_dns_names", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_CN":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_cn", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_SN":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_sn", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_C":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_c", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_O":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_o", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_OU":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_ou", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_L":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_l", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_P":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_p", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_SA":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_sa", "long_string", op, value
        )
    if condtype == "CERT_ISSUER_PC":
        return condition_dict_expression(
            "sessions", "ct id", "certificate_issuer_pc", "long_string", op, value
        )
    if condtype == "CT_STATE":
        return condition_ct_state_expression(value, op)
    if condtype == "CT_MARK":
        return condition_ct_mark_expression(value, op)
    if condtype == "META_MARK":
        return condition_mark_expression(mask_value, value, op)
    if condtype == "LIMIT_RATE":
        check_operation(op, ["<", ">"])
        return condition_limit_rate_expression(value, op, unit)
    if condtype == "BURST_SIZE":
        check_operation(op, ["=="])
        return condition_limit_rate_burst_expression(value, op, burst_unit)
    if condtype == "GEOIP":
        return condition_dict_expression(
            "sessions", "ct id", "server_country", "long_string", op, value
        )
    raise SettingsException(
        message_str="Unsupported condition type " + condtype + " " + str(condition.get("ruleId"))
    )


def conditions_expression(
    conditions, family, multi_type=None, multi_iter=None, settings_file=None
):
    """
    This method takes a list of conditions from a rule and translates them into a string containing the nftables conditions
    It returns a list of strings, because some set of conditions require multiple nftables rules
    Example input: ['type':'SOURCE_INTERFACE', 'value':'1'] -> "ct mark and 0xff == 0x01"
    Example input: ['type':'DESTINATION_PORT', 'value':'123'] -> "tcp dport 123"
    """
    if conditions is None:
        return ""

    strcat = ""

    new_conditions = []
    for condition in conditions:
        if condition.get("type") in ["SERVER_ADDRESS", "CLIENT_ADDRESS"]:
            if "," in condition.get("value") and "-" in condition.get("value"):
                ip_addrs = []
                split_values = condition.get("value").split(",")
                for item in split_values:
                    # create a new condition if there is a ip range and remove the item from split values array
                    if "-" in item:
                        new_condition = copy.deepcopy(condition)
                        new_condition["value"] = item
                        new_conditions.append(new_condition)
                    else:
                        ip_addrs.append(item)
                ips = ",".join(ip_addrs)
                condition["value"] = ips
    if len(new_conditions) > 0:
        conditions.extend(new_conditions)

    for condition in conditions:
        group_selector = condition.get("group_selector")
        if group_selector is not None:
            conditions_expression.meter_id = getattr(conditions_expression, "meter_id", 0) + 1
            if condition.get("port_protocol"):
                strcat = strcat + " meter meter-%d { %s" % (
                    conditions_expression.meter_id,
                    selector_expression(group_selector, family, condition.get("port_protocol")),
                )
            else:
                strcat = strcat + " meter meter-%d { %s" % (
                    conditions_expression.meter_id,
                    selector_expression(group_selector, family),
                )

        add_str = condition_expression(condition, family, multi_type, multi_iter, settings_file)
        if add_str != "":
            strcat = strcat + " " + add_str

        if group_selector is not None:
            strcat = strcat + " }"

    return strcat.strip()


def handle_set_priority(json_action, typ):
    priority = json_action.get("priority")
    if priority is None:
        raise SettingsException(
            message_str="Invalid action: Missing required parameter for action type " + str(typ)
        )
    priority_int = int(priority) & 0xFF
    if priority_int < 1 or priority_int > 21:
        raise SettingsException(message_str="Priority out of range (1-21): %d" % priority_int)
    return_action = ""
    return_action = " return" if json_action.get("return_action") is True else " accept"

    return (
        "meta mark set mark and 0xff00ffff or 0x00{}0000".format(f"{priority_int:02x}")
        + return_action
    )


def action_expression(json_action, family):
    """This method takes an method json object and provides the nft expression as a string"""
    check_action(json_action)
    typ = json_action.get("type")
    # Simply return an empty string for the "DOS-BLOCK" action as we don't want any of the accept/ reject/ drop/ return actions for it
    if typ == "DOS-BLOCK":
        return ""
    if typ == "REJECT":
        return "reject"
    if typ == "DROP":
        return "drop"
    if typ == "ACCEPT":
        return "accept"
    if typ == "RETURN":
        return "return"
    if typ == "DNAT":
        addr = json_action.get("dnat_address")
        port = json_action.get("dnat_port")
        if addr is None:
            raise SettingsException(
                message_str="Invalid action: Missing required address parameter for action type "
                + str(typ)
            )
        if family == "ip" and ":" in addr:
            msg = f"Ignore IPv6 for IPv4 DNAT: {family}"
            raise NonsensicalException(msg)
        if family == "ip6" and "." in addr:
            msg = f"Ignore IPv4 for IPv6 DNAT: {family}"
            raise NonsensicalException(msg)
        port_int = None
        if port is not None:
            port_int = int(port)
        if port_int is not None:
            return "dnat to %s:%i" % (addr, port_int)
        return f"dnat to {addr}"
    if typ == "SNAT":
        addr = json_action.get("snat_address")
        if addr is None:
            raise SettingsException(
                message_str="Invalid action: Missing required parameter for action type "
                + str(typ)
            )
        if family == "ip" and ":" in addr:
            msg = f"Ignore IPv6 for IPv4 SNAT: {family}"
            raise NonsensicalException(msg)
        if family == "ip6" and "." in addr:
            msg = f"Ignore IPv4 for IPv6 SNAT: {family}"
            raise NonsensicalException(msg)
        return f"snat to {addr}"
    if typ == "MASQUERADE":
        return "masquerade"
    if typ == "JUMP":
        chain = json_action.get("chain")
        if chain is None:
            raise SettingsException(
                message_str="Invalid action: Missing required parameter for action type "
                + str(typ)
            )
        return "jump " + chain
    if typ == "GOTO":
        chain = json_action.get("chain")
        if chain is None:
            raise SettingsException(
                message_str="Invalid action: Missing required parameter for action type "
                + str(typ)
            )
        return "goto " + chain
    if typ == "SET_PRIORITY":
        return handle_set_priority(json_action, typ)
    if typ == "LIMIT_EXCEED_ACTION":
        limit_exceed_action = json_action.get("limit_exceed_action")
        if limit_exceed_action is None:
            raise SettingsException(message_str="Required Limit Exceed Action")

        if limit_exceed_action == "PRIORITY":
            return handle_set_priority(json_action, typ)

        limit_exceed_action_str = ""
        if limit_exceed_action in ["ACCEPT", "REJECT", "DROP"]:
            limit_exceed_action_str = " " + limit_exceed_action.lower()
        else:
            limit_exceed_action_str = " " + "continue"

        return limit_exceed_action_str
    if typ == "WAN_POLICY":
        policy = format_guid_for_nft(json_action.get("policy"))
        if policy is None:
            raise SettingsException(
                message_str="Invalid action: Missing required parameter for action type "
                + str(typ)
            )
        return f"jump route-to-policy-{policy}"
    raise SettingsException(message_str="Unknown action type: " + str(json_action))


def add_to_set_expression(add_to_set_expressions, ruleId):
    """This method takes json and creates an add SET expression"""
    translation = {
        "SOURCE_ADDRESS": "ip saddr",
        "DESTINATION_ADDRESS": "ip daddr",
        "IP_PROTOCOL": "ip protocol",
    }
    strcat = ""
    for add_to_set_expression in add_to_set_expressions:
        if membership_check_for_set := add_to_set_expression.get("membership_check_for_set"):
            strcat += handle_membership_check_for_set_expression(
                add_to_set_expression.get("type"),
                membership_check_for_set,
                add_to_set_expression.get("op"),
                ruleId,
            )
            continue
        strcat += " add @"
        strcat += "{} {{ ".format(add_to_set_expression["set_name"])
        # We would either be required to- (1) add a single element or (2) add concatenated elements to the nft sets.
        # Thus add_to_set_expression["elements"] is a list. In nft syntax, concatenations are done with a dot notation
        # in between the elements to be concatenated.
        for i, element in enumerate(add_to_set_expression["elements"]):
            strcat += translation[element]
            # Don't put " . " after the last element to be concatenated
            if i != len(add_to_set_expression["elements"]) - 1:
                strcat += " . "
        ct_count = add_to_set_expression.get("ct_count")
        if ct_count is not None:
            strcat += " ct count"
            if add_to_set_expression.get("ct_count_operator") == ">":
                strcat += " " + "over"
            strcat += " " + str(ct_count)
        strcat += " } "

    return strcat


def logs_expression(logs):
    """This method takes an method json object and provides the nft log action(s)"""

    strcat = ""
    for log in logs:
        check_log(log)
        typ = log.get("type")

        if typ == "COUNTER":
            strcat = strcat + " counter"
        elif typ == "NFLOG":
            prefix = log.get("prefix")
            strcat = strcat + f' log prefix "{prefix} " group 0'
        elif typ == "DICT":
            field = log.get("field")
            value = log.get("value")
            field_type = log.get("field_type")
            if field_type is None or field_type == "LONG_STRING":
                strcat = strcat + f" dict sessions ct id {field} long_string set {value}"
            elif field_type == "INT":
                strcat = strcat + f" dict sessions ct id {field} int set {value}"
        else:
            raise SettingsException(message_str="Unknown log type: " + str(log))

    return strcat.strip()


def rule_expression(json_rule, family, table, chain, multi_type=None, multi_iter=None):
    """Builds an nft rule from the JSON rule object"""
    check_rule(json_rule)

    if chain == "prioritization-rules":
        # MFW-2496: Setting return_action for this chain because we need to add additional RETURN action for rules in this chain
        action = json_rule.get("action")
        action["return_action"] = True
    rule_exp = ""
    conditions = json_rule.get("conditions")
    if conditions is not None:
        rule_exp = (
            rule_exp + " " + conditions_expression(conditions, family, multi_type, multi_iter)
        )

    # Translation for adding element or concatenation of elements to the set
    add_to_set = json_rule.get("add_to_set")
    if add_to_set:
        rule_exp = rule_exp + " " + add_to_set_expression(add_to_set, json_rule.get("ruleId"))

    logs = json_rule.get("logs")
    if logs is not None:
        rule_exp = rule_exp + " " + logs_expression(logs)

    validate_shaping_rule(conditions, json_rule.get("action"))

    action_exp = action_expression(json_rule.get("action"), family)
    rule_exp = rule_exp + " " + action_exp

    return "add rule " + family + " " + table + " " + chain + " " + rule_exp[1:]


def rule_cmd(json_rule, family, table, chain):
    """This method takes a rule json object, and returns a list of nft commands associated with the rule"""
    check_rule(json_rule)
    nft_rule_list = []

    if not json_rule.get("enabled"):
        return None

    try:
        multi_type, multi_iter = determine_multi_rule(json_rule)
        if multi_type is not None and multi_iter is not None:
            for itr in multi_iter:
                nft_rule_list.append(
                    rule_expression(
                        json_rule, family, table, chain, multi_type=multi_type, multi_iter=str(itr)
                    )
                )

        else:
            nft_rule_list.append(rule_expression(json_rule, family, table, chain))
        return nft_rule_list
    except NonsensicalException:
        return None
    except:
        raise


def determine_multi_rule(json_rule):
    """
    determine_multi_rule will return an object to iterate if we need to write multiple NFT rules for this mfw rule
    :param json_rule (string) - the json rule
    """
    # Currently only SOURCE_PORT and DESTINATION_PORT conditions might require additional rules
    conditions = json_rule.get("conditions")
    for cnd in conditions:
        if cnd.get("type") == "SOURCE_PORT" or cnd.get("type") == "DESTINATION_PORT":
            # Check if multiple port_protocols are passed in
            if "," in str(cnd.get("port_protocol")):
                return "port_protocol", cnd.get("port_protocol")
    return None, None


def chain_create_cmd(json_chain, family, chain_type, table) -> str:
    """Return the nft command to create this chain"""
    check_chain(json_chain)
    check_family(family)

    name = json_chain.get("name")

    # type used to be stored in the chain JSON definition
    # keep this for backwards compatibility
    if chain_type is None:
        chain_type = json_chain.get("type")

    # vote is only valid in the ip, ip6 familyt, but the vote table is ip,ip6,inet just ignore inet
    if json_chain.get("base") and json_chain.get("type") == "route" and family == "inet":
        msg = "Ignore inet/route chains"
        raise NonsensicalException(msg)

    if json_chain.get("base"):
        hook = json_chain.get("hook")
        priority = json_chain.get("priority")
        if chain_type is None or chain_type not in ["filter", "route", "nat"]:
            raise SettingsException(message_str=f"Invalid type ({chain_type}) for chain {name}")
        if hook is None or hook not in [
            "prerouting",
            "input",
            "forward",
            "output",
            "postrouting",
            "ingress",
        ]:
            raise SettingsException(message_str=f"Invalid hook ({hook}) for chain {name}")
        if priority is None or (
            isinstance(priority, (int, float)) and (priority < -500 or priority > 500)
        ):
            raise SettingsException(
                message_str=f"Invalid priority ({priority:g}) for chain {name}"
            )
        return f"add chain {family} {table} {name} {{ type {chain_type} hook {hook} priority {priority!s} ; }}"
    return f"add chain {family} {table} {name}"


def chain_rules_cmds(json_chain, family, chain_type, table):
    """Return all the commands to create and populate this chain"""
    check_chain(json_chain)

    # type used to be stored in the chain JSON definition
    # keep this for backwards compatibility
    if chain_type is None:
        chain_type = json_chain.get("type")

    # route is only valid in the ip, ip6 families
    if json_chain.get("base") and chain_type == "route" and family not in ["ip", "ip6"]:
        msg = "Ignore inet/route chains"
        raise NonsensicalException(msg)

    cmds = []
    for rule in json_chain["rules"]:
        rule_cmd_items = rule_cmd(rule, family, table, json_chain["name"])
        if rule_cmd_items is not None:
            if BoardUtil.is_platform_os_eos():
                for i, rule_cmd_item in enumerate(rule_cmd_items):
                    if "dict" in rule_cmd_item:
                        str = "#Dict rules are not supported in this platform"
                        cmds.append(str)
                        rule_cmd_items[i] = "#" + rule_cmd_item
            cmds.extend(rule_cmd_items)
    return "\n".join(cmds)


def set_create_cmd(json_set, family, table) -> str:
    """Return the nft command to create this set"""
    check_set(json_set)
    check_family(family)
    timeout_str = ""
    timeout = json_set.get("timeout")
    size = json_set.get("size")
    if size:
        timeout_str += f"size {size} ; "
    if timeout:
        timeout_str += f"flags dynamic, timeout ; timeout {timeout} ;"
    elif json_set.get("dynamic"):
        timeout_str += "flags dynamic ;"

    return "add set {} {} {} {{ type {} ; {} }}".format(
        family, table, json_set.get("name"), json_set.get("type"), timeout_str
    )


def set_delete_cmd(json_set, family, table) -> str:
    """Return the nft command to delete the set: nft delete set <family> <table_name> <set_name>"""
    check_set(json_set)
    check_family(family)
    return "delete set {} {} {}".format(family, table, json_set.get("name"))


def table_create_cmd(json_table) -> str:
    """Return the nft command to create this table"""
    check_table(json_table)
    return "add table {} {}".format(json_table.get("family"), json_table.get("name"))


def table_flush_cmd(json_table):
    """Return the nft command to flush this table"""
    cmd = table_create_cmd(json_table)
    return cmd.replace("add ", "flush ")


def table_delete_cmd(json_table):
    """Return the nft command to delete this table"""
    cmd = table_create_cmd(json_table)
    return cmd.replace("add ", "delete ")


def table_all_cmds(json_table):
    """Return all the commands to create, flush, and populate this table"""
    check_table(json_table, allow_multiple_families=True)
    cmds = []
    name = json_table.get("name")
    family = json_table.get("family")
    chain_type = json_table.get("chain_type")
    if "," in family:
        families = family.split(",")
        strcat = ""
        for fam in families:
            # make shallow copies and create separate tables
            json_table_fam = copy.copy(json_table)
            json_table_fam["family"] = fam
            strcat += table_all_cmds(json_table_fam) + "\n"
        return strcat

    cmds.append(table_create_cmd(json_table))
    cmds.append(table_flush_cmd(json_table))
    for json_set in json_table.get("sets") or []:
        try:
            # Before we can execute the delete set command, we need to have the set created already otherwise delete fails.
            # During create_settings, the set does not exist already. Hence, create a set first, then run delete.
            # In other cases, when the set is already created, first create command won't error out, so this is safe.
            cmds.append(set_create_cmd(json_set, family, name))
            cmds.append(set_delete_cmd(json_set, family, name))
            cmds.append(set_create_cmd(json_set, family, name))
        except NonsensicalException:
            pass
    for json_chain in json_table.get("chains"):
        with contextlib.suppress(NonsensicalException):
            cmds.append(chain_create_cmd(json_chain, family, chain_type, name))
    for json_chain in json_table.get("chains"):
        with contextlib.suppress(NonsensicalException):
            cmds.append(chain_rules_cmds(json_chain, family, chain_type, name))
    return "\n".join(cmds)


def check_set(json_set) -> None:
    """Check the provided set has the required attributes, throw exception if not"""
    if json_set is None:
        raise SettingsException(message_str="Invalid set: null")
    name = json_set.get("name")
    type = json_set.get("type")
    if name is None or not legal_nft_name(name):
        raise SettingsException(message_str=f"Invalid name ({name}) for set")
    if type is None:
        raise SettingsException(message_str=f"Invalid rules (null) in set {name}")


def check_chain(json_chain) -> None:
    """Check the provided chain has the required attributes, throw exception if not"""
    if json_chain is None:
        raise SettingsException(message_str="Invalid chain: null")
    name = json_chain.get("name")
    rules = json_chain.get("rules")
    if name is None or not legal_nft_name(name):
        raise SettingsException(message_str=f"Invalid name ({name}) for chain")
    if rules is None:
        raise SettingsException(message_str=f"Invalid rules (null) in chain {name}")


def check_rule(json_rule) -> None:
    """Check the provided rule has the required attributes, throw exception if not"""
    if json_rule is None:
        raise SettingsException(message_str="Invalid rule: null")
    rule_id = json_rule.get("ruleId")
    if rule_id is None:
        raise SettingsException(message_str="Missing ruleId: " + str(json_rule))


def check_table(json_table, allow_multiple_families=False) -> None:
    """Check the provided table has the required attributes, throw exception if not"""
    if json_table is None:
        raise SettingsException(message_str="Invalid table: null")
    name = json_table.get("name")
    family = json_table.get("family")
    chains = json_table.get("chains")
    if name is None or not legal_nft_name(name):
        raise SettingsException(message_str=f"Invalid name ({name}) in table")
    if allow_multiple_families:
        for fam in family.split(","):
            if fam is None or fam not in ["ip", "ip6", "inet", "arp", "bridge", "netdev"]:
                raise SettingsException(message_str=f"Invalid family ({fam}) for table {name}")
    elif family is None or family not in ["ip", "ip6", "inet", "arp", "bridge", "netdev"]:
        raise SettingsException(message_str=f"Invalid family ({family}) for table {name}")
    if chains is None:
        raise SettingsException(message_str=f"Invalid chains (null) for table {name}")


def check_log(json_log) -> None:
    """Check the provided log has the required attributes, throw exception if not"""
    if json_log is None:
        raise SettingsException(message_str="Invalid log: null")
    if json_log.get("type") is None:
        raise SettingsException(message_str="Invalid log type: null")
    if json_log.get("type") == "NFLOG" and json_log.get("prefix") is None:
        raise SettingsException(message_str="Invalid log NFLOG prefix: null")
    if json_log.get("type") == "DICT" and json_log.get("field") is None:
        raise SettingsException(message_str="Invalid log DICT field: null")
    if json_log.get("type") == "DICT" and json_log.get("value") is None:
        raise SettingsException(message_str="Invalid log DICT value: null")


def check_action(json_action) -> None:
    """Check the provided action has the required attributes, throw exception if not"""
    if json_action is None:
        raise SettingsException(message_str="Invalid action: null")
    if json_action.get("type") is None:
        raise SettingsException(message_str="Invalid action type: null")


def check_family(family) -> None:
    """Check the provided string is a valid family - throw exception if not"""
    if family is None:
        raise SettingsException(message_str="Invalid family: null")
    if family not in ["ip", "ip6", "inet", "arp", "bridge", "netdev"]:
        raise SettingsException(message_str="Invalid family (" + family + ")")


def legal_nft_name(name):
    """Return true if a legal nft name, Fales otherwise"""
    if name is None:
        return False
    match = re.match("[a-z-]+", name)
    return match is not None


def check_mark(mark) -> bool:
    """Return true if the given string is a hex number"""
    if not mark:
        raise SettingsException(message_str="mark should not be null")

    try:
        mark = int(mark, 16)
    except:
        raise SettingsException(message_str=f"Invalid value for mark: {mark}")

    return True


def get_limit_rate_unit_string(unit):
    """Get the nftable syntax for a rate limit constant"""
    return {
        "PACKETS_PER_SECOND": "/second",
        "PACKETS_PER_MINUTE": "/minute",
        "PACKETS_PER_HOUR": "/hour",
        "PACKETS_PER_DAY": "/day",
        "PACKETS_PER_WEEK": "/week",
        "BYTES_PER_SECOND": " bytes/second",
        "KBYTES_PER_SECOND": " kbytes/second",
        "MBYTES_PER_SECOND": " mbytes/second",
    }.get(unit, "/second")


def get_limit_burst_unit_string(burst_unit):
    """Get the nftable syntax for a rate limit burst constant"""
    return {
        "PACKETS": " packets",
        "BYTES": " bytes",
        "KBYTES": " kbytes",
        "MBYTES": " mbytes",
    }.get(burst_unit, " packets")


def verify_guid(array, idName, relatedChains) -> None:
    """verify_guid verifies that we have converted the rule IDs to GUIDs, and also adds a new guid in case an ID was passed without one
    :param array: (array) array of policies or rules
    :param idName: id field like 'ruleId' or 'policyId'
    :param relatedChains: (array) array of related chains that need an updated id reference
    """
    if array:
        # id map for command center policies used to map pre 3.3 ids to 3.3 and above ids
        cc_policy_id_map = {
            100001: "2cde882b-1ee5-20d6-079f-a70b9d4b2d04",
            100002: "bf20d1da-423a-18e8-77ce-fa9326817b8b",
            100003: "a2da55ea-69be-cecc-0b4d-9406c1969125",
            100004: "5e83c8cc-c141-65ac-a2cd-699ce39f0961",
            100005: "af575439-ffa4-5ede-691d-2538bbeaf264",
            100006: "9d7d8d38-b6c8-c7dc-45a1-1007c2a57bdc",
            100007: "c197b2b4-c33c-49b8-b37d-e5abd416c2bc",
            100006: "5559b5f8-4E3b-f628-bb99-b38483a720ec",
            100009: "606986bb-80e5-4f94-f5ed-703c0b94a9bc",
        }
        isPolicies = idName == "policyId"
        for item in array:
            # If the item is missing an ID or is an int type, gen a new GUID
            if item.get(idName) is None or test_int(item.get(idName)):
                # Check if this property even exists
                if idName not in item:
                    # gen a new ID, this is something new
                    item[idName] = uuid4().__str__()
                else:
                    # store old ID for validating update potential
                    oldId = item[idName]
                    # if item is a policy and item is a command center policy with an old id, use a static guid
                    if isPolicies and cc_policy_id_map.get(oldId) is not None:
                        item[idName] = cc_policy_id_map.get(oldId)
                    else:
                        item[idName] = uuid4().__str__()

                    # if there are related policy chains, AND the old ID was an INT, we also need to fix the policy actions
                    if relatedChains and test_int(oldId):
                        # Get any chains using the old WAN_POLICY ID
                        for chain in relatedChains:
                            for rule in chain.get("rules"):
                                action = rule.get("action")
                                if action:
                                    if (
                                        action.get("policy")
                                        and test_int(action.get("policy"))
                                        and action.get("type") == "WAN_POLICY"
                                        and action.get("policy") == oldId
                                    ):
                                        # Set it to the new item's WAN_POLICY GUID
                                        action["policy"] = item[idName]


def test_int(s) -> Optional[bool]:
    """test_int tests if the passed in value is an int or not
    :param s: (any) any value
    returns true if int, else returns false
    """
    try:
        int(s)
        return True
    except ValueError:
        return False


def clean_rule_actions(parent, array, tableName=None) -> None:
    """clean_rule_actions is used to massage WAN_POLICY and DROP action rule types, as well as INTERFACE_TYPE conditions
    :param parent: (container) the parent container of the array that should hold the idSeqName attribute and value
    :param array: (array) an array of items that require unique ids
    :param (optional) tableName: (string) currently used for passing the tableName in for DROP action types"""
    if array:
        for item in array:
            # If action exists on this item, we need to run some special checks for WAN_POLICY and DROP types :
            action = item.get("action")
            if action:
                if action.get("type") == "WAN_POLICY":
                    item["logs"] = [
                        {
                            "type": "NFLOG",
                            "prefix": "{{'type':'R:wan-routing:{}','ruleId':'{}','action':'WAN_POLICY','policy':'{}'}} ".format(
                                parent.get("name"),
                                format_guid_for_nft(item.get("ruleId")),
                                format_guid_for_nft(action.get("policy")),
                            ),
                        },
                        {
                            "type": "DICT",
                            "field": "wan_rule_id",
                            "field_type": "long_string",
                            "value": format_guid_for_nft(item.get("ruleId")),
                        },
                    ]

                if tableName in ["filter", "access", "dos"]:
                    drop_prefix = {
                        "type": "R:{}:{}".format(tableName, parent.get("name")),
                        "ruleId": format_guid_for_nft(item.get("ruleId")),
                        "action": action.get("type"),
                    }
                    if action.get("type") == "DOS-BLOCK":
                        for log_item in item.get("logs", []):
                            # We can have multiple types of logs in a rule, replace just the nflog type's
                            # prefix part to include correct tablename, chainname, and this rule's ruleID.
                            if log_item.get("type") == "NFLOG":
                                if action.get("type") == "DOS-BLOCK":
                                    # In case of dos-block, add the "dos" key to prefix which denotes-
                                    # (1) protocol for which this dos offense has been made.
                                    # (2) whether this dos offense is for source ip address or destination ip address condition.
                                    drop_prefix["dos"] = log_item.get("prefix")
                                log_item["prefix"] = str(drop_prefix)
                    elif action.get("type") in ["DROP", "REJECT", "ACCEPT"]:
                        item["logs"] = []
                        if item.get("log", False):
                            item["logs"].append({"prefix": str(drop_prefix), "type": "NFLOG"})

            # _INTERFACE_TYPE conditions historically might be "wan", "lan", "unset"
            conditions = item.get("conditions")
            if conditions:
                for condition in conditions:
                    condition_type = condition.get("type")
                    if condition_type == "SOURCE_INTERFACE_TYPE":
                        value = condition.get("value")
                        if value == "unset":
                            condition["value"] = 0
                        elif value == "wan":
                            condition["value"] = 1
                        elif value == "lan":
                            condition["value"] = 2


def fix_port_proto_rules(rules) -> None:
    """
    fix_port_proto_rules is used to cleanup SOURCE_PORT and DESTINATION_PORT rules that are using the "old" method of
    checking for the ip protocol as a separate condition VS the current method of using the port_protocol extra field
    :param rules: (array) array of rules in this chain
    """
    if rules:
        for rule in rules:
            for condition in rule.get("conditions"):
                # We only need to check this on DESTINATION_PORT and SOURCE_PORT conditions, if they do not have port_protocol set
                if (
                    condition.get("type") == "DESTINATION_PORT"
                    or condition.get("type") == "SOURCE_PORT"
                    or (
                        condition.get("type") == "LIMIT_RATE"
                        and condition.get("group_selector") == "DESTINATION_PORT"
                    )
                    or (
                        condition.get("type") == "LIMIT_RATE"
                        and condition.get("group_selector") == "SOURCE_PORT"
                    )
                ) and condition.get("port_protocol") is None:
                    # If we can't find an associated IP_PROTOCOL for this rule, then just assign TCP (this shouldn't be possible)
                    setProto = 6

                    # Search the other conditions on this rule for the first IP_PROTOCOL condition and value
                    for otherCondition in rule.get("conditions"):
                        if otherCondition.get("type") == "IP_PROTOCOL":
                            setProto = otherCondition.get("value")

                    condition["port_protocol"] = setProto


def fix_MFW_1082_rules(tableName, rules) -> None:
    """
    MFW-1082:
    Remove Client/Server conditions from WAN Rules, Port Forward Rules, NAT Rules, and Access Rules
    Remove Source/Destination conditions from Shaping Rules and Filter Rulesfix_chain_rules fixes

    this function will 'fix' the condition in specific tables (According to logic linked in the above ticket)
    and then disable the rule
    """

    # clientServerConditionFixes is a map of old conditions that will be updated with whatever their value is
    # these are used for fixing the wan-routing, port-forward, nat, access tables
    clientServerConditionFixes = {}
    # Client conditions -> Source conditions
    clientServerConditionFixes["CLIENT_ADDRESS"] = "SOURCE_ADDRESS"
    clientServerConditionFixes["CLIENT_ADDRESS_V6"] = "SOURCE_ADDRESS_V6"
    clientServerConditionFixes["CLIENT_PORT"] = "SOURCE_PORT"
    clientServerConditionFixes["CLIENT_INTERFACE_ZONE"] = "SOURCE_INTERFACE_ZONE"
    clientServerConditionFixes["CLIENT_INTERFACE_TYPE"] = "SOURCE_INTERFACE_TYPE"

    # Server conditions -> Destination conditions
    clientServerConditionFixes["SERVER_ADDRESS"] = "DESTINATION_ADDRESS"
    clientServerConditionFixes["SERVER_ADDRESS_V6"] = "DESTINATION_ADDRESS_V6"
    clientServerConditionFixes["SERVER_PORT"] = "DESTINATION_PORT"
    clientServerConditionFixes["SERVER_INTERFACE_ZONE"] = "DESTINATION_INTERFACE_ZONE"
    clientServerConditionFixes["SERVER_INTERFACE_TYPE"] = "DESTINATION_INTERFACE_TYPE"

    srcDstConditionFixes = {}
    # Source conditions -> Client conditions
    srcDstConditionFixes["SOURCE_ADDRESS"] = "CLIENT_ADDRESS"
    srcDstConditionFixes["SOURCE_ADDRESS_V6"] = "CLIENT_ADDRESS_V6"
    srcDstConditionFixes["SOURCE_PORT"] = "CLIENT_PORT"
    srcDstConditionFixes["SOURCE_INTERFACE_ZONE"] = "CLIENT_INTERFACE_ZONE"
    srcDstConditionFixes["SOURCE_INTERFACE_TYPE"] = "CLIENT_INTERFACE_TYPE"

    # Destination conditions -> Server conditions
    srcDstConditionFixes["DESTINATION_ADDRESS"] = "SERVER_ADDRESS"
    srcDstConditionFixes["DESTINATION_ADDRESS_V6"] = "SERVER_ADDRESS_V6"
    srcDstConditionFixes["DESTINATION_PORT"] = "SERVER_PORT"
    srcDstConditionFixes["DESTINATION_INTERFACE_ZONE"] = "SERVER_INTERFACE_ZONE"
    srcDstConditionFixes["DESTINATION_INTERFACE_TYPE"] = "SERVER_INTERFACE_TYPE"

    if tableName in ("wan-routing", "port-forward", "nat", "access"):
        for rule in rules:
            switchCondition(rule, clientServerConditionFixes)

    if tableName in ("shaping", "filter"):
        for rule in rules:
            switchCondition(rule, srcDstConditionFixes)


def switchCondition(rule, conditionMap) -> None:
    """
    switchCondition is used largely by fix_MFW_1082_rules to switch old conditions with new conditions for a rule
    and also disable that condition
    """
    if rule:
        # Store the current enabled/disabled status of the rule
        # if we have to fix a condition, then we want to always disabled the rule after processing
        ruleEnabled = rule.get("enabled")
        if rule.get("conditions"):
            for condition in rule.get("conditions"):
                # Check if this type exists as a key in the condition map
                if condition.get("type") in conditionMap:
                    condition["type"] = conditionMap[condition.get("type")]
                    ruleEnabled = False

        # if these don't match after processing, then a condition change means we need to disable the rule
        if ruleEnabled != rule.get("enabled"):
            rule["enabled"] = ruleEnabled


def format_guid_for_nft(guid):
    """
    returns the first hex of a guid for nft purpose so we don't hit character limits
    :param guid: (string) a string containing a guid like 822f5c96-e04b-4248-aea4-7cbd5d4a8af5
    returns (string) ex: "822f5c96"
    """
    # if guid does not exist, is an empty string, or is an int as it's a deleted policy/rule, return it
    if guid is None or guid == "" or test_int(guid):
        return guid
    return guid[:8]
