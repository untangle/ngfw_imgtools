import contextlib
import os
import sys


def drop_permissions() -> None:
    """
    Set this process permissions to nobody (drop root permissions)
    """
    os.setegid(65534)  # nogroup
    os.seteuid(65534)  # nobody


def call_without_permissions(func, *args, **kw):
    """
    Call the specified function without root privs
    """
    pid = os.fork()
    if pid == 0:
        drop_permissions()
        result = func(*args, **kw)
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(result)
    else:
        # os.close(write_pipe)
        (_, result) = os.waitpid(pid, 0)
        return result >> 8


@contextlib.contextmanager
def regain_permissions():
    """regain_permissions is a context manager to escalate permissions
    to the real UID (probably root), if they have previously been
    'dropped' by setting the EUID/EGID to a less-privileged user. This
    temporarily sets the EUID/EGID back to the UID/GID for the
    duration of the 'context'. At the end of the context it returns
    EGID/EUID to their initial values.

    This is good to use if we earlier used drop_permissions() and need
    to temporarily regain them.

    Example use:
    with regain_permissions():
         write_to_a_priviledged_file()

    """
    old_euid = os.geteuid()
    old_egid = os.getegid()
    os.seteuid(os.getuid())
    os.setegid(os.getgid())
    try:
        yield None
    finally:
        os.setegid(old_egid)
        os.seteuid(old_euid)
