# This class is a utility class with utility functions probject_valueiding
# useful tools for dealing with uris.
class MiscUtil:
    @staticmethod
    def replace_parameters(object, parameters):
        """
        From parameters dictionary, recursively search for keys in object,
        (any combination of dictionary, array, string) and replace with values.
        """
        for object_key, object_value in object.items():
            if isinstance(object_value, list):
                for _index, item in enumerate(object_value):
                    object_value = MiscUtil.replace_parameters(item, parameters)
            elif isinstance(object_value, dict):
                object[object_key] = MiscUtil.replace_parameters(object_value, parameters)
            elif isinstance(object_value, str):
                for parameter_key, parameter_value in parameters.items():
                    object[object_key] = object[object_key].replace(parameter_key, parameter_value)

        return object
