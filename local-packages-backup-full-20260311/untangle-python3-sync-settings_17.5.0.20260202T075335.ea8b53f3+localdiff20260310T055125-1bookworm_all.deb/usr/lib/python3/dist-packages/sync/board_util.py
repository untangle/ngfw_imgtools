"""Board/system utilities."""

import contextlib
import os
import random
import re
import subprocess

from sync.common import Logger

logger = Logger.getInstance()

VITTORIA_PLATFORM_INDICATOR_DIR = "/velocloud"
OPENWRT_PLATFORM_INDICATOR_FILE = "/etc/openwrt_version"


class BoardUtil:
    """provides information about the host board and OS"""

    # Statics, once populated
    board_name: str = None
    EOS_platform: str = None
    OS_name: str = None
    is_openwrt: bool = None
    is_EOS: bool = None

    @classmethod
    def get_eos_platform(cls) -> str:
        """Get the eos platform name."""
        if cls.EOS_platform is None:
            try:
                cmd = "cat /proc/cmdline | xargs -n1 | grep sid |cut -d '=' -f2"
                sid = (
                    subprocess.check_output(
                        cmd,
                        shell=True,
                        stderr=subprocess.DEVNULL,
                    )
                    .decode("ascii")
                    .rstrip()
                )
                if sid in ["Independence"]:
                    cmd = (
                        "cat /etc/prefdl | grep HwApi | awk -F ': ' '{print $2}' | cut -d '.' -f1"
                    )
                    variant = (
                        subprocess.check_output(
                            cmd,
                            shell=True,
                            stderr=subprocess.DEVNULL,
                        )
                        .decode("ascii")
                        .rstrip()
                    )
                    cls.EOS_platform = {"03": "independence_P3", "02": "independence_P2"}.get(
                        variant, "independence_P3"
                    )
                else:
                    cls.EOS_platform = sid.lower()
            except (subprocess.CalledProcessError, UnicodeError) as e:
                cls.EOS_platform = "unknown"
                logger.exception(
                    "Subprocess '%s' failed with %s. EOS platform is %s",
                    str(cmd),
                    str(e.returncode),
                    str(cls.EOS_platform),
                )
            except Exception:
                logger.exception("Unexpected")
                raise

        return cls.EOS_platform

    @classmethod
    def is_platform_os_eos(cls, *, reload_data: bool = False) -> bool:
        """Returns True if the OS is EOS."""
        if cls.is_EOS is None or reload_data is True:
            if os.path.isfile("/etc/Eos-release"):
                cls.is_EOS = True
            else:
                cls.is_EOS = False

        return cls.is_EOS

    @classmethod
    def is_NGFW(cls) -> bool:
        """Returns True if the Call is from NGFW"""
        return bool(os.path.isfile("/etc/debian_version"))

    @classmethod
    def is_WAF(cls) -> bool:
        """Returns True if the Call is from WAF"""
        return bool(os.path.isdir("/usr/share/untangle/waf/"))

    @classmethod
    def is_platform_vittoria(cls) -> bool:
        """Returns True if the Call is from Vittoria"""
        return os.path.exists(VITTORIA_PLATFORM_INDICATOR_DIR)

    @classmethod
    def get_board_name(cls, *, reload_data: bool = False) -> str:
        """Get the board name."""
        if cls.board_name is None or reload_data is True:
            try:
                if cls.is_platform_os_eos(reload_data=reload_data):
                    cls.board_name = cls.get_eos_platform()
                elif cls.is_platform_vittoria():
                    cls.board_name = "vittoria"
                else:
                    # read the product_board_name and if starts with e4/q4/e8/q8 add it to the return value
                    # something like untangle-inc-default-string-e4
                    with open("/tmp/sysinfo/product_board_name") as f1:  # noqa: S108
                        product_board_name = f1.read().rstrip().lower()
                    with open("/tmp/sysinfo/board_name") as f2:  # noqa: S108
                        board_name = f2.read().rstrip()
                    cls.board_name = (
                        board_name + "-" + product_board_name[:2]
                        if product_board_name in ["e4", "e8", "e8W", "q4", "q8", "q8w"]
                        else board_name
                    )
            except (OSError, ValueError, InterruptedError):
                if not (cls.is_NGFW() or cls.is_WAF()):
                    logger.exception("Error in opening the file:")
                cls.board_name = "unknown"
            except Exception:
                logger.exception("Unexpected")
                raise

        return cls.board_name

    @classmethod
    def is_platform_mfw(cls) -> bool:
        return cls.is_running_in_openwrt() and not cls.is_platform_vittoria()

    @classmethod
    def is_running_in_openwrt(cls) -> bool:
        """Return True if OS is openwrt"""
        if cls.is_openwrt is None:
            # FIXME: use Path.is_dir()
            if os.path.isfile(OPENWRT_PLATFORM_INDICATOR_FILE):
                cls.is_openwrt = True
            else:
                cls.is_openwrt = False
        return cls.is_openwrt


def get_hidden_interfaces() -> list:
    """Returns a list of interfaces that should be hidden from the user."""
    board_name = BoardUtil.get_board_name()
    return {
        "armada-385-linksys-shelby": ["eth0", "eth1"],
        "linksys,shelby": ["eth0", "eth1"],
        "armada-385-linksys-rango": ["eth0", "eth1", "wlan2"],
        "linksys,rango": ["eth0", "eth1", "wlan2"],
        "armada-385-linksys-venom": ["eth0", "eth1", "wlan2"],
        "linksys,venom": ["eth0", "eth1", "wlan2"],
        "armada-385-turris-omnia": ["eth0", "eth1"],
        "cznic,turris-omnia": ["eth0", "eth1"],
        "globalscale,espressobin": ["eth0"],
        "globalscale,espressobin-v7-emmc": ["eth0"],
        "caswell-caf-0262": ["wwan1", "wwan2"],
        "untangle-inc-default-string": ["wwan1", "wwan2"],
        "arista-networks-inc-default-string": ["wwan1", "wwan2"],
    }.get(board_name, [])


def get_wan_interfaces() -> list:
    """Get the list of the wan devices."""
    board_name = BoardUtil.get_board_name()
    return {
        "armada-385-linksys-shelby": ["wan"],
        "linksys,shelby": ["wan"],
        "armada-385-linksys-rango": ["wan"],
        "linksys,rango": ["wan"],
        "armada-385-linksys-venom": ["wan"],
        "linksys,venom": ["wan"],
        "armada-385-turris-omnia": ["eth2"],
        "cznic,turris-omnia": ["eth2"],
        "globalscale,espressobin": ["wan", "lan0"],
        "globalscale,espressobin-v7-emmc": ["eth1", "eth2"],
        "caswell-caf-0262": ["eth4", "eth5"],
        "untangle-inc-default-string": ["eth4", "eth5"],
        "arista-networks-inc-default-string": ["eth4", "eth5"],
        "untangle-inc-default-string-e4": ["eth0"],
        "arista-networks-inc-default-string-q4": ["eth0"],
        "untangle-inc-default-string-e8": ["eth0"],
        "arista-networks-inc-default-string-q8": ["eth0"],
        "raspberrypi,3-model-b-plus": ["eth0"],
        "raspberrypi,3-model-b": ["eth0"],
        "veos": [
            "et3",
            "et4",
            "et5",
            "et6",
            "et7",
            "et8",
            "et9",
            "et10",
            "et11",
            "et12",
            "et13",
            "et14",
            "et15",
            "et16",
            "et17",
            "et18",
            "et19",
            "et20",
        ],
        "councilbluffs": ["et1_1"],
        "councilbluffsruby1": ["et1_1"],
        "independence_P2": ["et1_1"],
        "independence_P3": ["et1_1"],
        "independenceruby1": ["et1_1"],
        "independenceruby2": ["et1_1"],
        "willamette": ["et1"],
    }.get(board_name, ["eth1"])


def get_internal_interfaces() -> list:
    """Get the list of the internal devices."""
    board_name = BoardUtil.get_board_name()
    return {
        "armada-385-linksys-shelby": ["lan1", "lan2", "lan3", "lan4"],
        "linksys,shelby": ["lan1", "lan2", "lan3", "lan4"],
        "armada-385-linksys-rango": ["lan1", "lan2", "lan3", "lan4"],
        "linksys,rango": ["lan1", "lan2", "lan3", "lan4"],
        "armada-385-linksys-venom": ["lan1", "lan2", "lan3", "lan4"],
        "linksys,venom": ["lan1", "lan2", "lan3", "lan4"],
        "armada-385-turris-omnia": ["lan0", "lan1", "lan2", "lan3", "lan4"],
        "cznic,turris-omnia": ["lan0", "lan1", "lan2", "lan3", "lan4"],
        "globalscale,espressobin": ["lan1"],
        "globalscale,espressobin-v7-emmc": ["eth3"],
        "caswell-caf-0262": ["eth0", "eth1", "eth2", "eth3"],
        "untangle-inc-default-string": ["eth0", "eth1", "eth2", "eth3"],
        "arista-networks-inc-default-string": ["eth0", "eth1", "eth2", "eth3"],
        "untangle-inc-default-string-e4": ["eth1", "eth2", "eth3"],
        "arista-networks-inc-default-string-q4": ["eth1", "eth2", "eth3"],
        "untangle-inc-default-string-e8": ["eth1", "eth2", "eth3", "eth4", "eth5", "eth6", "eth7"],
        "arista-networks-inc-default-string-q8": [
            "eth1",
            "eth2",
            "eth3",
            "eth4",
            "eth5",
            "eth6",
            "eth7",
        ],
        "raspberrypi,3-model-b-plus": ["wlan0"],
        "raspberrypi,3-model-b": ["wlan0"],
        "veos": [],
        "councilbluffs": [],
        "councilbluffsruby1": [],
        "independence_P2": [],
        "independence_P3": [],
        "independenceruby1": [],
        "independenceruby2": [],
        "willamette": [],
    }.get(board_name, ["eth0"])


def get_management_interface() -> str:
    """Gets the list of management interfaces for a board.

    Returns an empty list of there is none
    """
    board_name: str = BoardUtil.get_board_name()
    return {
        "veos": "ma1",
        "councilbluffs": "ma1_1",
        "councilbluffsruby1": "ma1_1",
        "independence_P2": "ma1_1",
        "independence_P3": "ma1_1",
        "independenceruby1": "ma1_1",
        "independenceruby2": "ma1_1",
        "willamette": "ma1",
    }.get(board_name, "")


interface_name_maps = {
    "globalscale,espressobin-v7-emmc": {
        "eth1": "WAN0",
        "eth2": "WAN1",
        "eth3": "LAN",
        "wlan0": "WiFi",
    },
    "caswell-caf-0262": {
        "eth0": "LAN1",
        "eth1": "LAN2",
        "eth2": "LAN3",
        "eth3": "LAN4",
        "eth4": "WAN0",
        "eth5": "WAN1",
        "wlan0": "WiFi",
        "wwan0": "LTE",
    },
    "untangle-inc-default-string": {
        "eth0": "LAN1",
        "eth1": "LAN2",
        "eth2": "LAN3",
        "eth3": "LAN4",
        "eth4": "WAN0",
        "eth5": "WAN1",
        "wlan0": "WiFi",
        "wwan0": "LTE",
    },
    "arista-networks-inc-default-string": {
        "eth0": "LAN1",
        "eth1": "LAN2",
        "eth2": "LAN3",
        "eth3": "LAN4",
        "eth4": "WAN0",
        "eth5": "WAN1",
        "wlan0": "WiFi",
        "wwan0": "LTE",
    },
    "untangle-inc-default-string-e4": {
        "eth0": "WAN1",
        "eth1": "LAN1",
        "eth2": "LAN2",
        "eth3": "LAN3",
    },
    "arista-networks-inc-default-string-q4": {
        "eth0": "WAN1",
        "eth1": "LAN1",
        "eth2": "LAN2",
        "eth3": "LAN3",
    },
    "untangle-inc-default-string-e8": {
        "eth0": "WAN1",
        "eth1": "LAN1",
        "eth2": "LAN2",
        "eth3": "LAN3",
        "eth4": "LAN4",
        "eth5": "LAN5",
        "eth6": "LAN6",
        "eth7": "LAN7",
        "wlan0": "WiFi",
        "wlan1": "WiFi",
    },
    "arista-networks-inc-default-string-q8": {
        "eth0": "WAN1",
        "eth1": "LAN1",
        "eth2": "LAN2",
        "eth3": "LAN3",
        "eth4": "LAN4",
        "eth5": "LAN5",
        "eth6": "LAN6",
        "eth7": "LAN7",
        "wlan0": "WiFi",
        "wlan1": "WiFi",
    },
    "linksys,shelby": {
        "lan1": "LAN1",
        "lan2": "LAN2",
        "lan3": "LAN3",
        "lan4": "LAN4",
        "wan": "WAN",
        "wlan0": "WiFiOne",
        "wlan1": "WiFiTwo",
    },
    "linksys,rango": {
        "lan1": "LAN1",
        "lan2": "LAN2",
        "lan3": "LAN3",
        "lan4": "LAN4",
        "wan": "WAN",
        "wlan0": "WiFiOne",
        "wlan1": "WiFiTwo",
    },
    "linksys,venom": {
        "lan1": "LAN1",
        "lan2": "LAN2",
        "lan3": "LAN3",
        "lan4": "LAN4",
        "wan": "WAN",
        "wlan0": "WiFiOne",
        "wlan1": "WiFiTwo",
    },
    "veos": {
        "ma1": "MGMT1",
        "et1": "LAN1",
        "et2": "LAN2",
        "et3": "WAN0",
        "et4": "WAN1",
        "et5": "WAN2",
        "et6": "WAN3",
        "et7": "WAN4",
        "et8": "WAN5",
        "et9": "WAN6",
        "et10": "WAN7",
        "et11": "WAN8",
        "et12": "WAN9",
        "et13": "WAN10",
        "et14": "WAN11",
        "et15": "WAN12",
        "et16": "WAN13",
        "et17": "WAN14",
        "et18": "WAN15",
        "et19": "WAN16",
        "et20": "WAN17",
    },
    "councilbluffs": {
        "ma1_1": "MGMT1",
        "et1_1": "LAN1",
        "et1_2": "WAN0",
        "et1_3": "WAN1",
        "et1_4": "LAN2",
        "et1_5": "LAN3",
        "et1_6": "LAN4",
        "et1_7": "LAN5",
        "et1_8": "LAN6",
    },
    "councilbluffsruby1": {
        "ma1_1": "MGMT1",
        "et1_1": "LAN1",
        "et1_2": "WAN0",
        "et1_3": "WAN1",
        "et1_4": "LAN2",
        "et1_5": "LAN3",
        "et1_6": "LAN4",
        "et1_7": "LAN5",
        "et1_8": "LAN6",
    },
    "independence_P2": {
        "ma1_1": "MGMT1",
        "et1_9": "WAN0",
        "et1_10": "WAN1",
        "et1_11": "LAN1",
        "et1_12": "LAN2",
        "et1_13": "LAN3",
        "et1_14": "LAN4",
        "et1_15": "LAN5",
        "et1_16": "LAN6",
    },
    "independence_P3": {
        "ma1_1": "MGMT1",
        "et1_1": "WAN0",
        "et1_2": "WAN1",
        "et1_3": "LAN1",
        "et1_4": "LAN2",
        "et1_5": "LAN3",
        "et1_6": "LAN4",
        "et1_7": "LAN5",
        "et1_8": "LAN6",
        "et1_9": "WAN2",
        "et1_10": "WAN3",
        "et1_11": "LAN7",
        "et1_12": "LAN8",
        "et1_13": "LAN9",
        "et1_14": "LAN10",
        "et1_15": "LAN11",
        "et1_16": "LAN12",
    },
    "independenceruby1": {
        "ma1_1": "MGMT1",
        "et1_1": "WAN0",
        "et1_2": "WAN1",
        "et1_3": "LAN1",
        "et1_4": "LAN2",
        "et1_5": "LAN3",
        "et1_6": "LAN4",
        "et1_7": "LAN5",
        "et1_8": "LAN6",
        "et1_9": "WAN2",
        "et1_10": "WAN3",
        "et1_11": "LAN7",
        "et1_12": "LAN8",
        "et1_13": "LAN9",
        "et1_14": "LAN10",
        "et1_15": "LAN11",
        "et1_16": "LAN12",
    },
    "independenceruby2": {
        "ma1_1": "MGMT1",
        "et1_1": "WAN0",
        "et1_2": "WAN1",
        "et1_3": "LAN1",
        "et1_4": "LAN2",
        "et1_5": "LAN3",
        "et1_6": "LAN4",
        "et1_7": "LAN5",
        "et1_8": "LAN6",
        "et1_9": "WAN2",
        "et1_10": "WAN3",
        "et1_11": "LAN7",
        "et1_12": "LAN8",
        "et1_13": "LAN9",
        "et1_14": "LAN10",
        "et1_15": "LAN11",
        "et1_16": "LAN12",
    },
    "willamette": {
        "ma1": "MGMT1",
        "et1": "WAN0",
        "et2": "WAN1",
        "et3": "LAN1",
        "et4": "LAN2",
        "et5": "LAN3",
        "et6": "LAN4",
        "et7": "LAN5",
    },
}


def get_interface_name(device):
    """Get the device specific interface name."""
    board_name = BoardUtil.get_board_name()
    return interface_name_maps.get(board_name, {}).get(device, "")


def get_management_interface_broadcast_address() -> str:
    """Retrieves the broadcast address of a management interface If a
    management broadcast address can't be found, default to 255.255.255.255."""
    default_management_broadcast = "255.255.255.255"

    ma: str = get_management_interface()
    if not ma:
        return default_management_broadcast

    try:
        cmd: str = rf"ip addr show {ma} | sed -nE 's/.*inet .* brd ([0-9.]+).*/\1/p'"
        return (
            subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL)
            .decode("ascii")
            .strip()
        )
    except (subprocess.CalledProcessError, UnicodeError) as e:
        logger.exception("Subprocess '%s' failed with %s", str(cmd), str(e.returncode))
        return default_management_broadcast
    except Exception:
        logger.exception("Unexpected")
        raise


interface_broadcast_address_maps: dict[str, str] = {
    "veos": {"ma1": get_management_interface_broadcast_address()},
    "councilbluffs": {"ma1_1": get_management_interface_broadcast_address()},
    "councilbluffsruby1": {"ma1_1": get_management_interface_broadcast_address()},
    "independence_P2": {"ma1_1": get_management_interface_broadcast_address()},
    "independence_P3": {"ma1_1": get_management_interface_broadcast_address()},
    "independenceruby1": {"ma1_1": get_management_interface_broadcast_address()},
    "independenceruby2": {"ma1_1": get_management_interface_broadcast_address()},
    "willamette": {"ma1": get_management_interface_broadcast_address()},
}


def get_interface_broadcast_address(device) -> str:
    """Get the broadcast address from an interface name."""
    board_name: str = BoardUtil.get_board_name()
    return interface_broadcast_address_maps.get(board_name, {}).get(device, "")


def get_country_code():
    """Get the country code."""
    board_name = BoardUtil.get_board_name()
    if board_name in ["armada-385-linksys-shelby", "linksys,shelby"]:
        sku = None
        with contextlib.suppress(Exception):
            sku = (
                subprocess.check_output(
                    "cat /tmp/syscfg/syscfg/syscfg.dat | sed -ne 's/^device::cert_region=//p'",
                    shell=True,
                    stderr=subprocess.DEVNULL,
                )
                .decode("ascii")
                .rstrip()
            )
        return {
            "AP": "CN",
            "AU": "AU",
            "EU": "DE",
            "US": "US",
        }.get(sku, "")

    return ""


def get_device_macaddr(ifname):
    """Get the device mac address for the given ifname."""
    try:
        cmd = f"cat /sys/class/net/{ifname}/address"
        return (
            subprocess.check_output(
                cmd,
                shell=True,
                stderr=subprocess.DEVNULL,
            )
            .decode("ascii")
            .rstrip()
        )
    except (subprocess.CalledProcessError, UnicodeError) as e:
        logger.exception("Subprocess '%s' failed with %s", str(cmd), str(e.returncode))
        return None
    except Exception:
        logger.exception("Unexpected")
        raise


def increment_mac(mac, inc):
    """Increment the specified MAC address."""
    eth_mac = mac.split(":")
    nic = int("".join([eth_mac[3], eth_mac[4], eth_mac[5]]), 16)
    nic += inc
    new_nic = f"{nic:06x}"
    return ":".join([eth_mac[0], eth_mac[1], eth_mac[2], new_nic[0:2], new_nic[2:4], new_nic[4:6]])


def is_valid_mac(mac):
    # Regular expression for validating a MAC address
    if mac:
        mac_regex = re.compile(r"^([0-9A-Fa-f]{2}:){5}([0-9A-Fa-f]{2})$")
        return bool(mac_regex.match(mac))
    return False


def randomize_mac(mac, octet):
    """Randomize MAC address in a given octet."""
    eth_mac = mac.split(":")
    eth_mac[octet] = f"{random.randint(0, 255):02x}"
    return ":".join(eth_mac)


def get_interface_macaddr(ifname, base_mac_addr=None):
    """Get the interface's mac address."""
    board_name = BoardUtil.get_board_name()
    if board_name in ["armada-385-linksys-shelby", "linksys,shelby"]:
        return {
            "wlan0": increment_mac(get_device_macaddr("eth0"), 1),
            "wlan1": increment_mac(get_device_macaddr("eth0"), 2),
            "lan1": get_device_macaddr("eth1"),
            "lan2": get_device_macaddr("eth1"),
            "lan3": get_device_macaddr("eth1"),
            "lan4": get_device_macaddr("eth1"),
            "wan": get_device_macaddr("eth1"),
        }.get(ifname, "")
    if board_name in [
        "armada-385-linksys-rango",
        "armada-385-linksys-venom",
        "linksys,rango",
        "linksys,venom",
    ]:
        return {
            "lan1": get_device_macaddr("eth1"),
            "lan2": get_device_macaddr("eth1"),
            "lan3": get_device_macaddr("eth1"),
            "lan4": get_device_macaddr("eth1"),
            "wan": get_device_macaddr("eth1"),
        }.get(ifname, "")
    if board_name in ["globalscale,espressobin", "globalscale,espressobin-v7-emmc"]:
        return {
            "eth1": randomize_mac(get_device_macaddr("eth0"), 4),
            "eth2": randomize_mac(get_device_macaddr("eth0"), 4),
            "eth3": randomize_mac(get_device_macaddr("eth0"), 4),
        }.get(ifname, "")
    if base_mac_addr:
        # For EOS hybrid mode, initialize the interface MACs with their burninAddr
        if board_name in ["independence_P2"]:
            return {
                "et1_9": base_mac_addr,
                "et1_10": increment_mac(base_mac_addr, 1),
                "et1_11": increment_mac(base_mac_addr, 2),
                "et1_12": increment_mac(base_mac_addr, 3),
                "et1_13": increment_mac(base_mac_addr, 4),
                "et1_14": increment_mac(base_mac_addr, 5),
                "et1_15": increment_mac(base_mac_addr, 6),
                "et1_16": increment_mac(base_mac_addr, 7),
            }.get(ifname, "")

        if board_name in ["independence_P3", "independenceruby1", "independenceruby2"]:
            return {
                "et1_1": base_mac_addr,
                "et1_2": increment_mac(base_mac_addr, 1),
                "et1_3": increment_mac(base_mac_addr, 2),
                "et1_4": increment_mac(base_mac_addr, 3),
                "et1_5": increment_mac(base_mac_addr, 4),
                "et1_6": increment_mac(base_mac_addr, 5),
                "et1_7": increment_mac(base_mac_addr, 6),
                "et1_8": increment_mac(base_mac_addr, 7),
                "et1_9": increment_mac(base_mac_addr, 8),
                "et1_10": increment_mac(base_mac_addr, 9),
                "et1_11": increment_mac(base_mac_addr, 10),
                "et1_12": increment_mac(base_mac_addr, 11),
                "et1_13": increment_mac(base_mac_addr, 12),
                "et1_14": increment_mac(base_mac_addr, 13),
                "et1_15": increment_mac(base_mac_addr, 14),
                "et1_16": increment_mac(base_mac_addr, 15),
            }.get(ifname, "")

        if board_name in ["councilbluffs", "councilbluffsruby1"]:
            return {
                "et1_1": base_mac_addr,
                "et1_2": increment_mac(base_mac_addr, 1),
                "et1_3": increment_mac(base_mac_addr, 2),
                "et1_4": increment_mac(base_mac_addr, 3),
                "et1_5": increment_mac(base_mac_addr, 4),
                "et1_6": increment_mac(base_mac_addr, 5),
                "et1_7": increment_mac(base_mac_addr, 6),
                "et1_8": increment_mac(base_mac_addr, 7),
            }.get(ifname, "")

        if board_name in ["willamette"]:
            return {
                "et1": base_mac_addr,
                "et2": increment_mac(base_mac_addr, 1),
                "et3": increment_mac(base_mac_addr, 2),
                "et4": increment_mac(base_mac_addr, 3),
                "et5": increment_mac(base_mac_addr, 4),
                "et6": increment_mac(base_mac_addr, 5),
                "et7": increment_mac(base_mac_addr, 6),
            }.get(ifname, "")

    return ""


def get_switch_settings():
    """Get the switch settings."""
    # currently unused as we moved switch config to kernel
    board_name = BoardUtil.get_board_name()
    return {}.get(board_name, [])


def is_docker() -> bool:
    """Returns true if the system is a docker container."""
    try:
        grep_output = subprocess.check_output(["/bin/grep", "docker", "/proc/1/cgroup"])
        if "docker" in grep_output.decode():
            return True
    except subprocess.CalledProcessError:
        pass
    return False
