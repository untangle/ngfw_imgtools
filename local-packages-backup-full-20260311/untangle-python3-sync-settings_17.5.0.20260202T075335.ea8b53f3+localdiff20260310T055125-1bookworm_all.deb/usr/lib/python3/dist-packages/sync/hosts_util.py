"""hosts_util provides hosts utility functions"""

import os
import stat

from sync.common import Logger

logger = Logger.getInstance()


class HostsUtil:
    def write_hostname_file(file, settings, prefix) -> None:
        """saves the hostname to /etc/hostname"""
        fqdn_hostname = settings["hostName"]
        if "domainName" in settings:
            fqdn_hostname = fqdn_hostname + "." + settings["domainName"]
        filename = prefix + file
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write(f"{fqdn_hostname}\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_pre_network_hook_file(file, settings, prefix) -> None:
        """writes into the pre-network hook filename"""
        fqdn_hostname = settings["hostName"]
        if "domainName" in settings:
            fqdn_hostname = fqdn_hostname + "." + settings["domainName"]
        filename = prefix + file
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write("/bin/hostname -F /etc/hostname")
        file.write("\n\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))
