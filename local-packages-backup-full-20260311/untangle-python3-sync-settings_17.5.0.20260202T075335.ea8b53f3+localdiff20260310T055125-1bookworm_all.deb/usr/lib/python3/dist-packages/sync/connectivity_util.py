"""connectivity_util provides utility functions to check cloud connectivity"""

import os
import shutil
import subprocess
import time

from sync.file_util import FileUtil

ROLLBACK_SETTINGS_DIR = "/etc/config/rollback/"
DNS_CHECK_RETRY_WAIT = 2
CONNECTIVITY_CHECK_RETRY_WAIT = 2
DNS_TIMEOUT = 1
CONNECTIVITY_TIMEOUT = 3
DNS_RETRY_COUNT = 5
RETRY_COUNT = 2
HOSTNAME = "cmd.edge.arista.com"


def check_cmd_connectivity():
    """check connectivity with CMD"""

    total_elapsed_time = 0

    time_start = time.time()
    # DNS lookup a quick "fail out" test; if it fails there's no point in attempting to connect to the host.
    dns_success = True
    for _ in range(DNS_RETRY_COUNT):
        try:
            ret = subprocess.Popen(
                f"timeout -s SIGKILL {DNS_TIMEOUT}s dig {HOSTNAME} 2>&1 > /dev/null",
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                shell=True,
            ).wait()
            dns_success = ret == 0
            if dns_success:
                break
        except Exception:
            pass
        time.sleep(DNS_CHECK_RETRY_WAIT)

    total_elapsed_time += time.time() - time_start

    if dns_success is False:
        return (
            False,
            f"Connectivity check dns lookup failed after {DNS_RETRY_COUNT} retries ({round(total_elapsed_time)}s)",
        )

    time_start = time.time()
    # Determine connectivity by trying a connection to cmd.edge.arista.com
    for _ in range(RETRY_COUNT):
        try:
            # run nc command and check for exit status
            ret = subprocess.Popen(
                f"timeout -s SIGKILL {CONNECTIVITY_TIMEOUT}s nc {HOSTNAME} 443 < /dev/null",
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                shell=True,
            ).wait()
            if ret == 0:
                return True, "Connectivity successful"
        except Exception:
            pass
        time.sleep(CONNECTIVITY_CHECK_RETRY_WAIT)

    total_elapsed_time += time.time() - time_start

    return (
        False,
        f"Connectivity check failed after {RETRY_COUNT} retries ({round(total_elapsed_time)}s)",
    )


def save_rollback_settings(
    settings_filename, rollback_settings_dir=FileUtil.locate_file(ROLLBACK_SETTINGS_DIR)
):
    """check if connectivity is successful and store current settings
    in rollback location"""
    status, message = check_cmd_connectivity()
    if status:
        if not os.path.exists(rollback_settings_dir):
            os.makedirs(rollback_settings_dir)
        shutil.copy(settings_filename, rollback_settings_dir + "settings.json")
    return status, message


def restore_rollback_settings(
    settings_filename, rollback_settings_dir=FileUtil.locate_file(ROLLBACK_SETTINGS_DIR)
):
    """check if connectivity fails and restore rollback settings"""
    if not os.path.isdir(rollback_settings_dir):
        # No point in attempting to check and rollback if we don't have a rollback directory
        return False, f"no rollback directory {rollback_settings_dir}"

    status, message = check_cmd_connectivity()

    if not status:
        shutil.copy(rollback_settings_dir + "settings.json", settings_filename)
        return True, message
    return False, message
