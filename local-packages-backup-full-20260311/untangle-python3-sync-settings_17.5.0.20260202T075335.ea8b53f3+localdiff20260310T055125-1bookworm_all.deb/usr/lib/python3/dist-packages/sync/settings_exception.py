import json
from typing import Optional


class SettingsException(Exception):
    """
    Formated Exception raised related to sync settings.
    """

    def __init__(
        self,
        message: str = "",
        message_str: Optional[str] = None,
        error_type: Optional[str] = None,
        vars: Optional[list] = None,
        debug: Optional[dict] = None,
    ) -> None:
        """
        Initialize the SettingsException with specific attributes.
        """
        self.message = message if message else message_str
        self.error_type = error_type
        self.vars = vars
        self.debug = debug

    def __str__(self) -> Optional[str]:
        """
        If error_type is "confirm", returns self.message directly.
        Otherwise, returns a JSON-encoded dictionary representation of the exception attributes.
        """
        if self.error_type == "confirm":
            return self.message
        return json.dumps(self.to_dict())

    def to_dict(self):
        error_dict = {
            "error": self.message if self.message else "",
            "vars": self.vars if self.vars else [],
            "error_type": self.error_type,
            "debug": self.debug if self.debug else {},
        }

        return {k: v for k, v in error_dict.items() if v is not None and v not in ({}, [])}
