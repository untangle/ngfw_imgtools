from __future__ import annotations

import os
import re

from sync.common import Logger

logger = Logger.getInstance()

# Environment variable that stores tmpdir of sync-settings.
# Useful for pre_commands handlers to access the temporary config files.
TOPDIR_VAR = "SYNC_SETTINGS_TOPDIR"

# Operation defines operations to runs before and after syncing settings
# Each operation has these properties
# name - the primary key - must be unique
# pre_command - the command to run before sync (may be None)
# post_command - the command to run after sync (may be None)
# priority - an integer, lowest operations run first, defines the order to avoid any inconsistency
# parent - the name of the parent (if any) that is in INCLUSIVE of this operation. If the parent is required then this operation can be skipped
operations = {}

# files stores a mapping of all files to be changed
# Each file has the follow properties
# filepath - the file
# operation - the name of the operation that must be before/after changing this file
# owner - the manager responsible for writing this file
files = {}

# managers store a list of all the "manager" modules
# managers are responsible for serializing the settings to disk
managers = []

# A list of settings_files and the managers that want to operate on them.
settings_files = []

# The main settings file
main_settings_file = None


def get_main_settings() -> str | None:
    return main_settings_file


def add_main_settings(settings: str) -> None:
    global main_settings_file
    main_settings_file = settings


def register_manager(manager) -> None:
    global managers
    managers.append(manager)


def register_operation(name, pre_commands, post_commands, priority, parent=None) -> None:
    """
    Register available operations that can be associated with processing files.
    """
    global operations
    operations[name] = {
        "name": name,
        "pre_commands": pre_commands,
        "post_commands": post_commands,
        "priority": priority,
        "parent": parent,
    }


def get_operation(name):
    """
    Return operation values
    """
    global operations
    if name in operations:
        return (
            operations[name]["pre_commands"],
            operations[name]["post_commands"],
            operations[name]["priority"],
            operations[name]["parent"],
        )

    return None


def get_manager(name):
    """
    Return instantiated manager by class name
    """
    global managers
    for manager in managers:
        if manager.__class__.__name__ == name:
            return manager

    return None


def get_managers():
    """
    Return all instantiated managers
    """
    global managers
    return managers


def register_file(filepath, operation, owner) -> None:
    """
    Register a file (full path) with an operation to act upon.
    """
    global files, operations
    if operation is not None:
        op = operations[operation]
        if op is None:
            raise ValueError("Unknown operation: " + operation)

    files[filepath] = {"filepath": filepath, "operation": operation, "owner": owner}


def unregister_file(filepath) -> None:
    """
    Unregister a file (full path) from the registrar
    """
    global files
    files.pop(filepath, None)


def register_settings_file(id, manager) -> None:
    """
    Register a manager with a settings file identifer.
    If id=*, manager will see all settings files.
    """
    settings_files.append({"id": id, "manager": manager})


def operation_subset_of(parent, child):
    """
    Returns true if the child operation is a child or x-grandchild of parent
    In other words, the child operation is a subset of the parent operation
    Otherwise returns False
    """
    if child == parent:
        return False
    child_op = operations.get(child)
    parent_op = operations.get(parent)
    if child_op is None or parent_op is None:
        return False
    if child_op.get("parent") == parent:
        return True
    if child_op.get("parent") is not None:
        return operation_subset_of(parent, child_op.get("parent"))
    return False


def calculate_required_operations(changed_files):
    """
    Calculates the required operations that need to be completed
    if the specified files have changed
    """
    global files
    operations = []
    for filename in changed_files:
        f = find_file_registration(filename)
        if f is None:
            raise ValueError("Missing file from registrar: " + filename)
        op = f.get("operation")
        if op is not None and op not in operations:
            operations.append(op)

    # Sort in ascending order based on operation priority.
    operations.sort(key=lambda x: get_operation(x)[2])

    return operations


def find_file_registration(filename):
    """
    Find the file registration object for the given filename
    """
    global files
    f = files.get(filename)
    if f is not None:
        return f
    for regex in files:
        if re.compile(regex).match(filename):
            return files.get(regex)
    return None


def registrar_check_file(filename) -> bool:
    """
    Checks that the specified filename is present in the registrar
    Exits with exit code 1 if filename is not found
    """
    global files
    for regex in files:
        if filename == regex:
            return True
    return any(re.compile(regex).match(filename) for regex in files)


def reduce_operations(ops):
    """
    This attempts to reduce the number of required operations is some semi-intelligent fashion
    """
    global operations
    if ops is None:
        return None
    if len(ops) == 0:
        return ops
    # Check operations
    for op1 in ops:
        o = operations.get(op1)
        if o is None:
            raise ValueError("Missing op for registrar: " + op1)
    # First remove any operations that are already included
    orig_ops = list(ops)
    for op1 in orig_ops:
        for op2 in orig_ops:
            if operation_subset_of(op1, op2):
                ops.remove(op2)

    # See if including any of the immediate parents of the operations reduces the length
    # If so, its probably worth it to do include the parent
    orig_ops = list(ops)
    for op1 in orig_ops:
        o1 = operations.get(op1)
        if o1.get("parent") is not None:
            new_ops = [*ops, o1.get("parent")]
            new_ops = reduce_operations(new_ops)
            if len(new_ops) < len(orig_ops):
                return reduce_operations(new_ops)

    return ops


def check_registrar_files(tmpdir) -> int:
    """
    This checks that all files written in tmpdir are properly registered
    in the registrar. Returns 1 if error, 0 otherwise
    """
    for root, _dirs, files in os.walk(tmpdir):
        for filename in files:
            rootpath = os.path.join(root, filename).replace(tmpdir, "")
            result = registrar_check_file(rootpath)
            if not result:
                logger.warning("Unregistered file: %s", str(rootpath))
                return 1
    return 0


def check_registrar_operations(ops) -> int:
    """
    Check that all operations in the ops list is in the registrar
    Returns 1 if an operation is missing in the registrar
    0 otherwise
    """
    if ops is None:
        return 0
    if len(ops) > 0:
        logger.info("Required operations: ")
    for op in ops:
        logger.info("Operation: %s", str(op))
        o = operations.get(op)
        if o is None:
            return 1
    return 0


def check_registrar_settings_file(id, manager) -> bool:
    """
    Determine if the specified manager is interested in this settings file identifier.
    """
    for settings_file in settings_files:
        if settings_file["manager"] == manager:
            if settings_file["id"] == id or settings_file["id"] == "*":
                return True

    return False
