"""settings management"""

import collections
import json
import os
import os.path
import re
import traceback

from sync.common import Logger

logger = Logger.getInstance()


class SettingsFile:
    """
    This class manages settings files.
    """

    os_name = None

    @classmethod
    def set_os_name(cls, os_name=None) -> None:
        """
        Specifies os name for determining identifier.
        """
        cls.os_name = os_name

    def __init__(self, file_name) -> None:
        """
        Initialize
        """
        self._file_name = file_name
        self._settings = {}
        self._id = get_id(self._file_name)

    @property
    def file_name(self):
        """
        Settings file name.
        """
        return self._file_name

    @property
    def id(self):
        """
        Settings identifier
        """
        return self._id

    @property
    def settings(self):
        """
        Returns the current settings
        """
        return self._settings

    @settings.setter
    def settings(self, settings) -> None:
        """
        Set the settings of the file.
        """
        self._settings = settings

    def update_settings(self) -> None:
        """
        Updates the settings dict with
        the latest from the settings file
        """
        self._settings = get_settings_from_file(self._file_name)

    def save_settings(self, prefix_path=None) -> None:
        """
        Save the specified settings to the settings file

        Arguments:
        prefix_path Optional prefix for the file_name.
        """
        save_file_name = self.file_name
        if prefix_path is not None:
            save_file_name = f"{prefix_path}{save_file_name}"

        # Create target path
        target_path = os.path.dirname(save_file_name)
        if target_path and not os.path.exists(target_path):
            os.makedirs(target_path)

        try:
            # settings_file = open(self.file_name, 'w')
            settings_file = open(save_file_name, "w")
            json.dump(self.settings, settings_file, indent=4, separators=(",", ": "))
            settings_file.flush()
            settings_file.close()
        except OSError:
            logger.exception("Unable to save settings file.")
            traceback.print_exc()
            # cleanup(1)

    def is_setting_match(self, setting, compare):
        """
        If current setting matches compare, return True, otherwise False.

        NOTE: For compare as an object, a match is considered whatever matches fields defined in the compare.
        For example, a search of { description: "what I want" } will match that object even if the settings
        target contains more fields that aren't in the compare like { description: "what I want", some_boolean: True }

        setting     --- Current setting value.
        compare     --- Compare to match.
        """
        match = False

        setting_type = type(setting)
        compare_type = type(compare)
        if setting_type is collections.OrderedDict and compare_type is collections.OrderedDict:
            # Dictionary match.
            for compare_key in compare:
                if compare_key not in setting:
                    # Compare key not in setting object.
                    return False

                compare_value = compare[compare_key]
                compare_value_type = type(compare_value)
                setting_value = setting[compare_key]
                setting_value_type = type(setting_value)
                if compare_value_type != setting_value_type:
                    # Values are not same type.
                    if type(setting_value) is list:
                        # Special case: If setting is a list and we're not, see
                        # if our compare is inside it.
                        # This is to fix the case of port_protocol which is usually
                        # written as a string from us, but made into a list from the UI.
                        if str(compare_value) in list(map(str, setting_value)):
                            return True
                    return False

                if compare_value_type is collections.OrderedDict:
                    # Walk dictionary.
                    if self.is_setting_match(setting_value, compare_value) is False:
                        return False

                    # Dictionary match
                    match = True
                elif compare_value_type is list:
                    # Walk list
                    if len(compare_value) != len(setting_value):
                        # List not same length
                        return False

                    if self.is_setting_match(setting_value, compare_value) is False:
                        # No match.
                        return False

                    # List match
                    match = True
                elif compare_value_type is str:
                    # Try regex first
                    match = re.match(compare_value, setting_value)
                    if match is None:
                        if compare_value in setting_value:
                            # Try substring match.
                            match = True
                        else:
                            return False
                elif compare_value == setting_value:
                    # Any other match.
                    match = True
                else:
                    return False
        elif setting_type is list and compare_type is list:
            # Walk compare list and compare with corresponding setting index.
            for index, compare_item in enumerate(compare):
                if self.is_setting_match(setting[index], compare_item) is False:
                    # No match to this element.
                    return False

                # List elements match.
                match = True

        return match

    def get_settings_by_path(self, path=None, current_settings=None):
        """
        Recursively look for settings and return the target value.

        If not found, None is returned.

        Keyword arguments:
        path             -- path to search for (default None)
                            Example: firewall/tables/access/chains/name:access-rules/rules
        current_settings -- Current settings node (default None)
        """
        if current_settings is None:
            # Start with root of settings.
            current_settings = self.settings

        # Process search path
        if type(path) == list:
            paths = path
        else:
            # Break into array.
            paths = path.split("/")

        if len(paths) > 0:
            # Walk current settings via path.
            path_find = paths[0]
            paths = paths[1:]

            if type(current_settings) is collections.OrderedDict:
                if path_find in current_settings:
                    return self.get_settings_by_path(paths, current_settings.get(path_find))
                return None
            if type(current_settings) is list:
                for setting in current_settings:
                    if type(setting) is collections.OrderedDict:
                        path_compare = collections.OrderedDict()
                        for path in path_find.split(","):
                            path_set = path.split("=")
                            path_compare[path_set[0]] = path_set[1]

                        if self.is_setting_match(setting, path_compare):
                            return self.get_settings_by_path(paths, setting)
                return None

        # Reached the end of path.  Return the path settings.
        return current_settings

    def find_settings_list(self, path=None, compare=None):
        """
        From a path, search a list for matching dict settings and return matches.

        NOTE: For compare as an object, a match is considered whatever matches fields defined in the compare.
        For example, a search of { description: "what I want" } will match that object even if the settings
        target contains more fields that aren't in the compare like { description: "what I want", some_boolean: True }

        Keyword arguments:
        path             -- String path to search for (default None)
                            Example: firewall/tables/access/chains/name:access-rules/rules
                            If not a string, assume to be a collectons.OrderedDict of the current settings node.
        compare          -- Dict object to match. (defailt None)
                            Example: { "action": { "type": "ACCEPT" } }
        current_settings -- Current settings node (default None)
        """
        result = []
        if compare is None:
            return result

        if compare is not None and type(compare) == dict:
            ## Convert to OrderedDict for 1:1 type comparisions to settings
            compare = json.loads(json.dumps(compare), object_pairs_hook=collections.OrderedDict)

        current_settings = self.get_settings_by_path(path) if type(path) == str else path

        # Look for matching compares from this settings node.
        if type(current_settings) == list:
            for setting in current_settings:
                if self.is_setting_match(setting, compare):
                    result.append(setting)

        return result

    def merge(self, source_settings=None, destination_settings=None) -> None:
        """
        Recursively merge from template into current settings.

        This currently walks down the path looking for a target
        list of dictionaries to update.  It uses the first dictionary
        key/value pair as a key these objects and on a match, replaces
        the entire object.

        The index index between the source and destination settings list does not need to match.

        NOTE: You almost certainly don't want to use this to update item with unique
        keys like ruleIds.

        The source_settings should start at the root path.

        For example, to update uriTranslations, the contents should be:
        {
            "uris":{
                "uriTranslations":[{
                    "uri": "https://boxbackup.edge.arista.com/boxbackup/backup.php"
                }]
            }
        }

        Keyword arguments:
        source_settings        collections.OrderedDict to merge into the current settings.
        destination_settings    Current location in settings.  Under normal cicumstances, this is None and managed by this method.
        """
        if source_settings is None:
            return

        if type(source_settings) != collections.OrderedDict:
            return

        if destination_settings is None:
            destination_settings = self.settings

        for key in source_settings:
            if key in destination_settings:
                # Walk dictionary path
                self.merge(source_settings[key], destination_settings[key])

            if type(source_settings[key]) == type(source_settings[key]):
                # Same type
                if type(source_settings[key]) == list:
                    # Both are lists
                    for new_index, source_setting in enumerate(source_settings[key]):
                        # Walk source list
                        new_match = False
                        for destination_index, destination_setting in enumerate(
                            destination_settings[key]
                        ):
                            # Walk destination list
                            if type(destination_setting) == dict:
                                destination_setting = collections.OrderedDict(destination_setting)
                            if (
                                type(source_setting) != collections.OrderedDict
                                or type(destination_setting) != collections.OrderedDict
                            ):
                                # Not a dictionaries
                                logger.debug("not dicts")
                                continue
                            # Get first dictionary key (it's ordered)
                            source_key = next(iter(source_settings[key][new_index].keys()))
                            if (
                                source_key in destination_setting
                                and source_setting[source_key] == destination_setting[source_key]
                            ):
                                # Key values match.  Replace contents.
                                new_match = True
                                destination_settings[key][destination_index] = source_setting

                        if new_match is False:
                            destination_settings[key].append(source_setting)

    def merge_templates(self, templates_path=None) -> None:
        """
        With specified templates_path, perform merge into current settings.

        Keyword arguments:
        templates_path  Directory containing "*.js" files to be merged.
        """
        if templates_path is None:
            return

        if not os.path.exists(templates_path):
            return

        glob_path = f"{templates_path}/*"
        for template_filename in os.listdir(os.path.dirname(glob_path)):
            try:
                template_file = open(f"{templates_path}/{template_filename}")
                template_data = template_file.read()
                template_file.close()
                settings_template = json.loads(
                    template_data, object_pairs_hook=collections.OrderedDict
                )
            except OSError:
                logger.exception("Unable to read template file")
                continue

            self.merge(settings_template)


def get_settings_from_file(file_name):
    """
    Get a settings dict from a specified file
    """
    # By default, return an empty dict
    # if anything goes wrong while
    # reading the settings file
    settings = {}
    try:
        settings_file = open(file_name)
        settings_data = settings_file.read()
        settings_file.close()
        settings = json.loads(settings_data, object_pairs_hook=collections.OrderedDict)
    except OSError:
        logger.exception("Unable to read settings file.")
    return settings


def get_id(file_name):
    """
    Gets the ID for a settings file
    given the filename. Returns
    None if no ID could be determined
    """
    id_ = ""
    path = os.path.abspath(file_name).split("/")
    base_name = path.pop().split(".")
    if SettingsFile.os_name == "debian":
        base_name.pop()
        base_name = ".".join(base_name)
        id_ = base_name
        # Debian/ngfw has a special case where settings file is usually
        # "network.js" but if another app is specified, it will be
        # "settings_xx.js" where xx is a number.  In this case, pull
        # the last path as the identifier so "/../intrusion-prevention/settings_82.js"
        # will have an idenfitier of "intrusion-prevention".
        if base_name.startswith("settings_"):
            id_ = path.pop()
    elif SettingsFile.os_name in ("openwrt", "untangle-waf", "eos", "vittoria"):
        id_ = base_name[0]
    else:
        logger.error("Unable to retrieve ID for settings file %s.", str(file_name))

    return id_
