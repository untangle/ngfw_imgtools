"""Interface utilities."""

import json
import re
from typing import Any, Union

from sync import board_util, network_util
from sync.board_util import BoardUtil
from sync.file_util import FileUtil
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

GREEK_NAMES = [
    "alpha",
    "beta",
    "gamma",
    "delta",
    "epsilon",
    "zeta",
    "eta",
    "theta",
    "iota",
    "kappa",
    "lambda",
    "mu",
]

INTERFACE_CONDITIONS = {
    "SOURCE_INTERFACE_NAME": "SOURCE_INTERFACE_ZONE",
    "DESTINATION_INTERFACE_NAME": "DESTINATION_INTERFACE_ZONE",
}


def discover_interfaces(use_startup_config=False) -> list[dict[str, Any]]:
    "this discovers all devices present in MFW and create interface settings for them"
    device_list = network_util.get_devices()
    internal_device_list = board_util.get_internal_interfaces()
    wan_device_list = board_util.get_wan_interfaces()
    base_mac_addr = None

    if BoardUtil.is_platform_os_eos() and use_startup_config:
        wan_from_config = network_util.get_wan_interfaces_from_startup_config()
        if wan_from_config:
            # Use WAN interfaces from startup-config instead of board defaults
            wan_device_list = wan_from_config

    # Move wans to top of list
    for wan_device_name in wan_device_list:
        if wan_device_name in device_list:
            device_list.remove(wan_device_name)
            device_list.insert(wan_device_list.index(wan_device_name), wan_device_name)

    interface_list = []
    intf_id = 0
    internal_id = None
    wwan_index = 0
    internal_count = 1

    # add management interface first so it takes the first available IP
    devices = network_util.get_devices()
    sorted_devices = [d for d in devices if network_util.is_management_device_name(d)] + [
        d for d in devices if not network_util.is_management_device_name(d)
    ]

    if BoardUtil.is_platform_os_eos():
        base_mac_addr = get_intf_burninaddr()
        if not board_util.is_valid_mac(base_mac_addr):
            # If mac from device cache is invalid, consider et1_1 as baseMacAddr
            base_mac_addr = board_util.get_device_macaddr("et1_1")

    for device_name in sorted_devices:
        if "." in device_name:
            # we're ignoring all interfaces that contain a dot in their name
            # because those are VLANs and we don't want them to be upgraded
            continue
        if device_name in board_util.get_hidden_interfaces():
            continue
        intf_id = intf_id + 1
        interface = {}
        interface["interfaceId"] = intf_id
        interface["device"] = device_name
        interface["name"] = board_util.get_interface_name(interface["device"])

        interface["qosEnabled"] = False
        interface["downloadKbps"] = 0
        interface["uploadKbps"] = 0
        interface["wanWeight"] = 0

        interface["macaddr"] = board_util.get_interface_macaddr(interface["device"], base_mac_addr)

        if interface["device"].startswith("wlan"):
            interface["type"] = "WIFI"
        elif interface["device"].startswith("wwan"):
            interface["type"] = "WWAN"
        else:
            interface["type"] = "NIC"

        if device_name in internal_device_list:
            internal_id = intf_id
            create_settings_internal_interface(interface, internal_count)
            internal_count = internal_count + 1
        elif device_name in wan_device_list:
            # TODO: Add logic to get any preconfigured interface settings here for WANs
            create_settings_wan_interface(interface, wan_device_list.index(device_name))
        elif interface["type"] == "WWAN":
            create_settings_wwan_interface(interface, wwan_index)
            wwan_index += 1
        elif network_util.is_management_device_name(device_name):
            create_management_interface(interface, internal_count)
        else:
            interface["wan"] = False
            interface["enabled"] = True
            if interface["name"] == "":
                if intf_id < len(GREEK_NAMES):
                    interface["name"] = GREEK_NAMES[intf_id]
                else:
                    interface["name"] = "intf%i" % intf_id
            if internal_id is not None and (
                device_name.startswith("wlan") or device_name in internal_device_list
            ):
                interface["configType"] = "BRIDGED"
                interface["bridgedTo"] = internal_id
            else:
                create_settings_internal_interface(interface, internal_count)
                internal_count = internal_count + 1
                interface["enabled"] = False

        interface_list.append(interface)
    return interface_list


def create_settings_interfaces(settings) -> None:
    """Create interfaces settings."""
    settings["network"]["interfaces"] = discover_interfaces(use_startup_config=True)


def create_settings_wwan_interface(interface, index) -> None:
    """Create the default wwan settings."""
    if interface["name"] == "":
        interface["name"] = "WWAN" + str(index)
    interface["wan"] = True
    interface["management"] = False
    interface["enabled"] = True
    interface["simDelay"] = 10
    interface["simTimeout"] = 30
    interface["simMode"] = "ALL"
    interface["simPdptype"] = "IPV4"
    interface["configType"] = "ADDRESSED"
    interface["v4ConfigType"] = "DHCP"
    interface["v6ConfigType"] = "DISABLED"
    interface["natEgress"] = True
    interface["mtu"] = 1500


def create_settings_internal_interface(interface, internal_count) -> None:
    """Create the default internal settings."""
    if interface["name"] == "":
        if internal_count > 1:
            interface["name"] = "internal%i" % internal_count
        else:
            interface["name"] = "internal"
    interface["wan"] = False
    interface["enabled"] = True
    interface["configType"] = "ADDRESSED"
    interface["v4ConfigType"] = "STATIC"
    interface["v4StaticAddress"] = "192.168.%i.1" % internal_count
    interface["v4StaticPrefix"] = 24
    if SettingsFile.os_name == "eos":
        interface["v6ConfigType"] = "DISABLED"
    else:
        interface["v6ConfigType"] = "ASSIGN"
        interface["v6AssignPrefix"] = 64
        interface["v6AssignHint"] = "1234"
        interface["dhcpEnabled"] = True
        interface["dhcpRangeStart"] = "192.168.%i.100" % internal_count
        interface["dhcpRangeEnd"] = "192.168.%i.200" % internal_count
        interface["dhcpRelayEnabled"] = False
        interface["dhcpRelayAddress"] = ""
        interface["dhcpLeaseDuration"] = 60 * 60
    interface["mtu"] = 1500
    if board_util.is_docker():
        interface["configType"] = "ADDRESSED"
        interface["v4ConfigType"] = "STATIC"
        interface["v4StaticAddress"] = "172.51.0.2"
        interface["v4StaticPrefix"] = 16
        interface["v6ConfigType"] = "DISABLED"
        interface["mtu"] = 1500


def create_management_interface(interface: dict[str, Any], internal_count: int) -> None:
    """Creates the default settings for a management interface if.

    Should only be used if the management interface is setup and has an
    IP assigned.
    """
    ipv4 = network_util.get_intf_ipv4_from_startup_config(interface["device"])
    if ipv4:
        interface["v4StaticAddress"] = str(ipv4.ip)
        interface["v4StaticPrefix"] = ipv4.network.prefixlen
    else:
        interface["v4StaticAddress"] = f"192.168.{internal_count}.1"
        interface["v4StaticPrefix"] = 24

    if interface["name"] == "":
        if internal_count > 1:
            interface["name"] = f"mgmt{internal_count}"
        else:
            interface["name"] = "mgmt"

    ipv6 = network_util.get_intf_ipv6_from_startup_config(interface["device"])
    if ipv6:
        interface["v6StaticAddress"] = str(ipv6.ip)
        interface["v6StaticPrefix"] = ipv6.network.prefixlen
        interface["v6ConfigType"] = "STATIC"
    else:
        interface["v6ConfigType"] = "ASSIGN"
        interface["v6AssignPrefix"] = 64
        interface["v6AssignHint"] = "1234"

    interface["wan"] = False
    interface["management"] = True
    interface["enabled"] = True
    interface["configType"] = "ADDRESSED"
    interface["dhcpRelayEnabled"] = False
    interface["dhcpRelayAddress"] = ""
    interface["dhcpLeaseDuration"] = 60 * 60
    interface["v4ConfigType"] = "STATIC"
    interface["mtu"] = 1500

    internal_count = internal_count + 1


def create_settings_wan_interface(interface, index) -> None:
    """create the default wan settings"""
    if interface["name"] == "":
        interface["name"] = "WAN" + str(index)
    interface["wan"] = True
    interface["enabled"] = True
    interface["configType"] = "ADDRESSED"
    interface["v4ConfigType"] = "DHCP"
    if SettingsFile.os_name == "eos":
        interface["v6ConfigType"] = "DISABLED"
    else:
        interface["v6ConfigType"] = "DHCP"
    interface["natEgress"] = True
    interface["mtu"] = 1500
    if board_util.is_docker():
        interface["configType"] = "ADDRESSED"
        interface["v4ConfigType"] = "STATIC"
        interface["v4StaticAddress"] = "172.50.0.2"
        interface["v4StaticPrefix"] = 16
        interface["v4StaticGateway"] = "172.50.0.1"
        interface["v4StaticDNS1"] = "8.8.8.8"
        interface["v4StaticDNS2"] = "8.8.4.4"
        interface["v6ConfigType"] = "DISABLED"
        interface["mtu"] = 1500


def get_intf_burninaddr():
    fru_plugin_file = FileUtil.locate_file("/etc/sfaFruPluginDevices.json")
    try:
        with open(fru_plugin_file) as file:
            data = json.load(file)
            return data.get("firstMacAddr")
    except Exception:
        return None


def get_intf_eos_name(mfw_intf: dict) -> Union[str, None]:
    """
    Given an MFW interface from the settings file's
    network/interfaces list, return the eos name of the interface
    (like, et1_1 becomes Ethernet1/1). This currently only works for
    management and ethernet interfaces.

    Returns None if we don't know how to get the eos name, otherwise a
    string.
    """
    dev: str = mfw_intf["device"]
    m = re.match(r"(et|ma)(\d+)_(\d+)", dev)

    if not m:
        return None

    type = m.group(1)
    slot = m.group(2)
    card = m.group(3)

    eos_typename = None

    if type == "et":
        eos_typename = "Ethernet"
    elif type == "ma":
        eos_typename = "Management"
    else:
        return None

    return f"{eos_typename}{slot}/{card}"


def get_all_wan_list(settings):
    """
    returns a list of wan_interface's for all enabled wans
    """
    wan_list = []
    interfaces = settings.get("network").get("interfaces")
    for intf in interfaces:
        if network_util.enabled_wan(intf):
            wan_list.append({"interfaceId": intf.get("interfaceId"), "weight": 1})

    return wan_list


def get_number_of_wans(settings):
    """returns number of enabled wan interfaces"""
    wans = 0
    interfaces = settings.get("network").get("interfaces")
    for intf in interfaces:
        if network_util.enabled_wan(intf):
            wans += 1

    return wans


def sanitize_interface_name_conditions(settings_file: SettingsFile, condition: dict) -> dict:
    """
    We should change any source_interface_name or destionation_interface_name == <device_name> or <UI_interface_name>
    conditions into source_interface_zone or destination_interface_zone conditions == <interface_id>, because
    interface names can change from UI and we do not want to incorrectly raise a SettingsException for such cases.
    So modify them into source_interface_zone or destination_interface_zone == <interface_id> type of conditions
    here, because <interface_id> cannot be changed for interfaces, hence conditions on zones always work correctly.
    Parameters:
    -----------
    settings_file : object
        An object containing the settings, which includes network interface details. It is expected to have
        a `settings` attribute that provides access to the network configuration.
    condition : dict
        A dictionary representing a condition. It should contain the following keys:
        - "type" (str): The type of the condition, e.g., "source_interface_name" or "destination_interface_name".
        - "value" (str): The value of the condition, typically the name of the interface.
    Returns:
    --------
    dict
        The modified condition dictionary where the interface name condition is replaced with an
        interface zone condition.
    Raises:
    -------
    SettingsException
        If the provided interface name in the condition does not match any known interface name or device name in the settings file.
    """
    condition_type = condition.get("type")
    condition_value = condition.get("value", "").lower()
    if condition_value == "lo":
        return condition
    interfaces = settings_file.settings.get("network", {}).get("interfaces", [])
    for interface in interfaces:
        # If the interface name condition was already either a Linux device name or it was a UI interface name,
        # then change it into a <source_or_dest>_interface_zone == <interface _id> condition now. So that its
        # consequent interface mark would be set in the nftable rule handled during nftable rule translation.
        if (
            condition_value == interface.get("device", "").lower()
            or condition_value == interface.get("name", "").lower()
        ):
            condition["type"] = INTERFACE_CONDITIONS[condition_type]
            condition["value"] = interface["interfaceId"]
            return condition
    # If condition_value didn't match any device or interface name, then this is an invalid interface name.
    raise SettingsException(
        message="invalid_interface_name",
        vars=[condition_value, condition_type.split("_")[0].capitalize()],
    )


def get_interface_key_to_details_dict(settings: dict, key_name: str = "interfaceId") -> dict:
    """
    Creates a dictionary mapping interface attributes to their configuration details.

    Args:
        settings: The settings dictionary containing network interface configurations.
        key_name: The interface attribute to use as the dictionary key (default: "interfaceId").
                  Common values: "interfaceId", "name" (device name).

    Returns:
        Dictionary mapping key_name values to interface detail dictionaries containing:
        - interfaceId: The interface ID
        - name: The device name
        - display_name: The display name (empty string if not set)
        - configType, v4ConfigType, v4StaticAddress, v4StaticNetmask, v4StaticGateway: Network configuration
    """
    interfaces = settings.get("network", {}).get("interfaces", [])
    return {
        intf[key_name]: {
            "interfaceId": intf["interfaceId"],
            "name": intf["device"],
            "display_name": intf.get("name", ""),
            "configType": intf.get("configType", ""),
            "v4ConfigType": intf.get("v4ConfigType", ""),
            "v4StaticAddress": intf.get("v4StaticAddress"),
            "v4StaticPrefix": intf.get("v4StaticPrefix", 24),
        }
        for intf in interfaces
        if "interfaceId" in intf and "device" in intf and key_name in intf
    }


def get_all_interface_ids(settings: dict) -> set[int]:
    """
    Extract all interface IDs from network.interfaces settings.

    Args:
        settings: The settings dictionary containing network interface configurations.

    Returns:
        Set of interface IDs found in network.interfaces.
    """
    all_interface_ids = set()
    interfaces = settings.get("network", {}).get("interfaces", [])
    for intf in interfaces:
        intf_id = intf.get("interfaceId")
        if intf_id is not None:
            all_interface_ids.add(intf_id)
    return all_interface_ids
