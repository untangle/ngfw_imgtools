import os
import shutil
import sys

from sync.board_util import BoardUtil
from sync.common import Logger

logger = Logger.getInstance()


class FileUtil:
    """
    General file utilities
    """

    @classmethod
    def find(cls, search_name, search_path=None):
        """
        Find file or diectory within search path.

        search_name     string  File or directory name or substring to find.
        search_path     string  Root path to search below.  If not specified, use sys.path
        """
        if search_path is None:
            search_path = sys.path
        elif type(search_path) is not list:
            search_path = [search_path]

        file_names = []
        for path in search_path:
            for root, dirs, files in os.walk(path):
                for target in dirs + files:
                    if search_name in target:
                        full_path = os.path.join(root, target)
                        if full_path not in file_names:
                            file_names.append(full_path)

        return file_names

    @classmethod
    def copy(cls, source_path=None, destination_path=None) -> None:
        """ """
        if source_path is None:
            return
        if destination_path is None:
            return

        shutil.copy2(source_path, destination_path)

    @classmethod
    def locate_file(cls, file_name):
        """
        Locate/translate file based on platform
        """
        # Special paths that do not fit the typical translation rules for kernel -> EOS
        eos_special_paths = {"/etc/sfaFruPluginDevices.json": "/var/run/sfaFruPluginDevices.json"}
        vittoria_special_paths = {
            "/usr/bin/fetch_ip_list.py": "/opt/mfw/bin/fetch_ip_list.py",
            "/usr/bin/dynamic_lists_dispatcher.py": "/opt/mfw/bin/dynamic_lists_dispatcher.py",
        }

        openwrt_settings_path = "/etc/config"
        eos_settings_path = "/mnt/flash/mfw-settings"
        vittoria_settings_path = "/opt/mfw/etc"

        if os.path.exists(file_name):
            return file_name

        if BoardUtil.is_platform_mfw():
            return file_name

        if BoardUtil.is_platform_os_eos() and file_name in eos_special_paths:
            return eos_special_paths[file_name]

        if BoardUtil.is_platform_vittoria() and file_name in vittoria_special_paths:
            return vittoria_special_paths[file_name]

        file_path = os.path.abspath(file_name)
        if str(file_path).startswith(openwrt_settings_path):
            if BoardUtil.is_platform_os_eos():
                settings_path_prefix = eos_settings_path
            elif BoardUtil.is_platform_vittoria():
                settings_path_prefix = vittoria_settings_path
            else:
                msg = f"Could not determine the platform while locating file: {file_name}. Not translating for current platform"
                if not (BoardUtil.is_NGFW() or BoardUtil.is_WAF()):
                    logger.error(msg)
                return file_name

            # Remove openwrt_settings_path from the path and place it
            # under the settings_path_prefix. Handles files in directories
            relative_path = os.path.relpath(file_path, openwrt_settings_path)
            settings_path = os.path.join(settings_path_prefix, relative_path.lstrip("/"))
            return str(settings_path)

        return file_name

    @classmethod
    def move_write_only_registered_files_to_tmp(cls, new_file_path, delete_old_dir=False):
        """
        Move the write-only registered files from /etc/config to /tmp
        """
        old_file_path = new_file_path.replace("/tmp", "/etc/config")
        if os.path.exists(old_file_path):
            file_dir = os.path.dirname(new_file_path)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)
            shutil.move(old_file_path, new_file_path)
            if delete_old_dir:
                old_file_dir = os.path.dirname(old_file_path)
                os.rmdir(old_file_dir)
