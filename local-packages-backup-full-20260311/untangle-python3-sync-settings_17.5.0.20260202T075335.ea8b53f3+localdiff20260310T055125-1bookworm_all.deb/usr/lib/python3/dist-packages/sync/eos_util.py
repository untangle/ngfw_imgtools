from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import os
    import pathlib

from sync.common import Logger

logger = Logger.getInstance()


class StaleSysdbState:
    """
    Stale vlan-interfaces are present in the kernel, even after removing
    it from settings.json and running sync-settings (MFW - 3340).
    A stale vlan-interface is identified by comparing the old with the new
    contents of interface.cfg file.
    'no interface' form of the stale interface is appended to the new configs,
    which ensures stale vlan-interfaces to be removed from Sysdb.

    Similarly, in hybrid mode, stale ACLs are left behind when access/filter
    rules are removed from settings.json. We find out these ACLs here and append
    "no " to these rules and add them back to the acl.cfg file to be removed.
    """

    def __init__(self, file_path: str | os.path | pathlib.Path, new_config_string: str) -> None:
        self.file_path = file_path
        self.new_configs = new_config_string
        self.deleted_entries = []

    def _discover_deleted_entity(self, entity: str) -> None:
        """
        since the <entity>.cfg file, still isn't overwritten with the new configs,
        the old configs are read and deleted entities are obtained.
        """
        old_config_string = ""
        with open(self.file_path) as f:
            old_config_string = f.read()

        old_config = self._convert_to_dictionary(old_config_string, entity)
        new_config = self._convert_to_dictionary(self.new_configs, entity)

        self._update_deleted_entities(old_config, new_config)

    def _convert_to_dictionary(self, configs: str, entity: str) -> dict[str, list]:
        """
        The <entity>.cfg config strings are converted into dictionaries
        with entity name as the key and its attributes as the value.
        """
        config_dictionary = {}
        config_key = ""
        config_value = []
        for raw_line in configs.splitlines():
            line = raw_line.strip()
            if line == "":
                continue
            if f"no {entity}" in line:
                # Ignore, this config is for Sysdb to remove stale vlan-interfaces
                continue
            if entity in line:
                config_key = line
            elif line == "!" and config_key != "":
                config_dictionary[config_key] = config_value.copy()
                config_value.clear()
                config_key = ""
            else:
                config_value.append(line)
        return config_dictionary

    def _update_deleted_entities(
        self, old_config: dict[str, list], new_config: dict[str, list]
    ) -> None:
        """
        A stale entity is identified by comparing the old with the new
        contents of <entity>.cfg file.
        """
        for entry in old_config:
            if entry not in new_config:
                self.deleted_entries.append(entry)

    def remove_stale_entity(self, entity: str) -> str:
        """
        Updates config to add 'no <entity>' for deleted entries in the new configs.
        also removes 'interfaces' from WAN group if any.
        """
        self._discover_deleted_entity(entity)
        if len(self.deleted_entries) == 0:
            return self.new_configs
        self.new_configs = self.new_configs + "\n"

        deleted_str = ""
        deleted_wan_group_entries = []
        for entry in self.deleted_entries:
            deleted_str = deleted_str + f"no {entry}\n"
            if entity == "interface" and "vlan" in entry.lower():
                deleted_wan_group_entries.append(f"   no {entry}")
        self.new_configs = deleted_str + "\n" + self.new_configs
        deleted_wan_group = ""
        if entity == "interface":
            if deleted_wan_group_entries:
                deleted_wan_group = (
                    "group interface WAN\n" + "\n".join(deleted_wan_group_entries) + "\n!"
                )
        self.new_configs = self.new_configs + deleted_wan_group
        return self.new_configs

    def parse_acl_cfg(self, config, intfs):
        """
        Function to parse acl.cfg to retrieve converted ACLs for each eth intf
            Input: acl.cfg
            Output: Dict of ACLs for each eth intf
        """
        acl_dict = {}
        for eth in intfs:
            # Creating default lists
            acl_dict[eth] = []
        config_list = config.splitlines()
        eth_num = "0"  # Default string
        i = 0
        while i < len(config_list):
            if (i == 0) and ("access-list" not in str(config_list[i])):
                return None
            if str(config_list[i]) == "!":
                i = i + 1
                eth_num = "0"
                continue
            if "access-list" in str(config_list[i]):
                for eth in intfs:
                    if i >= len(config_list):
                        eth_num = "0"
                        break
                    if eth in str(config_list[i]):
                        eth_num = str(config_list[i])
                        break
                    eth_num = "0"
                    continue
                i = i + 1
            elif str(eth_num) == "0":
                # This means that although access-list and ! are not found
                # this config is not meant for this list of eths
                # So, just continue
                i = i + 1
                continue
            else:
                acl_dict[eth_num].append(str(config_list[i]))
                i = i + 1
        return acl_dict

    def remove_stale_acls(self, intf_list):
        old_config_string = ""
        """
        Returns a dict of ACLs for each intf that were deleted
        if any
        """
        with open(self.file_path) as f:
            old_config_string = f.read()
        old_acl_dict = self.parse_acl_cfg(old_config_string, intf_list)
        if old_acl_dict is None:
            return None
        new_acl_dict = self.parse_acl_cfg(self.new_configs, intf_list)
        if new_acl_dict is None:
            return None
        diff_acl_dict = {}

        for eth in intf_list:
            diff_acl_dict[eth] = []
            for i in range(len(old_acl_dict[eth])):
                if (old_acl_dict[eth][i] not in new_acl_dict[eth]) and (
                    "no " not in str(old_acl_dict[eth][i])
                ):
                    # Create a negation rule to delete this rule
                    deleted_rule = "no " + str(old_acl_dict[eth][i].strip())
                    diff_acl_dict[eth].append(deleted_rule)

        return diff_acl_dict


class EOSBashRunner:
    """
    This API is used for execution any command in EOS Bash
    """

    bash_timeout = "15"
    bash_prefix = f"bash timeout {bash_timeout} bash -c"

    def __init__(self, eapiClient) -> None:
        self.eapiClient = eapiClient

    def run_with_timeout(self, command):
        """
        Will take a bash command and run it with a timeout.
        Returns the output
        """
        output = self.eapiClient.runCmds(
            version=1,
            cmds=[f"{self.bash_prefix} '{command}'"],
            format="text",
            requestTimeout=1,
        )["result"][0]["output"]
        logger.info("ran command '%s' with output: '%s'", str(command), str(output))

        return output


class SysdbNotify(EOSBashRunner):
    """
    The initial requirement of this is from MFW-3378 to update
    Sysdb's packetd, on settings changes using Acons
    """

    sysdb_packetd_signal_path = "/ar/Sysdb/bess/cli/config"
    acons_suffix = "| python3 -m Acons Sysdb"

    def run_acons_command(self, path, command):
        """
        Will take the input of Sysdb path and command to execute
        Returns the eAPI client output
        """
        command = f'(echo -e "cd {path}"; {command}) {self.acons_suffix}'
        return super().run_with_timeout(command)

    def sysdb_notify_packetd(self) -> None:
        """
        If there is any change is settings.json and
        if the sync-settings runs without an issue
        then .packetdSignal in bess will be toggled
        """
        command = 'echo -e "_.packetdSignal = 1"'
        self.run_acons_command(self.sysdb_packetd_signal_path, command)
        command = 'echo -e "_.packetdSignal = 0"'
        self.run_acons_command(self.sysdb_packetd_signal_path, command)
