"""This class is responsible for managing logger settings"""

from sync import Manager, registrar
from sync.common import Logger
from sync.logger_defaults import default_logger_settings
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class LoggerManager(Manager):
    """LoggerManager manages the logger settings"""

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:  # noqa: ANN001, ARG002
        """syncs settings"""
        logger.info("Sync settings")

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["logger"] = default_logger_settings()

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""

        logger_settings = settings_file.settings.get("logger")
        defaults = default_logger_settings()

        # missing logger settings
        if logger_settings is None:
            settings_file.settings["logger"] = defaults

        # keep only defined settings
        settings_file.settings["logger"] = {
            name: value
            for name, value in settings_file.settings["logger"].items()
            if name in defaults
        }

        # reset setting if empty
        for name, value in defaults.items():
            if name not in settings_file.settings["logger"]:
                settings_file.settings["logger"][name] = value
            else:
                # if the key exist check for the inner fields to see if defaults for any new service is added
                for s_name, s_value in value.items():
                    if s_name not in settings_file.settings["logger"][name]:
                        settings_file.settings["logger"][name][s_name] = s_value

    def validate_settings(self, settings_file) -> None:
        """validates settings"""

        logger_settings = settings_file.settings.get("logger")

        # missing logger settings
        if logger_settings is None:
            raise SettingsException(message_str="Missing Logger settings")

        # missing/invalid logger prop
        for key in default_logger_settings():
            value = logger_settings.get(key)
            if value is None or not isinstance(value, object):
                raise SettingsException(
                    message_str=f'Missing or invalid required Logger setting "{key}"'
                )


registrar.register_manager(LoggerManager())
