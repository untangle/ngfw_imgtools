import subprocess

from sync.common import Logger

logger = Logger.getInstance()


class EncryptionUtil:
    @staticmethod
    def execute_password_manager(encrypt_decrypt_Flag, cipher_text):
        """
        Executes the password-manager script with the specified flag and text.

        Args:
            flag (str): The flag to pass to the password manager script (e.g., '-e' for encrypt).
            text (str): The text to be processed by the password manager script.

        Returns:
            str: The encrypted data extracted from the password manager script.
        """
        command = ["/usr/bin/password-manager", encrypt_decrypt_Flag, cipher_text]

        # Run password-manager script as a subprocess
        password_manager_process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        # Communicate with the password-manager script
        output, error = password_manager_process.communicate()

        # Check for any errors
        if password_manager_process.returncode != 0:
            logger.error("failed with error: %s", error)
            msg = "password_manager_failure"
            raise RuntimeError(msg)

        return output.strip()
