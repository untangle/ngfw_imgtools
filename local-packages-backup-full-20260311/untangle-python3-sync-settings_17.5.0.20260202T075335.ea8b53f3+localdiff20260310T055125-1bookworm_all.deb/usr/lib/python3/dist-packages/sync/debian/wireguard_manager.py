import os
import stat

from sync import IptablesUtil, Manager, NetworkUtil, Variables, registrar
from sync.common import Logger
from sync.iptables_util import IptablesUtil
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class WireguardManager(Manager):
    """
    This class is responsible for generating wireguard configuration
    based on the settings object passed from sync-settings
    """

    wireguard_vpn_conf = "/etc/wireguard/wg0.conf"
    wireguard_remote_conf_dir = "/etc/wireguard/untangle"
    wireguard_iptables_script = "/etc/untangle/iptables-rules.d/720-wireguard-vpn"

    iptables_table_chain_rules = {
        "mangle": {
            # Set source interface mark
            "mark-src-intf": [
                {
                    "new": "insert",
                    "index": 3,
                    "rule": '-i $WG_INTERFACE -j MARK --set-mark {src_mark} -m comment --comment "Set src interface mark for wireguard vpn"',
                }
            ],
            "mark-dst-intf": [
                {
                    # Mark destination interface mark
                    "new": "insert",
                    "index": 3,
                    "rule": '-o $WG_INTERFACE -j MARK --set-mark {dst_mark} -m comment --comment "Set dst interface mark for wireguard vpn"',
                },
                {
                    # MSS clamping rule for wireguard tunnels
                    "new": "insert",
                    "index": 3,
                    "rule": '-o $WG_INTERFACE -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu -m comment --comment "Perform mss clamping for wireguard vpn"',
                },
            ],
        },
        "nat": {
            "port-forward-rules": [
                {
                    "new": "insert",
                    "rule": '-p tcp -d {wireguard_ip_address} --destination-port _https_port_ -j REDIRECT --to-ports 443 -m comment --comment "Send wireguard VPN to apache https"',
                },
                {
                    "new": "insert",
                    "rule": '-p tcp -d {wireguard_ip_address} --destination-port _http_port_ -j REDIRECT --to-ports 80 -m comment --comment "Send wireguard to apache http"',
                },
            ]
        },
        "filter": {
            "nat-reverse-filter": [
                {
                    "new": "insert",
                    "rule": '-m mark --mark {src_mark} -j RETURN -m comment --comment "Allow wireguard vpn"',
                }
            ]
        },
    }

    def initialize(self) -> None:
        """
        Register settings of interest and our file
        """
        registrar.register_settings_file("wireguard-vpn", self)
        registrar.register_file(self.wireguard_vpn_conf, "restart-wireguard", self)
        registrar.register_file(self.wireguard_iptables_script, "restart-iptables", self)
        ## !! need to remove all files.  Maybe rsync instead of cp?
        registrar.register_file(self.wireguard_remote_conf_dir + "/*", "restart-wireguard", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Synchronize our file by modifying.  This is different than how other managers.
        """
        self.write_wireguard_vpn_local_configuration(settings_file, prefix)
        self.write_wireguard_vpn_remote_configuration(settings_file, prefix)
        self.write_wireguard_iptables_script(settings_file, prefix)

    def write_wireguard_vpn_local_configuration(self, settings_file, prefix) -> None:
        """
        Write wireguard configuration for wg-quick
        """
        if settings_file.id != "wireguard-vpn":
            return

        self.out_file_name = prefix + self.wireguard_vpn_conf
        self.out_file_dir = os.path.dirname(self.out_file_name)
        if not os.path.exists(self.out_file_dir):
            os.makedirs(self.out_file_dir)
        self.out_file = open(self.out_file_name, "w+")

        # Interface
        self.out_file.write("[Interface]\n")
        self.out_file.write(
            "PrivateKey={privateKey}\n".format(privateKey=settings_file.settings.get("privateKey"))
        )
        address = settings_file.settings.get("addressPool")
        if address is not None:
            self.out_file.write("Address={address}\n".format(address=address.split("/")[0]))
        self.out_file.write(
            "ListenPort={listenPort}\n".format(listenPort=settings_file.settings.get("listenPort"))
        )
        if settings_file.settings.get("mtu") != 0:
            self.out_file.write("MTU={mtu}\n".format(mtu=settings_file.settings.get("mtu")))
        self.out_file.write("Table=wireguard")
        self.out_file.write("\n")

        # Peers
        keepaliveInterval = settings_file.settings.get("keepaliveInterval")
        for tunnel in settings_file.settings.get("tunnels"):
            if tunnel.get("enabled") is False:
                continue
            self.out_file.write("[Peer]\n")
            self.out_file.write("# {name}\n".format(name=tunnel.get("description")))
            self.out_file.write(
                "PublicKey={publicKey}\n".format(publicKey=tunnel.get("publicKey"))
            )
            if tunnel.get("endpointDynamic") is False:
                self.out_file.write(
                    "Endpoint={endpointHostname}:{endpointPort}\n".format(
                        endpointHostname=tunnel.get("endpointHostname"),
                        endpointPort=tunnel.get("endpointPort"),
                    )
                )
            allowedIps = []
            allowedIps.append(tunnel.get("peerAddress"))
            for network in tunnel.get("networks").split():
                allowedIps.append(network)
            self.out_file.write(
                "AllowedIPs={allowedIps}\n".format(allowedIps=",".join(allowedIps))
            )

            # only enable keepalives for static endpoints
            if tunnel.get("endpointDynamic") is False and keepaliveInterval != 0:
                self.out_file.write(f"PersistentKeepalive={keepaliveInterval}\n")

            self.out_file.write("\n")

        self.out_file.flush()
        self.out_file.close()
        os.chmod(self.out_file_name, stat.S_IRUSR | stat.S_IWUSR)

        logger.info("Wrote %s", str(self.out_file_name))

    def write_wireguard_vpn_remote_configuration(self, settings_file, prefix) -> None:
        """
        Write remote wireguard configuration for wg-quick
        """
        if settings_file.id != "wireguard-vpn":
            return

        if "tunnels" not in settings_file.settings:
            return

        for tunnel in settings_file.settings.get("tunnels"):
            if tunnel.get("enabled") is False:
                continue

            self.out_file_name = (
                prefix
                + self.wireguard_remote_conf_dir
                + "/remote-"
                + tunnel.get("publicKey").strip()
                + ".conf"
            )
            self.out_file_dir = os.path.dirname(self.out_file_name)
            if not os.path.exists(self.out_file_dir):
                os.makedirs(self.out_file_dir)
            self.out_file = open(self.out_file_name, "w+")

            # Interface
            self.out_file.write("[Interface]\n")
            if tunnel.get("privateKey") != "":
                self.out_file.write(
                    "PrivateKey={privateKey}\n".format(privateKey=tunnel.get("privateKey"))
                )
            else:
                self.out_file.write("PrivateKey=\n")
            self.out_file.write("Address={address}\n".format(address=tunnel.get("peerAddress")))
            if tunnel.get("endpointDynamic") is False:
                self.out_file.write(
                    "ListenPort={listenPort}\n".format(listenPort=tunnel.get("endpointPort"))
                )
            # Add DNS config if DNS Server settings is not blank
            if settings_file.settings.get("dnsServer"):
                # DNS should be added for all static profiles and dynamic profiles whose Assign DNS Server field is checked
                if tunnel.get("endpointDynamic") is False or tunnel.get("assignDnsServer") is True:
                    if (
                        settings_file.settings.get("dnsSearchDomain") is not None
                        and settings_file.settings.get("dnsSearchDomain").strip() != ""
                    ):
                        self.out_file.write(
                            "DNS={dnsServer},{dnsSearchDomain}\n".format(
                                dnsServer=settings_file.settings.get("dnsServer"),
                                dnsSearchDomain=settings_file.settings.get("dnsSearchDomain"),
                            )
                        )
                    else:
                        self.out_file.write(
                            "DNS={dnsServer}\n".format(
                                dnsServer=settings_file.settings.get("dnsServer")
                            )
                        )

            self.out_file.write("\n")
            self.out_file.write("[Peer]\n")
            self.out_file.write("# {name}\n".format(name=Variables.get("wireguardHostname")))
            self.out_file.write(
                "PublicKey={publicKey}\n".format(publicKey=settings_file.settings.get("publicKey"))
            )
            self.out_file.write(
                "Endpoint={endpointHostname}:{endpointPort}\n".format(
                    endpointHostname=Variables.get("wireguardUrl").split(":")[0],
                    endpointPort=settings_file.settings.get("listenPort"),
                )
            )
            allowedIps = []
            if tunnel.get("routedNetworks"):
                allowedIps = tunnel.get("routedNetworks").split(",")
            allowedIps.insert(0, settings_file.settings.get("addressPool").split("/")[0])
            self.out_file.write(
                "AllowedIPs={allowedIps}\n".format(allowedIps=",".join(allowedIps))
            )

            self.out_file.write("\n")

            self.out_file.flush()
            self.out_file.close()
            os.chmod(self.out_file_name, stat.S_IRUSR | stat.S_IWUSR)
            logger.info("Wrote %s", str(self.out_file_name))

        # shutil.rmtree(self.wireguard_remote_conf_dir)

    def write_wireguard_iptables_script(self, settings_file, prefix) -> None:
        """
        Write wireguard configuration for wg-quick
        """
        if bool(NetworkUtil.settings) is False:
            # Network settings must be specified
            raise SettingsException(message_str="Network settings not specified")

        wireguard_ip_address = settings_file.settings.get("addressPool").split("/")[0]
        # Added support for change of service ports NGFW-13648
        https_port = NetworkUtil.settings.get("httpsPort")
        if not https_port:
            https_port = 443
        http_port = NetworkUtil.settings.get("httpPort")
        if not http_port:
            http_port = 80

        for port_forward_rule in self.iptables_table_chain_rules.get("nat").get(
            "port-forward-rules"
        ):
            port_forward_rule["rule"] = (
                port_forward_rule.get("rule")
                .replace("_https_port_", str(https_port))
                .replace("_http_port_", str(http_port))
            )
        delete_rules, new_rules = IptablesUtil.write_wireguard_iptables_rules(
            self.iptables_table_chain_rules, wireguard_ip_address
        )

        self.out_file_name = prefix + self.wireguard_iptables_script
        self.out_file_dir = os.path.dirname(self.out_file_name)
        if not os.path.exists(self.out_file_dir):
            os.makedirs(self.out_file_dir)
        self.out_file = open(self.out_file_name, "w+")

        self.out_file.write("#!/bin/dash\n")
        self.out_file.write("## DO NOT EDIT. Changes will be overwritten.\n\n")

        self.out_file.write('if [ -z "$IPTABLES" ] ; then IPTABLES=/sbin/iptables ; fi' + "\n")
        self.out_file.write('if [ -z "$IPSET" ] ; then IPSET=/sbin/ipset ; fi' + "\n\n")

        self.out_file.write('WG_VPN_CHAIN="wg-vpn-isolation"' + "\n")
        self.out_file.write(
            "WG_INTERFACE=$(ip link show | grep \"wg[[:digit:]]\\+:\" | cut -d' ' -f2 | cut -d: -f1 | head -1)"
            "\n\n"
        )

        self.out_file.write("##\n")
        self.out_file.write("## Delete current rules\n")
        self.out_file.write("##\n")
        for rule in delete_rules:
            self.out_file.write(rule + "\n")

        self.out_file.write(self.get_wg_vpn_chain_deletion_script())

        self.out_file.write("\n##\n")
        self.out_file.write("## Add new rules\n")
        self.out_file.write("##\n")
        self.out_file.write('if [ "$WG_INTERFACE" != "" ] ; then ' + "\n")
        for rule in new_rules:
            self.out_file.write("    " + rule + "\n")

        self.out_file.write(self.get_wg_vpn_chain_setup_script(settings_file))

        self.out_file.write("fi" + "\n")

        self.out_file.flush()
        self.out_file.close()
        os.chmod(self.out_file_name, os.stat(self.out_file_name).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(self.out_file_name))

    # Method to get the script to flush and delete wg-vpn-isolation filter chain
    # flush and delete tunnel specific ipsets
    def get_wg_vpn_chain_deletion_script(self):
        return (
            "## Delete rule that forwards WireGuard interface traffic to wg-vpn-isolation chain\n"
            "$IPTABLES -t filter -D FORWARD -o $WG_INTERFACE -j $WG_VPN_CHAIN "
            '-m comment --comment "Forward wg interface traffic to wg-vpn-isolation chain" 2>/dev/null\n\n'
            "## Flush previous VPN chain and IP sets\n"
            "$IPTABLES -t filter -F $WG_VPN_CHAIN 2>/dev/null\n"
            "$IPTABLES -t filter -D FORWARD -o $WG_INTERFACE -j $WG_VPN_CHAIN 2>/dev/null\n"
            "$IPTABLES -t filter -X $WG_VPN_CHAIN 2>/dev/null\n\n"
            "## Destroy all IP sets matching wg_tun{ID}_src or wg_tun{ID}_dst\n"
            "for setname in $($IPSET list -n | grep -E '^wg_tun[0-9]+_(src|dst)$'); do\n"
            '    echo "Destroying ipset: $setname"\n'
            '    $IPSET flush "$setname" 2>/dev/null\n'
            '    $IPSET destroy "$setname" 2>/dev/null\n'
            "done\n\n"
        )

    # Method to get the script to create wg-vpn-isolation filter chain,
    # write a rules to forward wireguard traffic to this chain and allow ESTABLISHED,RELATED sessions
    # create src and dst ipsets for each tunnel dynamically and write rules to allow tunnel specific traffic
    # rule to DROP all other traffic from wg interface
    def get_wg_vpn_chain_setup_script(self, settings_file):
        lines = []
        lines.extend(
            [
                "",
                "    ## Create wg-vpn-isolation chain",
                "    $IPTABLES -t filter -N $WG_VPN_CHAIN\n",
                "    ## Jump to wg-vpn-isolation chain for all outgoing traffic via the WireGuard interface",
                '    $IPTABLES -t filter -A FORWARD -o $WG_INTERFACE -j $WG_VPN_CHAIN -m comment --comment "Forward wg interface traffic to wg-vpn-isolation chain"\n',
                "    ## Add rule for allowing ESTABLISHED, RELATED connections",
                '    $IPTABLES -t filter -A $WG_VPN_CHAIN -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT -m comment --comment "Allow ESTABLISHED,RELATED"\n',
            ]
        )

        for tunnel in settings_file.settings.get("tunnels", []):
            if not tunnel.get("enabled", True):
                continue
            ID = str(tunnel.get("id"))
            comment = f"Tunnel {ID}: Allow"

            lines.append(f"    ## {comment}")
            lines.append(f"    $IPSET create wg_tun{ID}_src hash:net -exist")
            lines.append(f"    $IPSET create wg_tun{ID}_dst hash:net -exist")

            # Add routed networks (source)
            routed_networks = tunnel.get("routedNetworks", "").split(",")
            for rnet in routed_networks:
                rnet = rnet.strip()
                if rnet:
                    lines.append(f"    $IPSET add wg_tun{ID}_src {rnet} -exist")

            # Add destination networks
            networks = tunnel.get("networks", "").splitlines()
            for net in networks:
                net = net.strip()
                if net:
                    lines.append(f"    $IPSET add wg_tun{ID}_dst {net} -exist")

            lines.append(
                f"    $IPTABLES -t filter -A $WG_VPN_CHAIN "
                f"-m set --match-set wg_tun{ID}_src src "
                f"-m set --match-set wg_tun{ID}_dst dst "
                f'-j ACCEPT -m comment --comment "{comment}"\n'
            )
        lines.extend(
            [
                "    ## Add rule to drop unmatched VPN traffic",
                '    $IPTABLES -t filter -A $WG_VPN_CHAIN -j DROP -m comment --comment "Drop unmatched VPN traffic"',
            ]
        )

        return "\n".join(lines) + "\n"


registrar.register_manager(WireguardManager())
