import copy
import json
import logging
import os
import stat
import subprocess
import textwrap
from pathlib import Path

from sync import Manager, registrar
from sync.common.dynamic_lists_manager import CommonDynamicListsManager
from sync.debian.fetch_and_block_ip import NgfwDynamicBlockListSetup
from sync.perms_util import regain_permissions

# Configure module-level logger
logger = logging.getLogger(__name__)

# Directory to store block list files
BLOCK_LIST_DIR = Path("/etc/config/blocklists")


class NgfwDynamicBlockListsManager(Manager):
    """
    Manager for NGFW Dynamic IP Blocking.
    Handles synchronization, cron generation, and execution of dynamic block list updates.
    """

    cron_filename = "/etc/cron.d/dbl-crons"
    script_write_filename = "/usr/share/untangle/bin/fetch_ip_list.py"

    def initialize(self):
        """Registers files and settings handled by this manager."""
        registrar.register_settings_file("dynamic-blocklists", self)
        registrar.register_file(self.script_write_filename, None, self)
        registrar.register_file(self.cron_filename, None, self)

    def sync_settings(self, settings_file, prefix, delete_list):
        """
        Syncs block list settings, ensuring directories and files are correctly set up.
        """
        with regain_permissions():
            BLOCK_LIST_DIR.resolve().mkdir(mode=0o755, parents=True, exist_ok=True)
        self.write_script_file(settings_file.settings, prefix)
        self.manage_block_list_files(settings_file, prefix)
        self.write_cron_file(settings_file, prefix, delete_list)

    def write_file(self, destination, data, prefix, mode):
        """Delegates writing files to the common dynamic list manager."""
        CommonDynamicListsManager.write_file(self, destination, data, prefix, mode)

    def write_script_file(self, settings, prefix):
        """
        Writes the fetch_and_block_ip script that triggers list fetching.
        """
        data = textwrap.dedent("""\
        #!/usr/bin/python3
        import sync.debian.fetch_and_block_ip as fetch_and_block_ip
        if __name__ == "__main__":
            fetch_and_block_ip.main()
        """)

        self.write_file(self.script_write_filename, data, prefix, "w")

    def manage_block_list_files(self, settings_file, prefix):
        """
        Ensures enabled block lists are fetched and stale lists are removed.
        """
        settings = settings_file.settings
        source_list = settings.get("configurations")
        all_files = CommonDynamicListsManager.find_block_list_files(self)

        self.clean_removed_source_from_dblSets(source_list)

        if all_files:
            self.delete_orphan_files(source_list, all_files)

        for block_list_config in source_list:
            if not isinstance(block_list_config, dict):
                continue

            if block_list_config.get("enabled") is True:
                with regain_permissions():
                    file_path = self.get_file_path(block_list_config.get("id", ""))
                    exec_cmd = CommonDynamicListsManager.build_fetch_call(
                        self,
                        prefix + self.script_write_filename,
                        block_list_config.get("id", ""),
                        block_list_config.get("source", ""),
                        str(file_path),
                        str(block_list_config.get("skipCertCheck", False)),
                        block_list_config.get("parsingMethod", "^\\S{2,256}"),
                        str(settings_file.file_name),
                        str(True),
                    )

                    # Run process in background to avoid blocking sync
                    exec_proc = subprocess.Popen(
                        exec_cmd,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        start_new_session=True,
                    )
                    subprocess.Popen(
                        ["logger", "-t", "dynamic_list_manager"], stdin=exec_proc.stdout
                    )
                    logger.info(
                        f"Triggered background fetch for blocklist {block_list_config.get('id')}"
                    )
            else:
                NgfwDynamicBlockListSetup.remove_and_destroy_disabled_entry(
                    NgfwDynamicBlockListSetup, "dblsets", block_list_config.get("id")
                )

    def create_auto_text(self, settings_file):
        """
        Builds a cron job string for all enabled block list configurations.
        """
        settings = settings_file.settings.get("configurations")
        cron_entries = []

        for auto_settings in settings:
            if not auto_settings or not auto_settings.get("enabled"):
                continue

            polling_unit = auto_settings.get("pollingUnit", "")
            polling_time = auto_settings.get("pollingTime", "")
            source_url = auto_settings.get("source", "")
            settings_guid = auto_settings.get("id", "")
            skip_cert_check = auto_settings.get("skipCertCheck", False)
            regex = auto_settings.get("parsingMethod", "^\\S{2,256}")
            file_path = self.get_file_path(settings_guid)
            setting_file = str(settings_file.file_name)

            # Build cron time pattern
            if polling_unit == "Minutes":
                cron = f"*/{polling_time} * * * *"
            elif polling_unit == "Hours":
                cron = f"0 */{polling_time} * * *"
            elif polling_unit == "Days":
                cron = f"0 0 */{polling_time} * *"
            elif polling_unit == "Months":
                cron = f"0 0 1 */{polling_time} *"
            else:
                continue

            fetch_command = " ".join(
                CommonDynamicListsManager.build_fetch_call(
                    self,
                    self.script_write_filename,
                    settings_guid,
                    source_url,
                    str(file_path),
                    str(skip_cert_check),
                    json.dumps(regex),
                    setting_file,
                    str(True),
                )
            )
            cron_entries.append(
                f"{cron} root {fetch_command} 2>&1 | logger -t dynamic_list_manager"
            )
        cron_text = "\n".join(cron_entries)
        if cron_text and not cron_text.endswith("\n"):
            cron_text += "\n"
        return cron_text

    def write_cron_file(self, settings, prefix, delete_list):
        """
        Writes cron configuration to trigger periodic block list updates.
        """
        cron_string = self.create_auto_text(settings)
        if cron_string:
            self.write_file(self.cron_filename, cron_string, prefix, "w")
            logger.info("Cron file for dynamic block lists updated successfully.")
        elif os.path.exists(self.cron_filename):
            delete_list.append(self.cron_filename)
            logger.debug("Removed stale cron configuration for dynamic block lists.")

    def get_file_path(self, list_id: str) -> Path:
        """
        Returns the filesystem path for a given block list ID.
        """
        file_name = CommonDynamicListsManager.block_list_file_name(self, list_id)
        return BLOCK_LIST_DIR.joinpath(file_name)

    def clean_removed_source_from_dblSets(self, dynamic_lists):
        """
        Removes any IP set entries that no longer correspond to an active configuration.
        """
        current_ids = {cfg.get("id") for cfg in dynamic_lists if isinstance(cfg, dict)}

        try:
            cmd = "ipset list dblsets -o save | grep '^add' | awk '{print $3}'"
            output = subprocess.check_output(cmd, shell=True, text=True)
            dblset_members = set(output.strip().splitlines())

            for member in dblset_members:
                if member not in current_ids:
                    logger.debug(f"Removing dblset member not in config: {member}")
                    NgfwDynamicBlockListSetup.remove_and_destroy_disabled_entry(
                        NgfwDynamicBlockListSetup, "dblsets", member
                    )

            NgfwDynamicBlockListSetup.remove_and_destroy_disabled_entry(
                NgfwDynamicBlockListSetup, "dblsets", "cidr_list"
            )

        except subprocess.CalledProcessError as e:
            logger.warning(f"Failed to fetch dblsets members: {e}")

    def delete_orphan_files(self, dynamic_lists, all_files):
        """
        Deletes orphaned block list files not associated with active configurations.
        """
        orphaned = copy.deepcopy(all_files)

        for configuration in dynamic_lists:
            if not configuration or not configuration.get("enabled"):
                continue

            list_id = configuration.get("id", "")
            try:
                orphaned.remove(self.get_file_path(list_id))
            except ValueError:
                logger.debug(f"{self.get_file_path(list_id)} not found among existing files.")

        for orphan_file in orphaned:
            try:
                # Remove CIDR entries from ipset if applicable
                with open(orphan_file) as f:
                    for line in f:
                        ip = line.strip()
                        if not ip:
                            continue
                        if "/" in ip or "-" in ip:
                            if NgfwDynamicBlockListSetup.ipset_exists(
                                NgfwDynamicBlockListSetup, "cidr_list"
                            ):
                                subprocess.run(
                                    ["sudo", "ipset", "del", "cidr_list", ip],
                                    check=False,
                                )
                                logger.debug(f"Removed CIDR IP {ip} from cidr_list.")
            except Exception as e:
                logger.warning(f"Error processing orphan file {orphan_file}: {e}")

            # Remove the orphaned file
            try:
                with regain_permissions():
                    if orphan_file.is_file():
                        orphan_file.unlink(missing_ok=True)
                        logger.debug(f"Deleted orphaned block list file: {orphan_file}")
            except PermissionError:
                logger.debug(f"Permission denied deleting {orphan_file}")

    @staticmethod
    def change_file_permissions(filename: str, _):
        """
        Ensures execute permissions are added for the file owner.
        """
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.debug(f"Set execute permissions for: {filename}")


# Register manager instance
registrar.register_manager(NgfwDynamicBlockListsManager())
