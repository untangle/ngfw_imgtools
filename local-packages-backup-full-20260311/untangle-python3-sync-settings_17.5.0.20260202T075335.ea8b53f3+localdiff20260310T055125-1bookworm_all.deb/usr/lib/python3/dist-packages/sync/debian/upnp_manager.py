import os
import stat

from sync import Manager, registrar
from sync.common import Logger

# This class is responsible for writing
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class UpnpManager(Manager):
    upnp_daemon_conf_filename = "/etc/miniupnpd/miniupnpd.conf"
    restart_hook_filename = "/etc/untangle/post-network-hook.d/990-restart-upnp"
    iptables_filename = "/etc/untangle/iptables-rules.d/741-upnp"
    iptables_init_filename = "/etc/miniupnpd/iptables_init.sh"
    ip6tables_init_filename = "/etc/miniupnpd/ip6tables_init.sh"

    #    iptables_chain = "upnp-rules"
    iptables_chain = "MINIUPNPD"

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_file(self.upnp_daemon_conf_filename, "restart-miniupnpd", self)
        registrar.register_file(self.restart_hook_filename, "restart-miniupnpd", self)
        registrar.register_file(self.iptables_filename, "restart-iptables", self)
        registrar.register_file(self.iptables_init_filename, "restart-miniupnpd", self)
        registrar.register_file(self.ip6tables_init_filename, "restart-miniupnpd", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        self.write_upnp_daemon_conf(settings_file.settings, prefix)
        self.write_restart_upnp_daemon_hook(settings_file.settings, prefix)
        self.write_iptables_hook(settings_file.settings, prefix)
        self.write_iptables_init_files(settings_file.settings, prefix)

    def write_upnp_daemon_conf(self, settings, prefix="") -> None:
        """
        Create UPnP configuration file
        """
        filename = prefix + self.upnp_daemon_conf_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated" + "\n")
        file.write("## DO NOT EDIT. Changes will be overwritten." + "\n")

        wan_interfaces = []
        lan_interfaces = []
        first_lan_address = None
        for intf in settings["interfaces"]:
            if intf.get("disabled"):
                continue
            if intf.get("isWan"):
                wan_interfaces.append(intf.get("symbolicDev"))
            else:
                lan_interfaces.append(intf.get("symbolicDev"))
                if first_lan_address is None:
                    first_lan_address = intf.get("v4StaticAddress")

        file.write("# Server options" + "\n")
        # WAN interface - Only one supported so use first
        if len(wan_interfaces) > 0:
            file.write(f"ext_ifname={wan_interfaces[0]}" + "\n")
        # LAN interface
        for intf in lan_interfaces:
            file.write(f"listening_ip={intf}" + "\n")
        # LXC interface
        file.write("listening_ip=br.lxc" + "\n")

        if (
            settings.get("upnpSettings") is None
            or settings["upnpSettings"].get("upnpEnabled") is False
        ):
            file.flush()
            file.close()
            os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
            logger.info("Wrote %s", str(filename))
            return

        port = settings["upnpSettings"].get("listenPort")
        file.write(f"port={port}" + "\n")
        file.write("enable_natpmp=yes" + "\n")
        file.write("enable_upnp=yes" + "\n")
        # Secure mode
        secure_mode = "yes" if settings["upnpSettings"].get("secureMode") is True else "no"
        file.write(f"secure_mode={secure_mode}" + "\n")

        file.write("system_uptime=yes" + "\n")

        file.write("\n" + "# Server identification notifications" + "\n")
        model_version = ""
        with open("/usr/share/untangle/lib/untangle-libuvm-api/VERSION") as version_file:
            model_version = version_file.read().replace("\n", "")
        host_name = settings["hostName"]
        file.write(f"friendly_name={host_name}" + "\n")
        file.write(f"model_name=NGFW {model_version}" + "\n")
        file.write("manufacturer_name=Arista" + "\n")
        file.write("model_number=1" + "\n")
        # NOTE: This is a bogus uuid and serial number.  DO NOT use the system's actual UUID and
        # serial number as the valyes will be seen by UPNP clients.
        file.write("uuid=b014febc-1170-4421-9f04-852de5742a80" + "\n")
        file.write("serial=12345678" + "\n")

        # If not specified, it picks the last LAN (not specified above!)
        file.write(f"presentation_url=http://{first_lan_address}/" + "\n")

        file.write("\n" + "# Rules" + "\n")
        # Rules
        for rule in settings["upnpSettings"]["upnpRules"]:
            if rule.get("enabled") is False:
                continue
            upnp_rule_action = "allow" if rule.get("allow") else "deny"
            upnp_rule_external_ports = "0-65535"
            upnp_rule_internal_address = "0.0.0.0/0"
            upnp_rule_internal_ports = "0-65535"
            for condition in rule["conditions"]:
                if condition.get("conditionType") == "DST_PORT":
                    upnp_rule_external_ports = condition.get("value")
                elif condition.get("conditionType") == "SRC_ADDR":
                    upnp_rule_internal_address = condition.get("value")
                elif condition.get("conditionType") == "SRC_PORT":
                    upnp_rule_internal_ports = condition.get("value")
            upnp_rule = f"{upnp_rule_action} {upnp_rule_external_ports} {upnp_rule_internal_address} {upnp_rule_internal_ports}"
            file.write(f"{upnp_rule}" + "\n")

        # Write custom advanced options
        if settings["upnpSettings"].get("customOptions") is not None:
            file.write("\\# Custom  options\n")
            custom_options = settings["upnpSettings"].get("customOptions")
            file.write(f"{custom_options}" + "\n")
            file.write("\n")

        file.write("\n")
        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))
        return

    def write_restart_upnp_daemon_hook(self, settings, prefix="") -> None:
        """
        Create network process extension to restart or stop daemon
        """
        filename = prefix + self.restart_hook_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        if (
            settings.get("upnpSettings") is None
            or settings["upnpSettings"].get("upnpEnabled") is False
        ):
            file.write(r"""
UPNPD_PID="`pidof miniupnpd`"

# Stop miniupnpd if running
if [ ! -z "$UPNPD_PID" ] ; then
    systemctl --no-block stop miniupnpd
    #/etc/untangle/iptables-rules.d/741-upnp
fi
""")
        else:
            file.write(r"""
UPNPD_PID="`pidof miniupnpd`"

# Restart miniupnpd if it isnt found
# Or if miniupnpd.conf orhas been written since miniupnpd was started
if [ -z "$UPNPD_PID" ] ; then
    systemctl --no-block restart miniupnpd
# use not older than (instead of newer than) because it compares seconds and we want an equal value to still do a restart
elif [ ! /etc/miniupnpd/miniupnpd.conf -ot /proc/$UPNPD_PID ] ; then
    systemctl --no-block restart miniupnpd
fi
""")

        file.write("\n")
        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_iptables_hook(self, settings, prefix="") -> None:
        """
        Create iptables configuraton for daemon
        """
        filename = prefix + self.iptables_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        wan_interfaces = []
        lan_interfaces = []
        first_lan_address = None
        for intf in settings["interfaces"]:
            if intf.get("disabled"):
                continue
            if intf.get("isWan"):
                wan_interfaces.append(intf.get("symbolicDev"))
            else:
                lan_interfaces.append(intf.get("symbolicDev"))
                if first_lan_address is None:
                    first_lan_address = intf.get("v4StaticAddress")

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        file.write("IPTABLES=${IPTABLES:-iptables}" + "\n")
        file.write(f"CHAIN={self.iptables_chain}" + "\n")
        if len(wan_interfaces) > 0:
            file.write(f"EXTIF={wan_interfaces[0]}" + "\n")
        # IPTABLES=${IPTABLES:-iptables}
        # CHAIN=%s
        # EXTIF=eth0

        file.write(r"""

flush_upnp_iptables_rules()
{
    # Clean the nat tables
    ${IPTABLES} -t nat -F ${CHAIN} >/dev/null 2>&1
    ${IPTABLES} -t nat -D PREROUTING -i ${EXTIF} -j ${CHAIN} >/dev/null 2>&1
    ${IPTABLES} -t nat -X ${CHAIN} >/dev/null 2>&1

    ${IPTABLES} -t nat -F ${CHAIN}-POSTROUTING >/dev/null 2>&1
    ${IPTABLES} -t nat -D POSTROUTING -o ${EXTIF} -j ${CHAIN}-POSTROUTING >/dev/null 2>&1
    ${IPTABLES} -t nat -X ${CHAIN}-POSTROUTING >/dev/null 2>&1

    # Clean the filter tables
    ${IPTABLES} -t filter -F ${CHAIN} >/dev/null 2>&1
    ${IPTABLES} -t filter -D FORWARD -i ${EXTIF} ! -o ${EXTIF} -j $CHAIN >/dev/null 2>&1
    ${IPTABLES} -t filter -X ${CHAIN} >/dev/null 2>&1

    # Clean mangle tables
    ${IPTABLES} -t mangle -F ${CHAIN} >/dev/null 2>&1
    ${IPTABLES} -t mangle -D FORWARD PREROUTING -i ${EXTIF} -j ${CHAIN} >/dev/null 2>&1
    ${IPTABLES} -t mangle -X ${CHAIN} >/dev/null 2>&1


}

insert_upnp_iptables_rules()
{
    ADDCMD=-A

    ${IPTABLES} -t nat -N $CHAIN
    ${IPTABLES} -t nat $ADDCMD PREROUTING -i $EXTIF -j $CHAIN
    ${IPTABLES} -t nat -F ${CHAIN}

    ${IPTABLES} -t nat -N $CHAIN-POSTROUTING
    ${IPTABLES} -t nat $ADDCMD POSTROUTING -o $EXTIF -j $CHAIN-POSTROUTING
    ${IPTABLES} -t nat -F ${CHAIN}-POSTROUTING

    ${IPTABLES} -t filter -N MINIUPNPD
    ${IPTABLES} -t filter $ADDCMD FORWARD -i $EXTIF ! -o $EXTIF -j $CHAIN
    ${IPTABLES} -t filter -F ${CHAIN}

    ${IPTABLES} -t mangle -N $CHAIN
    ${IPTABLES} -t mangle $ADDCMD PREROUTING -i $EXTIF -j $CHAIN
    ${IPTABLES} -t mangle -F ${CHAIN}

}

flush_upnp_iptables_rules

""")
        # insert_upnp_iptables_rules

        if (
            settings.get("upnpSettings") is not None
            and settings["upnpSettings"].get("upnpEnabled") is True
        ):
            file.write("insert_upnp_iptables_rules" + "\n")

        file.write("\n")
        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_iptables_init_files(self, settings, prefix="") -> None:
        """
        Overwrite miniupnpd package scripts
        The miniupnp packaging calls these scripts in the postinst
        We must overwrite them so they don't fail with an error
        """
        filename = prefix + self.iptables_init_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        file = open(filename, "w+")
        file.write("#!/bin/sh\n")
        file.write("exit 0\n")
        file.flush()
        file.close()
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

        filename = prefix + self.ip6tables_init_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        file = open(filename, "w+")
        file.write("#!/bin/sh\n")
        file.write("exit 0\n")
        file.flush()
        file.close()
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(UpnpManager())
