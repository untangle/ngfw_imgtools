import os
import stat

from sync import Manager, registrar
from sync.common import Logger

# This class is responsible for writing /etc/untangle/pre-network-hook.d/015-ethernet-media
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class EthernetManager(Manager):
    ethernet_media_filename = "/etc/untangle/pre-network-hook.d/015-ethernet-media"
    set_link_media_script = "/usr/share/untangle-sync-settings/bin/set-link-media.sh"

    duplex_map = {
        "AUTO": "auto",
        "M10000_FULL_DUPLEX": "10000-full-duplex",
        "M10000_HALF_DUPLEX": "10000-half-duplex",
        "M1000_FULL_DUPLEX": "1000-full-duplex",
        "M1000_HALF_DUPLEX": "1000-half-duplex",
        "M100_FULL_DUPLEX": "100-full-duplex",
        "M100_HALF_DUPLEX": "100-half-duplex",
        "M10_FULL_DUPLEX": "10-full-duplex",
        "M10_HALF_DUPLEX": "10-half-duplex",
    }

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_file(self.ethernet_media_filename, "restart-networking", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        self.write_ethernet_media(settings_file.settings, prefix)

    def write_ethernet_media(self, settings, prefix) -> None:
        filename = prefix + self.ethernet_media_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        if settings.get("devices") is not None:
            for deviceSettings in settings.get("devices"):
                if deviceSettings.get("mtu") is not None and deviceSettings.get("mtu") != 0:
                    file.write(
                        f"ip link set {deviceSettings.get('deviceName')} mtu {deviceSettings.get('mtu')}"
                        "\n"
                    )
                if deviceSettings.get("duplex") is not None:
                    duplex = deviceSettings.get("duplex")
                    if duplex not in self.duplex_map:
                        logger.error("Unknown duplex: %s", str(duplex))
                        continue
                    eeeEnabled = deviceSettings.get("energyEfficientEthernet")
                    file.write(
                        f"{self.set_link_media_script} {deviceSettings.get('deviceName')} {self.duplex_map.get(duplex)} {eeeEnabled}\n"
                    )

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(filename))


registrar.register_manager(EthernetManager())
