import ipaddress
import os
import stat

from sync import Manager, NetworkUtil, network_util, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class IPsecManager(Manager):
    """
    This class is responsible for generating ipsec configuration
    based on the settings object passed from sync-settings
    """

    ipsec_iptables_script = "/etc/untangle/iptables-rules.d/710-ipsec"
    ipsec_xauth_script = "/etc/untangle/iptables-rules.d/711-xauth"
    ipsec_gre_script = "/etc/untangle/iptables-rules.d/712-gre"

    def initialize(self) -> None:
        """
        Register settings of interest and our file
        """
        registrar.register_settings_file("ipsec-vpn", self)
        registrar.register_file(self.ipsec_iptables_script, "restart-iptables", self)
        registrar.register_file(self.ipsec_xauth_script, "restart-iptables", self)
        registrar.register_file(self.ipsec_gre_script, "restart-iptables", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Synchronize our file by modifying.  This is different than how other managers.
        """
        if bool(NetworkUtil.settings) is False:
            # Network settings must be specified
            raise SettingsException(message_str="Network settings not specified")
        settings = settings_file.settings
        self.write_ipsec_iptables_script(settings, prefix)
        self.write_XAUTH_script(settings, prefix)
        self.write_GRE_script(settings, prefix)

    def write_ipsec_iptables_script(self, settings, prefix) -> None:
        """
        Write ipsec iptables configuration
        """
        first_ip = str(
            ipaddress.IPv4Network(settings.get("virtualAddressPool")).network_address + 1
        )
        https_port = str(NetworkUtil.settings.get("httpsPort"))
        http_port = str(NetworkUtil.settings.get("httpPort"))

        self.out_file_name = prefix + self.ipsec_iptables_script
        self.out_file_dir = os.path.dirname(self.out_file_name)
        if not os.path.exists(self.out_file_dir):
            os.makedirs(self.out_file_dir)

        try:
            self.out_file = open(self.out_file_name, "w+")

            self.out_file.write("#!/bin/dash\n\n")
            self.out_file.write("# " + self.out_file_name + "\n")
            self.out_file.write(
                "# This file is created and maintained by the Untangle IPsec service.\n"
            )
            self.out_file.write(
                "# If you modify this file manually, your changes will be overwritten!\n\n"
            )

            self.out_file.write('if [ "$t_script" != "" ] ; then\n')
            self.out_file.write("  script_file_name=$t_script" + "\n")
            self.out_file.write("else" + "\n")
            self.out_file.write("  script_file_name=$0" + "\n")
            self.out_file.write("fi" + "\n")
            self.out_file.write("script_path=$(dirname $script_file_name)" + "\n")
            self.out_file.write("base_path=" + "\n")

            """
                * If we're not called from standard environment, we're probably in developer mode, so
                * dial back to get developer "root"
            """
            self.out_file.write(
                'if [ "$script_path" != "/etc/untangle/iptables-rules.d" ] ; then' + "\n"
            )
            self.out_file.write(
                "    new_base_path=$(dirname $(dirname $(dirname $script_path)))" + "\n"
            )

            """
                * If our base candidate path is not "." (we were called locally from the production location)
                * then use this new base candidate indicating a developer environment.
            """
            self.out_file.write('    if  [ "$new_base_path" != "." ] ; then' + "\n")
            self.out_file.write("        base_path = $new_base_path" + "\n")
            self.out_file.write("    fi" + "\n")
            self.out_file.write("fi" + "\n")

            """
                * With the base path and full reference to ut-uvm-update-rules.sh, capture the
                * variables we need to build our own DNAT rules.
            """
            self.out_file.write(
                "uvm_rules_file_name=$base_path/usr/share/untangle/bin/ut-uvm-update-rules.sh\n"
            )
            self.out_file.write(
                "# Get variables from untangle-vm script for non-bypass rules" + "\n"
            )
            self.out_file.write("eval $(grep TUN_DEV= $uvm_rules_file_name)" + "\n")
            self.out_file.write("eval $(grep TCP_REDIRECT_PORTS= $uvm_rules_file_name)" + "\n")

            self.out_file.write(
                "\n" + 'if [ -z "$IPTABLES" ] ; then IPTABLES=iptables ; fi' + "\n\n"
            )
            self.out_file.write(
                "\n" + 'if [ -z "$IP6TABLES" ] ; then IP6TABLES=ip6tables ; fi' + "\n\n"
            )

            # Determine if ipsec is enabled, 0 for true and false for the rest of return codes
            self.out_file.write(
                "IPSEC_STATUS=$(systemctl status ipsec >/dev/null 2>&1; echo $?)" + "\n"
            )

            self.out_file.write(
                "# We put the L2TP port forward rules in their own chain that we can flush" + "\n"
            )
            self.out_file.write(
                "# since the server address can be changed by the user meaning there is" + "\n"
            )
            self.out_file.write("# no easy way to find and delete any old rules" + "\n")
            self.out_file.write("${IPTABLES} -t nat -N l2tp-forward-rules >/dev/null 2>&1" + "\n")
            self.out_file.write(
                "${IPTABLES} -t nat -F l2tp-forward-rules >/dev/null 2>&1" + "\n\n"
            )

            self.out_file.write(
                "# We put the IPSec nat rules in their own chain that we can flush" + "\n"
            )
            self.out_file.write(
                "# since the server address can be changed by the user meaning there is" + "\n"
            )
            self.out_file.write("# no easy way to find and delete any old rules" + "\n")
            self.out_file.write(
                "${IPTABLES} -t nat -N tunnel-postrouting-rules >/dev/null 2>&1" + "\n"
            )

            self.out_file.write("# Allow IPsec traffic through the NAT reverse filter" + "\n")
            self.out_file.write(
                '${IPTABLES} -t filter -D nat-reverse-filter -m policy --pol ipsec --dir in  -j RETURN -m comment --comment "allow IPsec traffic" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write(
                '${IPTABLES} -t filter -D nat-reverse-filter -m policy --pol ipsec --dir out -j RETURN -m comment --comment "allow IPsec traffic" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write(
                "    "
                '${IPTABLES} -t filter -I nat-reverse-filter -m policy --pol ipsec --dir in  -j RETURN -m comment --comment "allow IPsec traffic"'
                "\n"
            )
            self.out_file.write(
                "    "
                '${IPTABLES} -t filter -I nat-reverse-filter -m policy --pol ipsec --dir out -j RETURN -m comment --comment "allow IPsec traffic"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write(
                '${IPTABLES} -t filter -D nat-reverse-filter -i ipsec+ -j RETURN -m comment --comment "allow IPsec traffic" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write(
                '${IPTABLES} -t filter -D nat-reverse-filter -i ipsec+ -j RETURN -m comment --comment "allow IPsec traffic" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write(
                "    "
                '${IPTABLES} -t filter -I nat-reverse-filter -o ipsec+ -j RETURN -m comment --comment "allow IPsec traffic"'
                "\n"
            )
            self.out_file.write(
                "    "
                '${IPTABLES} -t filter -I nat-reverse-filter -o ipsec+ -j RETURN -m comment --comment "allow IPsec traffic"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write(
                '${IPTABLES} -t nat -D POSTROUTING -m policy --pol ipsec --dir out -j RETURN -m comment --comment "do not NAT IPsec traffic" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write(
                "    " + "# Do not NAT all other ipsec traffic even if its leaving a WAN" + "\n"
            )
            self.out_file.write(
                "    "
                '${IPTABLES} -t nat -I POSTROUTING -m policy --pol ipsec --dir out -j RETURN -m comment --comment "do not NAT IPsec traffic"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write(
                '${IPTABLES} -t nat -D POSTROUTING -j tunnel-postrouting-rules -m comment --comment "nat jump for IPSEC" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write(
                "    " + "# Add the jump rule for the IPSec postrouting nat rules" + "\n"
            )
            self.out_file.write(
                "    "
                '${IPTABLES} -t nat -I POSTROUTING -j tunnel-postrouting-rules -m comment --comment "nat jump for IPSEC"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write("# Remove any existing IPsec traffic bypass rules" + "\n")
            self.out_file.write(
                "${IPTABLES} -t filter -D bypass-rules -m policy --pol ipsec --dir out --goto set-bypass-mark >/dev/null 2>&1"
                "\n"
            )
            self.out_file.write(
                "${IPTABLES} -t filter -D bypass-rules -m policy --pol ipsec --dir in  --goto set-bypass-mark >/dev/null 2>&1"
                "\n\n"
            )
            self.out_file.write(
                "${IPTABLES} -t filter -D bypass-rules -i ipsec+ --goto set-bypass-mark >/dev/null 2>&1"
                "\n"
            )
            self.out_file.write(
                "${IPTABLES} -t filter -D bypass-rules -i ipsec+ --goto set-bypass-mark >/dev/null 2>&1"
                "\n\n"
            )

            self.out_file.write(
                "# Bypass local to local traffic on IPsec if bypass flag is not set" + "\n"
            )

            # Our specific chain for dnat mapping.
            self.out_file.write(
                "# DNAT chain for traffic from right networks to proper local interface" + "\n"
            )
            self.out_file.write(
                "${IPTABLES} -t nat -N uvm-ipsec-tcp-redirect >/dev/null 2>&1" + "\n"
            )
            self.out_file.write(
                "${IPTABLES} -t nat -F uvm-ipsec-tcp-redirect >/dev/null 2>&1" + "\n\n"
            )

            # Remove our jump call in nat/uvm-tcp-redirect
            self.out_file.write(
                "${IPTABLES} -D uvm-tcp-redirect -t nat -j uvm-ipsec-tcp-redirect >/dev/null 2>&1"
                "\n\n"
            )

            if bool(settings.get("bypassflag")) is True:
                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    " + "# The bypass flag is set so add IPsec traffic bypass rules" + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t filter -I bypass-rules -m policy --pol ipsec --dir out --goto set-bypass-mark"
                    "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t filter -I bypass-rules -m policy --pol ipsec --dir in  --goto set-bypass-mark"
                    "\n"
                )
                self.out_file.write("fi" + "\n")
            else:
                # Rules to bypass local to local traffic so traffic will flow(NGFW-13426)
                active = False
                for tunnel in settings.get("tunnels"):
                    # Delete the rule for all tunnels and add only for the active ones
                    left_subnet = tunnel.get("leftSubnet")
                    left_subnet_parts = left_subnet.split("/")
                    if len(left_subnet_parts) == 0:
                        continue
                    # From our left side determine our local interface address.
                    interface_address = network_util.get_interface_by_ip_and_interfaces(
                        NetworkUtil.settings["interfaces"], left_subnet_parts[0]
                    )
                    if interface_address == None:
                        continue

                    right_subnet = tunnel.get("rightSubnet")
                    self.out_file.write(
                        "${IPTABLES} -D uvm-ipsec-tcp-redirect -t nat -i ${TUN_DEV}"
                        " -p tcp --source "
                        + right_subnet
                        + " --destination "
                        + left_subnet
                        + " -j DNAT"
                        + " --to-destination "
                        + interface_address.get("v4StaticAddress")
                        + ":${TCP_REDIRECT_PORTS}"
                        + " -m comment --comment \"Redirect reinjected ipsec for '"
                        + tunnel.get("description")
                        + "' to the untangle-vm\" >/dev/null 2>&1"
                        + "\n"
                    )
                    if not bool(tunnel.get("active")):
                        continue
                    active = True
                    self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                    self.out_file.write(
                        "    ${IPTABLES} -A uvm-ipsec-tcp-redirect -t nat -i ${TUN_DEV}"
                        " -p tcp --source "
                        + right_subnet
                        + " --destination "
                        + left_subnet
                        + " -j DNAT"
                        + " --to-destination "
                        + interface_address.get("v4StaticAddress")
                        + ":${TCP_REDIRECT_PORTS}"
                        + " -m comment --comment \"Redirect reinjected ipsec for '"
                        + tunnel.get("description")
                        + "' to the untangle-vm\""
                        + "\n"
                    )
                    self.out_file.write("fi" + "\n")
                if active:
                    self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                    self.out_file.write(
                        "    "
                        "${IPTABLES} -I uvm-tcp-redirect -t nat -j uvm-ipsec-tcp-redirect >/dev/null 2>&1"
                        "\n"
                    )
                    self.out_file.write("fi" + "\n")

            self.out_file.write(
                '${IPTABLES} -t nat -D nat-rules -m mark --mark 0xfb/0xff -j MASQUERADE -m comment --comment "NAT l2tp traffic" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write("    " + "# NAT traffic from L2TP interfaces" + "\n")
            self.out_file.write(
                "    "
                '${IPTABLES} -t nat -I nat-rules -m mark --mark 0xfb/0xff -j MASQUERADE -m comment --comment "NAT l2tp traffic"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write(
                '${IPTABLES} -t filter -D nat-reverse-filter -m mark --mark 0xfb/0xff -j RETURN -m comment --comment "Allow L2TP" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write("    " + "# Allow L2TP traffic to penetrate NATd networks" + "\n")
            self.out_file.write(
                "    "
                '${IPTABLES} -t filter -I nat-reverse-filter -m mark --mark 0xfb/0xff -j RETURN -m comment --comment "Allow L2TP"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write(
                '${IPTABLES} -t nat -D port-forward-rules -j l2tp-forward-rules -m comment --comment "Port forward jump for L2TP" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write("    " + "# Add the jump rule for the L2TP port forwards" + "\n")
            self.out_file.write(
                "    "
                '${IPTABLES} -t nat -I port-forward-rules -j l2tp-forward-rules -m comment --comment "Port forward jump for L2TP"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            if bool(settings.get("vpnflag")) is True:
                self.out_file.write(
                    "# Add port forward rules for L2TP and Xauth clients.  We need the port 53 rules"
                    "\n"
                )
                self.out_file.write(
                    "# for Xauth clients since the server side of the L2TP interface will not exist"
                    "\n"
                )
                self.out_file.write(
                    "# if no L2TP clients are connected.  Using the L2TP server side addresses for"
                    "\n"
                )
                self.out_file.write(
                    "# Xauth clients ended up being cleaner than trying to use the WAN interface."
                    "\n"
                )
                self.out_file.write(
                    "# We also don't need to do delete cleanup here since we're using dedicated\n"
                )
                self.out_file.write("# chains that were flushed above." + "\n")
                self.out_file.write(
                    "${IPTABLES} -t nat -D l2tp-forward-rules -p tcp -d "
                    + first_ip
                    + " --destination-port "
                    + https_port
                    + ' -j REDIRECT --to-ports 443 -m comment --comment "Send L2TP to apache" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write(
                    "${IPTABLES} -t nat -D l2tp-forward-rules -p tcp -d "
                    + first_ip
                    + " --destination-port "
                    + http_port
                    + ' -j REDIRECT --to-ports 80 -m comment --comment "Send L2TP to apache" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write(
                    "${IPTABLES} -t nat -D l2tp-forward-rules -p tcp -d "
                    + first_ip
                    + ' --destination-port 53 -j REDIRECT --to-ports 53 -m comment --comment "Send L2TP tcp to dnsmasq" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write(
                    "${IPTABLES} -t nat -D l2tp-forward-rules -p udp -d "
                    + first_ip
                    + ' --destination-port 53 -j REDIRECT --to-ports 53 -m comment --comment "Send L2TP udp to dnsmasq" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t nat -I l2tp-forward-rules -p tcp -d "
                    + first_ip
                    + " --destination-port "
                    + https_port
                    + ' -j REDIRECT --to-ports 443 -m comment --comment "Send L2TP to apache"'
                    + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t nat -I l2tp-forward-rules -p tcp -d "
                    + first_ip
                    + " --destination-port "
                    + http_port
                    + ' -j REDIRECT --to-ports 80 -m comment --comment "Send L2TP to apache"'
                    + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t nat -I l2tp-forward-rules -p tcp -d "
                    + first_ip
                    + ' --destination-port 53 -j REDIRECT --to-ports 53 -m comment --comment "Send L2TP tcp to dnsmasq"'
                    + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t nat -I l2tp-forward-rules -p udp -d "
                    + first_ip
                    + ' --destination-port 53 -j REDIRECT --to-ports 53 -m comment --comment "Send L2TP udp to dnsmasq"'
                    + "\n"
                )
                self.out_file.write("fi" + "\n")

                self.out_file.write(
                    '${IPTABLES} -t filter -D access-rules -p udp --dport 1701 -m policy --dir in --pol none -j DROP -m comment --comment "drop L2TP without IPsec" >/dev/null 2>&1'
                    "\n"
                )
                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    # This special rule blocks L2TP udp traffic on 1701 without IPsec\n"
                )
                self.out_file.write(
                    "    "
                    '${IPTABLES} -t filter -I access-rules -p udp --dport 1701 -m policy --dir in --pol none -j DROP -m comment --comment "drop L2TP without IPsec"'
                    "\n"
                )
                self.out_file.write("fi" + "\n")
        except Exception:
            logger.exception("Unable to write script:")
        finally:
            try:
                if self.out_file is not None:
                    self.out_file.flush()
                    self.out_file.close()
            except Exception:
                logger.exception("Unable to close script:")

        os.chmod(self.out_file_name, os.stat(self.out_file_name).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(self.out_file_name))

    def write_XAUTH_script(self, settings, prefix) -> None:
        """
        Write ipsec XAUTH iptables configuration
        """

        self.out_file_name = prefix + self.ipsec_xauth_script
        self.out_file_dir = os.path.dirname(self.out_file_name)
        if not os.path.exists(self.out_file_dir):
            os.makedirs(self.out_file_dir)

        try:
            self.out_file = open(self.out_file_name, "w+")

            self.out_file.write("#!/bin/dash\n\n")
            self.out_file.write("# " + self.out_file_name + "\n")
            self.out_file.write(
                "# This file is created and maintained by the Untangle IPsec service.\n"
            )
            self.out_file.write(
                "# If you modify this file manually, your changes will be overwritten!\n\n"
            )

            self.out_file.write('if [ -z "$IPTABLES" ] ; then IPTABLES=iptables ; fi' + "\n\n")

            # Determine if ipsec is enabled, 0 for true and false for the rest of return codes
            self.out_file.write(
                "IPSEC_STATUS=$(systemctl status ipsec >/dev/null 2>&1; echo $?)" + "\n"
            )

            self.out_file.write(
                "# we put the rules to mark the ipsec xauth interface in their own chains since\n"
            )
            self.out_file.write(
                "# the cidr pool is used to identify the traffic and that could be changed" + "\n"
            )
            self.out_file.write(
                "# by the user so we start by creating and flushing the chains" + "\n"
            )
            self.out_file.write("${IPTABLES} -t mangle -N ipsec-xauth-src >/dev/null 2>&1" + "\n")
            self.out_file.write("${IPTABLES} -t mangle -N ipsec-xauth-dst >/dev/null 2>&1" + "\n")
            self.out_file.write("${IPTABLES} -t mangle -F ipsec-xauth-src >/dev/null 2>&1" + "\n")
            self.out_file.write(
                "${IPTABLES} -t mangle -F ipsec-xauth-dst >/dev/null 2>&1" + "\n\n"
            )

            self.out_file.write("# delete old jump rules (if they exist)" + "\n")
            self.out_file.write(
                '${IPTABLES} -t mangle -D mark-src-intf -j ipsec-xauth-src -m comment --comment "src interface jump for Xauth" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write(
                '${IPTABLES} -t mangle -D mark-dst-intf -j ipsec-xauth-dst -m comment --comment "dst interface jump for Xauth" >/dev/null 2>&1'
                "\n\n"
            )

            self.out_file.write("# delete old nat-rules rule" + "\n")
            self.out_file.write(
                '${IPTABLES} -t nat -D nat-rules -m mark --mark 0xfc/0xff -j MASQUERADE -m comment --comment "NAT Xauth traffic" >/dev/null 2>&1'
                "\n\n"
            )

            self.out_file.write("# delete old nat-reverse-filter rule" + "\n")
            self.out_file.write(
                '${IPTABLES} -t filter -D nat-reverse-filter -m mark --mark 0xfc/0xff -j RETURN -m comment --comment "Allow Xauth" >/dev/null 2>&1'
                "\n\n"
            )

            if bool(settings.get("vpnflag")) is True:
                self.out_file.write(
                    "${IPTABLES} -t mangle -D ipsec-xauth-src -s "
                    + settings.get("virtualXauthPool")
                    + ' -j MARK --set-mark 0xfc/0xff -m comment --comment "Set src interface mark for Xauth" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write(
                    "${IPTABLES} -t mangle -D ipsec-xauth-src -s "
                    + settings.get("virtualXauthPool")
                    + ' -j CONNMARK --save-mark --mask 0xFFFF -m comment --comment "Copy mark to connmark for Xauth" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write(
                    "${IPTABLES} -t mangle -D ipsec-xauth-dst -d "
                    + settings.get("virtualXauthPool")
                    + ' -j MARK --set-mark 0xfc00/0xff00 -m comment --comment "Set dst interface mark for Xauth" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write(
                    "${IPTABLES} -t mangle -D ipsec-xauth-dst -d "
                    + settings.get("virtualXauthPool")
                    + ' -j CONNMARK --save-mark --mask 0xFFFF -m comment --comment "Copy mark to connmark for Xauth" >/dev/null 2>&1'
                    + "\n"
                )

                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    # first we add rules to the Xauth mark chains we prepared above" + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t mangle -I ipsec-xauth-src -s "
                    + settings.get("virtualXauthPool")
                    + ' -j MARK --set-mark 0xfc/0xff -m comment --comment "Set src interface mark for Xauth"'
                    + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t mangle -A ipsec-xauth-src -s "
                    + settings.get("virtualXauthPool")
                    + ' -j CONNMARK --save-mark --mask 0xFFFF -m comment --comment "Copy mark to connmark for Xauth"'
                    + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t mangle -I ipsec-xauth-dst -d "
                    + settings.get("virtualXauthPool")
                    + ' -j MARK --set-mark 0xfc00/0xff00 -m comment --comment "Set dst interface mark for Xauth"'
                    + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t mangle -A ipsec-xauth-dst -d "
                    + settings.get("virtualXauthPool")
                    + ' -j CONNMARK --save-mark --mask 0xFFFF -m comment --comment "Copy mark to connmark for Xauth"'
                    + "\n"
                )
                self.out_file.write("fi" + "\n")

                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    "
                    "# Add jump rules for xauth traffic.  These must be inserted ABOVE the line that"
                    "\n"
                )
                self.out_file.write(
                    "    "
                    "# returns if the marks are already set, otherwise the mark for the physical"
                    "\n"
                )
                self.out_file.write(
                    "    "
                    "# interface where the Xauth/IPsec traffic arrived will overwrite the special"
                    "\n"
                )
                self.out_file.write(
                    "    # mark we using for our pseudo/virtual interface for Xauth traffic.\n"
                )
                self.out_file.write(
                    "    "
                    '${IPTABLES} -t mangle -I mark-src-intf -j ipsec-xauth-src -m comment --comment "src interface jump for Xauth"'
                    "\n"
                )
                self.out_file.write(
                    "    "
                    '${IPTABLES} -t mangle -I mark-dst-intf -j ipsec-xauth-dst -m comment --comment "dst interface jump for Xauth"'
                    "\n"
                )
                self.out_file.write("fi" + "\n")

                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    "
                    "# insert nat-reverse-filter rule to allow Xauth to penetrate NATd networks"
                    "\n"
                )
                self.out_file.write(
                    "    "
                    '${IPTABLES} -t filter -I nat-reverse-filter -m mark --mark 0xfc/0xff -j RETURN -m comment --comment "Allow Xauth"'
                    "\n"
                )
                self.out_file.write("fi" + "\n")

                self.out_file.write("# create WAN NAT rules for Xauth traffic" + "\n")
                for interface_id in NetworkUtil.wan_list():
                    self.out_file.write(
                        "${IPTABLES} -t nat -D nat-rules -m mark --mark 0x"
                        + (hex((interface_id << 8) + 0x00FC)[2:])
                        + "/0xffff "
                        + '-j MASQUERADE -m comment --comment "NAT WAN-bound XAUTH traffic" >/dev/null 2>&1'
                        + "\n"
                    )

                    self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                    self.out_file.write(
                        "    "
                        "${IPTABLES} -t nat -I nat-rules -m mark --mark 0x"
                        + (hex((interface_id << 8) + 0x00FC)[2:])
                        + "/0xffff "
                        + '-j MASQUERADE -m comment --comment "NAT WAN-bound XAUTH traffic"'
                        + "\n"
                    )
                    self.out_file.write("fi" + "\n")
                self.out_file.write("\n")
        except Exception:
            logger.exception("Unable to write script:")
        finally:
            try:
                if self.out_file is not None:
                    self.out_file.flush()
                    self.out_file.close()
            except Exception:
                logger.exception("Unable to close script:")

        os.chmod(self.out_file_name, os.stat(self.out_file_name).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(self.out_file_name))

    def write_GRE_script(self, settings, prefix) -> None:
        """
        Write ipsec GRE iptables configuration
        """
        first_ip = str(
            ipaddress.IPv4Network(settings.get("virtualNetworkPool")).network_address + 1
        )
        https_port = str(NetworkUtil.settings.get("httpsPort"))
        http_port = str(NetworkUtil.settings.get("httpPort"))

        self.out_file_name = prefix + self.ipsec_gre_script
        self.out_file_dir = os.path.dirname(self.out_file_name)
        if not os.path.exists(self.out_file_dir):
            os.makedirs(self.out_file_dir)

        try:
            self.out_file = open(self.out_file_name, "w+")

            self.out_file.write("#!/bin/dash\n\n")
            self.out_file.write("# " + self.out_file_name + "\n")
            self.out_file.write(
                "# This file is created and maintained by the Untangle IPsec service.\n"
            )
            self.out_file.write(
                "# If you modify this file manually, your changes will be overwritten!\n\n"
            )

            self.out_file.write('if [ -z "$IPTABLES" ] ; then IPTABLES=iptables ; fi' + "\n\n")

            # Determine if ipsec is enabled, 0 for true and false for the rest of return codes
            self.out_file.write(
                "IPSEC_STATUS=$(systemctl status ipsec >/dev/null 2>&1; echo $?)" + "\n"
            )

            self.out_file.write(
                "# delete all existing gre interfaces except 0 which is hidden and protected\n"
            )
            self.out_file.write(
                "GRECOUNT=`cat /proc/net/dev | grep -v gre0 | grep gre | wc -l`" + "\n"
            )
            self.out_file.write("for i in `seq 1 $GRECOUNT` ; do" + "\n")
            self.out_file.write(
                "\t"
                '${IPTABLES} -t mangle -D mark-src-intf -i gre$i -j MARK --set-mark 0xfd/0xff -m comment --comment "Set src interface mark for GRE" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write(
                "\t"
                '${IPTABLES} -t mangle -D mark-dst-intf -o gre$i -j MARK --set-mark 0xfd00/0xff00 -m comment --comment "Set dst interface mark for GRE" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write("\t" + "ip tunnel del gre$i" + "\n")
            self.out_file.write("done" + "\n")
            self.out_file.write("\n")

            self.out_file.write("# delete all of the old WAN NAT rules" + "\n")
            for interface_id in NetworkUtil.wan_list():
                self.out_file.write(
                    "${IPTABLES} -t nat -D nat-rules -m mark --mark 0x"
                    + (hex((interface_id << 8) + 0x00FD)[2:])
                    + "/0xffff "
                    + '-j MASQUERADE -m comment --comment "NAT WAN-bound GRE traffic" >/dev/null 2>&1'
                    + "\n"
                )
            self.out_file.write("\n")

            self.out_file.write("# delete the old nat-reverse-filter rule" + "\n")
            self.out_file.write(
                '${IPTABLES} -t filter -D nat-reverse-filter -m mark --mark 0xfd/0xff -j RETURN -m comment --comment "Allow GRE" >/dev/null 2>&1'
                "\n"
            )
            self.out_file.write("\n")

            self.out_file.write("# delete the old admin forwards for GRE networks" + "\n")
            self.out_file.write(
                "${IPTABLES} -t nat -D port-forward-rules -p tcp -d "
                + first_ip
                + " --destination-port "
                + https_port
                + ' -j REDIRECT --to-ports 443 -m comment --comment "Send GRE to apache" >/dev/null 2>&1'
                + "\n"
            )
            self.out_file.write(
                "${IPTABLES} -t nat -D port-forward-rules -p tcp -d "
                + first_ip
                + " --destination-port "
                + http_port
                + ' -j REDIRECT --to-ports 80 -m comment --comment "Send GRE to apache" >/dev/null 2>&1'
                + "\n"
            )
            self.out_file.write("\n")

            for i in range(len(settings.get("networks"))):
                network = settings.get("networks")[i]
                if not bool(network.get("active")):
                    continue
                offset = i + 1
                iface = "gre" + str(offset)
                base_ip = ipaddress.ip_network(
                    settings.get("virtualNetworkPool"), strict=False
                ).network_address
                iaddr = str(ipaddress.ip_address(int(base_ip) + offset))

                self.out_file.write("# IpsecVpnNetwork - " + network.get("description") + "\n")
                self.out_file.write(
                    "ip tunnel add "
                    + iface
                    + " mode gre remote "
                    + network.get("remoteAddress")
                    + " local "
                    + network.get("localAddress")
                    + " ttl "
                    + str(network.get("ttl"))
                    + "\n"
                )
                self.out_file.write(
                    "ip link set " + iface + " mtu " + str(network.get("mtu")) + "\n"
                )
                self.out_file.write("ip link set " + iface + " up" + "\n")
                self.out_file.write("ip addr add " + iaddr + "/30 dev " + iface + "\n")

                net_list = network.get("remoteNetworks").split("\\n")

                for j in range(len(net_list)):
                    if len(net_list[j].strip()) == 0:
                        continue
                    self.out_file.write("ip route add " + net_list[j] + " dev " + iface + "\n")
                self.out_file.write(
                    "${IPTABLES} -t mangle -D mark-src-intf 4 -i "
                    + iface
                    + ' -j MARK --set-mark 0xfd/0xff -m comment --comment "Set src interface mark for GRE" >/dev/null 2>&1'
                    + "\n"
                )
                self.out_file.write(
                    "${IPTABLES} -t mangle -D mark-dst-intf 4 -o "
                    + iface
                    + ' -j MARK --set-mark 0xfd00/0xff00 -m comment --comment "Set dst interface mark for GRE" >/dev/null 2>&1'
                    + "\n"
                )

                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t mangle -I mark-src-intf 4 -i "
                    + iface
                    + ' -j MARK --set-mark 0xfd/0xff -m comment --comment "Set src interface mark for GRE"'
                    + "\n"
                )
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t mangle -I mark-dst-intf 4 -o "
                    + iface
                    + ' -j MARK --set-mark 0xfd00/0xff00 -m comment --comment "Set dst interface mark for GRE"'
                    + "\n"
                )
                self.out_file.write("fi" + "\n")

                self.out_file.write("\n")

            self.out_file.write("# create WAN NAT rules for each GRE interface" + "\n")
            for interface_id in NetworkUtil.wan_list():
                self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
                self.out_file.write(
                    "    "
                    "${IPTABLES} -t nat -I nat-rules -m mark --mark 0x"
                    + (hex((interface_id << 8) + 0x00FD)[2:])
                    + "/0xffff "
                    + '-j MASQUERADE -m comment --comment "NAT WAN-bound GRE traffic"'
                    + "\n"
                )
                self.out_file.write("fi" + "\n")
            self.out_file.write("\n")

            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write(
                "    # create nat-reverse-filter rule to allow GRE to penetrate NATd networks\n"
            )
            self.out_file.write(
                "    "
                '${IPTABLES} -t filter -I nat-reverse-filter -m mark --mark 0xfd/0xff -j RETURN -m comment --comment "Allow GRE"'
                "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write("\n")

            self.out_file.write('if [ "$IPSEC_STATUS" -eq "0" ]; then' + "\n")
            self.out_file.write("    " + "# create admin forwards for GRE networks" + "\n")
            self.out_file.write(
                "    "
                "${IPTABLES} -t nat -I port-forward-rules -p tcp -d "
                + first_ip
                + " --destination-port "
                + https_port
                + ' -j REDIRECT --to-ports 443 -m comment --comment "Send GRE to apache"'
                + "\n"
            )
            self.out_file.write(
                "    "
                "${IPTABLES} -t nat -I port-forward-rules -p tcp -d "
                + first_ip
                + " --destination-port "
                + http_port
                + ' -j REDIRECT --to-ports 80 -m comment --comment "Send GRE to apache"'
                + "\n"
            )
            self.out_file.write("fi" + "\n")

            self.out_file.write("\n")
        except Exception:
            logger.exception("Unable to write script:")
        finally:
            try:
                if self.out_file is not None:
                    self.out_file.flush()
                    self.out_file.close()
            except Exception:
                logger.exception("Unable to close script:")

        os.chmod(self.out_file_name, os.stat(self.out_file_name).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(self.out_file_name))


registrar.register_manager(IPsecManager())
