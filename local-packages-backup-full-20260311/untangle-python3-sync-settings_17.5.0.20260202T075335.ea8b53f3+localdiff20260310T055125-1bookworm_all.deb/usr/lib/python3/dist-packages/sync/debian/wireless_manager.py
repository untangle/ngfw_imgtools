import os
import re
import subprocess
import sys

from sync import Manager, registrar
from sync.common import Logger

# This class is responsible for writing /etc/network/interfaces
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class WirelessManager(Manager):
    wpasupplicant_conf_filename = "/etc/wpa_supplicant/wpa_supplicant.conf"
    hostapd_conf_filename = "/etc/hostapd/hostapd.conf"
    crda_default_filename = "/etc/default/crda"

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_file(
            self.wpasupplicant_conf_filename + ".*", "restart-networking", self
        )
        registrar.register_file(self.hostapd_conf_filename + ".*", "restart-networking", self)
        registrar.register_file(self.crda_default_filename, "restart-networking", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        # on Asus AC88U, find each disabled wifi interface, and remove
        # its corresponding hostapd configuration file if it
        # exists. untangle-broadcom-wireless relies solely on the
        # presence of that file to decide whether to start the AP
        # daemon or not (#13066)
        enabledInterfaces = [x["physicalDev"] for x in settings_file.settings.get("interfaces")]
        for intfName in [x for x in ("eth1", "eth2") if x not in enabledInterfaces]:
            filename = prefix + self.hostapd_conf_filename + "-" + intfName
            if os.path.exists(filename):
                delete_list.append(filename)

        self.write_wpasupplicant_conf(settings_file.settings, prefix)
        self.write_hostapd_conf(settings_file.settings, prefix)
        self.write_crda_file(settings_file.settings, prefix)

        # 14.0 delete obsolete file (can be removed in 14.1)
        delete_list.append("/etc/untangle/pre-network-hook.d/990-restart-hostapd")

    # Much of the ht_capab and vht_capab logic shamelessly copied from openwrt:
    # https://dev.openwrt.org/browser/trunk/package/kernel/mac80211/files/lib/netifd/wireless/mac80211.sh
    # https://dev.openwrt.org/browser/trunk/package/kernel/mac80211/files/lib/wifi/mac80211.sh

    def get_iw_info(self, phy_dev):
        output = subprocess.Popen(
            (f"iw phy {phy_dev} info").split(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT
        ).communicate()[0]
        return output.decode("ascii").split("\n")

    def set_hw_mode(self, conf, channel) -> None:
        if channel > 11 or channel == -2:
            conf["hw_mode"] = "a"
        else:
            conf["hw_mode"] = "g"

    def set_fallback_ht_capab(self, conf, channel) -> None:
        ht_capabs = []
        if channel > 11 or channel == -2:
            if ((channel // 4) % 2) == 0:
                ht_capabs.append("[HT40-]")
            if ((channel // 4) % 2) == 1:
                ht_capabs.append("[HT40+]")
        elif channel < 7:
            ht_capabs.append("[HT40+]")
        else:
            ht_capabs.append("[HT40-]")

        ht_capabs.append("[SHORT-GI-40]")
        ht_capabs.append("[TX-STBC]")
        ht_capabs.append("[RX-STBC1]")
        ht_capabs.append("[DSSS_CCK-40]")
        conf["ht_capab"] = "".join(map(str, ht_capabs))

    def set_ht_capab(self, conf, iw_info, channel, wlan_dev):
        # NGFW-13922 The realtek driver on the w4 reports different capabilities for Bands 1 and 2
        # Our previous logic always used the first Capabilities value in the iw info output. This created
        # an invalid ht_capab configuration line in 802.11ac mode which prevents the driver from loading.
        # Solution is to parse both Capabilities lines and use the correct one based on the channel.
        # We assume that Band 1 = Channels 1-14 and Band 2 = everything else.
        capab_line = []
        for line in iw_info:
            if re.search(r"\s*Capabilities:\s.*", line):
                capab_line.append(line)

        if len(capab_line) == 0:
            logger.warning("Unable to determine capabilities: %s", str(wlan_dev))
            return set_fallback_ht_capab(conf, channel)

        line = capab_line[0]
        if (channel < 1 or channel > 14) and len(capab_line) > 1:
            line = capab_line[1]

        segments = line.split()
        if len(segments) != 2:
            logger.warning("Unknown capabilities: %s", str(line))
            return set_fallback_ht_capab(conf, channel)
        capab_int = None
        try:
            capab_int = int(segments[1], 16)
        except Exception:
            logger.exception("Unknown capabilities: %s", str(line))
            return set_fallback_ht_capab(conf, channel)

        ht_capabs = []
        if channel > 11 or channel == -2:
            if ((channel // 4) % 2) == 0:
                ht_capabs.append("[HT40-]")
            if ((channel // 4) % 2) == 1:
                ht_capabs.append("[HT40+]")
        elif channel < 7:
            ht_capabs.append("[HT40+]")
        else:
            ht_capabs.append("[HT40-]")
        if (capab_int & 0x1) == 0x1:
            ht_capabs.append("[LDPC]")
        if (capab_int & 0x10) == 0x10:
            ht_capabs.append("[GF]")
        if (capab_int & 0x20) == 0x20:
            ht_capabs.append("[SHORT-GI-20]")
        if (capab_int & 0x40) == 0x40:
            ht_capabs.append("[SHORT-GI-40]")
        if (capab_int & 0x80) == 0x80:
            ht_capabs.append("[TX-STBC]")
        if (capab_int & 0x300) == 0x100:
            ht_capabs.append("[RX-STBC1]")
        if (capab_int & 0x300) == 0x200:
            ht_capabs.append("[RX-STBC12]")
        if (capab_int & 0x300) == 0x300:
            ht_capabs.append("[RX-STBC123]")
        if (capab_int & 0x800) == 0x800:
            ht_capabs.append("[MAX-AMSDU-7935]")
        if (capab_int & 0x1000) == 0x1000:
            ht_capabs.append("[DSSS_CCK-40]")
        conf["ht_capab"] = "".join(map(str, ht_capabs))
        return None

    def set_80211n(self, conf) -> None:
        conf["ieee80211n"] = 1
        conf["wmm_enabled"] = 1

    def set_80211ac(self, conf) -> None:
        conf["ieee80211ac"] = 1

    def set_vht(self, conf) -> None:
        # assume VHT40h
        # need some user options for VHT80
        conf["vht_oper_chwidth"] = 0

    def set_vht_capab(self, conf, iw_info, channel, wlan_dev):
        capab_line = None
        for line in iw_info:
            if re.search(r"\s*VHT Capabilities\s.*", line):
                capab_line = line
                break

        if capab_line is None:
            logger.warning("Unable to determine VHT capabilities: %s", str(wlan_dev))
            return set_fallback_ht_capab(conf, channel)

        segments = line.split()
        if len(segments) != 3:
            logger.warning("Unknown VHT capabilities: %s", str(line))
            return set_fallback_ht_capab(conf, channel)
        capab_str = segments[2]
        capab_str = re.sub(r"[\(\):]", "", capab_str)
        capab_int = None
        try:
            capab_int = int(capab_str, 16)
        except Exception:
            logger.exception("Unknown VHT capabilities: %s", str(line))
            return set_fallback_ht_capab(conf, channel)

        ht_capabs = []
        if (capab_int & 0x10) == 0x10:
            ht_capabs.append("[RXLDPC]")
        if (capab_int & 0x20) == 0x20:
            ht_capabs.append("[SHORT-GI-80]")
        if (capab_int & 0x40) == 0x40:
            ht_capabs.append("[SHORT-GI-160]")
        if (capab_int & 0x80) == 0x80:
            ht_capabs.append("[TX-STBC-2BY1]")
        if (capab_int & 0x800) == 0x800:
            ht_capabs.append("[SU-BEAMFORMER]")
        if (capab_int & 0x1000) == 0x1000:
            ht_capabs.append("[SU-BEAMFORMEE]")
        if (capab_int & 0x80000) == 0x80000:
            ht_capabs.append("[MU-BEAMFORMER]")
        if (capab_int & 0x100000) == 0x100000:
            ht_capabs.append("[MU-BEAMFORMEE]")
        if (capab_int & 0x200000) == 0x200000:
            ht_capabs.append("[VHT-TXOP-PS]")
        if (capab_int & 0x400000) == 0x400000:
            ht_capabs.append("[HTC-VHT]")
        if (capab_int & 0x10000000) == 0x10000000:
            ht_capabs.append("[RX-ANTENNA-PATTERN]")
        if (capab_int & 0x20000000) == 0x20000000:
            ht_capabs.append("[TX-ANTENNA-PATTERN]")
        if (capab_int & 0x700) == 0x100:
            ht_capabs.append("[RX-STBC1]")
        if (capab_int & 0x700) == 0x200:
            ht_capabs.append("[RX-STBC12]")
        if (capab_int & 0x700) == 0x300:
            ht_capabs.append("[RX-STBC123]")
        if (capab_int & 0x700) == 0x400:
            ht_capabs.append("[RX-STBC1234]")
        conf["vht_capab"] = "".join(map(str, ht_capabs))
        return None

    def find_string(self, iw_info, regex) -> bool:
        return any(re.search(regex, line) for line in iw_info)

    def supports_80211ac(self, channel, iw_info) -> bool:
        # if a 2.4 channel is chosen - then its 2.4 which does not support AC
        if channel > 0 and channel <= 11:
            return False
        # channel -1 means 2.4 auto
        if channel == -1:
            return False
        if not self.find_string(iw_info, r"\s*VHT Capabilities.*"):
            return False
        return self.find_string(iw_info, r"\s*Band 2.*")

    def get_wificard_config(self, wlan_dev, channel):
        try:
            conf = {}
            phy_dev = open(f"/sys/class/net/{wlan_dev}/phy80211/name").read()
            iw_info = self.get_iw_info(phy_dev)

            self.set_hw_mode(conf, channel)
            self.set_80211n(conf)
            self.set_ht_capab(conf, iw_info, channel, wlan_dev)

            if self.supports_80211ac(channel, iw_info):
                self.set_80211ac(conf)
                self.set_vht(conf)
                self.set_vht_capab(conf, iw_info, channel, wlan_dev)

            return conf
        except Exception:
            logger.exception("Unexpected error: %s", str(sys.exc_info()[0]))
            return None

    def write_hostapd_conf(self, settings, prefix="") -> None:
        configFilename = prefix + self.hostapd_conf_filename
        for filename in [configFilename]:
            file_dir = os.path.dirname(filename)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)

        interfaces = settings.get("interfaces")

        for intf in interfaces:
            if intf.get("isWirelessInterface") and intf.get("wirelessMode") == "AP":
                passwordLen = 0
                if intf.get("wirelessPassword") is not None:
                    passwordLen = len(intf.get("wirelessPassword"))
                if passwordLen < 8:
                    logger.info(
                        "Ignoring %s because password is too short (%s)",
                        str(intf.get("systemDev")),
                        str(passwordLen),
                    )
                    continue

                filename = configFilename + "-" + intf.get("systemDev")
                self.hostapdConfFile = open(filename, "w+")

                self.hostapdConfFile.write("## Auto Generated\n")
                self.hostapdConfFile.write("## DO NOT EDIT. Changes will be overwritten.\n")
                self.hostapdConfFile.write("\n\n")
                # -1 refers logging all wifi modules
                self.hostapdConfFile.write("logger_syslog=-1\n")
                # Default loglevel is informational
                log_level = 2
                if intf.get("wirelessLogLevel") is not None:
                    log_level = intf.get("wirelessLogLevel")
                self.hostapdConfFile.write(f"logger_syslog_level={log_level}\n")
                self.hostapdConfFile.write("interface={}\n".format(intf.get("systemDev")))
                self.hostapdConfFile.write("ssid={}\n".format(intf.get("wirelessSsid")))
                country_code = intf.get("wirelessCountryCode")
                if country_code is None or country_code == "":
                    country_code = "US"
                self.hostapdConfFile.write(f"country_code={country_code}\n")
                self.hostapdConfFile.write("max_num_sta=255\n")
                self.hostapdConfFile.write("auth_algs=1\n")
                if intf.get("wirelessVisibility") is not None:
                    self.hostapdConfFile.write(
                        "ignore_broadcast_ssid=%u\n" % intf.get("wirelessVisibility")
                    )
                else:
                    self.hostapdConfFile.write("ignore_broadcast_ssid=0\n")

                channel = intf.get("wirelessChannel")

                # Channel will be -1 for 2.4 GHz Auto and -2 for 5 GHz Auto
                # hostapd expect the channel to be 0 for auto channel selection
                channel = max(channel, 0)

                self.hostapdConfFile.write("channel=%u\n" % channel)
                if intf.get("wirelessEncryption") == "NONE":
                    self.hostapdConfFile.write("wpa=0\n")
                elif intf.get("wirelessEncryption") == "WPA1":
                    self.hostapdConfFile.write("wpa=1\n")
                    self.hostapdConfFile.write(
                        "wpa_passphrase={}\n".format(intf.get("wirelessPassword"))
                    )
                    self.hostapdConfFile.write("wpa_key_mgmt=WPA-PSK\n")
                    self.hostapdConfFile.write("wpa_pairwise=TKIP\n")
                    self.hostapdConfFile.write("rsn_pairwise=CCMP\n")
                elif intf.get("wirelessEncryption") == "WPA12":
                    self.hostapdConfFile.write("wpa=3\n")
                    self.hostapdConfFile.write(
                        "wpa_passphrase={}\n".format(intf.get("wirelessPassword"))
                    )
                    self.hostapdConfFile.write("wpa_key_mgmt=WPA-PSK\n")
                    self.hostapdConfFile.write("wpa_pairwise=TKIP\n")
                    self.hostapdConfFile.write("rsn_pairwise=CCMP\n")
                elif intf.get("wirelessEncryption") == "WPA2":
                    self.hostapdConfFile.write("wpa=2\n")
                    self.hostapdConfFile.write(
                        "wpa_passphrase={}\n".format(intf.get("wirelessPassword"))
                    )
                    self.hostapdConfFile.write("wpa_key_mgmt=WPA-PSK\n")
                    self.hostapdConfFile.write("wpa_pairwise=TKIP\n")
                    self.hostapdConfFile.write("rsn_pairwise=CCMP\n")

                # build the card specific hostapd config
                conf = self.get_wificard_config(intf.get("systemDev"), intf.get("wirelessChannel"))
                if conf is not None:
                    for key, value in sorted(conf.items()):
                        self.hostapdConfFile.write(f"{key!s}={value!s}\n")

                self.hostapdConfFile.flush()
                self.hostapdConfFile.close()

                logger.info("Wrote %s", str(filename))

    def write_wpasupplicant_conf(self, settings, prefix="") -> None:
        configFilename = prefix + self.wpasupplicant_conf_filename
        for filename in [configFilename]:
            fileDir = os.path.dirname(filename)
            if not os.path.exists(fileDir):
                os.makedirs(fileDir)

        interfaces = settings.get("interfaces")

        for intf in interfaces:
            if intf.get("isWirelessInterface") and intf.get("wirelessMode") == "CLIENT":
                passwordLen = 0
                if intf.get("wirelessPassword") is not None:
                    passwordLen = len(intf.get("wirelessPassword"))
                if passwordLen < 8:
                    logger.info(
                        "Ignoring %s because password is too short (%s)",
                        str(intf.get("systemDev")),
                        str(passwordLen),
                    )
                    continue

                filename = configFilename + "-" + intf.get("systemDev")
                self.wpasupplicantConfFile = open(filename, "w+")

                self.wpasupplicantConfFile.write("## Auto Generated\n")
                self.wpasupplicantConfFile.write("## DO NOT EDIT. Changes will be overwritten.\n")
                self.wpasupplicantConfFile.write("\n\n")
                self.wpasupplicantConfFile.write("ctrl_interface=/run/wpa_supplicant\n")
                self.wpasupplicantConfFile.write("update_config=1\n")
                self.wpasupplicantConfFile.write("network={\n")
                self.wpasupplicantConfFile.write('\tssid="{}"\n'.format(intf.get("wirelessSsid")))

                if intf.get("wirelessEncryption") == "NONE":
                    self.wpasupplicantConfFile.write("\tkey_mgmt=NONE\n")
                elif intf.get("wirelessEncryption") == "WPA1":
                    self.wpasupplicantConfFile.write("\tproto=WPA\n")
                    self.wpasupplicantConfFile.write("\tkey_mgmt=WPA-PSK\n")
                    self.wpasupplicantConfFile.write("\tpairwise=TKIP CCMP\n")
                    self.wpasupplicantConfFile.write("\tgroup=TKIP CCMP\n")
                    self.wpasupplicantConfFile.write(
                        '\tpsk="{}"\n'.format(intf.get("wirelessPassword"))
                    )
                elif intf.get("wirelessEncryption") == "WPA12":
                    self.wpasupplicantConfFile.write("\tproto=WPA RSN\n")
                    self.wpasupplicantConfFile.write("\tkey_mgmt=WPA-PSK\n")
                    self.wpasupplicantConfFile.write("\tpairwise=TKIP CCMP\n")
                    self.wpasupplicantConfFile.write("\tgroup=TKIP CCMP\n")
                    self.wpasupplicantConfFile.write(
                        '\tpsk="{}"\n'.format(intf.get("wirelessPassword"))
                    )
                elif intf.get("wirelessEncryption") == "WPA2":
                    self.wpasupplicantConfFile.write("\tproto=RSN\n")
                    self.wpasupplicantConfFile.write("\tkey_mgmt=WPA-PSK\n")
                    self.wpasupplicantConfFile.write("\tpairwise=TKIP CCMP\n")
                    self.wpasupplicantConfFile.write("\tgroup=TKIP CCMP\n")
                    self.wpasupplicantConfFile.write(
                        '\tpsk="{}"\n'.format(intf.get("wirelessPassword"))
                    )

                self.wpasupplicantConfFile.write("}\n")

                self.wpasupplicantConfFile.flush()
                self.wpasupplicantConfFile.close()

                logger.info("Wrote %s", str(filename))

    def write_crda_file(self, settings, prefix="") -> None:
        crdaFilename = prefix + self.crda_default_filename
        for filename in [crdaFilename]:
            file_dir = os.path.dirname(filename)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)

        # Get the globalwide country code
        country_code = None
        interfaces = settings.get("interfaces")
        for intf in interfaces:
            if intf.get("isWirelessInterface") and intf.get("wirelessMode") == "AP":
                country_code = intf.get("wirelessCountryCode")
                break
        if country_code is None or country_code == "":
            # Default to US
            country_code = "US"

        self.crdaDefaultFile = open(crdaFilename, "w+")
        self.crdaDefaultFile.write("## Auto Generated\n")
        self.crdaDefaultFile.write("## DO NOT EDIT. Changes will be overwritten.\n")
        self.crdaDefaultFile.write(f"REGDOMAIN={country_code}\n")
        self.crdaDefaultFile.flush()
        self.crdaDefaultFile.close()

        logger.info("Wrote %s", str(crdaFilename))


registrar.register_manager(WirelessManager())
