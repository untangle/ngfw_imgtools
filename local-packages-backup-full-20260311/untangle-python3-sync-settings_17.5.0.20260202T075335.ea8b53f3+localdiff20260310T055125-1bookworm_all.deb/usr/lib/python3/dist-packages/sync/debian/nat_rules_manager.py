import os
import traceback

from sync import Manager, registrar
from sync.common import Logger
from sync.iptables_util import IptablesUtil
from sync.network_util import NetworkUtil

# This class is responsible for writing /etc/untangle/iptables-rules.d/220-nat-rules
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class NatRulesManager(Manager):
    interfaces_mark_mask = 0x0000FFFF
    lxc_mark_mask = 0x04000000

    iptables_filename = "/etc/untangle/iptables-rules.d/220-nat-rules"
    filename = iptables_filename
    file = None

    # wireguard has nat rules that don't fit in the normal nat rules paradigm, so they go in their own file
    wireguard_iptables_filename = "/etc/untangle/iptables-rules.d/721-wireguard-nat-rules"
    wireguard_filename = wireguard_iptables_filename
    wireguard_file = None
    wireguard_commands = []

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_file(self.iptables_filename, "restart-iptables", self)
        registrar.register_file(self.wireguard_iptables_filename, "restart-iptables", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        self.write_nat_rules_file(settings_file.settings, prefix)

    def write_nat_rule(self, nat_rule, prefix="") -> None:
        if "enabled" in nat_rule and not nat_rule["enabled"]:
            return
        if "conditions" not in nat_rule:
            return
        if "ruleId" not in nat_rule:
            return

        if nat_rule.get("auto"):
            target = " -j MASQUERADE "
        elif "newSource" in nat_rule:
            target = " -j SNAT --to-source {} ".format(str(nat_rule["newSource"]))
        else:
            logger.error("invalid nat target: %s" + str(nat_rule))
            return

        description = "NAT Rule #%i" % int(nat_rule["ruleId"])
        commands = IptablesUtil.conditions_to_prep_commands(nat_rule["conditions"], description)
        iptables_conditions = IptablesUtil.conditions_to_iptables_string(
            nat_rule["conditions"], description, is_nat_rules=True
        )
        commands += [
            "${IPTABLES} -t nat -A nat-rules " + ipt + target for ipt in iptables_conditions
        ]
        self.wireguard_commands = self.wireguard_commands + IptablesUtil.commands_for_wireguard(
            nat_rule["conditions"]
        )

        self.file.write(f"# {description}\n")
        for cmd in commands:
            self.file.write(cmd + "\n")
        self.file.write("\n")

        return

    def interfaces_in_same_bridge_group(self, intf1, intf2) -> bool:
        if intf2["configType"] == "BRIDGED" and intf2["bridgedTo"] == intf1["interfaceId"]:
            return True
        if intf1["configType"] == "BRIDGED" and intf1["bridgedTo"] == intf2["interfaceId"]:
            return True
        return bool(
            intf1["configType"] == "BRIDGED"
            and intf2["configType"] == "BRIDGED"
            and intf1["bridgedTo"] == intf2["bridgedTo"]
        )

    def write_nat_rules(self, settings, prefix="") -> None:
        if settings is None or "natRules" not in settings:
            logger.error("Missing NAT Rules")
            return

        nat_rules = settings["natRules"]

        for nat_rule in nat_rules:
            try:
                self.write_nat_rule(nat_rule, prefix)
            except Exception:
                traceback.print_exc()

        # write out any wireguard nat rules to own file
        if len(self.wireguard_commands) > 0:
            self.wireguard_commands = [
                'if [ -z "$IPTABLES" ] ; then IPTABLES=/sbin/iptables ; fi',
                "",
                *self.wireguard_commands,
            ]
            for cmd in self.wireguard_commands:
                self.wireguard_file.write(cmd + "\n")

    def write_ingress_nat_rules(self, intf, interfaces) -> None:
        for other_intf in interfaces:
            # skip self
            if other_intf["interfaceId"] == intf["interfaceId"]:
                continue
            # skip interfaces in same zone
            if self.interfaces_in_same_bridge_group(intf, other_intf):
                continue

            self.file.write(
                "# NAT ingress traffic coming from interface {}".format(str(intf["interfaceId"]))
                + "\n"
            )
            self.file.write(
                '${IPTABLES} -t nat -A nat-rules -m connmark --mark 0x%0.4X/0xffff -m comment --comment "NAT traffic, %i -> %i (ingress setting)" -j MASQUERADE'
                % (
                    ((other_intf["interfaceId"] << 8) + intf["interfaceId"]),
                    intf["interfaceId"],
                    other_intf["interfaceId"],
                )
            )
            self.file.write("\n\n")

            self.file.write("# block traffic to NATd interface %i" % intf["interfaceId"] + "\n")
            # write a log rule before each block rule so we log every drop
            self.file.write(
                "${IPTABLES} -t filter -A nat-reverse-filter -m connmark --mark 0x%0.4X/0xffff -m comment --comment \"Block traffic to NATd interace, %i -> %i (ingress setting)\" -j NFLOG --nflog-prefix 'nat_blocked'"
                % (
                    ((intf["interfaceId"] << 8) + other_intf["interfaceId"]),
                    other_intf["interfaceId"],
                    intf["interfaceId"],
                )
            )
            self.file.write("\n")
            self.file.write(
                '${IPTABLES} -t filter -A nat-reverse-filter -m connmark --mark 0x%0.4X/0xffff -m comment --comment "Block traffic to NATd interace, %i -> %i (ingress setting)" -j REJECT'
                % (
                    ((intf["interfaceId"] << 8) + other_intf["interfaceId"]),
                    other_intf["interfaceId"],
                    intf["interfaceId"],
                )
            )
            self.file.write("\n\n")

    def write_egress_nat_rules(self, intf, interfaces) -> None:
        for other_intf in interfaces:
            # skip self
            if other_intf["interfaceId"] == intf["interfaceId"]:
                continue
            # skip interfaces in same zone
            if self.interfaces_in_same_bridge_group(intf, other_intf):
                continue

            self.file.write(
                "# NAT egress traffic exiting interface {}".format(str(intf["interfaceId"])) + "\n"
            )
            self.file.write(
                '${IPTABLES} -t nat -A nat-rules -m connmark --mark 0x%0.4X/0xffff -m comment --comment "NAT traffic, %i -> %i (egress setting)" -j MASQUERADE'
                % (
                    ((intf["interfaceId"] << 8) + other_intf["interfaceId"]),
                    other_intf["interfaceId"],
                    intf["interfaceId"],
                )
            )
            self.file.write("\n\n")

            self.file.write(
                "# block traffic from NATd interface {}".format(intf["interfaceId"]) + "\n"
            )
            self.file.write(
                "${IPTABLES} -t filter -A nat-reverse-filter -m connmark --mark 0x%0.4X/0xffff -m comment --comment \"Block traffic to NATd interace, %i -> %i (egress setting)\" -j NFLOG --nflog-prefix 'filter_blocked: ' "
                % (
                    ((other_intf["interfaceId"] << 8) + intf["interfaceId"]),
                    intf["interfaceId"],
                    other_intf["interfaceId"],
                )
            )
            self.file.write("\n")
            self.file.write(
                '${IPTABLES} -t filter -A nat-reverse-filter -m connmark --mark 0x%0.4X/0xffff -m comment --comment "Block traffic to NATd interace, %i -> %i (egress setting)" -j REJECT'
                % (
                    ((other_intf["interfaceId"] << 8) + intf["interfaceId"]),
                    intf["interfaceId"],
                    other_intf["interfaceId"],
                )
            )
            self.file.write("\n\n")

    def write_interface_nat_options(self, settings) -> None:
        interfaces = settings["interfaces"]
        for interface_settings in interfaces:
            if interface_settings.get("v4NatEgressTraffic"):
                self.write_egress_nat_rules(interface_settings, interfaces)
                # Find all interfaces bridged to this one
                for other_intf in interfaces:
                    if other_intf["interfaceId"] == interface_settings["interfaceId"]:
                        continue
                    if other_intf["configType"] != "BRIDGED":
                        continue
                    if other_intf["bridgedTo"] != interface_settings["interfaceId"]:
                        continue
                    self.write_egress_nat_rules(other_intf, interfaces)

            if interface_settings.get("v4NatIngressTraffic"):
                self.write_ingress_nat_rules(interface_settings, interfaces)
                # Find all interfaces bridged to this one
                for other_intf in interfaces:
                    if other_intf["interfaceId"] == interface_settings["interfaceId"]:
                        continue
                    if other_intf["configType"] != "BRIDGED":
                        continue
                    if other_intf["bridgedTo"] != interface_settings["interfaceId"]:
                        continue
                    self.write_ingress_nat_rules(other_intf, interfaces)

    def write_implicit_nat_rules(self, settings) -> None:
        self.file.write("# Implicit NAT Rule (hairpin for port forwards)" + "\n")
        for intfId in NetworkUtil.interface_list():
            self.file.write(
                f'${{IPTABLES}} -t nat -A nat-rules -m conntrack --ctstate DNAT -m connmark --mark 0x{intfId + (intfId << 8):X}/0x{self.interfaces_mark_mask:X} -j MASQUERADE -m comment --comment "NAT all port forwards (hairpin) (interface {intfId!s})"'
                "\n"
            )
        self.file.write("\n")

    def write_lxc_nat_rules(self, settings) -> None:
        self.file.write("# LXC NAT Rule" + "\n")
        self.file.write(
            f'${{IPTABLES}} -t nat -A nat-rules -m connmark --mark 0x{self.lxc_mark_mask:X}/0x{self.lxc_mark_mask:X} -j MASQUERADE -m comment --comment "NAT all LXC sessions"'
            "\n"
        )
        self.file.write("\n")

    def write_nat_rules_file(self, settings, prefix="") -> None:
        self.filename = prefix + self.iptables_filename
        self.file_dir = os.path.dirname(self.filename)
        if not os.path.exists(self.file_dir):
            os.makedirs(self.file_dir)

        self.file = open(self.filename, "w+")
        self.file.write("## Auto Generated\n")
        self.file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        self.file.write("\n")
        self.file.write("\n")

        self.file.write("# Create (if needed) and flush nat-rules chain" + "\n")
        self.file.write("${IPTABLES} -t nat -N nat-rules 2>/dev/null" + "\n")
        self.file.write("${IPTABLES} -t nat -F nat-rules >/dev/null 2>&1" + "\n")
        self.file.write("\n")

        self.file.write("# Call nat-rules chain from POSTROUTING chain to SNAT traffic" + "\n")
        self.file.write(
            '${IPTABLES} -t nat -D POSTROUTING -m comment --comment "SNAT rules" -j nat-rules >/dev/null 2>&1'
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t nat -A POSTROUTING -m comment --comment "SNAT rules" -j nat-rules\n'
        )
        self.file.write("\n")

        self.file.write("# Call nat-rules chain from POSTROUTING chain to SNAT traffic" + "\n")
        self.file.write(
            '${IPTABLES} -t nat -I POSTROUTING -i lo -j RETURN -m comment --comment "Never NAT loopback traffic" >/dev/null 2>&1'
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t nat -I POSTROUTING -o lo -j RETURN -m comment --comment "Never NAT loopback traffic" >/dev/null 2>&1'
            "\n"
        )
        self.file.write("\n")

        self.file.write("# Create (if needed) and flush nat-reverse-filter chain" + "\n")
        self.file.write("${IPTABLES} -t filter -N nat-reverse-filter 2>/dev/null" + "\n")
        self.file.write("${IPTABLES} -t filter -F nat-reverse-filter >/dev/null 2>&1" + "\n")
        self.file.write("\n")

        self.file.write(
            '# Call nat-reverse-filter chain from FORWARD chain to block traffic to NATd interface from "outside" '
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t filter -D FORWARD -m conntrack --ctstate NEW -m comment --comment "block traffic to NATd interfaces" -j nat-reverse-filter >/dev/null 2>&1'
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t filter -A FORWARD -m conntrack --ctstate NEW -m comment --comment "block traffic to NATd interfaces" -j nat-reverse-filter'
            "\n"
        )
        self.file.write("\n")

        self.file.write(
            '# Call nat-reverse-filter chain from FORWARD chain to block traffic to NATd interface from "outside" '
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t filter -D nat-reverse-filter -m conntrack --ctstate RELATED -m comment --comment "Allow RELATED traffic" -j RETURN >/dev/null 2>&1'
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t filter -A nat-reverse-filter -m conntrack --ctstate RELATED -m comment --comment "Allow RELATED traffic" -j RETURN'
            "\n"
        )
        self.file.write("\n")

        self.file.write(
            '# Call nat-reverse-filter chain from FORWARD chain to block traffic to NATd interface from "outside" '
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t filter -D nat-reverse-filter -m conntrack --ctstate DNAT -m comment --comment "Allow port forwarded traffic" -j RETURN >/dev/null 2>&1'
            "\n"
        )
        self.file.write(
            '${IPTABLES} -t filter -A nat-reverse-filter -m conntrack --ctstate DNAT -m comment --comment "Allow port forwarded traffic" -j RETURN'
            "\n"
        )
        self.file.write("\n")

        # separate wireguard nat file
        self.wireguard_filename = prefix + self.wireguard_iptables_filename
        self.wireguard_file_dir = os.path.dirname(self.wireguard_filename)
        if not os.path.exists(self.wireguard_file_dir):
            os.makedirs(self.wireguard_file_dir)
        self.wireguard_file = open(self.wireguard_filename, "w+")
        self.wireguard_file.write("## Auto Generated\n")
        self.wireguard_file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        self.wireguard_file.write("\n")
        self.wireguard_file.write("\n")

        self.write_nat_rules(settings, prefix)
        self.write_interface_nat_options(settings)
        self.write_implicit_nat_rules(settings)
        self.write_lxc_nat_rules(settings)

        self.file.flush()
        self.file.close()

        self.wireguard_file.flush()
        self.wireguard_file.close()

        logger.info("Wrote %s", str(self.filename))


registrar.register_manager(NatRulesManager())
