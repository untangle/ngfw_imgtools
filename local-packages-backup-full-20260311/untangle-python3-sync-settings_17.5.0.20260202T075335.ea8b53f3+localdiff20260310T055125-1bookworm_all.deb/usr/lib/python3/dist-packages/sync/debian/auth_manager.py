import glob
import os

from sync import EncryptionUtil, Manager, registrar
from sync.common import Logger

# This class is responsible for writing auth related conf files
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class AuthManager(Manager):
    # Paths for files
    chap_secrets_filename = "/etc/ppp/chap-secrets"

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_settings_file("local_directory", self)
        registrar.register_file(self.chap_secrets_filename, "noop", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """ """
        self.write_secret_files(settings_file, prefix)

    def write_secret_files(self, settings_file, prefix="") -> None:
        """
        At the moment this only writes chap-secrets

        As for why we do this intermediate file pattern, its due to two systems (PPPoE and RADIUS) depending
        on the same chap-secrets file.  In short, it would mean that for PPPoE connections, the network would
        restart every time a user managed via local directory.
        """
        secrets = ["", "## Auto Generated", "## DO NOT EDIT. Changes will be overwritten.", ""]
        if settings_file.id == "local_directory":
            # Write local directory entries
            local_secrets = []
            for user in settings_file.settings.get("list"):
                username = user["username"]
                encrypted_password = user["encryptedPassword"]
                if username is None:
                    continue
                try:
                    password = EncryptionUtil.execute_password_manager("-d", encrypted_password)
                except Exception:
                    continue
                local_secrets.append(f'"{username}"\t\tuntangle-l2tp\t\t"{password}"\t\t*')

            filename = (
                f"{prefix}{AuthManager.chap_secrets_filename}.intermediate-{settings_file.id}"
            )
            file_dir = os.path.dirname(filename)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)

            chap_secrets_file = open(filename, "w+")
            chap_secrets_file.write("\n".join(local_secrets))
            chap_secrets_file.flush()
            chap_secrets_file.close()

        # Look for intermediate files to read/append to these secrets
        intermediate_filenames = []
        # Current session
        for filename in glob.glob(f"{prefix}{AuthManager.chap_secrets_filename}.intermediate-*"):
            intermediate_filenames.append(filename)
        # Live
        for filename in glob.glob(f"{AuthManager.chap_secrets_filename}.intermediate-*"):
            found = False
            for i_filename in intermediate_filenames:
                if i_filename.endswith(filename):
                    found = True
            if found is False:
                intermediate_filenames.append(filename)

        for filename in intermediate_filenames:
            with open(filename) as file:
                for line in file:
                    secrets.append(line.strip())

        secrets.append("")

        filename = prefix + AuthManager.chap_secrets_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        chap_secrets_file = open(filename, "w+")
        chap_secrets_file.write("\n".join(secrets))
        chap_secrets_file.flush()
        chap_secrets_file.close()
        logger.info("Wrote %s", str(self.chap_secrets_filename))


registrar.register_manager(AuthManager())
