import glob
import os
import re

from sync import Manager, registrar
from sync.common import Logger

# This class is responsible for updating logrotate configuration files

logger = Logger.getInstance()


class LogrotateManager(Manager):
    logrotate_conf_file_name = "/etc/logrotate.conf"
    logrotate_directory_name = "/etc/logrotate.d"

    keyword_rotate = re.compile(r"^(\s*rotate)\s+(\d+)")

    def initialize(self) -> None:
        """
        Register the settings file and logrotate files.
        """
        registrar.register_settings_file("system", self)

        for file_name in self.get_file_names():
            registrar.register_file(file_name, "noop", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Synchronize our file by modifying.
        """
        logRetention = 7
        if "logRetention" in settings_file.settings:
            logRetention = settings_file.settings["logRetention"]
        logRetention = str(logRetention)

        for in_file_name in self.get_file_names():
            out_file_name = prefix + in_file_name
            out_file_dir = os.path.dirname(out_file_name)
            if not os.path.exists(out_file_dir):
                os.makedirs(out_file_dir)

            in_file = open(in_file_name)
            out_file = open(out_file_name, "w+")

            for line in in_file:
                match = re.search(self.keyword_rotate, line)
                if match:
                    rotate_command = match.group(1)
                    line = f"{rotate_command} {logRetention}\n"
                out_file.write(line)

            in_file.close()
            out_file.flush()
            out_file.close()
            logger.info("Wrote %s", str(out_file_name))

    def get_file_names(self):
        """
        Get the primary logrotate configuration and all others under its directory.
        """
        log_rotate_file_names = glob.glob(self.logrotate_directory_name + "/*")
        log_rotate_file_names.insert(0, self.logrotate_conf_file_name)
        return log_rotate_file_names


registrar.register_manager(LogrotateManager())
