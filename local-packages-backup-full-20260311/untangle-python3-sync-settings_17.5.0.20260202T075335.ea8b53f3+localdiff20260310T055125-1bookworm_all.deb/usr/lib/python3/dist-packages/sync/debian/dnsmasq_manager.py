import os
import stat

from sync import Manager, network_util, registrar
from sync.common import Logger

# This class is responsible for writing
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class DnsMasqManager(Manager):
    dnsmasq_hosts_filename = "/etc/hosts.dnsmasq"
    dnsmasq_conf_filename = "/etc/dnsmasq.conf"
    restart_hook_filename = "/etc/untangle/post-network-hook.d/990-restart-dnsmasq"
    dhcp_statics_filename = "/etc/dnsmasq.d/dhcp-static"
    dns_server_template = (
        "# interface {interface_id}, dns resolver {dns_index}\n"
        "server={dns_resolver_ip_address}{use_interface}{interface_device}\n\n"
    )

    dhcp_option_netmask = 1
    dhcp_option_gateway = 3
    dhcp_option_dns = 6

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        # dnsmasq settings, requires dnsmasq restart
        registrar.register_file(self.dnsmasq_hosts_filename, "restart-dnsmasq", self)
        registrar.register_file(self.dnsmasq_conf_filename, "restart-dnsmasq", self)
        registrar.register_file(self.dhcp_statics_filename, "restart-dnsmasq", self)
        # Just a restart script, no need to restart if changed
        registrar.register_file(self.restart_hook_filename, None, self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        self.write_dnsmasq_hosts(settings_file.settings, prefix)
        self.write_dhcp_statics_file(settings_file.settings, prefix)
        self.write_dnsmasq_conf(settings_file.settings, prefix)
        self.write_restart_dnsmasq_hook(settings_file.settings, prefix)

    def write_dnsmasq_hosts(self, settings, prefix) -> None:
        filename = prefix + self.dnsmasq_hosts_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write("# user-defined static entries \n")
        if (
            settings.get("dnsSettings") is not None
            and settings.get("dnsSettings").get("staticEntries") is not None
        ):
            for entry in settings.get("dnsSettings").get("staticEntries"):
                if entry.get("name") is not None and entry.get("address") is not None:
                    file.write("{}\t{}".format(entry.get("address"), entry.get("name")) + "\n")
            file.write("\n")

        file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_dnsmasq_conf(self, settings, prefix="") -> None:
        filename = prefix + self.dnsmasq_conf_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        # For a long time, We've  defined DNS resolver servers without pinning to interfaces.
        #
        # This can cause problems for some networks where dnsmasq will attempt to query
        # one of these resolver addresses on its own interface which will fail due to routing.
        # The behavior systems see in this case are DNS timeouts.
        #
        # For static Ethernet devices, if all interfaces have at least one of the
        # two resolvers defined, pin to the interface.
        # Otherwise, unpin.
        #
        # Pinning won't work for PPPOE because the symbolic devs are created
        # dynamically.  If we try to establish pinning here, the pppX interface
        # won't exist and therefore dnsmasq won't start.
        pin_ethernet_resolvers = True
        for intf in settings["interfaces"]:
            if intf.get("configType") == "ADDRESSED" and intf.get("isWan") is True:
                if intf.get("v4ConfigType") == "STATIC":
                    if intf.get("v4StaticDns1") is None and intf.get("v4StaticDns2") is None:
                        # In the current UI, we don't allow you to define a static interface without
                        # specifying a DNS resolver.  But we may have allowed this previously.
                        # If we have one interface with no DNS resolvers, don't use pinning.
                        pin_ethernet_resolvers = False
                if intf.get("v4ConfigType") == "PPPOE":
                    # In theory, if v4PPPoEUsePeerDns was set to True, we are getting
                    # a resolver address from the server.
                    # But we can't validate/guarantee this so any kind of PPPoE indicates
                    # non-pinnable environment,
                    pin_ethernet_resolvers = False

        for intf in settings["interfaces"]:
            # If its a static WAN then write the uplink DNS values
            if (
                intf.get("configType") == "ADDRESSED"
                and intf.get("isWan") is True
                and intf.get("v4ConfigType") == "STATIC"
            ):
                for index in [1, 2]:
                    dns_resolver = intf.get(f"v4StaticDns{index}")
                    if dns_resolver is None:
                        continue
                    file.write(
                        DnsMasqManager.dns_server_template.format(
                            dns_index=index,
                            interface_id=intf.get("interfaceId"),
                            dns_resolver_ip_address=dns_resolver,
                            use_interface=("@" if pin_ethernet_resolvers else ""),
                            interface_device=(
                                intf.get("symbolicDev") if pin_ethernet_resolvers else ""
                            ),
                        )
                    )
            # If its a PPPoE WAN then write the uplink DNS values if UserPeerDns is disabled
            if (
                intf.get("configType") == "ADDRESSED"
                and intf.get("isWan") is True
                and intf.get("v4ConfigType") == "PPPOE"
                and intf.get("v4PPPoEUsePeerDns") is False
            ):
                if intf.get("v4PPPoEDns1") is not None:
                    file.write("# Interface {} DNS 1".format(str(intf.get("interfaceId"))) + "\n")
                    file.write(
                        "server={} # uplink.{}".format(
                            intf.get("v4PPPoEDns1"), str(intf.get("interfaceId"))
                        )
                        + "\n"
                    )
                    file.write("\n")
                if intf.get("v4PPPoEDns2") is not None:
                    file.write("# Interface {} DNS 2".format(str(intf.get("interfaceId"))) + "\n")
                    file.write(
                        "server={} # uplink.{}".format(
                            intf.get("v4PPPoEDns2"), str(intf.get("interfaceId"))
                        )
                        + "\n"
                    )
                    file.write("\n")
            # If its a dhcp WAN then write the some comments for clarity
            if (
                intf.get("configType") == "ADDRESSED"
                and intf.get("isWan") is True
                and intf.get("v4ConfigType") == "AUTO"
            ):
                file.write("# Interface {} DNS".format(str(intf.get("interfaceId"))) + "\n")
                file.write("# stored in /etc/dnsmasq.d/dhcp-upstream-dns-servers" + "\n")
                file.write("\n")

        # Set global options
        file.write("# Global DNS options\n")
        file.write("interface=* # specified so local-service option is disabled\n")
        file.write("localise-queries\n")
        file.write("expand-hosts\n")
        # dont read /etc/hosts - this will result in returning 127.0.0.1 for some queries
        file.write("no-hosts\n")
        file.write("addn-hosts=/etc/hosts.dnsmasq\n")
        # use a dedicated file for the interface specific feature where dnsmasq returns the
        # most appropriate IP based on the interface address where the query was received
        file.write("addn-hosts=/etc/hosts.untangle\n")
        file.write("\n")

        # Set global DHCP options
        file.write("# Global DHCP options\n")
        if settings.get("dhcpAuthoritative") is True:
            file.write("dhcp-authoritative\n")
        file.write(f"dhcp-lease-max={settings['dhcpMaxLeases']}\n")
        file.write("dns-forward-max=512\n")
        file.write("\n")

        # dhcp_ranges contains dictionaries with the following keys:
        # comment       Comment to use
        # tag           Range tag.  For interfaces this is the systemdev name (e.g.,eth1),
        #               For relays the description with no spaces.
        # start         Start of the range.
        # end           End of the range.
        # lease         Lease time in seconds
        # options       List of options where each dictionary contains:
        #   comment     Configuration comment
        #   option      Numeric option code
        #   value       Value of the option
        dhcp_ranges = []

        # dhcp_relays contains dictionaries with the following keys:
        # comment       Comment to use
        # query         Address to query from, such as primary IP address of interface
        # host          Host address.
        dhcp_relays = []

        # Collect DHCP settings from interfaces
        for intf in settings["interfaces"]:
            if intf.get("configType") == "ADDRESSED" and intf.get("isWan") is False:
                dhcp_type = intf.get("dhcpType")
                if dhcp_type == "SERVER":
                    dhcp_range = {
                        "options": [],
                        "type": "SERVER",
                    }

                    lease = intf.get("dhcpLeaseDuration")
                    if lease is None or lease == 0:
                        lease = 3600
                    dhcp_range["lease"] = lease

                    # Use symbolicDev so the whole bridge is served if its a bridge
                    dhcp_range["comment"] = (
                        f"DHCP: Interface {intf.get('interfaceId')} ({intf.get('symbolicDev')})"
                    )
                    dhcp_range["tag"] = intf.get("symbolicDev")
                    dhcp_range["start"] = intf.get("dhcpRangeStart")
                    dhcp_range["end"] = intf.get("dhcpRangeEnd")

                    # Use override valye if specified, set it, otherwise use static address (ourselves) as gateway
                    gateway_address = intf.get("dhcpGatewayOverride")
                    if gateway_address is None or gateway_address == "":
                        gateway_address = intf.get("v4StaticAddress")
                    dhcp_range["options"].append(
                        {
                            "comment": f"{dhcp_range.get('comment')}, gateway address",
                            "option": DnsMasqManager.dhcp_option_gateway,
                            "value": gateway_address,
                        }
                    )

                    # If the override value is specified, set it, otherwise use static netmask
                    subnet_netmask = intf.get("dhcpNetmaskOverride")
                    if subnet_netmask is None or subnet_netmask == "":
                        subnet_netmask = intf.get("v4StaticNetmask")
                    dhcp_range["options"].append(
                        {
                            "comment": f"{dhcp_range.get('comment')}, subnet mask",
                            "option": DnsMasqManager.dhcp_option_netmask,
                            "value": subnet_netmask,
                        }
                    )

                    # If the override value is specified, set it, otherwise use static address (ourselves) as DNS
                    dns_address = intf.get("dhcpDnsOverride")
                    if dns_address is None or dns_address == "":
                        dns_address = intf.get("v4StaticAddress")
                    dhcp_range["options"].append(
                        {
                            "comment": f"{dhcp_range.get('comment')}, domain server address",
                            "option": DnsMasqManager.dhcp_option_dns,
                            "value": dns_address,
                        }
                    )

                    # write custom DHCP options
                    if "dhcpOptions" in intf:
                        for dhcpOption in intf.get("dhcpOptions"):
                            enabled = dhcpOption.get("enabled")
                            if enabled is None or not enabled:
                                continue
                            full_option = dhcpOption.get("value")
                            dhcp_range["options"].append(
                                {
                                    "comment": f"{dhcp_range.get('comment')}, {dhcpOption.get('description')}",
                                    "option": full_option.split(",")[0],
                                    "value": full_option.split(",", 1)[1],
                                }
                            )

                    dhcp_ranges.append(dhcp_range)
                elif dhcp_type == "RELAY":
                    dhcp_relays.append(
                        {
                            "comment": f"DHCP relay to host: Interface {intf.get('interfaceId')} ({intf.get('symbolicDev')})",
                            "query": intf.get("v4StaticAddress"),
                            "host": intf.get("dhcpRelayAddress"),
                        }
                    )

        # Collect DHCP settings from relays
        for dhcp_relay in settings["dhcpRelays"]:
            if not dhcp_relay.get("enabled"):
                continue
            dhcp_range = {
                "options": [],
                "type": "RELAY",
            }
            dhcp_range["comment"] = f"DHCP relay: {dhcp_relay.get('description')}"
            dhcp_range["tag"] = dhcp_relay.get("description").replace(" ", "_")
            dhcp_range["lease"] = dhcp_relay.get("leaseDuration")
            dhcp_range["start"] = dhcp_relay.get("rangeStart")
            dhcp_range["end"] = dhcp_relay.get("rangeEnd")
            # Gateway
            dhcp_range["options"].append(
                {
                    "comment": f"{dhcp_range.get('comment')}, gateway address",
                    "option": DnsMasqManager.dhcp_option_gateway,
                    "value": dhcp_relay.get("gateway"),
                }
            )
            # Netmask
            dhcp_range["options"].append(
                {
                    "comment": f"{dhcp_range.get('comment')}, subnet mask",
                    "option": DnsMasqManager.dhcp_option_netmask,
                    "value": network_util.ipv4_prefix_to_netmask(dhcp_relay.get("prefix")),
                }
            )
            # DNS
            dhcp_range["options"].append(
                {
                    "comment": f"{dhcp_range.get('comment')}, domain server address",
                    "option": DnsMasqManager.dhcp_option_dns,
                    "value": dhcp_relay.get("dns"),
                }
            )
            # Other options
            if "options" in dhcp_relay:
                for option in dhcp_relay.get("options"):
                    enabled = option.get("emabled")
                    if enabled is None or not enabled:
                        continue
                    full_option = option.get("value")
                    dhcp_range["options"].append(
                        {
                            "comment": f"{dhcp_range.get('comment')}, {option.get('description')}",
                            "option": full_option.split(",")[0],
                            "value": full_option.split(",", 1)[1],
                        }
                    )

            dhcp_ranges.append(dhcp_range)

        # Write DHCP ranges/options
        for dhcp_range in dhcp_ranges:
            file.write(f"# {dhcp_range.get('comment')}\n")
            range_prefix = "tag" if dhcp_range.get("type") == "SERVER" else "set"
            file.write(
                f"dhcp-range={range_prefix}:{dhcp_range.get('tag')},{dhcp_range.get('start')},{dhcp_range.get('end')},{dhcp_range.get('lease')}\n"
            )

            for option in dhcp_range.get("options"):
                file.write(f"# {option.get('comment')}\n")
                file.write(
                    f"dhcp-option=tag:{dhcp_range.get('tag')},{option.get('option')},{option.get('value')}\n"
                )
            file.write("\n")

        # Write dhcp relays
        for dhcp_relay in dhcp_relays:
            file.write(f"# {dhcp_relay.get('comment')}\n")
            file.write(f"dhcp-relay={dhcp_relay.get('query')},{dhcp_relay.get('host')}\n")
        if len(dhcp_relays) > 0:
            file.write("\n")

        # Write domain
        if settings.get("domainName") is not None:
            file.write("# domain\n")
            file.write("domain={}".format(settings.get("domainName")) + "\n")
            file.write("\n")

        # Local DNS servers
        file.write("# Local DNS servers\n")
        if (
            settings.get("dnsSettings") is not None
            and settings.get("dnsSettings").get("localServers") is not None
        ):
            for localServer in settings.get("dnsSettings").get("localServers"):
                if (
                    localServer.get("domain") is not None
                    and localServer.get("localServer") is not None
                ):
                    file.write(
                        "local=/{}/{}".format(localServer["domain"], localServer["localServer"])
                        + "\n"
                    )
            file.write("\n")

        # Write custom advanced options
        if settings.get("dnsmasqOptions") is not None:
            file.write("# Custom dnsmasq options\n")
            file.write("{}".format(settings.get("dnsmasqOptions")) + "\n")
            file.write("\n")

        file.write("\n")
        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_dhcp_statics_file(self, settings, prefix="") -> None:
        filename = prefix + self.dhcp_statics_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")

        # Static DHCP Entries
        file.write("# Static DHCP entries\n")
        if settings.get("staticDhcpEntries") is not None:
            for staticDhcpEntry in settings.get("staticDhcpEntries"):
                if (
                    staticDhcpEntry.get("macAddress") is not None
                    and staticDhcpEntry.get("address") is not None
                ):
                    file.write(
                        "dhcp-host={},{}".format(
                            staticDhcpEntry.get("macAddress"), staticDhcpEntry.get("address")
                        )
                        + "\n"
                    )
            file.write("\n")

        file.write("\n")
        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_restart_dnsmasq_hook(self, settings, prefix="") -> None:
        filename = prefix + self.restart_hook_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        file.write(r"""
DNSMASQ_PID="`pidof dnsmasq`"

# Restart dnsmasq if it isnt found
# Or if dnsmasq.conf or hosts.dnsmasq has been written since dnsmasq was started
if [ -z "$DNSMASQ_PID" ] ; then
    systemctl --no-block restart dnsmasq
# use not older than (instead of newer than) because it compares seconds and we want an equal value to still do a restart
elif [ ! /etc/dnsmasq.conf -ot /proc/$DNSMASQ_PID ] ; then
    systemctl --no-block restart dnsmasq
# use not older than (instead of newer than) because it compares seconds and we want an equal value to still do a restart
elif [ ! /etc/hosts.dnsmasq -ot /proc/$DNSMASQ_PID ] ; then
    systemctl --no-block restart dnsmasq
fi
""")

        file.write("\n")
        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(DnsMasqManager())
