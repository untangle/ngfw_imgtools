import glob
import os
import stat
import traceback

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

# This class is responsible for writing /etc/network/interfaces
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class InterfacesManager(Manager):
    interfaces_filename = "/etc/network/interfaces"
    interfaces_marks_filename = "/etc/untangle/iptables-rules.d/100-interface-marks"
    pre_network_hook_interface_mapping_filename = (
        "/etc/untangle/pre-network-hook.d/008-interfaces-mapping"
    )
    pre_network_hook_filename = "/etc/untangle/pre-network-hook.d/045-interfaces"
    hourly_cron_file = "/etc/cron.hourly/arp-updates-cron"
    systemd_network_path = "/etc/systemd/network"

    src_interface_mark_mask = 0x00FF
    dst_interface_mark_mask = 0xFF00
    lxc_interface_mark_mask = 0x04000000
    both_interfaces_mark_mask = 0xFFFF
    interfaces_file = None

    force_link_drivers = ["igc"]

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_file(self.interfaces_filename, "restart-networking", self)
        registrar.register_file(self.interfaces_marks_filename, "restart-iptables", self)
        registrar.register_file(self.pre_network_hook_filename, "restart-networking", self)
        registrar.register_file(
            self.pre_network_hook_interface_mapping_filename, "restart-networking", self
        )
        registrar.register_file(self.systemd_network_path, "restart-networking", self)
        registrar.register_file(self.hourly_cron_file, "noop", self)

    def validate_settings(self, settings_file) -> None:
        if settings_file.settings is None:
            raise SettingsException(message_str="Invalid Settings: null")

        if "interfaces" not in settings_file.settings:
            raise SettingsException(message_str="Invalid Settings: missing interfaces")
        interfaces = settings_file.settings["interfaces"]
        for intf in interfaces:
            for key in [
                "interfaceId",
                "name",
                "systemDev",
                "symbolicDev",
                "physicalDev",
                "configType",
            ]:
                if key not in intf:
                    raise SettingsException(
                        message_str=f"Invalid Interface Settings: missing key {key}"
                    )

        if "virtualInterfaces" not in settings_file.settings:
            raise SettingsException(message_str="Invalid Settings: missing virtualInterfaces")
        virtualInterfaces = settings_file.settings["virtualInterfaces"]
        for intf in virtualInterfaces:
            for key in ["interfaceId", "name"]:
                if key not in intf:
                    raise SettingsException(
                        message_str=f"Invalid Virtual Interface Settings: missing key {key}"
                    )

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        self.write_cron_file(settings_file.settings, prefix)
        self.write_interfaces_file(settings_file.settings, prefix)
        self.write_interface_marks(settings_file.settings, prefix)
        self.write_interface_mapping(settings_file.settings, prefix, delete_list)
        self.write_pre_network_hook(settings_file.settings, prefix)
        self.write_pre_network_hook_interface_mapping(settings_file.settings, prefix)

    def write_interface_v4(self, interface_settings, interfaces, settings) -> None:
        # find interfaces bridged to this interface
        is_bridge = False
        bridged_interfaces_str = []
        bridged_interfaces = []
        for intf in interfaces:
            if intf.get("configType") == "BRIDGED" and intf.get(
                "bridgedTo"
            ) == interface_settings.get("interfaceId"):
                bridged_interfaces_str.append(str(intf.get("systemDev")))
                bridged_interfaces.append(intf)
        if len(bridged_interfaces) > 0:
            is_bridge = True
            bridged_interfaces_str.append(
                interface_settings.get("systemDev")
            )  # include yourself in bridge
            bridged_interfaces.append(interface_settings)  # include yourself in bridge
        # We want to add the physical devices to the bridge first (see issue NGFW-10101)
        # And easy way to do this is to just sort by length
        bridged_interfaces_str.sort(key=lambda x: len(x))

        # If this is a bridge interface, write the blank config for the systemDev
        if is_bridge:
            for intf in bridged_interfaces:
                self.write_interface_blank(intf, interfaces)

        devName = interface_settings.get("symbolicDev")
        configString = "manual"
        if interface_settings.get("v4ConfigType") == "AUTO":
            configString = "dhcp"
        if interface_settings.get("v4ConfigType") == "PPPOE":
            configString = "ppp"

        self.interfaces_file.write(
            "## Interface %i IPv4 (%s)\n"
            % (interface_settings.get("interfaceId"), interface_settings.get("v4ConfigType"))
        )
        self.interfaces_file.write(f"auto {devName}\n")

        # find the minimum MTU of all devs in bridge (if its a bridge)
        bridgeMinMtu = None
        if is_bridge:
            for intf in bridged_interfaces:
                if intf.get("physicalDev") is not None and settings.get("devices") is not None:
                    for devSettings in settings.get("devices"):
                        if devSettings.get("deviceName") is not None and devSettings.get(
                            "deviceName"
                        ) == intf.get("physicalDev"):
                            if devSettings.get("mtu") is not None and devSettings.get("mtu") != 0:
                                # mtu found
                                if (
                                    bridgeMinMtu is None
                                    or int(devSettings.get("mtu")) < bridgeMinMtu
                                ):
                                    bridgeMinMtu = int(devSettings.get("mtu"))

        self.interfaces_file.write(f"iface {devName} inet {configString}\n")
        if is_bridge:
            self.write_interface_force_link(bridged_interfaces_str)
        else:
            self.write_interface_force_link(devName)
        self.interfaces_file.write(
            "\tuntangle_interface_index %i\n" % interface_settings.get("interfaceId")
        )

        # load 8021q
        if interface_settings.get("isVlanInterface"):
            self.interfaces_file.write("\tpre-up modprobe -q 8021q || true\n")

        # handle static stuff
        if interface_settings.get("v4ConfigType") == "STATIC":
            self.interfaces_file.write(
                "\tuntangle_v4_address {}\n".format(interface_settings.get("v4StaticAddress"))
            )
            self.interfaces_file.write(
                "\tuntangle_v4_netmask {}\n".format(interface_settings.get("v4StaticNetmask"))
            )
            if interface_settings.get("v4StaticGateway") is not None:
                self.interfaces_file.write(
                    "\tuntangle_v4_gateway {}\n".format(interface_settings.get("v4StaticGateway"))
                )

        # handle bridge-related stuff
        if is_bridge:
            self.interfaces_file.write(
                "\tbridge_ports {}\n".format(" ".join(bridged_interfaces_str))
            )
            self.interfaces_file.write("\tbridge_ageing %i\n" % 900)  # XXX
            stpEnabled = settings.get("stpEnabled") is not None and settings.get("stpEnabled")
            if stpEnabled:
                self.interfaces_file.write("\tbridge_stp on\n")
                self.interfaces_file.write("\tbridge_maxwait %i\n" % 30)
            else:
                self.interfaces_file.write("\tbridge_stp off\n")
                # maxwait comments: http://bugs.debian.org/cgi-bin/bugreport.cgi?bug=549696
                # For now I've decide to set this to 20
                # Its tempting to set this to zero because stp is disbled
                self.interfaces_file.write("\tbridge_maxwait %i\n" % 20)
            if bridgeMinMtu is not None:
                self.interfaces_file.write("\tmtu %i\n" % bridgeMinMtu)
            # multicast_snooping causes issues with IMQ/QoS, disable it (bug #11930)
            self.interfaces_file.write(
                "\tpost-up if [ -f /sys/devices/virtual/net/$IFACE/bridge/multicast_snooping ] ; then echo 0 > /sys/devices/virtual/net/$IFACE/bridge/multicast_snooping || true ; fi"
                "\n"
            )

        # handle PPPoE stuff
        if interface_settings.get("v4ConfigType") == "PPPOE":
            if interface_settings.get("v4PPPoERootDev") is not None:
                if interface_settings.get("isVlanInterface"):
                    self.interfaces_file.write(
                        "\tpre-up env IF_VLAN_RAW_DEVICE={} IFACE={} /etc/network/if-pre-up.d/vlan || true\n".format(
                            interface_settings.get("physicalDev"),
                            interface_settings.get("v4PPPoERootDev"),
                        )
                    )
                self.interfaces_file.write(
                    "\tpre-up /sbin/ifconfig {} up || true\n".format(
                        interface_settings.get("v4PPPoERootDev")
                    )
                )
                self.interfaces_file.write(
                    "\tpost-down /sbin/ifconfig {} down || true\n".format(
                        interface_settings.get("v4PPPoERootDev")
                    )
                )
                if interface_settings.get("isVlanInterface"):
                    self.interfaces_file.write(
                        "\tpost-down env IF_VLAN_RAW_DEVICE={} IFACE={} /etc/network/if-post-down.d/vlan || true\n".format(
                            interface_settings.get("physicalDev"),
                            interface_settings.get("v4PPPoERootDev"),
                        )
                    )
            self.interfaces_file.write(
                "\tprovider %s\n"
                % ("connection.intf" + str(interface_settings.get("interfaceId")))
            )
            # sleep to give PPPoE time to get address (bug #11431)
            self.interfaces_file.write(
                f"\tpost-up /usr/share/untangle-sync-settings/bin/pppoe-wait-for-address.sh {devName} 60 || true\n"
            )

        # write VRRP source routes
        if (
            interface_settings.get("isWan")
            and interface_settings.get("configType") == "ADDRESSED"
            and interface_settings.get("vrrpEnabled")
        ):
            if interface_settings.get("vrrpAliases") is not None:
                for alias in interface_settings.get("vrrpAliases"):
                    self.interfaces_file.write(
                        '\tpost-up /usr/share/untangle-sync-settings/bin/add-source-route.sh %s "uplink.%i" -4 || true\n'
                        % (alias.get("staticAddress"), interface_settings.get("interfaceId"))
                    )

        if interface_settings.get("isWirelessInterface"):
            if (
                interface_settings.get("wirelessMode") == "AP"
                or interface_settings.get("wirelessMode") is None
            ):
                self.interfaces_file.write(f"\thostapd /etc/hostapd/hostapd.conf-{devName}\n")
            elif interface_settings.get("wirelessMode") == "CLIENT":
                self.interfaces_file.write(
                    f"\twpa-conf /etc/wpa_supplicant/wpa_supplicant.conf-{devName}\n"
                )

        self.interfaces_file.write("\n\n")

    def write_interface_v6(self, interface_settings, interfaces) -> None:
        # If it is static without an address it is disabled
        if (
            interface_settings.get("v6ConfigType") == "STATIC"
            and interface_settings.get("v6StaticAddress") is None
        ):
            interface_settings["v6ConfigType"] = "DISABLED"

        self.interfaces_file.write(
            "## Interface %i IPv6 (%s)\n"
            % (interface_settings.get("interfaceId"), interface_settings.get("v6ConfigType"))
        )
        # self.interfaces_file.write("auto %s\n" % interface_settings.get('symbolicDev'))

        self.interfaces_file.write(
            "iface {} inet6 {}\n".format(interface_settings.get("symbolicDev"), "manual")
        )
        self.interfaces_file.write(
            "\tuntangle_interface_index %i\n" % interface_settings.get("interfaceId")
        )

        if interface_settings.get("v6ConfigType") == "STATIC":
            self.interfaces_file.write(
                "\tpre-up echo 0 > /proc/sys/net/ipv6/conf/$IFACE/disable_ipv6 || true" + "\n"
            )
            self.interfaces_file.write(
                "\tpre-up echo 0 > /proc/sys/net/ipv6/conf/$IFACE/autoconf || true" + "\n"
            )
            if interface_settings.get("v6StaticAddress") is not None:
                self.interfaces_file.write(
                    "\tuntangle_v6_address {}\n".format(interface_settings.get("v6StaticAddress"))
                )
            if interface_settings.get("v6StaticPrefixLength") is not None:
                self.interfaces_file.write(
                    "\tuntangle_v6_prefix {}\n".format(
                        interface_settings.get("v6StaticPrefixLength")
                    )
                )
            if interface_settings.get("isWan"):
                if interface_settings.get("v6StaticGateway") is not None:
                    self.interfaces_file.write(
                        "\tuntangle_v6_gateway {}\n".format(
                            interface_settings.get("v6StaticGateway")
                        )
                    )
                    self.interfaces_file.write(
                        "\tpre-up echo 0 > /proc/sys/net/ipv6/conf/$IFACE/accept_ra || true" + "\n"
                    )
                else:  # no gateway specified, use RAs
                    self.interfaces_file.write(
                        "\tpre-up echo 1 > /proc/sys/net/ipv6/conf/$IFACE/accept_ra || true" + "\n"
                    )
        elif interface_settings.get("v6ConfigType") == "AUTO":
            self.interfaces_file.write(
                "\tpre-up echo 0 > /proc/sys/net/ipv6/conf/$IFACE/disable_ipv6 || true" + "\n"
            )
            self.interfaces_file.write(
                "\tpre-up echo 1 > /proc/sys/net/ipv6/conf/$IFACE/autoconf || true" + "\n"
            )
            self.interfaces_file.write("\tuntangle_v6_address {}\n".format("auto"))
            if interface_settings.get("isWan"):
                self.interfaces_file.write(
                    "\tpre-up echo 1 > /proc/sys/net/ipv6/conf/$IFACE/accept_ra || true" + "\n"
                )
            else:
                self.interfaces_file.write(
                    "\tpre-up echo 0 > /proc/sys/net/ipv6/conf/$IFACE/accept_ra || true" + "\n"
                )
        elif interface_settings.get("v6ConfigType") == "DISABLED":
            self.interfaces_file.write(
                "\tpre-up echo 1 > /proc/sys/net/ipv6/conf/$IFACE/disable_ipv6 || true" + "\n"
            )

        self.interfaces_file.write("\n\n")

    def write_interface_disabled(self, interface_settings, interfaces) -> None:
        devName = interface_settings.get("symbolicDev")
        self.interfaces_file.write(
            "## Interface %i (DISABLED)\n" % interface_settings.get("interfaceId")
        )
        self.interfaces_file.write(f"auto {devName}\n")
        self.interfaces_file.write(f"iface {devName} inet manual\n")
        self.write_interface_force_link(devName)
        self.interfaces_file.write(
            "\tpre-up echo 1 > /proc/sys/net/ipv6/conf/$IFACE/disable_ipv6 || true" + "\n"
        )
        self.interfaces_file.write(f"\tpost-up ifconfig {devName} 0.0.0.0 up || true\n")
        self.interfaces_file.write("\n\n")

    def write_interface_blank(self, interface_settings, interfaces) -> None:
        # This is not necessary as the bridge-utils scripts bring up any sub-interfaces automatically
        # in /etc/network/if-**.d/bridge
        # However, we may want to control how and when those interfaces are brought up and down
        # If so, we can specify the config here
        if interface_settings.get("isWirelessInterface"):
            devName = interface_settings.get("systemDev")
            self.interfaces_file.write(
                "## Interface %i (BRIDGE PORT)\n" % interface_settings.get("interfaceId")
            )
            self.interfaces_file.write(f"auto {devName}\n")
            self.interfaces_file.write(f"iface {devName} inet manual\n")
            self.interfaces_file.write(f"\tpost-up ifconfig {devName} 0.0.0.0 up || true\n")
            if (
                interface_settings.get("wirelessMode") == "AP"
                or interface_settings.get("wirelessMode") is None
            ):
                self.interfaces_file.write(f"\thostapd /etc/hostapd/hostapd.conf-{devName}\n")
            elif interface_settings.get("wirelessMode") == "CLIENT":
                self.interfaces_file.write(
                    f"\twpa-conf /etc/wpa_supplicant/wpa_supplicant.conf-{devName}\n"
                )
            self.interfaces_file.write("\n\n")

    def write_interface_aliases(self, interface_settings, interfaces) -> None:
        # determine the proper interface to put the aliases "on"
        if interface_settings.get("v4ConfigType") != "PPPOE":
            intf_str = interface_settings.get("symbolicDev")
        else:
            # If its a PPPoE interface, put the alias on the physical device
            # This is because the ppp interface can go up and down
            intf_str = interface_settings.get("physicalDev")

        # handle v4 aliases
        count = 1
        if interface_settings.get("v4Aliases") is not None:
            for alias in interface_settings.get("v4Aliases"):
                self.interfaces_file.write(
                    "## Interface %i IPv4 alias\n" % (interface_settings.get("interfaceId"))
                )
                self.interfaces_file.write("auto %s:%i\n" % (intf_str, count))
                self.interfaces_file.write("iface %s:%i inet manual\n" % (intf_str, count))
                self.interfaces_file.write(
                    "\tuntangle_interface_index %i\n" % interface_settings.get("interfaceId")
                )
                self.interfaces_file.write(
                    "\tuntangle_v4_address {}\n".format(alias.get("staticAddress"))
                )
                self.interfaces_file.write(
                    "\tuntangle_v4_netmask {}\n".format(alias.get("staticNetmask"))
                )
                self.interfaces_file.write("\n")
                count = count + 1

        # handle v6 aliases
        if interface_settings.get("v6Aliases") is not None:
            for alias in interface_settings.get("v6Aliases"):
                self.interfaces_file.write(
                    "## Interface %i IPv6 alias\n" % (interface_settings.get("interfaceId"))
                )
                self.interfaces_file.write("auto %s:%i\n" % (intf_str, count))
                self.interfaces_file.write("iface %s:%i inet manual\n" % (intf_str, count))
                self.interfaces_file.write(
                    "\tuntangle_interface_index %i\n" % interface_settings.get("interfaceId")
                )
                self.interfaces_file.write(
                    "\tuntangle_v6_address {}\n".format(alias.get("staticAddress"))
                )
                self.interfaces_file.write(
                    "\tuntangle_v6_netmask {}\n".format(alias.get("staticNetmask"))
                )
                self.interfaces_file.write("\n")
                count = count + 1

    def write_interface_force_link(self, devName, is_bridge=False) -> None:
        """
        If driver is known to have link issues, apply link force in post up.
        """
        if type(devName) is not list:
            devName = [devName]

        for dev in devName:
            driver = None
            try:
                driver = os.path.basename(os.readlink(f"/sys/class/net/{dev}/device/driver"))
            except Exception:
                # Not a problem if we can't determine
                continue

            if driver in InterfacesManager.force_link_drivers:
                self.interfaces_file.write(
                    f'\tpost-up sleep 5; if [ "$(cat /sys/class/net/{dev}/carrier)" = "0" ]; then ip link set {dev} down; ip addr flush dev {dev}; ip link set {dev} up; for script in /etc/network/if-up.d/*; do $script; done; fi\n'
                )

    def check_interface_settings(self, interface_settings) -> bool:
        if interface_settings.get("systemDev") is None:
            logger.error("Missing symbolic dev!")
            return False
        if interface_settings.get("symbolicDev") is None:
            logger.error("Missing symbolic dev!")
            return False
        if interface_settings.get("interfaceId") is None:
            logger.error("Missing interface ID!")
            return False
        if interface_settings.get("name") is None:
            logger.error("Missing interface name!")
            return False
        return True

    def write_interfaces_file(self, settings, prefix="") -> None:
        filename = prefix + self.interfaces_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.interfaces_file = open(filename, "w+")
        self.interfaces_file.write("## Auto Generated\n")
        self.interfaces_file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        self.interfaces_file.write("\n\n")

        self.interfaces_file.write(
            "## This is a fake interface that launches the pre-networking-restart\n"
        )
        self.interfaces_file.write(
            "## hooks using the if-up.d scripts when IFACE=networking_pre_restart_hook\n"
        )
        self.interfaces_file.write("auto networking_pre_restart_hook\n")
        self.interfaces_file.write("iface networking_pre_restart_hook inet manual\n")
        if settings.get("blockDuringRestarts") is not None and settings.get("blockDuringRestarts"):
            self.interfaces_file.write(
                '\tpre-up /sbin/iptables -t filter -I FORWARD -m conntrack --ctstate NEW -j DROP -m comment --comment "drop sessions during restart" || true\n'
            )
            self.interfaces_file.write(
                '\tpre-up /sbin/iptables -t filter -I INPUT   -m conntrack --ctstate NEW -j DROP -m comment --comment "drop sessions during restart" || true\n'
            )
        self.interfaces_file.write("\n\n")

        self.interfaces_file.write("auto lo\n")
        self.interfaces_file.write("iface lo inet loopback\n")
        self.interfaces_file.write("\n\n")

        self.interfaces_file.write("source-directory interfaces.d\n")
        self.interfaces_file.write("\n\n")

        # Write disable interfaces first
        for interface_settings in settings.get("disabledInterfaces"):
            try:
                self.write_interface_disabled(interface_settings, settings.get("interfaces"))
            except Exception:
                traceback.print_exc()

        # Write addressed interfaces last
        for interface_settings in settings.get("interfaces"):
            # only write 'ADDRESSED' interfaces
            if interface_settings.get("configType") != "ADDRESSED":
                continue

            # if invalid settigs, skip it
            if not self.check_interface_settings(interface_settings):
                continue

            # Now write the main interface configurations
            try:
                self.write_interface_v4(interface_settings, settings.get("interfaces"), settings)
            except Exception:
                traceback.print_exc()
            try:
                self.write_interface_v6(interface_settings, settings.get("interfaces"))
            except Exception:
                traceback.print_exc()
            try:
                self.write_interface_aliases(interface_settings, settings.get("interfaces"))
            except Exception:
                traceback.print_exc()

        self.interfaces_file.write(
            "## This is a fake interface that launches the post-networking-restart\n"
        )
        self.interfaces_file.write(
            "## hooks using the if-up.d scripts when IFACE=networking_post_restart_hook\n"
        )
        self.interfaces_file.write("auto networking_post_restart_hook\n")
        self.interfaces_file.write("iface networking_post_restart_hook inet manual\n")
        self.interfaces_file.write("\n\n")

        self.interfaces_file.flush()
        self.interfaces_file.close()

        logger.info("Wrote %s", str(filename))

    def write_restore_interface_marks(self, file, interfaces, prefix) -> None:
        file.write("\n\n")
        file.write("#\n")
        file.write("# Create restore-interface-marks chain" + "\n")
        file.write("#\n\n")

        file.write("# First zero out any marks on this packet" + "\n")
        file.write(
            '${IPTABLES} -t mangle -A restore-interface-marks -j MARK --and-mark 0xFFFF0000 -m comment --comment "Zero out source and destination interface marks"'
            "\n"
        )
        file.write("\n")

        file.write(
            "# Ignore and broadcast sessions as they will all share the same conntrack entry so the connmark cant be used for src/dst intf"
            "\n"
        )
        file.write(
            "# These packets will still be marked in the mark-src-intf and mark-dst-intf chains later\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A restore-interface-marks -m addrtype --dst-type broadcast  -j RETURN -m comment --comment "Do not mark broadcast packets"'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A restore-interface-marks -m addrtype --src-type broadcast  -j RETURN -m comment --comment "Do not mark broadcast packets"'
            "\n"
        )
        file.write("\n")

        file.write(
            "# This rule says if the packet is in the original direction, just copy the intf marks from the connmark/session mark"
            "\n"
        )
        file.write("uname -a | grep -q 2.6.32" + "\n")
        file.write("KERN_2_6_32=$?" + "\n")
        file.write("if [ ${KERN_2_6_32} -eq 0 ] ; then" + "\n")
        file.write(
            "\t# The rule actually says REPLY and not ORIGINAL and thats because ctdir matches backwards in 2.6.32 # http://www.spinics.net/lists/netfilter-devel/msg17864.html"
            "\n"
        )
        file.write(
            f'\t${{IPTABLES}} -t mangle -A restore-interface-marks -m conntrack --ctdir REPLY -j CONNMARK --restore-mark --mask 0x{self.both_interfaces_mark_mask:X} -m comment --comment "If packet is in original direction, copy mark from connmark to packet"'
            "\n"
        )
        file.write(
            '\t${IPTABLES} -t mangle -A restore-interface-marks -m conntrack --ctdir REPLY -j RETURN -m comment --comment "If packet is in original direction we are done, just return"'
            "\n"
        )
        file.write("else" + "\n")
        file.write(
            f'\t${{IPTABLES}} -t mangle -A restore-interface-marks -m conntrack --ctdir ORIGINAL -j CONNMARK --restore-mark --mask 0x{self.both_interfaces_mark_mask:X} -m comment --comment "If packet is in original direction, copy mark from connmark to packet"'
            "\n"
        )
        file.write(
            '\t${IPTABLES} -t mangle -A restore-interface-marks -m conntrack --ctdir ORIGINAL -j RETURN -m comment --comment "If packet is in original direction we are done, just return"'
            "\n"
        )
        file.write("fi" + "\n")
        file.write("\n")

        file.write(
            "# Since this is a reply packet, copy dst intf from connmark to src intf mark, copy src intf from connmark to dst intf mark."
            "\n"
        )
        file.write(
            "# Two rules for each interfaces, one to set src mark, one to set dst mark" + "\n"
        )

        for intf in interfaces:
            id = intf["interfaceId"]
            file.write(
                '${IPTABLES} -t mangle -A restore-interface-marks -m connmark --mark 0x%04X/0x%04X -j MARK --set-mark 0x%04X/0x%04X -m comment --comment "Set dst interface mark from connmark for intf %i"'
                % (id, self.src_interface_mark_mask, id << 8, self.dst_interface_mark_mask, id)
                + "\n"
            )
            file.write(
                '${IPTABLES} -t mangle -A restore-interface-marks -m connmark --mark 0x%04X/0x%04X -j MARK --set-mark 0x%04X/0x%04X -m comment --comment "Set src interface mark from connmark for intf %i"'
                % (id << 8, self.dst_interface_mark_mask, id, self.src_interface_mark_mask, id)
                + "\n"
            )
        file.write("\n")

    def write_mark_src_intf(self, file, settings, interfaces, prefix) -> None:
        file.write("\n\n")
        file.write("#\n")
        file.write("# Create the mark-src-intf chain." + "\n")
        file.write("#\n\n")

        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-intf -m mark ! --mark 0/0x{self.src_interface_mark_mask:04X} -j RETURN -m comment --comment "If its already set, just return"'
            "\n"
        )
        file.write("\n")

        for intf in interfaces:
            id = intf["interfaceId"]
            systemDev = intf["systemDev"]
            symbolicDev = intf["symbolicDev"]
            configType = intf["configType"]

            file.write(
                '${IPTABLES} -t mangle -A mark-src-intf -i %s -j MARK --set-mark 0x%04X/0x%04X -m comment --comment "Set src interface mark for intf %i"'
                % (systemDev, id, self.src_interface_mark_mask, id)
                + "\n"
            )
            # if bridged also add bridge rules
            if symbolicDev.startswith("br.") or configType == "BRIDGED":
                file.write(
                    '${IPTABLES} -t mangle -A mark-src-intf -m physdev --physdev-in %s -j MARK --set-mark 0x%04X/0x%04X -m comment --comment "Set src interface mark for intf %i using physdev"'
                    % (systemDev, id, self.src_interface_mark_mask, id)
                    + "\n"
                )

        # NGFW-12726
        # We need to restore both interface marks on re-injected TCP packets.
        # Our reinject-restore-marks chain will extract the interface marks
        # from the source MAC address where the UVM stores them and set them
        # in the packet mark. This requires our modified xt_mac.ko matcher
        # module that has been enhanced to allow matching on the individual
        # bytes of the MAC address. When the first byte of the comparison
        # MAC address is 0xFF the module will use the second byte of the
        # address as the index to be compared. So bytes at index 0 and 1 are
        # used to trigger our special match logic. 2 and 3 are unused.
        # 4 = dst interface and 5 = src interface. So here we create a rule
        # that jumps to the reinject-restore-marks chain, and an OUTPUT rule
        # that will restore the marks from the values we extract and set in
        # our chain. We then fill our chain with a src and dst extraction rule
        # for each interface and finally add a rule to store the extracted
        # mark in connmark so so it can be restored later.
        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -i utun -p tcp -j reinject-restore-marks -m comment --comment "Extract src and dest interface marks from source MAC address"\n'
        )
        file.write(
            "${IPTABLES} -t mangle -D OUTPUT -p tcp -m conntrack --ctdir REPLY -j restore-interface-marks >/dev/null 2>&1"
            "\n"
        )
        file.write(
            "${IPTABLES} -t mangle -A OUTPUT -p tcp -m conntrack --ctdir REPLY -j restore-interface-marks >/dev/null 2>&1"
            "\n"
        )

        for intf in interfaces:
            id = intf["interfaceId"]
            # Restore the interface marks from the source MAC address
            # See netcap_virtual_interface.c for more details
            file.write(
                f'${{IPTABLES}} -t mangle -A reinject-restore-marks -m mac --mac-source FF:05:00:00:00:{id:02x} -j MARK --set-mark 0x00{id:02X}/0x00FF -m comment --comment "Set reinjected packet src interface {id:x}"'
                "\n"
            )
            file.write(
                f'${{IPTABLES}} -t mangle -A reinject-restore-marks -m mac --mac-source FF:04:00:00:{id:02X}:00 -j MARK --set-mark 0x{id:02X}00/0xFF00 -m comment --comment "Set reinjected packet dst interface {id:x}"'
                "\n"
            )

        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -i utun -p tcp -j CONNMARK --save-mark -m comment --comment "Save mark to connmark for reinject packets"\n'
        )

        # Mark ipsec interfaces
        lan_interface_id = self.get_first_lan_interface_id(settings)
        if lan_interface_id is not None:
            file.write(
                f'${{IPTABLES}} -t mangle -A mark-src-intf -m policy --pol ipsec --dir in -j MARK --set-mark 0x{lan_interface_id:04X}/0x{self.src_interface_mark_mask:04X} -m comment --comment "Set LAN interface mark on ipsec"'
                "\n"
            )
            file.write(
                f'${{IPTABLES}} -t mangle -A mark-src-intf -i ipsec+ -j MARK --set-mark 0x{lan_interface_id:04X}/0x{self.src_interface_mark_mask:04X} -m comment --comment "Set LAN interface mark on ipsec"'
                "\n"
            )

        # Special rule to mark LXC traffic
        # This is put in a special chain so it can be easily flushed/changed
        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -i br.lxc -j mark-src-lxc-intf -m comment --comment "Mark LXC interface"'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -i veth+  -j mark-src-lxc-intf -m comment --comment "Mark LXC interface"'
            "\n"
        )

        # Save mark to connmark
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-intf -m mark ! --mark 0/0x{self.src_interface_mark_mask:04X} -m conntrack --ctstate NEW -j CONNMARK --save-mark --mask 0x{self.src_interface_mark_mask:04X} -m comment --comment "Save src interface mark to connmark"'
            "\n"
        )

        # IPsec traffic may come from a bridge interface
        # Unfortunately, the incoming interface will be br.ethX but none of the above physdev rules will match above.
        # Do not print a warning to kern.log in this case
        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -m policy --pol ipsec --dir in -j RETURN -m comment --comment "Do not warn on IPsec traffic"'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -m policy --pol ipsec --dir in -j RETURN -m comment --comment "Do not warn on IPsec traffic"'
            "\n"
        )

        # Dont log lo or utun packets
        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -i lo -j RETURN -m comment --comment "Do not warn loopback traffic"'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A mark-src-intf -i utun -j RETURN -m comment --comment "Do not warn on utun traffic"'
            "\n"
        )

        # Log unknown packets
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-intf -m mark --mark 0/0x{self.src_interface_mark_mask:04X} -j LOG --log-prefix "WARNING (unknown src intf):" -m comment --comment "WARN on missing src mark"'
            "\n"
        )

        file.write("\n")

    def write_mark_src_lxc_intf(self, file, settings, interfaces, prefix) -> None:
        file.write("\n\n")
        file.write("#\n")
        file.write("# Create the mark-src-lxc-intf chain." + "\n")
        file.write("#\n\n")

        lxcInterfaceId = self.get_lxc_interface_id(settings)
        if lxcInterfaceId is None:
            return

        # Add a rule so LXC traffic is marked as if it was coming from lxcInterfaceId
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-lxc-intf -i br.lxc -j MARK --set-mark 0x{lxcInterfaceId:04X}/0x{self.src_interface_mark_mask:04X} -m comment --comment "Set src interface mark lxc"'
            "\n"
        )
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-lxc-intf -i veth+  -j MARK --set-mark 0x{lxcInterfaceId:04X}/0x{self.src_interface_mark_mask:04X} -m comment --comment "Set src interface mark lxc"'
            "\n"
        )

        # Give it a special mark
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-lxc-intf -i br.lxc -j MARK --set-mark 0x{self.lxc_interface_mark_mask:04X}/0x{self.lxc_interface_mark_mask:04X} -m comment --comment "Set lxc mark for lxc"'
            "\n"
        )
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-lxc-intf -i veth+  -j MARK --set-mark 0x{self.lxc_interface_mark_mask:04X}/0x{self.lxc_interface_mark_mask:04X} -m comment --comment "Set lxc mark for lxc"'
            "\n"
        )

        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-lxc-intf -i br.lxc -j CONNMARK --save-mark --mask 0x{self.lxc_interface_mark_mask:04X} -m comment --comment "Save lxc mark to connmark"'
            "\n"
        )
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-src-lxc-intf -i veth+  -j CONNMARK --save-mark --mask 0x{self.lxc_interface_mark_mask:04X} -m comment --comment "Save lxc mark to connmark"'
            "\n"
        )

        file.write("\n")

    def write_mark_dst_intf(self, file, settings, interfaces, prefix) -> None:
        file.write("\n\n")
        file.write("#\n")
        file.write("# Create the mark-dst-intf chain." + "\n")
        file.write("#\n\n")

        # We dont bother with already marked packets, except if its the first packet in the session
        # If it is the first packet then WAN-balancer could have picked a WAN but it might be headed elsewhere because of a static route.
        file.write(
            f'${{IPTABLES}} -t mangle -A mark-dst-intf -m mark ! --mark 0/0x{self.dst_interface_mark_mask:04X} -m conntrack ! --ctstate NEW -j RETURN -m comment --comment "If its already set and an existing session, just return"'
            "\n"
        )
        file.write("\n")

        # Don't bother with broadcast packets,
        file.write(
            '${IPTABLES} -t mangle -A mark-dst-intf -m addrtype --dst-type broadcast -j RETURN -m comment --comment "If its a broadcast packet, just return"'
            "\n"
        )
        file.write("\n")

        for intf in interfaces:
            id = intf["interfaceId"]
            systemDev = intf["systemDev"]
            symbolicDev = intf["symbolicDev"]
            configType = intf["configType"]

            file.write(
                '${IPTABLES} -t mangle -A mark-dst-intf -o %s -j MARK --set-mark 0x%04X/0x%04X -m comment --comment "Set dst interface mark for intf %i"'
                % (systemDev, id << 8, self.dst_interface_mark_mask, id)
                + "\n"
            )
            # if bridged also add bridge rules
            if symbolicDev.startswith("br.") or configType == "BRIDGED":
                file.write(
                    '${IPTABLES} -t mangle -A mark-dst-intf -o %s -m physdev --physdev-out %s -j MARK --set-mark 0x%04X/0x%04X -m comment --comment "Set dst interface mark for intf %i using physdev"'
                    % (symbolicDev, systemDev, id << 8, self.dst_interface_mark_mask, id)
                    + "\n"
                )

            # if PPPOE also do mss clamping
            if intf["v4ConfigType"] == "PPPOE":
                file.write(
                    f'${{IPTABLES}} -t mangle -A mark-dst-intf -o {systemDev} -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu -m comment --comment "Perform mss clamping for PPPOE intf {systemDev}"'
                    "\n"
                )

        file.write("\n")

        lxcInterfaceId = self.get_lxc_interface_id(settings)
        if lxcInterfaceId is not None:
            # Add a rule so LXC traffic is marked as if it was going to from lxcInterfaceId
            file.write(
                f'${{IPTABLES}} -t mangle -A mark-dst-intf -o br.lxc -j MARK --set-mark 0x{lxcInterfaceId << 8:04X}/0x{self.dst_interface_mark_mask:04X} -m comment --comment "Set dst interface mark lxc"'
                "\n"
            )
            file.write(
                f'${{IPTABLES}} -t mangle -A mark-dst-intf -o veth+  -j MARK --set-mark 0x{lxcInterfaceId << 8:04X}/0x{self.dst_interface_mark_mask:04X} -m comment --comment "Set dst interface mark lxc"'
                "\n"
            )
            file.write("\n")

    def write_save_dst_intf_mark(self, file, interfaces, prefix) -> None:
        file.write("\n\n")
        file.write("#\n")
        file.write("# Create the save-mark-dst-intf chain." + "\n")
        file.write("#\n\n")

        # file.write("${IPTABLES} -t filter -A save-mark-dst-intf -m mark --mark 0/0x%04X -j LOG --log-prefix \"WARNING (unknown dst intf):\" -m comment --comment \"WARN on missing dst mark\"" % (self.dst_interface_mark_mask) + "\n");
        file.write(
            f'${{IPTABLES}} -t filter -A save-mark-dst-intf -m conntrack --ctstate NEW -j CONNMARK --save-mark --mask 0x{self.dst_interface_mark_mask:04X} -m comment --comment "Save dst interface mark to connmark"'
            "\n"
        )

        file.write("\n")

    def write_interface_marks(self, settings, prefix) -> None:
        interfaces = settings["interfaces"]

        filename = prefix + self.interfaces_marks_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(
            "# Create (if needed) and flush restore-interface-marks, mark-src-intf, mark-dst-intf, reinject-restore-marks chains"
            "\n"
        )
        file.write("${IPTABLES} -t mangle -N restore-interface-marks 2>/dev/null" + "\n")
        file.write("${IPTABLES} -t mangle -F restore-interface-marks >/dev/null 2>&1" + "\n")
        file.write("${IPTABLES} -t mangle -N mark-src-intf 2>/dev/null" + "\n")
        file.write("${IPTABLES} -t mangle -F mark-src-intf >/dev/null 2>&1" + "\n")
        file.write("${IPTABLES} -t mangle -N mark-dst-intf 2>/dev/null" + "\n")
        file.write("${IPTABLES} -t mangle -F mark-dst-intf >/dev/null 2>&1" + "\n")
        file.write("${IPTABLES} -t filter -N save-mark-dst-intf 2>/dev/null" + "\n")
        file.write("${IPTABLES} -t filter -F save-mark-dst-intf >/dev/null 2>&1" + "\n")
        file.write("${IPTABLES} -t mangle -N mark-src-lxc-intf 2>/dev/null" + "\n")
        file.write("${IPTABLES} -t mangle -F mark-src-lxc-intf 2>/dev/null" + "\n")
        file.write("${IPTABLES} -t mangle -N reinject-restore-marks 2>/dev/null" + "\n")
        file.write("${IPTABLES} -t mangle -F reinject-restore-marks 2>/dev/null" + "\n")

        file.write("\n")

        file.write(
            "# Call restore-interface-marks then mark-src-intf from PREROUTING chain in mangle\n"
        )
        file.write(
            '${IPTABLES} -t mangle -D prerouting-set-marks -m comment --comment "Restore interface marks (0xffff) from connmark" -j restore-interface-marks >/dev/null 2>&1'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -D prerouting-set-marks -m comment --comment "Set src intf mark (0x00ff)" -j mark-src-intf >/dev/null 2>&1'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A prerouting-set-marks -m comment --comment "Restore interface marks (0xffff) from connmark" -j restore-interface-marks'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A prerouting-set-marks -m comment --comment "Set src intf mark (0x00ff)" -j mark-src-intf'
            "\n"
        )
        file.write("\n")

        file.write("# Call mark-dst-intf from FORWARD chain in mangle" + "\n")
        file.write(
            '${IPTABLES} -t mangle -D forward-set-marks -m comment --comment "Set dst intf mark (0xff00)" -j mark-dst-intf >/dev/null 2>&1'
            "\n"
        )
        file.write(
            '${IPTABLES} -t mangle -A forward-set-marks -m comment --comment "Set dst intf mark (0xff00)" -j mark-dst-intf'
            "\n"
        )
        file.write("\n")

        file.write("# Call save-mark-dst-intf from FORWARD chain in filter" + "\n")
        file.write("# Do not think this is necessary - local traffic is always bypassed" + "\n")
        file.write(
            '${IPTABLES} -t filter -D FORWARD -m comment --comment "Save dst intf mark (0xff00)" -j save-mark-dst-intf >/dev/null 2>&1'
            "\n"
        )
        file.write(
            '${IPTABLES} -t filter -A FORWARD -m comment --comment "Save dst intf mark (0xff00)" -j save-mark-dst-intf'
            "\n"
        )
        file.write("\n")

        file.write("# Call mark-dst-intf from OUTPUT chain in mangle for local traffic" + "\n")
        file.write("# Do not think this is necessary - local traffic is always bypassed" + "\n")
        file.write(
            '# ${IPTABLES} -t mangle -D output-set-marks -m comment --comment "Set dst intf mark (0xff00)" -j mark-dst-intf >/dev/null 2>&1'
            "\n"
        )
        file.write(
            '# ${IPTABLES} -t mangle -A output-set-marks -m comment --comment "Set dst intf mark (0xff00)" -j mark-dst-intf'
            "\n"
        )
        file.write("\n")

        self.write_restore_interface_marks(file, interfaces, prefix)

        self.write_mark_src_intf(file, settings, interfaces, prefix)

        self.write_mark_dst_intf(file, settings, interfaces, prefix)

        self.write_save_dst_intf_mark(file, interfaces, prefix)

        self.write_mark_src_lxc_intf(file, settings, interfaces, prefix)

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_interface_mapping(self, settings, prefix="", delete_list=None) -> None:
        """
        Write interface mapping of name to current mac address
        """
        if delete_list is None:
            delete_list = []
        created_files = []
        prefix_path = f"{prefix}{InterfacesManager.systemd_network_path}"
        # Use the physical device list, not interfaces which may not have disabled interfaces
        for device in settings.get("devices"):
            device_name = device.get("deviceName")
            mac_address_filename = f"/sys/class/net/{device_name}/address"
            mac_address = None
            if not os.path.isfile(mac_address_filename):
                # Mac address doesn't exit
                continue
            with open(mac_address_filename) as file:
                mac_address = file.readline().strip()
            if mac_address is None or mac_address in ("", "00:00:00:00:00:00"):
                # No mac address found
                continue

            if not os.path.exists(prefix_path):
                os.makedirs(prefix_path)

            map_filename = f"{prefix_path}/{device_name}.link"
            created_files.append(f"{InterfacesManager.systemd_network_path}/{device_name}.link")
            with open(map_filename, "w") as file:
                file.write(f"""
[Match]
MACAddress={mac_address}
Driver=!bridge
Type=!vlan

[Link]
NamePolicy=
Name={device_name}

""")
            logger.info("Wrote %s", str(map_filename))

        # If we find files there that we didn't create, remove them
        # This is to fix issues where existing model files will initially write
        # files like "10-eth0.link" instead of our new convetion of "eth0.link"
        for filename in glob.glob(f"{InterfacesManager.systemd_network_path}/*"):
            if filename not in created_files:
                delete_list.append(filename)

    def write_pre_network_hook(self, settings, prefix="") -> None:
        filename = prefix + self.pre_network_hook_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(r"""
## Return a list of all of the bridges
bridge_list()
{
    find /sys/class/net/*/bridge -name 'bridge_id' 2>/dev/null | sed -e 's|/sys/class/net/\([^/]*\)/.*|\1|'
}

## Return a list of interfaces that are in bridge.
bridge_port_list()
{
    local l_bridge=$1

    test -n "${l_bridge}" && {
        find /sys/class/net/${l_bridge}/brif/ -maxdepth 1 -mindepth 1 -exec basename {} \; 2>/dev/null
    }
}

## Deconfigure all of the active bridges
bridge_destroy_all()
{
    local l_bridge
    local l_port

    for l_bridge in `bridge_list` ; do
        $DEBUG "Destroying bridge: '${l_bridge}'."
        for l_port in `bridge_port_list ${l_bridge}` ; do
            $DEBUG "Removing interface '${l_port}' from the bridge '${l_bridge}'."
            brctl delif ${l_bridge} ${l_port}
            ifconfig ${l_port} 0.0.0.0
            ifconfig ${l_port} down
        done
        ifconfig ${l_bridge} down
        brctl delbr ${l_bridge}
    done
}

# cleanup: Flushing interface addresses.
ip addr flush scope global 2>/dev/null

# cleanup: Destroying all of the bridges.
bridge_destroy_all

# remove interface status files
rm -f /var/lib/interface-status/interface*status.js

# disable forwarding on all interfaces, enable in all
# enable accept_ra on all interfaces
# http://strugglers.net/~andy/blog/2011/09/04/linux-ipv6-router-advertisements-and-forwarding/
""")
        file.write("echo 1 > /proc/sys/net/ipv6/conf/all/forwarding" + "\n")
        file.write("echo 0 > /proc/sys/net/ipv6/conf/default/forwarding" + "\n")
        file.writelines(
            "if [ -f /proc/sys/net/ipv6/conf/{}/forwarding ] ; then echo 0 > /proc/sys/net/ipv6/conf/{}/forwarding; fi".format(
                intf["physicalDev"], intf["physicalDev"]
            )
            + "\n"
            for intf in settings.get("interfaces")
        )

        file.flush()
        file.close()
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(filename))

    def write_pre_network_hook_interface_mapping(self, settings, prefix="") -> None:
        """
        Write script to call network mapping script
        """
        filename = f"{prefix}{self.pre_network_hook_interface_mapping_filename}"
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        with open(filename, "w+") as file:
            file.write(r"""#!/bin/dash

## Auto Generated
## DO NOT EDIT. Changes will be overwritten.

## Perform interface mapping
/usr/share/untangle/bin/interface-mapping.sh

""")

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(filename))

    def get_first_lan_interface_id(self, settings):
        """
        Retrieve first non-wan interface id from interfaces
        """
        interface_id = None
        try:
            for intf in settings.get("interfaces"):
                if not intf.get("isWan"):
                    interface_id = intf.get("interfaceId")
                    break
        except Exception:
            traceback.print_exc()

        return interface_id

    def get_lxc_interface_id(self, settings):
        """
        Look for lxcInterfaceId value and if not found or 0,
        retrieve first non-wan interface id from interfaces
        """
        lxcInterfaceId = settings.get("lxcInterfaceId")
        if lxcInterfaceId in (0, None):
            lxcInterfaceId = self.get_first_lan_interface_id(settings)

        if lxcInterfaceId in (0, None):
            return None

        return lxcInterfaceId

    def write_cron_file(self, settings, prefix=""):
        """
        Write cron file
        """
        # Write hourly cron file for sending unsolicited ARP updates
        self.cron_file_path = prefix + self.hourly_cron_file
        self.out_file_dir = os.path.dirname(self.cron_file_path)
        if settings.get("sendUnsolicitedArpUpdates") is not None:
            if not os.path.exists(self.out_file_dir):
                os.makedirs(self.out_file_dir)
            if settings.get("sendUnsolicitedArpUpdates"):
                bash_code = r"""#!/bin/bash

                            # Tag for syslog
                            SYSLOG_TAG="arp-update"

                            # Process all routing tables starting with "uplink."
                            grep -E "^[0-9]+[[:space:]]+uplink\." /etc/iproute2/rt_tables | while read -r table_id table_name; do

                                route_info=$(ip route show table "$table_id" 2>/dev/null | grep "^default") || continue

                                default=$(echo "$route_info" | awk '{print $3}')
                                intf=$(echo "$route_info" | awk '{print $5}')
                                [ -z "$default" ] && continue
                                [ -z "$intf" ] && continue

                                # Skip interfaces like ppp0 (point-to-point)
                                if [[ "$intf" == ppp* ]]; then
                                    echo "Skipping $intf (no ARP on point-to-point links)"
                                    logger -t "$SYSLOG_TAG" "Skipping $intf (no ARP on point-to-point links)"
                                    continue
                                fi

                                wanaddr=$(ip -4 addr show dev "$intf" | grep 'inet ' | awk '{print $2}' | cut -d/ -f1)
                                [ -z "$wanaddr" ] && continue

                                # Run ARP commands, capture and log their output
                                for cmd in \
                                    "arping -A -c 2 -I \"$intf\" \"$wanaddr\"" \
                                    "arping -c 2 -U \"$wanaddr\" -I \"$intf\"" \
                                    "arping -c 2 -s \"$wanaddr\" -I \"$intf\" \"$default\""
                                do
                                    echo "$cmd"
                                    output=$(eval "$cmd" 2>&1)
                                    echo "$output"
                                    logger -t "$SYSLOG_TAG" "$cmd output: $output"
                                done

                            done"""
            else:
                bash_code = r"""
                            #!/bin/bash

                            # Sending ARP updates over WAN is disabled. Enable from Network -> Advanced settings.
                        """
            # Write to file
            with open(self.cron_file_path, "w") as f:
                f.write(bash_code)
            os.chmod(self.cron_file_path, os.stat(self.cron_file_path).st_mode | stat.S_IEXEC)


registrar.register_manager(InterfacesManager())
