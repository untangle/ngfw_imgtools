import os
import stat

import psutil

from sync import Manager, registrar
from sync.common import Logger

# This class is responsible for writing:
# /etc/untangle/post-network-hook.d/200-vrrp
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class VrrpManager(Manager):
    keepalived_conf_filename = "/etc/keepalived/keepalived.conf"
    zebra_conf_filename = "/etc/frr/zebra.conf"
    post_network_hook_filename = "/etc/untangle/post-network-hook.d/200-vrrp"
    iptables_hook_filename = "/etc/untangle/iptables-rules.d/241-vrrp-rules"
    vrrp_enabled = False
    auto_generated_comment = "Auto Generated"
    do_not_edit_comment = "DO NOT EDIT. Changes will be overwritten"
    hostname = "Router"
    password = "zebra"

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_file(self.keepalived_conf_filename, "restart-keepalived", self)
        registrar.register_file(self.zebra_conf_filename, "restart-keepalived", self)
        registrar.register_file(self.post_network_hook_filename, "restart-networking", self)
        registrar.register_file(self.iptables_hook_filename, "restart-iptables", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        self.write_keepalivd_conf(settings_file.settings, prefix)
        self.write_zebra_conf(settings_file.settings, prefix)
        self.write_post_network_hook(settings_file.settings, prefix)
        self.write_iptables_hook(settings_file.settings, prefix)

    def get_vrrp_interfaces(self, settings):
        vrrp_interfaces = []
        for interface_settings in settings["interfaces"]:
            if interface_settings.get("vrrpEnabled"):
                if interface_settings.get("configType") != "ADDRESSED":
                    continue
                if not interface_settings.get("vrrpId") or not interface_settings.get(
                    "vrrpPriority"
                ):
                    logger.info(
                        "Missing VRRP Config: %s, %s",
                        str(interface_settings.get("vrrpId")),
                        str(interface_settings.get("vrrpPriority")),
                    )
                    continue
                if not interface_settings.get("vrrpAliases") or not interface_settings.get(
                    "vrrpAliases"
                ):
                    logger.info(
                        "Missing VRRP Aliases: %s", str(interface_settings.get("vrrpAliases"))
                    )
                    continue
                if len(interface_settings.get("vrrpAliases")) < 1:
                    logger.info(
                        "Missing VRRP Aliases (0 length): %i",
                        len(interface_settings.get("vrrpAliases")),
                    )
                    continue
                vrrp_interfaces.append(interface_settings)

        return vrrp_interfaces

    def write_keepalivd_conf(self, settings, prefix="") -> None:
        filename = prefix + self.keepalived_conf_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        vrrp_interfaces = self.get_vrrp_interfaces(settings)

        file = open(filename, "w+")
        file.write("! Auto Generated\n")
        file.write("! DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        if len(vrrp_interfaces) < 1:
            file.flush()
            file.close()
            logger.info("Wrote %s", str(filename))
            return

        file.write(r"""
global_defs {
}
""")
        file.write("\n\n")

        file.write("vrrp_sync_group VRRPGROUP {" + "\n")
        file.write("\tgroup {" + "\n")
        file.writelines(
            "\t\tVI_" + str(intf.get("interfaceId")) + "\n" for intf in vrrp_interfaces
        )
        file.write("\t}" + "\n")
        file.write("}" + "\n")
        file.write("\n\n")

        for intf in vrrp_interfaces:
            main_list = intf.get("vrrpAliases")

            file.write("vrrp_instance VI_" + str(intf.get("interfaceId")) + " {" + "\n")
            file.write("\tstate MASTER" + "\n")
            # file.write("\tdont_track_primary" + "\n") # http://s.co.tt/2014/06/06/fix-for-keepalived-router-enters-fault-state-on-link-down/
            file.write("\tinterface {}".format(str(intf.get("symbolicDev"))) + "\n")
            file.write(
                "\tlvs_sync_daemon_interface {}".format(str(intf.get("symbolicDev"))) + "\n"
            )
            file.write("\tvirtual_router_id {}".format(str(intf.get("vrrpId"))) + "\n")
            file.write("\tpriority {}".format(str(intf.get("vrrpPriority"))) + "\n")
            file.write("\tadvert_int 1" + "\n")

            file.write("\tvirtual_ipaddress {" + "\n")

            file.writelines(
                "\t\t{}/{}".format(str(alias.get("staticAddress")), str(alias.get("staticPrefix")))
                + "\n"
                for alias in main_list
            )
            file.write("\t}" + "\n")

            file.write("}" + "\n")
            file.write("\n\n")
        file.write("\n\n")

        file.flush()
        file.close()
        logger.info("Wrote %s", str(filename))
        return

    def write_zebra_conf(self, settings, prefix="") -> None:
        """
        Modify zebra configuration with default settings
        """
        filename = prefix + self.zebra_conf_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write(rf"""
! {self.auto_generated_comment}
! {self.do_not_edit_comment}
hostname {self.hostname}
password {self.password}
enable password {self.password}

ip forwarding
line vty
""")

        file.write("\n")
        file.flush()
        file.close()
        logger.info("Wrote %s", str(filename))

    def write_post_network_hook(self, settings, prefix="") -> None:
        filename = prefix + self.post_network_hook_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")
        # Covering the upgrade scenario, if keepalived is configured.
        file.write(r"""
if [ ! -z "`pidof keepalived`" ] ; then
    killall keepalived
    sleep 5
    killall -9 keepalived
fi
""")
        file.write("\n\n")

        vrrp_interfaces = self.get_vrrp_interfaces(settings)
        if len(vrrp_interfaces) > 0:
            self.vrrp_enabled = True
        else:
            self.vrrp_enabled = False

        if self.vrrp_enabled:
            file.write("if lsmod | grep -q ip_vs ; then" + "\n")
            file.write("\ttrue # do nothing" + "\n")
            file.write("else" + "\n")
            file.write("\techo Loading ip_vs kernel module..." + "\n")
            file.write("\tmodprobe ip_vs" + "\n")
            file.write("fi" + "\n")
            file.write("\n")

            file.write(
                "/usr/sbin/keepalived --vrrp -f /etc/keepalived/keepalived.conf --dump-conf --log-console --log-detail"
                "\n"
            )

            # Added for vrrp with frr rollback purpose
            # if vrrp is enabled, vrrp interfaces should be deleted.
            # Get current interface information from the system directly
            interfaces = psutil.net_if_addrs()
            system_vrrp_interfaces = [iface for iface in interfaces if iface.startswith("vrrp-")]
            if len(system_vrrp_interfaces) > 0:
                for intf_name in system_vrrp_interfaces:
                    file.write(f"    ip link delete {intf_name}" + "\n")
                    file.write("\n")
                    logger.debug("Deleting vrrp interface: %s", str(intf_name))
                logger.info("Deleted all vrrp interfaces")
        else:
            file.write("if lsmod | grep -q ip_vs ; then" + "\n")
            file.write("\techo Unloading ip_vs kernel module..." + "\n")
            file.write("\tmodprobe -r ip_vs" + "\n")
            file.write("else" + "\n")
            file.write("\ttrue # do nothing" + "\n")
            file.write("fi" + "\n")
            file.write("\n")
        file.write("\n\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_iptables_hook(self, settings, prefix="") -> None:
        filename = prefix + self.iptables_hook_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/dash")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        if self.vrrp_enabled:
            file.write(
                '${IPTABLES} -t filter -I access-rules -p vrrp -m comment --comment "Allow VRRP" -j RETURN'
                "\n"
            )

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(VrrpManager())
