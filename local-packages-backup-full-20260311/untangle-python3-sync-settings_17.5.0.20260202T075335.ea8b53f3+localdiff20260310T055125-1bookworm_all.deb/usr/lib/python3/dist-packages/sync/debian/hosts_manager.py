import os
import re

from sync import Manager, registrar
from sync.common import Logger
from sync.hosts_util import HostsUtil

# This class is responsible for writing /etc/hosts and /etc/hostname
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class HostsManager(Manager):
    hosts_filename = "/etc/hosts"
    hostname_filename = "/etc/hostname"
    mailname_filename = "/etc/mailname"
    resolv_filename = "/etc/resolv.conf"
    pre_network_hook_filename = "/etc/untangle/pre-network-hook.d/001-sethostname"

    def initialize(self) -> None:
        registrar.register_settings_file("network", self)
        registrar.register_file(self.hosts_filename, None, self)
        registrar.register_file(self.hostname_filename, "update-hostname", self)
        registrar.register_file(self.mailname_filename, None, self)
        registrar.register_file(self.resolv_filename, None, self)
        registrar.register_file(self.pre_network_hook_filename, "restart-networking", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        HostsUtil.write_hostname_file(self.hostname_filename, settings_file.settings, prefix)
        self.write_hosts_file(settings_file.settings, prefix)
        self.write_resolve_file(settings_file.settings, prefix)
        self.write_mailname_file(settings_file.settings, prefix)
        HostsUtil.write_pre_network_hook_file(
            self.pre_network_hook_filename, settings_file.settings, prefix
        )

    def write_hosts_file(self, settings, prefix) -> None:
        filename = prefix + self.hosts_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")

        file.write(r"""
127.0.0.1  localhost localhost.localdomain

::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
ff02::3 ip6-allhosts

""")
        if "hostName" in settings:
            hostname = settings["hostName"]
            re.match(r".*?\.", hostname)

            # write hostname
            file.write(f"127.0.0.1\t{hostname}" + "\n")
            if settings.get("domainName") is not None:
                file.write("127.0.0.1\t{}.{}".format(hostname, settings.get("domainName")) + "\n")
            file.write("\n")

        file.write("# user-defined static entries \n")
        if (
            settings.get("dnsSettings") is not None
            and settings.get("dnsSettings").get("staticEntries") is not None
        ):
            for entry in settings.get("dnsSettings").get("staticEntries"):
                if entry.get("name") is not None and entry.get("address") is not None:
                    file.write("{}\t{}".format(entry.get("address"), entry.get("name")) + "\n")
            file.write("\n")

        file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_mailname_file(self, settings, prefix) -> None:
        if "domainName" not in settings:
            logger.error("Missing domainName setting")
            return

        filename = prefix + self.mailname_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("{}.{}\n".format(settings.get("hostName"), settings.get("domainName")))

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))
        return

    def write_resolve_file(self, settings, prefix) -> None:
        if "hostName" not in settings:
            logger.error("Missing hostname setting")
            return

        filename = prefix + self.resolv_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")

        file.write("\n")
        file.write("nameserver 127.0.0.1" + "\n")
        if settings.get("domainName") is not None:
            file.write("search {}".format(settings.get("domainName")) + "\n")
        file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))
        return


registrar.register_manager(HostsManager())
