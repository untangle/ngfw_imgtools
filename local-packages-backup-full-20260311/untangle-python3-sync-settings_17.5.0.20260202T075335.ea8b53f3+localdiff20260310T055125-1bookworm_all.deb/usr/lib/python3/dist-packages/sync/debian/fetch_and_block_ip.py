"""
Fetches lists of IPs from given URLs and manages corresponding ipsets for blocking.
"""

import argparse
import collections
import json
import logging
import os
import re
import subprocess
import sys
import traceback
from datetime import datetime

import requests
import uvm

from sync.common import Logger
from sync.common.fetch_ip_list import FetchIpList

# Configure logging
logger = logging.getLogger(__name__)
internal_logger = Logger.getInstance()


class NgfwDynamicBlockListSetup:
    """
    Handles fetching, managing, and updating NGFW dynamic IP block lists.
    This includes creating, populating, swapping, and destroying ipsets
    that represent dynamic block lists.
    """

    def remove_and_destroy_disabled_entry(self, mainlist_ipset_name, ipset_name):
        """
        Removes and destroys an ipset that has been disabled.
        """
        if self.ipset_exists(self, "dblsets") and self.check_entry_in_parent_list(
            self, "dblsets", ipset_name
        ):
            logger.debug(f"Removing and destroying disabled ipset: {ipset_name}")
            self.remove_and_destroy_ipset(self, mainlist_ipset_name, ipset_name)

    def remove_and_destroy_ipset(self, mainlist_ipset_name, ipset_name):
        """
        Removes an ipset from its parent and destroys it.
        """
        try:
            subprocess.run(["sudo", "ipset", "del", mainlist_ipset_name, ipset_name], check=False)
            logger.debug(f"Removed ipset {ipset_name} from {mainlist_ipset_name}")
        except subprocess.CalledProcessError as e:
            logger.warning(f"Error removing {ipset_name} from {mainlist_ipset_name}: {e}")

        try:
            subprocess.run(["sudo", "ipset", "destroy", ipset_name], check=False)
            logger.debug(f"Destroyed ipset {ipset_name}")
        except subprocess.CalledProcessError as e:
            logger.warning(f"Error destroying ipset {ipset_name}: {e}")

    def add_ips_from_file_to_ipset(self, file_path, list_id):
        """
        Reads IPs from a file and adds them to appropriate ipsets.
        CIDR or range entries are placed in `cidr_list`, while others go to the given list ID.
        """
        ip_list_created = False
        net_list_created = False

        try:
            with open(file_path) as file:
                for line in file:
                    ip = line.strip()
                    if not ip:
                        continue

                    if "/" in ip or "-" in ip:
                        if not net_list_created:
                            self.create_ipset("cidr_list", "hash:net")
                            net_list_created = True
                        self.add_ip_to_ipset("cidr_list", ip)
                    else:
                        if not ip_list_created:
                            self.create_ipset(list_id, "hash:ip")
                            self.create_ipset(f"{list_id}tmp", "hash:ip")
                            ip_list_created = True
                        self.add_ip_to_ipset(f"{list_id}tmp", ip)
        except Exception as e:
            logger.warning(f"Error adding IPs from file {file_path}: {e}")

    def add_ip_to_ipset(self, ipset_name, ip):
        """
        Adds an IP to a given ipset.
        Skips adding if the IP already exists (for cidr_list).
        """
        if ipset_name == "cidr_list" and self.check_entry_in_parent_list(ipset_name, ip):
            logger.debug(f"IP {ip} already in ipset {ipset_name}, skipping.")
            return

        try:
            subprocess.run(["sudo", "/sbin/ipset", "add", ipset_name, ip], check=False)
            logger.debug(f"Added IP {ip} to ipset {ipset_name}")
        except subprocess.CalledProcessError as e:
            logger.warning(f"Failed to add IP {ip} to {ipset_name}: {e}")

    def ipset_exists(self, ipset_name):
        """
        Checks if an ipset exists.
        """
        try:
            result = subprocess.run(
                ["sudo", "/sbin/ipset", "list", ipset_name],
                capture_output=True,
                text=True,
                check=False,
            )
            return result.returncode == 0
        except subprocess.CalledProcessError:
            return False

    def create_ipset(self, ipset_name, ipset_type):
        """
        Creates an ipset if it does not already exist.
        """
        try:
            if self.ipset_exists(ipset_name):
                logger.debug(f"ipset {ipset_name} already exists.")
                return

            subprocess.run(["sudo", "/sbin/ipset", "create", ipset_name, ipset_type], check=False)
            logger.debug(f"Created ipset {ipset_name} ({ipset_type})")

            if "tmp" not in ipset_name and not self.check_entry_in_parent_list(
                "dblsets", ipset_name
            ):
                subprocess.run(["sudo", "/sbin/ipset", "add", "dblsets", ipset_name], check=False)
                logger.debug(f"Added {ipset_name} to parent dblsets")
        except subprocess.CalledProcessError as e:
            logger.warning(f"Error creating ipset {ipset_name}: {e}")

    def check_entry_in_parent_list(self, ipset_name, entry):
        """
        Checks if an entry exists within an ipset.
        """
        try:
            result = subprocess.run(
                ["sudo", "/sbin/ipset", "test", ipset_name, entry],
                capture_output=True,
                text=True,
                check=False,
            )
            return result.returncode == 0
        except subprocess.CalledProcessError:
            return False

    def swap_and_remove_ipsets(self, tmp_ipset, actual_ipset):
        """
        Swaps a temporary ipset with its active counterpart and destroys the temp set.
        """
        if not self.ipset_exists(tmp_ipset):
            return

        try:
            subprocess.run(["sudo", "/sbin/ipset", "swap", tmp_ipset, actual_ipset], check=False)
            subprocess.run(["sudo", "/sbin/ipset", "destroy", tmp_ipset], check=False)
            logger.debug(f"Swapped and removed tmp ipset {tmp_ipset} to {actual_ipset}")
        except subprocess.CalledProcessError as e:
            logger.warning(f"Error during ipset swap/removal: {e}")

    @staticmethod
    def set_response(url):
        """
        Fetches the given URL and determines the number of entries.
        Uses the current time as the last updated timestamp.
        If the request fails or returns a non-200 status code, sets count and last_updated to -1 and 0 respectively.
        """
        try:
            response = requests.get(url)
            response.raise_for_status()

            lines = response.text.splitlines()
            count = len(lines) - 1  # Assuming first line is header
            last_updated = int(datetime.now().timestamp())
        except requests.exceptions.RequestException as e:
            logger.warning(f"Error fetching URL {url}: {e}")
            count = -1
            last_updated = 0

        return count, last_updated

    def update_settings(self, settings_file, list_id):
        """
        Updates the count and lastUpdated fields in the dynamic block list settings file.
        """
        internal_logger.debug(f"Loading settings from file: {settings_file}")

        settings = self.get_settings_from_file(self, settings_file)
        config_list = settings.get("configurations", {}).get("list", [])
        internal_logger.debug(f"Found {len(config_list)} configuration(s).")

        for i, config in enumerate(config_list):
            internal_logger.debug(f"Processing entry [{i}]")
            if config.get("enabled") and config.get("id") == list_id:
                count, last_updated = NgfwDynamicBlockListSetup.set_response(config["source"])
                config["count"] = count
                config["lastUpdated"] = last_updated
                internal_logger.info(
                    f"Updated entry {list_id}: count={count}, lastUpdated={last_updated}"
                )

        with open(settings_file, "w") as file:
            json.dump(settings, file, indent=4)
            internal_logger.debug(f"Settings written to {settings_file}")

        # Load updated settings into app
        internal_logger.info("Reloading settings into dynamic-blocklists app...")
        app_manager = uvm.Uvm().getUvmContext().appManager()
        app = app_manager.app("dynamic-blocklists")

        if app is None:
            internal_logger.error("dynamic-blocklists app not installed. Exiting.")
            sys.exit(0)

        app.loadSettings()
        sys.exit(0)

    @staticmethod
    def get_settings_from_file(self, file_name):
        """
        Loads a JSON settings file into a Python dictionary.
        """
        try:
            with open(file_name) as f:
                return json.load(f, object_pairs_hook=collections.OrderedDict)
        except OSError as e:
            logger.error(f"Unable to read settings file {file_name}: {e}")
            traceback.print_exc()
            return {}


def main():
    """
    CLI entry point — fetches IP list, writes to file, updates ipsets, and optionally updates settings.
    """
    parser = argparse.ArgumentParser(
        prog="Fetch IP list",
        description="Fetches lists of IPs and sets them in ipset",
    )
    parser.add_argument("id", help="GUID")
    parser.add_argument("source_url", help="The source URL of the list")
    parser.add_argument("file_path", help="The output file path")
    parser.add_argument(
        "disable_cert_check",
        choices=["True", "true", "false", "False"],
        metavar="disable_cert_check [True, False]",
        help="Ignore cert check",
    )
    parser.add_argument("ip_regex", type=str, help="Regex for parsing IPs")
    parser.add_argument("setting_file", type=str, help="Settings file for DBL")
    parser.add_argument(
        "is_update_settings",
        choices=["True", "true", "false", "False"],
        metavar="is_update_settings [True, False]",
        help="Update settings flag",
    )

    args = parser.parse_args()

    # Normalize boolean arguments
    args.is_update_settings = args.is_update_settings.lower() == "true"
    args.disable_cert_check = args.disable_cert_check.lower() == "true"

    # Validate regex
    try:
        re.compile(args.ip_regex)
    except re.error as e:
        logger.error(f"Invalid regex: {e}")
        sys.exit(1)

    fetcher = FetchIpList()
    ipset_manager = NgfwDynamicBlockListSetup()

    ip_list, fetch_success = fetcher.fetch_ips_from_source(
        args.source_url, args.ip_regex, args.disable_cert_check
    )
    is_cidr_ip = any("/" in ip or "-" in ip for ip in ip_list)
    is_fetch_empty = fetch_success == ""

    # If file doesn't exist yet and we're updating, create it
    if not os.path.exists(args.file_path) and args.is_update_settings:
        open(args.file_path, "w").close()

    file_written = fetcher.save_ips_to_file(ip_list, args.file_path, is_fetch_empty)
    if is_fetch_empty and (file_written or is_cidr_ip):
        ipset_manager.add_ips_from_file_to_ipset(args.file_path, args.id)
        ipset_manager.swap_and_remove_ipsets(f"{args.id}tmp", args.id)

    if args.is_update_settings:
        ipset_manager.update_settings(args.setting_file, args.id)
    elif not fetch_success:
        sys.exit(2)


if __name__ == "__main__":
    main()
