from sync.common.creators.base_creator import Creator
from sync.common.sanitizers.base_sanitizer import Sanitizer
from sync.common.validators.base_validator import Validator


class Manager:
    """
    Base manager class with stub methods
    """

    def __init__(self, creator=None, validator=None, sanitizer=None) -> None:
        """
        Initialize local instance variables
        """
        self.rule_managers = []
        self.creator = creator or Creator()
        self.validator = validator or Validator()
        self.sanitizer = sanitizer or Sanitizer()

    def initialize(self) -> None:
        """
        Initialization.
        Here managers call register methods to associate
        files with operations, settings_file identifiers the
        manager is interested in, etc.
        """

    def sanitize_settings_pre(self, settings_file) -> None:
        """
        Perform sanitization on settings meant to be written back before other calls.
        """

    def sanitize_settings(self, settings_file) -> None:
        """
        Perform sanitization on settings meant to be written back.
        """
        self.sanitizer.sanitize(settings_file)

    def sanitize_settings_post(self, settings_file) -> None:
        """
        Perform sanitization on settings meant to be written back after other calls.
        """

    def validate_settings(self, settings_file) -> None:
        """
        Perform validation of settings
        """
        self.validator.validate(settings_file)

    def upgrade_settings(self, settings_file) -> None:
        """
        Upgrade settings.
        """

    def archive_settings(self, settings_file) -> None:
        """
        Archive settings for future reference
        """

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """
        Create new settings for the appropriate settings_file.
        """
        # NOTE: Python class variables won't wok as we currently fork for call_without_permissions()
        self.creator.create(settings_file)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Create appropriate system files from settings.
        """
        # NOTE: Python class variables won't wok as we currently fork for call_without_permissions()

    def get_rule_managers(self):
        """
        Get list of rule manager objects.
        """
        return self.rule_managers
