"""This class is responsible for converting firewall table rules into EOS ACL CLI commands"""

import json
import os

import sync.eos.utils as EosCommon
from sync import Manager, registrar
from sync.common import Logger
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE
from sync.eos.network_policy_manager import NetworkPolicyManager
from sync.eos.rule_utility import AclRule, RuleDecoder
from sync.settings_file import SettingsFile

CONTROL_PLANE_INGRESS_ACL_NAME = "control_plane_ingress"

logger = Logger.getInstance()


class AclManager(Manager):
    """AclManager writes Sysdb ACL config"""

    ACL_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}acl.cfg"

    def initialize(self) -> None:
        """initialize ACL module"""
        registrar.register_settings_file("settings", self)
        self.filename = os.path.join(EosCommon.CONFIG_ALWAYS_DIR, self.ACL_CONFIG_FILENAME)
        # egress interface ACL list
        self.egress_interfaces = []

        registrar.register_file(
            self.filename,
            "eos-config-always",
            self,
        )

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""

        # Get the new converted ACL config file based on the updated settings.json
        ingress_acl_policy_manager = InterfaceIngressAclPolicyManager(settings_file)
        config = ingress_acl_policy_manager.get_config_cmds()

        control_plan_ingress_manager = ControlPlaneIngressAclPolicyManager(settings_file)
        config = f"{config}\n{control_plan_ingress_manager.get_config_cmds()}"

        # write to file
        dirname = os.path.join(prefix, EosCommon.CONFIG_ALWAYS_DIR.strip("/"))
        os.makedirs(dirname, exist_ok=True)
        with open(os.path.join(dirname, self.ACL_CONFIG_FILENAME), "w") as f:
            f.write(config)
        logger.info("Wrote %s", str(self.filename))


class InterfaceIngressAclPolicyManager(NetworkPolicyManager):
    def get_apply_policy_cmds(self) -> list[str]:
        intf_list = self.settings_file.get_settings_by_path("network/interfaces")
        return apply_acls_to_interfaces(intf_list, self.settings_file, remove_acls=False)

    def get_remove_policy_cmds(self) -> list[str]:
        intf_list = self.settings_file.get_settings_by_path("network/interfaces")
        return apply_acls_to_interfaces(intf_list, self.settings_file, remove_acls=True)

    def get_attach_rules_to_policy_cmds(self) -> list[str]:
        return attach_rules_to_acls(self.settings_file)


def apply_acl_to_ingress_control_plane(*, remove_acls: bool = False) -> list[str]:
    negation_prefix = "no " if remove_acls else ""
    return [
        f"{negation_prefix}ip access-list {CONTROL_PLANE_INGRESS_ACL_NAME}",
        "system control-plane",
        f"   {negation_prefix}ip access-group {CONTROL_PLANE_INGRESS_ACL_NAME} in",
    ]


def attach_rules_to_acls(settings_file: SettingsFile) -> list[str]:
    """
    Create the ingress ACL attached to each interface.
    """
    intf_list = settings_file.get_settings_by_path("network/interfaces")
    json_rules = (
        settings_file.settings.get("firewall", {})
        .get("tables", {})
        .get("filter", {})
        .get("chains", [{"rules": []}])[0]
        .get("rules", [])
    )

    acl_rules: list[AclRule] = []
    for json_rule in json_rules:
        try:
            acl_rule = json.loads(json.dumps(json_rule), cls=RuleDecoder)
            if acl_rule.enabled:
                acl_rules.append(acl_rule)
        except NotImplementedError:
            logger.exception(
                f"Got not implemented error while decoding for ruleId: {json_rule.get('ruleId', 'non-existent ruleId')}"
            )

    cmds = []

    for intf in EosCommon.get_interfaces_with_acl_chains_attached(intf_list):
        acl_name = get_acl_name_from_intf_name(intf["device"])
        cmds.append(f"ip access-list {acl_name}")
        for acl_rule in acl_rules:
            # We don't have a way to support source interface zone, source interface type, destination interface zone,
            # destination interface type of conditions through EOS Cli access-lists. That's why we attach these ACL
            # rules to every interface's ingress access-list. So for now acl_rule.target.matches_interface would
            # evaluate to True for every interface with none of the source interface, destination interface conditions.
            if acl_rule.target.matches_interface(intf):
                cmds.append(f"   {acl_rule.conditions.to_eos_config(acl_rule.action.action_type)}")
        cmds.append("   permit ip any any")

    return cmds


def apply_acls_to_interfaces(
    intf_list, settings_file: SettingsFile, *, remove_acls: bool = False
) -> list[str]:
    """
    Adds ingress ACLs to each etX_XX interface if filter rules exist. If the remove_acls flag is set, removes them.
    If there are no filter rules, this allows any other access-group to be configured for any interface from the EOS Cli
    """
    cmds = []
    filter_rules_present = filter_rules_exist(settings_file)
    for intf in EosCommon.get_interfaces_with_acl_chains_attached(intf_list):
        intf_name_eos_cli = EosCommon.convert_intf_name_to_eos_cli_format(intf["device"])
        cmd_negation = "no " if remove_acls else ""

        # Attach access-group to the interface only if Filter rules exist in the settings.
        # But if this a remove ACL rules flow, remove the access-group in case it was attached earlier.
        if remove_acls or filter_rules_present:
            # Create access-list
            acl_name = get_acl_name_from_intf_name(intf["device"])
            cmds.append(f"{cmd_negation}ip access-list {acl_name}")
            intf_name = intf["device"]
            cmds.append(f"interface {intf_name_eos_cli}")
            cmds.append(
                f"   {cmd_negation}ip access-group {get_acl_name_from_intf_name(intf_name)} in"
            )
    return cmds


def get_acl_name_from_intf_name(intf_name: str) -> str:
    return f"{intf_name}_ingress"


def filter_rules_exist(settings_file):
    """
    filter_rules_exist is just a helper to figure out if we have any enabled filter rules existing in the settings.
    @returns: boolean - if the rules exist for filter table in the settings or not
    """
    # TODO: Once we start supporting conditions on the source interface (type/ zone), destination interface
    # (type/ zone), we should check the interface existing in the filter conditions to be more accurate.
    return any(
        rule.get("enabled")
        for rule in settings_file.settings.get("firewall", {})
        .get("tables", {})
        .get("filter", {})
        .get("chains", [{"rules": []}])[0]
        .get("rules", [])
    )


class ControlPlaneIngressAclPolicyManager(NetworkPolicyManager):
    def get_apply_policy_cmds(self) -> list[str]:
        return apply_acl_to_ingress_control_plane(remove_acls=False)

    def get_remove_policy_cmds(self) -> list[str]:
        return apply_acl_to_ingress_control_plane(remove_acls=True)

    def get_attach_rules_to_policy_cmds(self) -> list[str]:
        json_rules = (
            self.settings_file.settings.get("firewall", {})
            .get("tables", {})
            .get("access", {})
            .get("chains", [{"rules": []}])[0]
            .get("rules", [])
        )
        acl_rules: list[AclRule] = []
        for json_rule in json_rules:
            try:
                if json_rule.get("enabled"):
                    acl_rule = json.loads(json.dumps(json_rule), cls=RuleDecoder)
                    # Overwrite the rule_id field with the control plane name.
                    # The AclRules typically create access lists around a rule id. Here
                    # they're being used to add to the default control plane ACL on the
                    # system
                    acl_rule.settings_file = self.settings_file
                    acl_rule.rule_id = CONTROL_PLANE_INGRESS_ACL_NAME
                    acl_rules.append(acl_rule)
            except NotImplementedError:
                logger.exception("Could not add rule to Control Plane Ingress ACL!")

        return [f"{acl_rule.to_eos_config()}" for acl_rule in acl_rules]


registrar.register_manager(AclManager())
