"""This class is responsible for writing BGP config."""

from __future__ import annotations

import json
import os
from typing import Any
from uuid import uuid4

import sync.eos.utils as EosCommon
from sync import EncryptionUtil, Manager, SettingsFile, network_util, registrar
from sync.common import Logger
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE
from sync.eos.utils import convert_intf_name_to_eos_cli_format, is_valid_uuid
from sync.interface_util import get_interface_key_to_details_dict
from sync.settings_exception import SettingsException

logger = Logger.getInstance()

MIN_ASN_VALUE = 0
MAX_ASN_VALUE = 4294967295

BGP_DEFAULT_SETTINGS = {
    "local_asn": None,
    "router_id": None,
    "graceful_restart": False,
    "id": None,
    "advertised_networks": [],
    "neighbors": [],
}

NEIGHBOR_DEFAULT_SETTINGS = {
    "ip": None,
    "asn": None,
    "update_source": None,
    "keepalive": 60,
    "hold": 180,
    "password_encrypted": None,
    "id": None,
    "address_family": {
        "ipv4": False,
        "ipv6": False,
    },
}


class BgpManager(Manager):
    """BgpManager writes Sysdb BGP config."""

    BGP_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}bgp.cfg"

    def __init__(self) -> None:
        super().__init__()
        self.bgp_vrf_map = {}

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)

        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.BGP_CONFIG_FILENAME),
            "eos-config",
            self,
        )

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """
        Sanitizes BGP settings by ensuring required fields have default values.

        This method ensures that:
        - The 'bgp' key exists in settings (initialized to empty list if missing)
        - Each BGP router and neighbor has an 'id' field (UUID auto-generated if missing)
        - Neighbor passwords are encrypted and plain text passwords are removed

        :param settings_file: settings file to be sanitized
        :return: None
        """
        if settings_file.settings.get("bgp") is None:
            settings_file.settings["bgp"] = []
        bgp_settings_list: list[dict[str, Any]] = settings_file.settings["bgp"]

        for bgp_settings in bgp_settings_list:
            if not bgp_settings.get("id"):
                bgp_settings["id"] = str(uuid4())
            for neighbor in bgp_settings.get("neighbors", []):
                if not neighbor.get("id"):
                    neighbor["id"] = str(uuid4())

                # Encrypt passwords using EncryptionUtil
                if neighbor.get("password"):
                    try:
                        encrypted_password = EncryptionUtil.execute_password_manager(
                            "-e", neighbor.get("password")
                        )
                        neighbor["password_encrypted"] = encrypted_password
                        del neighbor["password"]
                    except RuntimeError:
                        raise Exception(json.dumps({"error": "password_manager_failure"}))

    def _validate_ids(self, bgp_settings: dict[str, Any]) -> None:
        """Validate the id in the BGP settings"""
        bgp_id = bgp_settings.get("id")
        if bgp_id and not is_valid_uuid(bgp_id):
            raise SettingsException(f"Invalid BGP id: '{bgp_id}' is not a valid UUID.")

    def validate_asn(
        self, asn: int | None, asn_type: str = "ASN", allow_zero: bool = True
    ) -> bool:
        """
        Validates that an ASN (Autonomous System Number) is within the valid range.

        Args:
            asn: The ASN value to validate (can be None for optional ASNs)
            asn_type: Description of the ASN type for error messages (e.g., "local_asn", "remote asn")
            allow_zero: Whether to allow ASN value of 0 (default True for neighbors, False for local_asn)

        Returns:
            True if valid

        Raises:
            SettingsException: If the ASN is invalid (None, not an int, or out of range)
        """
        if asn is None or not isinstance(asn, int):
            exc_msg = f"Invalid BGP {asn_type}: {asn}"
            raise SettingsException(exc_msg)

        # Check range based on allow_zero parameter
        min_allowed = MIN_ASN_VALUE if allow_zero else MIN_ASN_VALUE + 1

        if not (min_allowed <= asn <= MAX_ASN_VALUE):
            exc_msg = f"Invalid BGP {asn_type}: {asn}"
            raise SettingsException(exc_msg)

        return True

    def validate_timers(self, keepalive: int | None, hold: int | None) -> bool:
        """
        Checks if keepalive and hold timer settings are valid together.

        Valid states are:
        - Both have a value (are not None).
        - Both are None.

        Invalid states are:
        - One is None and the other has a value.
        """

        if (keepalive is None) != (hold is None):
            exc_msg = "BGP keepalive and hold timers must be integers and both must be present."
            raise SettingsException(exc_msg)
        if keepalive is not None and hold is not None and keepalive > hold:
            exc_msg = "BGP hold time must be greater than or equal to keepalive time."
            raise SettingsException(exc_msg)

        return True

    def validate_neighbor(self, neighbor: dict[str, Any] | None) -> None:
        """
        Validates a BGP neighbor's settings.
        Raises:
            SettingsException: If the neighbor settings are invalid.
        Returns:
            None.
        """
        if neighbor is None:
            raise SettingsException("BGP neighbor configuration cannot be empty.")

        neighbor_id = neighbor.get("id", "")
        if neighbor_id and not is_valid_uuid(neighbor_id):
            raise SettingsException(
                f"Invalid BGP neighbor id: '{neighbor_id}' for neighbor with IP: {neighbor.get('ip')} is not a valid UUID."
            )

        ip = neighbor.get("ip", "")
        if not network_util.is_valid_ip(str(ip)):
            raise SettingsException(f"Invalid IP address for BGP neighbor: {ip}")

        # Validate remote ASN (neighbor ASN)
        remote_asn = neighbor.get("asn")
        if remote_asn is None:
            raise SettingsException(f"BGP neighbor is missing 'asn': {neighbor}")
        self.validate_asn(remote_asn, f"remote asn for neighbor {ip}")

        password_encrypted = neighbor.get("password_encrypted")
        if not (password_encrypted is None or isinstance(password_encrypted, str)):
            raise SettingsException(
                f"BGP neighbor password_encrypted must be a string or null, but got {type(password_encrypted).__name__} for neighbor {ip}"
            )

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """Validate BGP settings."""
        bgp_settings_list: list[dict[str, Any]] = settings_file.settings.get("bgp", [])

        # Track unique local_asn (only one allowed across all VRFs) and VRFs
        local_asns = set()
        vrf_to_router_id = {}  # Maps VRF name to router_id to ensure one router per VRF

        vrfs = settings_file.settings.get("vrf", [])
        self.bgp_vrf_map = {
            vrf_details["bgp"]: vrf_details for vrf_details in vrfs if vrf_details.get("bgp")
        }

        for bgp_settings in bgp_settings_list:
            self._validate_bgp_settings(bgp_settings)

            local_asn = bgp_settings.get("local_asn")
            if local_asn is not None:
                local_asns.add(local_asn)
                # EOS allows multiple BGP routers (one per VRF) but they must all share the same local_asn
                if len(local_asns) > 1:
                    exc_msg = (
                        f"Multiple local_asn values detected: {sorted(local_asns)}. "
                        f"All BGP routers on a device must use the same local_asn."
                    )
                    raise SettingsException(exc_msg)

            # Validate that no 2 BGP routers can be under the same VRF
            vrf_obj = self.bgp_vrf_map.get(bgp_settings.get("id"))
            if not vrf_obj:
                continue

            vrf_name = vrf_obj.get("name")
            if not vrf_name:
                continue

            router_id = bgp_settings.get("router_id")

            if vrf_name in vrf_to_router_id:
                existing_router_id = vrf_to_router_id[vrf_name]
                exc_msg = (
                    f"Duplicate BGP router in VRF '{vrf_name}'. "
                    f"VRF already has router with router_id {existing_router_id}, "
                    f"cannot add another router with router_id {router_id}."
                )
                raise SettingsException(exc_msg)

            if router_id is not None:
                vrf_to_router_id[vrf_name] = router_id

    def _validate_bgp_settings(self, bgp_settings: dict[str, Any]) -> bool:
        """
        Validate BGP settings.

        Args:
            bgp_settings: The BGP settings to validate.

        Returns:
            True if the settings are valid, False otherwise.
        """
        if not bgp_settings:
            return True

        self._validate_required_fields(bgp_settings)
        self._validate_ids(bgp_settings)
        self._validate_local_asn(bgp_settings)
        self._validate_router_id(bgp_settings)
        self._validate_timers(bgp_settings)
        self._validate_advertised_networks(bgp_settings)
        self._validate_neighbors_details(bgp_settings)

        return True

    def _validate_required_fields(self, bgp_settings: dict[str, Any]) -> None:
        """Validate that all required fields are present in the BGP settings."""
        err_msgs = []
        required_fields = set(BGP_DEFAULT_SETTINGS.keys()) - {"graceful_restart"}
        for field in required_fields:
            if field not in bgp_settings:
                msg = f"Missing BGP setting: {field}"
                err_msgs.append(msg)

        neighbors = bgp_settings.get("neighbors", [])
        if not isinstance(neighbors, list):
            raise SettingsException("BGP neighbors must be a list.")

        required_neighbor_fields = set(NEIGHBOR_DEFAULT_SETTINGS.keys()) - {
            "update_source",
            "keepalive",
            "hold",
            "password_encrypted",
        }
        for i, neighbor in enumerate(neighbors):
            for field in required_neighbor_fields:
                if field not in neighbor:
                    msg = f"Missing BGP neighbor setting: {field} for neighbor {i + 1}"
                    err_msgs.append(msg)

        if len(err_msgs) != 0:
            str_msg = "\n".join(err_msgs)
            raise SettingsException(str_msg)

    def _validate_local_asn(self, bgp_settings: dict[str, Any]) -> None:
        """Validate the local_asn in the BGP settings. Zero is not allowed for local_asn."""
        local_asn = bgp_settings.get("local_asn")
        self.validate_asn(local_asn, "local_asn", allow_zero=False)

    def _validate_router_id(self, bgp_settings: dict[str, Any]) -> None:
        """Validate the router_id in the BGP settings."""
        router_id = bgp_settings.get("router_id")
        if router_id is not None and not network_util.is_valid_ip(router_id):
            exc_msg = f"Invalid BGP router_id: {router_id}"
            raise SettingsException(exc_msg)

    def _validate_timers(self, bgp_settings: dict[str, Any]) -> None:
        """Validate the keepalive and hold timers in the BGP settings."""
        neighbors = bgp_settings.get("neighbors", [])
        for neighbor in neighbors:
            keepalive = neighbor.get("keepalive")
            hold = neighbor.get("hold")
            self.validate_timers(keepalive, hold)

    def _validate_advertised_networks(self, bgp_settings: dict[str, Any]) -> None:
        """Validate the advertised_networks in the BGP settings."""
        advertised_networks = bgp_settings.get("advertised_networks", [])
        if not isinstance(advertised_networks, list):
            exc_msg = "BGP advertised_networks must be a list."
            raise SettingsException(exc_msg)
        for network in advertised_networks:
            if not network_util.is_valid_network_cidr(network):
                exc_msg = f"Invalid advertised network: {network}"
                raise SettingsException(exc_msg)

    def _validate_neighbors_details(self, bgp_settings: dict[str, Any]) -> None:
        """Validate the neighbor details in the BGP settings."""
        neighbors = bgp_settings.get("neighbors", [])
        for neighbor in neighbors:
            self.validate_neighbor(neighbor)

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, _delete_list: list[str]
    ) -> None:
        """Syncs settings."""
        logger.info("Syncing BGP settings")

        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        config = self.get_bgp_commands(settings_file.settings)

        # write to file
        with open(os.path.join(dirname, self.BGP_CONFIG_FILENAME), "w") as f:
            f.write(config)

    def reset_bgp_config(self, bgp_settings: list[dict[str, Any]], bgp_vrf_names: set) -> str:
        """
        Generate commands to remove stale BGP config.
        Args:
            bgp_settings: The current bgp settings.
            bgp_vrf_names: vrf names for all bgps
        Returns:
            The commands to remove stale BGP config as a string.
        """
        cmds = []
        local_asn = bgp_settings[0].get("local_asn") if bgp_settings else None

        if local_asn is None:
            return "!\nno router bgp\n!\n"

        bgp_running_configs = EosCommon.get_running_config_section("bgp")
        if bgp_running_configs:
            remove_configs = EosCommon.remove_old_bgp_configs(bgp_running_configs, bgp_vrf_names)
            if remove_configs:
                cmds.append("\nrouter bgp " + str(local_asn))
                cmds.extend(remove_configs)
                cmds.append("!\n")
        return "\n".join(cmds)

    def get_bgp_commands(self, settings: dict[str, Any]) -> str:
        """
        Generate BGP config file from the settings.

        Args:
            settings: The current settings.

        Returns:
            The BGP configuration as a string.
        """
        # Clear the configs first
        all_commands: list[str] = []
        bgp_settings_list = settings.get("bgp", [])
        bgp_vrf_names = {vrf.get("name") for vrf in self.bgp_vrf_map.values() if vrf.get("name")}
        all_commands.append(self.reset_bgp_config(bgp_settings_list, bgp_vrf_names))
        interface_map = get_interface_key_to_details_dict(settings, key_name="name")

        for bgp_settings in bgp_settings_list:
            bgp_id = bgp_settings.get("id", "")
            if not bgp_id:
                continue

            local_asn = bgp_settings.get("local_asn")

            commands = [f"router bgp {local_asn}"]

            vrf_details = self.bgp_vrf_map.get(bgp_id)
            if not vrf_details:
                continue

            vrf_name = vrf_details.get("name")
            if not vrf_name:
                continue

            if vrf_name != "default":
                commands.append(f"  vrf {vrf_name}")
                if rd := vrf_details.get("rd"):
                    commands.append(f"  rd {rd}")

            router_id = bgp_settings.get("router_id")
            if router_id is not None:
                commands.append(f"  router-id {router_id}")

            graceful_restart = bgp_settings.get("graceful_restart", True)
            if not graceful_restart:
                commands.append("  no graceful-restart")
            else:
                commands.append("  graceful-restart")

            # Add advertised networks
            advertised_networks = bgp_settings.get("advertised_networks", [])
            commands.extend([f"  network {network}" for network in advertised_networks])

            # Add neighbors
            neighbors = bgp_settings.get("neighbors", [])
            for neighbor in neighbors:
                commands = self.get_bgp_neighbor_commands(
                    neighbor, commands, interface_map, local_asn
                )

            commands.append("  !")  # Exit BGP context

            commands.append("!")  # Exit commands
            all_commands.extend(commands)

        return "\n".join(all_commands)

    def get_bgp_neighbor_commands(
        self,
        neighbor: dict[str, Any],
        commands: list[str],
        interface_map: dict[str, dict[str, Any]],
        local_asn: int,
    ) -> list[str]:
        """
        Generate BGP neighbor configuration commands.

        Args:
            neighbor: The neighbor configuration dictionary.
            commands: The existing list of commands to append to.
            interface_map: Mapping of interface keys to interface details.
            local_asn: The local ASN of the BGP router.

        Returns:
            The updated list of commands with neighbor configuration added.
        """
        neighbor_ip = neighbor["ip"]
        neighbor_asn = neighbor["asn"]
        commands.append(f"  neighbor {neighbor_ip} remote-as {neighbor_asn}")

        # Only add ebgp-multihop for eBGP neighbors (different ASN)
        if neighbor_asn != local_asn:
            commands.append(f"  neighbor {neighbor_ip} ebgp-multihop")
        if device_name := interface_map.get(neighbor.get("update_source", ""), {}).get("name"):
            eos_device_name = convert_intf_name_to_eos_cli_format(device_name)
            commands.append(f"  neighbor {neighbor_ip} update-source {eos_device_name}")

        if neighbor.get("password_encrypted"):
            # Decrypt the encrypted password to get plain text for EOS CLI configuration.
            # From Cli, if the user adds an MD5-encrypted password using 7 as encrypt level, we always store
            # the plain-text password in the SuperServer flow and encrypt it before storing in settings.json.
            # Here, we decrypt the password and use encrypt level '0' since the string following '0'
            # will always be a plain-text password in EOS CLI.
            plain_text_password = EncryptionUtil.execute_password_manager(
                "-d", neighbor["password_encrypted"]
            )
            commands.append(f"  neighbor {neighbor_ip} password 0 {plain_text_password}")
        else:
            commands.append(f"  no neighbor {neighbor_ip} password")

        if neighbor.get("keepalive"):
            keepalive = neighbor["keepalive"]
            hold = neighbor["hold"]
            commands.append(f"  neighbor {neighbor_ip} timers {keepalive} {hold}")

        # Address family settings for the neighbor
        # Can activate ipv4 only, ipv6 only, both, or none
        address_family = neighbor.get("address_family", {})
        ipv4_enabled = address_family.get("ipv4", False)
        ipv6_enabled = address_family.get("ipv6", False)

        # Activate IPv4 address family if enabled
        if ipv4_enabled:
            commands.append("  address-family ipv4")
            commands.append(f"    neighbor {neighbor['ip']} activate")
            commands.append("    !")  # Exit address family

        # Activate IPv6 address family if enabled
        if ipv6_enabled:
            commands.append("  address-family ipv6")
            commands.append(f"    neighbor {neighbor['ip']} activate")
            commands.append("    !")  # Exit address family

        return commands


registrar.register_manager(BgpManager())
