"""Dynamic lists manager for EOS with cron.d style cron support"""

from sync import registrar
from sync.common.dynamic_lists_manager import CronDDynamicListsManager

registrar.register_manager(CronDDynamicListsManager())
