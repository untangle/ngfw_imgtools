# Copyright (c) 2023 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

"""This class is responsible for writing Vrf config."""

from __future__ import annotations

import os

# create/sync/sanitize settings functions are called in the order the managers
# register.
import sync.eos.utils as EosCommon
from sync import Manager, SettingsFile, registrar
from sync.common import Logger
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_EARLY
from sync.eos_util import StaleSysdbState
from sync.interface_util import get_all_interface_ids
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class VrfManager(Manager):
    """VrfManager writes Sysdb vrf config."""

    VRF_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_EARLY}vrf.cfg"

    def __init__(self, creator=None, validator=None, sanitizer=None) -> None:
        """Initialize VrfManager."""
        super().__init__()
        self.deleted_vrf_details = {}

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.VRF_CONFIG_FILENAME),
            "eos-config",
            self,
        )

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """
        Sanitizes VRF settings by ensuring required fields have default values.
        This is the main entry point that orchestrates all sanitization steps:
        - The 'vrf' key exists in settings (initialized to empty list if missing)
        - Each VRF object has default None values for optional GUID reference properties
        - Orphaned interface IDs (references to deleted interfaces) are removed from VRFs
        - All unassigned interfaces are rolled up under the default VRF
        :param settings_file: The settings file containing VRF configuration to sanitize
        :return: None (modifies settings_file.settings in-place)
        """
        self._ensure_vrf_list_exists(settings_file)
        self._add_default_guid_properties(settings_file)

        # Get all interface IDs once and pass to helper methods.
        all_interface_ids = get_all_interface_ids(settings_file.settings)
        self._remove_orphaned_interface_ids(settings_file, all_interface_ids)
        self._rollup_unassigned_interfaces_to_default_vrf(settings_file, all_interface_ids)

        self._get_deleted_vrfs(settings_file)
        self._remove_orphaned_vrf_entities(settings_file)

    def _ensure_vrf_list_exists(self, settings_file: SettingsFile) -> None:
        """
        Initialize empty VRF list if missing.
        :param settings_file: The settings file to check and modify
        :return: None (modifies settings_file.settings in-place)
        """
        if settings_file.settings.get("vrf") is None:
            settings_file.settings["vrf"] = []

        EosCommon.ensure_archive_structure(settings_file, "vrf")

    def _get_deleted_vrfs(self, settings_file):
        """
        Find entities for which vrf no longer exists
        :param settings_file: The settings file containing VRF and entities configuration
        :return: None. Populates deleted_vrf_details property of the object with deleted VRF's details.
        """

        vrfs = settings_file.settings.get("vrf", [])
        archived_vrfs = (
            settings_file.settings.get("archive", {}).get("last_run", {}).get("vrf", [])
        )

        current_vrf_names = [vrf["name"] for vrf in vrfs if vrf.get("name")]
        self.deleted_vrf_details = {
            archived_vrf.get("name"): {
                "routes": archived_vrf.get("routes"),
                "upstream_dns": archived_vrf.get("upstream_dns"),
                "dhcp": archived_vrf.get("dhcp"),
                "bgp": archived_vrf.get("bgp"),
            }
            for archived_vrf in archived_vrfs
            if archived_vrf.get("name") and archived_vrf["name"] not in current_vrf_names
        }

    def _remove_orphaned_vrf_entities(self, settings_file):
        """
        Remove entities for which the vrf no longer exists.
        This prevents validation errors when vrf is deleted but its respective entities still
        persists.

        This method removes entities (routes, upstream_dns, dhcp, bgp) that were exclusively
        assigned to deleted VRFs. If an entity is still referenced by other active VRFs,
        it will not be deleted.

        :param settings_file: The settings file containing VRF and entities configuration
        :return: None (modifies settings_file.settings in-place)
        """

        # Get all current VRFs to check for active references
        current_vrfs = settings_file.settings.get("vrf", [])

        # Collect all entity IDs currently referenced by active VRFs
        active_entity_refs = {
            "routes": set(),
            "upstream_dns": set(),
            "dhcp": set(),
            "bgp": set(),
        }

        for vrf in current_vrfs:
            for entity_type in active_entity_refs:
                entity_id = vrf.get(entity_type)
                if entity_id:
                    active_entity_refs[entity_type].add(entity_id)

        # Get all entity lists
        routes_all = settings_file.settings.get("routes", [])
        upstream_dns_all = settings_file.settings.get("upstream_dns", [])
        dhcp_all = settings_file.settings.get("dhcp", [])
        bgp_all = settings_file.settings.get("bgp", [])

        # Create ID-to-entity maps for quick lookup
        entity_maps = {
            "routes": {route.get("id"): route for route in routes_all},
            "upstream_dns": {dns.get("id"): dns for dns in upstream_dns_all},
            "dhcp": {dhcp.get("id"): dhcp for dhcp in dhcp_all},
            "bgp": {bgp_item.get("id"): bgp_item for bgp_item in bgp_all},
        }

        # Mapping of entity types to their corresponding lists
        entity_lists = {
            "routes": routes_all,
            "upstream_dns": upstream_dns_all,
            "dhcp": dhcp_all,
            "bgp": bgp_all,
        }

        def remove_orphaned_entity(
            entity_type: str,
            entity_id: str | None,
            archived_vrf_name: str,
        ) -> None:
            """
            Remove an entity if it exists, is not referenced by any active VRF.

            :param entity_type: Type of entity (routes, upstream_dns, dhcp, bgp)
            :param entity_id: GUID of the entity to potentially remove
            :param archived_vrf_name: Name of the deleted VRF (for logging)
            """
            if (
                entity_id
                and entity_id in entity_maps[entity_type]
                and entity_id not in active_entity_refs[entity_type]
            ):
                entity_lists[entity_type].remove(entity_maps[entity_type][entity_id])
                logger.info(
                    f"Removed {entity_type} config '{entity_id}' "
                    f"from deleted VRF '{archived_vrf_name}'"
                )

        # Delete entities from deleted VRFs that are not referenced by any active VRF
        for archived_vrf_name, archived_vrf_guids in self.deleted_vrf_details.items():
            # Handle all entity types
            remove_orphaned_entity("routes", archived_vrf_guids.get("routes"), archived_vrf_name)
            remove_orphaned_entity(
                "upstream_dns", archived_vrf_guids.get("upstream_dns"), archived_vrf_name
            )
            remove_orphaned_entity("dhcp", archived_vrf_guids.get("dhcp"), archived_vrf_name)
            remove_orphaned_entity("bgp", archived_vrf_guids.get("bgp"), archived_vrf_name)

    def _add_default_guid_properties(self, settings_file: SettingsFile) -> None:
        """
        Add default None values for GUID reference properties to all VRFs.
        This ensures each VRF has the standard VRF-aware service properties:
        dhcp, upstream_dns, routes, port-forward, nat, limiting, prioritization, bgp.
        :param settings_file: The settings file containing VRF configuration
        :return: None (modifies settings_file.settings in-place)
        """
        for vrf in settings_file.settings.get("vrf", []):
            if "dhcp" not in vrf:
                vrf["dhcp"] = None
            if "upstream_dns" not in vrf:
                vrf["upstream_dns"] = None
            if "routes" not in vrf:
                vrf["routes"] = None
            if "port-forward" not in vrf:
                vrf["port-forward"] = None
            if "nat" not in vrf:
                vrf["nat"] = None
            if "limiting" not in vrf:
                vrf["limiting"] = None
            if "prioritization" not in vrf:
                vrf["prioritization"] = None
            if "bgp" not in vrf:
                vrf["bgp"] = None

    def _remove_orphaned_interface_ids(
        self, settings_file: SettingsFile, all_interface_ids: set[int]
    ) -> None:
        """
        Remove interface IDs from VRF configurations that no longer exist in network.interfaces.

        This prevents validation errors when interfaces are deleted but VRF objects still
        reference them.

        :param settings_file: The settings file containing VRF and interface configuration
        :param all_interface_ids: Set of all valid interface IDs from network.interfaces
        :return: None (modifies settings_file.settings in-place)
        """

        # Remove orphaned interface IDs from each VRF
        for vrf in settings_file.settings.get("vrf", []):
            vrf_interfaces = vrf.get("interfaces", [])
            # Filter to keep only interface IDs that still exist
            valid_interfaces = [
                intf_id for intf_id in vrf_interfaces if intf_id in all_interface_ids
            ]

            # If we removed any orphaned IDs, log it and update the VRF
            if len(valid_interfaces) != len(vrf_interfaces):
                orphaned = set(vrf_interfaces) - set(valid_interfaces)
                logger.info(
                    f"Removed {len(orphaned)} orphaned interface ID(s) from VRF '{vrf.get('name')}': "
                    f"{sorted(orphaned)}"
                )
                vrf["interfaces"] = sorted(valid_interfaces)
            else:
                # Even if no orphaned IDs, ensure interfaces are sorted
                vrf["interfaces"] = sorted(valid_interfaces)

    def _rollup_unassigned_interfaces_to_default_vrf(
        self, settings_file: SettingsFile, all_interface_ids: set[int]
    ) -> None:
        """
        Roll up unassigned interfaces to the default VRF.

        Calculates: (all interfaces) - (interfaces in any custom VRF) = unassigned
        Then adds unassigned interfaces to default VRF if it exists.

        :param settings_file: The settings file containing VRF and interface configuration
        :param all_interface_ids: Set of all valid interface IDs from network.interfaces
        :return: None (modifies settings_file.settings in-place)
        """

        # Collect all interface IDs already assigned to VRFs
        assigned_interface_ids = set()
        default_vrf = None
        for vrf in settings_file.settings.get("vrf", []):
            if vrf.get("name") == "default":
                default_vrf = vrf
            vrf_interfaces = vrf.get("interfaces", [])
            assigned_interface_ids.update(vrf_interfaces)

        # Calculate unassigned interfaces
        unassigned_interface_ids = all_interface_ids - assigned_interface_ids

        # If there are unassigned interfaces, add them to the default VRF
        if unassigned_interface_ids and default_vrf is not None:
            # Ensure the default VRF has an interfaces list
            if "interfaces" not in default_vrf:
                default_vrf["interfaces"] = []

            # Add unassigned interfaces to default VRF
            default_vrf["interfaces"].extend(sorted(unassigned_interface_ids))
            logger.info(
                f"Rolled up {len(unassigned_interface_ids)} unassigned interface(s) "
                f"to default VRF: {sorted(unassigned_interface_ids)}"
            )

    def create_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list: list, filename: str
    ) -> None:
        """
        Creates VRF settings with only the default VRF.

        This method ensures the VRF list contains ONLY the default VRF by:
        - Creating a single default VRF object with:
          - Name: "default"
          - Description: "Default VRF"
          - RD: "" (empty string for default VRF)
          - Interfaces: All interface IDs from .network.interfaces (including management)
          - All GUID references set to None

        :param settings_file: The settings file to create VRF settings in
        :param prefix: Directory prefix for file operations (unused)
        :param delete_list: List to track files for deletion (unused)
        :param filename: Target filename (unused)
        :return: None (modifies settings_file.settings in-place)
        """
        logger.info("create_settings")

        # Get all interface IDs (including management interfaces)
        interface_ids = sorted(get_all_interface_ids(settings_file.settings))

        # Create default VRF object
        default_vrf = {
            "name": "default",
            "description": "Default VRF",
            "rd": "",
            "interfaces": interface_ids,
            "dhcp": None,
            "upstream_dns": None,
            "routes": None,
            "port-forward": None,
            "nat": None,
            "limiting": None,
            "prioritization": None,
            "bgp": None,
        }

        # Initialize the VRF list with only the default VRF
        settings_file.settings["vrf"] = [default_vrf]
        logger.info(
            f"Created VRF list with only default VRF containing {len(interface_ids)} interfaces"
        )

        EosCommon.ensure_archive_structure(settings_file, "vrf")

    def archive_settings(self, settings_file: SettingsFile) -> None:
        """Save vrfs for next run"""
        settings_file.settings["archive"]["last_run"]["vrf"] = settings_file.settings.get("vrf")

    def validate_vrf(self, vrf_obj: dict) -> None:
        """validates a single vrf"""
        self.validate_parameter(vrf_obj, "description", [str])
        self.validate_parameter(vrf_obj, "name", [str])
        self.validate_parameter(vrf_obj, "rd", [str])
        self.validate_parameter(vrf_obj, "interfaces", [list])

    def validate_parameter(
        self, parameters: dict, parameter_name: str, parameter_types: list
    ) -> None:
        """Validates parameters for type"""
        parameter_value = parameters.get(parameter_name)

        # Check if the parameter is missing or not of the correct type
        if parameter_value is None or not any(
            isinstance(parameter_value, type) for type in parameter_types
        ):
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["vrf", parameter_name]
            )

    def validate_vrf_interface_ids(self, vrf_obj: dict, all_intf_ids: set) -> None:
        """
        This checks if the provided interface ids for VRF are valid.
        It ensures that the given interfaces exist in network/interfaces.
        Management interfaces are allowed in VRFs (they will be in default VRF).

        :param vrf_obj: The VRF object to validate
        :param all_intf_ids: Set of all valid interface IDs (including management)
        """
        vrf_intf_ids = vrf_obj.get("interfaces", [])

        # Check that all VRF interface IDs are valid
        if not set(vrf_intf_ids).issubset(all_intf_ids):
            raise SettingsException(message="invalid_vrf_interfaces", vars=["vrf", "interfaces"])

    def validate_vrf_guid_references(self, vrf_obj: dict, settings_file: SettingsFile) -> None:
        """
        Validates that GUID references in VRF object point to valid entries in root-level settings.
        Each GUID reference property (dhcp, upstream_dns, routes, etc.) should reference an 'id'
        that exists in the corresponding root-level list.

        :param vrf_obj: The VRF object to validate
        :param settings_file: The settings file containing root-level configuration
        :raises SettingsException: If a referenced GUID does not exist in the corresponding setting
        """
        # Mapping of VRF property name to root-level settings key
        settings_keys = [
            "dhcp",
            "upstream_dns",
            "routes",
            "port-forward",
            "nat",
            "limiting",
            "prioritization",
            "bgp",
        ]

        for settings_key in settings_keys:
            guid_value = vrf_obj.get(settings_key)

            # Skip validation if GUID is None (optional reference)
            if guid_value is None:
                continue

            # Get the root-level list for this setting
            root_list = settings_file.settings.get(settings_key, [])

            # If root list doesn't exist and GUID is provided, it's invalid
            if not isinstance(root_list, list):
                raise SettingsException(
                    message="invalid_vrf_guid_reference",
                    vars=["vrf", settings_key, guid_value],
                )

            # Collect all valid IDs from the root-level list
            valid_ids = {
                item.get("id") for item in root_list if isinstance(item, dict) and "id" in item
            }

            # Check if the referenced GUID exists
            if guid_value not in valid_ids:
                raise SettingsException(
                    message="invalid_vrf_guid_reference",
                    vars=["vrf", settings_key, guid_value],
                )

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """
        Validates VRF settings.

        This method validates that:
        1. Default VRF is always present
        2. All interface IDs in VRFs are valid
        3. No interface is assigned to multiple VRFs
        4. All interfaces are assigned to exactly one VRF
        """
        logger.info("validate_settings")

        # Get all interface IDs once and reuse throughout validation
        # This includes ALL interfaces (management and non-management)
        all_interface_ids = get_all_interface_ids(settings_file.settings)

        present, vrfs = EosCommon.vrf_settings_present(settings_file)
        if not present:
            raise SettingsException(
                message="default_vrf_missing",
                vars=["vrf"],
            )

        # Validate that default VRF exists
        default_vrf_exists = any(vrf.get("name") == "default" for vrf in vrfs)
        if not default_vrf_exists:
            raise SettingsException(
                message="default_vrf_missing",
                vars=["vrf"],
            )

        vrf_interfaces = []
        for vrf in vrfs:
            self.validate_vrf(vrf)
            self.validate_vrf_interface_ids(vrf, all_interface_ids)
            self.validate_vrf_guid_references(vrf, settings_file)
            vrf_interfaces.extend(vrf.get("interfaces", []))

        """ Here, it makes sure that one interface is not attached to more than one vrfs"""
        vrf_interfaces_set = set(vrf_interfaces)
        if len(vrf_interfaces) != len(vrf_interfaces_set):
            raise SettingsException(
                message="one_or_more_vrfs_have_same_interfaces_attached",
                vars=["vrf", "interfaces"],
            )

        # Validate that all interfaces (including management) are assigned to exactly one VRF
        # Reuse the set we created at the beginning instead of calling get_interface_key_to_details_dict again
        if vrf_interfaces_set != all_interface_ids:
            # Not all interfaces assigned to VRF (this may indicate sanitization
            # failed to run or default VRF was missing during sanitization)
            raise SettingsException(
                message="not_all_interfaces_assigned_to_vrf",
                vars=["vrf", "interfaces"],
            )

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list: list[str]
    ) -> None:
        """Syncs settings."""
        logger.info("sync_settings")
        config = self.get_vrf_config(settings_file)

        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        file_path = os.path.join(EosCommon.CONFIG_DIR, self.VRF_CONFIG_FILENAME)
        # Remove stale sysdb states
        if os.path.isfile(file_path) and (os.path.getsize(file_path) > 0):
            state = StaleSysdbState(file_path, config)
            config = state.remove_stale_entity("vrf")

        with open(os.path.join(dirname, self.VRF_CONFIG_FILENAME), "w") as file:
            file.write(config)

    def get_vrf_config(self, settings_file: SettingsFile) -> str:
        """creates the vrf config Cli commands."""
        cmds = []
        present, vrfs = EosCommon.vrf_settings_present(settings_file)
        if present:
            cmds.extend(self.remove_vrf_config_cmds(vrfs))
            cmds.extend(self.create_vrf_config_cmds(vrfs))

        return "\n".join(cmds)

    def remove_vrf_config_cmds(self, vrfs: list[dict]) -> list[str]:
        """creates the flush commands."""
        cmds = []
        for vrf in vrfs:
            name = vrf.get("name")
            # Skip 'default' VRF as it's a reserved/built-in VRF in EOS
            if name != "default":
                cmds.append(f"no vrf instance {name}")
        # Also, delete deleted VRF instances
        for vrf_name in self.deleted_vrf_details.keys():
            # Skip 'default' VRF as it's a reserved/built-in VRF in EOS
            if vrf_name != "default":
                cmds.append(f"no vrf instance {vrf_name}")
        return cmds

    def create_vrf_config_cmds(self, vrfs: list[dict]) -> list[str]:
        """creates the Cli commands to create vrf and attach to interfaces."""
        cmds = []
        for vrf in vrfs:
            name = vrf.get("name")
            # Skip 'vrf instance' for 'default' VRF as it's a reserved/built-in VRF in EOS
            # But still enable IP routing for it
            if name != "default":
                cmds.append(f"vrf instance {name}")
            cmds.append(f"ip routing vrf {name}")
        return cmds


registrar.register_manager(VrfManager())
