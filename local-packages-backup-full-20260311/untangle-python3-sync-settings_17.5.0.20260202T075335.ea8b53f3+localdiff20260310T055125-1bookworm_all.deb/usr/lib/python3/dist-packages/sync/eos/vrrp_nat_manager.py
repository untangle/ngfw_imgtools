"""This class is responsible for writing the nat-vrrp chain"""

import os
import stat

from sync import Manager, registrar
from sync.common import Logger

logger = Logger.getInstance()


class VrrpNatManager(Manager):
    """VrrpNatManager manages the nat tables for EOS VRRP"""

    eos_vrrp_state_filename = "/etc/mfw/eos/EosVrrpState"
    vrrp_nat_rules_filename = "/etc/config/nftables-rules.d/104-nat-vrrp"

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.vrrp_nat_rules_filename, "restart-nftables-rules", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        self.write_vrrp_nat_rules_file(settings_file.settings, prefix)

    def write_vrrp_nat_rules_file(self, settings, prefix) -> None:
        "write the vrrp nat rules file"

        # Read VRRP State from Eos
        VrrpMasterVips = {}
        if os.path.isfile(self.eos_vrrp_state_filename):
            file = open(self.eos_vrrp_state_filename)
            for line in file:
                intf, vip = line.rstrip("\n").split(",")
                VrrpMasterVips[intf] = vip
            file.close()

        filename = prefix + self.vrrp_nat_rules_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")

        file.write("#!/usr/bin/nft_debug -f")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(r"""
add table ip nat-vrrp
flush table ip nat-vrrp

add chain ip nat-vrrp nat-vrrp-rules { type nat hook postrouting priority 97 ; }

""")

        interfaces = settings.get("network", {}).get("interfaces", [])
        for intf in interfaces:
            dev_name = intf.get("device")
            if dev_name not in VrrpMasterVips:
                continue
            if intf.get("wan") and intf.get("natEgress") and intf.get("configType") == "ADDRESSED":
                file.write(
                    f"add rule ip nat-vrrp nat-vrrp-rules oifname {dev_name} snat to {VrrpMasterVips[dev_name]}\n"
                )

        file.write("\n")
        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(VrrpNatManager())
