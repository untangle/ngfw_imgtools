"""This class is responsible for writing DHCP server config."""

import os
import socket

import sync.eos.utils as EosCommon
from sync import Manager, network_util, registrar
from sync.common import Logger
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE
from sync.eos.creators.dhcp_creator import DHCPCreator
from sync.eos.sanitizers.dhcp_sanitizer import DHCPSanitizer
from sync.eos.validators.dhcp_validator import DHCPValidator
from sync.network_util import translate_mfw_interface_name_to_eos

DHCP_IP_OPTIONS_CODES = [
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "11",
    "16",
    "21",
    "28",
    "32",
    "33",
    "41",
    "42",
    "44",
    "45",
    "48",
    "49",
    "54",
    "65",
    "68",
    "69",
    "70",
    "71",
    "72",
    "73",
    "74",
    "75",
    "76",
    "85",
    "89",
    "112",
    "136",
    "138",
    "150",
]
DHCP_STRING_OPTIONS_CODES = [
    "14",
    "15",
    "17",
    "18",
    "40",
    "47",
    "56",
    "60",
    "62",
    "64",
    "66",
    "67",
    "86",
    "87",
    "88",
    "98",
    "100",
    "101",
    "113",
    "114",
    "160",
]
DHCP_STRING_OR_IP_OPTIONS_CODES = [str(i) for i in range(224, 255)]

logger = Logger.getInstance()


class DHCPManager(Manager):
    """DHCPManager writes Sysdb DHCP server config."""

    DHCP_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}dhcp.cfg"
    DEFAULT_PREFIX = "32"

    def __init__(self) -> None:
        super().__init__(DHCPCreator(), DHCPValidator(), DHCPSanitizer())

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)

        registrar.register_file(
            os.path.join(EosCommon.CONFIG_ALWAYS_DIR, self.DHCP_CONFIG_FILENAME),
            "eos-config-always",
            self,
        )

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """Syncs settings."""
        logger.info("Syncing settings")

        dirname = os.path.join(prefix, EosCommon.CONFIG_ALWAYS_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        current_subnets = {}
        file_path = os.path.join(EosCommon.CONFIG_ALWAYS_DIR, self.DHCP_CONFIG_FILENAME)
        if os.path.isfile(file_path) and (os.path.getsize(file_path) > 0):
            current_subnets = self.get_current_dhcp_subnets_config(file_path)
            # No need to generate no subnet commands for interfaces
            # The subnets are automatically removed by removing from the interface.

        config = ""
        config += "\n" + self.get_dhcp_commands(settings_file.settings, current_subnets)

        current_relays = {}
        file_path = os.path.join(EosCommon.CONFIG_ALWAYS_DIR, self.DHCP_CONFIG_FILENAME)
        if os.path.isfile(file_path) and (os.path.getsize(file_path) > 0):
            current_relays = self.get_current_dhcp_relays_config(file_path)
            # No need to generate delete commands for relays
            # The relays are automatically removed by removing from the interface.

        config += "\n" + self.get_dhcp_relay_commands(settings_file.settings, current_relays)

        # write to file
        with open(os.path.join(dirname, self.DHCP_CONFIG_FILENAME), "w") as f:
            f.write(config)

    def get_dhcp_commands(self, settings: dict, current_subnets: dict) -> str:
        """Generate DHCP config file from the settings
        @settings: current settings JSON format.

        DHCP is implicitly enabled on LAN interfaces that have their corresponding
        subnet objects defined under DHCP.servers.
        """

        interfaces = settings.get("network", {}).get("interfaces", [])
        vrf_list = settings.get("vrf", [])
        dhcp_list = settings.get("dhcp", [])
        interface_dhcp_commands = []

        commands = []
        # Remove previously defined dhcp servers
        current_dhcp_config = os.path.join(EosCommon.CONFIG_ALWAYS_DIR, self.DHCP_CONFIG_FILENAME)
        if os.path.exists(current_dhcp_config):
            with open(current_dhcp_config) as f:
                for line in f:
                    if line.startswith("dhcp server"):
                        no_dhcp_server = f"no {line.strip()}"
                        commands.append(no_dhcp_server)

        # Build mapping: interfaceId -> interface object
        interface_map = {
            intf.get("interfaceId"): intf for intf in interfaces if intf.get("type") != "LOOPBACK"
        }

        # Build mapping: VRF name -> DHCP config
        vrf_to_dhcp = {}
        for vrf in vrf_list:
            vrf_name = vrf.get("name")
            dhcp_id = vrf.get("dhcp")

            if dhcp_id:
                for dhcp_config in dhcp_list:
                    if dhcp_config.get("id") == dhcp_id:
                        vrf_to_dhcp[vrf_name] = dhcp_config
                        break

        for vrf in vrf_list:
            vrf_name = vrf.get("name")
            vrf_interface_ids = vrf.get("interfaces", [])

            dhcp_config = vrf_to_dhcp.get(vrf_name)

            # Get DHCP servers from the DHCP config
            dhcp_servers = []
            if dhcp_config:
                dhcp_servers = dhcp_config.get("servers", [])

            # Build set of subnets that have DHCP server definitions
            dhcp_enabled_subnets = set()
            if dhcp_servers:
                dhcp_enabled_subnets = {
                    server.get("subnet") for server in dhcp_servers if server.get("subnet", None)
                }

            # DHCP is implicitly enabled if the interface's subnet matches a DHCP server definition
            dhcp_enabled_interfaces = []

            for intf_id in vrf_interface_ids:
                intf = interface_map.get(intf_id)
                if not intf:
                    continue

                if (
                    intf.get("management", False) is True
                    or intf.get("enabled") is False
                    or intf.get("dhcpRelayEnabled") is True
                    or intf.get("wan") is True
                    or intf.get("v4ConfigType") != "STATIC"
                    or (
                        intf.get("type") != "NIC"
                        and intf.get("type") != "VLAN"
                        and intf.get("configType") != "ADDRESSED"
                    )
                ):
                    continue

                v4_address = intf.get("v4StaticAddress", "")
                v4_prefix = intf.get("v4StaticPrefix", None)

                if not v4_address or v4_prefix is None:
                    continue

                interface_subnet = self.get_subnet(v4_address, v4_prefix)
                interface_dhcp_commands.append(
                    f"interface {translate_mfw_interface_name_to_eos(intf.get('device'))}"
                )

                # If this interface's subnet has a DHCP server definition
                # If yes, DHCP is implicitly enabled for this interface
                if interface_subnet in dhcp_enabled_subnets:
                    dhcp_enabled_interfaces.append(intf)

                    interface_dhcp_commands.append("  dhcp server ipv4")
                else:
                    interface_dhcp_commands.append("  no dhcp server ipv4")
            # If no valid interfaces, skip this VRF
            if not dhcp_enabled_interfaces:
                continue

            if vrf_name == "default":
                commands.append("dhcp server")
            else:
                commands.append(f"dhcp server vrf {vrf_name}")

            # Add domain name
            system = settings.get("system")
            if (domainName := system.get("domainName", "")) != "" and domainName is not None:
                commands.append(f"  dns domain name ipv4 {domainName}")

            for intf in dhcp_enabled_interfaces:
                intf_id = intf.get("interfaceId")

                # Get subnet from interface
                subnet = self.get_subnet(intf.get("v4StaticAddress"), intf.get("v4StaticPrefix"))

                # Find matching DHCP server config for this subnet
                matching_server = None
                for server in dhcp_servers:
                    server_subnet = server.get("subnet")
                    if server_subnet == subnet:
                        matching_server = server
                        break

                # If no matching server found, skip this interface
                if not matching_server:
                    continue

                commands.append(f"  subnet {subnet}")

                # Add reserved IP commands from staticDhcpEntries
                static_entries = matching_server.get("staticDhcpEntries", [])

                if static_entries:
                    reservation_commands = self.get_reservation_commands(
                        subnet,
                        current_subnets,
                        static_entries,
                        intf.get("v4StaticPrefix"),
                    )
                    if reservation_commands:
                        commands.append(reservation_commands)

                # Configure name
                interface_name = network_util.get_interface_name(settings, intf, "ipv4")
                commands.append(f"    name {interface_name}")

                # Configure range
                new_start = matching_server.get("rangeStart", None)
                new_end = matching_server.get("rangeEnd", None)
                if subnet in current_subnets:
                    old_start = current_subnets.get(subnet).get("start")
                    old_end = current_subnets.get(subnet).get("end")
                    if (old_start and new_start) and (
                        old_start != new_start or old_end != new_end
                    ):
                        commands.append(f"    no range {old_start} {old_end}")
                if new_start and new_end:
                    commands.append(f"    range {new_start} {new_end}")

                # Configure lease time
                lease_duration = matching_server.get("leaseDuration")

                if lease_duration is not None and lease_duration != 0:
                    lease_time_str = self.get_lease_time(lease_duration)
                    commands.append(f"    lease time {lease_time_str}")
                else:
                    commands.append("    lease time 0 days 1 hours 0 minutes")

                # Configure default gateway
                default_gateway = matching_server.get("gateway")
                commands.append(f"    default-gateway {default_gateway}")

                # Configure dns server
                dns_server = matching_server.get("dns")
                commands.append(f"    dns server {dns_server}")

                # Configure DHCP options
                dhcp_options = matching_server.get("dhcpOptions")
                if dhcp_options is not None:
                    for dhcp_option in dhcp_options:
                        if dhcp_option.get("enabled") is None or not dhcp_option.get("enabled"):
                            continue

                        code, value = dhcp_option.get("value").split(",")

                        if code == "66":  # Configure TFTP Server per subnet
                            commands.append(f"    tftp server option {code} {value}")
                        elif code in DHCP_IP_OPTIONS_CODES:
                            commands.append(
                                f"    option ipv4 {code} type ipv4-address data {value}"
                            )
                        elif code in DHCP_STRING_OPTIONS_CODES:
                            commands.append(f'    option ipv4 {code} type string data "{value}"')
                        elif code in DHCP_STRING_OR_IP_OPTIONS_CODES:
                            if network_util.is_valid_ipv4(value):
                                commands.append(
                                    f"    option ipv4 {code} type ipv4-address data {value}"
                                )
                            else:
                                commands.append(
                                    f'    option ipv4 {code} type string data "{value}"'
                                )
                        elif self.is_hex_string(value):
                            # Already in hex format - use directly
                            commands.append(f"    option ipv4 {code} type hex data {value}")
                        else:
                            # Not hex - convert IP or string to hex
                            hex_value = self.option_to_hex(value)
                            commands.append(f"    option ipv4 {code} type hex data {hex_value}")

                commands.append("  !")

        commands.extend(interface_dhcp_commands)  # Append interface DHCP commands at the end
        commands.append("!")

        return "\n".join(commands)

    def is_hex_string(self, value: any) -> bool:
        """
        Check if a string is a valid hexadecimal string.

        This is used to detect if a DHCP option value is already in hex format

        Args:
            value: The string to check

        Returns:
            True if the string contains only valid hex characters (0-9, a-f, A-F)
            False otherwise
        """
        if not value or not isinstance(value, str):
            return False

        # Check if all characters are valid hex digits
        try:
            int(value, 16)
            return True
        except ValueError:
            return False

    def option_to_hex(self, value: any) -> str:
        try:
            packed_ip = socket.inet_aton(value)
            return packed_ip.hex()
        except OSError:
            return value.encode("utf-8").hex()

    # Using the passed information, matches any staticDhcpEntries to the current subnet, and
    # constructs a string that is a list of commands (separated by newline characters) to
    # add an IP reservation to the config. Returns that string.
    def get_reservation_commands(
        self, subnet, current_subnets=None, staticDhcpEntries=None, prefix=None
    ):
        if staticDhcpEntries is None:
            staticDhcpEntries = []
        if current_subnets is None:
            current_subnets = {}
        prefix = prefix if prefix else self.DEFAULT_PREFIX
        commands = []
        # Overwrite any existing reservations, will rewrite in next step if necesssary
        # This prevents us from needing to individually delete reservations
        if subnet in current_subnets and "reservation" in current_subnets[subnet]:
            commands.append("    no reservations")
        # Add any staticDhcpEntries that are associated with interfaces
        for reservation in staticDhcpEntries:
            if subnet == self.get_subnet(reservation["address"], prefix):
                # only add `reservations` command once
                if len(commands) <= 1:
                    commands.append("    reservations")
                commands.append(f"      mac-address {reservation['macAddress']}")
                commands.append(f"        ipv4-address {reservation['address']}")
                commands.append("    !")
        return "\n".join(commands)

    def get_subnet(self, ip_address, prefix):
        octets = ip_address.split(".")

        octets[-1] = "0"

        subnet = ".".join(octets)

        return subnet + "/" + str(prefix)

    def get_lease_time(self, seconds) -> str:
        seconds = int(seconds)

        days, seconds = divmod(seconds, 86400)
        hours, seconds = divmod(seconds, 3600)
        minutes, seconds = divmod(seconds, 60)

        return f"{days} days {hours} hours {minutes} minutes"

    def get_current_dhcp_subnets_config(self, file_path) -> dict:
        """Get current DHCP subnets config from .cfg file.
        @file_path: the path for the DHCP cfg file.
        Returns a dict where the key is the subent and the value is the DHCP range.
        """
        with open(file_path) as f:
            current_config_string = f.read()

        current_subnets = {}
        current_subnet = ""
        for line in current_config_string.splitlines():
            line = line.strip()
            if line == "":
                continue
            if "no subnet" in line:
                # Ignore, this config is for Sysdb to remove stale vlan-interfaces
                continue
            # Checking if line contains only subnet. Do not delete the space after subnet or condition
            # will also be true for line 'ip dhcp relay all-subnets default'
            if "subnet " in line:
                current_subnet = line.split(" ")[1]
                current_subnets[current_subnet] = {}
            elif "range" in line:
                range_limits = line.split(" ")
                current_subnets[current_subnet]["start"] = range_limits[1]
                current_subnets[current_subnet]["end"] = range_limits[2]
            elif "reservation" in line:
                current_subnets[current_subnet]["reservation"] = line.strip()
            elif "tftp" in line:
                current_subnets[current_subnet]["tftp"] = line.strip()

        return current_subnets

    def get_dhcp_relay_commands(self, settings, current_subnets):
        """Generate DHCP config file comamnds from the settings
        @settings: current settings JSON format."""

        interfaces = settings.get("network", {}).get("interfaces", [])

        commands = []

        # Set DHCP Relay
        for intf in interfaces:
            if (
                intf.get("enabled") is True
                and intf.get("dhcpRelayEnabled") is True
                and intf.get("v4ConfigType") != "DISABLED"
                and (intf.get("configType") == "ADDRESSED" or intf.get("type") == "BRIDGE")
            ):
                intf_name = intf["device"].replace("_", "/")
                commands.append(f"interface {intf_name}")
                commands.append(f"  ip helper-address {intf.get('dhcpRelayAddress')}")
                commands.append("!")

        if len(commands) != 0:
            commands.append("ip dhcp relay all-subnets default")
            commands.append("!")

        return "\n".join(commands)

    def get_current_dhcp_relays_config(self, file_path):
        """Get current DHCP relay config from .cfg file.
        @file_path: the path for the DHCP cfg file.
        Returns a dict where the key is the interface and the value is the DHCP server.
        """
        with open(file_path) as f:
            current_config_string = f.read()

        current_relays = {}
        current_interface = ""
        for line in current_config_string.splitlines():
            line = line.strip()
            if line == "":
                continue
            if "no ip helper-address" in line:
                # Ignore, this config is for Sysdb to remove stale config
                continue
            if "interface" in line:
                current_interface = line.split(" ")[1]
                continue
            if "ip helper-address" in line:
                current_relays[current_interface] = line.split(" ")[2]
                continue

        return current_relays


registrar.register_manager(DHCPManager())
