"""Threat prevention manager for EOS with BCTI support"""

from sync import registrar
from sync.common.threat_prevention_manager import BctiThreatPreventionManager

registrar.register_manager(BctiThreatPreventionManager())
