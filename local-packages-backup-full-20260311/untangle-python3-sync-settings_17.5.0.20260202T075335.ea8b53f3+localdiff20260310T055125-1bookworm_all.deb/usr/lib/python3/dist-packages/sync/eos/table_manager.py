from typing import Any
from uuid import uuid4

# create/sync/sanitize settings functions are called in the order the managers
# register. This module depends on the sync/eos/system_manager to run first.
# Force it by importing here and not using it.
import sync.eos.system_manager  # noqa: F401
from sync import Manager, registrar
from sync.common import Logger
from sync.common.nft_types import Action, Condition, Rule, RuleChain, Table
from sync.common.table_manager import (
    default_filter_rules_table,
)
from sync.nftables_util import INTERFACE_TYPES
from sync.settings_exception import SettingsException

logger = Logger.getInstance()

ACCEPT_ALL_HTTP_RULE_DESC = "Accept All HTTP"
ACCEPT_ALL_HTTPS_RULE_DESC = ACCEPT_ALL_HTTP_RULE_DESC + "S"
SHAPING_PRIORITY_MASK = "0X001F0000"


class TableManager(Manager):
    """TableManager manages the all the firewall tables"""

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def sanitize_settings(self, settings_file: dict[str, Any]) -> None:
        # Update default access rules controlling HTTP/HTTPs access if they changed
        # in system_manager

        access_table = settings_file.settings.get("firewall", {}).get("tables", {}).get("access")
        if not access_table:
            access_table = default_access_rules_table()

        # Should only be one access rule chain in the access table
        access_rules = access_table.get("chains")[0].get("rules")
        desc_to_access_rule = {r.get("description", ""): r for r in access_rules}
        # Update access rules so restd doesn't cut web admin access on updates to
        # the default http port and https ports
        httpPort = settings_file.settings.get("httpPort")
        if httpPort and ACCEPT_ALL_HTTP_RULE_DESC in desc_to_access_rule:
            desc_to_access_rule[ACCEPT_ALL_HTTP_RULE_DESC].conditions[0].value = str(httpPort)

        httpsPort = settings_file.settings.get("httpsPort")
        if httpsPort and ACCEPT_ALL_HTTPS_RULE_DESC in desc_to_access_rule:
            desc_to_access_rule[ACCEPT_ALL_HTTPS_RULE_DESC].conditions[0].value = str(httpPort)

        # Make sure there is the always a drop all at the end since ACLs implicitly
        # have one
        last_rule = access_rules[-1]
        if (
            len(last_rule.get("conditions", [])) == 0
            and last_rule.get("action").get("type") == "DROP"
        ):
            last_rule["enabled"] = True
            return

        access_rules.append(get_drop_all_rule().get_json())

    def validate_settings(self, settings_file) -> None:
        """
        Validates table settings
        """
        errors = []
        tables = settings_file.settings["firewall"]["tables"]
        valid_tables = set(tables.keys()).intersection(
            {"filter", "port-forward", "nat", "access", "shaping"}
        )
        # Generally this failure will occur when a user is attempting to add a single rule.
        for table in valid_tables:
            for chain in tables[table]["chains"]:
                for rule in chain.get("rules"):
                    if rule.get("enabled") is True:
                        condition_types = set()
                        for condition in rule.get("conditions"):
                            cond_type = condition.get("type")
                            if cond_type in condition_types:
                                errors.append("conflicting protocols specified: tcp vs. udp")
                            condition_types.add(cond_type)
                        # Check for nat table: must have destination_interface_zone
                        if table == "nat" and "DESTINATION_INTERFACE_ZONE" not in condition_types:
                            errors.append(
                                f"Missing required condition: DESTINATION INTERFACE ZONE in NAT rule with description: `{rule.get('description', '')}`"
                            )
                        # Check for port-forward table: must have source_interface_zone
                        if (
                            table == "port-forward"
                            and "SOURCE_INTERFACE_ZONE" not in condition_types
                        ):
                            errors.append(
                                f"Missing required condition: SOURCE INTERFACE ZONE in Port Forward rule with description: `{rule.get('description', '')}`"
                            )

        if len(errors) > 0:
            raise SettingsException(message_str="\n".join(errors))

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        interfaces = settings_file.settings["network"]["interfaces"]
        wan_intfs = [
            {"name": intf["name"], "id": intf["interfaceId"]}
            for intf in interfaces
            if intf.get("wan", False)
        ]
        tables = {}
        tables["filter"] = default_filter_rules_table()
        tables["access"] = default_access_rules_table()
        tables["nat"] = default_nat_rules_table(wan_intfs)
        tables["port-forward"] = default_port_forward_table()
        tables["shaping"] = default_shaping_rules_table()
        settings_file.settings["firewall"] = {}
        settings_file.settings["firewall"]["tables"] = tables

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        # The actual processing currently handled by the acl_manager/nat_manager


def get_drop_all_rule() -> dict[str, Any]:
    return Rule(
        enabled=True,
        description="Drop all other traffic",
        rule_id=uuid4().__str__(),
        conditions=[],
        action=Action(type="DROP"),
        log=False,
    )


def default_access_rules_table() -> dict[str, Any]:
    default_access_rules_table = Table(
        name="access", family="inet", chain_type="filter", chains=[]
    )

    # All access-rules will be placed in the system's Control Plane ACL.
    # The control plane runs at least two types of services:
    # management      SSH, HTTP/HTTPS.  Only management allowed traffic
    #   (management interface) should be allowed to access.
    # non-management  ICMP, DHCP.  These are typically open to different
    #   types of interfaces, but most commonly LANs.
    #
    # And finally, traffic originating from the control plane should always be
    # allowed back.
    default_rule_chain = RuleChain(
        name="access-rules",
        description="The base access-rules chain",
        base=True,
        hook="input",
        priority=0,
        rules=[
            Rule(
                enabled=True,
                description="Established",
                rule_id=uuid4().__str__(),
                conditions=[
                    Condition(type="CT_STATE", op="==", value="established"),
                ],
                action=Action(type="ACCEPT"),
                log=False,
            ),
            Rule(
                enabled=True,
                description="Management Control Plane Services",
                rule_id=uuid4().__str__(),
                conditions=[
                    Condition(type="SOURCE_INTERFACE_ZONE", op="==", value="MGMT1"),
                ],
                action=Action(type="ACCEPT"),
                log=False,
            ),
            Rule(
                enabled=True,
                description="Respond to ICMP (LANs)",
                rule_id=uuid4().__str__(),
                conditions=[
                    Condition(type="IP_PROTOCOL", op="==", value="1"),
                    Condition(type="SOURCE_INTERFACE_TYPE", op="==", value=INTERFACE_TYPES["lan"]),
                    Condition(
                        type="DESTINATION_INTERFACE_TYPE", op="==", value=INTERFACE_TYPES["lan"]
                    ),
                ],
                action=Action(type="ACCEPT"),
                log=False,
            ),
            Rule(
                enabled=True,
                description="Respond to ICMP (WANs)",
                rule_id=uuid4().__str__(),
                conditions=[
                    Condition(type="IP_PROTOCOL", op="==", value="1"),
                    Condition(
                        type="DESTINATION_INTERFACE_TYPE", op="==", value=INTERFACE_TYPES["wan"]
                    ),
                ],
                action=Action(type="ACCEPT"),
                log=False,
            ),
            Rule(
                enabled=True,
                description="Respond to UDP/DNS (LANs)",
                rule_id=uuid4().__str__(),
                conditions=[
                    Condition(type="DESTINATION_PORT", op="==", value="53", port_protocol=17),
                    Condition(type="SOURCE_INTERFACE_TYPE", op="==", value=INTERFACE_TYPES["lan"]),
                    Condition(
                        type="DESTINATION_INTERFACE_TYPE", op="==", value=INTERFACE_TYPES["lan"]
                    ),
                ],
                action=Action(type="ACCEPT"),
                log=False,
            ),
            Rule(
                enabled=True,
                description="Respond to TCP/DNS (LANs)",
                rule_id=uuid4().__str__(),
                conditions=[
                    Condition(type="DESTINATION_PORT", op="==", value="53", port_protocol=6),
                    Condition(type="SOURCE_INTERFACE_TYPE", op="==", value=INTERFACE_TYPES["lan"]),
                    Condition(
                        type="DESTINATION_INTERFACE_TYPE", op="==", value=INTERFACE_TYPES["lan"]
                    ),
                ],
                action=Action(type="ACCEPT"),
                log=False,
            ),
            Rule(
                enabled=True,
                description="Accept BGP traffic",
                rule_id=uuid4().__str__(),
                conditions=[
                    Condition(type="DESTINATION_PORT", op="==", value="179", port_protocol=6),
                ],
                action=Action(type="ACCEPT"),
                log=False,
            ),
            # All ACLs have an implicit drop all at the end.
            get_drop_all_rule(),
        ],
    )
    default_access_rules_table.chains.append(default_rule_chain)
    return default_access_rules_table.get_json()


def default_port_forward_table() -> dict[str, Any]:
    """
    For EOS, creating a separate default port forward table which does not have any rules.
    EOS port forward rules require SOURCE_INTERFACE_ZONE conditions to compulsorily be present
    in each port forward rule's conditions. That is not the case with OpenWrt's system-derived
    port-forward rules in the port-forward-validation chain. That's why best to separate them
    out at this point. Also, keeping just one chain here and removing port-forward-validation
    as we only ever process the rules in the first chain in EOS nat_manager.
    """
    default_port_forward_table = Table(
        name="port-forward",
        family="ip,ip6",
        chain_type="nat",
        chains=[
            RuleChain(
                name="port-forward-rules",
                description="The base port-forwards chain",
                base=False,
                default=True,
                rules=[],
            ),
        ],
    )

    return default_port_forward_table.get_json()


def default_shaping_rules_table() -> dict[str, Any]:
    """default shaping rules table"""
    default_shaping_rules_table = Table(
        name="shaping",
        family="inet",
        chain_type="filter",
        chains=[
            RuleChain(
                name="shaping-rules",
                description="The base shaping-rules chain",
                base=True,
                hook="postrouting",
                priority=5,
                rules=[],
            ),
            RuleChain(
                name="prioritization-rules",
                description="The main prioritization rules chain",
                default=True,
                rules=[],
            ),
            RuleChain(
                name="limiting-rules",
                description="The main limiting rules chain",
                default=True,
                rules=[],
            ),
            RuleChain(
                name="quota-rules",
                description="The main quota rules chain",
                default=True,
                rules=[],
            ),
        ],
    )

    return default_shaping_rules_table.get_json()


def default_nat_rules_table(wan_intfs: list) -> dict[str, Any]:
    """default nat rule table for wan interface"""
    default_nat_rule_table_for_wan = Table(
        name="nat",
        family="ip,ip6",
        chain_type="nat",
        chains=[
            RuleChain(
                name="nat-rules",
                description="The base default nat rule for wan chain",
                base=True,
                hook="postrouting",
                priority=95,
                rules=[default_nat_rule(intf) for intf in wan_intfs],
            ),
            RuleChain(
                name="output",
                description="The output chain",
                base=True,
                hook="output",
                priority=100,
                rules=[],
            ),
        ],
    )

    return default_nat_rule_table_for_wan.get_json()


def default_nat_rule(intf: dict) -> dict[str, Any]:
    """default nat rule table for wan interface"""
    name = intf["name"]
    intf_id = intf["id"]
    rule = Rule(
        enabled=True,
        description=f"masquerade for default wan {name}",
        rule_id=uuid4().__str__(),
        conditions=[
            Condition(type="DESTINATION_INTERFACE_ZONE", op="==", value=intf_id),
        ],
        action=Action(type="MASQUERADE"),
        log=False,
    )
    return rule


registrar.register_manager(TableManager())
