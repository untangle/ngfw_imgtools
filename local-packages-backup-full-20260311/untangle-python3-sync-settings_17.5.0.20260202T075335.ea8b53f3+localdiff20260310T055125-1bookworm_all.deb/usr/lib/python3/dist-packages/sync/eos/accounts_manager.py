"""
This class handles accounts (admin) credentials settings translation
from MFW settings.json to EOS Sysdb
"""

import os

import sync.eos.utils as EosCommon
from sync import registrar
from sync.common import Logger
from sync.common.accounts_manager import AccountsManager
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE
from sync.settings_file import SettingsFile

logger = Logger.getInstance()


class EOSAccountsManager(AccountsManager):
    """
    AccountsManager is responsible to write accounts credentials into Sysdb
    """

    ACCOUNT_CRED_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}accounts_credentials.cfg"

    def initialize(self) -> None:
        """
        Initialize this module
        """
        logger.info("Initializing settings")
        registrar.register_settings_file("settings", self)
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.ACCOUNT_CRED_FILENAME), "eos-config", self
        )

    def get_accounts_credentials_config(self, credentials: list[dict[str, str]]) -> str:
        """
        Generate config file from the accounts.credentials settings
        @credentials: list of accounts credentials in JSON format
        """
        commands = []
        for cred in credentials:
            # Check each account credential
            # if authorized public ssh-key is present add to commands
            # else either SHA512, MD5 or cleartext password is present add to commands
            cred_username = cred["username"]
            if cred.get("authorizedKeys"):
                commands.append(f"username {cred_username} ssh-key {cred['authorizedKeys']}")
            else:
                if cred.get("passwordHashSHA512"):
                    cred_secret = "sha512"  # noqa: S105
                    cred_password = cred.get("passwordHashSHA512")
                elif cred.get("passwordHashMD5"):
                    cred_secret = "5"  # noqa: S105
                    cred_password = cred.get("passwordHashMD5")
                elif cred.get("passwordCleartext"):
                    cred_secret = ""
                    cred_password = cred.get("passwordCleartext")
                else:
                    continue
                commands.append(f"username {cred_username} secret {cred_secret} {cred_password}")

        return "\n".join(commands)

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list: list[str]
    ) -> None:
        """
        syncs settings
        """
        credentials = settings_file.settings.get("accounts", {}).get("credentials", [])
        config = self.get_accounts_credentials_config(credentials)

        # write to file
        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        with open(os.path.join(dirname, self.ACCOUNT_CRED_FILENAME), "w") as f:
            f.write(config)


registrar.register_manager(EOSAccountsManager())
