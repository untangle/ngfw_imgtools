# Copyright (c) 2023 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.


import json
import os
from socket import (
    IPPROTO_ICMP,
    IPPROTO_TCP,
    IPPROTO_UDP,
)
from typing import ClassVar

import Tac

from sync import SettingsFile, registrar
from sync.common import Logger
from sync.common.dos_manager import DENIAL_OF_SERVICE, DosManager
from sync.interface_util import get_intf_eos_name

logger = Logger.getInstance()


class DosWriter:
    """
    This class is just for writing out the settings file dos
    settings to a dos config object.
    """

    PROTO_MAP: ClassVar[dict] = {
        "icmp": IPPROTO_ICMP,
        "udp": IPPROTO_UDP,
        "tcp": IPPROTO_TCP,
        "all": 0xFF,
    }

    def write_interfaces(self, dos_config, settings_file: SettingsFile) -> None:
        """
        Find all the interfaces that we want to attach to the modules
        and attach them.
        """

        dos_config.enabledInterfaces.clear()
        all_interfaces = settings_file.settings.get("network", {}).get("interfaces", [])

        applied_interfaces = [
            get_intf_eos_name(i)
            for i in all_interfaces
            if (i.get("type") == "NIC" and i.get("enabled") and (not i.get("management")))
        ]
        applied_interfaces_arnet = [
            Tac.newInstance("Arnet::IntfId", i) for i in applied_interfaces if i is not None
        ]

        for i in applied_interfaces_arnet:
            dos_config.enabledInterfaces.add(i)

    def sync_settings_to_sysdb(self, dos_config, settings_file: SettingsFile) -> None:
        dos_settings = settings_file.settings.get(DENIAL_OF_SERVICE, {})

        tac_objs = []
        for proto, num in self.PROTO_MAP.items():
            dest_sessions_max = dos_settings.get(f"dest_sessions_max_{proto}", 0)
            src_sessions_max = dos_settings.get(f"source_sessions_max_{proto}", 0)
            src_rate_max = dos_settings.get(f"new_sessions_per_second_{proto}", 0)
            tac_objs.append(
                Tac.newInstance(
                    "EfwSfe::DosLimitConfig",
                    src_sessions_max,
                    dest_sessions_max,
                    src_rate_max,
                    num,
                )
            )
        dos_config.limitConfigs.keys()

        dos_config.limitConfigs.clear()

        for obj in tac_objs:
            dos_config.limitConfigs.addMember(obj)

        dos_config.blockDuration = dos_settings.get("block_duration", False)
        dos_config.removeActiveSessions = dos_settings.get("remove_active_sessions", False)
        self.write_interfaces(dos_config, settings_file)
        dos_config.enabled = dos_settings.get("enabled", False)
        logger.info("DoS config enabled: %s", dos_config.enabled)


class EosDosManager(DosManager, DosWriter):
    """DosEosManager manages the dos filter settings for EOS"""

    # Path to write json snippet of the dos settings to. This allows
    # sync-settings to see the diff.
    settings_path: ClassVar[str] = "/tmp/dos_settings"

    dos_default_settings: ClassVar[dict] = {
        **DosManager.dos_default_settings,
        "enabled": False,
    }

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(EosDosManager.settings_path, "dos-config", self)

    def sync_settings(self, settings_file: SettingsFile, prefix: str, delete_list) -> None:
        """syncs settings by writing out to the dos settings file
        which is just the JSON snippet from settings.json. This allows
        sync-settings to detect the diff using its typical mechanism
        and run the dos sync script only when necessary."""
        logger.info("Syncing settings")
        path = prefix + self.settings_path
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            f.write(json.dumps(settings_file.settings.get(DENIAL_OF_SERVICE, {})))


registrar.register_manager(EosDosManager())
