"""
EOS UID Manager - Platform-specific implementation for EOS.

Manages the UID file at /mnt/flash/mfw-settings/uid for EOS platforms.
"""

from sync import registrar
from sync.common.uid_manager import UIDManager


class EOSUIDManager(UIDManager):
    """
    EOS-specific UID Manager implementation.

    Stores the UID file at /mnt/flash/mfw-settings/uid
    """

    def get_config_dir(self) -> str:
        """
        Get the EOS-specific configuration directory for the UID file.

        Returns:
            str: "/mnt/flash/mfw-settings" - the EOS configuration directory
        """
        return "/mnt/flash/mfw-settings"


registrar.register_manager(EOSUIDManager())
