"""This class is responsible for validating DHCP config"""

from sync.common.sanitizers.base_sanitizer import Sanitizer
from sync.settings_file import SettingsFile


class DHCPSanitizer(Sanitizer):
    """Handles sanitization of DHCP config"""

    def sanitize(self, settings_file: SettingsFile) -> None:
        """
        sanitizes DNS and DHCP settings
        """

        # Sanitize DHCP configurations
        dhcp_settings = settings_file.settings.get("dhcp")
        if dhcp_settings is not None and isinstance(dhcp_settings, list):
            for dhcp_config in dhcp_settings:
                if dhcp_config.get("servers") is None:
                    dhcp_config["servers"] = []

                # Sanitize server entries
                for server in dhcp_config.get("servers", []):
                    if server.get("staticDhcpEntries") is None:
                        server["staticDhcpEntries"] = []
                    if server.get("dns") is None:
                        server["dns"] = ""
                    if server.get("leaseDuration") is None:
                        server["leaseDuration"] = 3600

        # Missing dhcpRelay settings.
        interfaces = settings_file.settings.get("network", {}).get("interfaces", [])
        for interface in interfaces:
            if interface.get("wan") is False:
                if interface.get("dhcpRelayEnabled") is None:
                    interface["dhcpRelayEnabled"] = False
                if interface.get("dhcpRelayAddress") is None:
                    interface["dhcpRelayAddress"] = ""
