"""This class is responsible for writing interface-marks chains."""

from __future__ import annotations

import json
import os
import re
from typing import Any

import sync.eos.utils as EosCommon
from sync import Manager, SettingsFile, registrar
from sync.common import Logger
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_TWO, MfwEapiClientLib
from sync.eos_util import StaleSysdbState
from sync.network_util import translate_mfw_interface_name_to_eos
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class InterfaceManager(Manager):
    """InterfaceManager writes Sysdb interface config."""

    INTERFACE_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_TWO}interface.cfg"

    @staticmethod
    def _get_switchport_command(intf: dict[str, Any]) -> str:
        """Determine the switchport command for a non-management NIC interface.

        Returns '   switchport' for L2 mode (no IP configured) or
        '   no switchport' for L3 mode (has IP configured).

        Args:
            intf: Interface configuration dictionary

        Returns:
            The appropriate switchport command with indentation
        """
        v4ConfigType = intf.get("v4ConfigType", "DISABLED")
        v6ConfigType = intf.get("v6ConfigType", "DISABLED")

        # Check if interface has an IP address configured (v4 or v6)
        has_v4_ip = (
            v4ConfigType == "STATIC" and intf.get("v4StaticAddress")
        ) or v4ConfigType == "DHCP"
        has_v6_ip = (
            v6ConfigType == "STATIC" and intf.get("v6StaticAddress")
        ) or v6ConfigType == "SLAAC"

        if has_v4_ip or has_v6_ip:
            # Interface has IP configured - use L3 mode
            return "   no switchport"
        # No IP configured - L2 switchport mode
        return "   switchport"

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.INTERFACE_CONFIG_FILENAME),
            "eos-config",
            self,
        )

    def get_interface_config(self, interfaces: dict[Any, Any], vrfs: list[Any]) -> str:
        """Generate config file from the network.interface settings
        @interfaces: list of interface settings in JSON format."""
        pre_commands = []
        disables = []
        commands = []
        for intf in interfaces:
            # Dont configure ipsec interface in EOS
            if intf["type"] == "IPSEC":
                continue

            # Do not configure backend bridge in EOS
            # TODO: remove this once MFW-2879 is closed
            if intf["type"] == "BRIDGE":
                continue

            if intf["type"] == "LOOPBACK":
                commands.extend(self.get_loopback_config(intf))
                continue

            intf_name = EosCommon.convert_intf_name_to_eos_cli_format(intf["device"])

            # Setup vlan outside of interface config before attaching it to the
            # interface
            if intf.get("virtual", False):
                # vlanid is a string in the json but can only be between 1-4094
                vlanId = int(intf.get("vlanid", "0"))
                if vlanId == 0:
                    # vlan id 0 is the default meaning no vlan
                    continue

                commands.append(f"vlan {vlanId}")

            # Reset the interface settings to default, non-configured state
            # This removes everything including vrrp aliases, etc, that "no interface ..." doesn't.
            # We perform this operation for all interfaces in a group instead of with
            # each interface to avoid IP conflict.  For example, if we're switching
            # the networks for et1_1 and et1_2, the config for et1_1 would fail because et1_2
            # still has the network that et1_1 is trying to set.
            # TODO: Until we load all additional interface properties in, remove this?
            ##pre_commands.append(f"default interface {intf_name}")

            if intf["enabled"]:
                commands.append(f"interface {intf_name}")
                commands.append("   no shutdown")
            else:
                disables.append(f"interface {intf_name}")
                disables.append("   shutdown")

                # For disabled ADDRESSED NIC interfaces, write L2/L3 mode and IP config
                # This ensures the interface's IP configuration matches settings.json
                if (
                    intf["configType"] == "ADDRESSED"
                    and intf["type"] == "NIC"
                    and not intf.get("management")
                ):
                    disables.append(self._get_switchport_command(intf))

                    # Write IPv4 configuration based on v4ConfigType
                    v4ConfigType = intf.get("v4ConfigType", "DISABLED")
                    if v4ConfigType == "STATIC":
                        v4_addr = intf.get("v4StaticAddress")
                        v4_prefix = intf.get("v4StaticPrefix")
                        if v4_addr is not None and v4_prefix is not None:
                            disables.append(f"   ip address {v4_addr}/{v4_prefix}")
                        else:
                            disables.append("   no ip address")
                    elif v4ConfigType == "DHCP":
                        disables.append("   ip address dhcp")
                    else:
                        # DISABLED or unknown - clear IP address
                        disables.append("   no ip address")

                    # Write IPv6 configuration based on v6ConfigType
                    v6ConfigType = intf.get("v6ConfigType", "DISABLED")
                    if v6ConfigType == "STATIC":
                        v6_addr = intf.get("v6StaticAddress")
                        v6_prefix = intf.get("v6StaticPrefix")
                        if v6_addr is not None and v6_prefix is not None:
                            disables.append(f"   ipv6 address {v6_addr}/{v6_prefix}")
                        else:
                            disables.append("   no ipv6 address")
                    elif v6ConfigType == "SLAAC":
                        disables.append("   ipv6 address auto-config")
                    else:
                        # DISABLED, DHCP (not valid for IPv6), or unknown - clear IPv6
                        disables.append("   no ipv6 address")

                disables.append("!")
                continue

            if intf["name"]:
                commands.append(f"   description {intf['name']}")
            else:
                commands.append("   no description")

            # Add vrf to interface, if interface is not associated to any vrf then add default vrf
            intf_id = intf.get("interfaceId")
            vrf_name = "default"
            if vrfs:
                vrf_name = next(
                    (v["name"] for v in vrfs if intf_id in v.get("interfaces", [])), "default"
                )
            commands.append(f"   vrf {vrf_name}")

            # sub-interface needs below command for vlan tagging
            if intf["type"] == "VLAN":
                commands.append(f"   encapsulation dot1q vlan {intf['vlanid']}")

            if intf["configType"] == "ADDRESSED":
                v4ConfigType = intf.get("v4ConfigType", "")
                v6ConfigType = intf.get("v6ConfigType", "")

                # Determine switchport mode for non-management NIC interfaces
                if not intf.get("management") and intf["type"] == "NIC":
                    commands.append(self._get_switchport_command(intf))

                if v4ConfigType == "STATIC":
                    v4_addr = intf.get("v4StaticAddress")
                    v4_prefix = intf.get("v4StaticPrefix")
                    if v4_addr is not None and v4_prefix is not None:
                        commands.append(f"   ip address {v4_addr}/{v4_prefix}")
                elif v4ConfigType == "DHCP":
                    # Enable EOS DHCPO client
                    commands.append("   ip address dhcp")
                    commands.append("   dhcp client accept default-route")
                elif v4ConfigType == "DISABLED":
                    # Explicitly remove IP address when disabled
                    commands.append("   no ip address")
                elif v4ConfigType:
                    assert False, f"unsupported v4ConfigType '{v4ConfigType}'"

                if v6ConfigType == "STATIC":
                    v6_addr = intf.get("v6StaticAddress")
                    v6_prefix = intf.get("v6StaticPrefix")
                    if v6_addr is not None and v6_prefix is not None:
                        commands.append(f"   ipv6 address {v6_addr}/{v6_prefix}")
                elif v6ConfigType == "DHCP":
                    # NOTE: "ipv6 address dhcp" is not a valid EOS command.
                    # Treat DHCP as DISABLED - remove any IPv6 address.
                    commands.append("   no ipv6 address")
                elif v6ConfigType == "SLAAC":
                    # SLAAC via auto-config
                    commands.append("   ipv6 address auto-config")
                elif v6ConfigType == "DISABLED":
                    # Explicitly remove IPv6 address when disabled
                    commands.append("   no ipv6 address")
                elif v6ConfigType == "ASSIGN":
                    # IPv6 auto-assign, no explicit command needed
                    pass
                elif v6ConfigType:
                    assert False, f"unsupported v6ConfigType '{v6ConfigType}'"
            elif intf["configType"] == "BRIDGED":
                commands.append("   switchport mode access")
            else:
                msg = f"unsupported configType '{intf['configType']}'"
                raise AssertionError(msg)

            # FIXME: should this be "mac-address router"?
            if intf.get("macaddr"):
                commands.append(f"   mac-address {intf['macaddr']}")

            # duplex/speed: need more specifications

            # L2 or L3 MTU?
            if intf.get("mtu"):
                commands.append(f"   mtu {intf['mtu']}")
            else:
                commands.append("   no mtu")

            # VRRP
            if intf.get("vrrpEnabled"):
                commands.append(f"   vrrp {intf['vrrpId']} priority-level {intf['vrrpPriority']}")
                for i, addr in enumerate(intf.get("vrrpV4Aliases", [])):
                    flags = ""
                    if i > 0:
                        flags = "secondary"
                    commands.append(f"   vrrp {intf['vrrpId']} ipv4 {addr['v4Address']} {flags}")

                for track in intf.get("vrrpTrack", []):
                    commands.append(
                        f"   vrrp {intf['vrrpId']} tracked-object {track['name']} decrement {track['decrement']}"
                    )

            commands.append("!")
        cmds = self.populate_wan_group(interfaces)
        commands.extend(cmds)

        # Set all interfaces to defaults
        result = "\n".join(pre_commands) + "\n"
        if len(disables) > 0:
            # Disable any interfaces which are disabled
            # This prevents potential conflict between disabled
            # and enabled interfaces.
            result += "\n".join(disables) + "\n"
        # Then process the enabled interfaces
        result += "\n".join(commands) + "\n"
        return result

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, _delete_list: list[str]
    ) -> None:
        """Syncs settings."""
        interfaces = settings_file.settings.get("network", {}).get("interfaces", [])
        _, vrfs = EosCommon.vrf_settings_present(settings_file)
        config = self.get_interface_config(interfaces, vrfs)
        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        file_path = os.path.join(EosCommon.CONFIG_DIR, self.INTERFACE_CONFIG_FILENAME)
        # Remove stale sysdb states
        if os.path.isfile(file_path) and (os.path.getsize(file_path) > 0):
            state = StaleSysdbState(file_path, config)
            config = state.remove_stale_entity("interface")

        # write to file
        with open(os.path.join(dirname, self.INTERFACE_CONFIG_FILENAME), "w") as f:
            f.write(config)

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """Sanitizes interface settings for EOS environment.

        This includes:
        - Speed settings for NIC interfaces from Sysdb
        - Auto-generation of device names for loopback interfaces
        """
        eapiClient = MfwEapiClientLib.EapiClient("ar", disableAaa=True, privLevel=15)
        interfaces = settings_file.settings.get("network", {}).get("interfaces", [])

        # Sanitize loopback device names
        self._sanitize_loopback_devices(interfaces)

        # Sanitize NIC speed settings
        for intf in interfaces:
            if intf["type"] == "NIC":
                intf["ethSpeed"], intf["ethDuplex"], intf["ethAutoneg"] = self.collect_intf_speed(
                    intf["device"], eapiClient
                )
            intf.pop("natEgress", None)
            intf.pop("natIngress", None)
            # remove vrf property from interface
            # vrf name can be fetched from vrf object of settings.json
            intf.pop("vrf", None)

    def _sanitize_loopback_devices(self, interfaces: list[dict[str, Any]]) -> None:
        """Auto-generate device names for loopback interfaces without a device field.

        Similar to IPsec tunnel interface logic, this ensures each loopback interface
        has a unique device name (lo0, lo1, lo2, etc.). The 'name' field can be any
        user-visible description, while 'device' is the actual system device name.

        Args:
            interfaces: List of interface dictionaries from settings
        """
        loopback_num = 0
        lo_pattern = r"lo\d+"
        loopback_pattern = r"(Loopback|loopback)(\d+)"

        # Get all existing loopback device names
        loopback_interfaces = [intf for intf in interfaces if intf.get("type") == "LOOPBACK"]
        devices = {
            intf["device"]
            for intf in loopback_interfaces
            if intf.get("device") and re.fullmatch(lo_pattern, intf["device"])
        }

        for intf in loopback_interfaces:
            dev = intf.get("device", "")

            # If the interface already has a valid device name in MFW format (lo0, lo1, etc.), skip it
            if re.fullmatch(lo_pattern, dev):
                continue

            # Check if the 'name' field matches "Loopback" or "loopback" followed by a number
            # If so, try to use that number for the device name (if not already taken)
            name = intf.get("name", "")
            matched = re.fullmatch(loopback_pattern, name)
            if matched:
                desired_name = "lo" + matched.group(2)
                if desired_name not in devices:
                    devices.add(desired_name)
                    intf["device"] = desired_name
                    continue
                # If desired name is taken, fall through to auto-generation below

            # Generate a new device name by finding the next available number
            # For example, if lo1, lo2 already exist, new interfaces will be lo0, lo3, etc.
            new_dev = f"lo{loopback_num}"
            while new_dev in devices:
                loopback_num += 1
                new_dev = f"lo{loopback_num}"

            intf["device"] = new_dev
            devices.add(new_dev)
            loopback_num += 1

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """Validates settings."""
        interfaces = settings_file.settings.get("network", {}).get("interfaces", [])
        for intf in interfaces:
            if intf.get("management", None) is True and intf.get("wan", None) is True:
                # this is a management interface.
                raise SettingsException(message_str="Management interface configured as WAN")

    def collect_intf_speed(
        self, intf_name: str, eapiClient: MfwEapiClientLib.EapiClient
    ) -> tuple[None | int, None | str, None | str]:
        """Run 'show interfaces' for each interface and fetch its speed, duplex
        and auto-negotiation from Sysdb using EAPI."""
        # et1_1 interface name needs to be changed to et1/1 to query in sysdb
        intf_name = translate_mfw_interface_name_to_eos(intf_name)
        # Fetch the speed of the interface from Sysdb
        interface_output = eapiClient.runCmds(
            version=1,
            cmds=[f"show interfaces {intf_name} | json"],
            format="text",
            requestTimeout=1,
        )["result"][0]["output"]

        data = json.loads(interface_output)
        interface = data.get("interfaces", {}).get(intf_name, {})

        bandwidth_bps: None | int = interface.get("bandwidth")
        bandwidth_Mbps: None | int = bandwidth_bps // 1_000_000 if bandwidth_bps else None
        duplex: None | str = interface.get("duplex")
        duplex_map = {"duplexFull": "full", "duplexHalf": "half"}
        duplex: None | str = duplex_map.get(interface.get("duplex"), None)
        # Convert auto-negotiation to boolean
        auto_negotiation: bool = interface.get("autoNegotiate") != "off"

        return bandwidth_Mbps, duplex, auto_negotiation

    def populate_wan_group(self, interfaces):
        """Create WAN group with command 'group interface WAN' for adding all WAN interfaces"""
        cmds = []
        cmds.append("group interface WAN")

        for intf in interfaces:
            wan, device_name, intf_type = intf["wan"], intf["device"], intf["type"]

            # Exclude management, LOOPBACK interface to prevent unintended WAN grouping
            if "management" in intf or intf_type == "LOOPBACK":
                continue

            if intf_type == "VLAN":
                vlan_id = intf["vlanid"]
                intf_name = f"vlan {vlan_id}"
            else:
                intf_name = translate_mfw_interface_name_to_eos(device_name)
            interface_add_cmd = "   no " if not wan else "   "
            interface_add_cmd += f"interface {intf_name}"
            cmds.append(interface_add_cmd)

        cmds.append("!")
        return cmds

    def get_loopback_config(self, intf: dict[str, Any]) -> list[str]:
        """Generate config commands for loopback interface
        Parameters:
        intf (dict[str, Any]): The interface configuration dictionary.

        Returns:
        list[str]: A list of CLI configuration commands
        """
        commands = []
        commands.append(f"interface {translate_mfw_interface_name_to_eos(intf['device'])}")

        if intf["enabled"]:
            commands.append("   no shutdown")
        else:
            commands.append("   shutdown")

        if intf.get("name"):
            commands.append(f"   description {intf['name']}")
        else:
            commands.append("   no description")

        if intf["configType"] == "ADDRESSED":
            v4ConfigType = intf.get("v4ConfigType", "")
            if v4ConfigType == "STATIC":
                v4_addr = intf.get("v4StaticAddress")
                v4_prefix = intf.get("v4StaticPrefix")
                if v4_addr is not None and v4_prefix is not None:
                    commands.append(f"   ip address {v4_addr}/{v4_prefix}")
            elif v4ConfigType == "DISABLED":
                commands.append("   no ip address")

        else:
            msg = f"unsupported configType '{intf['configType']}'"
            raise AssertionError(msg)

        if intf.get("mtu"):
            commands.append(f"   mtu {intf['mtu']}")
        else:
            commands.append("   no mtu")
        commands.append("!")
        return commands


registrar.register_manager(InterfaceManager())
