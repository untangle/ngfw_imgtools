from sync import registrar
from sync.common.ips_manager import CronDIpsManager

registrar.register_manager(CronDIpsManager())
