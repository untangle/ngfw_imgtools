# Copyright (c) 2016 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

# Note: this is a copy of the EOS's version to be a standalone library
# This is temporary until mfw is fully integrated into EOS


import copy
import errno
import io
import json
import os
import select
import socket
import struct
import time


class EditConfigOptions:
    """Defined the possible edit config options and the default options.
    The options below are as per RFC 6241 Section 7.2"""

    OPERATION_MERGE = "merge"
    OPERATION_REPLACE = "replace"

    TEST_OPTION_TEST_THEN_SET = "testThenSet"
    TEST_OPTION_TEST_ONLY = "testOnly"
    TEST_OPTION_SET = "set"

    DEFAULT_OPERATION = OPERATION_MERGE
    DEFAULT_TEST_OPTION = TEST_OPTION_TEST_THEN_SET

    VALID_OPERATIONS = (OPERATION_MERGE, OPERATION_REPLACE)
    VALID_TEST_OPTIONS = (
        TEST_OPTION_TEST_THEN_SET,
        TEST_OPTION_SET,
        TEST_OPTION_TEST_ONLY,
    )


# Necessary supporting routines


INTEGER_STRUCT = struct.Struct("I")


def readNbytes(fd, totalBytes):
    """Given a file descriptor it will read exactly n bytes and return them or
    None in case of a read error. Note that if the writing end is python code then
    it can happen that a simple 32 bit entity gets broken up into pieces!"""
    chunks = []
    receivedBytes = 0
    while receivedBytes < totalBytes:
        chunk = fd.recv(totalBytes - receivedBytes)
        if chunk == b"":
            msg = "socket connection broken"
            raise RuntimeError(msg)
        chunks.append(chunk)
        receivedBytes += len(chunk)
    return b"".join(chunks)


def getIntFromIntStruct(intStruct):
    """Given a c struct that contains an integer we unpack it to get a python int"""
    return INTEGER_STRUCT.unpack_from(intStruct, 0)[0]


def readInteger(fd):
    """Given a file descriptor it will read an integer. Will return None if unable
    to read an integer"""
    bytesToRead = readNbytes(fd, INTEGER_STRUCT.size)
    if not bytesToRead:
        return None
    return getIntFromIntStruct(bytesToRead)


def sendAll(fd, string):
    bytesWritten = 0
    bytesToWrite = len(string)
    while bytesWritten < bytesToWrite:
        try:
            bytesSent = fd.send(string[bytesWritten:])
        except OSError as e:
            if e.errno == errno.EINTR:
                continue
            raise
        if bytesSent == 0:
            msg = "socket connection broken"
            raise RuntimeError(msg)
        bytesWritten += bytesSent
    return bytesWritten


def writeInteger(fd, num) -> None:
    """Given a file descriptor it will write an integer. Will throw an exception
    if message is not entirely sent"""
    sendAll(fd, INTEGER_STRUCT.pack(*(num,)))


def writeBytes(fd, data) -> None:
    """Given a file descriptor, we will write an integer with the length of the
    bytes, followed by the bytes itself. Will throw an exception if message is not
    entirely sent"""
    writeInteger(fd, len(data))
    sendAll(fd, data)


def writeString(fd, string) -> None:
    """Given a file descriptor, we will write an integer with the length of the
    string, followed by the string itself. Will throw an exception if message is not
    entirely sent"""
    writeBytes(fd, string.encode())


# External api to invoke eAPI going directly to the CLI process. This is similar
# other eAPI examples using jsonrpclib
#    from EapiClientLib import EapiClient
#    eapiClient = EapiClient()
#    print( eapiClient.runCmds( 1, [ "show version" ] ) )


CLI_SERVER_ADDRESS_FMT = "\x00/CliServer/%s"


class JsonRpcErrorCodes:
    """Error codes used in JSON RPC error responses"""

    # DO NOT change these numbers unless you know what you are doing:
    # these are part of the public API.

    # Predefined error codes:
    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603

    # Custom error codes:

    # Command execution failed:
    COMMAND_FAILED = 1000  # General error
    COMMAND_EXCEPTION = 1001  # InternalError
    COMMAND_INVALID = 1002  # String does not match any command
    COMMAND_UNCONVERTED = 1003  # Command has not been converted yet
    COMMAND_INCOMPATIBLE = 1004  # Marked as not compatible with CAPI
    COMMAND_UNAUTHORIZED = 1005  # Insufficient permissions to run the command
    COMMAND_CONFIG_LOCKED = 1006  # Configuration is locked


class CliConnector:
    def _createArgStr(self, argv):
        return "\x00".join(argv)

    def _createEnvStr(self, env):
        return "\x00".join([f"{key}\x00{value}" for key, value in env.items()])

    def _createAndSendSock(self, sock):
        s1, s2 = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM, 0)
        socket.send_fds(sock, [b"\0"], [s2.fileno()])
        s2.close()
        return s1

    def _connectToBackend(self, sysname, argv, env, uid, gid, ctty):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM, 0)
        startTime = time.time()
        # the CliServer might not be up at the beginning of time. So we will instead
        # keep track of our startTime, and if we haven't been able to connect
        # due to a connection refused we will raise that error.
        while True:
            try:
                sock.connect(CLI_SERVER_ADDRESS_FMT % sysname)
                break  # this means we were able to connect. break while loop
            except OSError as e:
                # if the error is something other than connection refuse we raise error
                if e.errno != errno.ECONNREFUSED:
                    raise

                currTime = time.time()
                # if we have waited for more than 120 seconds we also raise the error
                # otherwise we will continue our loop
                if currTime - startTime >= 120:
                    raise

                # we sleep a bit before we retry
                time.sleep(0.1)

        signalSock = self._createAndSendSock(sock)
        writeString(sock, self._createArgStr(argv))
        writeString(sock, self._createEnvStr(env))
        writeString(sock, str(uid))
        writeString(sock, str(gid))
        writeString(sock, ctty)
        return sock, signalSock


class EapiCliConnector(CliConnector):
    def __init__(self, stateless=True) -> None:
        self.stateless_ = stateless

    def connectToBackend(self, sysname, argv, env, uid, gid):
        sock, signalSock = self._connectToBackend(sysname, argv, env, uid, gid, "")
        os.write(sock.fileno(), b"c" if self.stateless_ else b"d")
        responseSock = self._createAndSendSock(sock)
        requestSock = self._createAndSendSock(sock)
        statisticsSock = self._createAndSendSock(sock)
        sock.close()
        return (signalSock, responseSock, requestSock, statisticsSock)


REQUEST_CONTENT = {
    "jsonrpc": "2.0",
    "method": None,
    "params": None,
    "id": "FastCliSocketLib",
}

REMOTE_SOCK_READ_SIZE = 65536
SELECT_TIMEOUT = 5


class EapiException(Exception):
    def __init__(self, msg=None, code=None, data=None) -> None:
        Exception.__init__(self, msg)
        self.msg = msg
        self.code = code
        self.data = data

    def __str__(self) -> str:
        msg = f"EapiClient error {self.code}: '{self.msg}'"
        if self.data:
            msg += f" Data: {self.data}"
        return msg


class _Method:
    def __init__(self, name, sysname, disableAaa, disableGuards, privLevel, env, uid, gid) -> None:
        self.name_ = name
        self.sysname_ = sysname
        self.disableAaa_ = disableAaa
        self.disableGuards_ = disableGuards
        self.env_ = env
        self.privLevel_ = privLevel
        self.uid_ = uid
        self.gid_ = gid
        self.signalSock_ = None
        self.responseSock_ = None
        self.statisticsSock_ = None

    def _disconnect(self) -> None:
        if self.signalSock_:
            self.signalSock_.close()
        self.signalSock_ = None
        if self.responseSock_:
            self.responseSock_.close()
        self.responseSock_ = None

    def _sendRequest(self, jsonRpcRequest) -> None:
        cliConnector = EapiCliConnector()
        argv = [f"-p={self.privLevel_}", f"-s={self.sysname_}"]
        if self.disableAaa_:
            argv.append("-A")
        if self.disableGuards_:
            argv.append("-G")
        (
            self.signalSock_,
            self.responseSock_,
            requestSock,
            self.statisticsSock_,
        ) = cliConnector.connectToBackend(self.sysname_, argv, self.env_, self.uid_, self.gid_)
        writeBytes(requestSock, jsonRpcRequest.encode())
        requestSock.close()

    def _getJsonRpcRequest(self, args, kwargs):
        request = copy.deepcopy(REQUEST_CONTENT)
        request["method"] = self.name_
        if kwargs:
            request["params"] = kwargs
        else:
            request["params"] = args
        return json.dumps(request)

    def _readStreamedResponse(self):
        readableSocks = [self.signalSock_, self.responseSock_]
        try:
            while True:
                try:
                    socksToRead = select.select(readableSocks, [], [])[0]
                except OSError as e:
                    if e.args[0] == errno.EINTR:
                        continue
                    raise
                if self.signalSock_ in socksToRead:
                    self.signalSock_.recv(1)
                    if not self.responseSock_:
                        # if we don't have anymore in the response buffer we don't need
                        # to clear it
                        return

                    # The FastClid-session has signaled to use that we are done producing
                    # output. So we clear the response buffer until it returns nothing
                    while True:
                        response = self.responseSock_.recv(REMOTE_SOCK_READ_SIZE)
                        if not response:
                            return
                        yield response
                    return
                if self.responseSock_ in socksToRead:
                    response = self.responseSock_.recv(REMOTE_SOCK_READ_SIZE)
                    if not response:
                        readableSocks.remove(self.responseSock_)
                        self.responseSock_.close()
                        self.responseSock_ = None
                    else:
                        yield response

        except Exception as e:
            raise EapiException(str(e), JsonRpcErrorCodes.INTERNAL_ERROR)
        finally:
            self._disconnect()

    def _readStatistics(self):
        try:
            requestCount = readInteger(self.statisticsSock_)
            commandCount = readInteger(self.statisticsSock_)
            return requestCount, commandCount
        except Exception as e:
            raise EapiException(str(e), JsonRpcErrorCodes.INTERNAL_ERROR)
        finally:
            self.statisticsSock_.close()
            self.statisticsSock_ = None

    def _jsonRpcCall(self, args, kwargs):
        jsonRpcRequest = self._getJsonRpcRequest(args, kwargs)
        try:
            self._sendRequest(jsonRpcRequest)
            responseBuffer = io.BytesIO()
            for i in self._readStreamedResponse():
                if i is None:
                    continue
                responseBuffer.write(i)
            self._readStatistics()
            response = json.loads(responseBuffer.getvalue())
            responseBuffer.close()
        except EapiException:
            raise
        except Exception as e:
            raise EapiException(str(e), JsonRpcErrorCodes.INTERNAL_ERROR)

        if "error" in response:
            raise EapiException(
                response["error"]["message"],
                response["error"]["code"],
                response["error"].get("data", None),
            )
        return response

    def _sendRpcRequest(self, args, kwargs):
        jsonRpcRequest = None
        if args:
            jsonRpcRequest = args[0]
        if kwargs:
            jsonRpcRequest = kwargs["jsonRpcRequest"]
        if jsonRpcRequest is None:
            msg = "'jsonRpcRequest' not specified"
            raise EapiException(msg, JsonRpcErrorCodes.INTERNAL_ERROR)

        try:
            self._sendRequest(jsonRpcRequest)
        except Exception as e:
            raise EapiException(str(e), JsonRpcErrorCodes.INTERNAL_ERROR)

        return self._readStreamedResponse(), self._readStatistics

    def __call__(self, *args, **kwargs):
        if kwargs and args:
            msg = "JSON-RPC does not support both positional and keyword arguments."
            raise EapiException(
                msg,
                JsonRpcErrorCodes.INVALID_PARAMS,
            )
        if self.name_ == "_sendRpcRequest":
            return self._sendRpcRequest(args, kwargs)
        return self._jsonRpcCall(args, kwargs)


class _EapiClientBase:
    def __init__(
        self,
        sysname="ar",
        disableAaa=False,
        disableGuards=False,
        privLevel=1,
        uid=os.getuid(),
        gid=os.getgid(),
        aaaAuthnId=None,
        realTty=None,
        logName=None,
        sshConnection=None,
    ) -> None:
        self.sysname_ = sysname
        self.disableAaa_ = disableAaa
        self.disableGuards_ = disableGuards
        self.privLevel_ = privLevel
        self.uid_ = uid
        self.gid_ = gid
        self.env_ = {}
        if aaaAuthnId is not None:
            self.env_["AAA_AUTHN_ID"] = aaaAuthnId
        if realTty is not None:
            self.env_["REALTTY"] = realTty
        if logName is not None:
            self.env_["LOGNAME"] = logName
        if sshConnection is not None:
            self.env_["SSH_CONNECTION"] = sshConnection


class EapiClient(_EapiClientBase):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

    def setPrivLevel(self, privLevel) -> None:
        self.privLevel_ = privLevel

    def __getattr__(self, name):
        return _Method(
            name,
            self.sysname_,
            self.disableAaa_,
            self.disableGuards_,
            self.privLevel_,
            self.env_,
            self.uid_,
            self.gid_,
        )


class EapiClientCtx(_EapiClientBase):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(**kwargs)
        self.signalSock_ = None
        self.responseSock_ = None
        self.requestSock_ = None
        self.statisticsSock_ = None

    def __enter__(self):
        cliConnector = EapiCliConnector(stateless=False)
        argv = [f"-p={self.privLevel_}", f"-s={self.sysname_}"]
        if self.disableAaa_:
            argv.append("-A")
        if self.disableGuards_:
            argv.append("-G")
        (
            signalSock,
            responseSock,
            requestSock,
            statisticsSock,
        ) = cliConnector.connectToBackend(self.sysname_, argv, self.env_, self.uid_, self.gid_)
        self.signalSock_ = signalSock
        self.responseSock_ = responseSock
        self.requestSock_ = requestSock
        self.statisticsSock_ = statisticsSock

    def sendRpcRequest(self, jsonRpcRequest):
        writeString(self.requestSock_, jsonRpcRequest)
        output = []
        done = False
        while not done:
            try:
                filesReadyToRead, _, _ = select.select(
                    [self.statisticsSock_, self.responseSock_], [], [], SELECT_TIMEOUT
                )
            except OSError as e:
                if e.args[0] == errno.EINTR:
                    # If we get interrupted we just go back to where we were before
                    continue
                raise

            if self.responseSock_ in filesReadyToRead:
                buf = self.responseSock_.recv(REMOTE_SOCK_READ_SIZE)
                output.append(buf)
            elif self.statisticsSock_ in filesReadyToRead:
                # now lets read the statistics to make sure everything is correct
                requestCount = readInteger(self.statisticsSock_)
                commandCount = readInteger(self.statisticsSock_)
                done = True

        response = b"".join(output).decode()

        return response, requestCount, commandCount

    def __exit__(self, errType, value, tb):
        # we are going to block until the front-end has disconnected
        self.requestSock_.close()
        self.requestSock_ = None
        self.responseSock_.close()
        self.responseSock_ = None
        self.statisticsSock_.close()
        self.statisticsSock_ = None
        self.signalSock_.recv(1)
        self.signalSock_.close()
        self.signalSock_ = None
