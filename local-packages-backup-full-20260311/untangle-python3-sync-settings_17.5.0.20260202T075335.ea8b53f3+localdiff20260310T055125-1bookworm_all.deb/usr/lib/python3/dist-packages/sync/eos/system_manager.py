"""This class handles writing configs through the EOS CLI."""

import os
from typing import Any

import sync.eos.utils as EosCommon
from sync import registrar
from sync.common import Logger
from sync.common.system_manager import CommonSystemManager
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_EARLY, EOS_CONFIG_LOAD_PRIORITY_LATE

TIMEZONE_CFG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_EARLY}timezone.cfg"
SYSTEM_CFG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_EARLY}system.cfg"
DNSMASQ_CFG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}dnsmasq.cfg"
HTTPMGMT_CFG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_EARLY}httpmgmt.cfg"
HOSTNAME_CFG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_EARLY}hostname.cfg"

logger = Logger.getInstance()


class ConfigWriter:
    """Creates and writes EOS configuration files."""

    def __init__(self, filename: str) -> None:
        self._config = ""
        self._commands = []
        self._functions = []
        self._config_filename = filename

    def generate_config_file_contents(self, settings: dict[str, Any]) -> None:
        """Generate configs to be written."""
        self._config = ""
        self._commands.clear()

        for f in self._functions:
            try:
                f(settings)
            except ValueError:
                logger.exception("")
                raise
        self._config = "\n".join(self._commands)

    def write_to_file(self, dir_path: str, prefix: str) -> None:
        """Write the config to file."""
        # write to file
        dirname = os.path.join(prefix, dir_path.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        with open(os.path.join(dirname, self._config_filename), "w", encoding="ascii") as f:
            f.write(self._config)

    def write(self, settings: dict[str, Any], prefix: str) -> None:
        try:
            self.generate_config_file_contents(settings)
            self.write_to_file(EosCommon.CONFIG_DIR, prefix)
        except Exception:
            logger.exception("")
            raise


class TimezoneConfigWriter(ConfigWriter):
    """Creates and writes EOS configuration file for timezone."""

    def __init__(self, filename: str) -> None:
        super().__init__(filename)
        self._functions.append(self.create_timezone_config)

    def create_timezone_config(self, settings: dict[str, Any]) -> None:
        """Generate config file from the system.timezone settings."""
        timezone_display = settings.get("system", {}).get("timeZone", {}).get("displayName")
        if timezone_display is None:
            msg = "No displayName in system.timeZone settings!"
            raise ValueError(msg)
        self._commands.append(f"clock timezone {timezone_display}")


class SystemConfigWriter(ConfigWriter):
    """Creates and writes EOS configuration file for hostname and static_configs."""

    def __init__(self, filename: str) -> None:
        super().__init__(filename)
        self._functions.append(self.create_domain_name_config)
        self._functions.append(self.create_static_configs)

    def create_domain_name_config(self, settings: dict[str, Any]) -> None:
        """Generate config file from the system.domainName settings."""
        domainName = settings.get("system", {}).get("domainName")
        if domainName is None:
            msg = "No domainName in system settings!"
            raise ValueError(msg)
        self._commands.append(f"dns domain {domainName}")

    def create_static_configs(self, settings: dict[str, Any]) -> None:
        """Write out static system config items"""
        self._commands.append("ip routing")


class DnsmasqConfigWriter(ConfigWriter):
    """Creates and writes EOS configuration file for dnsmasq."""

    def __init__(self, filename: str) -> None:
        super().__init__(filename)
        self._functions.append(self.create_dnsmasq_config)

    def create_dnsmasq_config(self, settings: dict[str, Any]) -> None:
        """Sets EOS dnsmasq into proxy mode"""
        self._commands.append("ip domain proxy")


class HttpManagementConfigWriter(ConfigWriter):
    """Creates and writes EOS configuration file for no http management."""

    def __init__(self, filename: str) -> None:
        super().__init__(filename)


class HostnameConfigWriter(ConfigWriter):
    """Creates and writes EOS configuration file for system hostname"""

    def __init__(self, filename: str) -> None:
        super().__init__(filename)
        self._functions.append(self.create_hostname_config)

    def create_hostname_config(self, settings: dict[str, Any]) -> None:
        """Generate config file from the system.hostname settings."""
        hostname = settings.get("system", {}).get("hostName")
        if hostname is None:
            msg = "No hostName in system settings!"
            raise ValueError(msg)
        self._commands.append(f"hostname {hostname}")


class SystemManager(CommonSystemManager):
    """SystemManager is responsible to write the system variables set in MFW to
    EOS."""

    def __init__(self) -> None:
        SystemConfigWriter(SYSTEM_CFG_FILENAME)
        HttpManagementConfigWriter(HTTPMGMT_CFG_FILENAME)

    def initialize(self) -> None:
        """Initialize this module."""

        registrar.register_settings_file("settings", self)
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, TIMEZONE_CFG_FILENAME),
            "eos-config",
            self,
        )
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, HOSTNAME_CFG_FILENAME),
            "eos-config",
            self,
        )
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, SYSTEM_CFG_FILENAME),
            "eos-config",
            self,
        )
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, DNSMASQ_CFG_FILENAME),
            "eos-config",
            self,
        )
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, HTTPMGMT_CFG_FILENAME),
            "eos-config",
            self,
        )

    def set_time_zone(self, settings_file: dict[str, Any], prefix: str) -> None:
        TimezoneConfigWriter(TIMEZONE_CFG_FILENAME).write(settings_file.settings, prefix)

    def set_host_name(self, settings_file: dict[str, Any], prefix: str) -> None:
        HostnameConfigWriter(HOSTNAME_CFG_FILENAME).write(settings_file.settings, prefix)

    def get_default_system_settings(self):
        """Gets the default EOS EFW system settings."""
        return {
            "hostName": "efw",
            "domainName": "example.com",
            "timeZone": {
                "displayName": "UTC",
                "value": "UTC",
            },
            "httpPort": "1024",
            "httpsPort": "1025",
            "cloud": {
                "enabled": True,
                "supportAccessEnabled": True,
                "cloudServers": ["cmd.edge.arista.com"],
            },
            "setupWizard": {"completed": False},
            "autoUpgrade": {
                "dayOfWeek": -1,
                "hourOfDay": -1,
                "minuteOfHour": -1,
                "enabled": True,
            },
            "autoBackup": {
                "dayOfWeek": -1,
                "hourOfDay": -1,
                "minuteOfHour": -1,
                "enabled": True,
            },
        }

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """Creates settings."""
        super().create_settings(settings_file, prefix, delete_list, filename)

    def sanitize_settings(self, settings_file) -> None:
        if not settings_file.settings.get("system"):
            settings_file.settings["system"] = self.get_default_system_settings()

        http_port = settings_file.get_settings_by_path("system/httpPort")
        if not http_port:
            logger.info("Creating default http port setting")
            http_port = settings_file.settings["system"]["httpPort"] = "1024"

        https_port = settings_file.get_settings_by_path("system/httpsPort")
        if not https_port:
            logger.info("Creating default https port setting")
            https_port = settings_file.settings["system"]["httpsPort"] = "1025"

    def validate_settings(self, settings_file) -> None:
        pass

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """Syncs settings."""
        super().sync_settings(settings_file, prefix, delete_list)
        for config_writer in [
            DnsmasqConfigWriter(DNSMASQ_CFG_FILENAME),
            HttpManagementConfigWriter(HTTPMGMT_CFG_FILENAME),
            SystemConfigWriter(SYSTEM_CFG_FILENAME),
        ]:
            config_writer.write(settings_file.settings, prefix)


registrar.register_manager(SystemManager())
