"""This class is responsible for validating DHCP config"""

from sync.common.validators.base_validator import Validator
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile


class DHCPValidator(Validator):
    """Handles validation of DHCP config"""

    def validate(self, settings_file: SettingsFile) -> None:
        """
        validates DNS and DHCP settings
        """

        dns_settings = settings_file.settings.get("dns")
        if dns_settings is not None and dns_settings.get("localServers") is not None:
            for local_server in dns_settings.get("localServers"):
                # Check if local_server is a dictionary before calling .get()
                if not isinstance(local_server, dict):
                    raise SettingsException(message="api_invalid_dns_localServer_format")
                if local_server.get("localServer") is None:
                    raise SettingsException(message="api_missing_dns_localServer")

        dhcp_settings = settings_file.settings.get("dhcp")
        if dhcp_settings is not None:
            if not isinstance(dhcp_settings, list):
                raise SettingsException(message="api_invalid_dhcp_format")

            dhcp_ids = set()
            for dhcp_config in dhcp_settings:
                if not isinstance(dhcp_config, dict):
                    raise SettingsException(message="api_invalid_dhcp_config_format")

                dhcp_id = dhcp_config.get("id")
                if dhcp_id is None:
                    raise SettingsException(message="api_missing_dhcp_id")

                # Check for duplicate IDs
                if dhcp_id in dhcp_ids:
                    raise SettingsException(message="api_duplicate_dhcp_id")
                dhcp_ids.add(dhcp_id)

                if dhcp_config.get("name") is None:
                    raise SettingsException(message="api_missing_dhcp_name")

                # Validate servers if present
                servers = dhcp_config.get("servers")
                if servers is not None:
                    if not isinstance(servers, list):
                        raise SettingsException(message="api_invalid_dhcp_servers_format")

                    for server in servers:
                        if not isinstance(server, dict):
                            raise SettingsException(message="api_invalid_dhcp_server_format")

                        if server.get("subnet") is None:
                            raise SettingsException(message="api_missing_dhcp_server_subnet")
                        if server.get("dns") is None:
                            raise SettingsException(message="api_missing_dhcp_server_dns")
                        if server.get("rangeStart") is None:
                            raise SettingsException(message="api_missing_dhcp_server_rangeStart")
                        if server.get("rangeEnd") is None:
                            raise SettingsException(message="api_missing_dhcp_server_rangeEnd")
                        if server.get("leaseDuration") is None:
                            raise SettingsException(
                                message="api_missing_dhcp_server_leaseDuration"
                            )
                        if server.get("gateway") is None:
                            raise SettingsException(message="api_missing_dhcp_server_gateway")

                        # CHANGE: Added staticDhcpEntries validation at server level
                        static_entries = server.get("staticDhcpEntries")
                        if static_entries is not None:
                            if not isinstance(static_entries, list):
                                raise SettingsException(
                                    message="api_invalid_dhcp_staticEntries_format"
                                )

                            for static_entry in static_entries:
                                if not isinstance(static_entry, dict):
                                    raise SettingsException(
                                        message="api_invalid_dhcp_staticEntry_format"
                                    )
                                if static_entry.get("macAddress") is None:
                                    raise SettingsException(message="api_missing_dhcp_macAddress")
                                if static_entry.get("address") is None:
                                    raise SettingsException(message="api_missing_dhcp_address")
