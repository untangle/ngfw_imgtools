# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

"""This class is responsible for writing ipsec config commands."""

from __future__ import annotations

import os
import re

import sync.eos.utils as EosCommon

# create/sync/sanitize settings functions are called in the order the managers register
from sync import Manager, registrar
from sync.common import Logger
from sync.common.sanitizers.ipsec_sanitizer import IpsecSanitizer
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE
from sync.settings_exception import SettingsException

logger = Logger.getInstance()

dh_group_codes = {
    "modp768": 1,
    "modp1024": 2,
    "modp1536": 5,
    "modp2048": 14,
    "modp3072": 15,
    "modp4096": 16,
    "modp6144": 17,
    "modp8192": 18,
    "modp1024s160": 22,
    "modp2048s224": 23,
    "modp2048s256": 24,
}


class IpsecManager(Manager):
    """IpsecManager writes Sysdb ipsec config."""

    IPSEC_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}ipsec.cfg"

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)
        logger.info("Initializing settings")

        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.IPSEC_CONFIG_FILENAME),
            "eos-config",
            self,
        )

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """
        Sanitizes IPsec settings by:
        - Ensuring consistent device naming (tu0, tu1, etc.)
        - Encrypting pre-shared keys and removing plain text versions

        :param settings_file: settings file to be sanitized
        :return: None
        """
        logger.info("sanitizes settings")
        # on Eos the device property can only be tunnel followed by a number for example
        # tunnel, tunnel0 etc. For consistency we would name the device fields tunnel followed by a number.
        tunnel_num = 0
        tu_pattern = r"tu\d+"
        tunnel_pattern = r"(Tunnel|tunnel)(\d+)"
        interfaces = self.get_ipsec_interfaces(settings_file)
        devices = {
            intf["device"]
            for intf in interfaces
            if intf.get("device") and re.fullmatch(tu_pattern, intf["device"])
        }
        for intf in interfaces:
            # Encrypt pre-shared keys using common sanitizer
            IpsecSanitizer.sanitize_ipsec_interface(intf)

            # Remove deprecated networks properties from local and remote objects (EFW-1830)
            # EOS no longer uses local/remote networks for IPsec configuration
            ipsec_config = intf.get("ipsec", {})
            if "local" in ipsec_config and isinstance(ipsec_config["local"], dict):
                ipsec_config["local"].pop("networks", None)
            if "remote" in ipsec_config and isinstance(ipsec_config["remote"], dict):
                ipsec_config["remote"].pop("networks", None)

            dev = intf.get("device", "")
            # if the intf's device name is in already in EOS format, skip reassgining
            if re.fullmatch(tu_pattern, dev):
                continue

            name = intf.get("name", "")
            matched = re.fullmatch(tunnel_pattern, name)
            if matched:
                name = "tu" + matched.group(2)
                devices.add(name)
                intf["device"] = name
                continue

            new_dev = f"tu{tunnel_num}"
            # For example, there are already tu1, tu2 existing
            # two new tunnels are getting created
            # this makes sure that the new two tunnels will be tu0 and tu3
            while new_dev in devices:
                tunnel_num += 1
                new_dev = f"tu{tunnel_num}"
                continue
            intf["device"] = new_dev
            tunnel_num += 1
        EosCommon.cleanup_absent_policies_from_ipsec_profile()

    def validate_ipsec_interface(self, ipsec_param: str, ipsec_interface: dict) -> None:
        """
        validates the ipsec parameters
        parameters like ike, sa, authentication data etc
        """
        ipsec_data = ipsec_interface.get("ipsec")
        if ipsec_param not in ipsec_data:
            raise SettingsException(
                message=f"{ipsec_param} data is not present for ipsec configuration",
                vars=["interface", ipsec_interface.get("device")],
            )
        # %any is not valid for tunnel source/destination.
        if any(word in ipsec_param for word in ["local", "remote"]):
            gw_ip = ipsec_data.get(ipsec_param).get("gateway")
            if not gw_ip or gw_ip == "%any":
                raise SettingsException(
                    message="gateway ip can not be empty or %any",
                    vars=["interface", ipsec_interface.get("device")],
                )

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates settings"""
        logger.info("validate settings")
        self.ipsec_enabled_intfs = self.get_ipsec_enabled_interfaces(settings_file)
        self.ipsec_intfs = self.get_ipsec_interfaces(settings_file)
        for intf in self.ipsec_enabled_intfs:
            if "ipsec" not in intf:
                raise SettingsException(
                    message="No ipsec config available for ipsec enabled interface",
                    vars=["interface", intf.get("device")],
                )

            self.validate_ipsec_interface("authentication", intf)
            self.validate_ipsec_interface("phase1", intf)
            self.validate_ipsec_interface("phase2", intf)
            self.validate_ipsec_interface("local", intf)
            self.validate_ipsec_interface("remote", intf)

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list: list[str]
    ) -> None:
        """sync settings"""
        logger.info("sync settings")
        config = self.get_ipsec_config()
        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        logger.info("Writing IPSEC config to %s", self.IPSEC_CONFIG_FILENAME)

        with open(os.path.join(dirname, self.IPSEC_CONFIG_FILENAME), "w") as file:
            file.write(config)

    def get_ipsec_enabled_interfaces(self, settings_file: SettingsFile) -> list[dict]:
        """returns ipsec enabled interfaces from settings.json"""
        interfaces = settings_file.get_settings_by_path("network/interfaces")
        return [
            interface
            for interface in interfaces
            if interface.get("type") == "IPSEC" and interface.get("enabled")
        ]

    def get_ipsec_interfaces(self, settings_file: SettingsFile) -> list[dict]:
        """returns ipsec interfaces from settings.json"""
        interfaces = settings_file.get_settings_by_path("network/interfaces")
        return [interface for interface in interfaces if interface.get("type") == "IPSEC"]

    def get_ipsec_config(self) -> str:
        """returns ipsec cli commands as string"""
        cmds = []
        running_config = EosCommon.get_running_config()
        if running_config:
            cmds.extend(EosCommon.remove_old_ipsec_configs(running_config))
        for intf in self.ipsec_intfs:
            intf_name = intf.get("device")
            ike_name = f"ike-{intf_name}"
            sa_name = f"sa-{intf_name}"
            profile_name = f"ipsec-{intf_name}-profile"

            # Decrypt the encrypted shared secret to get plain text for EOS CLI configuration.
            # The shared_secret is encrypted and stored as shared_secret_encrypted in settings.json.
            # Here, we decrypt it to use the plain text in EOS CLI commands.
            auth_config = intf.get("ipsec", {}).get("authentication", {})
            shared_secret = IpsecSanitizer.decrypt_shared_secret(auth_config, default="secret")

            cmds.append("ip security")
            ike_commands = self.get_ipsec_ike_commands(ike_name, intf["ipsec"])
            sa_commands = self.get_ipsec_sa_commands(sa_name, intf["ipsec"])
            cmds.extend(ike_commands)
            cmds.extend(sa_commands)
            cmds.extend(
                self.get_ipsec_profile_commands(
                    ike_name, sa_name, shared_secret, profile_name, ike_commands, sa_commands
                )
            )
            cmds.extend(self.get_ipsec_tunnel_commands(profile_name, intf))

        return "\n".join(cmds)

    def get_ipsec_ike_commands(self, ike_name: str, ipsec_config: dict) -> list[str]:
        """
        returns ipsec ike cli commands
        this creates the config commands for phase1
        For each interface, it creates the ike configuration
        """
        cmds = []
        if len(ipsec_config["phase1"]) > 0:
            encryption = ipsec_config.get("phase1")[0].get("encryption", "aes256")
            hash_algo = ipsec_config.get("phase1")[0].get("hash", "sha1")
            group = ipsec_config.get("phase1")[0].get("group", "modp2048")
            group_code = dh_group_codes.get(group, 14)
            ike_lifetime = int(ipsec_config.get("phase1Lifetime", "3600"))
            ike_lifetime_in_hours = ike_lifetime // 3600

            cmds.append(f"ike policy {ike_name}")
            cmds.append(f"  encryption {encryption}")
            cmds.append(f"  integrity {hash_algo}")
            cmds.append(f"  dh-group {group_code}")
            cmds.append(f"  ike-lifetime {ike_lifetime_in_hours}")
        return cmds

    def get_ipsec_sa_commands(self, sa_name: str, ipsec_config: dict) -> list[str]:
        """
        returns ipsec sa cli commands
        this creates the config commands for phase2
        For each interface, it creates the sa configuration
        """
        cmds = []
        if len(ipsec_config["phase2"]) > 0:
            encryption = ipsec_config.get("phase2")[0].get("encryption", "aes256")
            hash_algo = ipsec_config.get("phase2")[0].get("hash", "sha1")
            group = ipsec_config.get("phase2")[0].get("group", "modp2048")
            group_code = dh_group_codes.get(group, 14)
            sa_lifetime = int(ipsec_config.get("phase2Lifetime", "3600"))
            sa_lifetime_in_hours = sa_lifetime // 3600

            cmds.append(f"sa policy {sa_name}")
            cmds.append(f"  esp encryption {encryption}")
            cmds.append(f"  esp integrity {hash_algo}")
            cmds.append(f"  pfs dh-group {group_code}")
            cmds.append(f"  sa lifetime {sa_lifetime_in_hours}")
        return cmds

    def get_ipsec_profile_commands(
        self,
        ike_name: str,
        sa_name: str,
        secret_data: str,
        profile_name: str,
        ike_commands: list,
        sa_commands: list,
    ) -> list[str]:
        """
        returns ipsec sa cli commands
        For each interface, it creates the ipsec profile
        """
        cmds = []
        cmds.append(f"profile {profile_name}")
        if len(ike_commands) > 0:
            cmds.append(f"  ike-policy {ike_name}")
        if len(sa_commands) > 0:
            cmds.append(f"  sa-policy {sa_name}")
        cmds.append("  connection start")
        cmds.append(f"  shared-key {secret_data}")
        return cmds

    def get_ipsec_tunnel_commands(self, profile_name: str, ipsec_interface: dict) -> list[str]:
        """
        returns ipsec tunnel cli commands
        For each interface, it creates the tunnel configuration
        """
        cmds = []
        local_ip = ipsec_interface.get("ipsec").get("local").get("gateway")
        remote_ip = ipsec_interface.get("ipsec").get("remote").get("gateway")
        ip_addr = ipsec_interface.get("ipAddress", "")
        enabled = ipsec_interface.get("enabled")

        cmds.append(f"interface {ipsec_interface.get('device')}")
        if enabled:
            cmds.append("  no shutdown")
        else:
            cmds.append("  shutdown")
        if ip_addr:
            cmds.append(f"  ip address {ip_addr}")
        cmds.append("  tunnel mode ipsec")
        cmds.append(f"  mtu {ipsec_interface.get('mtu')}")
        cmds.append(f"  tunnel source {local_ip}")
        cmds.append(f"  tunnel destination {remote_ip}")
        cmds.append(f"  tunnel ipsec profile {profile_name}")
        return cmds


registrar.register_manager(IpsecManager())
