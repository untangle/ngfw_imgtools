import sync.registrar
from sync.board_util import BoardUtil

sync.registrar.register_operation(
    "restart-nftables-rules", [""], ["/usr/local/sbin/nftables-rules restart"], 9, None
)


# load all configuration files under /etc/mfw/eos
sync.registrar.register_operation(
    "eos-config",
    ["load-eos-config --verify --config-root-dir %tmpdir%"],
    # load-eos-config wipes sysdb entries when it copies to
    # running-config. Normally everything is configured via cli so
    # this is not noticed because the act of copying reconfigures
    # things, but for now DoS has no cli and we write to sysdb, so we
    # need to run dos_sync.py afterwards to put sysdb settings back
    # in.
    ["load-eos-config", "/usr/bin/dos_sync.py %settingsfile%"],
    10,
    None,
)

# load all configuration files under /etc/mfw/eos-always
sync.registrar.register_operation(
    "eos-config-always",
    ["load-eos-config --verify --always --config-root-dir %tmpdir%"],
    ["load-eos-config --always"],
    10,
    None,
)

# sync dos sysdb
sync.registrar.register_operation(
    "dos-config",
    [""],
    ["/usr/bin/dos_sync.py %settingsfile%"],
    12,
    "eos-config",
)

sync.registrar.register_operation(
    "restart-networking",
    [""],
    ["/etc/init.d/network reload"],
    11,
    None,
)

sync.registrar.register_operation(
    "restart-wan-routing",
    [""],
    ["/etc/config/nftables-rules.d/102-wan-routing; /etc/init.d/wan-manager restart"],
    12,
    None,
)

sync.registrar.register_operation("restart-qos", [""], ["/etc/init.d/qos restart"], 13, None)

sync.registrar.register_operation(
    "restart-ipsec", [""], ["/etc/init.d/ipsec restart ; ipsec restart"], 13, None
)
sync.registrar.register_operation(
    "restart-default-route",
    [""],
    ["/etc/config/ifdown.d/10-default-route"],
    14,
    "restart-networking",
)
sync.registrar.register_operation(
    "restart-restd-captive-portal", [""], ["pkill -HUP restd || true"], 30, None
)
sync.registrar.register_operation("restart-bctid", [""], ["systemctl restart bctid"], 30, None)
sync.registrar.register_operation(
    "sync-dos-active-session", [""], ["echo 'Nothing to do for EOS'"], 30, None
)
if not BoardUtil.is_running_in_openwrt():
    sync.registrar.register_operation(
        "restart-restd-access",
        [""],
        [
            "pkill -HUP restd || true",
            "/mnt/flash/mfw-settings/nftables-rules.d/200-access",
        ],
        30,
        None,
    )
    sync.registrar.register_operation(
        "restart-cron",
        [""],
        ["systemctl restart crond"],
        35,
        None,
    )
sync.registrar.register_operation(
    "SIGHUP-packetd", [""], ["/usr/bin/updateSysdbSignal --sighup"], 30, None
)
sync.registrar.register_operation(
    "restart-reportd-alerts", [""], ["pkill -HUP reportd || true"], 30, None
)
sync.registrar.register_operation(
    "restart-uid",
    [""],
    ["systemctl restart client-license-service", "systemctl restart pyconnector"],
    15,
    None,
)
