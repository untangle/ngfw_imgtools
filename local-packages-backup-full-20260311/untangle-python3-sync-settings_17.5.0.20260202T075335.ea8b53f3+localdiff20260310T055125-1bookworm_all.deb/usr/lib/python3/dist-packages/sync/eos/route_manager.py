"""
This class handles accounts (admin) credentials settings translation
from MFW settings.json to EOS Sysdb
"""

import os
import subprocess
from uuid import uuid4

import sync.eos.utils as EosCommon
import sync.network_util
from sync import registrar
from sync.common import Logger
from sync.common.route_manager import CommonRouteManager
from sync.common.validators.route_validator import RouteValidator
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE
from sync.perms_util import regain_permissions
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class RouteManager(CommonRouteManager):
    """
    RoutesManager is responsible to write static routes into Sysdb
    """

    STATIC_ROUTE_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}static_route.cfg"

    def initialize(self) -> None:
        """
        Initialize this module
        """
        logger.info("Initializing settings")
        registrar.register_settings_file("settings", self)
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.STATIC_ROUTE_FILENAME),
            "eos-config",
            self,
        )

    def _get_eos_interface_name(self, interface_id, settings):
        """
        Get EOS CLI format interface name from interface ID.

        Args:
            interface_id: The interface ID to look up
            settings: Settings object containing interface configurations

        Returns:
            str: EOS CLI format interface name, or empty string if interface not found
        """
        if not interface_id:
            return ""

        interface = sync.network_util.get_interface_by_id(settings, interface_id)
        if not interface:
            return ""

        device_name = interface.get("device")
        if not device_name:
            return ""

        return EosCommon.convert_intf_name_to_eos_cli_format(device_name)

    def create_static_route_config(self, mfw_routes, mfw_archived_routes, settings):
        """
        Write static routes to EOS
        @eos_routes: list of static routes in EOS
        @mfw_routes: list of static routes in MFW
        @mfw_archived_routes: list of archived static routes in MFW from last run
        """
        commands = []
        # Find deleted static routes in MFW, we want to remove those on EOS.
        for archived_route in mfw_archived_routes:
            if not self.is_route_in_list(archived_route, mfw_routes):
                archived_route_vrf = (
                    f"vrf {archived_route['vrf']} "
                    if archived_route.get("vrf") and archived_route["vrf"] != "default"
                    else ""
                )

                interface_id = archived_route.get("interfaceId")
                intf_name = self._get_eos_interface_name(interface_id, settings)
                archived_route_intf_name = f" {intf_name}" if intf_name else ""

                commands.append(
                    f"no ip route {archived_route_vrf}{archived_route['network']}{archived_route_intf_name} {archived_route['nextHop']}"
                )

        # Append routes in MFW.
        for mfw_route in mfw_routes:
            if "interface" in mfw_route:
                intf = sync.network_util.get_interface_by_device(settings, mfw_route["interface"])
                interface_id = intf["interfaceId"]
            else:
                interface_id = mfw_route.get("interfaceId")

            network = mfw_route.get("network")
            next_hop = mfw_route.get("nextHop")
            metric = mfw_route.get("metric")
            intf_name = ""
            vrf = mfw_route.get("vrf")
            if network is None or next_hop is None:
                logger.warning("Invalid static route config: %s %s", str(network), str(next_hop))
                continue
            if interface_id:
                intf_name = self._get_eos_interface_name(interface_id, settings)
                if not intf_name:
                    logger.warning("get_interface_by_id failed for %s", str(interface_id))
                    continue

            metric_command = f" metric {metric}" if metric else ""
            route_enabled = mfw_route.get("enabled")
            if vrf and vrf != "default":
                # Get the appropriate VRF route command prefix depending on route status
                vrf_route_prefix = "" if route_enabled else "no "
                commands.append(
                    f"{vrf_route_prefix}ip route vrf {vrf} {network} {next_hop}" + metric_command
                )
            elif route_enabled:
                commands.append(f"ip route {network} {intf_name} {next_hop}" + metric_command)
            else:
                commands.append(f"no ip route {network} {intf_name} {next_hop}" + metric_command)

        return "\n".join(commands)

    def get_static_routes_from_settings(self, routes, vrf_name) -> list:
        """
        Get static routes from settings
        """
        static_routes = []
        for route in routes:
            network = route.get("network")
            next_hop = route.get("nextHop")
            interface_id = route.get("interfaceId")
            metric = route.get("metric")
            enabled = route.get("enabled")
            if network is None or next_hop is None:
                logger.warning("Invalid static route config %s %s", str(network), str(next_hop))
                continue
            static_routes.append(
                {
                    "network": network,
                    "nextHop": next_hop,
                    "interfaceId": interface_id,
                    "metric": metric,
                    "enabled": enabled,
                    "vrf": vrf_name,
                }
            )
        return static_routes

    def get_routes_with_vrfs(self, vrfs: list[dict], routes_all: list[dict]) -> list[dict]:
        """
        Get a flattened list of all static routes associated with a list of VRFs.

        This method maps VRFs to their corresponding route objects using a GUID
        and aggregates all static routes from those objects into a single list.

        :param vrfs: A list of VRF objects (dictionaries), where each VRF may
                     contain a 'routes' key with a GUID referencing a route object.
        :param routes_all: A list of all available route objects (dictionaries),
                           where each object has an 'id' and a 'routes' list.
        :return: A list of all static route objects (dictionaries) for the given VRFs.
        """
        static_routes = []
        routes_map = {route.get("id"): route for route in routes_all}

        for vrf in vrfs:
            routes_guid = vrf.get("routes")
            if not routes_guid:
                continue

            vrf_name = vrf.get("name")
            if routes_guid in routes_map:
                routes_for_vrf = routes_map[routes_guid]
                routes = routes_for_vrf.get("routes")
                if routes:
                    static_routes.extend(self.get_static_routes_from_settings(routes, vrf_name))
        return static_routes

    def get_static_routes_from_eos(self):
        """
        Get current static routes from EOS
        """
        # Run eos command.
        try:
            with regain_permissions():
                result = subprocess.run(
                    ["/usr/bin/run-eos-command", "-c", "show ip route static"],
                    capture_output=True,
                    check=False,
                )
        except:
            # If we can't obtain the routes, we can't sync them.
            raise SettingsException(message="unable_to_run_eos_command")

        if result is None:
            return None
        # Parse the output
        routes = []
        for line in result.stdout.decode("utf-8").split("\n"):
            if "S" in line.strip():
                network = line.split()[1]
            if "via" in line:
                parts = line.split()
                next_hop = parts[1]
                routes.append(
                    {
                        "network": network,
                        "nextHop": next_hop.split(",")[0],
                        "interface": sync.network_util.translate_eos_interface_name_to_mfw(
                            parts[2]
                        ),
                    }
                )
        return routes

    def is_route_in_list(self, route, route_list) -> bool:
        """
        Check if route is in the list
        @route: route to check
        @route_list: list of routes
        """
        for r in route_list:
            if (
                r.get("network") == route.get("network")
                and r.get("nextHop") == route.get("nextHop")
                and r.get("interfaceId", 0) == route.get("interfaceId", 0)
            ):
                return True
        return False

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        syncs settings
        """

        vrfs = settings_file.settings.get("vrf", [])
        routes_all = settings_file.settings.get("routes", [])
        static_routes = self.get_routes_with_vrfs(vrfs, routes_all)

        archived_vrfs = settings_file.settings.get("archive").get("last_run").get("vrf", [])
        archived_routes_all = (
            settings_file.settings.get("archive").get("last_run").get("routes", [])
        )
        archived_static_routes = self.get_routes_with_vrfs(archived_vrfs, archived_routes_all)

        config = ""
        if static_routes or archived_static_routes:
            config = self.create_static_route_config(
                static_routes if static_routes else [],
                archived_static_routes if archived_static_routes else [],
                settings_file.settings,
            )

        # write to file
        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        with open(os.path.join(dirname, self.STATIC_ROUTE_FILENAME), "w") as f:
            f.write(config)

    def validate_route_ids(self, settings_file) -> None:
        """
        checks if the id in the route object is a valid uuid
        """
        routes_all = settings_file.settings.get("routes", [])

        for routes_for_vrf in routes_all:
            route_id = routes_for_vrf.get("id")
            if route_id and not EosCommon.is_valid_uuid(route_id):
                msg = f"Invalid route id: '{route_id}'. Is not a valid UUID."
                raise SettingsException(msg)

    def validate_settings(self, settings_file) -> None:
        """validates settings"""
        routeValidator = RouteValidator(settings_file)
        routeValidator.validate()
        self.validate_route_ids(settings_file)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["archive"] = {}

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        logger.info("sanitizes settings")
        EosCommon.ensure_archive_structure(settings_file, "routes")

        vrfs = settings_file.settings.get("vrf", [])
        routes_all = settings_file.settings.get("routes", [])
        interfaces_all = settings_file.settings.get("network", {}).get("interfaces", [])

        routes_map = {route.get("id"): route for route in routes_all}
        interfaces_map = {intf.get("interfaceId"): intf for intf in interfaces_all}

        for vrf in vrfs:
            routes_guid = vrf.get("routes")
            vrf_interface_ids = vrf.get("interfaces", [])
            vrf_interfaces = [
                interfaces_map[intf_id]
                for intf_id in vrf_interface_ids
                if intf_id in interfaces_map
            ]

            wan_gateway_routes = self.get_wan_gateway_routes(vrf_interfaces)

            # If WAN interface is present but the routes is not created
            if wan_gateway_routes and not routes_guid:
                new_guid = str(uuid4())
                new_route_object = {
                    "id": new_guid,
                    "name": f"{vrf.get('name', '')} vrf routes",
                    "routes": [],
                }
                routes_all.append(new_route_object)
                routes_map[new_guid] = new_route_object
                vrf["routes"] = new_guid
                routes_guid = new_guid

            if routes_guid in routes_map:
                routes_for_vrf = routes_map[routes_guid]
                routes = routes_for_vrf.get("routes", [])
                # We need to detect if the default gateway route (NextHop) for the respective vrf was changed from the last run.
                # If the route is new, add it to the list of static routes.
                for route in wan_gateway_routes:
                    if self.find_and_replace_route(route, routes) is None:
                        routes.append(route)

    def archive_settings(self, settings_file) -> None:
        """Save static routes for next run"""
        routes = settings_file.settings.get("routes")
        settings_file.settings["archive"]["last_run"]["routes"] = routes

    def find_and_replace_route(self, route, routes):
        """
        Find and replace a route in the list. This is used to detect if the default gateway route
        was changed from the last run.
        """
        replaced_route = None
        for r in routes:
            if r.get("interfaceId") == route.get("interfaceId") and r.get("network") == route.get(
                "network"
            ):
                replaced_route = r
                r["nextHop"] = route.get("nextHop")
                r["metric"] = route.get("metric")
                r["enabled"] = route.get("enabled")
                if route.get("description"):
                    r["description"] = route.get("description", "")

        return replaced_route

    def get_wan_gateway_routes(self, vrf_interfaces: list[dict]) -> list[dict]:
        """
        Get default WAN routes for a given list of VRF interfaces.

        This method iterates through a list of interface objects and generates default
        "quad-zero" (0.0.0.0/0) routes for enabled WAN interfaces that are configured
        with a static IPv4 address and gateway.

        :param vrf_interfaces: A list of interface objects (dictionaries), each
                               representing a network interface associated with a VRF.
        :return: A list of default WAN route objects (dictionaries) to be added to
                 the static route configuration.
        """
        default_wan_routes = []
        for interface in vrf_interfaces:
            if not interface.get("enabled"):
                continue
            if (
                interface.get("wan")
                and interface.get("v4ConfigType") == "STATIC"
                and interface.get("v4StaticGateway") is not None
            ):
                # Add route to list
                network = "0.0.0.0/0"
                next_hop = interface.get("v4StaticGateway")
                # If metric is set, use it. Otherwise, set to 0.
                metric = interface.get("v4StaticGatewayMetric")
                metric = int(metric) if metric is not None else 0
                device_name = EosCommon.convert_intf_name_to_eos_cli_format(
                    interface.get("device")
                )
                device_name = device_name.replace("et", "Ethernet")

                r = {
                    "network": network,
                    "nextHop": next_hop,
                    "interfaceId": interface.get("interfaceId"),
                    "metric": metric,
                    "description": f"Default route for {device_name}",
                    "enabled": True,
                }

                # Append to list
                default_wan_routes.append(r)
        return default_wan_routes


registrar.register_manager(RouteManager())
