# Copyright (c) 2023 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

import os

from sync.board_util import BoardUtil

# EOS configuration dependencies
# For example, interfaces must be loaded before acl/nat
EOS_CONFIG_LOAD_PRIORITY_EARLY = "01-"
EOS_CONFIG_LOAD_PRIORITY_TWO = "02-"
EOS_CONFIG_LOAD_PRIORITY_LATE = "10-"

from sync.common import (
    network_manager,
)

from . import (
    accounts_manager,
    acl_manager,
    bgp_manager,
    connectivity_manager,
    dhcp_manager,
    dos_manager,
    dynamic_lists_manager,
    interface_manager,
    ips_manager,
    ipsec_manager,
    nat_manager,
    operations,
    route_manager,
    static_dns_manager,
    system_manager,
    table_manager,
    threat_prevention_manager,
    track_manager,
    uid_manager,
    upstream_dns_manager,
    vrf_manager,
)

# As part of MFW-6411 we remove references to hybrid
# but EFW-142 suggests vrrp_nat_manager should not be created on active

from sync.common import (
    alerts_manager,
    application_control_manager,
    bypass_manager,
    captive_portal_manager,
    databases_manager,
    discovery_manager,
    dnsfilter_manager,
    geoip_manager,
    policy_manager,
    reports_manager,
    settings_manager,
    stats_manager,
    uri_manager,
    web_filter_manager,
    webroot_manager,
)
