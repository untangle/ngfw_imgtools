"""This class is responsible for managing upstream DNS configuration."""

import os
import re
import uuid

import sync.eos.utils as EosCommon
from sync import Manager, SettingsFile, registrar
from sync.common import Logger
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class UpstreamDnsManager(Manager):
    """UpstreamDnsManager manages upstream DNS configurations for VRF-aware DNS."""

    UPSTREAM_DNS_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}upstream_dns.cfg"

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)

        registrar.register_file(
            os.path.join(EosCommon.CONFIG_ALWAYS_DIR, self.UPSTREAM_DNS_CONFIG_FILENAME),
            "eos-config-always",
            self,
        )

    def create_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list: list, filename: str
    ) -> None:
        """Creates upstream_dns settings with an empty list."""
        logger.info("create_settings")

        # Initialize with empty upstream_dns list
        settings_file.settings["upstream_dns"] = []

        EosCommon.ensure_archive_structure(settings_file, "upstream_dns")

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """
        Sanitizes upstream_dns settings by ensuring required fields have default values.
        """
        logger.info("sanitize_settings")

        # Ensure upstream_dns list exists
        if settings_file.settings.get("upstream_dns") is None:
            settings_file.settings["upstream_dns"] = []

        EosCommon.ensure_archive_structure(settings_file, "upstream_dns")

        # Sanitize each upstream_dns entry
        for dns_config in settings_file.settings.get("upstream_dns", []):
            # Ensure id exists
            if "id" not in dns_config or dns_config["id"] is None:
                dns_config["id"] = str(uuid.uuid4())

            # Ensure name exists
            if "name" not in dns_config:
                dns_config["name"] = "Upstream DNS"

            # Ensure servers list exists
            if "servers" not in dns_config or dns_config["servers"] is None:
                dns_config["servers"] = []

            # Sanitize each server entry
            for idx, server in enumerate(dns_config.get("servers", [])):
                # Ensure priority exists
                if "priority" not in server or server["priority"] is None:
                    server["priority"] = idx * 10

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """
        Validates upstream_dns settings.
        """
        logger.info("validate_settings")

        upstream_dns_list = settings_file.settings.get("upstream_dns", [])

        if not isinstance(upstream_dns_list, list):
            raise SettingsException(
                message="invalid_parameter_type",
                vars=["upstream_dns", "list"],
            )

        # Track IDs to ensure uniqueness
        seen_ids = set()

        for dns_config in upstream_dns_list:
            if not isinstance(dns_config, dict):
                raise SettingsException(
                    message="invalid_parameter_type",
                    vars=["upstream_dns entry", "dict"],
                )

            # Validate id
            dns_id = dns_config.get("id")
            if not dns_id or not isinstance(dns_id, str):
                raise SettingsException(
                    message="missing_or_invalid_parameter_value",
                    vars=["upstream_dns", "id"],
                )

            # Check for duplicate IDs
            if dns_id in seen_ids:
                raise SettingsException(
                    message="duplicate_upstream_dns_id",
                    vars=["upstream_dns", dns_id],
                )
            seen_ids.add(dns_id)

            # Validate name
            if not dns_config.get("name") or not isinstance(dns_config["name"], str):
                raise SettingsException(
                    message="missing_or_invalid_parameter_value",
                    vars=["upstream_dns", "name"],
                )

            # Validate servers
            servers = dns_config.get("servers")
            if not isinstance(servers, list):
                raise SettingsException(
                    message="missing_or_invalid_parameter_value",
                    vars=["upstream_dns", "servers"],
                )

            for server in servers:
                if not isinstance(server, dict):
                    raise SettingsException(
                        message="invalid_parameter_type",
                        vars=["upstream_dns.servers entry", "dict"],
                    )

                # Validate ip
                if not server.get("ip") or not isinstance(server["ip"], str):
                    raise SettingsException(
                        message="missing_or_invalid_parameter_value",
                        vars=["upstream_dns.servers", "ip"],
                    )

                # Validate priority
                priority = server.get("priority")
                if priority is None or not isinstance(priority, int):
                    raise SettingsException(
                        message="missing_or_invalid_parameter_value",
                        vars=["upstream_dns.servers", "priority"],
                    )

    def archive_settings(self, settings_file: SettingsFile) -> None:
        """
        Save upstream_dns configuration for next run.

        Note: We only store raw upstream_dns here. The VRF data is stored by vrf_manager.
        During the next run, we reconstruct the VRF-nameserver mappings on-the-fly from
        both archived upstream_dns and archived vrf data.
        """
        # Store raw upstream_dns list
        settings_file.settings["archive"]["last_run"]["upstream_dns"] = settings_file.settings.get(
            "upstream_dns"
        )

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list: list[str]
    ) -> None:
        """
        Sync settings - writes upstream DNS server configuration to EOS config file.

        Generates 'ip name-server' commands for each VRF based on upstream_dns
        configurations assigned to VRFs.
        """
        logger.info("Syncing upstream DNS settings")

        dirname = os.path.join(prefix, EosCommon.CONFIG_ALWAYS_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        config = self.get_upstream_dns_config(settings_file.settings)

        # Write to file
        with open(os.path.join(dirname, self.UPSTREAM_DNS_CONFIG_FILENAME), "w") as f:
            f.write(config)

    def get_upstream_dns_config(self, settings: dict) -> str:
        """
        Generate upstream DNS server configuration for EOS.

        Uses intelligent deletion detection to manage nameservers:
        - Adds nameservers from settings.json
        - Deletes nameservers that were removed from settings (tracked via archive)
        - Preserves manually configured nameservers during startup (not in archive)
        - SuperServer NetConfigReactor syncs Sysdb nameservers into settings.json

        :param settings: The settings dictionary containing upstream_dns and vrf
        :return: EOS CLI commands as a string
        """
        commands = []

        # Build current nameserver list
        current_nameservers = self._build_vrf_nameserver_map(settings)

        # Reconstruct archived nameserver list from archived upstream_dns and vrf
        # (vrf_manager stores archive["last_run"]["vrf"])
        archived_settings = {
            "upstream_dns": settings.get("archive", {})
            .get("last_run", {})
            .get("upstream_dns", []),
            "vrf": settings.get("archive", {}).get("last_run", {}).get("vrf", []),
        }
        archived_nameservers = self._build_vrf_nameserver_map(archived_settings)

        # Find deleted nameservers (were in archive, not in current)
        deleted_nameservers = self._get_deleted_nameservers(
            current_nameservers, archived_nameservers
        )

        # Query running config to verify which nameservers actually exist
        # This prevents errors when trying to delete already-deleted nameservers
        running_config_nameservers = self._get_current_nameservers_from_running_config()

        # Generate deletion commands for each removed nameserver
        for ns in deleted_nameservers:
            vrf_name = ns["vrf"]
            ip = ns["ip"]
            priority = ns.get("priority", 0)

            # Only delete if the nameserver currently exists in running config
            # This prevents the race condition where IntfConfigManager already deleted it
            if (vrf_name, ip) not in running_config_nameservers:
                logger.info(
                    "Skipping deletion of nameserver %s from VRF %s - "
                    "not found in running config (already deleted via CLI or SuperServer)",
                    ip,
                    vrf_name,
                )
                continue

            # Generate deletion command (no priority needed for deletion)
            commands.append(f"no ip name-server vrf {vrf_name} {ip}")

            logger.info(
                "Deleting nameserver %s from VRF %s (priority was %s) - "
                "removed from settings.json and exists in running config",
                ip,
                vrf_name,
                priority,
            )

        # Get upstream_dns configurations and VRFs
        upstream_dns_list = settings.get("upstream_dns", [])
        vrfs = settings.get("vrf", [])

        # Create a mapping of upstream_dns id to configuration
        upstream_dns_map = {dns_config["id"]: dns_config for dns_config in upstream_dns_list}

        # For each VRF, check if it has an upstream_dns assignment
        for vrf in vrfs:
            vrf_name = vrf.get("name", "default")
            upstream_dns_id = vrf.get("upstream_dns")

            # If this VRF has an upstream_dns assigned, add those servers
            if upstream_dns_id and upstream_dns_id in upstream_dns_map:
                dns_config = upstream_dns_map[upstream_dns_id]
                servers = dns_config.get("servers", [])

                for server in servers:
                    ip = server.get("ip")
                    priority = server.get("priority", 0)

                    if ip:
                        if priority > 0:
                            commands.append(
                                f"ip name-server vrf {vrf_name} {ip} priority {priority}"
                            )
                        else:
                            commands.append(f"ip name-server vrf {vrf_name} {ip}")

        commands.append("!")
        return "\n".join(commands)

    def _build_vrf_nameserver_map(self, settings: dict) -> list[dict]:
        """
        Build a normalized list of VRF-nameserver combinations from settings.

        This method extracts all nameservers configured across all VRFs and returns
        them in a normalized format that enables comparison with archived state.

        :param settings: The settings dictionary containing upstream_dns and vrf
        :return: List of dicts like [{"vrf": "default", "ip": "172.22.22.40", "priority": 0}, ...]
        """
        nameservers = []
        upstream_dns_list = settings.get("upstream_dns", [])
        vrfs = settings.get("vrf", [])

        # Create mapping of upstream_dns id to configuration
        upstream_dns_map = {dns_config["id"]: dns_config for dns_config in upstream_dns_list}

        # For each VRF, extract its assigned nameservers
        for vrf in vrfs:
            vrf_name = vrf.get("name", "default")
            upstream_dns_id = vrf.get("upstream_dns")

            if upstream_dns_id and upstream_dns_id in upstream_dns_map:
                dns_config = upstream_dns_map[upstream_dns_id]
                servers = dns_config.get("servers", [])

                for server in servers:
                    ip = server.get("ip")
                    priority = server.get("priority", 0)

                    if ip:
                        nameservers.append({"vrf": vrf_name, "ip": ip, "priority": priority})

        return nameservers

    def _get_deleted_nameservers(
        self, current_nameservers: list[dict], archived_nameservers: list[dict]
    ) -> list[dict]:
        """
        Find nameservers that existed in the previous run but not in current settings.

        This method compares VRF-nameserver combinations to detect deletions.
        A nameserver is considered deleted if it was in the archive but is NOT
        in the current configuration.

        We ignore priority in comparison - if only priority changes, we generate
        a new add command with the new priority (EOS will update it). We only
        delete if the IP is completely removed from a VRF.

        :param current_nameservers: List of current VRF-nameserver combinations
        :param archived_nameservers: List of archived VRF-nameserver combinations
        :return: List of deleted VRF-nameserver combinations
        """
        # Create a set of (vrf, ip) tuples for fast lookup
        # We ignore priority in comparison since it can change without deletion
        current_set = {(ns["vrf"], ns["ip"]) for ns in current_nameservers}

        deleted_nameservers = []
        for archived_ns in archived_nameservers:
            archived_key = (archived_ns["vrf"], archived_ns["ip"])
            if archived_key not in current_set:
                deleted_nameservers.append(archived_ns)

        return deleted_nameservers

    def _get_current_nameservers_from_running_config(self) -> set[tuple[str, str]]:
        """
        Query EOS running config to get currently configured nameservers.

        Prevents deletion commands for nameservers that don't exist (already deleted via CLI).

        Returns:
            Set of (vrf, ip) tuples representing nameservers in running config.
            Returns empty set if query fails (safer to skip deletions than delete incorrectly).
        """
        nameserver_set = set()

        try:
            running_config = EosCommon.get_running_config_section("ip")

            if not running_config:
                logger.warning(
                    "Failed to query running config for nameservers - "
                    "running config section 'ip' returned None"
                )
                return nameserver_set

            # Match: ip name-server vrf <vrf> <ip> [priority <num>]
            nameserver_pattern = r"^ip name-server vrf (\S+) (\S+)(?:\s+priority\s+\d+)?$"

            for line in running_config.splitlines():
                match = re.match(nameserver_pattern, line.strip())
                if match:
                    vrf_name = match.group(1)
                    ip_address = match.group(2)
                    nameserver_set.add((vrf_name, ip_address))

            logger.info(
                "Found %d nameservers in running config: %s", len(nameserver_set), nameserver_set
            )

        except Exception as e:
            logger.error(
                "Exception while querying running config for nameservers: %s. "
                "Skipping deletion verification - no deletions will be performed.",
                str(e),
            )
            return set()

        return nameserver_set


registrar.register_manager(UpstreamDnsManager())
