from sync.common.creators.base_creator import Creator
from sync.settings_file import SettingsFile


class DHCPCreator(Creator):
    """Creates default settings for DHCP"""

    def create(self, settings_file: SettingsFile) -> None:
        if "dns" not in settings_file.settings:
            settings_file.settings["dns"] = {}
            settings_file.settings["dns"]["localServers"] = []
            settings_file.settings["dns"]["staticEntries"] = []

        # Initialize DHCP as an empty list for the new structure
        settings_file.settings["dhcp"] = []
