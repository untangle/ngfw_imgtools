#!/usr/bin/env python3
# Copyright (c) 2022 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

import re
from typing import List, Optional, Tuple
from uuid import UUID

from sync.board_util import get_wan_interfaces
from sync.common import Logger
from sync.eos.MfwEapiClientLib import EapiClient, EapiException
from sync.settings_file import SettingsFile

CONFIG_DIR = "/etc/mfw/eos"
CONFIG_ALWAYS_DIR = "/etc/mfw/eos-always"
MFW_ROOTFS = "/mfw"

logger = Logger.getInstance()


def convert_intf_name_to_eos_cli_format(intf_name):
    if "_" in intf_name:
        return intf_name.replace("_", "/")
    return intf_name


def intf_has_acl_chain(intf):
    has_acl_chain = "et" in intf.get("device", "")
    enabled = intf.get("enabled", False)
    return has_acl_chain and enabled


def get_interfaces_with_acl_chains_attached(intf_list):
    return [intf for intf in intf_list if intf_has_acl_chain(intf)]


def get_enabled_ipsec_interfaces(intf_list):
    return [intf for intf in intf_list if intf.get("type") == "IPSEC" and intf.get("enabled")]


def is_ipv4_static(intf):
    return intf.get("v4ConfigType") == "STATIC"


def is_default_wan_interface(intf):
    default_wan_intfs = get_wan_interfaces()
    device = intf.get("device", "")
    return device in default_wan_intfs


def execute_eos_cli_cmds(eapi_client, *cmds):
    """
    Executes one or more CLI commands on the target device using the provided
    EAPI client. Handles both a single command string or a list of commands.

    Args:
        eapi_client: The EAPI client used to execute commands.
        cmds: A single command (string) or a list of commands to execute.

    Returns:
        A list of results with each index corresponding to the order it was presented
        in cmds. If an EapiException occurs, None is returned
    """
    try:
        result = eapi_client.runCmds(version=1, cmds=cmds, format="text", requestTimeout=1)[
            "result"
        ]
    except EapiException:
        result = None

    return result


def format_cmd_for_eapi_bash_execution(cmd, timeout_sec=1) -> str:
    return f"bash timeout {timeout_sec} bash -c {cmd}"


def get_running_config():
    cmd_result = execute_eos_cli_cmds(
        EapiClient("ar", disableAaa=True, privLevel=15), "show running-config"
    )

    return cmd_result[0]["output"] if cmd_result else None


def get_running_config_section(section: str):
    """
    Retrieve a specific section of the running configuration from the device.
    """
    cmd_result = execute_eos_cli_cmds(
        EapiClient("ar", disableAaa=True, privLevel=15), "show running-config section " + section
    )

    return cmd_result[0]["output"] if cmd_result else None


def get_startup_config():
    cmd_result = execute_eos_cli_cmds(
        EapiClient("ar", disableAaa=True, privLevel=15), "show startup-config"
    )

    return cmd_result[0]["output"] if cmd_result else None


def remove_acls_matching_regex(running_config, acl_name_matcher):
    pattern = rf"^ip access-list {acl_name_matcher}$"
    cmds = []
    for line in running_config.splitlines():
        acl_config_line = line.strip()
        if re.match(pattern, acl_config_line):
            cmds.append(f"no {acl_config_line}")

    return cmds


def remove_nat_pools_matching_regex(running_config, nat_pool_name_matcher):
    pattern = rf"^ip nat pool {nat_pool_name_matcher}"
    cmds = []
    for line in running_config.splitlines():
        nat_pool_config_line = line.strip()
        if re.match(pattern, nat_pool_config_line):
            cmds.append(f"no {nat_pool_config_line}")

    return cmds


def vrf_settings_present(settings_file: SettingsFile) -> Tuple[bool, Optional[List]]:
    """It checks if vrf configuration is present."""
    vrfs = settings_file.settings.get("vrf", [])
    if not isinstance(vrfs, list) or not vrfs:
        logger.info("No settings for vrf")
        return False, None
    return True, vrfs


def get_interface_id_vrf_name_dict(settings_file: SettingsFile) -> dict:
    """It returns the interface id to vrf name dict."""
    exists, vrfs = vrf_settings_present(settings_file)
    if not exists:
        logger.info("empty vrf settings")
        return {}

    interface_id_vrf_name = {
        intf_id: vrf.get("name", "default") for vrf in vrfs for intf_id in vrf.get("interfaces")
    }
    return interface_id_vrf_name


def remove_old_ipsec_configs(running_config):
    """
    This method will generate cmds to remove old ipsec configs that were created by sync-settings.
    It removes tunnels, profiles, sa policies, and ike policies associated with tunnel interfaces.
    """
    cmds = []

    # Patterns for sync-settings created IPsec configurations
    tunnel_interface_pattern = r"^interface [tT]unnel\d+"

    tunnels_to_remove = []

    for line in running_config.splitlines():
        config_line = line.strip()
        if re.match(tunnel_interface_pattern, config_line):
            tunnels_to_remove.append(f"no {config_line}")

    # Order of deletion is important: tunnels, then profiles, then policies
    # cmds.extend(profiles_to_detach)
    cmds.extend(tunnels_to_remove)

    cmds.append("no ip security")
    return cmds


def cleanup_absent_policies_from_ipsec_profile() -> str:
    """
    This is a cleanup function which removes policy associations from an IPsec profile for which
    the policy definition does not exist.
    """
    cmds = ["configure", "ip security"]

    running_config = get_running_config_section("ip security")

    defined_ike_policies = set()
    defined_sa_policies = set()
    profiles = {}

    current_profile = None

    if not running_config:
        return None

    # collect definitions and associations
    for line in running_config.splitlines():
        config_line = line.strip()

        # IKE policy definitions
        m = re.match(r"^ike policy (\S+)", config_line)
        if m:
            defined_ike_policies.add(m.group(1))
            continue

        # SA policy definitions
        m = re.match(r"^sa policy (\S+)", config_line)
        if m:
            defined_sa_policies.add(m.group(1))
            continue

        # Profile start
        m = re.match(r"^profile (\S+)", config_line)
        if m:
            current_profile = m.group(1)
            profiles[current_profile] = {"ike": None, "sa": None}
            continue

        if current_profile:
            # IKE association
            m = re.match(r"^ike-policy (\S+)", config_line)
            if m:
                profiles[current_profile]["ike"] = m.group(1)
                continue

            # SA association
            m = re.match(r"^sa-policy (\S+)", config_line)
            if m:
                profiles[current_profile]["sa"] = m.group(1)
                continue

            # End of profile block
            if config_line == "!":
                current_profile = None

    # generate cleanup commands
    for profile, policies in profiles.items():
        ike_policy = policies["ike"]
        sa_policy = policies["sa"]

        if ike_policy and ike_policy not in defined_ike_policies:
            cmds.extend([f"profile {profile}", f"no ike-policy {ike_policy}"])

        if sa_policy and sa_policy not in defined_sa_policies:
            cmds.extend([f"profile {profile}", f"no sa-policy {sa_policy}"])

    if cmds:
        cmd_result = execute_eos_cli_cmds(EapiClient("ar", disableAaa=True, privLevel=15), *cmds)

    return cmd_result[0]["output"] if cmd_result else None


def remove_old_bgp_configs(running_config: str, settings_vrfs: set) -> list[str]:
    """
    This method will generate cmds to remove old bgp configs.
    """
    bgp_vrf_pattern = r"^vrf (?!default$)(.+)"
    bgp_router_pattern = r"^router-id\s+\S+"
    bgp_network_pattern = r"^network\s+\S+"
    bgp_neighbor_pattern = r"^neighbor\s+(\S+)"
    bgp_graceful_restart_pattern = r"^(?<!no\s)graceful-restart$"
    bgp_router_asn = r"^router\s+bgp\s+\d+$"

    cmds = []
    seen_neighbors = set()
    bgp_router_present = False

    current_vrf = "default" if "default" in settings_vrfs else ""
    for line in running_config.splitlines():
        config_line = line.strip()

        # Wait until we find 'router bgp <number>'
        if not bgp_router_present:
            if re.match(bgp_router_asn, config_line):
                bgp_router_present = True
            continue

        if config_line == "!":
            continue
        if match := re.match(bgp_vrf_pattern, config_line):
            vrf = match.group(1)
            if vrf not in settings_vrfs:
                cmds.append(f"  no {config_line}")
            else:
                cmds.append(f"  {config_line}")
            current_vrf = vrf
        elif re.match(bgp_router_pattern, config_line) or re.match(
            bgp_network_pattern, config_line
        ):
            cmds.append(f"  no {config_line}")

        elif re.match(bgp_graceful_restart_pattern, config_line):
            cmds.append("  no graceful-restart")

        elif match := re.match(bgp_neighbor_pattern, config_line):
            neighbor_ip = match.group(1)
            if neighbor_ip not in seen_neighbors:
                cmds.append(f"  no neighbor {neighbor_ip}")
                seen_neighbors.add(neighbor_ip)
        elif current_vrf == "":
            cmds.append(f"  no {config_line}")

    return cmds


def is_valid_uuid(val: str) -> bool:
    """Checks if the string is a valid UUID."""
    try:
        UUID(str(val))
    except (ValueError, TypeError):
        return False
    else:
        return True


def ensure_archive_structure(settings_file, *keys):
    """
    Ensure archive structure exists in settings file with the given keys.

    This helper creates the nested archive.last_run structure if it doesn't exist,
    and initializes any specified keys with empty lists.

    Args:
        settings_file: SettingsFile object to modify
        *keys: Variable number of keys to initialize as empty lists under archive.last_run

    Example:
        ensure_archive_structure(settings_file, "routes", "vrf")
        # Creates: settings["archive"]["last_run"]["routes"] = []
        #          settings["archive"]["last_run"]["vrf"] = []
    """
    if settings_file.settings.get("archive") is None:
        settings_file.settings["archive"] = {}

    if settings_file.settings.get("archive").get("last_run") is None:
        settings_file.settings["archive"]["last_run"] = {}

    for key in keys:
        if settings_file.settings.get("archive").get("last_run").get(key) is None:
            settings_file.settings["archive"]["last_run"][key] = []
