"""Config static dns entries directly to EOS."""

import os

import sync.eos.utils as EosCommon
from sync import Manager, registrar
from sync.common import Logger
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE

logger = Logger.getInstance()


class StaticDnsEntriesManager(Manager):
    """StaticDnsEntriesManager writes static dns entries config."""

    DNS_CONFIG_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}static_dns.cfg"

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)

        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.DNS_CONFIG_FILENAME),
            "eos-config",
            self,
        )

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """Creates settings with empty staticEntries."""
        settings_file.settings["dns"] = {
            "staticEntries": [],
        }

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """Sync settings - writes static DNS entries to EOS config file."""
        logger.info("Syncing static DNS settings")

        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        dns = settings_file.settings.get("dns", {})

        config = self.get_static_dns_entries(dns)

        # Write to file
        with open(os.path.join(dirname, self.DNS_CONFIG_FILENAME), "w") as f:
            f.write(config)

    def get_static_dns_entries(self, dns_settings: []) -> str:
        """
        Generate static DNS entries for EOS CLI.

        Creates 'ip host' commands for each static DNS entry (e.g., edge.arista.com -> IP).

        :param dns_settings: DNS settings dictionary containing staticEntries
        :return: EOS CLI commands as a string
        """
        static_entries = dns_settings.get("staticEntries", [])

        commands = ["!"]

        commands.append("no ip host")

        for entry in static_entries:
            name = entry.get("name")
            address = entry.get("address")
            commands.append(f"ip host {name} {address}")

        commands.append("!")
        return "\n".join(commands)


registrar.register_manager(StaticDnsEntriesManager())
