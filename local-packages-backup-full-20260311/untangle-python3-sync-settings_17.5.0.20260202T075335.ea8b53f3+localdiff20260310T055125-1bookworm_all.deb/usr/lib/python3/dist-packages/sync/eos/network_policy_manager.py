from abc import ABC, abstractmethod

import sync.eos.utils as EosCommon
from sync.settings_file import SettingsFile


class NetworkPolicyManager(ABC):
    """
    Abstract base class for managing ACLs and NAT configuration command generation
    in EOS.

    To manage ACL/NAT-profiles effectively:

    1. **Delete existing policies**: It's often easier to wipe the entire ACL rather than removing individual rules.
    2. **Rebuild policies**: Set up new ACLs from scratch.
    3. **Add updated rules**: Apply the latest rules to the freshly rebuilt ACLs.
    """

    def __init__(self, settings_file: SettingsFile) -> None:
        self.settings_file = settings_file
        self.intf_id_to_vrf_name = EosCommon.get_interface_id_vrf_name_dict(settings_file)

    def get_config_cmds(self) -> str:
        """
        Generate configuration commands to manage policies.

        This function:
        - Removes existing policies from interfaces.
        - Applies new policies to interfaces.
        - Attaches rules to the policies.
        - Returns all the cmds as a newline separated string
        """
        cmds = self.get_remove_policy_cmds()
        cmds.extend(self.get_apply_policy_cmds())
        cmds.extend(self.get_attach_rules_to_policy_cmds())
        return "\n".join(cmds)

    @abstractmethod
    def get_apply_policy_cmds(self) -> list[str]:
        pass

    @abstractmethod
    def get_remove_policy_cmds(self) -> list[str]:
        pass

    @abstractmethod
    def get_attach_rules_to_policy_cmds(self) -> list[str]:
        pass
