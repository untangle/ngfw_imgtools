from __future__ import annotations

import ipaddress
import json
from enum import Enum

from sync import network_util
from sync.common import Logger
from sync.settings_file import SettingsFile

# Regex to match the name of rule IDs
RULE_ID_NAME_MATCHER = (
    r"[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}"
)

logger = Logger.getInstance()


class SupportedActions(str, Enum):
    ACCEPT = "ACCEPT"
    DENY = "REJECT"
    DROP = "DROP"
    DNAT = "DNAT"
    SNAT = "SNAT"
    SET_PRIORITY = "SET_PRIORITY"
    MASQUERADE = "MASQUERADE"

    def __str__(self) -> str:
        return f"{self.value}".lower()


class SupportedConditions(str, Enum):
    SOURCE_ADDRESS = "SOURCE_ADDRESS"
    DESTINATION_ADDRESS = "DESTINATION_ADDRESS"
    SOURCE_PORT = "SOURCE_PORT"
    DESTINATION_PORT = "DESTINATION_PORT"
    IP_PROTOCOL = "IP_PROTOCOL"
    CT_STATE = "CT_STATE"
    SOURCE_INTERFACE_ZONE = "SOURCE_INTERFACE_ZONE"
    SOURCE_INTERFACE_TYPE = "SOURCE_INTERFACE_TYPE"
    SOURCE_INTERFACE_NAME = "SOURCE_INTERFACE_NAME"
    DESTINATION_INTERFACE_ZONE = "DESTINATION_INTERFACE_ZONE"
    DESTINATION_INTERFACE_TYPE = "DESTINATION_INTERFACE_TYPE"
    DESTINATION_INTERFACE_NAME = "DESTINATION_INTERFACE_NAME"


class SupportedIPProtocols(int, Enum):
    TCP = 6
    UDP = 17


class SupportedTargets(str, Enum):
    SOURCE_INTERFACE_ZONE = "SOURCE_INTERFACE_ZONE"
    SOURCE_INTERFACE_TYPE = "SOURCE_INTERFACE_TYPE"
    SOURCE_INTERFACE_NAME = "SOURCE_INTERFACE_NAME"
    DESTINATION_INTERFACE_ZONE = "DESTINATION_INTERFACE_ZONE"
    DESTINATION_INTERFACE_TYPE = "DESTINATION_INTERFACE_TYPE"
    DESTINATION_INTERFACE_NAME = "DESTINATION_INTERFACE_NAME"


class InterfaceType(str, Enum):
    WAN = "1"
    LAN = "2"


class SupportedCTTypes(str, Enum):
    ESTABLISHED = "established"


class AclAction:
    """Represents an ACL Action of any type"""

    def __init__(
        self, action_type: SupportedActions, address: str, port: str, priority: str
    ) -> None:
        self.action_type = action_type

        try:
            if "/" in address:
                network = ipaddress.ip_network(address, strict=False)
                self.start_address = str(network[1])
                self.end_address = str(network[-2])
                self.prefix = network.prefixlen
            elif "-" in address:
                start, end = address.split("-")
                self.start_address = str(ipaddress.ip_address(start.strip()))
                self.end_address = str(ipaddress.ip_address(end.strip()))
                self.prefix = self.get_prefix_from_range(start, end)
            else:
                self.start_address = self.end_address = str(ipaddress.ip_address(address))
                self.prefix = 32
        except:
            self.start_address = address
            self.end_address = address
            self.prefix = 32

        self.port = port
        self.priority = priority
        # TODO: Actions must have a rule id.... or should actions be merged with ACLRules?
        self.rule_id = None

    def set_rule_id(self, rule_id: str) -> None:
        self.rule_id = rule_id

    def to_eos_config(self, profile_name: str | None = None, *, remove_action: bool = False):
        # Build the action component, IE: nat pool for snat/dnat, override for masquerade
        negation_prefix = "no " if remove_action else ""
        conf_string = ""

        # Nat section
        if self.is_nat_action():
            if self.action_type in (SupportedActions.DNAT, SupportedActions.SNAT):
                conf_string += self.create_eos_nat_pool(remove_nat_pool=remove_action)

            nat_rule = self.create_eos_rule()
            # Add the nat rule to the concerned nat profile
            if profile_name:
                # If this a delete flow, then it's enough to delete the nat-profile to remove all the rules
                conf_string += f"\n{negation_prefix}ip nat profile {profile_name}"
                if not remove_action:
                    conf_string += nat_rule

        return conf_string

    def create_eos_nat_pool(self, *, remove_nat_pool: bool = False) -> str:
        negation_prefix = "no " if remove_nat_pool else ""

        conf_string = ""
        if self.port is not None:
            conf_string += (
                f"\n{negation_prefix}ip nat pool {self.rule_id} prefix-length {self.prefix}"
            )

            if not remove_nat_pool:
                conf_string += (
                    f"\n  range {self.start_address} {self.end_address} {self.port} {self.port}"
                )
        else:
            conf_string += f"\n{negation_prefix}ip nat pool {self.rule_id} {self.start_address} {self.end_address} prefix-length {self.prefix}"

        return conf_string

    def create_eos_rule(self) -> str:
        if self.action_type in (SupportedActions.DNAT, SupportedActions.SNAT):
            direction = "destination"

            if self.action_type == SupportedActions.SNAT:
                direction = "source"

            return f"\n ip nat {direction} dynamic access-list {self.rule_id} pool {self.rule_id}"

        if self.action_type == SupportedActions.MASQUERADE:
            return f"\n ip nat source dynamic access-list {self.rule_id} overload"

        if self.action_type == SupportedActions.ACCEPT:
            return ""

        msg = f" {self.action_type} action types are not implemented - file a bug! or fix me"
        raise NotImplementedError(msg)

    def is_nat_action(self) -> bool:
        return self.action_type in (
            SupportedActions.DNAT,
            SupportedActions.SNAT,
            SupportedActions.MASQUERADE,
        )

    def get_prefix_from_range(self, start_ip: str, end_ip: str) -> int:
        start = int(ipaddress.IPv4Address(start_ip))
        end = int(ipaddress.IPv4Address(end_ip))

        prefix_length = 32

        while prefix_length > 0:
            subnet = ipaddress.IPv4Network((start, prefix_length), strict=False)
            if int(subnet.network_address) <= start and int(subnet.broadcast_address) >= end:
                return prefix_length

            prefix_length -= 1

        return 0


class AclCondition:
    """Represents an ACL Condition of any type"""

    def __init__(
        self,
        condition_type: str,
        ct_state: str,
        source_port: str,
        destination_port: str,
        source_address: str,
        destination_address: str,
        source_interfaces: list[str],
        destination_interfaces: list[str],
        source_interface_type: int,
        destination_interface_type: int,
        protocols: list,
    ) -> None:
        self.condition_type = condition_type
        self.ct_state = ct_state
        self.source_port = source_port
        self.destination_port = destination_port
        self.source_address = source_address
        self.destination_address = destination_address
        self.source_interfaces = source_interfaces
        self.destination_interfaces = destination_interfaces
        self.source_interface_type = source_interface_type
        self.destination_interface_type = destination_interface_type
        self.protocols = protocols


ip_protocol_value_map = {
    "1": "icmp",
    "6": "tcp",
    "17": "udp",
    "50": "esp",
    "51": "ahp",
}


class AclConditions:
    """Manages a list of ACL conditions associated to an ACL Rule"""

    def __init__(self) -> None:
        self.conditions = []
        self.settings_file = None

    def add(self, condition: AclCondition) -> None:
        self.conditions.append(condition)

    def to_eos_config(self, acl_action_type: SupportedActions = SupportedActions.ACCEPT) -> str:
        rule_verb = (
            "deny"
            if acl_action_type in [SupportedActions.DENY, SupportedActions.DROP]
            else "permit"
        )
        ct_state = ""
        source_port = ""
        destination_port = ""
        source_addresses = ["any"]
        destination_addresses = ["any"]
        source_interfaces = None
        destination_interfaces = None

        port_protocols = []
        ip_protocols = []

        if len(self.conditions) == 0:
            return ""

        for condition in self.conditions:
            if condition.condition_type == SupportedConditions.SOURCE_ADDRESS:
                source_addresses = [condition.source_address]
            if condition.condition_type == SupportedConditions.DESTINATION_ADDRESS:
                destination_addresses = [condition.destination_address]
            if condition.condition_type == SupportedConditions.SOURCE_PORT:
                source_port = condition.source_port
                port_protocols = condition.protocols
            if condition.condition_type == SupportedConditions.DESTINATION_PORT:
                destination_port = condition.destination_port
                port_protocols = condition.protocols
            if condition.condition_type == SupportedConditions.IP_PROTOCOL:
                ip_protocols = condition.protocols
            if condition.condition_type == SupportedConditions.CT_STATE:
                if condition.ct_state not in list(SupportedCTTypes):
                    msg = f"Condition: ct_state {condition.ct_state} not in supproted CT_STATE"
                    raise NotImplementedError(msg)
                if condition.ct_state == SupportedCTTypes.ESTABLISHED:
                    ct_state = " tracked"

            if (
                condition.condition_type in SupportedTargets._member_names_
                and self.settings_file is None
            ):
                # Ideally, this condition should trigger an exception, but we also
                # use these conditions in NAT rules that are processed in the nat manaager.
                # For now, just ignore processing of these types without
                # a settings file which is always passed from acl manager.
                continue

            if self.settings_file:
                if condition.condition_type == SupportedConditions.SOURCE_INTERFACE_TYPE:
                    source_interfaces = network_util.get_interface_names_from_type(
                        settings_file=self.settings_file,
                        interface_type=condition.source_interface_type,
                    )

                if condition.condition_type == SupportedConditions.DESTINATION_INTERFACE_TYPE:
                    destination_interfaces = network_util.get_interface_names_from_type(
                        settings_file=self.settings_file,
                        interface_type=condition.destination_interface_type,
                    )

                if condition.condition_type in [
                    SupportedConditions.SOURCE_INTERFACE_ZONE,
                    SupportedConditions.SOURCE_INTERFACE_NAME,
                    SupportedConditions.SOURCE_INTERFACE_TYPE,
                ]:
                    if source_interfaces is None:
                        source_interfaces = condition.source_interfaces
                    source_addresses = network_util.get_source_networks_from_interfaces(
                        settings_file=self.settings_file,
                        interface_names=source_interfaces,
                    )

                if condition.condition_type in [
                    SupportedConditions.DESTINATION_INTERFACE_ZONE,
                    SupportedConditions.DESTINATION_INTERFACE_NAME,
                    SupportedConditions.DESTINATION_INTERFACE_TYPE,
                ]:
                    if destination_interfaces is None:
                        destination_interfaces = condition.destination_interfaces
                    destination_addresses = network_util.get_destination_networks_from_interfaces(
                        settings_file=self.settings_file, interface_names=destination_interfaces
                    )

                # NOTE: If either source or destination addresses is empty, the ACL will not be generated.
                # For example, an interface configured for a DHCP address that does not have one yet is NOT the same as "any"!

        if len(port_protocols) > 0 and len(ip_protocols) > 0:
            if len(port_protocols) != len(ip_protocols):
                msg = f"Protocol collision in rule conditions. Port_protocols: {port_protocols}, IP Protocols: {ip_protocols}"
                raise ValueError(msg)
            port_protocols_set = set()
            for p in port_protocols:
                port_protocols_set.add(ip_protocol_value_map[p])

            if len(port_protocols_set.difference(set(ip_protocols))) != 0:
                msg = f"Protocol collision in rule conditions. Port_protocols: {port_protocols}, IP Protocols: {ip_protocols}"
                raise ValueError(msg)

        protocols = ["ip"]
        if len(port_protocols) > 0:
            protocols = port_protocols
        elif len(ip_protocols) > 0:
            protocols = ip_protocols

        cmd = []
        for source_address in source_addresses:
            # None value is checked using "in" operator as address is coming as ip/mask format
            if "none" in source_address.lower() or not source_address:
                continue
            for destination_address in destination_addresses:
                if "none" in destination_address.lower() or not destination_address:
                    continue
                for p in protocols:
                    cmd.append(
                        f" {rule_verb} {p} {source_address}{source_port} {destination_address}{destination_port}{ct_state}"
                    )

        if cmd:
            return "\n".join(cmd)
        return ""


class ConditionDecoder(json.JSONDecoder):
    def interpret_ip_protocol_value(self, value: str) -> str:
        """
        Function to take an IP_PROTOCOL value argument and convert it to ACL protocol type
        """
        valuesplit = value.split(",")
        if len(valuesplit) > 1:
            return ",".join([self.interpret_ip_protocol_value(v) for v in valuesplit])
        # Otherwise we have a since IP_PROTOCOL in value
        if value not in ip_protocol_value_map:
            msg = f"Condition: IP_PROTOCOL:{value} for ACL conditions not implemented"
            raise NotImplementedError(msg)
        return ip_protocol_value_map[value]

    def decode(self, s: str) -> AclCondition:
        data = super().decode(s)
        ct_state = ""
        source_port = ""
        destination_port = ""
        source_address = "any"
        destination_address = "any"
        port_protocol = data.get("port_protocol", None)
        protocol = ["ip"]  # by default
        condition_type = data.get("type")
        source_interfaces = []
        destination_interfaces = []
        source_interface_type = None
        destination_interface_type = None

        # Sanity check condition - skip condition if this happens
        if condition_type not in list(SupportedConditions):
            msg = f"Condition: {condition_type} for ACL Conditions"
            raise NotImplementedError(msg)

        # If no port protocol, skip src/dst ports
        if condition_type == SupportedConditions.IP_PROTOCOL:
            valid_protocol = self.interpret_ip_protocol_value(data.get("value", ""))
            protocol = valid_protocol.split(",")
        elif port_protocol is not None:
            protocols = []
            if isinstance(port_protocol, list):
                protocols.extend(port_protocol)
            else:
                protocols.append(port_protocol)

            self.validate_protocols(protocols)

            if condition_type == SupportedConditions.SOURCE_PORT:
                source_port = f" eq {data.get('value', '')}"

            if condition_type == SupportedConditions.DESTINATION_PORT:
                destination_port = f" eq {data.get('value', '')}"

            protocol = protocols

        if condition_type == SupportedConditions.CT_STATE:
            ct_state = data.get("value", "")

        if condition_type == SupportedConditions.SOURCE_ADDRESS:
            temp_addr = ipaddress.ip_network(data.get("value", ""), strict=False)
            if temp_addr.prefixlen in (32, 128):
                source_address = f"host {temp_addr.network_address}"
            else:
                source_address = f"{temp_addr!s}"

        if condition_type == SupportedConditions.DESTINATION_ADDRESS:
            temp_addr = ipaddress.ip_network(data.get("value", ""), strict=False)
            if temp_addr.prefixlen in (32, 128):
                destination_address = f"host {temp_addr.network_address}"
            else:
                destination_address = f"{temp_addr!s}"

        if condition_type in [
            SupportedConditions.SOURCE_INTERFACE_ZONE,
            SupportedConditions.SOURCE_INTERFACE_NAME,
        ]:
            source_interfaces = [data.get("value", "")]

        if condition_type in [
            SupportedConditions.DESTINATION_INTERFACE_ZONE,
            SupportedConditions.DESTINATION_INTERFACE_NAME,
        ]:
            destination_interfaces = [data.get("value", "")]

        if condition_type == SupportedConditions.SOURCE_INTERFACE_TYPE:
            source_interface_type = data.get("value", None)

        if condition_type == SupportedConditions.DESTINATION_INTERFACE_TYPE:
            destination_interface_type = data.get("value", None)

        return AclCondition(
            condition_type,
            ct_state,
            source_port,
            destination_port,
            source_address,
            destination_address,
            source_interfaces,
            destination_interfaces,
            source_interface_type,
            destination_interface_type,
            protocol,
        )

    def validate_protocols(self, protocols: list) -> None:
        for p in protocols:
            if int(p) not in list(SupportedIPProtocols):
                msg = f"Protocol: {p} for ACL conditions is not implemented"
                raise NotImplementedError(msg)


class ConditionsDecoder(json.JSONDecoder):
    def decode(self, s: str) -> AclConditions:
        data = super().decode(s)

        conditions = AclConditions()
        for condition in data:
            aclCondition = json.loads(json.dumps(condition), cls=ConditionDecoder)
            if aclCondition is not None:
                conditions.add(aclCondition)

        return conditions


class ActionDecoder(json.JSONDecoder):
    def decode(self, s: str) -> AclAction | None:
        data = super().decode(s)
        action_type = data.get("type", "")
        address = None
        port = None
        priority = None

        if action_type not in list(SupportedActions):
            return None

        if action_type == SupportedActions.DNAT:
            address = data.get("dnat_address", "")
            port = data.get("dnat_port", None)

        elif action_type == SupportedActions.SNAT:
            address = data.get("snat_address", "")

        elif action_type == SupportedActions.SET_PRIORITY:
            priority = data.get("priority", 0)
        elif action_type in (SupportedActions.MASQUERADE, SupportedActions.ACCEPT):
            address = None
            port = None
            priority = None
        elif action_type in [SupportedActions.DENY, SupportedActions.DROP]:
            address = None
            port = data.get("value", None)
            priority = None
        else:
            msg = f"{action_type} is not implemented"
            raise NotImplementedError(msg)

        return AclAction(action_type, address, port, priority)


class InterfaceTarget:
    """Represents the interface target of a rule"""

    def __init__(
        self,
        source_interface_type: str,
        source_interface_zone: str,
        source_interface_name: str,
        destination_interface_type: str,
        destination_interface_zone: str,
        destination_interface_name: str,
    ) -> None:
        self.source_interface_type = source_interface_type
        self.source_interface_zone = source_interface_zone
        self.source_interface_name = source_interface_name
        self.destination_interface_type = destination_interface_type
        self.destination_interface_zone = destination_interface_zone
        self.destination_interface_name = destination_interface_name

    def matches_interface(self, interface: dict[str, str]) -> bool:
        interface_type = InterfaceType.LAN
        if interface.get("wan"):
            interface_type = InterfaceType.WAN
        return (
            (self.source_interface_type in (None, interface_type))
            and (
                self.source_interface_zone is None
                or interface.get("name") == self.source_interface_zone
            )
            and (
                self.source_interface_name is None
                or interface.get("device") == self.source_interface_name
            )
            and (self.destination_interface_type in (None, interface_type))
            and (
                self.destination_interface_zone is None
                or interface.get("name") == self.destination_interface_zone
            )
            and (
                self.destination_interface_name is None
                or interface.get("device") == self.destination_interface_name
            )
        )


class InterfaceTargetDecoder(json.JSONDecoder):
    def decode(self, s: str) -> InterfaceTarget:
        data = super().decode(s)

        source_interface_type: str = None
        source_interface_zone: str = None
        source_interface_name: str = None
        destination_interface_type: str = None
        destination_interface_zone: str = None
        destination_interface_name: str = None

        for condition in data.get("conditions", []):
            condition_type = condition.get("type")
            condition_value = condition.get("value", "")

            if condition_type == SupportedTargets.SOURCE_INTERFACE_TYPE:
                source_interface_type = condition_value
                continue

            if condition_type == SupportedTargets.SOURCE_INTERFACE_ZONE:
                source_interface_zone = condition_value
                continue

            if condition_type == SupportedTargets.SOURCE_INTERFACE_NAME:
                source_interface_name = condition_value
                continue

            if condition_type == SupportedTargets.DESTINATION_INTERFACE_TYPE:
                destination_interface_type = condition_value
                continue

            if condition_type == SupportedTargets.DESTINATION_INTERFACE_ZONE:
                destination_interface_zone = condition_value
                continue

            if condition_type == SupportedTargets.DESTINATION_INTERFACE_NAME:
                destination_interface_name = condition_value
                continue

        return InterfaceTarget(
            source_interface_type,
            source_interface_zone,
            source_interface_name,
            destination_interface_type,
            destination_interface_zone,
            destination_interface_name,
        )


class AclRule:
    """Represents an ACL rule of any type, with an associated action"""

    def __init__(
        self,
        enabled: bool,
        conditions: AclConditions,
        action: AclAction,
        rule_id: str,
        target: InterfaceTarget,
        settings_file: SettingsFile,
    ) -> None:
        self.enabled = enabled
        self.conditions = conditions
        self.action = action
        self.rule_id = rule_id
        self.target = target
        self.settings_file = settings_file

    def to_eos_config(self, profile_name: str | None = None, *, remove_rule: bool = False) -> str:
        negation_prefix = "no " if remove_rule else ""
        rule_config = f"\n{negation_prefix}ip access-list {self.rule_id}"

        if not remove_rule:
            # Check if this is an allow/block all rule by looking at action/condition
            # fields.
            if not self.conditions.conditions:
                if self.action.action_type == SupportedActions.ACCEPT:
                    rule_config += "\n   permit ip any any"
                    return rule_config
                if self.action.action_type == SupportedActions.DROP:
                    rule_config += "\n   deny ip any any"
                    return rule_config

            self.conditions.settings_file = self.settings_file
            eos_rules = self.conditions.to_eos_config(self.action.action_type)
            if len(eos_rules):
                rule_config += f"\n{eos_rules}"
            else:
                rule_config = ""

        rule_config += self.action.to_eos_config(profile_name, remove_action=remove_rule)

        return rule_config

    def matches_interface(self, interface: dict[str, str]) -> bool:
        interface_type = InterfaceType.LAN
        if interface.get("wan"):
            interface_type = InterfaceType.WAN

        if (
            interface_type != InterfaceType.WAN
            and self.action.action_type == SupportedActions.DNAT
        ):
            return False

        return self.target.matches_interface(interface)


class RuleDecoder(json.JSONDecoder):
    def decode(self, s: str) -> AclRule:
        data = super().decode(s)
        enabled = data.get("enabled", False)
        rule_id = data.get("ruleId", None)
        action: AclAction
        target: InterfaceTarget

        # TODO: Is there a better way to pass these the proper decoders, instead of json.dumps + json.loads
        json_action = json.dumps(data.get("action", {}))

        # Call condition decoder on each json dumped condition
        conditions = json.loads(json.dumps(data.get("conditions", [])), cls=ConditionsDecoder)

        # Call action decoder
        try:
            action = json.loads(json_action, cls=ActionDecoder)
            if action is not None:
                action.set_rule_id(rule_id)
        except NotImplementedError:
            logger.exception("")

        target = json.loads(json.dumps(data), cls=InterfaceTargetDecoder)

        return AclRule(enabled, conditions, action, rule_id, target, None)
