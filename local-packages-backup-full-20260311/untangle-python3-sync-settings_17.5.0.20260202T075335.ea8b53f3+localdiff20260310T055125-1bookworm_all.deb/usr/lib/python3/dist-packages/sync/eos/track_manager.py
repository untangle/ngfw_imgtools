"""
This class handles all track config settings translation
from MFW settings.json to EOS Sysdb
"""

import os

import sync.eos.utils as EosCommon
from sync import Manager, registrar
from sync.eos import EOS_CONFIG_LOAD_PRIORITY_LATE


class TrackManager(Manager):
    """
    TrackManager is responsible to write tracks configs into Sysdb
    """

    TRACK_FILENAME = f"{EOS_CONFIG_LOAD_PRIORITY_LATE}tracks.cfg"

    def initialize(self) -> None:
        """
        Initialize this module
        """
        registrar.register_settings_file("settings", self)
        registrar.register_file(
            os.path.join(EosCommon.CONFIG_DIR, self.TRACK_FILENAME), "eos-config", self
        )

    # Reading previous config to remove the sysdb configs when track configs are deleted
    def read_previous_config(self, file_path):
        try:
            with open(file_path) as file:
                # Parse the previous config to extract information
                track_entries = [line.split() for line in file if line.startswith("track")]
                previous_json_data = {"track": []}
                for entry in track_entries:
                    name = entry[1]
                    interface_id = entry[-2].split("/")[-1]  # Extract interface ID
                    previous_json_data["track"].append({"name": name, "interfaceId": interface_id})
                return previous_json_data
        except FileNotFoundError:
            # return empty list if the config file does not exist
            return {"track": []}

    def get_track_configs(self, track_configs, interfaces, track_filename):
        """
        Generate config file from the track settings
        @track: list of track configs in JSON format
        """

        intf_data = {}
        for interface in interfaces:
            intf_data[interface["interfaceId"]] = (
                interface["device"].replace("et", "Ethernet").replace("_", "/")
            )

        previous_json_data = self.read_previous_config(track_filename)

        commands = []
        # construct the track config commands
        for track in track_configs:
            name = track["name"]
            interface_name = intf_data[track["interfaceId"]]
            cmd = f"track {name} interface {interface_name} line-protocol"
            commands.append(cmd)

        # If previous configs exists check and remove the deleted entries
        if previous_json_data:
            previous_entries = {entry.get("name") for entry in previous_json_data.get("track", [])}
            current_entries = {entry.get("name") for entry in track_configs}
            removed_entries = previous_entries - current_entries
            for removed_entry in removed_entries:
                commands.append(f"no track {removed_entry}")

        return "\n".join(commands)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        syncs settings
        """
        track_filename = os.path.join(EosCommon.CONFIG_DIR, self.TRACK_FILENAME)

        track_configs = settings_file.settings.get("track", [])
        interfaces = settings_file.settings.get("network", {}).get("interfaces", [])
        config = self.get_track_configs(track_configs, interfaces, track_filename)

        # write to file
        dirname = os.path.join(prefix, EosCommon.CONFIG_DIR.strip("/"))
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        with open(os.path.join(dirname, self.TRACK_FILENAME), "w") as f:
            f.write(config)


registrar.register_manager(TrackManager())
