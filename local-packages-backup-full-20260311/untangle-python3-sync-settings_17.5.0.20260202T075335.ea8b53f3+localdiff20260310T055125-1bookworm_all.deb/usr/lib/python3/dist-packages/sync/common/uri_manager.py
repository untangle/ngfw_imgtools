"""This class is responsible for managing URI translation settings"""

from sync import Manager, registrar
from sync.common import Logger

logger = Logger.getInstance()


class UriManager(Manager):
    # Default URIs
    default_settings = {
        "uriTranslations": [
            {
                # packetd
                "uri": "https://downloads.edge.arista.com/download.php"
            },
            {
                # packetd
                "uri": "https://queue.edge.arista.com/v1/put"
            },
            {
                # packetd
                "uri": "https://classify.edge.arista.com/"
            },
            {
                # restd
                "uri": "https://edge.arista.com/store/open.php"
            },
            {
                # restd
                "uri": "https://auth.edge.arista.com/v1/CheckTokenAccess"
            },
            {
                # reportd
                "uri": "https://database.edge.arista.com/v1/put"
            },
            {
                # mfw_ui
                "uri": "https://edge.arista.com/cmd/networks"
            },
            {
                # mfw_ui
                "uri": "https://edge.arista.com/cmd/account/"
            },
            {
                # mfw_ui
                "uri": "https://edge.arista.com/legal"
            },
            {
                # mfw_ui
                "uri": "https://support.edge.arista.com/hc"
            },
            {
                # mfw_ui
                "uri": "https://aristamicroedge.featureupvote.com/"
            },
            {
                # mfw_ui
                "uri": "https://launchpad.edge.arista.com"
            },
            {
                # client-license-service
                "uri": "https://license.edge.arista.com/license.php"
            },
            {
                # mfw_feeds
                "uri": "https://updates.edge.arista.com/api"
            },
            {
                # mfw_feeds
                "uri": "https://boxbackup.edge.arista.com/boxbackup/backup.php"
            },
            {
                # mfw_feeds - pyconnector
                "uri": "https://cmd.edge.arista.com/"
            },
            {
                # sync-settings
                "uri": "https://edge.arista.com/api/v1/appliance/OnSettingsUpdate"
            },
        ]
    }

    def create_default_uri_map(self) -> None:
        """
        Sets the map of uri_translations_map to a default value of their key "found" set to False.
        """
        self.uri_translations_map = {
            uri_details["uri"]: {"found": False, "value": uri_details}
            for uri_details in UriManager.default_settings["uriTranslations"]
        }

    def initialize(self) -> None:
        """
        Initialize module
        """
        registrar.register_settings_file("settings", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """
        Create default URI translation settings
        """
        logger.info("Initializing settings")
        settings_file.settings["uris"] = UriManager.default_settings

    def sanitize_settings(self, settings_file) -> None:
        """
        Sanitizes settings
        """
        uris_settings = settings_file.settings.get("uris")

        # Missing URI settings
        if uris_settings is None:
            settings_file.settings["uris"] = {}
            settings_file.settings["uris"] = UriManager.default_settings
        else:
            # Some URI settings already present. Update those URIs from default settings which are missing.
            self.create_default_uri_map()
            for uri_details in settings_file.settings["uris"]["uriTranslations"]:
                uri = uri_details.get("uri")
                # Set this URI as "found" in the settings if URI is already present in uri_translations_map
                if uri and uri in self.uri_translations_map:
                    self.uri_translations_map[uri]["found"] = True
                else:
                    # remove the URI if URI is not present in uri_translations_map
                    settings_file.settings["uris"]["uriTranslations"].remove(uri_details)

            for uri_default in self.uri_translations_map.values():
                if uri_default["found"] is False:
                    # Add the translations of remaining URIs which were not found in the settings already present
                    settings_file.settings["uris"]["uriTranslations"].append(uri_default["value"])


registrar.register_manager(UriManager())
