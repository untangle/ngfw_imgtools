"""This class is responsible for validating routes"""

import ipaddress

from sync.common.validators.base_validator import Validator
from sync.settings_exception import SettingsException


class RouteValidator(Validator):
    """Handles validation of routes"""

    def __init__(self, settings_file) -> None:
        self.settings_file = settings_file

    def validate(self) -> None:
        static_routes = []
        routes_all = self.settings_file.settings.get("routes", [])
        for routes_for_vrf in routes_all:
            static_routes.extend(routes_for_vrf.get("routes", []))

        for route in static_routes:
            # Check route given is valid
            if route.get("enabled"):
                try:
                    _ = str(ipaddress.IPv4Network(route.get("network")).netmask)
                except (ValueError, TypeError, AttributeError):
                    raise SettingsException(
                        message="static_route_network_field_invalid", vars=[route]
                    )
