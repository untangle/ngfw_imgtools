"""This IPS manager is responsible for managing the IPS settings."""

import os
import random
import re
from typing import Any

import sync.common.utils as Common
from sync import Manager, registrar
from sync.common import Logger
from sync.file_util import FileUtil

logger = Logger.getInstance()

""" Format of the "ips" entry from settings.json.
    ips: {
        "enabled": true,
        "enabled_ips": true,
        "update_time": "00:00",
        "rules": [
        {
            "enabled": true,
            "sid": 0,
            "action": "alert",
            "message": "alert message", (Optional)
            "classType": "class type", (Optional)
        },
        ...
        ]
    }
"""

# The default settings does not contain a "update_time" field. This is so that we can generate a random time.
ips_default_settings = {
    "enabled": True,
    "enabled_ips": True,
    "rules": [],
    "ruleList": [
        {
            "name": "Suricata Community Rules",
            "url": "https://ids.edge.arista.com/suricatasignatures.tar.gz",
            "enabled": True,
            "version": "6",
            "local_dir": "rules",
        }
    ],
}


class IpsManager(Manager):
    """
    Base IPS manager that handles settings registration and sanitization.

    This base class handles settings management only.
    Platforms that need cron job support should use CronDIpsManager subclass.
    """

    SIGNATURE_DIR = FileUtil.locate_file("/etc/config/intrusion-prevention-signatures")
    # Version of Suricata to use for signatures
    SURICATA_VERSION = 6

    def initialize(self) -> None:
        """Initialize the IPS manager."""
        logger.info("Initializing IPS manager")
        registrar.register_settings_file("settings", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:  # noqa: ANN001
        """Create default IPS settings."""
        logger.info("Creating default IPS settings")
        settings_file.settings["ips"] = ips_default_settings

    def _validate_rule_entry(self, entry: dict[str, Any]) -> None:
        """Validate individual rule entry"""
        required_fields = ["enabled", "sid", "action"]
        optional_fields = ["message", "classType"]

        for field in required_fields:
            if field not in entry:
                logger.error("IPS entry is missing the '%s' field.", field)

        for field in optional_fields:
            if field not in entry:
                logger.warning("IPS entry is missing optional '%s' field.", field)

    def sanitize_settings(self, settings_file) -> None:  # noqa: ANN001
        """Sanitize the IPS settings."""
        logger.info("Sanitizing settings")
        ips_settings = settings_file.settings.get("ips")
        # Check that we have an IPS section in the settings file
        if ips_settings is None:
            logger.warning("IPS settings are missing, adding default settings.")
            settings_file.settings["ips"] = ips_default_settings
            ips_settings = settings_file.settings["ips"]
        # Iterate through the IPS settings and check for required fields
        if not isinstance(ips_settings, dict):
            logger.error("IPS entry is not in the correct format.")
            return
        if "enabled" not in ips_settings:
            logger.error("IPS settings are missing the 'enabled' field.")
        if "enabled_ips" not in ips_settings:
            logger.error("IPS settings are missing the 'enabled_ips' field.")
        if "rules" not in ips_settings:
            logger.error("IPS entry is missing the 'rules' field.")
            return

        for entry in ips_settings["rules"]:
            self._validate_rule_entry(entry)
        if "ruleList" not in ips_settings:
            logger.error("IPS settings are missing the 'ruleList' field.")
            # Adding default ruleList if not present
            ips_settings["ruleList"] = ips_default_settings["ruleList"]


class CronDIpsManager(IpsManager):
    """IPS manager with cron job support for signature updates.

    This class extends IpsManager to add cron file management
    and update scheduling for platforms that need automatic signature updates.
    """

    UPDATE_SCRIPT_FILENAME = "intrusion-prevention-get-updates"

    def initialize(self) -> None:
        """Initialize the IPS manager with cron job registration."""
        logger.info("Initializing CronD IPS manager")
        registrar.register_file(
            os.path.join(Common.CRON_D_DIR, CronDIpsManager.UPDATE_SCRIPT_FILENAME),
            "restart-cron",
            self,
        )
        registrar.register_settings_file("settings", self)

    def sanitize_settings(self, settings_file) -> None:  # noqa: ANN001
        """Sanitize the IPS settings including update_time for cron."""
        super().sanitize_settings(settings_file)

        ips_settings = settings_file.settings.get("ips")
        if ips_settings is None or not isinstance(ips_settings, dict):
            return

        if "update_time" not in ips_settings:
            logger.warning(
                "IPS settings are missing the 'update_time' field, generating random time."
            )
            # Generate random time between 0:00 and 3:59
            random_minute = random.randint(0, 59)  # noqa: S311
            random_hour = random.randint(0, 3)  # noqa: S311
            ips_settings["update_time"] = f"{random_hour:02d}:{random_minute:02d}"
        # Validate the update_time format
        elif not re.match(r"^([0-9]|[01][0-9]|2[0-3]):([0-5][0-9])$", ips_settings["update_time"]):
            logger.error("IPS settings 'update_time' field has invalid format. Expected HH:MM.")

    def sync_settings(self, settings_file, prefix, delete_list) -> None:  # noqa: ANN001
        """
        Sync the IPS settings with the underlying system.
        Creates a cron job to update IPS signatures.
        """
        logger.info("Syncing settings")
        self.create_crond_config(prefix, settings_file)

    def create_crond_config(self, prefix: str, settings_file: str) -> None:
        """Create cronjob for updating IPS signatures nightly"""
        dirname = os.path.join(prefix, Common.CRON_D_DIR.strip("/"))
        cron_file_path = os.path.join(dirname, CronDIpsManager.UPDATE_SCRIPT_FILENAME)

        ips_settings = settings_file.settings.get("ips", {})

        # iterate through the rules source list and build the arguments to the script
        ips_sources = ips_settings.get("ruleList", [])
        args = []
        urls_found = False
        for source in ips_sources:
            # If not enabled skip this source
            if not source.get("enabled", True):
                continue
            # Source is enabled, found a URL
            urls_found = True
            # append url
            args.append(f"--url {source.get('url')}")
            if source.get("version"):
                args.append(f"--suricata-version {source.get('version')}")

        # If no enabled URLs were found, remove the cron job file if it exists.
        if not urls_found:
            if not os.path.exists(dirname):
                os.makedirs(dirname)
            with open(cron_file_path, "w") as _:
                pass  # Write an empty file
            return

        # If we have URLs, create the cron job
        if not os.path.exists(dirname):
            os.makedirs(dirname)

        # append signatures directory
        args.append(f"--signatures-directory {IpsManager.SIGNATURE_DIR}")
        # create a string arguments
        args_str = " ".join(args)

        # Parse the update_time from settings
        update_time = ips_settings.get("update_time", "00:00")
        try:
            hour, minute = map(int, update_time.split(":"))
        except (ValueError, AttributeError):
            logger.exception("Invalid update_time format, using default 00:00")
            hour, minute = 0, 0

        with open(cron_file_path, "w+") as f:
            f.write(
                f"{minute} {hour} * * * root {os.path.join(Common.USR_BIN_DIR, CronDIpsManager.UPDATE_SCRIPT_FILENAME)} {args_str} &>> {os.path.join(Common.LOG_DIR, CronDIpsManager.UPDATE_SCRIPT_FILENAME)}.log\n"
            )
