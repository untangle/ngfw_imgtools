"""This class is responsible for validating interfaces"""

import ipaddress
import re

from sync import network_util, registrar
from sync.common.validators.base_validator import Validator
from sync.settings_exception import SettingsException


class InterfaceValidator(Validator):
    """Handles validation of interfaces"""

    def __init__(self, settings_file) -> None:
        self.settings_file = settings_file

    def validate(self, intf) -> None:
        """
        validates that each field within an interface makes sense individually
        @param self - this class instance
        @param intf - the network interface we are validating
        """
        # If the interface is disabled, don't bother verifying attributes
        if intf.get("enabled") is None:
            raise SettingsException(message_str="Missing enabled attribute: " + intf.get("name"))
        if not intf.get("enabled"):
            return

        interfaces = self.settings_file.settings.get("network").get("interfaces")

        for required_key in [
            "interfaceId",
            "name",
            "wan",
            "device",
            "type",
            "configType",
        ]:
            if required_key not in intf:
                raise SettingsException(
                    message_str="Missing required attribute: "
                    + intf.get("name")
                    + " "
                    + required_key
                )

        for ipv4_key in [
            "v4StaticAddress",
            "v4StaticGateway",
            "v4StaticDNS1",
            "v4StaticDNS2",
            "v4DhcpAddressOverride",
            "v4DhcpGatewayOverride",
            "v4DhcpDNS1Override",
            "v4DhcpDNS2Override",
            "v4PPPoEOverrideDNS1",
            "v4PPPoEOverrideDNS2",
            "dhcpRangeStart",
            "dhcpRangeEnd",
            "dhcpGatewayOverride",
            "dhcpDNSOverride",
        ]:
            if not valid_ipv4(intf.get(ipv4_key), accept_none=True):
                raise SettingsException(
                    message_str="Invalid IPv4 Address: "
                    + intf.get("name")
                    + " "
                    + ipv4_key
                    + " = "
                    + intf.get(ipv4_key)
                )

        for ipv6_key in [
            "v6StaticAddress",
            "v6StaticGateway",
            "v6StaticDNS1",
            "v6StaticDNS2",
            "v6DhcpDNS1Override",
            "v6DhcpDNS2Override",
        ]:
            if not valid_ipv6(intf.get(ipv6_key), accept_none=True):
                raise SettingsException(
                    message_str="Invalid IPv6 Address: "
                    + intf.get("name")
                    + " "
                    + ipv6_key
                    + " = "
                    + intf.get(ipv6_key)
                )

        for ipv4_prefix_key in [
            "v4StaticPrefix",
            "v4DhcpPrefixOverride",
            "dhcpPrefixOverride",
        ]:
            if intf.get(ipv4_prefix_key) is not None and (
                intf.get(ipv4_prefix_key) < 1 or intf.get(ipv4_prefix_key) > 32
            ):
                raise SettingsException(
                    message_str="Invalid IPv4 Prefix: "
                    + intf.get("name")
                    + " "
                    + ipv4_prefix_key
                    + " = "
                    + intf.get(ipv4_prefix_key)
                )

        for ipv6_prefix_key in ["v6StaticPrefix", "v6AssignPrefix"]:
            if intf.get(ipv6_prefix_key) is not None and (
                intf.get(ipv6_prefix_key) < 1 or intf.get(ipv6_prefix_key) > 128
            ):
                raise SettingsException(
                    message_str="Invalid IPv6 Prefix: "
                    + intf.get("name")
                    + " "
                    + ipv6_prefix_key
                    + " = "
                    + intf.get(ipv6_prefix_key)
                )

        # check individual settings
        if "-" in intf.get("name"):
            raise SettingsException(
                message_str="Invalid interface name contains hyphen: " + intf.get("name")
            )

        # validate that interface name is not only integers
        if not re.match("^[a-zA-Z]+[a-zA-Z0-9_]*$", intf.get("name")):
            raise SettingsException(
                message_str="Invalid interface name, at least one character required: "
                + intf.get("name")
            )

        # validate interface name is "nftables compatible"
        if intf.get("name")[0].isdigit():
            raise SettingsException(
                message_str="Invalid interface name, interfaces should not start with an integer: "
                + intf.get("name")
            )

        if intf.get("v4ConfigType") not in [
            None,
            "STATIC",
            "DHCP",
            "PPPOE",
            "DISABLED",
        ]:
            raise SettingsException(
                message_str="Invalid v4ConfigType: "
                + intf.get("name")
                + " "
                + intf.get("v4ConfigType")
            )

        if intf.get("v4Aliases") is not None:
            for v4_alias in intf.get("v4Aliases"):
                if not valid_ipv4(v4_alias.get("v4Address")):
                    raise SettingsException(
                        message_str="Invalid IPv4 Alias Address: "
                        + intf.get("name")
                        + " "
                        + v4_alias.get("v4Address")
                    )
                if v4_alias.get("v4Prefix") < 1 or v4_alias.get("v4Prefix") > 32:
                    raise SettingsException(
                        message_str="Invalid IPv4 Alias Prefix: "
                        + intf.get("name")
                        + " "
                        + v4_alias.get("v4Prefix")
                    )

        if intf.get("v4PPPoEUsername") is not None and not isinstance(
            intf.get("v4PPPoEUsername"), str
        ):
            raise SettingsException(
                message_str="Invalid PPPoE Username: "
                + intf.get("name")
                + " "
                + intf.get("v4PPPoEUsername")
            )

        if intf.get("v4PPPoEPassword") is not None and not isinstance(
            intf.get("v4PPPoEPassword"), str
        ):
            raise SettingsException(
                message_str="Invalid PPPoE Password: "
                + intf.get("name")
                + " "
                + intf.get("v4PPPoEPassword")
            )

        if intf.get("v4PPPoEUsePeerDNS") is not None and not isinstance(
            intf.get("v4PPPoEUsePeerDNS"), bool
        ):
            raise SettingsException(
                message_str="Invalid PPPoE UsePeerDNS: "
                + intf.get("name")
                + " "
                + intf.get("v4PPPoEUsePeerDNS")
            )

        if intf.get("v6ConfigType") not in [
            None,
            "DHCP",
            "SLAAC",
            "ASSIGN",
            "STATIC",
            "DISABLED",
        ]:
            raise SettingsException(
                message_str="Invalid v6ConfigType: "
                + intf.get("name")
                + " "
                + intf.get("v6ConfigType")
            )

        if intf.get("v6AssignHint") is not None and not isinstance(intf.get("v6AssignHint"), str):
            raise SettingsException(
                message_str="Invalid v6AssignHint: "
                + intf.get("name")
                + " "
                + intf.get("v6AssignHint")
            )

        if intf.get("v6RelayEnabled") is not None and not isinstance(
            intf.get("v6RelayEnabled"), bool
        ):
            raise SettingsException(
                message_str="Invalid IPv6 Relay option: "
                + intf.get("name")
                + " "
                + intf.get("v6RelayEnabled")
            )

        if intf.get("routerAdvertisements") is not None and not isinstance(
            intf.get("routerAdvertisements"), bool
        ):
            raise SettingsException(
                message_str="Invalid Router Advertisements: "
                + intf.get("name")
                + " "
                + intf.get("routerAdvertisements")
            )

        if intf.get("bridgedTo") is not None and not isinstance(intf.get("bridgedTo"), int):
            raise SettingsException(
                message_str="Invalid Bridged To: " + intf.get("name") + " " + intf.get("bridgedTo")
            )

        if intf.get("wan") and intf.get("qosEnabled"):
            if intf.get("downloadKbps") is not None and not isinstance(
                intf.get("downloadKbps"), int
            ):
                raise SettingsException(
                    message_str="Invalid DownloadKbps: "
                    + intf.get("name")
                    + " "
                    + intf.get("downloadKbps")
                )

            if intf.get("downloadKbps") is None or intf.get("downloadKpbs") == 0:
                raise SettingsException(
                    message_str="No DownloadKbps specified: " + intf.get("name")
                )

            if intf.get("uploadKbps") is not None and not isinstance(intf.get("uploadKbps"), int):
                raise SettingsException(
                    message_str="Invalid UploadKbps: "
                    + intf.get("name")
                    + " "
                    + intf.get("uploadKbps")
                )

            if intf.get("uploadKbps") is None or intf.get("uploadKpbs") == 0:
                raise SettingsException(message_str="No UploadKbps specified: " + intf.get("name"))

        if intf.get("macaddr") is not None and not isinstance(intf.get("macaddr"), str):
            raise SettingsException(
                message_str="Invalid MAC Address: " + intf.get("name") + " " + intf.get("macaddr")
            )
        if intf.get("macaddr") is not None and not re.match(
            "[0-9a-f]{2}([-:]?)[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$", intf.get("macaddr")
        ):
            raise SettingsException(
                message_str="Invalid MAC Address: " + intf.get("name") + " " + intf.get("macaddr")
            )

        if (
            intf.get("dhcpEnabled", None) is not None
            and not isinstance(intf.get("dhcpEnabled"), bool)
            and self.settings_file.os_name != "eos"
        ):
            raise SettingsException(
                message_str="Invalid DHCP Enabled: "
                + intf.get("name")
                + " "
                + intf.get("dhcpEnabled")
            )
        if intf.get("dhcpOptions") is not None:
            for dhcp_option in intf.get("dhcpOptions"):
                if not isinstance(dhcp_option.get("enabled"), bool):
                    raise SettingsException(
                        message_str="Invalid DHCP Option Enabled: "
                        + intf.get("name")
                        + " "
                        + dhcp_option.get("enabled")
                    )
                if not isinstance(dhcp_option.get("value"), str):
                    raise SettingsException(
                        message_str="Invalid DHCP Option Value: "
                        + intf.get("name")
                        + " "
                        + dhcp_option.get("value")
                    )

        if intf.get("vrrpEnabled") is not None and not isinstance(intf.get("vrrpEnabled"), bool):
            raise SettingsException(
                message_str="Invalid VRRP Enabled: "
                + intf.get("name")
                + " "
                + intf.get("vrrpEnabled")
            )

        if intf.get("vrrpId") is not None and (
            not isinstance(intf.get("vrrpId"), int)
            or intf.get("vrrpId") < 1
            or intf.get("vrrpId") > 255
        ):
            raise SettingsException(
                message_str="Invalid VRRP Id: " + intf.get("name") + " " + intf.get("vrrpId")
            )

        if intf.get("vrrpPriority") is not None and (
            not isinstance(intf.get("vrrpPriority"), int)
            or intf.get("vrrpPriority") < 1
            or intf.get("vrrpPriority") > 255
        ):
            raise SettingsException(
                message_str="Invalid VRRP Priority: "
                + intf.get("name")
                + " "
                + intf.get("vrrpPriority")
            )

        if intf.get("vrrpV4Aliases") is not None:
            for v4_alias in intf.get("vrrpV4Aliases"):
                if not valid_ipv4(v4_alias.get("v4Address")):
                    raise SettingsException(
                        message_str="Invalid IPv4 VRRP Alias Address: "
                        + intf.get("name")
                        + " "
                        + v4_alias.get("v4Address")
                    )
                if v4_alias.get("v4Prefix") < 1 or v4_alias.get("v4Prefix") > 32:
                    raise SettingsException(
                        message_str="Invalid IPv4 VRRP Alias Prefix: "
                        + intf.get("name")
                        + " "
                        + v4_alias.get("v4Prefix")
                    )

        if intf.get("wirelessSsid") is not None and not isinstance(intf.get("wirelessSsid"), str):
            raise SettingsException(
                message_str="Invalid Wireless SSID: "
                + intf.get("name")
                + " "
                + intf.get("wirelessSsid")
            )

        if intf.get("wirelessEncryption") not in [
            None,
            "NONE",
            "WPA1",
            "WPA12",
            "WPA2",
        ]:
            raise SettingsException(
                message_str="Invalid Wireless Encryption: "
                + intf.get("name")
                + intf.get("wirelessEncryption")
            )

        if intf.get("wirelessMode") not in [None, "AP", "CLIENT"]:
            raise SettingsException(
                message_str="Invalid Wireless Mode: "
                + intf.get("name")
                + " "
                + intf.get("wirelessMode")
            )

        if intf.get("type") == "WIFI" and intf.get("hidden") not in [True, False]:
            raise SettingsException(
                message_str="Invalid Hidden Value: "
                + intf.get("name", "")
                + " "
                + intf.get("hidden", "")
            )

        if intf.get("wirelessPassword") is not None and not isinstance(
            intf.get("wirelessPassword"), str
        ):
            raise SettingsException(
                message_str="Invalid Wireless Password: "
                + intf.get("name")
                + " "
                + intf.get("wirelessPassword")
            )

        if intf.get("wirelessChannel") is not None and (
            not isinstance(intf.get("wirelessChannel"), int)
            or intf.get("wirelessChannel") < 0
            or intf.get("wirelessChannel") > 200
        ):
            raise SettingsException(
                message_str="Invalid Wireless Channel: "
                + intf.get("name")
                + " "
                + intf.get("wirelessChannel")
            )

        # do not allow management interfaces to be bridged to (Version 3 bridges)
        if intf.get("management") is True and intf.get("bridgedTo") is not None:
            raise SettingsException(
                message_str="Invalid Management Interface configuration: Cannot bridge a management interface"
                + intf.get("name")
                + " "
                + intf.get("bridgedTo")
            )

        if intf.get("type") in ["NIC", "WIFI", "VLAN"] and intf.get("configType") == "ADDRESSED":
            v4Address = None
            v6Address = None
            if intf.get("v4ConfigType") == "STATIC":
                v4Address = intf.get("v4StaticAddress")
            if intf.get("v6ConfigType") == "STATIC":
                v6Address = intf.get("v6StaticAddress")
            for interface in interfaces:
                if (
                    interface.get("enabled")
                    and interface.get("type") in ["NIC", "WIFI", "VLAN"]
                    and interface.get("configType") == "ADDRESSED"
                    and intf.get("interfaceId") != interface.get("interfaceId")
                ):
                    if v4Address is not None:
                        if (
                            interface.get("v4ConfigType") == "STATIC"
                            and interface.get("v4StaticAddress") == v4Address
                        ):
                            raise SettingsException(
                                message_str="Duplicate IPV4 Address detected: "
                                + v4Address
                                + " used by "
                                + intf.get("name")
                                + " and "
                                + interface.get("name")
                            )

                        if interface.get("v4Aliases") is not None:
                            for alias in interface.get("v4Aliases"):
                                if alias.get("v4Address") == v4Address:
                                    raise SettingsException(
                                        message_str="Duplicate IPV4 Address detected: "
                                        + v4Address
                                        + " used by "
                                        + intf.get("name")
                                        + " and "
                                        + interface.get("name")
                                    )

                    if v6Address is not None:
                        if (
                            interface.get("v6ConfigType") == "STATIC"
                            and interface.get("v6StaticAddress") == v6Address
                        ):
                            raise SettingsException(
                                message_str="Duplicate IPV6 Address detected: "
                                + v6Address
                                + " used by "
                                + intf.get("name")
                                + " and "
                                + interface.get("name")
                            )

                        if interface.get("v6Aliases") is not None:
                            for alias in interface.get("v6Aliases"):
                                if alias.get("v6Address") == v6Address:
                                    raise SettingsException(
                                        message_str="Duplicate IPV6 Address detected: "
                                        + v6Address
                                        + " used by "
                                        + intf.get("name")
                                        + " and "
                                        + interface.get("name")
                                    )

        if intf.get("type") == "OPENVPN":
            if intf.get("configType") not in ["ADDRESSED"]:
                raise SettingsException(
                    message_str="Unsupported OPENVPN config type: " + intf.get("configType")
                )
            for required_attribute in [
                "name",
                "device",
                "openvpnConfFile",
                "natEgress",
                "wan",
            ]:
                if intf.get(required_attribute) is None:
                    raise SettingsException(
                        message_str="Missing required OpenVPN interface attribute: "
                        + required_attribute
                    )
            conffile = intf["openvpnConfFile"]
            for required_attribute in ["encoding", "contents"]:
                if conffile.get(required_attribute) is None:
                    raise SettingsException(
                        message_str="Missing required OpenVPN interface confFile attribute: "
                        + required_attribute
                    )
            if conffile["encoding"] != "base64":
                raise SettingsException(
                    message_str="Unsupported encoding in OpenVPN conf file: "
                    + conffile["encoding"]
                )
            path = "/etc/config/openvpn-" + str(intf["interfaceId"]) + ".ovpn"
            auth_path = "/etc/config/openvpn-" + str(intf["interfaceId"]) + ".auth"

            wanId = intf.get("boundInterfaceId")
            if wanId is not None:
                if isinstance(wanId, str):
                    wanId = int(wanId, 10)

                if wanId != 0:
                    for interface in interfaces:
                        if interface.get("interfaceId") == wanId:
                            if interface.get("enabled") is not True:
                                raise SettingsException(
                                    message_str="Openvpn interface "
                                    + intf.get("name")
                                    + " is bound to disabled wan "
                                    + interface.get("name")
                                )
                else:
                    wanEnabled = False
                    openvpnId = intf.get("interfaceId")
                    for interface in interfaces:
                        if (
                            interface.get("enabled")
                            and interface.get("wan")
                            and openvpnId != interface.get("interfaceId")
                        ):
                            wanEnabled = True

                    if wanEnabled is not True:
                        raise SettingsException(
                            message_str="Openvpn interface "
                            + intf.get("name")
                            + " is enabled, but no parent wans are enabled"
                        )

            # register a new operation to restart this interface if this config file changes
            # register the config file with the new operation
            cmd = "ifdown " + intf["name"] + " ; " + "ifup " + intf["name"]
            opname = "restart-" + intf["device"]
            registrar.register_operation(opname, [""], [cmd], 99, None)
            registrar.register_file(path, opname, self)
            registrar.register_file(auth_path, opname, self)

            # if this openvpn interface uses a username and password, also
            # register the auth file
            if intf.get("openvpnUsernamePasswordEnabled"):
                path = "/etc/config/openvpn-" + str(intf["interfaceId"]) + ".auth"
                registrar.register_operation(opname, [""], [cmd], 99, None)
                registrar.register_file(path, opname, self)

        if intf.get("type") == "WIREGUARD":
            if intf.get("configType") not in ["ADDRESSED"]:
                raise SettingsException(
                    message_str="Unsupported WIREGUARD config type: " + intf.get("configType")
                )
            for required_attribute in ["name", "boundInterfaceId", "wan"]:
                if intf.get(required_attribute) is None:
                    raise SettingsException(
                        message_str="Missing required WireGuard interface attribute: "
                        + required_attribute
                    )
            wanId = intf.get("boundInterfaceId")
            if wanId is not None:
                if isinstance(wanId, str):
                    wanId = int(wanId, 10)

                interfaces = self.settings_file.settings.get("network").get("interfaces")
                if wanId != 0:
                    for interface in interfaces:
                        if interface.get("interfaceId") == wanId:
                            if interface.get("enabled") is not True:
                                raise SettingsException(
                                    message_str="WireGuard interface "
                                    + intf.get("name")
                                    + " is bound to disabled wan "
                                    + interface.get("name")
                                )
                else:
                    wanEnabled = False
                    wireguardId = intf.get("interfaceId")
                    for interface in interfaces:
                        if (
                            interface.get("enabled")
                            and interface.get("wan")
                            and wireguardId != interface.get("interfaceId")
                        ):
                            wanEnabled = True

                    if wanEnabled is not True:
                        raise SettingsException(
                            message_str="WireGuard interface "
                            + intf.get("name")
                            + " is enabled, but no parent wans are enabled"
                        )
            ## Modify restart-networking operation to add ifdown/up after network restart
            (pre_commands, post_commands, priority, parent) = registrar.get_operation(
                "restart-networking"
            )
            post_commands.append("ifdown " + intf["name"] + " ; " + "ifup " + intf["name"])
            registrar.register_operation(
                "restart-networking", pre_commands, post_commands, priority, parent
            )

            if intf.get("wireguardPrivateKey") is None or intf.get("wireguardPrivateKey") == "":
                raise SettingsException(
                    message_str="No wireguard private key specified for interface: "
                    + intf.get("name")
                )

            if not isinstance(intf.get("wireguardPrivateKey"), str):
                raise SettingsException(
                    message_str="Specified wireguard private key is not a string: "
                    + intf.get("name")
                )

            if intf.get("wireguardAddresses") is None or intf.get("wireguardAddresses") == []:
                raise SettingsException(
                    message_str="No wireguard addresses specified for interface: "
                    + intf.get("name")
                )

            addresses = intf.get("wireguardAddresses")
            for address in addresses:
                if not valid_ipv4_network(address.get("address")) and not valid_ipv6_network(
                    address.get("address")
                ):
                    raise SettingsException(
                        message_str="Invalid wireguard address: "
                        + intf.get("name")
                        + " "
                        + address.get("address")
                    )

            if intf.get("wireguardPeers") is None or intf.get("wireguardPeers") == []:
                raise SettingsException(
                    message_str="No wireguard peers specified for interface: " + intf.get("name")
                )

            peers = intf.get("wireguardPeers")
            for peer in peers:
                if peer.get("publicKey") is None or peer.get("publicKey") == "":
                    raise SettingsException(
                        message_str="No public key specified for wireguard peer of interface: "
                        + intf.get("name")
                    )

                if not isinstance(peer.get("publicKey"), str):
                    raise SettingsException(
                        message_str="Specified wireguard peer private key is not a string: "
                        + intf.get("name")
                    )

                host = peer.get("host")
                if (
                    not valid_ipv4_network(host)
                    and not valid_ipv6_network(host)
                    and not valid_hostname(host)
                ):
                    raise SettingsException(
                        message_str="Specified WireGuard Endpoint address is not valid: " + peer
                    )

                port = peer.get("port")
                if not isinstance(port, int):
                    raise SettingsException(
                        message_str="WireGuard Endpoint Listen Port not an integer: " + port
                    )

                if peer.get("allowedIps") is None or peer.get("allowedIps") == []:
                    raise SettingsException(
                        message_str="No wireguard peer addresses specified for interface: "
                        + intf.get("name")
                    )

                networks = peer.get("allowedIps")
                for network in networks:
                    cidr_network = "{address}/{prefix}".format(
                        address=network.get("address"), prefix=network.get("prefix")
                    )
                    if not valid_ipv4_network(cidr_network) and not valid_ipv6_network(
                        cidr_network
                    ):
                        raise SettingsException(
                            message_str="Invalid wireguard ip: "
                            + intf.get("name")
                            + " "
                            + cidr_network
                        )

                if peer.get("routeAllowedIps") is not None and not isinstance(
                    peer.get("routeAllowedIps"), bool
                ):
                    raise SettingsException(
                        message_str="wireguard peer settings routeAllowedIps is not a bool: "
                        + intf.get("name")
                    )

                if peer.get("keepalive") is not None and not isinstance(
                    peer.get("keepalive"), int
                ):
                    raise SettingsException(
                        message_str="wireguard peer keepalive is not an integer: "
                        + intf.get("name")
                    )

                if peer.get("keepalive") is not None and peer.get("keepalive") < 0:
                    raise SettingsException(
                        message_str="Invalid wireguard peer keepalive: "
                        + intf.get("name")
                        + " "
                        + str(peer.get("keepalive"))
                    )

            if intf.get("wireguardPort") is not None:
                if not isinstance(intf.get("wireguardPort"), int):
                    raise SettingsException(
                        message_str="Specified wireguard port is not an integer: "
                        + intf.get("name")
                    )

                if intf.get("wireguardPort") < 0 or intf.get("wireguardPort") > 65535:
                    raise SettingsException(
                        message_str="Invalid wireguard port (valid values 0-65535): "
                        + intf.get("name")
                        + " "
                        + str(intf.get("wireguardPort"))
                    )

        if intf.get("type") == "WWAN":
            if intf.get("simApn") is not None and not isinstance(intf.get("simApn"), str):
                raise SettingsException(
                    message_str="Invalid WWAN apn: must be a string: " + intf.get("name")
                )

            if intf.get("simProfile") is not None and not isinstance(intf.get("simProfile"), int):
                raise SettingsException(
                    message_str="Invalid WWAN profile: must be an int: " + intf.get("name")
                )

            if intf.get("simPin") is not None and not isinstance(intf.get("simPin"), int):
                raise SettingsException(
                    message_str="Invalid WWAN pin: must be an int: " + intf.get("name")
                )

            auth = intf.get("simAuth")
            if auth is not None:
                if not isinstance(auth, str):
                    raise SettingsException(
                        message_str="Invalid WWAN auth: must be a string: " + intf.get("name")
                    )

                if auth != "NONE":
                    if auth not in ["PAP", "CHAP", "BOTH"]:
                        raise SettingsException(
                            message_str="Invalid WWAN auth: must NONE, PAP, CHAP, or BOTH: "
                            + intf.get("name")
                        )

                    if intf.get("simUsername") is None:
                        raise SettingsException(
                            message_str="Invalid WWAN config: Must specify username for PAP/CHAP/BOTH: "
                            + intf.get("name")
                        )

                    if not isinstance(intf.get("simUsername"), str):
                        raise SettingsException(
                            message_str="Invalid WWAN username: Username must be string: "
                            + intf.get("name")
                        )

                    if intf.get("simPassword") is None:
                        raise SettingsException(
                            message_str="Invalid WWAN config: Must specify password for PAP/CHAP/BOTH: "
                            + intf.get("name")
                        )

                    if not isinstance(intf.get("simPassword"), str):
                        raise SettingsException(
                            message_str="Invalid WWAN password: Password must be string: "
                            + intf.get("name")
                        )

            mode = intf.get("simMode")
            if mode is not None:
                if not isinstance(mode, str):
                    raise SettingsException(
                        message_str="Invalid WWAN mode: must be a string: " + intf.get("name")
                    )

                if mode not in ["ALL", "LTE", "UMTS", "GSM", "CDMA", "TDSCDMA"]:
                    raise SettingsException(
                        message_str="Invalid WWAN mode: must be ALL, LTE, UMTS, GSM, CDMA, or TDSCDMA: "
                        + intf.get("name")
                    )

            pdptype = intf.get("simPdptype")
            if pdptype is not None:
                if not isinstance(pdptype, str):
                    raise SettingsException(
                        message_str="Invalid WWAN pdptype: must be a string: " + intf.get("name")
                    )

                if pdptype not in ["IPV4", "IPV6", "IPV4V6"]:
                    raise SettingsException(
                        message_str="Invalid WWAN pdptype: must be IPV4, IPV6, or IPV4V6: "
                        + intf.get("name")
                    )

            plmn = intf.get("simPlmn")
            if plmn is not None and not isinstance(plmn, int):
                raise SettingsException(
                    message_str="Invalid WWAN plmn: must be an int: " + intf.get("name")
                )

            autoconnect = intf.get("simAutoconnect")
            if autoconnect is not None and not isinstance(autoconnect, bool):
                raise SettingsException(
                    message_str="Invalid WWAN autoconnect: must be a bool: " + intf.get("name")
                )

        if intf.get("type") == "VLAN":
            for interface in interfaces:
                if (
                    interface.get("interfaceId") != intf.get("interfaceId")
                    and interface.get("enabled")
                    and interface.get("type") == "VLAN"
                    and interface.get("vlanid") == intf.get("vlanid")
                    and interface.get("boundInterfaceId") == intf.get("boundInterfaceId")
                ):
                    vlanBoundInterface = network_util.get_interface_by_id(
                        self.settings_file.settings, intf.get("boundInterfaceId")
                    )
                    raise SettingsException(
                        message_str="Invalid VLAN config: A VLAN with parent interface "
                        + vlanBoundInterface.get("name")
                        + " and vlanId "
                        + str(intf.get("vlanid"))
                        + " already exists"
                    )

        if intf.get("type") == "BRIDGE":
            self.validate_bridge(interfaces, intf, self.settings_file)

        if intf.get("type") == "IPSEC":
            if intf.get("configType") not in ["ADDRESSED"]:
                raise SettingsException(
                    message_str="Unsupported IPSEC config type: " + intf.get("configType")
                )
            for required_attribute in ["name", "boundInterfaceId", "wan", "ipsec"]:
                if intf.get(required_attribute) is None:
                    raise SettingsException(
                        message_str="Missing required IPsec interface attribute: "
                        + required_attribute
                    )

            ipsec = intf.get("ipsec")
            for required_attribute in [
                "authentication",
                "local",
                "remote",
                "phase1",
                "phase2",
                "phase1Lifetime",
                "phase2Lifetime",
            ]:
                if ipsec.get(required_attribute) is None:
                    raise SettingsException(
                        message_str="Missing required IPsec attribute: " + required_attribute
                    )

            if ipsec.get("local").get("gateway") is None:
                raise SettingsException(message_str="Missing IPsec local gateway")
            if not ipsec.get("local").get("networks"):
                raise SettingsException(message_str="Missing IPsec local networks")

            if ipsec.get("remote").get("gateway") is None:
                raise SettingsException(message_str="Missing IPsec remote gateway!")
            if not ipsec.get("remote").get("networks"):
                raise SettingsException(message_str="Missing IPsec remote networks")

            if (
                ipsec.get("remote").get("gateway") == "%any"
                and ipsec.get("local").get("gateway") == "%any"
            ):
                raise SettingsException(message="api_ipsec_local_remote_any")

            wanId = intf.get("boundInterfaceId")
            if wanId is not None:
                if isinstance(wanId, str):
                    wanId = int(wanId, 10)
                if wanId != 0:
                    for interface in interfaces:
                        if interface.get("interfaceId") == wanId:
                            if interface.get("enabled") is not True:
                                raise SettingsException(
                                    message_str="IPsec interface "
                                    + intf.get("name")
                                    + " is bound to disabled wan "
                                    + interface.get("name")
                                )

    def validate_bridge(self, interfaces, bridge_intf, settings_file) -> None:
        """returns error if bridge configuration is invalid"""
        bridged_interfaces = bridge_intf.get("bridgedInterfaces", None)

        for br_intf_id in bridged_interfaces:
            br_intf = network_util.get_interface_by_id(settings_file.settings, br_intf_id)
            if br_intf.get("management") is True:
                raise SettingsException(
                    message_str=f"Invalid BRIDGE config: Cannot bridge management interface '{br_intf.get('name')}' with bridge '{bridge_intf.get('name')}'"
                )


def valid_ipv4(address, accept_none=False) -> bool:
    """returns true if address (string) is a valid IPv4 address"""
    if address is None and accept_none:
        return True
    try:
        ipaddress.IPv4Address(address)
        return True
    except:
        return False


def valid_ipv6(address, accept_none=False) -> bool:
    """returns true if address (string) is a valid IPv6 address"""
    if address is None and accept_none:
        return True
    try:
        ipaddress.IPv6Address(address)
        return True
    except:
        return False


def valid_ipv4_network(address, accept_none=False) -> bool:
    """returns true if address (string) is a valid IPv4 network"""
    if address is None and accept_none:
        return True
    try:
        ipaddress.IPv4Interface(address)
        return True
    except:
        return False


def valid_ipv6_network(address, accept_none=False) -> bool:
    """returns true if address (string) is a valid IPv6 network"""
    if address is None and accept_none:
        return True
    try:
        ipaddress.IPv6Interface(address)
        return True
    except:
        return False


def valid_hostname(hostname, accept_none=False):
    """returns true if hostname (string) is a valid domain name"""
    if hostname is None and accept_none:
        return True

    hostname = hostname.removesuffix(".")

    if len(hostname) < 1 or len(hostname) > 253:
        return False

    hostname_segment_re = re.compile("^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$", re.IGNORECASE)
    return all(hostname_segment_re.match(x) for x in hostname.split("."))
