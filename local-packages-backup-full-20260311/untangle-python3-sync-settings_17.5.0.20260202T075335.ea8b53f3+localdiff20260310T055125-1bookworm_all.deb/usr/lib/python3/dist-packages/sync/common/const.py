# MFW config constants
MFW_CONFIG_WANPOLICY = "mfw-config-wanpolicy"
MFW_CONFIG_CAPTIVEPORTAL = "mfw-config-captiveportal"
