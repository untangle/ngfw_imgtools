"""webroot_manager manages webroot settings"""

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

# default values for webroot configuration
default_webroot_config = {"cacheEnabled": True, "cacheTtlSeconds": 30}

logger = Logger.getInstance()


class WebrootManager(Manager):
    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def validate_settings(self, settings_file) -> None:
        """validates settings"""
        webrootSettings = settings_file.settings.get("webroot")
        if webrootSettings is None:
            raise SettingsException(message="api_webroot_missing_config")

        if "cacheEnabled" not in webrootSettings:
            raise SettingsException(message="api_webroot_cache_enabled_missing")

        if not isinstance(webrootSettings["cacheEnabled"], bool):
            raise SettingsException(message="api_webroot_cache_enabled_invalid_value")

        if "cacheTtlSeconds" not in webrootSettings:
            raise SettingsException(message="api_webroot_cache_ttl_seconds_missing")

        if not isinstance(webrootSettings["cacheTtlSeconds"], int):
            raise SettingsException(message="api_webroot_cache_ttl_seconds_invalid_value")

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["webroot"] = default_webroot_config

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""

        # Load defaults if no webroot settings are present.
        webroot_settings = settings_file.settings.get("webroot")
        if webroot_settings is None:
            settings_file.settings["webroot"] = default_webroot_config
            return

        # Remove unknown fields.
        if webroot_settings is not None:
            # keep only defined settings
            settings_file.settings["webroot"] = {
                name: value
                for name, value in settings_file.settings.get("webroot").items()
                if name in default_webroot_config
            }

        # Add missing configuration fields from defaults.
        for key, value in default_webroot_config.items():
            if key not in settings_file.settings["webroot"]:
                settings_file.settings["webroot"][key] = value


registrar.register_manager(WebrootManager())
