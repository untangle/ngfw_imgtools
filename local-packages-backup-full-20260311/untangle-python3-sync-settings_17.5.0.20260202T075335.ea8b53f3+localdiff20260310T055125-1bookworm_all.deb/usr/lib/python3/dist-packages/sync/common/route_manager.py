"""route_manager manages wan based routing decisions"""

import collections
import copy
import json
import os
import subprocess
from uuid import uuid4

from sync import (
    Manager,
    Variables,
    interface_util,
    network_util,
    nftables_util,
    registrar,
)
from sync.common import Logger
from sync.file_util import FileUtil
from sync.interface_util import INTERFACE_CONDITIONS, sanitize_interface_name_conditions
from sync.perms_util import regain_permissions
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

logger = Logger.getInstance()


class CommonRouteManager(Manager):
    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        version = settings_file.settings["version"]
        if version >= 4:
            # In MFW-6.1, the file "102-wan-routing" is moved from /etc/config/nftables-rules.d
            # When MFW gets upgraded from previous versions, to make sure that the old file is removed.
            # so below method call deletes the old file
            self.delete_wan_routing_config_file(
                "/etc/config/nftables-rules.d/102-wan-routing", False
            )
            # MFW-6326 the brightcloud fix file /etc/config/ifup.d/10-brightcloud-fix should be removed
            # also the ip should be deleted if exists
            self.clean_brightcloud_ip(
                FileUtil.locate_file("/etc/config/ifup.d/10-brightcloud-fix")
            )

        wan = settings_file.settings["wan"]
        nftables_util.verify_guid(wan.get("policies"), "policyId", wan.get("policy_chains"))

        self.sanitize_policies(settings_file)
        self.sanitize_policy_chains(settings_file)
        self.sanitize_check_disabled_wan_rules(settings_file)
        self.sort_policy_rules(settings_file)
        self.sanitize_invalid_settings(settings_file)
        self.sanitize_ping_analyzers(settings_file)

    def sanitize_ping_analyzers(self, settings_file) -> None:
        """removes interfaceId of deleted/non-wan Interface from the Ping Analyzers"""
        new_interfaces = settings_file.settings.get("network").get("interfaces")

        # make a map of all wan interface IDs
        interface_id_map = {}
        for new_interface in new_interfaces:
            if new_interface["wan"] and new_interface["enabled"]:
                interface_id_map[new_interface["interfaceId"]] = True

        # iterate over all pingAnalyzers and remove the interface IDs which does not exists
        updated_ping_analyzers = settings_file.settings.get("stats").get("pingAnalyzers")
        for i in range(len(updated_ping_analyzers)):
            for interface_id in updated_ping_analyzers[i]["interfaceIds"]:
                if not interface_id_map.get(interface_id, False):
                    updated_ping_analyzers[i]["interfaceIds"].remove(interface_id)

        settings_file.settings["stats"]["pingAnalyzers"] = updated_ping_analyzers

    # Check for newly created wan interfaces THAT ARE NOT IPSEC (those are handled in the ipsec manager)
    # The interface will be flagged with a 'new' field by the UI
    # For new wan interfaces create a SPECIFIC_WAN policy and then remove the new field
    def sanitize_policies(self, settings_file) -> None:
        policies = settings_file.settings["wan"].get("policies")
        interfaces = settings_file.settings.get("network").get("interfaces")
        for interface in interfaces:
            # IPSEC tunnels are handled by ipsec_manager
            if interface.get("new") is not None and interface.get("type") != "IPSEC":
                policy = {}
                policy["description"] = "Send traffic to " + interface.get("name")
                policy["enabled"] = interface.get("enabled")
                policy["interfaces"] = [
                    collections.OrderedDict({"interfaceId": interface.get("interfaceId")})
                ]
                policy["type"] = "SPECIFIC_WAN"
                policy["policyId"] = uuid4().__str__()
                policy["readOnly"] = True
                ordered_policy = collections.OrderedDict(policy)
                if not self.policy_exists(ordered_policy, policies):
                    policies.append(ordered_policy)

    def sanitize_conditions_for_interface_name(
        self, settings_file: SettingsFile, rules: list[dict]
    ) -> list[dict]:
        """
        Iterates all the rules and searches if any condition has any of the source_interface_name
        or destination_interface_name types and replaces them with the source_interface_zone
        == <interface_id> or destination_interface_zone == <interface_id> condition.
        Args:
            settings_file : object
        An object containing the settings, which includes network interface details. It is expected to have
        a `settings` attribute that provides access to the network configuration.
            rules (list[dict]): A list of rule dictionaries. Each rule may contain
                a "conditions" key, which is a list of condition dictionaries to be sanitized.
        Returns:
            list[dict]: The sanitized list of rules with updated conditions.
        """
        for rule in rules:
            for condition in rule.get("conditions", []):
                if condition.get("type") in INTERFACE_CONDITIONS:
                    # Change into <source_or_dest>_interface_zone == <interface _id> condition
                    condition = sanitize_interface_name_conditions(settings_file, condition)
        return rules

    def sanitize_policy_chains(self, settings_file) -> None:
        version = settings_file.settings["version"]
        policy_chains = settings_file.settings["wan"].get("policy_chains")
        for chain in policy_chains:
            chain["rules"] = self.sanitize_conditions_for_interface_name(
                settings_file, chain.get("rules", [])
            )
            nftables_util.verify_guid(chain.get("rules"), "ruleId", relatedChains=None)
            nftables_util.clean_rule_actions(chain, chain.get("rules"))

            # Version check, use MFW version for the version bump
            if version < 3:
                nftables_util.fix_MFW_1082_rules("wan-routing", chain.get("rules"))
                nftables_util.fix_port_proto_rules(chain.get("rules"))

    # Clean up rules that may be referencing a disabled interface, only if Force is passed as true
    def sanitize_check_disabled_wan_rules(self, settings_file) -> None:
        wan_rule_with_disabled_intf = self.get_wan_rules_with_disabled_or_deleted_intf(
            settings_file.settings
        )
        policies = settings_file.settings["wan"].get("policies")
        if Variables.get("force") is not None and Variables.get("force").lower() == "true":
            deleted_policies = []
            for pidx, policy in enumerate(policies):
                interfaces = policy.get("interfaces")
                for _iidx, interface in enumerate(interfaces):
                    curr_intf = network_util.get_interface_by_id(
                        settings_file.settings, interface.get("interfaceId")
                    )
                    if interface.get("interfaceId") != 0 and (
                        curr_intf is None or curr_intf.get("enabled") is False
                    ):
                        if curr_intf is None:
                            deleted_policies.append(pidx)

            policies = [
                policy for pidx, policy in enumerate(policies) if pidx not in deleted_policies
            ]
            settings_file.settings["wan"]["policies"] = policies

            deleted_rules = []
            policy_chains = settings_file.settings["wan"].get("policy_chains")
            for pcidx, policy_chain in enumerate(policy_chains):
                for ridx, rule in enumerate(policy_chain.get("rules")):
                    action = rule.get("action")
                    if action.get("type") == "WAN_POLICY":
                        policy = action.get("policy")
                        curr_pol = network_util.get_policy_by_id(settings_file.settings, policy)
                        if curr_pol is None or (
                            rule.get("enabled")
                            and wan_rule_with_disabled_intf.get(rule["ruleId"], False)
                        ):
                            if curr_pol is None:
                                deleted_rules.append(ridx)
                            elif wan_rule_with_disabled_intf.get(rule["ruleId"], False):
                                policy_chain.get("rules")[ridx]["enabled"] = False
                new_rules = [
                    rule
                    for ridx, rule in enumerate(policy_chain.get("rules"))
                    if ridx not in deleted_rules
                ]
                settings_file.settings["wan"]["policy_chains"][pcidx]["rules"] = new_rules

    def sort_policy_rules(self, settings_file) -> None:
        policy_chains = settings_file.settings["wan"].get("policy_chains")

        for pcidx, policy_chain in enumerate(policy_chains):
            hidden_rules = []
            other_rules = []

            for _, rule in enumerate(policy_chain.get("rules")):
                isHidden = rule.get("isHidden")
                if isHidden is True:
                    hidden_rules.append(rule)
                else:
                    other_rules.append(rule)

            sorted_rules = hidden_rules + other_rules
            settings_file.settings["wan"]["policy_chains"][pcidx]["rules"] = sorted_rules

    # Returns a map of WAN ruleId with interfaceId (if interface is disabled or deleted)
    def get_wan_rules_with_disabled_or_deleted_intf(self, settings_file):
        is_interface_id_disabled = {}  # maintains interface id if disabled
        policy_id_with_disabled_attached_inteface = {}  # policy Id attached to disabled interfaces
        wan_rule_state = {}  # if associated interface is disabled then policy should also be disabled
        interfaces = settings_file["network"]["interfaces"]

        # Create a map of all disabled interfaces with key:InterfaceID, value: True (If disabled)
        for interface in interfaces:
            if not interface.get("enabled"):
                is_interface_id_disabled[interface.get("interfaceId")] = True

        # Create a map of WAN Policiy ID attached to disabled or deleted WAN Interfaces
        for wan_policy in settings_file["wan"]["policies"]:
            for interface in wan_policy.get("interfaces"):
                if (
                    is_interface_id_disabled.get(interface["interfaceId"], False)
                    or network_util.get_interface_by_id(settings_file, interface["interfaceId"])
                    is None
                ):
                    policy_id_with_disabled_attached_inteface[wan_policy["policyId"]] = interface[
                        "interfaceId"
                    ]

        # Create a map of WAN RuleID to attached interface ID
        for wan_rules in settings_file["wan"]["policy_chains"]:
            for wan_rule in wan_rules.get("rules"):
                wan_action = wan_rule.get("action")
                if wan_action.get("type") == "WAN_POLICY":
                    if policy_id_with_disabled_attached_inteface.get(wan_action["policy"], False):
                        wan_rule_state[wan_rule["ruleId"]] = (
                            policy_id_with_disabled_attached_inteface[wan_action["policy"]]
                        )

        return wan_rule_state

    # Sanitizes rule's conditions
    # Check is related services are enabled
    # Adds to invalid_items if invalid services are disabled
    def check_rule_condition_service(
        self,
        settings,
        rules,
        application_contol_enabled,
        geoip_enabled,
        invalid_items,
        possible_invalid_items,
        disable_invalid_rules,
    ):
        """Sanitize Rules to check required service state"""

        for rule in rules["rules"]:
            if rule["enabled"] is False:
                # rule is disabled, no need to check service state
                continue
            for rule_condition in rule["conditions"]:
                # Possible to have a rule with conditions for which muliple services are disabled
                # i.e. A wan-rule can have both geo-IP and Application Control Condition
                # In case multiple required services are disabled, add both of them in invalid_items
                if "APPLICATION" in rule_condition["type"] and application_contol_enabled is False:
                    if disable_invalid_rules is True:
                        rule["enabled"] = False
                    else:
                        # Rule has application control related condition
                        # Service: Application Control is disabled
                        # fore='true' is not recieved, add to invalid items
                        invalid_items.update(
                            self.create_invalid_items(
                                rule,
                                settings["application_control"],
                                rule.get("ruleId"),
                                "rule",
                                rule.get("description"),
                                "application_control",
                                "services",
                                "Application Control",
                                possible_invalid_items,
                                invalid_items,
                            )
                        )
                if "GEOIP" in rule_condition["type"] and geoip_enabled is False:
                    if disable_invalid_rules is True:
                        rule["enabled"] = False
                    else:
                        # Rule has geoip related condition
                        # Service: geo-IP is disabled
                        # fore='true' is not recieved, add to invalid items
                        invalid_items.update(
                            self.create_invalid_items(
                                rule,
                                settings["geoip"],
                                rule.get("ruleId"),
                                "rule",
                                rule.get("description"),
                                "geoip",
                                "services",
                                "Geo-IP",
                                possible_invalid_items,
                                invalid_items,
                            )
                        )

        return invalid_items

    # Checks the following rules: [Network > Shaping Rules, Network > NAT Rules, Routing > WAN Rules, Settings > Firewall > Filter Rules]
    # If the Rule is enabled and it has a condition for which required service is disabled, add to invalid_items
    # e.g. Network > Shaping Rule has condition related to Application Control, and Service: Application Control is disabled, Add this rule to list of invalid_items
    def sanitize_invalid_rules(self, settings, invalid_items, possible_invalid_items):
        """Checks invalid rules having condition with disabled services"""

        application_contol_enabled = settings["application_control"]["enabled"]
        geoip_enabled = settings["geoip"]["enabled"]

        if application_contol_enabled is True and geoip_enabled is True:
            # Required Services are already enabled
            return invalid_items

        disable_invalid_rules = False
        if Variables.get("force") is not None and Variables.get("force").lower() == "true":
            # User clicked OK on CONFIRM pop-up
            # Instead of updating the invalid_items disable the enabled rule (for which Service is disabled).
            disable_invalid_rules = True

        # Checks firewall rules and sanitize rules-chains against rules_list_to_check items.
        rules_list_to_check = ["shaping", "nat", "filter"]
        for current_rule in rules_list_to_check:
            rule_chain = (
                settings.get("firewall", {})
                .get("tables", {})
                .get(current_rule, {})
                .get("chains", [])
            )
            for index in range(len(rule_chain)):
                invalid_items = self.check_rule_condition_service(
                    settings,
                    settings["firewall"]["tables"][current_rule]["chains"][index],
                    application_contol_enabled,
                    geoip_enabled,
                    invalid_items,
                    possible_invalid_items,
                    disable_invalid_rules,
                )

        # Checks wan rules and sanitize invalid rules
        for wan_rules in settings["wan"]["policy_chains"]:
            invalid_items = self.check_rule_condition_service(
                settings,
                wan_rules,
                application_contol_enabled,
                geoip_enabled,
                invalid_items,
                possible_invalid_items,
                disable_invalid_rules,
            )

        return invalid_items

    def sanitize_invalid_settings(self, settings_file) -> None:
        """checks for invalid items - for example a rule that had it's policy disabled"""
        settings = settings_file.settings
        invalid_items = {}  # items that are invalid
        possible_invalid_items = {}  # items that are disabled but could be related to true invalid items

        invalid_items, possible_invalid_items = self.sanitize_invalid_policies(
            settings, invalid_items, possible_invalid_items
        )
        invalid_items = self.sanitize_invalid_policy_chains(
            settings, invalid_items, possible_invalid_items
        )
        invalid_items = self.sanitize_invalid_rules(
            settings, invalid_items, possible_invalid_items
        )

        if invalid_items is not None and len(invalid_items) > 0:
            invRPStr = '{"CONFIRM": {"invalidItems": ' + json.dumps(invalid_items) + "}}"
            raise SettingsException(message_str=invRPStr, error_type="confirm")

    def sanitize_invalid_policies(self, settings, invalid_items, possible_invalid_items):
        """sanitize invalid wan policies"""
        wan = settings["wan"]
        policies = wan.get("policies")
        policy_ids = []

        for policy in policies:
            interfaces = policy.get("interfaces")
            policy_id = policy.get("policyId")

            # verify policy ids are correct
            if policy_id is None:
                raise SettingsException(message="api_policy_missing_id")
            if policy_id in policy_ids:
                raise SettingsException(message="api_policy_duplicate_id", vars=[str(policy_id)])

            policy_ids.append(policy_id)

            # check interfaces are valid
            for interface in interfaces:
                if interface.get("interfaceId") is None:
                    raise SettingsException(
                        message="api_interface_missing_id", vars=[str(policy_id)]
                    )

                weight = interface.get("weight")
                if weight is not None and (weight > 10000 or weight < 1):
                    raise SettingsException(
                        message="api_interface_invalid_weight", vars=[str(policy_id), str(weight)]
                    )

            # check have wans
            if len(interfaces) == 1 and interfaces[0].get("interfaceId") == 0:
                interfaces = interface_util.get_all_wan_list(settings)

                if len(interfaces) == 0:
                    raise SettingsException(
                        message="api_policy_no_wans", vars=[policy.get("description")]
                    )

            else:
                # add any invalid policies i.e. need to delete associated rule and polocy if associated interface is deleted
                invalid_items.update(
                    self.create_invalid_policy_interface_items(
                        policy, interfaces, settings, possible_invalid_items
                    )
                )

        # return any invalid items
        return invalid_items, possible_invalid_items

    def create_invalid_items(
        self,
        curr_item,
        parent,
        id,
        type,
        value,
        parent_id,
        parent_type,
        parent_value,
        possible_invalid_items,
        curr_invalid_items=None,
    ):
        """add to invalid_items map by adding child and associated parents"""
        invalid_items = {}
        supported_services_as_parents = ["application_control", "geoip"]

        # current item
        reason = "disabled"
        if curr_item is None:
            reason = "deleted"

        # If child ID already exists in curr_invalid_items and a new parent_id is being added.
        # Check if parent ID does not already exists in the child's ID (to prevent duplicate message shown on the UI)
        # Append the newly added parent ID by (,) seperated (If the parent ID is in supported_services_as_parents)
        current_parent_id = parent_id
        if (
            parent_type == "services"
            and curr_invalid_items.get(id)
            and parent_id not in curr_invalid_items[id]["parentId"]
            and (curr_invalid_items[id]["parentId"] in supported_services_as_parents)
        ):
            current_parent_id = curr_invalid_items[id]["parentId"] + "," + parent_id

        invalid_items[id] = {
            "childId": "",
            "reason": reason,
            "type": type,
            "value": value,
            "parentId": current_parent_id,
        }

        # if parent already in possible_invalid_items, use that value
        if parent_id in possible_invalid_items or (
            curr_invalid_items is not None and parent_id in curr_invalid_items
        ):
            parent_arr = (
                possible_invalid_items
                if parent_id in possible_invalid_items
                else curr_invalid_items
            )
            invalid_items[parent_id] = parent_arr[parent_id]
            invalid_items[parent_id]["childId"] = id
            parent_parent_id = invalid_items[parent_id]["parentId"]
            if len(parent_parent_id) > 0 and (
                parent_parent_id in possible_invalid_items
                or (curr_invalid_items is not None and parent_parent_id in curr_invalid_items)
            ):
                parent_parent_arr = (
                    possible_invalid_items
                    if parent_parent_id in possible_invalid_items
                    else curr_invalid_items
                )
                invalid_items[parent_parent_id] = parent_parent_arr[parent_parent_id]
        else:
            # add new parent
            reason = "disabled"
            if parent is None:
                reason = "deleted"
            if parent_id in supported_services_as_parents:
                reason = "enabled"
            invalid_items[parent_id] = {
                "childId": id,
                "reason": reason,
                "type": parent_type,
                "value": parent_value,
                "parentId": "",
            }

        return invalid_items

    def sanitize_invalid_policy_chains(self, settings, invalid_items, possible_invalid_items):
        """validate policy chains"""

        # check have policy chains
        wan = settings["wan"]
        policy_chains = wan.get("policy_chains")
        if policy_chains is None:
            raise SettingsException(message="api_policy_missing_policyChains")

        existing_policies = {}
        policies = wan.get("policies")

        for policy in policies:
            if policy.get("policyId") is not None:
                existing_policies[policy.get("policyId")] = True

        wan_rule_with_disabled_intf = self.get_wan_rules_with_disabled_or_deleted_intf(settings)

        for policy_chain in policy_chains:
            # check properties are valid
            if policy_chain.get("rules") is None:
                raise SettingsException(message="api_policy_missing_rules_wan_settings")
            for rule in policy_chain.get("rules"):
                action = rule.get("action")
                if rule.get("enabled") is not True:
                    if action is not None:
                        invalid_items.update(
                            self.create_invalid_rule_interface_items(
                                action,
                                rule,
                                settings,
                                invalid_items,
                                possible_invalid_items,
                                wan_rule_with_disabled_intf,
                            )
                        )
                    continue
                rule_id = rule.get("ruleId")
                if rule_id is None:
                    raise SettingsException(message="api_wan_rule_missing_id")
                if action is None:
                    raise SettingsException(
                        message="api_wan_rule_missing_action", vars=[str(rule_id)]
                    )
                if rule.get("enabled") is None:
                    raise SettingsException(
                        message="api_wan_rule_missing_enabled", vars=[str(rule_id)]
                    )
                if action.get("type") is None:
                    raise SettingsException(
                        message="api_wan_rule_missing_action_type", vars=[str(rule_id)]
                    )
                if action.get("policy") and not existing_policies.get(action.get("policy")):
                    invalid_items.update(
                        self.create_invalid_items(
                            rule,
                            action.get("policy"),
                            rule_id,
                            "rule",
                            rule.get("description", ""),
                            action.get("policy"),
                            "policy",
                            "",
                            possible_invalid_items,
                            wan_rule_with_disabled_intf,
                        )
                    )

                invalid_items.update(
                    self.create_invalid_rule_interface_items(
                        action,
                        rule,
                        settings,
                        invalid_items,
                        possible_invalid_items,
                        wan_rule_with_disabled_intf,
                    )
                )

        return invalid_items

    def create_invalid_rule_interface_items(
        self,
        action,
        rule,
        settings,
        curr_invalid_items,
        possible_invalid_items,
        wan_rule_with_disabled_intf,
    ):
        """create invalid items based on wan-rules/interface groupings"""
        invalid_items = {}

        # check wan policies are valid
        if action.get("type") == "WAN_POLICY":
            # if wan rule is enabled but associated WAN Interface is disabled, add to invalid_items list
            intf_id = wan_rule_with_disabled_intf.get(rule["ruleId"], -1)
            if intf_id != -1 and rule["enabled"]:
                intf = network_util.get_interface_by_id(settings, intf_id)
                rule_description = rule.get("description")
                if "readOnly" in rule and rule.get("readOnly") is True:
                    rule_description = f"{rule_description} (system created)"
                invalid_items.update(
                    self.create_invalid_items(
                        rule,
                        intf,
                        rule.get("ruleId"),
                        "rule",
                        rule_description,
                        str(intf_id),
                        "interface",
                        str(network_util.get_interface_name_confirm(settings, intf_id)),
                        curr_invalid_items,
                        possible_invalid_items,
                    )
                )
        return invalid_items

    def create_invalid_policy_interface_items(
        self, policy, interfaces, settings, possible_invalid_items, force_add_policy=False
    ):
        """create invalid items based on policy/interface groupings"""
        invalid_items = {}

        # loop through a policy's interfaces
        for interface in interfaces:
            # get interface information
            interface_id = interface.get("interfaceId")
            intf = network_util.get_interface_by_id(settings, interface_id)
            interface_id_key = str(interface_id)

            # if the policy is enabled, or we're adding all possible invalid items
            # and it's not the main wan
            # and the interface is disabled/deleted
            # add to invalid_items
            if interface.get("interfaceId") != 0 and (intf is None or force_add_policy):
                invalid_items.update(
                    self.create_invalid_items(
                        policy,
                        intf,
                        policy.get("policyId"),
                        "policy",
                        policy.get("description"),
                        interface_id_key,
                        "interface",
                        str(network_util.get_interface_name_confirm(settings, interface_id)),
                        possible_invalid_items,
                    )
                )
        return invalid_items

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")

        wans = []
        # interfaces = settings_file.settings.get('network').get('interfaces')
        interfaces = settings_file.settings.get("network", {}).get("interfaces", [])
        for intf in interfaces:
            if network_util.enabled_wan(intf):
                wans.append(intf.get("interfaceId"))

        settings_file.settings["wan"] = {}

        lowestLatencyWanPolicyId = uuid4().__str__()
        settings_file.settings["wan"]["policy_chains"] = [
            {
                "default": True,
                "description": "User defined wan routing rules",
                "name": "user-wan-rules",
                "rules": [
                    {
                        "action": {"policy": lowestLatencyWanPolicyId, "type": "WAN_POLICY"},
                        "conditions": [],
                        "description": "Send all traffic to wan policy 1",
                        "enabled": True,
                        "ruleId": uuid4().__str__(),
                    }
                ],
            }
        ]
        settings_file.settings["wan"]["policies"] = [
            {
                "best_of_metric": "LOWEST_LATENCY",
                "criteria": [],
                "description": "Lowest Latency WAN",
                "interfaces": [{"interfaceId": 0}],
                "type": "BEST_OF",
                "policyId": lowestLatencyWanPolicyId,
            },
            {
                "best_of_metric": "HIGHEST_AVAILABLE_BANDWIDTH",
                "criteria": [],
                "description": "Highest Available Bandwidth WAN",
                "interfaces": [{"interfaceId": 0}],
                "type": "BEST_OF",
                "policyId": uuid4().__str__(),
            },
            {
                "balance_algorithm": "AVAILABLE_BANDWIDTH",
                "criteria": [],
                "description": "Balance by Bandwidth Available",
                "interfaces": [{"interfaceId": 0}],
                "type": "BALANCE",
                "policyId": uuid4().__str__(),
            },
            {
                "balance_algorithm": "BANDWIDTH",
                "criteria": [],
                "description": "Balance by Bandwidth",
                "interfaces": [{"interfaceId": 0}],
                "type": "BALANCE",
                "policyId": uuid4().__str__(),
            },
        ]

    def delete_wan_routing_config_file(self, file_path, run_nft_cmd=True) -> None:
        """It regains the permissions and deletes the configuration file /etc/config/nft-wan-routing/102-wan-routing
        During execution of sync-settings method, the configuration file gets created in temporary directory which was passed using the parameter prefix.
        Later it will be compared against the original file. If differences exist, it will be replaced and corresponding operation gets triggered.
        During boot of MFW, the init script /etc/init.d/nftables-rules executes the nftables scripts from /etc/config/nftables-rules.d/
        Since 102-wan-routing is moved from this directory as a fix for MFW-6037, during reboot of MFW wan-routing[nft list table ip wan-routing] is not present.
        To solve it, during reboot of MFW, it will check if the table is present. If not the file /etc/config/nft-wan-routing/102-wan-routing will be deleted.
        So sync-settings method recreates this file which triggers the corresponding operation.
        In this way, it is made sure that the table gets created during reboot.

        During upgrade of MFW, this method is used remove the old file at /etc/config/nftables-rules.d/. For this, the command "nft list table ip wan-routing" is not needed.
        so run_nft_cmd is passed as False.
        """
        try:
            with regain_permissions():
                if run_nft_cmd:
                    result = subprocess.run(
                        ["nft", "list", "table", "ip", "wan-routing"],
                        capture_output=True,
                        check=False,
                    )
                    if result.returncode == 0:
                        return

                if os.path.exists(file_path):
                    os.unlink(file_path)
        except Exception:
            logger.exception("Failed to delete dos configuration file:")

    def clean_brightcloud_ip(self, file_path):
        ip_address = "172.217.4.110"
        try:
            # Check if the IP address 172.217.4.110/32 exists on the loopback interface
            result = subprocess.run(
                ["ip", "addr", "show", "dev", "lo"], capture_output=True, text=True, check=False
            )
            if ip_address in result.stdout:
                subprocess.run(["ip", "addr", "del", f"{ip_address}/32", "dev", "lo"], check=True)
            if os.path.exists(file_path):
                os.unlink(file_path)
        except Exception:
            logger.exception("Failed to delete brightcloud ip file:")

    def policy_exists(self, new_policy, existing_policies):
        """Check if an equivalent policy (excluding policyId) already exists."""
        new_policy_copy = copy.deepcopy(new_policy)
        new_policy_copy.pop("policyId", None)

        for existing in existing_policies:
            existing_copy = copy.deepcopy(existing)
            existing_copy.pop("policyId", None)
            if new_policy_copy == existing_copy:
                return True
        return False


registrar.register_manager(CommonRouteManager())
