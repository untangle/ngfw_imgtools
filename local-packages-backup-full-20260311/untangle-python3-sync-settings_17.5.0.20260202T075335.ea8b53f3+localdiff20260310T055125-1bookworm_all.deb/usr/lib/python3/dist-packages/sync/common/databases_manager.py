"""This class is responsible for writing the database settings."""

import json
from uuid import uuid4

from sync import EncryptionUtil, Manager, registrar
from sync.common import Logger
from sync.file_util import FileUtil
from sync.settings_exception import SettingsException

databases_default_settings = [
    {
        "db_connection_string": "sqlite:///tmp/reports.db",
        "db_name": "/tmp/reports.db",  # noqa: S108
        "description": "Local reports database",
        "enabled": True,
        "id": uuid4().__str__(),
        "name": "Local DB",
        "type": "sqlite",
        "default": True,
    }
]

logger = Logger.getInstance()


class DatabasesManager(Manager):
    """DatabasesManager manages the database settings."""

    uid_path = FileUtil.locate_file("/etc/config/uid")

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)

    def validate_settings(self, settings_file) -> None:
        """Validate database settings."""
        database_settings = settings_file.settings.get("databases")
        defaults_count = 0
        for db in database_settings:
            self.validate_database_settings(db)
            if db.get("default", False):
                defaults_count += 1
        if defaults_count > 1:
            raise SettingsException(message="database_error_default_count", vars=[])
        self.validate_unique_connection(database_settings)

    def validate_unique_connection(self, database_settings) -> None:
        # Checks if another database connection already exists for the provided details
        existing_db_conn = set()
        for database in database_settings:
            if database["type"] == "sqlite":
                key = database["db_name"]
            else:
                key = database["db_server"] + str(database["db_port"])
            if key in existing_db_conn:
                raise SettingsException(
                    message="database_connection_not_unique", vars=[database["name"]]
                )
            existing_db_conn.add(key)

    def validate_database_settings(self, parameters) -> None:
        # Null checks and type checks for settings
        self.validate_parameter(parameters, "enabled", bool)
        self.validate_parameter(parameters, "db_name", str)
        if parameters.get("type", "") != "sqlite":
            self.validate_parameter(parameters, "db_username", str)
            self.validate_parameter(parameters, "db_password_encrypted", str)
            self.validate_parameter(parameters, "db_server", str)
            self.validate_parameter(parameters, "db_port", int)
        self.validate_parameter(parameters, "description", str)
        self.validate_parameter(parameters, "name", str)
        self.validate_parameter(parameters, "type", str)

    def validate_parameter(self, parameters, parameter_name, parameter_type) -> None:
        """validates parameters"""
        parameter_value = parameters[parameter_name]
        if parameter_value is None or not isinstance(parameter_value, parameter_type):
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["database", parameter_name]
            )

        if parameter_name == "type" and parameter_value not in ["mysql", "sqlite", "postgres"]:
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["database", parameter_name]
            )

    def sanitize_settings(self, settings_file) -> None:
        """Sanitize system settings."""
        if settings_file.settings.get("databases") is None:
            settings_file.settings["databases"] = databases_default_settings

        for database in settings_file.settings["databases"]:
            # Encrypt passwords using the new mechanism
            if database.get("db_password"):
                try:
                    encrypted_password = EncryptionUtil.execute_password_manager(
                        "-e", database.get("db_password")
                    )

                    # Update the database entry
                    database["db_password_encrypted"] = encrypted_password
                    # Update db_connection_string if necessary
                    if database.get("db_connection_string"):
                        database["db_connection_string"] = database[
                            "db_connection_string"
                        ].replace(database["db_password"], database["db_password_encrypted"])
                    del database["db_password"]
                except RuntimeError:
                    raise Exception(json.dumps({"error": "password_manager_failure"}))

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """Creates settings."""
        logger.info("Initializing settings")
        settings_file.settings["databases"] = databases_default_settings

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """Syncs settings."""


registrar.register_manager(DatabasesManager())
