class Creator:
    def create(self, object) -> None:
        """
        create returns the configuration object.
        """
