#!/usr/bin/env python3
# Copyright (c) 2025 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.

CRON_D_DIR = "/etc/cron.d/"
USR_BIN_DIR = "/usr/bin/"
LOG_DIR = "/var/log/"
