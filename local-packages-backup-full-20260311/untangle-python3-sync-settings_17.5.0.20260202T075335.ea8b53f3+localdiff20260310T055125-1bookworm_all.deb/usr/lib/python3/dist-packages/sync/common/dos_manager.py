from sync import Manager
from sync.common import Logger
from sync.file_util import FileUtil
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

DENIAL_OF_SERVICE = "denial_of_service"
DELETE_ACTIVE_SESSIONS_SETTINGS_PATH = "/tmp/dos/active_session"
LIMIT_VALUES_SETTINGS_PATH = "/tmp/dos/dos_settings"

logger = Logger.getInstance()


class DosManager(Manager):
    """Creates default settings for DOS"""

    dos_default_settings = {
        "enabled": True,
        "source_sessions_max_tcp": 5000,
        "source_sessions_max_udp": 5000,
        "source_sessions_max_icmp": 300,
        "source_sessions_max_all": 5000,
        "dest_sessions_max_tcp": 5000,
        "dest_sessions_max_udp": 5000,
        "dest_sessions_max_icmp": 1000,
        "dest_sessions_max_all": 5000,
        "new_sessions_per_second_tcp": 2000,
        "new_sessions_per_second_udp": 2000,
        "new_sessions_per_second_icmp": 250,
        "block_duration": 300,
        "remove_active_sessions": True,
    }

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Creating settings")
        settings_file.settings[DENIAL_OF_SERVICE] = self.dos_default_settings

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """sanitizes DOS settings"""
        logger.info("Sanitize settings")
        dos_settings = settings_file.settings.get(DENIAL_OF_SERVICE)

        # missing dos settings
        if dos_settings is None:
            settings_file.settings[DENIAL_OF_SERVICE] = self.dos_default_settings
        # upgrades to 6.2 - moves dos_settings backup file from /etc/config to /tmp
        if settings_file.settings.get("version") <= 5:
            for file_path in [DELETE_ACTIVE_SESSIONS_SETTINGS_PATH, LIMIT_VALUES_SETTINGS_PATH]:
                FileUtil.move_write_only_registered_files_to_tmp(file_path)

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates DOS settings"""
        logger.info("Validate settings")
        dos_settings = settings_file.settings.get(DENIAL_OF_SERVICE)
        # Missing denial_of_service settings
        if dos_settings is None:
            raise SettingsException(message_str="Missing DOS settings")
        self.validate_parameters(dos_settings)

    def validate_parameters(self, data) -> None:
        """validates parameters"""

        self.validate_parameter(data, "block_duration", [int, float], (0, 86400))
        self.validate_parameter(data, "enabled", [bool])
        self.validate_parameter(data, "remove_active_sessions", [bool])

        # Check for protocol keys and validate their values
        protocols = {
            "source_sessions_max_tcp",
            "source_sessions_max_udp",
            "source_sessions_max_icmp",
            "source_sessions_max_all",
            "dest_sessions_max_tcp",
            "dest_sessions_max_udp",
            "dest_sessions_max_icmp",
            "dest_sessions_max_all",
            "new_sessions_per_second_tcp",
            "new_sessions_per_second_udp",
            "new_sessions_per_second_icmp",
        }

        for key in protocols:
            if key in data:
                self.validate_parameter(data, key, [int, float], (0, 100000))

    def validate_parameter(self, parameters, parameter_name, parameter_types, limits=None) -> None:
        """Validates parameters for type and limits."""
        parameter_value = parameters.get(parameter_name)

        # Check if the parameter is missing or not of the correct type
        if parameter_value is None or not any(
            isinstance(parameter_value, type) for type in parameter_types
        ):
            raise SettingsException(
                message="missing_or_invalid_parameter_value",
                vars=["denial of service", parameter_name],
            )

        # Check limits are valid if provided
        if limits is not None:
            min_limit, max_limit = limits
            if not (min_limit <= parameter_value <= max_limit):
                raise SettingsException(
                    message="missing_or_invalid_parameter_value",
                    vars=["denial of service", parameter_name],
                )
