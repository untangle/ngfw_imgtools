"""This class is responsible for managing captive portal settings"""

import copy
import json
import os

from sync import Manager, nftables_util, registrar
from sync.common import Logger
from sync.common.creators.captive_portal_creator import CaptivePortalCreator
from sync.file_util import FileUtil
from sync.network_util import get_local_interfaces
from sync.perms_util import regain_permissions
from sync.settings_exception import SettingsException

from .const import MFW_CONFIG_CAPTIVEPORTAL

CAPTIVE_PORTAL_IMAGE_FILE_PATH = "/etc/config/captive_portal/"
CAPTIVE_PORTAL_SETTINGS_FILE_PATH = "/etc/config/captive_portal/captive_portal_settings"

logger = Logger.getInstance()


class CaptivePortalManager(Manager):
    """CaptivePortalManager manages the captive portal settings"""

    captive_portal_minimum_timeout_value = 1
    captive_portal_timeout_period_options = ["d", "h", "m"]

    def __init__(self) -> None:
        super().__init__(CaptivePortalCreator(), None, None)
        self.captive_portal_image_file_path = FileUtil.locate_file(CAPTIVE_PORTAL_IMAGE_FILE_PATH)
        self.captive_portal_settings_file_path = FileUtil.locate_file(
            CAPTIVE_PORTAL_SETTINGS_FILE_PATH
        )

    def initialize(self) -> None:
        """initialize this module"""

        registrar.register_settings_file("settings", self)
        registrar.register_file(
            self.captive_portal_settings_file_path, "restart-restd-captive-portal", self
        )
        registrar.register_file(
            self.captive_portal_image_file_path + "*", "restart-restd-captive-portal", self
        )

    def validate_settings(self, settings_file) -> None:
        """validates settings"""
        self.captive_portal_settings = settings_file.settings.get("captiveportal")
        # Missing captive_portal settings
        if self.captive_portal_settings is None:
            raise SettingsException(message_str="Missing captive portal settings")

        # Null checks and type checks for settings
        self.validate_parameter("enabled", bool)
        self.validate_parameter("acceptText", str)
        self.validate_parameter("acceptButtonText", str)
        self.validate_parameter("messageHeading", str)
        self.validate_parameter("messageText", str)
        self.validate_parameter("welcomeText", str)
        self.validate_parameter("timeoutValue", int)
        self.validate_parameter("timeoutPeriod", str)
        self.validate_parameter("pageTitle", str)
        self.validate_parameter("rules", list)

        # Validate rules property if exist
        if self.captive_portal_settings.get("rules"):
            self.validate_rules()

    def validate_parameter(self, parameter_name, parameter_type, base_key=None) -> None:
        """validates parameters"""
        parameters = self.captive_portal_settings
        if base_key:
            parameters = self.captive_portal_settings[base_key]
        parameter_value = parameters[parameter_name]
        if parameter_value is None or not isinstance(parameter_value, parameter_type):
            raise SettingsException(
                message="missing_or_invalid_parameter_value",
                vars=["captive portal", parameter_name],
            )
        if (
            parameter_name == "timeoutValue"
            and parameter_value < self.captive_portal_minimum_timeout_value
        ):
            raise SettingsException(
                message="minimum_parameter_value",
                vars=["timeoutValue", self.captive_portal_minimum_timeout_value],
            )
        if (
            parameter_name == "timeoutPeriod"
            and parameter_value not in self.captive_portal_timeout_period_options
        ):
            raise SettingsException(
                message="missing_or_invalid_parameter_value",
                vars=["captive portal", parameter_name],
            )

    # method for validating the `rules` part of the config
    # skip the items that do not have the minimum required fields
    def validate_rules(self) -> None:
        required_fields = {"action", "conditions", "description"}
        condition_properties = {"type", "value", "op"}
        condition_fields = [
            "DESTINATION_ADDRESS",
            "DESTINATION_ADDRESS_V6",
            "DESTINATION_INTERFACE_TYPE",
            "DESTINATION_PORT",
            "SOURCE_ADDRESS",
            "SOURCE_ADDRESS_V6",
            "SOURCE_INTERFACE_TYPE",
            "SOURCE_INTERFACE_ZONE",
            "SOURCE_PORT",
            "IP_PROTOCOL",
        ]
        condition_operators = ["==", "!="]
        actions = ["ENABLE", "DISABLE"]

        for item in self.captive_portal_settings["rules"]:
            if not isinstance(item, dict):
                raise SettingsException(
                    message="missing_or_invalid_parameter_value", vars=["captive portal", "rules"]
                )
            cp_rule_copy = copy.deepcopy(item)

            missing_fields = required_fields - set(cp_rule_copy)
            if bool(missing_fields):
                raise SettingsException(
                    message="missing_or_invalid_rule_property",
                    vars=["captive portal", next(iter(missing_fields))],
                )

            if isinstance(cp_rule_copy["action"], dict):
                if cp_rule_copy["action"]["type"] not in actions:
                    raise SettingsException(
                        message="invalid_action_type", vars=[cp_rule_copy["action"]["type"]]
                    )

            if type(cp_rule_copy["conditions"]) != list:
                raise SettingsException(
                    message="missing_or_invalid_rule_property",
                    vars=["captive portal", "conditions"],
                )

            for condition in cp_rule_copy["conditions"]:
                missing_conditions = condition_properties - set(condition)
                if bool(missing_conditions):
                    raise SettingsException(
                        message="missing_rule_condition_filed",
                        vars=[next(iter(missing_conditions))],
                    )
                if condition["type"] not in condition_fields:
                    raise SettingsException(
                        message="invalid_condition_field", vars=["type", condition["type"]]
                    )
                if condition["op"] not in condition_operators:
                    raise SettingsException(
                        message="invalid_condition_field", vars=["operation", condition["op"]]
                    )
                if condition["value"] is None:
                    raise SettingsException(
                        message="invalid_condition_field", vars=["value", condition["value"]]
                    )

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        self.write_settings_file(settings_file, prefix)

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        self.settings_data = settings_file.settings.get("captiveportal")
        if self.settings_data is None:
            self.creator.create(settings_file)
            self.settings_data = settings_file.settings["captiveportal"]
        nftables_util.verify_guid(self.settings_data["rules"], "ruleId", relatedChains=None)
        self.sanitize_rules()

    def sanitize_rules(self) -> None:
        """
        FOR UPGRADE CASES ONLY
        Check if the IP_PROTOCOL condition exists and type is string, then convert it to an array
        """
        for rule in self.settings_data["rules"]:
            for condition in rule["conditions"]:
                if condition["type"] == "IP_PROTOCOL" and type(condition["value"]) == str:
                    condition["value"] = condition["value"].split(",")

    def write_settings_file(self, settings_file, prefix) -> None:
        """writes the settings to specified filepath"""
        settings_data = {}
        # Writes captive portal settings to file
        filename = prefix + self.captive_portal_settings_file_path
        settings_data["captive_portal"] = settings_file.settings.get("captiveportal")

        # If captive portal settings are not enabled, delete the settings and
        # unregister any operations related to captive portal
        if not settings_data.get("captive_portal", {}).get("enabled"):
            registrar.unregister_file(filename)
            registrar.unregister_file(self.captive_portal_image_file_path + "*")
            if os.path.exists(self.captive_portal_settings_file_path):
                try:
                    with regain_permissions():
                        os.unlink(self.captive_portal_settings_file_path)
                except Exception:
                    logger.exception("Failed to delete captive portal settings file:")
            return

        # Writes redirection IPs to file
        cp_redirection_ips = get_local_interfaces(settings_file.settings)
        settings_data["redirection_ips"] = cp_redirection_ips

        # Writes redirection host to file
        system_settings = settings_file.settings.get("system")
        settings_data["redirection_host"] = (
            system_settings["hostName"] + "." + (system_settings["domainName"] or "")
        )
        self.write_file(filename, json.dumps(settings_data).encode("utf-8"))

    def write_file(self, filename, data) -> None:
        """writes data to specified file"""
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "wb+")
        file.write(data)
        file.flush()
        file.close()
        logger.info("Wrote %s", str(filename))


def do_captive_portal_settings_exist(settings: dict) -> bool:
    """check if captive portal settings are enabled in any policy or
    the regular service config"""
    if settings.get("captiveportal", {}).get("enabled", False):
        return True
    return any(
        i.get("settings", {}).get("enabled")
        for i in get_policy_settings_for_plugin(MFW_CONFIG_CAPTIVEPORTAL, settings)
    )


def get_policy_settings_for_plugin(plugin_type, settings_file) -> list:
    """get all settings for plugin plugin-type (probably
    mfw-config-XXX) that policy manager knows about."""
    return [
        i
        for i in (settings_file.get("policy_manager", {}).get("configurations", []))
        if i.get("type") == plugin_type
    ]


registrar.register_manager(CaptivePortalManager())
