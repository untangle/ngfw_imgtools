"""This class is responsible for sanitizing IPsec configuration"""

from __future__ import annotations

import json
from typing import Any

from sync.common import Logger
from sync.common.sanitizers.base_sanitizer import Sanitizer
from sync.encryption_util import EncryptionUtil

logger = Logger.getInstance()


class IpsecSanitizer(Sanitizer):
    """Handles sanitization of IPsec shared secrets by encrypting them"""

    @staticmethod
    def encrypt_shared_secret(auth_config: dict[str, Any]) -> None:
        """
        Encrypts the shared_secret field in an IPsec authentication configuration.

        This function:
        1. Checks if a plaintext shared_secret exists
        2. Encrypts it using EncryptionUtil
        3. Stores the encrypted value in shared_secret_encrypted
        4. Deletes the plaintext shared_secret field

        :param auth_config: The authentication configuration dictionary
        :raises Exception: If password manager encryption fails
        """
        if auth_config.get("shared_secret"):
            try:
                encrypted_secret = EncryptionUtil.execute_password_manager(
                    "-e", auth_config.get("shared_secret")
                )
                auth_config["shared_secret_encrypted"] = encrypted_secret
                del auth_config["shared_secret"]
                logger.debug("Successfully encrypted IPsec shared secret")
            except RuntimeError:
                logger.error("Failed to encrypt IPsec shared secret")
                raise Exception(json.dumps({"error": "password_manager_failure"}))

    @staticmethod
    def decrypt_shared_secret(auth_config: dict[str, Any], default: str = "secret") -> str:
        """
        Decrypts the shared_secret_encrypted field in an IPsec authentication configuration.

        This function:
        1. Checks if shared_secret_encrypted exists
        2. Decrypts it using EncryptionUtil and returns the plaintext
        3. Falls back to the default value if no encrypted secret exists

        :param auth_config: The authentication configuration dictionary
        :param default: Default value to return if no encrypted secret exists
        :return: The decrypted shared secret (plaintext)
        """
        shared_secret_encrypted = auth_config.get("shared_secret_encrypted")

        if shared_secret_encrypted:
            try:
                plaintext_secret = EncryptionUtil.execute_password_manager(
                    "-d", shared_secret_encrypted
                )
                logger.debug("Successfully decrypted IPsec shared secret")
                return plaintext_secret
            except RuntimeError:
                logger.error("Failed to decrypt IPsec shared secret, using default")
                return default
        else:
            # Fallback for legacy configs without encryption or during migration
            plaintext_secret = auth_config.get("shared_secret", default)
            if plaintext_secret != default:
                logger.warning(
                    "Found unencrypted shared_secret in IPsec config - should be encrypted"
                )
            return plaintext_secret

    @staticmethod
    def sanitize_ipsec_interface(interface: dict[str, Any]) -> None:
        """
        Sanitizes a single IPsec interface configuration by encrypting its shared secret.

        :param interface: The interface configuration dictionary
        """
        if interface.get("type") == "IPSEC":
            ipsec_config = interface.get("ipsec", {})
            auth_config = ipsec_config.get("authentication", {})
            IpsecSanitizer.encrypt_shared_secret(auth_config)
