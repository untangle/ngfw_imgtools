class Condition:
    """
    Represents an nftable's rule condition
    """

    # membership_check_for_set new attribute is Name of the nft set for which we are checking the membership of a particular element
    def __init__(
        self,
        type,
        op,
        value,
        port_protocol=None,
        rate_unit=None,
        burst_unit=None,
        mask_value=None,
        membership_check_for_set=None,
    ) -> None:
        self.type = type
        self.op = op
        self.value = value
        self.port_protocol = port_protocol
        self.rate_unit = rate_unit
        self.burst_unit = burst_unit
        self.mask_value = mask_value
        self.membership_check_for_set = membership_check_for_set

    def get_json(self):
        """Creates a condition for a rule"""
        json = {"type": self.type, "op": self.op, "value": self.value}

        if self.port_protocol:
            json["port_protocol"] = self.port_protocol

        if self.rate_unit:
            json["rate_unit"] = self.rate_unit

        if self.burst_unit:
            json["burst_unit"] = self.burst_unit

        if self.mask_value:
            json["mask_value"] = self.mask_value

        if self.membership_check_for_set:
            json["membership_check_for_set"] = self.membership_check_for_set

        return json


class Action:
    """
    Represents an nftable's rule's actions
    """

    def __init__(
        self,
        type,
        dnat_address=None,
        dnat_port=None,
        snat_address=None,
        chain=None,
        priority=None,
        limit_exceed_action=None,
        return_action=None,
    ) -> None:
        self.type = type
        self.dnat_address = dnat_address
        self.dnat_port = dnat_port
        self.snat_address = snat_address
        self.chain = chain
        self.priority = priority
        self.limit_exceed_action = limit_exceed_action
        self.return_action = return_action

    def get_json(self):
        json = {"type": self.type}

        if self.dnat_address:
            json["dnat_address"] = self.dnat_address

        if self.dnat_port:
            json["dnat_port"] = self.dnat_port

        if self.snat_address:
            json["snat_address"] = self.snat_address

        if self.chain:
            json["chain"] = self.chain

        # Priority can be 0
        if self.priority is not None:
            json["priority"] = self.priority

        if self.limit_exceed_action:
            json["limit_exceed_action"] = self.limit_exceed_action

        if self.return_action is True:
            json["return_action"] = self.return_action

        return json


class Set:
    """
    Represents an nftables' set
    """

    def __init__(self, name, type, size=None, dynamic=None, timeout=None) -> None:
        self.name = name
        self.type = type
        # When you want "flags dynamic, timeout" with some timeout period,
        # set that timeout period to this timeout attribute.
        self.timeout = timeout
        # When you want flags as only dynamic i.e. "flags dynamic", set dynamic as True
        self.dynamic = dynamic
        # Size limit of the nftable set
        self.size = size

    def get_json(self):
        "Creates a set"
        json = {
            "name": self.name,
            "type": self.type,
        }
        if self.timeout:
            json["timeout"] = self.timeout
        if self.dynamic:
            json["dynamic"] = self.dynamic
        if self.size:
            json["size"] = self.size
        return json


class AddToSet:
    """"""

    def __init__(self, set_name, elements, ct_count=None, ct_count_operator=None) -> None:
        self.set_name = set_name
        self.elements = elements
        self.ct_count = ct_count
        self.ct_count_operator = ct_count_operator

    def get_json(self):
        add_to_set_json = {
            "set_name": self.set_name,
            "elements": self.elements,
        }

        if self.ct_count:
            add_to_set_json["ct_count"] = self.ct_count
        if self.ct_count_operator:
            add_to_set_json["ct_count_operator"] = self.ct_count_operator

        return add_to_set_json


class Rule:
    """
    Represents an nftables's rule
    """

    def __init__(
        self,
        enabled,
        description,
        rule_id,
        conditions,
        action,
        logs=None,
        add_to_set=None,
        log=False,
    ) -> None:
        self.enabled = enabled
        self.description = description
        self.rule_id = rule_id
        self.conditions = conditions
        self.action = action
        self.logs = logs
        self.add_to_set = add_to_set
        self.log = log

    def get_json(self):
        rule_json = {
            "enabled": self.enabled,
            "description": self.description,
            "ruleId": self.rule_id,
            "conditions": [condition.get_json() for condition in self.conditions],
            "action": self.action.get_json(),
        }
        if self.logs:
            rule_json["logs"] = [log.get_json() for log in self.logs] if self.logs else []
        if self.add_to_set:
            rule_json["add_to_set"] = (
                [add_to_set.get_json() for add_to_set in self.add_to_set]
                if self.add_to_set
                else []
            )
        return rule_json


class Log:
    def __init__(self, type, prefix=None, field=None, value=None, field_type=None) -> None:
        self.type = type
        self.prefix = prefix
        self.field = field
        self.value = value
        self.field_type = field_type

    def get_json(self):
        log_json = {
            "type": self.type,
        }
        if self.prefix:
            log_json["prefix"] = self.prefix
        if self.field:
            log_json["field"] = self.field
        if self.value:
            log_json["value"] = self.value
        if self.field_type:
            log_json["field_type"] = self.field_type
        return log_json


class RuleChain:
    """
    Represents an nftable's rule chain
    """

    def __init__(
        self,
        name,
        description,
        rules,
        default=None,
        type=None,
        base=None,
        hook=None,
        priority=None,
    ) -> None:
        self.name = name
        self.description = description
        self.base = base
        self.hook = hook
        self.priority = priority
        self.rules = rules
        self.type = type
        self.default = default

    def get_json(self):
        """Creates rule chain"""
        json = {
            "name": self.name,
            "description": self.description,
            "rules": [rule.get_json() for rule in self.rules],
        }

        if self.type:
            json["type"] = self.type

        if self.default:
            json["default"] = self.default

        if self.base:
            json["base"] = self.base

        if self.hook:
            json["hook"] = self.hook

        if self.priority is not None:
            json["priority"] = self.priority

        return json


class Table:
    """
    Represents an nftable's table
    """

    def __init__(self, name, family, chains, chain_type=None, sets=None) -> None:
        self.name = name
        self.family = family
        self.chains = chains
        self.chain_type = chain_type
        self.sets = sets

    def get_json(self):
        """Creates a table"""
        json = {
            "name": self.name,
            "family": self.family,
            "chains": [chain.get_json() for chain in self.chains],
        }

        if self.chain_type:
            json["chain_type"] = self.chain_type

        if self.sets:
            json["sets"] = [tableset.get_json() for tableset in self.sets]

        return json
