"""This class is responsible for managing alert settings"""

import json
import os

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

ALERT_SETTINGS_FILE_PATH = "/tmp/alert/alert_settings"  # noqa: S108
logger = Logger.getInstance()

alerts_default_settings = [
    {"message": "ALERT_LOGIN_FAILED", "enabled": True},
    {"message": "ALERT_LOGIN_SUCCESS", "enabled": True},
    {"message": "THREATPREVENTION_SESSION_BLOCKED", "enabled": True},
    {"message": "THREATPREVENTION_SESSION_REDIRECTED", "enabled": True},
    {"message": "WEBFILTER_BLOCK_SESSION", "enabled": True},
    {"message": "WEBFILTER_ALERT_SESSION", "enabled": True},
    {"message": "WEBFILTER_REJECT_SESSION", "enabled": True},
    {"message": "GEOIP_ALERTED_SESSION", "enabled": True},
    {"message": "GEOIP_BLOCKED_SESSION", "enabled": True},
    {"message": "GEOIP_REJECTED_SESSION", "enabled": True},
    {"message": "ALERT_NEW_DEVICE_DISCOVERED", "enabled": True},
    {"message": "INTERFACE_OFFLINE", "enabled": True},
    {"message": "SYSUPGRADE_FAILED", "enabled": True},
    {"message": "UPGRADE_FAILED", "enabled": True},
    {"message": "EXPORT_SETTINGS_FAILED", "enabled": True},
    {"message": "APPLICATIONCONTROL_SESSION_BLOCKED", "enabled": True},
    {"message": "APPLICATIONCONTROL_SESSION_ALERTED", "enabled": True},
    {"message": "APPLICATIONCONTROL_SESSION_REJECTED", "enabled": True},
    {"message": "CAPTIVEPORTAL_SESSION_REDIRECTED", "enabled": True},
    {"message": "CAPTIVEPORTAL_SESSION_BLOCKED", "enabled": True},
    {"message": "DNSFILTER_ALERT_SESSION", "enabled": True},
    {"message": "DNSFILTER_BLOCK_SESSION", "enabled": True},
    {"message": "DNSFILTER_REJECT_SESSION", "enabled": True},
    {"message": "DYNAMICLISTS_SESSION_BLOCKED", "enabled": True},
    {"message": "DATABASE_STATUS_ONLINE", "enabled": True},
    {"message": "DATABASE_STATUS_OFFLINE", "enabled": True},
    {"message": "DATABASE_SCHEMA_MISMATCH", "enabled": True},
    {"message": "DATABASE_WRITE_FAILED", "enabled": True},
    {"message": "POLICYMANAGER_SESSION_BLOCKED", "enabled": True},
    {"message": "POLICYMANAGER_SESSION_REJECTED", "enabled": True},
    {"message": "DOS_EVENT", "enabled": True},
    {"message": "FILTER_EVENT", "enabled": True},
    {"message": "ACCESS_EVENT", "enabled": True},
    {"message": "SETTINGS_CREATE_SUCCESS", "enabled": True},
    {"message": "SETTINGS_CREATE_FAIL", "enabled": True},
    {"message": "SETTINGS_UPDATE_SUCCESS", "enabled": True},
    {"message": "SETTINGS_UPDATE_FAIL", "enabled": True},
    {"message": "SETTINGS_DELETE_SUCCESS", "enabled": True},
    {"message": "SETTINGS_DELETE_FAIL", "enabled": True},
]


class AlertsManager(Manager):
    """Creates default settings for Alerts"""

    def __init__(self) -> None:
        """Alerts configuration definition file"""
        self.alert_settings_file_path = ALERT_SETTINGS_FILE_PATH

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

        # Registers the alerts configuration file with alertd SIGHUP operation
        registrar.register_file(self.alert_settings_file_path, "restart-reportd-alerts", self)

    def create_settings(
        self, settings_file: SettingsFile, _prefix: str, _delete_list: list[str], _filename: str
    ) -> None:
        """creates settings"""
        logger.info("Create settings")
        settings_file.settings["alerts"] = alerts_default_settings

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """sanitizes Alerts settings"""
        logger.info("Sanitize settings")
        alerts_settings = settings_file.settings.get("alerts")

        # missing alerts settings
        if alerts_settings is None:
            settings_file.settings["alerts"] = alerts_default_settings

    # method for validating top level properties for alerts
    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates Alerts settings"""
        logger.info("Validate settings")
        alerts_settings = settings_file.settings.get("alerts")
        # Missing alerts settings
        if alerts_settings is None:
            raise SettingsException(message_str="Missing Alerts settings")

        # Validating parameter type for the operation
        self.validate_parameter(alerts_settings, "enabled", bool)
        self.validate_parameter(alerts_settings, "message", str)

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, _delete_list: list[str]
    ) -> None:
        """syncs settings"""
        self.write_settings_file(settings_file, prefix)

    def validate_parameter(self, parameters, parameter_name, parameter_type) -> None:
        """validates parameters"""
        for p in parameters:
            """ This checks for these 3 conditions
                1. Parameter (parameter_name) is a part of each alerting configuration
                2. Value of each parameter is not None
                3. Type of that parameter matches the desired type (parameter_type)
            """
            parameter_exists = parameter_name in p
            parameter_is_none = p[parameter_name] is None
            parameter_is_wrong_type = not isinstance(p[parameter_name], parameter_type)

            if not parameter_exists or parameter_is_none or parameter_is_wrong_type:
                raise SettingsException(
                    message="missing_or_invalid_parameter_value", vars=["alerts", parameter_name]
                )

    def write_settings_file(self, settings_file: SettingsFile, prefix: str) -> None:
        """writes the settings to specified filepath"""
        settings_data = {}
        filename = prefix + self.alert_settings_file_path
        settings_data["alerts"] = settings_file.settings.get("alerts")
        self.write_file(filename, json.dumps(settings_data).encode("utf-8"))

    def write_file(self, filename: str, data: str) -> None:
        """writes data to specified file"""
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        with open(filename, "wb+") as file:
            file.write(data)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(AlertsManager())
