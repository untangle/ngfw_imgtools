"""This class is responsible for managing web filter settings"""

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

webfilter_default_settings = {
    "enabled": False,
    "rejectOnMissingCache": True,
    "categories": [
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 11},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 44},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 49},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 56},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 57},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 58},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 59},
        {"enabled": True, "logged": True, "rejected": False, "alerted": True, "id": 67},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 85},
        {"enabled": True, "alerted": True, "rejected": False, "logged": True, "id": 86},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 0},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 1},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 2},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 3},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 4},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 5},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 6},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 7},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 8},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 9},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 10},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 12},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 13},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 14},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 15},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 16},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 17},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 18},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 19},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 20},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 21},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 22},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 23},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 24},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 25},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 26},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 27},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 28},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 29},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 30},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 31},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 32},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 33},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 34},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 35},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 36},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 37},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 38},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 39},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 40},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 41},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 42},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 43},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 45},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 46},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 47},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 48},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 50},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 51},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 52},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 53},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 54},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 55},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 60},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 61},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 62},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 63},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 64},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 65},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 66},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 68},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 69},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 71},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 74},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 75},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 76},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 78},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 79},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 80},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 81},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 82},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 87},
        {"enabled": False, "alerted": False, "rejected": False, "logged": True, "id": 88},
    ],
    "blockList": [],
    "passList": [],
}

logger = Logger.getInstance()


class WebFilterManager(Manager):
    """WebFilterManager manages the web filter settings"""

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["webfilter"] = {}
        settings_file.settings["webfilter"] = webfilter_default_settings

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""

        webfilter_settings = settings_file.settings.get("webfilter")

        # missing webfilter settings
        if webfilter_settings is None:
            settings_file.settings["webfilter"] = {}
            settings_file.settings["webfilter"] = webfilter_default_settings

        # upgrades to 6.1 if settings doesn't have logged property add it
        if webfilter_settings and settings_file.settings.get("version") <= 4:
            for category in webfilter_settings.get("categories"):
                if "logged" not in category:
                    category["logged"] = True
                if "rejected" not in category:
                    category["rejected"] = False
                if "flagged" in category:
                    category["alerted"] = category.pop("flagged")
            for bl in webfilter_settings.get("blockList"):
                if "logged" not in bl:
                    bl["logged"] = True
                if "rejected" not in bl:
                    bl["rejected"] = False
                if "flagged" in bl:
                    bl["alerted"] = bl.pop("flagged")
            for pl in webfilter_settings.get("passList"):
                if "logged" not in pl:
                    pl["logged"] = True
                if "flagged" in pl:
                    pl["alerted"] = category.pop("flagged")

            # if settings miss some of categories, add it
            existing_category_ids = {
                category.get("id")
                for category in webfilter_settings.get("categories", [])
                if category.get("id") is not None
            }
            default_category_ids = {
                category.get("id")
                for category in webfilter_default_settings.get("categories", [])
                if category.get("id") is not None
            }

            missing_ids = default_category_ids - existing_category_ids

            # Add missing categories with default values
            new_categories = []
            for missing_id in missing_ids:
                new_category = {
                    "enabled": False,
                    "alerted": False,
                    "logged": True,
                    "id": missing_id,
                    "rejected": False,
                }
                new_categories.append(new_category)

            webfilter_settings["categories"].extend(new_categories)
        # upgrade to 6.2 add rejectOnMissingCache property
        if "rejectOnMissingCache" not in webfilter_settings:
            webfilter_settings["rejectOnMissingCache"] = True

    def validate_settings(self, settings_file) -> None:
        """validates settings"""

        webfilter_settings = settings_file.settings.get("webfilter")

        # missing webfilter settings
        if webfilter_settings is None:
            raise SettingsException(message_str="Missing Web Filter settings")

        # missing/invalid webfilter "enabled" prop
        webfilter_enabled = webfilter_settings.get("enabled")
        if webfilter_enabled is None or not isinstance(webfilter_enabled, bool):
            raise SettingsException(
                message_str='Missing or invalid required Web Filter setting "enabled"'
            )

        # missing/invalid webfilter "categories" prop
        webfilter_categories = webfilter_settings.get("categories")
        if webfilter_categories is None or not isinstance(webfilter_categories, list):
            raise SettingsException(
                message_str='Missing or invalid required Web Filter setting "categories"'
            )

        # missing/invalid webfilter "blockList" prop
        webfilter_block_list = webfilter_settings.get("blockList")
        if webfilter_block_list is None or not isinstance(webfilter_block_list, list):
            raise SettingsException(
                message_str='Missing or invalid required Web Filter setting "blockList"'
            )

        # missing/invalid webfilter "passList" prop
        webfilter_pass_list = webfilter_settings.get("passList")
        if webfilter_pass_list is None or not isinstance(webfilter_pass_list, list):
            raise SettingsException(
                message_str='Missing or invalid required Web Filter setting "passList"'
            )


registrar.register_manager(WebFilterManager())
