"""This class is responsible for managing geoip filter settings"""

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

geoip_default_settings = {
    "enabled": False,
    "actions": {"block": [], "log": [], "reject": [], "alert": []},
    "passedNetworks": [],
}
logger = Logger.getInstance()


class GeoipManager(Manager):
    """GeoipManager manages the geoip filter settings"""

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["geoip"] = {}
        settings_file.settings["geoip"] = geoip_default_settings

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""

        geoip_settings = settings_file.settings.get("geoip")
        # missing geoip settings
        if geoip_settings is None:
            settings_file.settings["geoip"] = {}
            settings_file.settings["geoip"] = geoip_default_settings

        if settings_file.settings.get("version") <= 4:
            if "actions" not in geoip_settings or not isinstance(geoip_settings["actions"], dict):
                geoip_settings["actions"] = {"block": [], "log": [], "reject": [], "alert": []}
            # Add 'blockedCountries' to the 'block' list inside 'actions' if it exists
            if "blockedCountries" in geoip_settings and isinstance(
                geoip_settings["blockedCountries"], list
            ):
                geoip_settings["actions"]["block"] = geoip_settings.get("blockedCountries", [])
                if geoip_settings.get("enabledLog", False):
                    geoip_settings["actions"]["log"] = geoip_settings.get("blockedCountries", [])
                del geoip_settings["blockedCountries"]

            if "enabledLog" in geoip_settings:
                del geoip_settings["enabledLog"]

    def validate_settings(self, settings_file) -> None:
        """validates settings"""
        self.geoip_settings = settings_file.settings.get("geoip")
        # Missing geoip settings
        if self.geoip_settings is None:
            raise SettingsException(message_str="Missing Geo IP settings")

        # Null checks and type checks for settings
        self.validate_parameter("enabled", bool)
        self.validate_actions("actions", dict)
        self.validate_networks("passedNetworks", list)

    def validate_parameter(self, parameter_name, parameter_type) -> None:
        parameter_value = self.geoip_settings.get(parameter_name)
        if not isinstance(parameter_value, parameter_type):
            raise SettingsException(
                message_str=f"Parameter '{parameter_name}' must be of type '{parameter_type}' "
            )

    def validate_actions(self, parameter_name, parameter_type) -> None:
        # Retrieve actions from settings
        parameter_value = self.geoip_settings.get(parameter_name)

        # Check if actions is a dictionary
        if not isinstance(parameter_value, parameter_type):
            msg = "Actions must be a dictionary."
            raise TypeError(msg)

        # Define the expected keys and their types
        expected_keys = {"block": list, "log": list, "alert": list, "reject": list}

        # Validate each key in the actions dictionary
        for key, expected_type in expected_keys.items():
            if key not in parameter_value:
                raise SettingsException(message_str=f'Missing expected action key:  "{key}"')
            if not isinstance(parameter_value[key], expected_type):
                raise SettingsException(message_str=f"Invalid type for '{key}'")

    def validate_networks(self, parameter_name, parameter_type) -> None:
        parameter_value = self.geoip_settings.get(parameter_name)

        # Check if the parameter exists and is of the correct type
        if not isinstance(parameter_value, parameter_type):
            raise SettingsException(message_str="passedNetworks must be a list.")


registrar.register_manager(GeoipManager())
