from abc import ABC, abstractmethod

from sync import Manager
from sync.common import Logger

logger = Logger.getInstance()


class CommonSystemManager(Manager, ABC):
    """
    Common SystemManager config done in openWRT and MFW in Native EOS
    """

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        self.set_time_zone(settings_file, prefix)
        self.set_host_name(settings_file, prefix)

    @abstractmethod
    def set_time_zone(self, settings_file, prefix):
        pass

    @abstractmethod
    def set_host_name(self, settings_file, prefix):
        pass

    def get_default_system_settings(self):
        """Gets the default system settings."""
        return {
            "hostName": "mfw",
            "domainName": "example.com",
            "timeZone": {
                "displayName": "UTC",
                "value": "UTC",
            },
            "httpPort": "80",
            "httpsPort": "443",
            "cloud": {
                "enabled": True,
                "supportAccessEnabled": True,
                "cloudServers": ["cmd.edge.arista.com"],
            },
            "setupWizard": {"completed": False},
            "autoUpgrade": {
                "dayOfWeek": -1,
                "hourOfDay": -1,
                "minuteOfHour": -1,
                "enabled": True,
            },
            "autoBackup": {
                "dayOfWeek": -1,
                "hourOfDay": -1,
                "minuteOfHour": -1,
                "enabled": True,
            },
        }

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """Creates settings."""
        logger.info("Initializing settings")
        settings_file.settings["system"] = self.get_default_system_settings()

    def sanitize_settings(self, settings_file) -> None:
        if not settings_file.settings.get("system"):
            settings_file.settings["system"] = self.get_default_system_settings()

        http_port = settings_file.get_settings_by_path("system/httpPort")
        if not http_port:
            logger.info("Creating default http port setting")
            http_port = settings_file.settings["system"]["httpPort"] = "80"

        https_port = settings_file.get_settings_by_path("system/httpsPort")
        if not https_port:
            logger.info("Creating default https port setting")
            https_port = settings_file.settings["system"]["httpsPort"] = "443"
