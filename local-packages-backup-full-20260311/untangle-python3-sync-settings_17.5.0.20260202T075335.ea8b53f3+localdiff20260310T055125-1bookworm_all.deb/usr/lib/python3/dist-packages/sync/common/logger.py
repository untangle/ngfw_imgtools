"""Wrapper for logger creation to have a single entry point"""

from __future__ import annotations

import logging
import sys
import time
from typing import TYPE_CHECKING, ClassVar, Literal

if TYPE_CHECKING:
    from collections.abc import Mapping


class Logger:
    _instance = None
    _loggers: ClassVar[Mapping[str, logging.Logger]] = {}

    def __init__(self) -> None:
        msg = "Don't call me directly! Use getInstance() instead"
        raise RuntimeError(msg)

    @classmethod
    def getInstance(cls, name: str | None = None) -> logging.Logger:
        """Return a logger with the specified name, creating it if necessary.

        If no name is specified, return the root logger.

        to log just call
        -> logger.debug(...)
        -> logger.info(...)
        -> logger.warning(...)
        -> logger.error(...)
        -> logger.critical(...)

        For exception, it will print callstack and exception message:
        -> except Exception:
        ->     logger.exception("Exception occurred retrieving rollback setting")"""
        if cls._instance is None:
            cls._instance = cls.__new__(cls)

        if name not in cls._loggers:
            cls._loggers[name] = logging.getLogger(name)
            cls._configLogger(name)
        return cls._loggers[name]

    @classmethod
    def _configLogger(cls, name: str | None = None) -> None:
        """Configs a logger setting formatter, handler(stdout) etc"""

        if cls._instance is None:
            msg = "Call getInstance() before _configLogger(...)"
            raise RuntimeError(msg)

        if name not in cls._loggers:
            msg = "Call getInstance(name) before _configLogger(name)"
            raise RuntimeError(msg)

        cls._loggers[name].setLevel(logging.INFO)

        # for STDOUT
        stream_handler = logging.StreamHandler(stream=sys.stdout)

        # if we wold like PID - %(process)d
        # TID (if available) - %(thread)d
        formatter = logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] [%(filename)s:%(lineno)d] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%SZ",
        )

        # enforce UTC time
        logging.Formatter.converter = time.gmtime
        stream_handler.setFormatter(formatter)

        cls._loggers[name].addHandler(stream_handler)

        # if we need more handlers, like for file etc here is a good place to add then
        # handlers can have different log level filtering

    @classmethod
    def setLogLevel(
        cls,
        logLevel: Literal[
            logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL
        ] = logging.INFO,
        name: str | None = None,
    ) -> None:
        if cls._instance is None:
            msg = "Call getInstance() before _configLogger(...)"
            raise RuntimeError(msg)

        if name not in cls._loggers:
            msg = "Call getInstance(name) before _configLogger(name)"
            raise RuntimeError(msg)

        cls._loggers[name].setLevel(logLevel)
