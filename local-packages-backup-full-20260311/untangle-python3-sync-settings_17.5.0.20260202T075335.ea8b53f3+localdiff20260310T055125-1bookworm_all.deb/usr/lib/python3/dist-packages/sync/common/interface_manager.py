"""This class is responsible for writing interface-marks chains."""

import os
import stat

from sync import Manager, nftables_util, registrar
from sync.common import Logger
from sync.file_util import FileUtil

logger = Logger.getInstance()


class CommonInterfaceManager(Manager):
    """InterfaceManager writes /etc/config/nftables-rules.d/101-interface-
    marks."""

    INTERFACE_MARKS_FILENAME = FileUtil.locate_file(
        "/etc/config/nftables-rules.d/101-interface-marks"
    )

    SRC_INTERFACE_MASK = 0x000000FF
    SRC_INTERFACE_MASK_INVERSE = 0xFFFFFF00
    SRC_INTERFACE_SHIFT = 0
    DST_INTERFACE_MASK = 0x0000FF00
    DST_INTERFACE_MASK_INVERSE = 0xFFFF00FF
    DST_INTERFACE_SHIFT = 8
    CLIENT_INTERFACE_MASK = 0x000000FF
    CLIENT_INTERFACE_MASK_INVERSE = 0xFFFFFF00
    CLIENT_INTERFACE_SHIFT = 0
    SERVER_INTERFACE_MASK = 0x0000FF00
    SERVER_INTERFACE_MASK_INVERSE = 0xFFFF00FF
    SERVER_INTERFACE_SHIFT = 8
    SRC_TYPE_MASK = 0x03000000
    SRC_TYPE_MASK_INVERSE = 0xFCFFFFFF
    SRC_TYPE_SHIFT = 24
    DST_TYPE_MASK = 0x0C000000
    DST_TYPE_MASK_INVERSE = 0xF3FFFFFF
    DST_TYPE_SHIFT = 26
    CLIENT_TYPE_MASK = 0x03000000
    CLIENT_TYPE_MASK_INVERSE = 0xFCFFFFFF
    CLIENT_TYPE_SHIFT = 24
    SERVER_TYPE_MASK = 0x0C000000
    SERVER_TYPE_MASK_INVERSE = 0xF3FFFFFF
    SERVER_TYPE_SHIFT = 26
    ALL_MASK = 0x0FFFFFFF
    LOCAL_INTERFACE_ID = 0xFF  # 255

    # Our rule manager for adding management interface block rule
    mgmt_rule_manager = None

    # For sanitization, use this MTU if none exists.
    DEFAULT_MTU = 1500

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.INTERFACE_MARKS_FILENAME, "restart-nftables-rules", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """Syncs settings."""
        self.write_interface_marks_file(settings_file.settings, prefix)

    def write_interface_marks_file(self, settings, prefix) -> None:
        """write_interface_marks_file writes /etc/config/nftables-
        rules.d/101-interface-marks."""

        filename = prefix + self.INTERFACE_MARKS_FILENAME
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/usr/bin/nft_debug -f")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(
            r"""
add table inet interface-marks
flush table inet interface-marks
add chain inet interface-marks prerouting-interface-marks { type filter hook prerouting priority -150 ; }
add chain inet interface-marks forward-interface-marks { type filter hook forward priority -150 ; }
add chain inet interface-marks postrouting-interface-marks { type filter hook postrouting priority 0 ; }
add chain inet interface-marks input-interface-marks { type filter hook input priority -150 ; }
add chain inet interface-marks restore-interface-marks
add chain inet interface-marks restore-interface-marks-original
add chain inet interface-marks restore-interface-marks-reply
add rule inet interface-marks restore-interface-marks ct direction original jump restore-interface-marks-original
add rule inet interface-marks restore-interface-marks ct direction reply jump restore-interface-marks-reply
add chain inet interface-marks mark-src-interface
add chain inet interface-marks mark-dst-interface
add rule inet interface-marks prerouting-interface-marks jump restore-interface-marks
add rule inet interface-marks prerouting-interface-marks ct state new jump mark-src-interface
add rule inet interface-marks prerouting-interface-marks mark and 0x000000ff == 0 jump mark-src-interface

# If its a new session - we set the mark the dst interface marks regardless of what they were set to before
# often we will set them prerouting to "vote" for a specific interface, but that may not be the actual dst interface
# after the routing table is consulted (it could have been overridden by a local route for example)
# in this case we need to reset the dst interface mark to the correct & actual dst interface mark
add rule inet interface-marks forward-interface-marks ct state new jump mark-dst-interface

# sometimes sessions were created before these rules were in place - still mark these
add rule inet interface-marks postrouting-interface-marks mark and 0x0000ff00 == 0 jump mark-dst-interface
add rule inet interface-marks postrouting-interface-marks ct state new jump mark-dst-interface

"""
        )

        # input-interface-marks doesn't mark broadcast or multicast sessions
        # These sessions have multiple destinations and so setting the dest/server
        # mark to 0xff does not make much sense
        file.write(
            f"add rule inet interface-marks input-interface-marks ct state new fib daddr type != {{ broadcast, multicast }} ct mark set ct mark and 0x{self.SERVER_INTERFACE_MASK_INVERSE:x} or 0x{self.LOCAL_INTERFACE_ID << self.SERVER_INTERFACE_SHIFT:x}\n"
        )
        file.write(
            f"add rule inet interface-marks input-interface-marks mark set mark and 0x{self.DST_INTERFACE_MASK_INVERSE:x} or 0x{self.LOCAL_INTERFACE_ID << self.DST_INTERFACE_SHIFT:x}\n"
        )

        # We don't set/restore marks in output because there is no src/client mark
        # and the dst/server mark is handled in postrouting

        interfaces = settings.get("network").get("interfaces")
        for intf in interfaces:
            if not intf.get("enabled"):
                continue
            # just use the normal interface name
            interface_name = intf.get("netfilterDev")
            if intf.get("management"):
                # maintenance type
                interface_type = nftables_util.INTERFACE_TYPES["management"]
            elif intf.get("wan"):
                # WAN type
                interface_type = nftables_util.INTERFACE_TYPES["wan"]
            else:
                # LAN type
                interface_type = nftables_util.INTERFACE_TYPES["lan"]

            interface_id = intf.get("interfaceId")

            file.write("# set source interface mark\n")
            file.write(
                f"add rule inet interface-marks mark-src-interface iifname {interface_name} mark set mark and 0x{self.SRC_INTERFACE_MASK_INVERSE:x} or 0x{(interface_id << self.SRC_INTERFACE_SHIFT) & self.SRC_INTERFACE_MASK:x}\n"
            )
            file.write("# set source interface type\n")
            file.write(
                f"add rule inet interface-marks mark-src-interface iifname {interface_name} mark set mark and 0x{self.SRC_TYPE_MASK_INVERSE:x} or 0x{(interface_type << self.SRC_TYPE_SHIFT) & self.SRC_TYPE_MASK:x}\n"
            )
            file.write("# set client interface mark\n")
            file.write(
                f"add rule inet interface-marks mark-src-interface ct direction original iifname {interface_name} ct mark set ct mark and 0x{self.CLIENT_INTERFACE_MASK_INVERSE:x} or 0x{(interface_id << self.CLIENT_INTERFACE_SHIFT) & self.CLIENT_INTERFACE_MASK:x}\n"
            )
            file.write("# set client interface type\n")
            file.write(
                f"add rule inet interface-marks mark-src-interface ct direction original iifname {interface_name} ct mark set ct mark and 0x{self.CLIENT_TYPE_MASK_INVERSE:x} or 0x{(interface_type << self.CLIENT_TYPE_SHIFT) & self.CLIENT_TYPE_MASK:x}\n"
            )

            file.write("# set destination interface mark\n")
            file.write(
                f"add rule inet interface-marks mark-dst-interface oifname {interface_name} mark set mark and 0x{self.DST_INTERFACE_MASK_INVERSE:x} or 0x{(interface_id << self.DST_INTERFACE_SHIFT) & self.DST_INTERFACE_MASK:x}\n"
            )
            file.write("# set destination interface type\n")
            file.write(
                f"add rule inet interface-marks mark-dst-interface oifname {interface_name} mark set mark and 0x{self.DST_TYPE_MASK_INVERSE:x} or 0x{(interface_type << self.DST_TYPE_SHIFT) & self.DST_TYPE_MASK:x}\n"
            )
            file.write("# set server interface mark\n")
            file.write(
                f"add rule inet interface-marks mark-dst-interface ct direction original oifname {interface_name} ct mark set ct mark and 0x{self.SERVER_INTERFACE_MASK_INVERSE:x} or 0x{(interface_id << self.SERVER_INTERFACE_SHIFT) & self.SERVER_INTERFACE_MASK:x}\n"
            )
            file.write("# set server interface type\n")
            file.write(
                f"add rule inet interface-marks mark-dst-interface ct direction original oifname {interface_name} ct mark set ct mark and 0x{self.SERVER_TYPE_MASK_INVERSE:x} or 0x{(interface_type << self.SERVER_TYPE_SHIFT) & self.SERVER_TYPE_MASK:x}\n"
            )

            if intf.get("routeMtu"):
                file.write("\n")
                file.write("# Set the MSS size to route mtu in the mark-dst-interface chain\n")
                file.write(
                    "add rule inet interface-marks mark-dst-interface mark & 0x0000ff00 == 0x%x tcp flags syn tcp option maxseg size set rt mtu\n"
                    % (interface_id << self.DST_INTERFACE_SHIFT)
                )
                file.write("\n")

            file.write(
                "# if ct mark server interface is X then set the mark client interface to X\n"
            )
            file.write(
                f"add rule inet interface-marks restore-interface-marks-reply ct mark and 0x{self.SERVER_INTERFACE_MASK:x} == 0x{interface_id << self.SERVER_INTERFACE_SHIFT:x} mark set mark and 0x{self.CLIENT_INTERFACE_MASK_INVERSE:x} or 0x{interface_id << self.CLIENT_INTERFACE_SHIFT:x}\n"
            )
            file.write(
                "# if ct mark server interface is X then set the mark client type to Xs type\n"
            )
            file.write(
                f"add rule inet interface-marks restore-interface-marks-reply ct mark and 0x{self.SERVER_INTERFACE_MASK:x} == 0x{interface_id << self.SERVER_INTERFACE_SHIFT:x} mark set mark and 0x{self.CLIENT_TYPE_MASK_INVERSE:x} or 0x{interface_type << self.CLIENT_TYPE_SHIFT:x}\n"
            )
            file.write(
                "# if ct mark client interface is X then set the mark server interface to X\n"
            )
            file.write(
                f"add rule inet interface-marks restore-interface-marks-reply ct mark and 0x{self.CLIENT_INTERFACE_MASK:x} == 0x{interface_id << self.CLIENT_INTERFACE_SHIFT:x} mark set mark and 0x{self.SERVER_INTERFACE_MASK_INVERSE:x} or 0x{interface_id << self.SERVER_INTERFACE_SHIFT:x}\n"
            )
            file.write(
                "# if ct mark client interface is X then set the mark server type to Xs type\n"
            )
            file.write(
                f"add rule inet interface-marks restore-interface-marks-reply ct mark and 0x{self.CLIENT_INTERFACE_MASK:x} == 0x{interface_id << self.CLIENT_INTERFACE_SHIFT:x} mark set mark and 0x{self.SERVER_TYPE_MASK_INVERSE:x} or 0x{interface_type << self.SERVER_TYPE_SHIFT:x}\n"
            )

        file.write("# restore reply direction interface marks for local output traffic\n")
        file.write(
            f"add rule inet interface-marks restore-interface-marks-reply ct mark and 0x{self.SERVER_INTERFACE_MASK:x} == 0x{255 << self.SERVER_INTERFACE_SHIFT:x} mark set mark and 0x{self.CLIENT_INTERFACE_MASK_INVERSE:x} or 0x{255 << self.CLIENT_INTERFACE_SHIFT:x}\n"
        )
        file.write(
            f"add rule inet interface-marks restore-interface-marks-reply ct mark and 0x{self.CLIENT_INTERFACE_MASK:x} == 0x{255 << self.CLIENT_INTERFACE_SHIFT:x} mark set mark and 0x{self.SERVER_INTERFACE_MASK_INVERSE:x} or 0x{255 << self.SERVER_INTERFACE_SHIFT:x}\n"
        )

        file.write("# restore original direction interface marks\n")
        file.write(
            f"add rule inet interface-marks restore-interface-marks-original mark set ct mark and 0x{self.ALL_MASK:x}\n"
        )

        file.write(
            f'add rule inet interface-marks prerouting-interface-marks mark and 0x{self.SRC_INTERFACE_MASK:x} == 0 iifname != lo log prefix "WARNING: Unknown src intf: "\n'
        )
        file.write(
            f'add rule inet interface-marks postrouting-interface-marks mark and 0x{self.DST_INTERFACE_MASK:x} == 0 oifname != lo log prefix "WARNING: Unknown dst intf: "\n'
        )

        # We could just have static rules in restore-interface-marks-reply that just apply the original marks but shifted around a bit
        # However This would require something like:
        # mark set mark or ct mark and 0xff << 8
        # However nft won't let you do this:
        # Error: Right hand side of binary operation (|) must be constant
        # So we have to use a ton of rules to do the same thing above

        file.write("\n")
        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(CommonInterfaceManager())
