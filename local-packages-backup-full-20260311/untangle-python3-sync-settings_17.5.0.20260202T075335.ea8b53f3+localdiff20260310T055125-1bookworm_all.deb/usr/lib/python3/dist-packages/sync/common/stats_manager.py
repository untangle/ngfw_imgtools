from sync import Manager, network_util, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

default_ping_analyzer_name = "Default Ping Analyzer"

logger = Logger.getInstance()


def get_default_stats_config(settings):
    return {
        "pingAnalyzers": [
            {
                "name": "Default Ping Analyzer",
                "interfaceIds": get_active_wans(settings),
                "ipv4Addresses": [
                    "1.1.1.1",
                    "1.0.0.1",
                    "8.8.8.8",
                    "8.8.4.4",
                    "208.67.222.222",
                    "208.67.220.220",
                ],
                "ipv6Addresses": [
                    "2606:4700:4700::1111",
                    "2606:4700:4700::1001",
                    "2001:4860:4860::8888",
                    "2001:4860:4860::8844",
                    "2620:119:35::35",
                    "2620:119:53::53",
                ],
                "enabled": True,
            }
        ]
    }


class StatsManager(Manager):
    """
    Manager for Stats settings
    """

    def initialize(self) -> None:
        registrar.register_settings_file("settings", self)

    def sanitize_settings(self, settings_file) -> None:
        if "stats" not in settings_file.settings:
            settings_file.settings["stats"] = get_default_stats_config(settings_file.settings)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["stats"] = get_default_stats_config(settings_file.settings)

    def validate_settings(self, settings_file) -> None:
        if settings_file.settings is None:
            raise SettingsException(message="api_missing_system_settings")

        if "stats" not in settings_file.settings:
            raise SettingsException(message="api_missing_stats_settings")

        stats = settings_file.settings["stats"]
        ping_analyzers = stats["pingAnalyzers"]

        for pa in ping_analyzers:
            ipv4_addresses = pa["ipv4Addresses"]
            ipv6_addresses = pa["ipv6Addresses"]

            for ipv4_addr in ipv4_addresses:
                if network_util.get_ip_type(ipv4_addr) != 4:
                    raise SettingsException(message="ip")
            for ipv6_addr in ipv6_addresses:
                if network_util.get_ip_type(ipv6_addr) != 6:
                    raise SettingsException(message="ip_v6")


def get_active_wans(settings):
    wans = []
    for intf in settings.get("network", {}).get("interfaces", []):
        if intf.get("virtual", False):
            continue

        if network_util.enabled_wan(intf):
            wans.append(intf["interfaceId"])

    return wans


registrar.register_manager(StatsManager())
