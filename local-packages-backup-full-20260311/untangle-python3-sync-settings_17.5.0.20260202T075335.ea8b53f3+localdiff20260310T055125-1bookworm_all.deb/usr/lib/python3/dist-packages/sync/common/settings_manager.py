"""settings_manager manages /etc/config/current.json"""

import os
import shutil
from collections import OrderedDict

from sync import Manager, registrar
from sync.common import Logger
from sync.file_util import FileUtil
from sync.perms_util import regain_permissions
from sync.settings_exception import SettingsException

# This class is responsible for writing /etc/config/network
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class SettingsManager(Manager):
    """
    This class is responsible for writing /etc/config/current.json
    and general settings initialization
    """

    settings_filename = FileUtil.locate_file("/etc/config/current.json")

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.settings_filename, None, self)

    def create_settings(self, settings_file, prefix, delete_list, filepath) -> None:
        """creates settings"""
        logger.info("Initializing settings")

        settings_file.settings["version"] = 1

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        # orig_settings_filename = settings_file.settings["filename"]
        orig_settings_filename = settings_file.file_name
        filename = prefix + self.settings_filename
        file_dir = os.path.dirname(filename)
        with regain_permissions():
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)
            shutil.copyfile(orig_settings_filename, filename)
        logger.info("Wrote %s", str(filename))

    def sanitize_settings(self, settings_file) -> None:
        # Update settings file version after all other sanitizers have run
        if settings_file.settings["version"] <= 4:
            settings_file.settings["version"] = 5


registrar.register_manager(SettingsManager())


def validate_schema(settings) -> None:
    """
    Eventually this should validate the schema against mfw_schema, at which point the recursion can probably be removed
    """
    bad_att_locations = []

    schema_recurse(settings, bad_att_locations)

    if len(bad_att_locations) > 0:
        raise SettingsException(
            message_str=f"Schema Validation: Bad attributes found. JSON Locations: {bad_att_locations} "
        )


def schema_recurse(currentItem, bad_attr_locations, itemParents=None) -> None:
    """
    This function currently recurses the entire json schema for attribute names of 'output', 'result', or 'error' and raises an exception if found

    """
    if itemParents is None:
        itemParents = ["root"]
    bad_attributes = ["output", "results", "error"]

    if isinstance(currentItem, OrderedDict):
        iterator = currentItem.items()
    elif isinstance(currentItem, list):
        iterator = enumerate(currentItem)
    else:
        return

    for k, v in iterator:
        if k in bad_attributes:
            dataLocation = str("/".join(itemParents)) + "/" + k
            logger.warning("Bad JSON data found: %s", str(dataLocation))
            bad_attr_locations.append(dataLocation)

        if isinstance(v, (OrderedDict, list)):
            itemParents.append(str(k))
            schema_recurse(v, bad_attr_locations, itemParents)
            del itemParents[-1]
