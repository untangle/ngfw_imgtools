"""network_manager manages network settings"""

import copy
from typing import Any

from sync import (
    EncryptionUtil,
    Manager,
    board_util,
    interface_util,
    network_util,
    registrar,
)
from sync.common import Logger
from sync.common.validators.interface_validator import InterfaceValidator
from sync.common.validators.route_validator import RouteValidator
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

logger = Logger.getInstance()


class NetworkManager(Manager):
    """
    This class is responsible for writing /etc/config/network
    based on the settings object passed from sync-settings
    """

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def find_bridge_by_bridge_to(self, bridgeto: int, bridges: list[str]) -> list[str]:
        """
        This function finds the bridge with the given bridgeTo
        """
        for bridge in bridges:
            for bridgedTo in bridge["bridgedInterfaces"]:
                if bridgedTo == bridgeto:
                    return bridge
        return None

    def create_bridge(
        self, bridgeTo: list[int], parent_intf: dict[str, Any], interface_id: int
    ) -> dict[str, str]:
        """
        This function creates a bridge, using info from the original target interface.
        """
        unused_props = ["ethAutoNegotiation", "ethDuplex", "ethSpeed", "natIngress"]

        new_bridge = copy.deepcopy(parent_intf)

        new_bridge["name"] = "B_" + parent_intf.get("name")
        new_bridge["bridgedInterfaces"] = bridgeTo
        new_bridge["type"] = "BRIDGE"
        new_bridge["configType"] = "BRIDGED"
        new_bridge["device"] = "B_" + parent_intf.get("name")
        new_bridge["interfaceId"] = interface_id
        new_bridge.pop("bridgedTo", None)

        for prop in unused_props:
            new_bridge.pop(prop, None)

        return new_bridge

    def handle_interface_upgrade(
        self, intf: dict[str, str], interfaces: list[dict[str, str]]
    ) -> None:
        """Function checks interface settings and updates it"""
        if intf.get("type") == "NIC" and intf.get("configType") == "ADDRESSED":
            for eintf in interfaces:
                if eintf.get("device") == intf.get("device"):
                    eintf["interfaceId"] = None
                    return

            intf["interfaceId"] = None
            interfaces.append(intf)

    def sanitize_settings_pre(self, settings_file: SettingsFile) -> None:
        """sanitizes removes blank settings"""
        interfaces = settings_file.settings.get("network", {}).get("interfaces")
        self.upgrade_interface_settings(interfaces)
        # Remove all "" and 0 and null values
        for intf in interfaces:
            for k, v in dict(intf).items():
                if v == "":
                    del intf[k]
                if intf.get(k, "missing") is None:
                    del intf[k]
            # Never do natIngress
            intf["natIngress"] = False

            # The UI currently doesn't set wan = false for LANS
            # if it is not specified, assume its false
            if intf.get("wan") is None:
                intf["wan"] = False
            if intf.get("interfaceId") is None:
                intf["interfaceId"] = find_lowest_available_interface_id(interfaces)
            # We used to set configType == DISABLED to disable interfaces
            if intf.get("enabled") is None:
                if intf["configType"] == "DISABLED":
                    intf["enabled"] = False
                else:
                    intf["enabled"] = True
            # mfw-1093 ensure no more remaining openVpnBoundInterfaceId properties
            # change openvpnBoundInterfaceId to boundInterfaceId
            if intf.get("openvpnBoundInterfaceId"):
                intf["boundInterfaceId"] = intf.pop("openvpnBoundInterfaceId", "0")

            # sync vlan device with vlan name for debuggability's sake
            if intf.get("type") == "VLAN":
                # convert the vlanid to string
                intf["vlanid"] = str(intf.get("vlanid"))
                # Changing the device name to EOS compatible name
                if intf.get("configType") == "BRIDGED":
                    bound_interface = network_util.get_interface_by_id(
                        settings_file.settings, intf.get("bridgedTo")
                    )
                else:
                    bound_interface = network_util.get_interface_by_id(
                        settings_file.settings, intf.get("boundInterfaceId")
                    )
                intf["device"] = bound_interface.get("device") + "." + intf.get("vlanid")
                if intf.get("wan") is not True or intf.get("configType") != "ADDRESSED":
                    intf["natEgress"] = False

            # sets the "virtual" field for an interface (true for VPNs, false for physical devices)
            if intf.get("type") in ["OPENVPN", "WIREGUARD", "VLAN", "IPSEC", "BRIDGE", "LOOPBACK"]:
                intf["virtual"] = True
            else:
                intf["virtual"] = False

            # Currently we only support IPV4 tunnels - for IPv6 support, we need to add additional
            # default configs to the UI, and also change how some of the tunnel types are generated
            if intf.get("virtual") is True and intf.get("type") != "VLAN":
                intf["family"] = "ipv4"

            self.sanitize_interface_device(intf, interfaces)

        self.sanitize_mac_addrs(interfaces)

        if settings_file.settings.get("version") <= 3:
            self.upgrade_bridge_and_vlan_settings(interfaces, settings_file.settings)

    def sanitize_interface_device(
        self, interface_settings: dict[str, Any], interfaces: dict[str, Any]
    ) -> None:
        """
        Sets the "device" field for an interface.
        When creating new interfaces the UI doesn't know which device identifier
        interface to use so it leaves it unset. This process will go through
        and find the first available tunX interface for any openvpn interface
        without a device set
        """
        if interface_settings.get("type") == "OPENVPN":
            if interface_settings.get("device") is None:
                interface_settings["device"] = find_lowest_available_tun(interfaces)
        elif (
            interface_settings.get("type") == "IPSEC"
            and not board_util.BoardUtil.is_platform_os_eos()
        ):
            # Always postfix ipsec with "0" to avoid problems if name is ever "ipsec" which will cause problems in nftables.
            interface_settings["device"] = interface_settings.get("name") + "0"
        elif interface_settings.get("type") == "WIREGUARD":
            interface_settings["device"] = interface_settings.get("name")
        elif "device" not in interface_settings and interface_settings.get("name") is not None:
            # If not defined and name is defined, use the name as-is.
            interface_settings["device"] = interface_settings.get("name")

    def sanitize_mac_addrs(self, interfaces: dict[str, Any]) -> None:
        """
        Sanitize mac addrs will verify that the 'parent' mac address device's OUI is used in the child mac addresses in settings
        currently this only affects espressobin devices (e3 and e3w)
        """

        board_name = board_util.BoardUtil.get_board_name()
        if board_name in ["globalscale,espressobin", "globalscale,espressobin-v7-emmc"]:
            parent_oui = board_util.get_device_macaddr("eth0")[0:9]
            for intf in interfaces:
                if (
                    intf.get("type") is not None
                    and intf.get("type") == "NIC"
                    and (intf.get("macaddr") is None or parent_oui not in intf.get("macaddr"))
                ):
                    intf["macaddr"] = board_util.get_interface_macaddr(intf["device"])

    def sanitize_settings_post(self, settings_file: SettingsFile) -> None:
        # Clear "new" flag and enable the interface if it is bridged
        interfaces = settings_file.settings.get("network").get("interfaces")
        for interface in interfaces:
            if interface.get("new") is not None:
                del interface["new"]
            if network_util.get_bridge_name(settings_file.settings, interface, "ipv4") != "":
                interface["enabled"] = True

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        # Missing static routes settings.
        routes_settings = settings_file.settings.get("routes")
        if routes_settings is None:
            routes_settings = []
            settings_file.settings["routes"] = routes_settings
        else:
            for route in settings_file.settings["routes"]:
                if route.get("interface"):
                    intf = network_util.get_interface_by_device(
                        settings_file.settings, route["interface"]
                    )
                    if intf:
                        route["interfaceId"] = intf["interfaceId"]

        for interface_settings in settings_file.settings["network"]["interfaces"]:
            if interface_settings.get("v4ConfigType") == "PPPOE" and interface_settings.get(
                "v4PPPoEPassword"
            ):
                encrypted_password = EncryptionUtil.execute_password_manager(
                    "-e", interface_settings["v4PPPoEPassword"]
                )
                interface_settings["v4PPPoEPasswordEncrypted"] = encrypted_password
                del interface_settings["v4PPPoEPassword"]

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates settings"""
        if not board_util.BoardUtil.is_platform_os_eos():
            validator = InterfaceValidator(settings_file)
            interfaces = settings_file.settings.get("network").get("interfaces")
            for intf in interfaces:
                validator.validate(intf)
                # TODO add mulit-setting validation:
                # for example:
                # if dhcp is enabled, dhcpStart and dhcpEnd are specified
                # etc
                # TODO add multi-interface validation:
                # for example:
                # if an interface is bridged its bridged to an interface that exists
                # a static interface doesn't have the same subnet as another static interface
                # etc
                # Write out static routes

        routeValidator = RouteValidator(settings_file)
        routeValidator.validate()

    def create_settings(
        self,
        settings_file: SettingsFile,
        prefix: str,
        delete_list: list[str],
        _filename: str,
    ) -> None:
        """creates settings"""
        logger.info("Creating settings")
        network = {}
        network["interfaces"] = []
        settings_file.settings["network"] = network

        routes = []
        settings_file.settings["routes"] = routes

        interface_util.create_settings_interfaces(settings_file.settings)
        self.create_settings_switches(settings_file.settings, prefix, delete_list)

    def upgrade_settings(self, settings_file: SettingsFile) -> None:
        """
        Reads WAN interfaces from startup-config's 'group interface WAN' section
        and updates settings to matching interfaces as WAN.

        Also reads interface IP configuration from startup-config for interfaces
        with 'no switchport' and updates settings to match.
        """
        if not board_util.BoardUtil.is_platform_os_eos():
            return

        # Phase 1: Get WAN interface device names from startup-config
        wan_devices = network_util.get_wan_interfaces_from_startup_config()

        # Build map of current interfaces keyed by device
        current_interfaces = settings_file.settings["network"]["interfaces"]
        current_intf_map = {
            intf.get("device"): intf for intf in current_interfaces if intf.get("device")
        }

        if wan_devices:
            # Update current interfaces with WAN status from startup-config
            for device in wan_devices:
                if device in current_intf_map:
                    current_intf_map[device]["wan"] = True
        else:
            logger.info("No WAN interfaces found in startup-config for WAN group, skipping...")

        # Phase 2: Update interface IP configuration from startup-config
        ip_configs = network_util.get_interface_ip_config_from_startup_config()
        logger.info(
            f"IP configs from startup-config: {list(ip_configs.keys()) if ip_configs else 'empty'}"
        )
        if not ip_configs:
            logger.info("No interface IP configs found in startup-config, skipping...")
            return

        for intf in current_interfaces:
            device = intf.get("device")
            if not device or device not in ip_configs:
                if device:
                    logger.debug(f"Device {device} not in ip_configs, skipping...")
                continue

            # Skip non-NIC and management interfaces
            if intf.get("type") != "NIC" or intf.get("management"):
                logger.debug(
                    f"Skipping {device}: type={intf.get('type')}, management={intf.get('management')}"
                )
                continue

            ip_config = ip_configs[device]
            logger.info(
                f"Applying IP config from startup-config to {device}: v4_type={ip_config.v4_type}, v6_type={ip_config.v6_type}"
            )
            self._apply_ip_config_from_startup(intf, ip_config)

    def _apply_ip_config_from_startup(
        self, intf: dict, ip_config: network_util.InterfaceIPConfig
    ) -> None:
        """Apply parsed IP configuration from startup-config to an interface."""
        # IPv4
        if ip_config.v4_type == "DHCP":
            intf["v4ConfigType"] = "DHCP"
            intf.pop("v4StaticAddress", None)
            intf.pop("v4StaticPrefix", None)
        elif ip_config.v4_type == "STATIC":
            intf["v4ConfigType"] = "STATIC"
            intf["v4StaticAddress"] = ip_config.v4_address
            intf["v4StaticPrefix"] = ip_config.v4_prefix
        elif ip_config.v4_type == "DISABLED":
            intf["v4ConfigType"] = "DISABLED"
            intf.pop("v4StaticAddress", None)
            intf.pop("v4StaticPrefix", None)

        # IPv6
        if ip_config.v6_type == "SLAAC":
            intf["v6ConfigType"] = "SLAAC"
            intf.pop("v6StaticAddress", None)
            intf.pop("v6StaticPrefix", None)
        elif ip_config.v6_type == "STATIC":
            intf["v6ConfigType"] = "STATIC"
            intf["v6StaticAddress"] = ip_config.v6_address
            intf["v6StaticPrefix"] = ip_config.v6_prefix
        elif ip_config.v6_type == "DISABLED":
            intf["v6ConfigType"] = "DISABLED"
            intf.pop("v6StaticAddress", None)
            intf.pop("v6StaticPrefix", None)

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, _delete_list: list[str]
    ) -> None:
        """syncs settings"""
        interfaces = settings_file.settings["network"]["interfaces"]
        for intf in interfaces:
            is_bridge = False
            bridged_interfaces_str = []
            bridged_interfaces = []
            for intf2 in interfaces:
                if (
                    intf2.get("enabled")
                    and intf2.get("configType") == "BRIDGED"
                    and intf2.get("bridgedTo") == intf.get("interfaceId")
                ):
                    bridged_interfaces_str.append(str(intf2.get("device")))
                    bridged_interfaces.append(intf2)
                if intf2.get("type") == "BRIDGE":
                    bound_interface = intf2.get("bridgedInterfaces")
                    if intf.get("interfaceId") in bound_interface and intf.get("type") != "WIFI":
                        intf["enabled"] = False

            if bridged_interfaces:
                is_bridge = True
                bridged_interfaces_str.insert(
                    0, intf.get("device")
                )  # include yourself in bridge at front
                bridged_interfaces.insert(0, intf)  # include yourself in bridge at front
                intf["is_bridge"] = is_bridge
            if is_bridge:
                intf["bridged_interfaces_str"] = bridged_interfaces_str

            if intf.get("is_bridge"):
                intf["logical_name"] = "b_" + intf["name"]
                # https://wiki.openwrt.org/doc/uci/network#aliasesthe_new_way
                # documentation says to use "br-" plus logical name
                intf["ifname"] = "br-" + intf["logical_name"]
                intf["netfilterDev"] = intf["ifname"]
            elif intf.get("type") == "IPSEC":
                ipsec_device = intf["device"]
                intf["logical_name"] = f"{ipsec_device}"
                intf["netfilterDev"] = f"vti-{ipsec_device}"
            else:
                intf["logical_name"] = intf["name"]
                # Set vlan ifname to the name of the vlan so configuration works properly
                if intf.get("type") == "VLAN":
                    intf["logical_name"] = intf.get("device")
                    intf["ifname"] = intf.get("device")
                else:
                    intf["ifname"] = intf.get("device")
                intf["netfilterDev"] = intf["device"]

    def create_settings_switches(
        self, settings: dict[str, str], _prefix: str, _delete_list: list[str]
    ) -> None:
        """create switches config"""
        settings["network"]["switches"] = board_util.get_switch_settings()

    def upgrade_interface_settings(self, interfaces: list[dict[str, str]]) -> None:
        """
        This function maintains interface in case of restore backup scenario,
        as well as regular cases. It takes care of interface Id,
        and restore backup configuration.
        """
        orig_interfaces = interface_util.discover_interfaces()
        for intf in orig_interfaces:
            self.handle_interface_upgrade(intf, interfaces)

    def upgrade_bridge_and_vlan_settings(
        self, interfaces: list[dict[str, str]], settings: dict[str, Any]
    ) -> None:
        """
        This function upgrades bridge and vlan settings from 5.0 to 5.1 format.
        Mainly we now keep bridging in its own interface, where before it was part
        of the interface it was bridged from.
        """
        new_interfaces = []
        new_bridges = []
        # Iterate through interfaces and create bridges as needed
        for intf in interfaces:
            # Was this interface bridged? But not a vlan
            if intf.get("configType") == "BRIDGED" and intf.get("vlanid") is None:
                # special case for empty bridge... MFW-4130 TB backed out.
                if intf.get("bridgedInterfaces") == []:
                    continue
                bridge_to = intf.get("bridgedTo")
                bridge = self.find_bridge_by_bridge_to(bridge_to, new_bridges)
                if bridge is None:
                    # No existing bridge found, create a new one
                    new_interface_id = find_lowest_available_interface_id(interfaces) + len(
                        new_bridges
                    )
                    parent_intf = network_util.get_interface_by_id(settings, bridge_to)
                    if parent_intf.get("type") == "MANAGEMENT":
                        raise SettingsException(message_str="Cannot bridge management interfaces!")
                    bridge_intfs = [bridge_to, intf.get("interfaceId")]
                    bridge = self.create_bridge(bridge_intfs, parent_intf, new_interface_id)
                    new_bridges.append(bridge)
                else:
                    # add this interfaceID to existing bridge.
                    bridge["bridgedInterfaces"].append(intf.get("interfaceId"))

                intf["configType"] = "ADDRESSED"
            # Add interface to new interfaces list
            new_interfaces.append(intf)

        # Iterate again for vlan bridged interfaces
        for intf in new_interfaces:
            # Was this interface a vlan to a bridged interface?
            if intf.get("vlanid") and intf.get("configType") == "BRIDGED":
                # Find the bridge
                bridge = self.find_bridge_by_bridge_to(intf.get("bridgedTo"), new_bridges)
                if bridge is None:
                    # Should never happen
                    raise SettingsException(
                        message_str=f"Unable to find parent bridge for interface id {intf.get('interfaceId')} bridged to {intf.get('bridgedTo')}"
                    )
                # add this interfaceID to existing bridge.
                bridge["bridgedInterfaces"].append(intf.get("interfaceId"))
                intf["configType"] = "ADDRESSED"
                intf["v4ConfigType"] = "DISABLED"
                intf["v6ConfigType"] = "DISABLED"
            intf.pop("bridgedTo", None)

        # Add bridged interfaces to new list
        new_interfaces.extend(new_bridges)

        # Replace interfaces with new interfaces
        interfaces.clear()
        interfaces.extend(new_interfaces)


def find_lowest_available_tun(interfaces: dict[str, Any]) -> str:
    """
    This loops thought the specified interfaces
    and finds the lowest available unused tunX device
    If no other tun devices exists tun0 is returned
    """
    available = list(range(255))
    for intf in interfaces:
        if intf.get("device") is not None and intf.get("device").startswith("tun"):
            dev = intf["device"].replace("tun", "")
            try:
                available.remove(int(dev))
            except ValueError as err:
                raise SettingsException(
                    message_str="Invalid tun interface: " + intf["device"]
                ) from err
    if not available:
        raise SettingsException(message_str="No available tun interfaces")
    return "tun" + str(available[0])


def find_lowest_available_interface_id(interfaces: dict[str, Any]) -> int:
    """
    This loops through the specified interfaces
    and finds the lowest available unused interfaceID
    """
    available = list(range(1, 254))
    for intf in interfaces:
        interface_id = intf.get("interfaceId")
        try:
            if interface_id is not None:
                available.remove(interface_id)
        except ValueError as err:
            raise SettingsException(
                message_str="Invalid interface ID: " + intf["interfaceId"]
            ) from err
    if not available:
        raise SettingsException(message_str="No available interface IDs")
    return available[0]


registrar.register_manager(NetworkManager())
