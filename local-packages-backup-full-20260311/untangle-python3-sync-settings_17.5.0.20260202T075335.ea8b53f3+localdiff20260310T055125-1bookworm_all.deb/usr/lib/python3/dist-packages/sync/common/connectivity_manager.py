"""This class is responsible for managing checking connectivity with cloud services"""

from sync import Manager, registrar
from sync.settings_exception import SettingsException


class ConnectivityManager(Manager):
    """ConnectivityManager manages the connectivity with cloud services"""

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def validate_settings(self, settings_file) -> None:
        """validates settings"""
        connectivity_settings = settings_file.settings.get("connectivity")
        # Null checks and type checks for settings
        if connectivity_settings is None:
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["connectivity", "settings"]
            )

        if "settings_rollback" not in connectivity_settings or not isinstance(
            connectivity_settings["settings_rollback"], bool
        ):
            raise SettingsException(
                message="missing_or_invalid_parameter_value",
                vars=["connectivity", "settings_rollback"],
            )


registrar.register_manager(ConnectivityManager())
