"""This class is responsible for managing bypass filter settings"""

import json
import os
from uuid import uuid4

from sync import Manager, registrar
from sync.common import Logger
from sync.file_util import FileUtil
from sync.network_util import get_interface_by_id
from sync.perms_util import regain_permissions
from sync.settings_exception import SettingsException

logger = Logger.getInstance()

BYPASS_SETTINGS_PATH = "/tmp/bypass/bypass_settings"  # noqa: S108
BYPASS = "bypass"

bypass_default_settings = {"rules": []}


class BypassManager(Manager):
    """BypassManager manages the bypass filter settings"""

    def __init__(self) -> None:
        self.bypass_settings_path = FileUtil.locate_file(BYPASS_SETTINGS_PATH)

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        # Added "sync-dos-active-session" operations here to send the SIGHUP signal to packetd
        # Instead of creating new operation which will do the same thing used old operation "sync-dos-active-session"
        registrar.register_file(self.bypass_settings_path, "sync-dos-active-session", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings[BYPASS] = bypass_default_settings

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        bypass_settings = settings_file.settings.get(BYPASS)

        # Missing bypass settings
        if bypass_settings is None:
            settings_file.settings[BYPASS] = bypass_default_settings
            return

        for rule in bypass_settings.get("rules", []):
            if rule.get("ruleId") is None:
                rule["ruleId"] = uuid4().__str__()
            if "log" not in rule:
                rule["log"] = False
            # uses interface_name instead of interface_id for SOURCE_INTERFACE_ZONE
            for condition in rule.get("conditions", []):
                if condition.get("type") == "SOURCE_INTERFACE_ZONE":
                    interface_details = get_interface_by_id(
                        settings_file.settings, condition["value"]
                    )
                    condition["value"] = (
                        interface_details["name"]
                        if interface_details is not None
                        else condition["value"]
                    )
        # upgrades to 6.2 - moves bypass_settings backup file from /etc/config to /tmp and deletes older folder path for backup file
        if settings_file.settings.get("version") <= 5:
            FileUtil.move_write_only_registered_files_to_tmp(self.bypass_settings_path, True)

    def validate_settings(self, settings_file) -> None:
        """validates settings"""
        bypass_settings = settings_file.settings.get(BYPASS)
        # Missing bypass settings
        if bypass_settings is None:
            raise SettingsException(message_str="missing_bypass_rule_action")

        if "rules" not in bypass_settings:
            raise SettingsException(message_str="missing_bypass_rules")

        for rule in bypass_settings.get("rules", []):
            self.validate_rule(rule)

    def validate_rule(self, rule) -> None:
        """validates a single rule"""
        self.validate_parameter(rule, "enabled", bool)
        self.validate_parameter(rule, "description", str)

        if "action" not in rule or "type" not in rule.get("action"):
            raise SettingsException(message_str="missing_bypass_rule_action")
        if rule["action"]["type"] != "BYPASS":
            raise SettingsException(
                message_str="invalid_condition_field_bypass", vars=[rule["action"]["type"]]
            )
        if "conditions" in rule:
            for condition in rule.get("conditions"):
                self.validate_condition(condition)
        else:
            raise SettingsException(message_str="missing_bypass_rule_condition")

    def validate_parameter(self, parameters, parameter_name, parameter_type) -> None:
        """validates parameters"""
        parameter_value = parameters.get(parameter_name)
        if parameter_value is None or not isinstance(parameter_value, parameter_type):
            raise SettingsException(
                message="missing_or_invalid_parameter_value_bypass", vars=[parameter_name]
            )

    def validate_condition(self, condition) -> None:
        """validates a single condition"""
        condition_fields = [
            "DESTINATION_ADDRESS",
            "DESTINATION_ADDRESS_V6",
            "DESTINATION_INTERFACE_TYPE",
            "DESTINATION_PORT",
            "SOURCE_ADDRESS",
            "SOURCE_ADDRESS_V6",
            "SOURCE_INTERFACE_TYPE",
            "SOURCE_INTERFACE_ZONE",
            "SOURCE_PORT",
            "IP_PROTOCOL",
            "SOURCE_INTERFACE_NAME",
            "MAC_ADDRESS",
        ]
        condition_operators = ["==", "!="]
        port_conditions = ["DESTINATION_PORT", "SOURCE_PORT"]

        if condition.get("type") in port_conditions:
            if condition.get("port_protocol") is None:
                raise SettingsException(
                    message_str="missing_bypass_rule_condition_field",
                    vars=["port_protocol", condition.get("port_protocol")],
                )
        if condition["type"] not in condition_fields:
            raise SettingsException(
                message="invalid_condition_field_bypass", vars=["type", condition["type"]]
            )
        if condition["op"] not in condition_operators:
            raise SettingsException(
                message="invalid_condition_field_bypass", vars=["type", condition["op"]]
            )
        if condition["value"] is None:
            raise SettingsException(
                message="invalid_condition_field_bypass", vars=["type", condition["value"]]
            )

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")
        self.write_bypass_settings(settings_file, prefix)

    def write_bypass_settings(self, settings_file, prefix) -> None:
        """writes the settings to specified filepath"""
        current_bypass_settings = settings_file.settings[BYPASS]
        filename = prefix + self.bypass_settings_path
        self.write_settings_file(filename, json.dumps(current_bypass_settings).encode("utf-8"))

    def write_settings_file(self, filename, data) -> None:
        """writes data to specified file"""
        file_dir = os.path.dirname(filename)
        with regain_permissions():
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)
            with open(filename, "wb+") as file:
                file.write(data)

        logger.info("Wrote %s", str(filename))


registrar.register_manager(BypassManager())
