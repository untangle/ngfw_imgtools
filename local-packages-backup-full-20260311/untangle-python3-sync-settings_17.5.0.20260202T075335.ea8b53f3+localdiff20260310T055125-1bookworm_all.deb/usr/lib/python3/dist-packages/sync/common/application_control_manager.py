import copy

from sync import Manager, SettingsFile, registrar
from sync.common import Logger

logger = Logger.getInstance()

# default values for application control
default_application_control_config = {
    "enabled": False,
    "cloud_classification": False,
    "actions": {"block": [], "alert": [], "reject": [], "log": []},
}

# possible condition fields and condition operators
condition_fields = [
    "CLIENT_ADDRESS",
    "CLIENT_PORT",
    "SERVER_ADDRESS",
    "SERVER_PORT",
    "PORT_PROTOCOL",
]
condition_operators = ["==", "!=", "<", ">", "<=", ">="]


class ApplicationControlManager(Manager):
    """Application Control definition file"""

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["application_control"] = default_application_control_config

    def sanitize_settings(self, settings_file) -> None:
        if "application_control" not in settings_file.settings:
            settings_file.settings["application_control"] = default_application_control_config

        self.temp_settings = copy.deepcopy(settings_file.settings["application_control"])

        # Validate `enabled` property
        if "enabled" not in self.temp_settings:
            self.temp_settings["enabled"] = False
        # Validate `cloud classification` property
        if "cloud_classification" not in self.temp_settings:
            self.temp_settings["cloud_classification"] = False
        # if flag is in action change it to alert
        if "flag" in self.temp_settings.get("actions", {}):
            if "alert" in self.temp_settings.get("actions", {}):
                self.temp_settings.get("actions", {})["alert"].extend(
                    self.temp_settings.get("actions", {}).pop("flag")
                )
            else:
                self.temp_settings.get("actions", {})["alert"] = self.temp_settings.get(
                    "actions", {}
                ).pop("flag")
        # upgrades to 6.1 if settings doesn't have log property add it and remove custom_rules property
        if self.temp_settings and settings_file.settings.get("version") <= 4:
            self.temp_settings["actions"]["log"] = list(
                set(
                    self.temp_settings.get("actions", {}).get("block", [])
                    + self.temp_settings.get("actions", {}).get("reject", [])
                    + self.temp_settings.get("actions", {}).get("alert", [])
                )
            )
            # Remove `custom_rules` property
            self.remove_custom_rules()

    def sanitize_rules(self) -> None:
        """
        FOR UPGRADE CASES ONLY
        Check if the PORT_PROTOCOL condition exists and type is string, then convert it to an array
        """
        for rule in self.temp_settings["custom_rules"]:
            for condition in rule["conditions"]:
                if condition["type"] == "PORT_PROTOCOL" and type(condition["value"]) == str:
                    condition["value"] = condition["value"].split(",")

    # method for validating top level properties for application control
    def validate_settings(self, settings_file: SettingsFile) -> None:
        # Validate actions
        self.validate_actions()

        settings_file.settings["application_control"] = self.temp_settings

        settings_file.save_settings()

    # method for removing the `custom rules` part of the config
    # the custom_rules feature was deprecated from Application control
    # after the 6.1 release
    def remove_custom_rules(self) -> None:
        if "custom_rules" in self.temp_settings:
            del self.temp_settings["custom_rules"]

    # method for validating application control actions
    # make sure we have those 3 lists
    def validate_actions(self) -> None:
        required_fields = {"reject", "block", "alert", "log"}
        sanitized_actions = copy.deepcopy(self.temp_settings["actions"])

        if not required_fields.issubset(set(sanitized_actions)):
            sanitized_actions = {"reject": [], "block": [], "alert": [], "log": []}

        if type(sanitized_actions["reject"]) != list:
            sanitized_actions["reject"] = []

        if type(sanitized_actions["block"]) != list:
            sanitized_actions["block"] = []

        if type(sanitized_actions["alert"]) != list:
            sanitized_actions["alert"] = []

        if type(sanitized_actions["log"]) != list:
            sanitized_actions["log"] = []

        self.temp_settings["actions"] = sanitized_actions


registrar.register_manager(ApplicationControlManager())
