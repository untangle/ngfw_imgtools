"""This class is responsible for validating DHCP config"""

import crypt

from sync.common import Logger
from sync.common.sanitizers.base_sanitizer import Sanitizer
from sync.settings_file import SettingsFile

logger = Logger.getInstance()


class AccountsSanitizer(Sanitizer):
    """Handles sanitization of Accounts config"""

    def sanitize(self, settings_file: SettingsFile) -> None:
        """sanitizes removes the cleartext password and replaces with the proper hashes"""
        accounts = settings_file.settings.get("accounts")
        if accounts is None:
            return
        creds = accounts.get("credentials")
        if creds is None:
            return
        for cred in creds:
            cleartext_password = cred.get("passwordCleartext")
            if cleartext_password is None:
                continue
            logger.info("Sanitizing password...")
            # Remove the cleartext password. We don't want to save this.
            del cred["passwordCleartext"]
            # Replace with the hashed versions of the password
            cred["passwordHashMD5"] = crypt.crypt(
                cleartext_password, crypt.mksalt(crypt.METHOD_MD5)
            )
            cred["passwordHashSHA512"] = crypt.crypt(
                cleartext_password, crypt.mksalt(crypt.METHOD_SHA512)
            )
        return
