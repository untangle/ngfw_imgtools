"""Fetches lists of IPs."""

import argparse
import hashlib
import ipaddress
import json
import os
import re
import signal
import subprocess
import sys
from typing import Optional

import idna
import requests

from sync.board_util import BoardUtil
from sync.common import Logger
from sync.file_util import FileUtil

logger = Logger.getInstance()


def get_pid(name: str) -> int:
    """Gets the PID for the provided process name.

    Throws an exception if finds multiple PIDs for process name.
    Args:
        name (str): Name of the process to get the PID for.
    """
    return int(subprocess.check_output(["pidof", name]))


def get_api_endpoint():
    setting_file = FileUtil.locate_file("/etc/config/settings.json")
    http_port = 1024

    if os.path.isfile(setting_file):
        try:
            with open(setting_file) as f:
                data = json.load(f)
                http_port = data.get("system", {}).get("httpPort", http_port)
        except (OSError, json.JSONDecodeError) as e:
            logger.Info(f"Failed to read {setting_file}: {e}")

    apiEndpoint = f"http://127.0.0.1:{http_port}/api/"
    return apiEndpoint


def notify_process(*processes: str) -> None:
    """Notifies the processes with SIGHUP.

    Args:
        processes (str...): Name of the processes to signal.
    """

    for process in processes:
        try:
            if BoardUtil.is_platform_os_eos():
                subprocess.run(["/usr/bin/updateSysdbSignal"], check=False)
            elif BoardUtil.is_platform_vittoria():
                process = "packetd"
                sig = signal.SIGHUP.value
                api_url = f"{get_api_endpoint()}/sendsignal/{process}/{sig}"
                try:
                    r = requests.get(api_url, verify=True)
                    if r.status_code == 200:
                        logger.info("Successfully notified store of appliance settings changes.")
                except Exception as err:
                    return False, f"Exception: {err!s}"
            else:
                pid = get_pid("packetd")
                os.kill(pid, signal.SIGHUP)
                # get_pid exception
        except subprocess.SubprocessError:  # noqa: PERF203
            logger.exception("Error getting the PID for process: packetd")
            # Kill exception
        except OSError:
            logger.exception("Error signaling %s with SIGHUP: ", str(process))
        except Exception:
            logger.exception("Error signaling %s with SIGHUP: ", str(process))


class FetchIpList:
    """A class for fetching and storing IP addresses from a given source
    URL."""

    report_endpoint = "http://localhost:5555"

    @staticmethod
    def is_valid_ip(ip: str) -> Optional[bool]:
        """Check if the provided IP address is valid.

        Args: ip (str): IP address to validate.
        """
        try:
            # Check if the ip is an IP Range
            ips = ip.split("-", maxsplit=1)
            if len(ips) == 2:
                start = ipaddress.ip_address(ips[0])
                end = ipaddress.ip_address(ips[1])
                if start.version != end.version or start > end:
                    return False
            else:
                # ip is an address with or without CIDR
                ipaddress.ip_network(ip, strict=False)
            return True
        except ValueError:
            return False

    def is_valid_fqdn(self, fqdn: str) -> Optional[bool]:
        """Check if the provided string matches the FQDN's regex.
        This will support the fqdns like www.abc.*.com, *.xyz.com www.a*.b.c.in, www.amazon.* etc

        Args: fqdn (str): If the parsed data using parse_ip_list is not ip then it can be fqdn or adblock style fqdn.
        """
        fqdn_regex = r"(?:[a-zA-Z0-9\*](?:[a-zA-Z0-9\-\*]{0,61}[a-zA-Z0-9\*])?(?:\.[a-zA-Z0-9\*](?:[a-zA-Z0-9\-\*]{0,61}[a-zA-Z0-9\*])?)*\.(?:[a-zA-Z]{2,63}|\*))"
        try:
            fqdn_pattern = re.compile(fqdn_regex)
            return bool(fqdn_pattern.fullmatch(fqdn))
        except (re.error, ValueError):
            return False

    def is_valid_adblock_style_fqdn(self, fqdn: str) -> Optional[bool]:
        """Check if the provided string matches the Adblock style FQDN's regex.
        This will support the fqdns or ips like ||abc.com^, |xyz.in^, ||10.53.26.3^, |10.47.34.9^ etc

        Args: fqdn (str): If the parsed data using parse_ip_list is not ip then it can be fqdn or adblock style fqdn.
        """
        adblock_regex = r"\|{1,2}(?:\d{1,3}(?:\.\d{1,3}){3}|[a-zA-Z0-9*.-]+\.[a-zA-Z*]{2,})[\^|]"
        try:
            adblock_pattern = re.compile(adblock_regex)
            if adblock_pattern.fullmatch(fqdn):
                return "*" not in fqdn
            return False
        except re.error:
            return False

    @staticmethod
    def idna_encode_fqdn(fqdn: str) -> str:
        """
        Encodes a (possibly wildcard) FQDN to IDNA/Punycode using regex for splitting.
        Handles wildcards by encoding each label separately, preserving '*' and '.'.
        This will convert Unicode to Punycode (e.g., 'gооgle.com' to 'xn--gogle-lpm.com')
        and also normalize standard ASCII domains (e.g., 'google.com' to 'google.com').
        This will raise an IDNAError if the domain is invalid.
        For wildcard domains, we need to handle each part separately. So we split the FQDN
        by '.' or '*' and encode each part separately. This is necessary because IDNA encoding does not support wildcards directly. We will rejoin the parts with .' or '*' after encoding.
        """
        # Split by '.' or '*' and keep them.
        parts = re.split(r"([.*])", fqdn)
        encoded_parts = [
            idna.encode(part).decode("ascii") if part not in {".", "*", ""} else part
            for part in parts
        ]
        return "".join(encoded_parts)

    @staticmethod
    def preprocess_prefix_suffix(fqdn_candidate: str) -> str:
        """
        Preprocesses a line to extract the FQDN part by removing adblock-style prefixes and suffixes.

        Args:
            fqdn_candidate (str): A line containing a domain or IP in adblock-style format.

        Returns:
            str: The extracted FQDN part of the line.
        """
        # The idna library works best on individual domain labels or full domain names.
        # Your blocklist lines might have ||, ^, or other prefixes/suffixes.
        # We need to extract the "naked" FQDN part for idna conversion.
        if fqdn_candidate.startswith("||") and fqdn_candidate.endswith("^"):
            fqdn_candidate = fqdn_candidate[2:-1]
        elif fqdn_candidate.startswith("|") and fqdn_candidate.endswith("^"):
            fqdn_candidate = fqdn_candidate[1:-1]
        return fqdn_candidate

    @staticmethod
    def postprocess_prefix_suffix(original_line: str, normalized_fqdn: str) -> str:
        """
        Postprocesses a normalized FQDN to restore adblock-style prefixes and suffixes.

        Args:
            original_line (str): The original line containing the domain or IP.
            normalized_fqdn (str): The normalized FQDN after IDNA processing.

        Returns:
            str: The line with the normalized FQDN restored in its original format.
        """
        # Reconstruct the line with the Punycode FQDN if it was an adblock style, etc.
        # This ensures your regexes still work on the blocklist format.
        if original_line.startswith("||") and original_line.endswith("^"):
            normalized_line = f"||{normalized_fqdn}^"
        elif original_line.startswith("|") and original_line.endswith("^"):
            normalized_line = f"|{normalized_fqdn}^"
        else:
            # Assume it was a plain FQDN
            normalized_line = normalized_fqdn
        return normalized_line

    @staticmethod
    def normalize_lines_to_ascii(entries: list[str]) -> list[str]:
        """
        Normalizes a list of string entries to ASCII/Punycode form, handling internationalized domain names (IDNs).
        Each entry is processed to extract the FQDN (Fully Qualified Domain Name) part, which is then normalized using IDNA encoding.
        If the entry is a valid IP address, it is left unchanged. If the entry contains an invalid domain name or an error occurs
        during normalization, the original entry is preserved. The normalized or original lines are appended to the processed_lines list and returned.
        Args:
            entries (list[str]): List of string entries to normalize, typically containing domain names or IP addresses.
        Returns:
            list[str]: The processed_lines list with normalized or original entries appended.
        """
        processed_lines = []
        # Normalize each relevant line for Punycode
        for entry in entries:
            # Keeping the original for debugging/logging
            original_line = entry

            # Attempt to normalize the line to Punycode/ASCII form. This is critical for handling international
            # domain names. idna.encode will convert Unicode to Punycode, and also validate. If it's already
            # ASCII, it returns it unchanged. If it's invalid IDN, it raises an exception.
            try:
                # Examining here to extract the FQDN part from adblock style
                fqdn_candidate = FetchIpList.preprocess_prefix_suffix(entry)

                # Check if it looks like an IP first to avoid unnecessary IDNA processing
                if FetchIpList.is_valid_ip(fqdn_candidate):
                    # IPs don't get Punycode'd
                    processed_lines.append(entry)
                    continue

                normalized_fqdn = FetchIpList.idna_encode_fqdn(fqdn_candidate)
                # Examining here to extract the FQDN part from adblock style
                normalized_line = FetchIpList.postprocess_prefix_suffix(
                    original_line, normalized_fqdn
                )
                processed_lines.append(normalized_line)

            except idna.IDNAError:
                # This means the domain name is invalid according to IDNA standards. We still
                # add the original_line, if it's to be ruled out then regex would do it.
                processed_lines.append(original_line)
            except Exception:
                # General error during processing, e.g., if it's not a domain at all
                # Add the original_line, if it's to be ruled out then regex would do it.
                processed_lines.append(original_line)
        return processed_lines

    @staticmethod
    def process_for_punycode(text: str) -> list[str]:
        """
        Processes the provided text for Punycode normalization. This function will
        convert non-ASCII domain names to Punycode format using the idna library.
        Args:
            text (str): Text containing domain names or IPs to normalize.
            It can contain ASCII as well as non-ASCII characters.
        Returns:
            list[str]: List of normalized Punycode domain names.
        """
        processed_lines = []
        lines = text.splitlines()
        for line in lines:
            line = line.strip()
            # Discard blank lines and lines starting with common comment indicators.
            if not line or line.startswith(("!", "#")):
                continue

            entries = line.split()
            processed_lines.extend(FetchIpList.normalize_lines_to_ascii(entries))

        return processed_lines

    def parse_ip_list(self, ip_regex, text: str):
        """Parses a List of valid IPs from the text using the given Regex.

        Returns list: list of valid IP strings.

        Args:
            ip_regex (re.Pattern[any]): Regex to match IP candidates.
            text (str): Text to be parsed.
        """
        text = "\n".join(self.process_for_punycode(text))
        if ip_regex != "^\\S{2,256}":
            r"""when finding all matches, sometimes we have domain names or ip ranges in the comments section.
            With existing ip regex as well as with updated fqdn related regex, it is extracting the ips or fqdns from the comments
            For example the lines
            (! Homepage: https://laniksj.github.io/ubo-filters) and (# should not have ranges like 192.168.57.10-192.168.57.20 in this list)
            The existing regex is extracting 192.168.57.10-192.168.57.20, and newly added regex is matching laniksj.github.io
            To avoid this we are doing re.match(r'^(\|\||\||\*|[a-zA-Z0-9])
            Because the new regex will support ips which start with numbers or ' or " or ::(ipv6), fqdns and it's wildcard * which may start with *, character
            and adblock styled fqdns which start with | or ||
            """
            text = "\n".join(
                line
                for line in text.splitlines()
                if re.match(r"^(\|\||\||\*|[a-zA-Z0-9]|\'|\"|::)", line.strip())
            )
        ip_list = []
        ip_addresses = re.finditer(
            ip_regex,
            text,
            re.MULTILINE,
        )
        for ip in ip_addresses:
            ip_str = ip.group()
            if (
                self.is_valid_ip(ip_str)
                or self.is_valid_adblock_style_fqdn(ip_str)
                or self.is_valid_fqdn(ip_str)
            ):
                ip_list.append(ip_str)
        return ip_list

    def fetch_ips_from_source(
        self, source_url, ip_regex, file_path=None, disable_cert_check=False
    ):
        """Fetches a list of IP addresses from the provided source URL and validates them.

        Uses HTTP cache headers (ETag and Last-Modified) to avoid unnecessary downloads
        when content hasn't changed. If the server returns 304 Not Modified, the existing
        file is preserved and an empty list is returned with success status.

        Returns: tuple[list, str, bool]:
            - list of IP strings
            - error message string (empty if successful)
            - boolean indicating if content was modified (False for 304 responses)

        Args:
            source_url (str): URL of the source containing IP addresses.
            ip_regex (str): Regex pattern to match IP addresses.
            file_path (str, optional): Path to the IP list file (for cache management).
            disable_cert_check (bool): If True, SSL certificate verification is disabled.
        """
        ip_list = []
        error_msg = ""
        content_modified = True  # Assume modified unless we get 304

        try:
            # Prepare headers for conditional request
            headers = {}
            if file_path:
                cache_data = self.load_cache_headers(file_path)
                if cache_data.get("etag"):
                    headers["If-None-Match"] = cache_data["etag"]
                    logger.debug("Using ETag for conditional request: %s", cache_data["etag"])
                if cache_data.get("last_modified"):
                    headers["If-Modified-Since"] = cache_data["last_modified"]
                    logger.debug(
                        "Using Last-Modified for conditional request: %s",
                        cache_data["last_modified"],
                    )

            response = requests.get(
                source_url, headers=headers, verify=(not disable_cert_check), timeout=5
            )

            if response.status_code == 200:
                # Content was modified or no cache headers were sent
                ip_list = self.parse_ip_list(ip_regex, response.content.decode("utf-8-sig"))

                # Save cache headers for future requests
                if file_path:
                    etag = response.headers.get("ETag")
                    last_modified = response.headers.get("Last-Modified")
                    if etag or last_modified:
                        self.save_cache_headers(file_path, etag, last_modified)
                        logger.info("Saved cache headers for future requests")

            elif response.status_code == 304:
                # Content has not been modified since last fetch
                logger.info("Content not modified (HTTP 304). Using existing file.")
                content_modified = False
                # ip_list remains empty, which signals to use the existing file

            else:
                error_msg = f"Error fetching IP addresses. Status Code: {response.status_code}"

        except requests.exceptions.RequestException as e:
            error_msg = f"Error fetching IP addresses. RequestException: {e}"
        except Exception as e:
            error_msg = f"Error fetching IP addresses. Unknown exception occurred: {e}"

        if error_msg:
            logger.error(error_msg)

        return ip_list, error_msg, content_modified

    def save_ips_to_file(self, ip_list, file_path, fetch_list_success, content_modified=True):
        """Saves the provided list of IP addresses to a file if the content's
        hash has changed.

        In edge cases where we don't write to the file:
            1. fetching failed (so the ip list is empty) AND another successful file already exists
            2. content was not modified (HTTP 304) - the existing file is already up-to-date

        Returns True if the file was saved.
        Args:
            ip_list (list): List of IP addresses to save.
            file_path (str): Path of the file to save the IP addresses.
            fetch_list_success (bool): whether or not the list was fetched successfully
            content_modified (bool): whether the content was modified (False for 304 responses)
        """
        # If content was not modified (304), don't rewrite the file
        if not content_modified:
            logger.info("Content not modified, keeping existing file: %s", file_path)
            return False

        # If the ip list is empty and the file exists, leave the old success in-place
        if not fetch_list_success and os.path.isfile(file_path):
            return False

        original_md5 = self.md5_of_file(file_path)
        text = "\n".join(ip_list)
        md5 = hashlib.md5(text.encode("utf-8")).hexdigest()
        # The file changed if the new MD5 hash is different than the old one
        file_changed = md5 != original_md5
        if file_changed:
            try:
                with open(file_path, "w") as file:
                    file.write(text)
                logger.info("IP addresses saved to %s", str(file_path))
            except OSError:
                logger.exception("Error saving IP addresses to file:")
                file_changed = False
        return file_changed

    def md5_of_file(self, file_path: str):
        """Calculates the MD5 hash of the file.

        Args:
            file_path (str): Path of the file to save the IP addresses.
        """
        md5 = ""
        try:
            with open(file_path) as file_to_check:
                # read contents of the file
                data = file_to_check.read()
                # calculate the md5 of the file
                md5 = hashlib.md5(data.encode("utf-8")).hexdigest()
        except OSError:
            # ignore any errors reading file or if it doesn't exist
            pass
        return md5

    @staticmethod
    def get_cache_file_path(file_path: str) -> str:
        """Gets the cache metadata file path for a given IP list file.

        Args:
            file_path (str): Path of the IP list file.

        Returns:
            str: Path to the cache metadata file.
        """
        return f"{file_path}.cache"

    def load_cache_headers(self, file_path: str) -> dict:
        """Loads HTTP cache headers from the cache file.

        Args:
            file_path (str): Path of the IP list file.

        Returns:
            dict: Dictionary containing 'etag' and 'last_modified' if available.
        """
        cache_file = self.get_cache_file_path(file_path)
        cache_data = {}

        try:
            if os.path.isfile(cache_file):
                with open(cache_file) as f:
                    cache_data = json.load(f)
                logger.debug("Loaded cache headers from %s", cache_file)
        except (OSError, json.JSONDecodeError) as e:
            logger.warning("Failed to load cache headers from %s: %s", cache_file, e)

        return cache_data

    def save_cache_headers(
        self,
        file_path: str,
        etag: Optional[str],
        last_modified: Optional[str],
    ) -> None:
        """Saves HTTP cache headers to the cache file.

        Note: last_fetch_time is managed by the dispatcher, not this method.

        Args:
            file_path (str): Path of the IP list file.
            etag (Optional[str]): ETag header value from the HTTP response.
            last_modified (Optional[str]): Last-Modified header value from the HTTP response.
        """
        cache_file = self.get_cache_file_path(file_path)
        cache_data = {}

        # Load existing cache data to preserve last_fetch_time (managed by dispatcher)
        try:
            if os.path.isfile(cache_file):
                with open(cache_file) as f:
                    cache_data = json.load(f)
        except (OSError, json.JSONDecodeError):
            pass

        if etag:
            cache_data["etag"] = etag
        if last_modified:
            cache_data["last_modified"] = last_modified

        try:
            with open(cache_file, "w") as f:
                json.dump(cache_data, f, indent=2)
            logger.debug("Saved cache metadata to %s", cache_file)
        except OSError as e:
            logger.warning("Failed to save cache metadata to %s: %s", cache_file, e)

    def send_dynamic_lists_report(
        self, guid: str, ip_list: list, fetch_list_success: bool
    ) -> None:
        """Send a report of the dynamic list to reportd.

        Args:
            guid (str): GUID of the dynamic list config (id field).
            ip_list (list): List of IP addresses.
            fetch_list_success (bool): True if the fetch operation was successful.
        """
        data = {"uuid": guid, "num_entries": len(ip_list), "status": fetch_list_success}
        try:
            # Try updating existing report with PUT
            # TODO: add timeout to put request
            response = requests.put(
                f"{self.report_endpoint}/api/reports/dynamiclists/{guid}", json=data
            )
            if response.status_code == 200:
                logger.info("Success Updating report")
            elif response.status_code == 404:
                # Try adding new report with POST
                # TODO: add timeout to put request
                add_response = requests.post(
                    f"{self.report_endpoint}/api/reports/dynamiclists", json=data
                )
                if add_response.status_code == 200:
                    logger.info("Success Adding report")
                else:
                    logger.error(
                        "Error adding report. Status Code: %s Body: %s",
                        str(add_response.status_code),
                        str(add_response.content),
                    )
            else:
                logger.error(
                    "Error updating report. Status Code: %s Body: %s",
                    str(response.status_code),
                    str(response.content),
                )
        except requests.exceptions.RequestException:
            logger.exception("Error sending:")

    def notify_of_changes(self) -> None:
        """Notify packetd to reload block lists."""
        notify_process("packetd")

    def send_alert(self, severity: str, alert_type: str, message: str, params: str) -> None:
        """
        Sends an alert using the external /usr/bin/send-alert program.
        """
        cmd = [
            "/usr/bin/send-alert",
            "-s",
            severity,
            "-t",
            alert_type,
            "-m",
            message,
            "-p",
            params,
        ]
        try:
            result = subprocess.run(cmd, check=False, capture_output=True, text=True)
            logger.debug("Executed command: %s", " ".join(cmd))
            logger.debug("send-alert return code: %d", result.returncode)
            if result.stdout:
                logger.debug("send-alert stdout: %s", result.stdout.strip())
            if result.stderr:
                logger.error("send-alert stderr: %s", result.stderr.strip())
        except FileNotFoundError:
            logger.error("The /usr/bin/send-alert command was not found.")
        except Exception as e:
            logger.error("Failed to execute send-alert: %s", e)


def main() -> None:
    """Fetches the IP list and saves the list in a file.

    If fetching fails, the script fails. However, if saving to a file
    fails, we don't need to alert the user. So the script is still
    successful.
    """

    parser = argparse.ArgumentParser(
        prog="Fetch IP list",
        description="Fetches lists of IPs",
    )

    parser.add_argument("id", help="GUID")
    parser.add_argument("source_url", help="The source URL of the list")
    parser.add_argument("file_path", help="The output file path")
    parser.add_argument(
        "disable_cert_check",
        help="If set, will ignore certification checks in HTTP requests",
        choices=["True", "true", "false", "False"],
        metavar="disable_cert_check [True, False]",
    )
    parser.add_argument(
        "ip_regex",
        help="Regex to be used to parse the source text",
        type=str,
    )

    args = parser.parse_args()

    # Necessary for correct bool casting
    if args.disable_cert_check in ["True", "true"]:
        args.disable_cert_check = True
    else:
        args.disable_cert_check = False

    # Validate regex
    try:
        re.compile(args.ip_regex)
    except Exception as e:
        logger.critical("Invalid regex: %s", str(e))
        sys.exit(1)

    fetch = FetchIpList()
    # Example source_url = "http://opendbl.net/lists/etknown.list"

    ip_list, fetch_error, content_modified = fetch.fetch_ips_from_source(
        args.source_url, args.ip_regex, args.file_path, args.disable_cert_check
    )
    fetch_list_success = fetch_error == ""

    # For 304 responses, we consider it a success but don't update the file
    # The existing file is already up-to-date
    if not content_modified and fetch_list_success:
        logger.info("Content not modified (HTTP 304). List is up-to-date.")
        # Still report success with the count from the existing file
        existing_ip_list = []
        try:
            if os.path.isfile(args.file_path):
                with open(args.file_path) as f:
                    existing_ip_list = [line.strip() for line in f if line.strip()]
        except OSError:
            logger.warning("Could not read existing file for count: %s", args.file_path)
        fetch.send_dynamic_lists_report(args.id, existing_ip_list, fetch_list_success)
        # No need to notify of changes since content hasn't changed
        sys.exit(0)

    # report status, even if fetch is unsuccessful
    fetch.send_dynamic_lists_report(args.id, ip_list, fetch_list_success)
    file_written = fetch.save_ips_to_file(
        ip_list, args.file_path, fetch_list_success, content_modified
    )
    if fetch_list_success and file_written:
        fetch.notify_of_changes()
    elif not fetch_list_success:
        fetch.send_alert(
            "ERROR", "DYNAMICLISTS", "DYNAMICLISTS_DOWNLOAD_FAILED", f"error={fetch_error}"
        )
        # We want script failure when the list is not fetched properly
        sys.exit(2)


if __name__ == "__main__":
    main()
