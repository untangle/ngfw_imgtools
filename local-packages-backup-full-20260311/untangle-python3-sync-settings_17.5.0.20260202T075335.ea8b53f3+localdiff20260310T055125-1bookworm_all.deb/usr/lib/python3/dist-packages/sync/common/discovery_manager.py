"""This class is responsible for managing discovery service settings"""

import collections
import copy

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

MIN_AUTO_INTERVAL = 60 * 60
MAX_AUTO_INTERVAL = 365 * 24 * 60 * 60
AUTO_INTERVAL_INCREMENT = 60 * 60

logger = Logger.getInstance()


class DiscoveryManager(Manager):
    """DiscoveryManager manages the discovery service settings"""

    settings_service_key = "discovery"
    settings_service_template = {
        "enabled": True,
        "plugins": [
            {"type": "lldp", "enabled": True, "autoInterval": 86400},
            {"type": "nmap", "enabled": False, "autoInterval": 86400},
            {"type": "neighbour", "enabled": True, "autoInterval": 86400},
        ],
    }

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        logger.info("Initializing settings")
        settings_file.settings[DiscoveryManager.settings_service_key] = copy.deepcopy(
            DiscoveryManager.settings_service_template
        )

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""

        discovery_settings = settings_file.settings.get(self.settings_service_key)

        # missing discovery settings
        if discovery_settings is None:
            settings_file.settings[DiscoveryManager.settings_service_key] = copy.deepcopy(
                DiscoveryManager.settings_service_template
            )

    def validate_settings(self, settings_file) -> None:
        discovery_settings = settings_file.settings.get("discovery")

        if discovery_settings is None:
            raise SettingsException(message="network_discovery_missing_settings")

        discovery_enabled = discovery_settings.get("enabled")
        if discovery_enabled is None or not isinstance(discovery_enabled, bool):
            raise SettingsException(message="network_discovery_invalid_setting", vars=["enabled"])

        discovery_plugins = discovery_settings.get("plugins")
        if discovery_plugins is None or not isinstance(discovery_plugins, list):
            raise SettingsException(message="network_discovery_invalid_setting", vars=["plugins"])

        # Only validate plugin settings if discovery settings are enabled
        if discovery_enabled:
            validate_plugin_list(
                get_plugin_types_list(discovery_plugins),
                get_plugin_types_list(self.settings_service_template.get("plugins")),
            )

            for plugin in discovery_plugins:
                validate_plugin_settings(plugin)


# Validates that the list of discovery plugins contains all the expected plugins
def validate_plugin_list(expected_plugins, actual_plugins) -> None:
    if collections.Counter(expected_plugins) != collections.Counter(actual_plugins):
        raise SettingsException(message="network_discovery_invalid_setting", vars=["plugins"])


# From a dict of plugins, go through and get a list of all the plugin types contained
def get_plugin_types_list(plugin_list):
    plugin_types = []

    for plugin in plugin_list:
        plugin_type = plugin.get("type")
        if plugin_type is None or not isinstance(plugin_type, str):
            raise SettingsException(message="network_discovery_invalid_setting", vars=["type"])

        plugin_types.append(plugin_type)

    return plugin_types


# Validates discovery plugin settings. Raises an exception if the settings are invalid
def validate_plugin_settings(plugin) -> None:
    plugin_type = plugin.get("type")
    if plugin_type is None or not isinstance(plugin_type, str):
        raise SettingsException(message="network_discovery_invalid_plugin_setting", vars=["type"])

    plugin_enabled = plugin.get("enabled")
    if plugin_enabled is None or not isinstance(plugin_enabled, bool):
        raise SettingsException(
            message="network_discovery_invalid_plugin_setting", vars=[plugin_type, "enabled"]
        )

    if plugin_enabled:
        plugin_auto_interval = plugin.get("autoInterval")
        if plugin_auto_interval is None or not isinstance(plugin_auto_interval, int):
            raise SettingsException(
                message="network_discovery_invalid_plugin_setting",
                vars=[plugin_type, "autoInterval"],
            )

        if plugin_auto_interval < MIN_AUTO_INTERVAL or plugin_auto_interval > MAX_AUTO_INTERVAL:
            # This exception ends up getting displayed to the user. Since the user sees hours in the UI, but
            # the internal values are seconds convert the internal numbers back to hours
            raise SettingsException(
                message="network_discovery_invalid_plugin_setting",
                vars=[plugin_type, "autoInterval"],
            )


registrar.register_manager(DiscoveryManager())
