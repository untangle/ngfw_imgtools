class Validator:
    def validate(self, object) -> None:
        """
        validate verifies a configuration object.
        """
