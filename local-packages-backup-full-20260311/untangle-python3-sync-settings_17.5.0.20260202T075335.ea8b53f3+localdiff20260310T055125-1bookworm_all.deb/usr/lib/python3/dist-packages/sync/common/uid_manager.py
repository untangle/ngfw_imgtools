"""
Abstract UID Manager - Base class for platform-specific UID managers.

This manager ensures that a UID file exists at the appropriate location
based on the platform, and triggers pyconnector restart when the UID is created.
"""

import os
import uuid
from abc import ABC, abstractmethod

from sync import Manager, registrar
from sync.common import Logger
from sync.perms_util import regain_permissions

logger = Logger.getInstance()


class UIDManager(Manager, ABC):
    """
    Abstract base class for UID Manager.

    Platform-specific implementations should inherit from this class
    and implement the get_config_dir() method to specify where the
    UID file should be stored.
    """

    uid_filename = "uid"

    def __init__(self) -> None:
        super().__init__()

    @abstractmethod
    def get_config_dir(self) -> str:
        """
        Get the platform-specific configuration directory for the UID file.

        Returns:
            str: The configuration directory path where the UID file should be stored.
                 Returns None if UID generation is not applicable for this platform.
        """

    def initialize(self) -> None:
        """Initialize this module and register with the settings file."""
        registrar.register_settings_file("settings", self)
        registrar.register_file(
            self.get_config_dir() + "/" + self.uid_filename, "restart-uid", self
        )

    def get_uid_path(self, prefix) -> tuple[str, str]:
        """
        Get the platform-specific UID directory and file path.

        Returns:
            tuple: (config_directory, uid_file_path) or ("", "") if not applicable
        """
        config_dir = (prefix if prefix is not None else "") + self.get_config_dir()

        if not config_dir:
            return "", ""

        uid_path = os.path.join(config_dir, self.uid_filename)

        return config_dir, uid_path

    def _ensure_uid_exists(self, prefix) -> None:
        """
        Ensure the UID file exists, creating it if necessary.
        Registers the UID file to trigger restart-uid operation.
        """
        _, system_uid_path = self.get_uid_path("")

        with regain_permissions():
            if os.path.isfile(system_uid_path):
                return

        # If system UID file doesn't exist, then proceed with the checks on UID file under prefix's config directory.
        config_dir, uid_path = self.get_uid_path(prefix)

        if not config_dir or not uid_path:
            logger.info("UID generation not applicable for this platform")
            return

        # Create config directory if it doesn't exist, added try catch for Unit tests failing with permission error inspite of mocking
        try:
            os.makedirs(config_dir, exist_ok=True)
        except (FileNotFoundError, PermissionError):
            logger.info(f"Skipping directory creation for path: '{config_dir}' due to error.")
            return

        # Generate UID if none exists
        if not os.path.isfile(uid_path):
            generated_uuid = str(uuid.uuid4())
            logger.info(f"Generated UUID: {generated_uuid} at: {uid_path}")

            with open(uid_path, "w") as uid_file:
                uid_file.write(generated_uuid + "\n")
        else:
            logger.info(f"UID already exists at: {uid_path}")

    def create_settings(self, settings_file, prefix, delete_list, filename=None) -> None:
        """
        Create the UID file if it doesn't exist during settings creation.

        This is called when sync-settings is run with the -c flag.
        """
        self._ensure_uid_exists(prefix)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Sync UID settings - ensures UID file exists.

        This is called during normal sync-settings operation.
        """
        self._ensure_uid_exists(prefix)
