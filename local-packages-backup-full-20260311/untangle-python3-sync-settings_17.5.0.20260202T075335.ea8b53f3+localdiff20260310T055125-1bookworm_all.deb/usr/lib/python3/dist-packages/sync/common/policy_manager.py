import copy
import functools
import ipaddress
import json

from sync import Manager, network_util, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

from .const import MFW_CONFIG_CAPTIVEPORTAL, MFW_CONFIG_WANPOLICY

# default values for policy manager
default_policy_manager_config = {
    "enabled": False,
    "conditions": [],
    "condition_groups": [],
    "configurations": [],
    "objects": [],
    "object_groups": [],
    "rules": [],
    "policies": [],
}

# possible condition fields and condition operators
condition_fields = [
    "APPLICATION",
    "APPLICATION_NAME",
    "APPLICATION_NAME_INFERRED",
    "APPLICATION_CATEGORY",
    "APPLICATION_CATEGORY_INFERRED",
    "APPLICATION_PRODUCTIVITY",
    "APPLICATION_PRODUCTIVITY_INFERRED",
    "APPLICATION_RISK",
    "APPLICATION_RISK_INFERRED",
    "CERT_SUBJECT_CN",
    "CERT_SUBJECT_DNS",
    "CERT_SUBJECT_O",
    "CLIENT_ADDRESS",
    "CLIENT_PORT",
    "CLIENT_APPLICATION",
    # Treated the same as SOURCE_INTERFACE_NAME
    "CLIENT_INTERFACE_NAME",
    # Treated the same as SOURCE_INTERFACE_TYPE
    "CLIENT_INTERFACE_TYPE",
    # Treated the same as SOURCE_INTERFACE_ZONE
    "CLIENT_INTERFACE_ZONE",
    "CLIENT_SERVICE",
    "DAY_OF_WEEK",
    "DESTINATION_ADDRESS",
    "DESTINATION_INTERFACE",
    # Treated the same as SERVER_INTERFACE_NAME
    "DESTINATION_INTERFACE_NAME",
    # Treated the same as SERVER_INTERFACE_TYPE
    "DESTINATION_INTERFACE_TYPE",
    # Treated the same as SERVER_INTERFACE_ZONE
    "DESTINATION_INTERFACE_ZONE",
    "SERVER_GEOIP",
    "CLIENT_GEOIP",
    "INTERFACE",
    "IP_PROTOCOL",
    "SERVER_ADDRESS",
    "SERVER_DNS_HINT",
    "SERVER_PORT",
    "SERVER_APPLICATION",
    "SERVER_INTERFACE_NAME",
    "SERVER_INTERFACE_TYPE",
    "SERVER_INTERFACE_ZONE",
    "SERVER_SERVICE",
    "SERVICE",
    "SOURCE_ADDRESS",
    "SOURCE_INTERFACE",
    "SOURCE_INTERFACE_NAME",
    "SOURCE_INTERFACE_TYPE",
    "SOURCE_INTERFACE_ZONE",
    "PROTOCOL_TYPE",
    "TIME_OF_DAY",
    "THREATPREVENTION",
    "VLAN_TAG",
    "HOSTNAME",
    "VRF_NAME",
]

group_condition_operators = ["in", "not_in", "match", "not_match"]
condition_operators = ["==", "!=", "<", ">", "<=", ">=", *group_condition_operators]

object_types = {
    "mfw-object-ipaddress",
    "mfw-object-interfacezone",
    "mfw-object-geoip",
    "mfw-object-service",
    "mfw-object-hostname",
    "mfw-object-domain",
    "mfw-object-user",
    "mfw-object-uno-user",
    "mfw-object-vlantag",
    "mfw-object-application",
    "mfw-object-vrfname",
}

object_group_types = {
    "mfw-object-interfacezone-group",
    "mfw-object-ipaddress-group",
    "mfw-object-geoip-group",
    "mfw-object-service-group",
    "mfw-object-domain-group",
    "mfw-object-user-group",
    "mfw-object-vlantag-group",
    "mfw-object-application-group",
    "mfw-object-hostname-group",
    "mfw-object-vrfname-group",
}

object_rule_types = {
    "mfw-rule-applicationcontrol",
    "mfw-rule-captiveportal",
    "mfw-rule-geoipfilter",
    "mfw-rule-nat",
    "mfw-rule-portforward",
    "mfw-rule-security",
    "mfw-rule-shaping",
    "mfw-rule-wanpolicy",
    "mfw-rule-threatprevention",
    "mfw-rule-webfilter",
    "mfw-rule-dnsfilter",
}

object_condition_group_type = "mfw-object-condition-group"
object_condition_type = "mfw-object-condition"

# List of all valid potential object types
valid_object_types = {
    object_condition_group_type,
    object_condition_type,
    *object_group_types,
    *object_types,
    *object_rule_types,
}

logger = Logger.getInstance()


class PolicyManager(Manager):
    """Policy Manager definition file"""

    def __init__(self) -> None:
        super().__init__()
        self.error_list = []
        self.warning_list = []
        self.VALIDATORS = [
            functools.partial(self.validate_object_list, "conditions"),
            functools.partial(self.validate_object_list, "condition_groups"),
            functools.partial(self.validate_object_list, "objects"),
            functools.partial(self.validate_object_list, "object_groups"),
            functools.partial(self.validate_object_list, "rules"),
            functools.partial(self.validate_configurations),
            functools.partial(self.validate_policies),
        ]

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def sanitize_settings(self, settings_file) -> None:
        if "policy_manager" not in settings_file.settings:
            settings_file.settings["policy_manager"] = default_policy_manager_config

        self.temp_settings = copy.deepcopy(settings_file.settings["policy_manager"])

        if isinstance(self.temp_settings["policies"], list):
            policies = self.temp_settings["policies"]
            for policy in policies:
                if "enabled" not in policy:
                    policy["enabled"] = True

    # method for validating top level properties for policy manager
    def validate_settings(self, settings_file) -> None:
        # We don't want to error when fields are missing, just add them so that below validation can occur in any order
        for key, val in default_policy_manager_config.items():
            if key not in self.temp_settings:
                self.temp_settings[key] = val

        # run all validate_X functions (excluding this one)
        for validator in self.VALIDATORS:
            validator()

        # There's a trade-off to be made here. Either raise only one Exception to match the format laid out in
        # route_manager.py, or stuff multiple errors into one exception. I'm going with the former, but this means
        # fixing sync-settings errors can be whack-a-mole. Ideally there should be a standard way to defer Exceptions
        # across the entirety of sync-settings, and raise them all at the end so that we can:
        # 1. get all errors in one message and fix them
        # 2. Allow parts of new settings that work to be saved, and problems to not be saved
        if len(self.error_list) > 0:
            for error_str in self.error_list:
                logger.error(error_str)
            raise SettingsException(message_str=self.error_list[0])
        if len(self.warning_list) > 0:
            logger.warning(
                "%i warnings occurred while validating policy manager", len(self.warning_list)
            )
            for warning in self.warning_list:
                logger.warning(warning)

    # builds an error string to be printed as an exception, vars are optional. Format borrowed from route_manager.py
    # This should probably eventually be a util function, but is out of scope for this ticket
    def add_error_to_list(self, error, vars=[]) -> None:
        if vars:
            vars = []
        if vars:
            self.error_list.append(json.dumps({"error": error, "vars": vars}))
        else:
            self.error_list.append(error)

    # builds a warning string to be printed as an exception, vars are optional.
    def add_warning_to_list(self, warning, vars=None) -> None:
        if vars is None:
            vars = []
        if vars:
            self.warning_list.append(json.dumps({"warning": warning, "vars": vars}))
        else:
            self.warning_list.append(warning)

    # checks if the passed value is a valid snat address
    # valid values are: single ip / ip range / CIDR
    def is_valid_snat_address(self, value):
        return (
            network_util.is_valid_ipv4(value)
            or self.is_valid_ipv4_range(value)
            or self.is_valid_ipv4_cidr(value)
        )

    # checks if the passed var is an ip range
    def is_valid_ipv4_cidr(self, value):
        try:
            network = ipaddress.ip_network(value, strict=True)
            return network.version == 4
        except ValueError:
            return False

    # checks if the passed var is an ip range
    def is_valid_ipv4_range(self, value):
        try:
            ips = value.split("-", maxsplit=1)
            if len(ips) != 2:
                return False

            start = ipaddress.ip_address(ips[0])
            end = ipaddress.ip_address(ips[1])

            if start.version != end.version or start > end:
                return False

            return start.version == 4
        except ValueError:
            return False

    # method to create error details
    def create_error_vars(self, debug_error, failed_property, failed_value, object_id):
        return [
            {
                "debug": debug_error,
                "failed_property": failed_property,
                "failed_value": failed_value,
                "object": object_id,
            }
        ]

    # checks if the passed var is an ip
    def is_valid_ip(self, ip) -> bool:
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            return False
        else:
            return True

    # Validates a condition. Returns true if valid, otherwise appends
    # an error to the running error list and returns false
    def validate_condition_object(self, condition) -> bool:
        required_items_props = {"op", "type"}
        if condition["type"] != object_condition_type:
            self.add_error_to_list(
                "policy_manager_conditions_invalid_type_err",
                self.create_error_vars(
                    "debug_error_condition_type",
                    "type",
                    condition["type"],
                    condition.get("id", ""),
                ),
            )
        elif isinstance(condition["items"], list):
            sanitized_items = []
            for item in condition["items"]:
                if not required_items_props.issubset(set(item)):
                    self.add_error_to_list("policy_manager_conditions_items_req_err")
                elif item["type"] not in condition_fields:
                    if item["type"] == "":
                        self.add_error_to_list(
                            "policy_manager_conditions_items_type_err",
                            self.create_error_vars(
                                "debug_error_item_type",
                                "type",
                                item["type"],
                                condition.get("id", ""),
                            ),
                        )
                    else:
                        self.add_warning_to_list(
                            "policy_manager_conditions_items_type_unregistered_warn",
                            [item["type"]],
                        )
                        sanitized_items.append(item)
                elif item["op"] not in condition_operators:
                    self.add_error_to_list(
                        "policy_manager_conditions_items_op_err",
                        self.create_error_vars(
                            "debug_error_item_op", "op", item["op"], condition.get("id", "")
                        ),
                    )
                elif "value" in item and not item["value"]:
                    self.add_error_to_list(
                        "policy_manager_conditions_items_value_err",
                        self.create_error_vars(
                            "debug_error_item_value",
                            "value",
                            item["value"],
                            condition.get("id", ""),
                        ),
                    )
                elif "object" in item and not item["object"]:
                    self.add_error_to_list(
                        "policy_manager_conditions_items_object_err",
                        self.create_error_vars(
                            "debug_error_item_object",
                            "object",
                            item["object"],
                            condition.get("id", ""),
                        ),
                    )
                elif item.get("object"):
                    if item.get("value"):
                        self.add_error_to_list(
                            "policy_manager_conditions_items_value_and_object_err",
                            self.create_error_vars(
                                "debug_error_item_value",
                                "value",
                                item["value"],
                                condition.get("id", ""),
                            ),
                        )
                    elif item["op"] not in group_condition_operators:
                        self.add_error_to_list(
                            "policy_manager_conditions_object_groups_op_err",
                            self.create_error_vars(
                                "debug_error_item_op", "op", item["op"], condition.get("id", "")
                            ),
                        )
                    else:
                        sanitized_items.append(item)
                else:
                    sanitized_items.append(item)
            if len(condition["items"]) == len(sanitized_items):
                condition["items"] = sanitized_items
                return True

        return False

    # Validates a condition group. Returns true if valid, otherwise appends
    # an error to the running error list and returns false
    def validate_condition_group_object(self, condition_group) -> bool:
        if condition_group["type"] != object_condition_group_type:
            self.add_error_to_list(
                "policy_manager_condition_groups_invalid_type_err",
                self.create_error_vars(
                    "debug_error_condition_group_type",
                    "type",
                    condition_group["type"],
                    condition_group.get("id", ""),
                ),
            )
        elif not isinstance(condition_group["items"], list):
            self.add_error_to_list(
                "policy_manager_condition_groups_invalid_items_type_err",
                self.create_error_vars(
                    "debug_error_condition_group_items",
                    "items",
                    condition_group["items"],
                    condition_group.get("id", ""),
                ),
            )
        else:
            return True

        return False

    # Validates an object. Returns true if valid, otherwise appends an error
    # to the running error list and returns false
    def validate_object(self, object) -> bool:
        if object["type"] not in object_types:
            self.add_error_to_list("policy_manager_objects_type_err", [object["type"]])
        elif not isinstance(object["items"], list):
            self.add_error_to_list(
                "policy_manager_objects_invalid_items_type_err",
                self.create_error_vars(
                    "debug_error_object_items", "items", object["items"], object.get("id", "")
                ),
            )
        else:
            return True

        return False

    # Validates an object groups. Returns true if valid, otherwise appends an error
    # to the running error list and returns false
    def validate_object_group(self, object_group) -> bool:
        if not object_group:
            object_group = []
        if object_group["type"] not in object_group_types:
            self.add_error_to_list(
                "policy_manager_object_groups_type_err",
                self.create_error_vars(
                    "debug_error_object_group_type",
                    "type",
                    object_group["type"],
                    object_group.get("id", ""),
                ),
            )
        elif not isinstance(object_group["items"], list):
            self.add_error_to_list(
                "policy_manager_object_group_invalid_items_type_err",
                self.create_error_vars(
                    "debug_error_object_group_items",
                    "items",
                    object_group["items"],
                    object_group.get("id", ""),
                ),
            )
        else:
            return True

        return False

    # Validates a rule. Returns true if valid, otherwise appends an error
    # to the running error list and returns false
    def validate_rule(self, rule) -> bool:
        required_fields = {"id", "name", "type", "conditions", "action"}
        action_types = [
            "ACCEPT",
            "REJECT",
            "SET_CONFIGURATION",
            "DROP",
            "SNAT",
            "DNAT",
            "MASQUERADE",
            "SET_PRIORITY",
            "WAN_POLICY",
        ]

        if not required_fields.issubset(set(rule)):
            self.add_error_to_list("policy_manager_rules_req_err")
        elif not isinstance(rule["conditions"], list):
            self.add_error_to_list(
                "policy_manager_rules_invalid_conditions_err",
                self.create_error_vars(
                    "debug_error_rule_conditions",
                    "conditions",
                    rule["conditions"],
                    rule.get("id", ""),
                ),
            )
        elif rule["type"] not in object_rule_types:
            self.add_error_to_list(
                "policy_manager_rules_type_err",
                self.create_error_vars(
                    "debug_error_rule_type", "type", rule["type"], rule.get("id", "")
                ),
            )
        elif not isinstance(rule["action"], dict) or rule["action"]["type"] not in action_types:
            self.add_error_to_list(
                "policy_manager_rules_type_err",
                self.create_error_vars(
                    "debug_error_rule_action", "action", rule["action"], rule.get("id", "")
                ),
            )
        elif rule["action"]["type"] == "SNAT" and not (
            "snat_address" in rule["action"]
            and self.is_valid_snat_address(rule["action"]["snat_address"])
        ):
            self.add_error_to_list(
                "policy_manager_rules_invalid_snat",
                self.create_error_vars(
                    "debug_error_rule_action", "action", rule["action"], rule.get("id", "")
                ),
            )
        elif rule["action"]["type"] == "DNAT" and not (
            "dnat_address" in rule["action"] and self.is_valid_ip(rule["action"]["dnat_address"])
        ):
            self.add_error_to_list(
                "policy_manager_rules_invalid_dnat",
                self.create_error_vars(
                    "debug_error_rule_action", "action", rule["action"], rule.get("id", "")
                ),
            )
        else:
            return True

        return False

    # Validates an object list. The conditions, conditions_groups, objects, rules and object_groups
    # lists can all contain any variety of objects. Validates the list of objects provided
    def validate_object_list(self, list_type) -> None:
        valid_conditions = []
        if isinstance(self.temp_settings[list_type], list):
            for object in self.temp_settings[list_type]:
                type = object.get("type")
                is_rule = type in object_rule_types

                if type not in valid_object_types:
                    self.add_error_to_list("policy_manager_conditions_invalid_type_err", [type])
                elif is_rule and self.validate_rule(object):
                    valid_conditions.append(object)
                elif not {"id", "name", "type", "items"}.issubset(set(object)) and not is_rule:
                    self.add_error_to_list("policy_manager_objects_req_err")
                elif (
                    (
                        type == object_condition_group_type
                        and self.validate_condition_group_object(object)
                    )
                    or (type == object_condition_type and self.validate_condition_object(object))
                    or (type in object_types and self.validate_object(object))
                    or (type in object_group_types and self.validate_object_group(object))
                ):
                    valid_conditions.append(object)

        self.temp_settings[list_type] = valid_conditions

    # Validate configuration group config parameters. Returns a list of errors.
    def validate_configurations(self) -> None:
        valid_configurations = []
        required_fields = {"id", "name", "type", "settings"}
        type_fields = {
            "mfw-config-geoipfilter",
            "mfw-config-webfilter",
            "mfw-config-threatprevention",
            MFW_CONFIG_WANPOLICY,
            "mfw-config-applicationcontrol",
            MFW_CONFIG_CAPTIVEPORTAL,
            "mfw-config-dnsfilter",
        }

        if isinstance(self.temp_settings["configurations"], list):
            for configuration in self.temp_settings["configurations"]:
                if not required_fields.issubset(set(configuration)):
                    self.add_error_to_list(
                        "policy_manager_configurations_req_err",
                        self.create_error_vars(
                            "debug_error_configuration",
                            "configuration",
                            configuration,
                            configuration.get("id", ""),
                        ),
                    )
                elif configuration["type"] not in type_fields:
                    self.add_error_to_list(
                        "policy_manager_configurations_type_err",
                        self.create_error_vars(
                            "debug_error_configuration_type",
                            "type",
                            configuration["type"],
                            configuration.get("id", ""),
                        ),
                    )
                else:
                    valid_configurations.append(configuration)

        self.temp_settings["configurations"] = valid_configurations

    # Validate policy config parameters. Returns a list of errors.
    def validate_policies(self) -> None:
        valid_policies = []
        required_fields = {"id", "name", "enabled", "conditions", "rules"}

        if isinstance(self.temp_settings["policies"], list):
            for policy in self.temp_settings["policies"]:
                if not required_fields.issubset(set(policy)):
                    self.add_error_to_list(
                        "policy_manager_policies_req_err",
                        self.create_error_vars(
                            "debug_error_policy", "policy", policy, policy.get("id", "")
                        ),
                    )
                elif not isinstance(policy["conditions"], list):
                    self.add_error_to_list(
                        "policy_manager_policies_invalid_conditions_err",
                        self.create_error_vars(
                            "debug_error_policy_condition",
                            "conditions",
                            policy["conditions"],
                            policy.get("id", ""),
                        ),
                    )
                elif not isinstance(policy["rules"], list):
                    self.add_error_to_list(
                        "policy_manager_policies_invalid_rules_err",
                        self.create_error_vars(
                            "debug_error_policy_rules",
                            "rules",
                            policy["rules"],
                            policy.get("id", ""),
                        ),
                    )
                else:
                    valid_policies.append(policy)

        self.temp_settings["policies"] = valid_policies


registrar.register_manager(PolicyManager())
