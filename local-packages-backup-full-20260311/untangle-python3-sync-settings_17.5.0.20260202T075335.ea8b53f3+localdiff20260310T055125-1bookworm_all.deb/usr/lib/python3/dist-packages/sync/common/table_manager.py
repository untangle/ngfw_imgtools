from typing import Any

from sync.common.nft_types import RuleChain, Table


def default_nat_rules_table() -> dict[str, Any]:
    """default nat rules table"""
    default_nat_rules_table = Table(
        name="nat",
        family="ip,ip6",
        chain_type="nat",
        chains=[
            RuleChain(
                name="nat-rules",
                description="The nat-rules chain",
                base=True,
                hook="postrouting",
                priority=95,
                rules=[],
            ),
            RuleChain(
                name="output",
                description="The output chain",
                base=True,
                hook="output",
                priority=100,
                rules=[],
            ),
        ],
    )

    return default_nat_rules_table.get_json()


def default_filter_rules_table() -> dict[str, Any]:
    """default filter rules table"""
    default_filter_rules_table = Table(
        name="filter",
        family="inet",
        chain_type="filter",
        chains=[
            RuleChain(
                name="filter-rules",
                description="The base filter-rules chain",
                base=True,
                hook="forward",
                priority=0,
                rules=[],
            )
        ],
    )

    return default_filter_rules_table.get_json()
