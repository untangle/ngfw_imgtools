"Handles accounts/admin settings"

from sync import Manager, registrar
from sync.common import Logger
from sync.common.sanitizers.accounts_sanitizer import AccountsSanitizer
from sync.settings_file import SettingsFile

logger = Logger.getInstance()


class AccountsManager(Manager):
    def __init__(self) -> None:
        super().__init__(None, None, AccountsSanitizer())

    def initialize(self) -> None:
        """initialize this module"""
        logger.info("Initializing settings")
        registrar.register_settings_file("settings", self)

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates settings"""
        accounts = settings_file.settings.get("accounts")
        if accounts is None:
            return
        creds = accounts.get("credentials")
        if creds is None:
            return
        for cred in creds:
            if cred.get("authorizedKeys") is None:
                continue
            if cred.get("username") != "admin":
                continue
            registrar.register_file("/root/.ssh/authorized_keys", None, self)

    def create_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list, filename: str
    ) -> None:
        """creates settings"""
        logger.info("Creating settings")
        settings_file.settings["accounts"] = {}

        settings_file.settings["accounts"]["credentials"] = [
            {
                "username": "admin",
                "passwordCleartext": self.get_admin_password(SettingsFile.os_name),
            }
        ]

    def get_admin_password(self, os_name: str) -> str:
        """returns admin password"""
        return "" if os_name == "eos" else "passwd"


registrar.register_manager(AccountsManager())
