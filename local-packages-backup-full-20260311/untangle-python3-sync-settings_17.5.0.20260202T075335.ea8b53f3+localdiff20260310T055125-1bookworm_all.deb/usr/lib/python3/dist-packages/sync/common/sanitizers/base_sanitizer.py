class Sanitizer:
    def sanitize(self, object) -> None:
        """
        sanitize performs validation of object.
        """
