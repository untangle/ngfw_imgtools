#!/usr/bin/env python3
"""Dynamic Lists Dispatcher

This script runs on a regular schedule (every minute via cron) and determines
which dynamic block lists need to be fetched based on their polling intervals
and last fetch times. It then spawns fetch_ip_list.py for each due list.

"""

import json
import os
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from sync.common import Logger
from sync.file_util import FileUtil

logger = Logger.getInstance()

SETTINGS_FILE = FileUtil.locate_file("/etc/config/settings.json")
BLOCK_LIST_DIR = Path(FileUtil.locate_file("/etc/config/blocklists"))
FETCH_SCRIPT = FileUtil.locate_file("/usr/bin/fetch_ip_list.py")


class DynamicListsDispatcher:
    """Manages dispatching of dynamic list fetch operations."""

    def __init__(
        self,
        settings_file: Optional[str] = None,
        blocklists_dir: Optional[str] = None,
        fetch_script: Optional[str] = None,
    ) -> None:
        """Initialize the dispatcher.

        Args:
            settings_file: Path to settings.json (defaults to SETTINGS_FILE)
            blocklists_dir: Path to blocklists directory (defaults to BLOCK_LIST_DIR)
            fetch_script: Path to fetch_ip_list.py script (defaults to FETCH_SCRIPT)
        """
        self.settings_file = settings_file or SETTINGS_FILE
        self.blocklists_dir = Path(blocklists_dir) if blocklists_dir else BLOCK_LIST_DIR
        self.fetch_script = fetch_script or FETCH_SCRIPT

    def load_settings(self) -> dict[str, Any]:
        """Load settings from the settings JSON file.

        Returns:
            Dictionary containing settings, or empty dict on error
        """
        try:
            with open(self.settings_file) as f:
                settings = json.load(f)
            logger.debug("Loaded settings from %s", self.settings_file)
            return settings
        except (OSError, json.JSONDecodeError) as e:
            logger.error("Failed to load settings from %s: %s", self.settings_file, e)
            return {}

    def get_cache_file_path(self, file_path: str) -> str:
        """Get the cache metadata file path for a given IP list file.

        Args:
            file_path: Path of the IP list file

        Returns:
            Path to the cache metadata file
        """
        return f"{file_path}.cache"

    def load_cache_metadata(self, file_path: str) -> dict[str, Any]:
        """Load cache metadata including last fetch time.

        Args:
            file_path: Path of the IP list file

        Returns:
            Dictionary containing cache metadata (etag, last_modified, last_fetch_time)
        """
        cache_file = self.get_cache_file_path(file_path)
        cache_data = {}

        try:
            if os.path.isfile(cache_file):
                with open(cache_file) as f:
                    cache_data = json.load(f)
                logger.debug("Loaded cache metadata from %s", cache_file)
        except (OSError, json.JSONDecodeError) as e:
            logger.warning("Failed to load cache metadata from %s: %s", cache_file, e)

        return cache_data

    def save_cache_metadata(self, file_path: str, metadata: dict[str, Any]) -> None:
        """Save cache metadata including last fetch time.

        Args:
            file_path: Path of the IP list file
            metadata: Dictionary containing cache metadata to save
        """
        cache_file = self.get_cache_file_path(file_path)

        try:
            with open(cache_file, "w") as f:
                json.dump(metadata, f, indent=2)
            logger.debug("Saved cache metadata to %s", cache_file)
        except OSError as e:
            logger.warning("Failed to save cache metadata to %s: %s", cache_file, e)

    def calculate_next_fetch_time(
        self, last_fetch_time: datetime, polling_unit: str, polling_time: int
    ) -> datetime:
        """Calculate when the next fetch should occur.

        Args:
            last_fetch_time: When the list was last fetched
            polling_unit: Unit of time (Minutes, Hours, Days, Months)
            polling_time: Number of polling units

        Returns:
            DateTime when the next fetch should occur
        """
        if polling_unit == "Minutes":
            return last_fetch_time + timedelta(minutes=polling_time)
        if polling_unit == "Hours":
            return last_fetch_time + timedelta(hours=polling_time)
        if polling_unit == "Days":
            return last_fetch_time + timedelta(days=polling_time)
        if polling_unit == "Months":
            # Approximate: 30 days per month
            return last_fetch_time + timedelta(days=polling_time * 30)
        logger.warning("Unknown polling unit: %s, defaulting to 1 hour", polling_unit)
        return last_fetch_time + timedelta(hours=1)

    def is_fetch_due(
        self, file_path: str, polling_unit: str, polling_time: int
    ) -> tuple[bool, Optional[datetime]]:
        """Determine if a list is due for fetching.

        Args:
            file_path: Path to the list file
            polling_unit: Unit of time (Minutes, Hours, Days, Months)
            polling_time: Number of polling units

        Returns:
            Tuple of (is_due, last_fetch_time)
        """
        cache_metadata = self.load_cache_metadata(file_path)
        last_fetch_str = cache_metadata.get("last_fetch_time")

        # If never fetched before, it's due
        if not last_fetch_str:
            logger.info("List %s has never been fetched, scheduling fetch", file_path)
            return True, None

        try:
            last_fetch_time = datetime.fromisoformat(last_fetch_str)
        except (ValueError, TypeError) as e:
            logger.warning(
                "Invalid last_fetch_time format in cache for %s: %s. Scheduling fetch.",
                file_path,
                e,
            )
            return True, None

        # Remove microseconds from last_fetch_time for consistent comparison
        last_fetch_time = last_fetch_time.replace(microsecond=0)

        next_fetch_time = self.calculate_next_fetch_time(
            last_fetch_time, polling_unit, polling_time
        )
        # Remove microseconds from current time to avoid sub-second timing issues
        now = datetime.now().replace(microsecond=0)

        # Add 30-second grace period to account for execution delays
        # If we're within 30 seconds of next fetch time, fetch anyway to avoid waiting full cycle
        grace_period = timedelta(seconds=30)
        is_due = now >= (next_fetch_time - grace_period)

        if is_due:
            logger.info(
                "List %s is due for fetch (last: %s, next: %s, now: %s)",
                file_path,
                last_fetch_time,
                next_fetch_time,
                now,
            )
        else:
            logger.debug(
                "List %s not yet due (last: %s, next: %s, now: %s)",
                file_path,
                last_fetch_time,
                next_fetch_time,
                now,
            )

        return is_due, last_fetch_time

    def update_last_fetch_time(self, file_path: str) -> None:
        """Update the last fetch time in the cache metadata.

        Args:
            file_path: Path to the list file
        """
        cache_metadata = self.load_cache_metadata(file_path)
        # Remove microseconds to avoid timing precision issues with cron
        cache_metadata["last_fetch_time"] = datetime.now().replace(microsecond=0).isoformat()
        self.save_cache_metadata(file_path, cache_metadata)

    def get_list_file_path(self, list_id: str) -> str:
        """Get the file path for a dynamic list.

        Args:
            list_id: UUID of the dynamic list

        Returns:
            Full path to the list file
        """
        return str(self.blocklists_dir / f"dynamic_ip_addresses_list_{list_id}.txt")

    def fetch_list(self, config: dict[str, Any]) -> None:
        """Fetch a single dynamic list using fetch_ip_list.py.

        Args:
            config: Configuration dictionary for the list
        """
        list_id = config.get("id", "")
        source_url = config.get("source", "")
        skip_cert_check = config.get("skipCertCheck", False)
        parsing_method = config.get("parsingMethod", "^\\S{2,256}")

        file_path = self.get_list_file_path(list_id)

        # Build the command with timeout wrapper
        cmd = [
            "timeout",
            "30s",
            self.fetch_script,
            list_id,
            source_url,
            file_path,
            "True" if skip_cert_check else "False",
            parsing_method,
        ]

        logger.info("Dispatching fetch for list %s from %s", list_id, source_url)
        logger.debug("Command: %s", " ".join(cmd))

        # Spawn the fetch process with output piped to logger for syslog
        fetch_proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )

        # Pipe output to logger for syslog
        subprocess.Popen(
            ["logger", "-t", f"fetch_ip_list_{list_id}"],
            stdin=fetch_proc.stdout,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

        # Close our reference so logger gets EOF when fetch completes
        fetch_proc.stdout.close()

    def process_lists(self) -> int:
        """Process all dynamic lists and fetch those that are due.

        Lists are dispatched as independent background processes with timeout protection.
        Output is piped to logger command for syslog logging.

        Returns:
            Number of lists that were dispatched
        """
        settings = self.load_settings()
        dynamic_lists = settings.get("dynamic_lists", {})

        # Check if dynamic lists are globally enabled
        if not dynamic_lists.get("enabled", False):
            logger.debug("Dynamic lists are globally disabled")
            return 0

        configurations = dynamic_lists.get("configurations", [])
        if not configurations:
            logger.debug("No dynamic list configurations found")
            return 0

        # Track how many lists we dispatched
        dispatched_count = 0

        for config in configurations:
            # Skip disabled lists
            if not config.get("enabled", False):
                logger.debug("Skipping disabled list: %s", config.get("name", "unnamed"))
                continue

            list_id = config.get("id")
            if not list_id:
                logger.warning("List configuration missing 'id' field, skipping")
                continue

            polling_unit = config.get("pollingUnit", "Hours")
            polling_time = config.get("pollingTime", 1)

            file_path = self.get_list_file_path(list_id)

            # Check if fetch is due
            is_due, _ = self.is_fetch_due(file_path, polling_unit, polling_time)

            if is_due:
                # Update last_fetch_time BEFORE spawning the fetch to avoid timing skew
                self.update_last_fetch_time(file_path)
                # Dispatch fetch process as independent background task
                self.fetch_list(config)
                dispatched_count += 1

        if dispatched_count == 0:
            logger.debug("No lists are due for fetching")
            return 0

        logger.debug("Dispatcher finished: %d lists dispatched", dispatched_count)
        return dispatched_count


def main() -> None:
    """Main entry point for the dispatcher."""
    logger.info("Dynamic Lists Dispatcher starting")

    dispatcher = DynamicListsDispatcher()

    try:
        dispatched_count = dispatcher.process_lists()
        logger.info("Dispatcher completed successfully. Dispatched %d lists.", dispatched_count)
        sys.exit(0)
    except Exception as e:
        logger.exception("Dispatcher failed with exception: %s", e)
        sys.exit(1)


if __name__ == "__main__":
    main()
