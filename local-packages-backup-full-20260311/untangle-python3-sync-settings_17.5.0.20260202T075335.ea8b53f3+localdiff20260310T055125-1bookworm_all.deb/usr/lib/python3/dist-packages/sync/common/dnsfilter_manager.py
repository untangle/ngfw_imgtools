"""This class is responsible for managing DNSFILTER settings"""

import json
import os

from sync import Manager, registrar
from sync.common import Logger
from sync.file_util import FileUtil
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

dnsfilter_default_settings = {
    "enabled": False,
    "blockList": [
        {
            "description": "All Other Domains",
            "block": False,
            "alert": False,
            "log": True,
            "exact": False,
            "name": "All Other Domains",
            "reject": False,
        }
    ],
}


DNSFILTER_SETTINGS_PATH = FileUtil.locate_file("/tmp/dnsfilter/dnsfilter_settings")
DNSFILTER = "dns_filter"

logger = Logger.getInstance()


class DNSFilterManager(Manager):
    """DNSFilterManager manages the dns_filter settings"""

    def __init__(self) -> None:
        self.dnsfilter_settings_path = DNSFILTER_SETTINGS_PATH

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.dnsfilter_settings_path, "SIGHUP-packetd", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        settings_file.settings["dns_filter"] = dnsfilter_default_settings

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """sanitizes DNSFILTER settings"""
        dnsfilter_settings = settings_file.settings.get("dns_filter")
        # Missing dnsfilter settings
        if dnsfilter_settings is None:
            dnsfilter_settings = dnsfilter_default_settings
            settings_file.settings["dns_filter"] = dnsfilter_settings
        # upgrades to 6.2 - moves dnsfilter_settings backup file from /etc/config to /tmp and deletes older folder path for backup file
        if settings_file.settings.get("version") <= 5:
            FileUtil.move_write_only_registered_files_to_tmp(self.dnsfilter_settings_path, True)
        # change flagged to alerted in lists
        for listEntry in dnsfilter_settings.get("blockList"):
            if "flagged" in listEntry:
                listEntry["alert"] = listEntry.pop("flagged")
            if "enabled" in listEntry:
                listEntry["block"] = listEntry.pop("enabled")
            if "logged" in listEntry:
                listEntry["log"] = listEntry.pop("logged")

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates settings"""
        dnsfilter_settings = settings_file.settings.get("dns_filter")
        # Missing dnsfilter settings
        if dnsfilter_settings is None:
            raise SettingsException(message_str="missing_dnsfilter_settings")

        self.validate_parameters(dnsfilter_settings)

    def validate_parameters(self, data) -> None:
        """validates parameters"""
        self.validate_parameter(data, "enabled", [bool])
        for list in data.get("blockList", []):
            self.validate_blocklist(list)

    def validate_blocklist(self, list) -> None:
        """validates a single blocklist"""
        self.validate_parameter(list, "description", [str])
        self.validate_parameter(list, "block", [bool])
        self.validate_parameter(list, "alert", [bool])
        self.validate_parameter(list, "log", [bool])
        self.validate_parameter(list, "exact", [bool])
        self.validate_parameter(list, "name", [str])
        self.validate_parameter(list, "reject", [bool])

    def validate_parameter(self, parameters, parameter_name, parameter_types) -> None:
        """Validates parameters for type"""
        parameter_value = parameters.get(parameter_name)

        # Check if the parameter is missing or not of the correct type
        if parameter_value is None or not any(
            isinstance(parameter_value, type) for type in parameter_types
        ):
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["dns filter", parameter_name]
            )

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")
        self.write_dnsfilter_settings(settings_file, prefix)

    def write_dnsfilter_settings(self, settings_file, prefix) -> None:
        """writes the settings to specified filepath"""
        current_dnsfilter_settings = settings_file.settings[DNSFILTER]
        filename = prefix + self.dnsfilter_settings_path
        self.write_file(filename, json.dumps(current_dnsfilter_settings).encode("utf-8"))

    def write_file(self, filename, data) -> None:
        """writes data to specified file"""
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        with open(filename, "wb+") as file:
            file.write(data)

        logger.info("Wrote %s", str(filename))


registrar.register_manager(DNSFilterManager())
