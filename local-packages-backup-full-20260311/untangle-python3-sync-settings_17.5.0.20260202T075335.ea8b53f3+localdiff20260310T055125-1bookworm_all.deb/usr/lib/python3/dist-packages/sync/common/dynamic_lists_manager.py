import copy
import json
import os
import re
import stat
import subprocess
import textwrap
from pathlib import Path
from uuid import UUID

from sync import Manager, SettingsFile, registrar
from sync.common import Logger
from sync.common.utils import CRON_D_DIR
from sync.file_util import FileUtil
from sync.perms_util import regain_permissions
from sync.settings_exception import SettingsException

# Dir to store the block list files
BLOCK_LIST_DIR = Path(FileUtil.locate_file("/etc/config/blocklists"))

# Cron filename for cron.d style platforms
CRON_D_FILENAME = "dynamic-blocklist-fetch-ip-list"

logger = Logger.getInstance()


class CommonDynamicListsManager(Manager):
    """
    Manager for Dynamic Ip Blocking
    """

    script_write_filename = FileUtil.locate_file("/usr/bin/fetch_ip_list.py")
    script_dispatcher_filename = FileUtil.locate_file("/usr/bin/dynamic_lists_dispatcher.py")

    settings_service_key = "dynamic_lists"
    CONFIG_KEYS = [
        "name",
        "id",
        "type",
        "enabled",
        "source",
        "pollingUnit",
        "pollingTime",
        "skipCertCheck",
        "parsingMethod",
    ]
    settings_service_template = {
        "enabled": False,
        "configurations": [
            {
                "name": "Emerging Threats",
                "id": "defa17b1-b10c-4de5-7897-3f426fb32b99",
                "type": "IPList",
                "enabled": False,
                "source": "http://opendbl.net/lists/etknown.list",
                "pollingUnit": "Minutes",
                "pollingTime": 30,
                "skipCertCheck": False,
                "parsingMethod": "^\\S{2,256}",
            },
            {
                "name": "DShield Blocklist",
                "id": "f9209659-3968-4de5-9385-3f426df3411a",
                "type": "IPList",
                "enabled": False,
                "source": "http://opendbl.net/lists/dshield.list",
                "pollingUnit": "Hours",
                "pollingTime": 1,
                "skipCertCheck": False,
                "parsingMethod": "((?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)+|(?:[a-f0-9:]+:+)+(?:[a-f0-9](?:(::)?))+)(?:\\/{1}\\d+|-((?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)+|(?:[a-f0-9:]+:+)+(?:[a-f0-9](?:(::)?))+))?|(\\|{1,2}(?:\\d{1,3}(?:\\.\\d{1,3}){3}|[a-zA-Z0-9*.-]+\\.[a-zA-Z*]{2,})[\\^|])|(?:[a-zA-Z0-9\\*](?:[a-zA-Z0-9\\-\\*]{0,61}[a-zA-Z0-9\\*])?(?:\\.[a-zA-Z0-9\\*](?:[a-zA-Z0-9\\-\\*]{0,61}[a-zA-Z0-9\\*])?)*\\.(?:[a-zA-Z]{2,63}|\\*))",
            },
        ],
    }

    def initialize(self) -> None:
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.script_write_filename, None, self)
        registrar.register_file(self.script_dispatcher_filename, None, self)
        registrar.register_file(self.cron_filename, "restart-cron", self)

    def sync_settings(self, settings_file: SettingsFile, prefix: str, delete_list: list) -> None:
        """syncs settings"""
        logger.info("Sync settings")
        # Ensure the BLOCK_LIST_DIR exists
        with regain_permissions():
            BLOCK_LIST_DIR.resolve().mkdir(mode=0o755, parents=True, exist_ok=True)

        self.write_script_file(prefix)
        self.write_dispatcher_script(prefix)
        self.write_cron_file(settings_file.settings, prefix, delete_list)
        self.manage_block_list_files(settings_file.settings, prefix, delete_list)

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        """sanitizes settings"""
        dynamic_lists_settings = settings_file.settings.get(self.settings_service_key)

        if dynamic_lists_settings is None:
            settings_file.settings[self.settings_service_key] = self.settings_service_template

    def validate_parameter(
        self, settings: dict, parameter_name: str, parameter_type: type
    ) -> None:
        """validates parameters"""
        parameter_value = settings[parameter_name]
        if parameter_value is None or type(parameter_value) is not parameter_type:
            raise SettingsException(
                message_str=f"Missing or invalid type of Dynamic Lists setting: {parameter_name}"
            )
        if parameter_name == "id":
            try:
                UUID(parameter_value)
            except ValueError:
                raise SettingsException(
                    message_str=f"Invalid ID in dynamic lists: {parameter_value}"
                )

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates settings"""

        dynamic_lists_settings = settings_file.settings.get(self.settings_service_key)

        if dynamic_lists_settings is None:
            raise SettingsException(message_str="Missing Dynamic Lists settings")

        self.validate_parameter(dynamic_lists_settings, "enabled", bool)
        for configuration in dynamic_lists_settings["configurations"]:
            self.validate_parameter(configuration, "name", str)
            self.validate_parameter(configuration, "id", str)
            self.validate_parameter(configuration, "type", str)
            self.validate_parameter(configuration, "enabled", bool)
            self.validate_parameter(configuration, "source", str)
            self.validate_parameter(configuration, "pollingUnit", str)
            self.validate_parameter(configuration, "pollingTime", int)
            self.validate_parameter(configuration, "skipCertCheck", bool)
            self.validate_parameter(configuration, "parsingMethod", str)
            if sorted(configuration.keys()) != sorted(self.CONFIG_KEYS):
                extra_keys = set(configuration.keys()) - set(self.CONFIG_KEYS)
                raise SettingsException(
                    message_str=f"Extra keys present in configuration: {list(extra_keys)}"
                )

    def write_file(self, destination: str, data: str, prefix: str, mode: str) -> None:
        """
        Reusable function to write to a file
        """
        filename = prefix + destination
        file_dir = os.path.dirname(filename)
        os.makedirs(file_dir, exist_ok=True)
        try:
            with open(filename, mode) as file:
                file.write(data)
            self.change_file_permissions(filename, destination == self.cron_filename)
            logger.info("Wrote %s", str(filename))
        except Exception:
            logger.exception("An error occurred:")

    def write_script_file(self, prefix: str) -> None:
        """
        Write fetch_ip_list script after registering
        """

        data = textwrap.dedent(
            """\
        #!/usr/bin/python3
        import sync.common.fetch_ip_list as fetch_ip_list
        if __name__ == "__main__":
            fetch_ip_list.main()
        """
        )

        self.write_file(self.script_write_filename, data, prefix, "w")

    def block_list_file_name(self, guid: str) -> str:
        """
        Build the base filename for a block list
        """
        return f"dynamic_ip_addresses_list_{guid}.txt"

    def find_block_list_files(self) -> list[Path]:
        """
        Find the list of existing block list files
        """
        try:
            with regain_permissions():
                files = [f for f in Path(BLOCK_LIST_DIR).glob("dynamic_ip_addresses_list_*.txt")]
                return files
        except PermissionError:
            logger.exception("ERROR: Unable to access %s:", str(BLOCK_LIST_DIR))
        return []

    def manage_block_list_files(self, settings: dict, prefix: str, delete_list: list) -> None:
        """
        Delete orphaned block list files and trigger a download on any blocklists which should have a file
        """
        dl_settings = settings.get(self.settings_service_key)
        all_files = self.find_block_list_files()
        orphan_files, new_block_lists_dict = self.classify_block_list_files(dl_settings, all_files)
        # Delete both the orphaned blocklist file and its cache file
        for orphan in orphan_files:
            delete_list.append(str(orphan))
            delete_list.append(str(orphan) + ".cache")
        for block_list_file, block_list_config in new_block_lists_dict.items():
            # ensure the block lists are enabled before we run fetch_ip_lists
            # We don't need to check if they exist - that's handled by find_block_list_files() above
            if settings.get(self.settings_service_key)["enabled"] and block_list_config.get(
                "enabled", False
            ):
                with regain_permissions():
                    exec = self.build_fetch_call(
                        prefix + self.script_write_filename,
                        block_list_config.get("id", ""),
                        block_list_config.get("source", ""),
                        str(block_list_file),
                        str(block_list_config.get("skipCertCheck", False)),
                        block_list_config.get("parsingMethod", "^\\S{2,256}"),
                    )
                    # start_new_session runs in bg so as to not clog up sync-settings
                    exec_proc = subprocess.Popen(
                        exec,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        start_new_session=True,
                    )
                    # piping to logger logs the process rather than sending output to stdout
                    subprocess.Popen(
                        ["logger", "-t", self.settings_service_key],
                        stdin=exec_proc.stdout,
                    )

    def build_cronjob_text(self, settings: dict) -> tuple[bool, str]:
        """
        Return a cron string with appropriate arguments required for the script
        """
        records = False
        cron_string = ""
        source_url = ""
        settings_guid = ""
        def_skip_cert_check = "False"
        auto_settings_list = settings.get(self.settings_service_key)
        if auto_settings_list["enabled"] is True:
            for auto_settings in auto_settings_list["configurations"]:
                if auto_settings is not None:
                    if auto_settings.get("enabled") is True:
                        records = True
                        polling_unit = auto_settings.get("pollingUnit", source_url)
                        polling_time = auto_settings.get("pollingTime", source_url)
                        source_url = auto_settings.get("source", source_url)
                        settings_guid = auto_settings.get("id", settings_guid)
                        skip_cert_check = auto_settings.get("skipCertCheck", def_skip_cert_check)
                        regex = auto_settings.get("parsingMethod", "^\\S{2,256}")

                        file_name = self.block_list_file_name(settings_guid)
                        file_path = BLOCK_LIST_DIR.joinpath(file_name)

                        cron = self.compose_cron_timestamp_string(polling_unit, polling_time)

                        cron_string += "{} {} 2>&1 | logger -t dbl_cron\n".format(
                            cron,
                            " ".join(
                                self.build_fetch_call(
                                    self.script_write_filename,
                                    settings_guid,
                                    source_url,
                                    str(file_path),
                                    str(skip_cert_check),
                                    json.dumps(regex),
                                )
                            ),
                        )

        return records, cron_string

    def build_fetch_call(self, filename: str, *args):
        return [filename, *list(args)]

    def classify_block_list_files(
        self, dynamic_lists_settings: dict, all_files: list[Path]
    ) -> tuple[list[Path], dict[Path, dict]]:
        """
        Get two categories of block lists
        - [list] orphan files: files that lack a corresponding block list configuration
        - [dict] other files: files that don't yet exist but have a configuration in settings.json
            - saved as a dict so that all the new files can be linked to their config
        """
        orphaned_block_lists = copy.deepcopy(all_files)
        new_block_lists_dict = {}

        settings_guid = ""
        # Plugin Enabled status is not considered
        for configuration in dynamic_lists_settings["configurations"]:
            if configuration is not None:
                # Configuration Enabled status is not considered
                settings_guid = configuration.get("id", "")
                file_name = self.block_list_file_name(settings_guid)
                file_path = BLOCK_LIST_DIR.joinpath(file_name)

                try:
                    # File is not an orphan
                    orphaned_block_lists.remove(file_path)
                except ValueError:
                    # If the file is not in the list, then the file we want to exist doesn't exist yet
                    new_block_lists_dict[file_path] = configuration

        # remaining block list files are unreferenced
        return orphaned_block_lists, new_block_lists_dict


class CronDDynamicListsManager(CommonDynamicListsManager):
    """
    Dynamic Lists Manager for platforms using standard cron.d style cron.
    Used by EOS and other standard Linux platforms.
    """

    cron_filename = os.path.join(CRON_D_DIR, CRON_D_FILENAME)

    def write_cron_file(self, settings: dict, prefix: str, delete_list: list) -> None:
        """
        Write cron expression to dedicated cron file.
        Use write mode since this is a dedicated cron file for dynamic blocklists.
        """
        records, cron_string = self.build_cronjob_text(settings)
        if records:
            self.write_file(self.cron_filename, cron_string, prefix, "w")
        elif os.path.exists(self.cron_filename):
            # Remove the cron file if there are no enabled dynamic list configurations
            delete_list.append(self.cron_filename)

    @staticmethod
    def compose_cron_timestamp_string(polling_unit: str, polling_time: int) -> str:
        """
        Composes the timestamp_string for cron in standard cron.d style.
        :param polling_unit: Unit of time; it can be minutes, hours, days, months.
        :param polling_time: Numeric value of time
        :return:
        """
        cron = ""
        if polling_unit == "Minutes":
            cron = "*/" + str(polling_time) + " * * * *"
        elif polling_unit == "Hours":
            cron = "0 */" + str(polling_time) + " * * *"
        elif polling_unit == "Days":
            cron = "0 0 */" + str(polling_time) + " * *"
        elif polling_unit == "Months":
            cron = "0 0 1 */" + str(polling_time) + " *"
        # cron.d style requires username
        return cron + " root"

    @staticmethod
    def change_file_permissions(filename: str, is_cron_file: bool = False) -> None:
        """
        Set appropriate file permissions. Cron files in /etc/cron.d should not
        have the executable permission bit set.
        :param filename: absolute filename
        :param is_cron_file: whether this is a cron file
        :return: None
        """
        if is_cron_file:
            os.chmod(filename, os.stat(filename).st_mode & ~stat.S_IEXEC)
        else:
            os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)


class CrontabDynamicListsManager(CommonDynamicListsManager):
    """
    Dynamic Lists Manager for platforms using OpenWrt-style crontab.
    Uses /etc/crontabs/root shared crontab file with append mode.
    Used by OpenWrt, Vittoria, and similar platforms.
    """

    cron_filename = "/etc/crontabs/root"

    def write_cron_file(self, settings: dict, prefix: str, delete_list: list) -> None:
        """
        Write cron expression to shared crontab file.
        Uses append mode since this is a shared crontab file.
        Does not remove the file even if there are no enabled configurations.
        """
        records, cron_string = self.build_cronjob_text(settings)
        if records:
            self.write_file(self.cron_filename, cron_string, prefix, "a")

    @staticmethod
    def compose_cron_timestamp_string(polling_unit: str, polling_time: int) -> str:
        """
        Composes the timestamp_string for cron in OpenWrt crontab style.
        :param polling_unit: Unit of time; it can be minutes, hours, days, months.
        :param polling_time: Numeric value of time
        :return:
        """
        cron = ""
        if polling_unit == "Minutes":
            cron = "*/" + str(polling_time) + " * * * *"
        elif polling_unit == "Hours":
            cron = "0 */" + str(polling_time) + " * * *"
        elif polling_unit == "Days":
            cron = "0 0 */" + str(polling_time) + " * *"
        elif polling_unit == "Months":
            cron = "0 0 1 */" + str(polling_time) + " *"
        return cron

    @staticmethod
    def change_file_permissions(filename: str, _) -> None:
        """
        Add execute permission for the file's owner.
        :param filename: absolute filename
        :param _: unused parameter for API compatibility
        :return: None
        """
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)


class CrontabVittoriaDynamicListsManager(CrontabDynamicListsManager):
    cron_filename = "/etc/crontabs/root"
    script_dispatcher_filename = FileUtil.locate_file("/usr/bin/dynamic_lists_dispatcher.py")

    def initialize(self) -> None:
        """Override to register the dispatcher script for Vittoria"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.script_write_filename, None, self)
        registrar.register_file(self.script_dispatcher_filename, None, self)
        registrar.register_file(self.cron_filename, "restart-cron", self)

    def write_script_file(self, prefix: str) -> None:
        """
        Write fetch_ip_list script after registering
        """

        data = textwrap.dedent(
            """\
        #!/usr/bin/python3
        import sys
        sys.path.insert(0, "/opt/mfw/lib/python")
        import sync.common.fetch_ip_list as fetch_ip_list
        if __name__ == "__main__":
            fetch_ip_list.main()
        """
        )

        self.write_file(self.script_write_filename, data, prefix, "w")

    def write_dispatcher_script(self, prefix: str) -> None:
        """
        Write dynamic_lists_dispatcher script for Vittoria
        """

        data = textwrap.dedent(
            """\
        #!/usr/bin/python3
        import sys
        sys.path.insert(0, "/opt/mfw/lib/python")
        import sync.common.dynamic_lists_dispatcher as dynamic_lists_dispatcher
        if __name__ == "__main__":
            dynamic_lists_dispatcher.main()
        """
        )

        self.write_file(self.script_dispatcher_filename, data, prefix, "w")

    def sync_settings(self, settings_file: SettingsFile, prefix: str, delete_list: list) -> None:
        """Override sync_settings to write dispatcher script for Vittoria"""
        logger.info("Sync settings (Vittoria)")
        # Ensure the BLOCK_LIST_DIR exists
        with regain_permissions():
            BLOCK_LIST_DIR.resolve().mkdir(mode=0o755, parents=True, exist_ok=True)

        self.write_script_file(prefix)
        self.write_dispatcher_script(prefix)
        self.write_cron_file(settings_file.settings, prefix, delete_list)
        self.manage_block_list_files(settings_file.settings, prefix, delete_list)

    def build_cronjob_text(self, settings: dict) -> tuple[bool, str]:
        """
        Return a single static cron entry that calls the dispatcher script every 15 minutes.
        The dispatcher handles all polling logic based on settings.json.
        """
        auto_settings_list = settings.get(self.settings_service_key)

        # Check if dynamic lists are enabled and have any configurations
        if not auto_settings_list.get("enabled", False):
            return False, ""

        configurations = auto_settings_list.get("configurations", [])
        if not configurations:
            return False, ""

        # Check if at least one configuration is enabled
        has_enabled = any(config.get("enabled", False) for config in configurations)
        if not has_enabled:
            return False, ""

        # Single cron entry that runs every 15 minutes
        cron = "*/15 * * * *"
        command = f"{self.script_dispatcher_filename} 2>&1 | logger -t dbl_cron"
        cron_string = f"{cron} {command}\n"

        return True, cron_string

    def write_cron_file(self, settings: dict, prefix: str, delete_list: list) -> None:
        """
        Write cron expression to shared crontab file using staging pattern.
        Preserves existing content outside the MFW block.
        Writes merged content to staging directory for proper operation triggering.
        """
        MFW_BEGIN = "# BEGIN MFW"
        MFW_END = "# END MFW"

        _, cron_string = self.build_cronjob_text(settings)
        # Read existing crontab content (from real location, not staging)
        existing_content = ""
        if os.path.exists(self.cron_filename):
            try:
                with open(self.cron_filename) as f:
                    existing_content = f.read()
            except OSError:
                logger.exception("Failed to read existing crontab %s", self.cron_filename)

        # Remove old MFW block if exists
        existing_content = re.sub(
            re.escape(MFW_BEGIN) + r".*?" + re.escape(MFW_END),
            "",
            existing_content,
            flags=re.DOTALL,
        ).rstrip()

        # Build merged content
        if cron_string.strip():
            # Wrap new data with BEGIN/END markers
            mfw_block = f"{MFW_BEGIN}\n{cron_string}{MFW_END}"
            merged_content = (
                existing_content + ("\n" if existing_content else "") + mfw_block + "\n"
            )
        else:
            # No MFW entries, just preserve existing content
            merged_content = existing_content + "\n" if existing_content else ""

        print("Write_file called")
        self.write_file(self.cron_filename, merged_content, prefix, "w")
