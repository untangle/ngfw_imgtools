"""This class is responsible for managing threat prevention settings"""

import os
import stat
from pathlib import Path

from sync import FileUtil, Manager, registrar
from sync.common import Logger
from sync.notification_util import get_uid

threat_prevention_default_settings = {
    "enabled": False,
    "passList": [],
    "sensitivity": 20,
}

logger = Logger.getInstance()


class ThreatPreventionManager(Manager):
    """ThreatPreventionManager manages the threat prevention settings.

    This base class handles settings sanitization only.
    Platforms that use BCTI should use a platform-specific subclass
    that registers the bcti.cfg file and restart-bctid operation.
    """

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        if not settings_file.settings.get("threatprevention"):
            settings_file.settings["threatprevention"] = threat_prevention_default_settings
        if (
            "redirect" in settings_file.settings["threatprevention"]
            and settings_file.settings.get("version") <= 5
        ):
            del settings_file.settings["threatprevention"]["redirect"]


class BctiThreatPreventionManager(ThreatPreventionManager):
    """ThreatPreventionManager with BCTI daemon support.

    This class extends ThreatPreventionManager to add BCTI file management
    and restart-bctid registration for platforms that run the bctid daemon.
    """

    bctid_filename = FileUtil.locate_file("/etc/config/bcti.cfg")
    bcti_log_filename = "/tmp/log/bcti.log"  # noqa: S108

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_file(self.bctid_filename, "restart-bctid", self)
        registrar.register_settings_file("settings", self)

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        if not os.path.exists(self.bctid_filename):
            self.write_bctid_file(self.bctid_filename, "/usr/share/bctid/bcti.cfg", get_uid())
        if not os.path.exists(self.bcti_log_filename):
            self.write_bcti_log_file()

        super().sanitize_settings(settings_file)

    def write_bctid_file(self, filename, bcti_config_template_filename, uid) -> None:
        try:
            file_dir = os.path.dirname(filename)
            if not os.path.exists(file_dir):
                os.makedirs(file_dir)
            with open(bcti_config_template_filename) as f:
                contents = f.read()
        except Exception:
            logger.exception("Failed to create %s file:", str(filename))
            return

        # Add this device UID
        contents = contents.replace("UID=XXX", "UID=" + uid)
        try:
            with open(filename, "w+") as f:
                f.write(contents)
                f.flush()
            os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        except Exception:
            logger.exception("Error writing to %s:", str(filename))
            return

        logger.info("Wrote %s", str(filename))

    def write_bcti_log_file(self) -> None:
        bcti_log_path = Path(self.bcti_log_filename)
        bcti_log_path.parent.mkdir(parents=True, exist_ok=True)
        bcti_log_path.touch(exist_ok=True)
