from sync.common.creators.base_creator import Creator
from sync.settings_file import SettingsFile


class CaptivePortalCreator(Creator):
    """Creates default settings for captive portal"""

    def create(self, settings_file: SettingsFile) -> None:
        settings_file.settings["captiveportal"] = {
            "enabled": False,
            "acceptText": "I agree",
            "acceptButtonText": "Continue",
            "messageHeading": "Guest Access Notice",
            "messageText": "Click Continue to access the Internet",
            "welcomeText": "Welcome to guest access",
            "timeoutValue": 1,
            "timeoutPeriod": "d",
            "pageTitle": "Guest access",
            "rules": [],
        }
