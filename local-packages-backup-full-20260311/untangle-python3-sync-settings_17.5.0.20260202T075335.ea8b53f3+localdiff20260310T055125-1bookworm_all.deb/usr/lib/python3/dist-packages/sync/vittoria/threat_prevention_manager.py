from sync import registrar
from sync.common.threat_prevention_manager import ThreatPreventionManager

registrar.register_manager(ThreatPreventionManager())
