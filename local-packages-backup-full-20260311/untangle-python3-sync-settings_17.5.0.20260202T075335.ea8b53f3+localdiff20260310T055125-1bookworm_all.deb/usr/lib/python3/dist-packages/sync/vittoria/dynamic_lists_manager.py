"""Dynamic lists manager for Vittoria with crontab style cron support"""

from sync import registrar
from sync.common.dynamic_lists_manager import CrontabVittoriaDynamicListsManager

registrar.register_manager(CrontabVittoriaDynamicListsManager())
