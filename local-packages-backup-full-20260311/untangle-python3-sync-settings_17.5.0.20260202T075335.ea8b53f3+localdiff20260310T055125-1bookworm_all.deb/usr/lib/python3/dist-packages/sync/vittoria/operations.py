import sync.registrar
from sync.file_util import FileUtil

SETTINGS_FILE = FileUtil.locate_file("/etc/config/settings.json")

sync.registrar.register_operation(
    "restart-cron",
    [""],
    ["/etc/init.d/cron stop ; /etc/init.d/cron enable ; /etc/init.d/cron start "],
    35,
    None,
)
sync.registrar.register_operation(
    "restart-reportd-alerts", [""], ["pkill -HUP reportd || true"], 30, None
)
sync.registrar.register_operation("restart-uid", [""], ["pkill -9 pyconnector"], 30, None)
sync.registrar.register_operation(
    "SIGHUP-packetd",
    [""],
    [
        f"curl -sk -X GET https://127.0.0.1:$(jq -r '.system.httpsPort // \"1025\"' {SETTINGS_FILE})/api/sendsignal/packetd/1"
    ],
    30,
    None,
)
