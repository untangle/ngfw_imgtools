"""
Vittoria UID Manager - Platform-specific implementation for Vittoria.

Manages the UID file at /opt/mfw/etc/uid for Vittoria platforms.
"""

from sync import registrar
from sync.common.uid_manager import UIDManager


class VittoriaUIDManager(UIDManager):
    """
    Vittoria-specific UID Manager implementation.

    Stores the UID file at /opt/mfw/etc/uid
    """

    def get_config_dir(self) -> str:
        """
        Get the Vittoria-specific configuration directory for the UID file.

        Returns:
            str: "/opt/mfw/etc" - the Vittoria configuration directory
        """
        return "/opt/mfw/etc"


registrar.register_manager(VittoriaUIDManager())
