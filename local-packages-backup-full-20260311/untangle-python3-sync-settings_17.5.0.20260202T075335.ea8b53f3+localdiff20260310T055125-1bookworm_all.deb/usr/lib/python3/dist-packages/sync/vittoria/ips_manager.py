from sync import registrar
from sync.common.ips_manager import IpsManager

registrar.register_manager(IpsManager())
