from __future__ import annotations

from sync import Manager, SettingsFile, registrar
from sync.common import Logger

logger = Logger.getInstance()
HTTP_PORT = "1024"
HTTPS_PORT = "1025"


class SystemManager(Manager):
    """
    Vittoria SystemManager
    """

    def get_default_system_settings(self):
        """Gets the default system settings."""
        return {
            "httpPort": HTTP_PORT,
            "httpsPort": HTTPS_PORT,
        }

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

    def create_settings(
        self,
        settings_file: SettingsFile,
        prefix: str,
        delete_list: list[str],
        filename: str,
    ) -> None:
        """Creates settings."""
        logger.info("Initializing settings")
        settings_file.settings["system"] = self.get_default_system_settings()

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        if not settings_file.settings.get("system"):
            settings_file.settings["system"] = self.get_default_system_settings()

        http_port = settings_file.get_settings_by_path("system/httpPort")
        if not http_port:
            logger.info("Creating default http port setting")
            http_port = settings_file.settings["system"]["httpPort"] = HTTP_PORT

        https_port = settings_file.get_settings_by_path("system/httpsPort")
        if not https_port:
            logger.info("Creating default https port setting")
            https_port = settings_file.settings["system"]["httpsPort"] = HTTPS_PORT


registrar.register_manager(SystemManager())
