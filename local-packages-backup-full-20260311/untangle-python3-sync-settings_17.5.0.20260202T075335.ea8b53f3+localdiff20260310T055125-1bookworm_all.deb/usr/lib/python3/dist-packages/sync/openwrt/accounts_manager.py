"Handles accounts/admin settings"

import os
import os.path
import stat

from sync import registrar
from sync.board_util import BoardUtil
from sync.common import Logger
from sync.common.accounts_manager import AccountsManager
from sync.file_util import FileUtil
from sync.settings_file import SettingsFile

PASSWORD_SETTER_FILE_OPENWRT = "/etc/config/setup.d/100-setpasswd"  # noqa: S105
AUTO_TEST_NO_PASSWORD_FILE_OPENWRT = "/etc/config/mfwAutoTestNoAdminPassword"  # noqa: S105

logger = Logger.getInstance()


class OpenWrtAccountsManager(AccountsManager):
    """AccountsManager is responsible for managing the "accounts" (credentials) settings"""

    password_setter_filename = "/etc/config/setup.d/100-setpasswd"  # noqa: S105

    def __init__(self) -> None:
        logger.info("Initializing settings")
        super().__init__()
        self.password_setter_filename = FileUtil.locate_file(PASSWORD_SETTER_FILE_OPENWRT)
        self.auto_test_no_password_file = FileUtil.locate_file(AUTO_TEST_NO_PASSWORD_FILE_OPENWRT)

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

        # running the setup-scripts operation isn't needed when
        # sync-settings is running natively on EOS
        operations = "setup-scripts" if BoardUtil.is_running_in_openwrt() else None
        registrar.register_file(self.password_setter_filename, operations, self)

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, delete_list: list[str]
    ) -> None:
        """syncs settings"""
        logger.info("Syncing settings")
        accounts = settings_file.settings.get("accounts")
        if accounts is None:
            return
        creds = accounts.get("credentials")
        if creds is None:
            return

        user_pass_dict = {}
        for cred in creds:
            if "username" in cred:
                # write authorized keys
                if cred.get("authorizedKeys", None) == "admin":
                    self.write_authorized_keys("/root/.ssh", cred["authorizedKeys"], prefix)
                # Use SHA512 if available - if the passwordHashSHA512 is missing,
                # then crypt.METHOD_SHA512 does not return a value on this architecture

                password = ""
                if cred.get("passwordHashSHA512", None):
                    password = cred.get("passwordHashSHA512", None)
                elif cred.get("passwordHashMD5", None):
                    password = cred.get("passwordHashMD5", None)
                else:
                    logger.warning("AccountsManager: Could not find password hash")
                    continue

                user_pass_dict[cred["username"]] = password

        # Prefer "root" user for root password. If "root" doesn't exist use "admin"
        # If neither exist, don't set root password
        if "root" in user_pass_dict:
            self.write_password_setter(user_pass_dict["root"], prefix)
        elif "admin" in user_pass_dict:
            self.write_password_setter(user_pass_dict["admin"], prefix)
        else:
            # if not found, delete any previous password script
            delete_list.append(self.password_setter_filename)

    def write_authorized_keys(self, dirname: str, contents: str, prefix: str) -> None:
        """Write the script to set the password in /tmp/shadow"""
        filename = prefix + dirname + "/authorized_keys"
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        registrar.register_file(filename, None, self)

        file = open(filename, "w+")
        file.write(contents)
        file.flush()
        file.close()

        os.chmod(filename, stat.S_IWRITE | stat.S_IREAD)  # chmod 600
        logger.info("AccountsManager: Wrote %s", str(filename))

    def write_password_setter(self, phash: str, prefix: str) -> None:
        """Write the script to set the password in /tmp/shadow"""
        filename = prefix + self.password_setter_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write('TMPFILE="/tmp/shadow"\n')
        file.write("/bin/sed -e 's|^\\(root:\\)[^:]*:[^:]*\\(:.*\\)$|\\1")
        file.write(phash.replace("$", r"\$"))
        file.write(":\\2|' /etc/shadow > $TMPFILE\n")
        file.write("\n")

        file.write(
            "if ! diff /etc/shadow $TMPFILE >/dev/null 2>&1 ; then cp $TMPFILE /etc/shadow ; fi\n"
        )
        file.write("\n")

        file.write("rm -f $TMPFILE")
        file.write("\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("AccountsManager: Wrote %s", str(filename))


registrar.register_manager(OpenWrtAccountsManager())
