"""wireless_manager manages /etc/config/wireless"""

import os
import re
import subprocess

from sync import Manager, board_util, network_util, registrar
from sync.board_util import BoardUtil
from sync.common import Logger
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class WirelessManager(Manager):
    """
    This class is responsible for writing /etc/config/wireless
    based on the settings object passed from sync-settings
    """

    wireless_filename = "/etc/config/wireless"

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.wireless_filename, "restart-wireless", self)

    def validate_settings(self, settings_file) -> None:
        """validates settings"""
        interfaces = settings_file.settings["network"]["interfaces"]
        for intf in interfaces:
            if enabled_wifi(intf):
                encryption = intf.get("wirelessEncryption")
                if encryption is None or encryption == "":
                    raise SettingsException(
                        message="api_wireless_no_encryption", vars=[intf.get("name")]
                    )
                if encryption in ("WPA1", "WPA12", "WPA2"):
                    password = intf.get("wirelessPassword")
                    if password is None or password == "":
                        raise SettingsException(
                            message="api_wireless_no_wpa_psk", vars=[intf.get("name")]
                        )
                    if len(password) < 8:
                        raise SettingsException(
                            message="api_wireless_wpa_psk_short", vars=[intf.get("name"), password]
                        )

                ssid = intf.get("wirelessSsid")
                if ssid is None or ssid == "":
                    raise SettingsException(
                        message="api_wireless_no_ssid", vars=[intf.get("name")]
                    )

                hidden = intf.get("hidden")
                if hidden not in [True, False]:
                    raise SettingsException(
                        message="api_wireless_no_hidden", vars=[intf.get("name")]
                    )

                mode = intf.get("wirelessMode")
                if mode is None or mode == "":
                    raise SettingsException(
                        message="api_wireless_no_mode", vars=[intf.get("name")]
                    )
                if mode not in ("AP", "CLIENT"):
                    raise SettingsException(
                        message="api_wireless_invalid_mode", vars=[intf.get("name"), mode]
                    )

                if mode == "AP":
                    channel = intf.get("wirelessChannel")
                    if channel is None:
                        raise SettingsException(
                            message="api_wireless_no_channel", vars=[intf.get("name")]
                        )
                    if channel <= 0:
                        raise SettingsException(
                            message="api_wireless_invalid_channel",
                            vars=[intf.get("name"), str(channel)],
                        )
                    if channel <= 11 and not self.has_2ghz(intf):
                        raise SettingsException(
                            message="api_wireless_invalid_channel_5",
                            vars=[intf.get("name"), str(channel)],
                        )
                    if channel > 11 and not self.has_5ghz(intf):
                        raise SettingsException(
                            message="api_wireless_invalid_channel_2_4",
                            vars=[intf.get("name"), str(channel)],
                        )

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        interfaces = settings_file.settings["network"]["interfaces"]
        for intf in interfaces:
            if intf.get("type") == "WIFI":
                if self.has_5ghz(intf):
                    intf["wirelessChannel"] = 36
                else:
                    intf["wirelessChannel"] = 11
                intf["wirelessMode"] = "AP"
                intf["wirelessEncryption"] = "WPA2"
                intf["wirelessPassword"] = "12345678"
                intf["hidden"] = False
                intf["wirelessSsid"] = "Arista"
                intf["wirelessThroughput"] = "AUTO"

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Syncing settings")
        self.write_wireless_file(settings_file.settings, prefix)

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        interfaces = settings_file.settings["network"]["interfaces"]
        for intf in interfaces:
            if intf.get("type") == "WIFI" and intf.get("hidden") is None:
                intf["hidden"] = False

    def get_phy_name(self, interface):
        "get the phy name for an device"
        return interface["device"].replace("wlan", "phy")

    def get_phy_path(self, interface):
        path = self.get_phy_realpath(interface)
        path = os.path.relpath(path, "/sys/devices")
        if bool(re.search("platform.*/pci*", path)):
            path = os.path.relpath(path, "platform")
        return path

    def get_phy_realpath(self, interface):
        return os.path.realpath(f"/sys/class/ieee80211/{self.get_phy_name(interface)}/device")

    def get_phy_mac(self, interface):
        try:
            return (
                subprocess.check_output(
                    f"cat /sys/class/ieee80211/{self.get_phy_name(interface)}/macaddress",
                    shell=True,
                )
                .decode("ascii")
                .rstrip()
            )
        except:
            logger.exception(
                "WARNING: Failed to determine MAC address for %s", str(interface.get("device"))
            )
            return "00:00:00:00:00:00"

    def get_device_id(self, interface) -> str:
        if self.is_device_link(interface):
            return f"option path '{self.get_phy_path(interface)}'"
        return f"option macaddr '{self.get_phy_mac(interface)}'"

    def is_device_link(self, interface):
        return os.path.islink(f"/sys/class/ieee80211/{self.get_phy_name(interface)}")

    def is_5ghz(self, interface) -> bool:
        return interface.get("wirelessChannel") > 11

    def has_5ghz(self, interface):
        return (
            subprocess.call(
                f"iw phy {self.get_phy_name(interface)} info | grep -q '5180 MHz'", shell=True
            )
            == 0
        )

    def has_2ghz(self, interface):
        return (
            subprocess.call(
                f"iw phy {self.get_phy_name(interface)} info | grep -q '2412 MHz'", shell=True
            )
            == 0
        )

    def get_band(self, interface) -> str:
        if self.is_5ghz(interface):
            return "5g"
        return "2g"

    def get_htmode(self, interface):
        htmode = ""
        if (
            subprocess.call(
                f"iw phy {self.get_phy_name(interface)} info | grep -q 'Capabilities:'", shell=True
            )
            == 0
        ):
            htmode = "\toption htmode 'HT20'\n"
        if (
            self.is_5ghz(interface)
            and subprocess.call(
                f"iw phy {self.get_phy_name(interface)} info | grep -q 'VHT Capabilities'",
                shell=True,
            )
            == 0
        ):
            htmode = "\toption htmode 'VHT80'\n"
        return htmode

    def get_wireless_interface_settings(self, settings_file, enabled_check=True):
        """
        Return wireless interfaces
        """
        interfaces_settings = []
        interfaces = settings_file.get_settings_by_path("network/interfaces")
        for interface in interfaces:
            if interface.get("type") != "WIFI":
                continue
            if enabled_check is False or interface.get("enabled") is True:
                interfaces_settings.append(interface)
        return interfaces_settings

    def write_country(self, file) -> None:
        country_code = board_util.get_country_code()
        if country_code != "":
            file.write(f"\toption country '{country_code}'\n")

    def write_macaddr(self, file, macaddr) -> None:
        if macaddr not in ("", None):
            file.write(f"\toption macaddr '{macaddr}'\n")

    def write_wireless_encryption(self, file, encryption, password) -> None:
        if encryption == "NONE":
            file.write("\toption encryption 'none'\n")
        elif encryption == "WPA1":
            file.write("\toption encryption 'psk'\n")
            file.write(f"\toption key '{password}'\n")
        elif encryption == "WPA12":
            file.write("\toption encryption 'psk-mixed+tkip+ccmp'\n")
            file.write(f"\toption key '{password}'\n")
        else:
            file.write("\toption encryption 'psk2'\n")
            file.write(f"\toption key '{password}'\n")

    def write_wireless_file(self, settings, prefix="") -> None:
        filename = prefix + self.wireless_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.network_file = open(filename, "w+")
        file = self.network_file
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")

        file.write("\n")

        board_name = BoardUtil.get_board_name()

        interfaces = settings["network"]["interfaces"]
        devidx = 0
        for intf in interfaces:
            if intf.get("type") == "WIFI":
                file.write("config wifi-device 'radio%d'\n" % devidx)
                file.write("\toption type 'mac80211'\n")
                file.write("\toption channel '{}'\n".format(intf["wirelessChannel"]))
                file.write(f"\toption band '{self.get_band(intf)}'\n")
                if board_name in ["globalscale,espressobin", "globalscale,espressobin-v7-emmc"]:
                    file.write("\toption legacy_rates '1'\n")
                file.write(f"\t{self.get_device_id(intf)}\n")
                thruput = intf.get("wirelessThroughput")
                if thruput is None or thruput in ("", "AUTO"):
                    file.write(f"{self.get_htmode(intf)}")
                else:
                    file.write(f"\toption htmode '{thruput}'\n")
                if not intf.get("enabled"):
                    file.write("\toption disabled '1'\n")
                else:
                    file.write("\toption disabled '0'\n")
                self.write_country(file)
                file.write("\n")
                file.write("config wifi-iface 'default_radio%d'\n" % devidx)
                file.write("\toption device 'radio%d'\n" % devidx)
                file.write("\toption ifname '{}'\n".format(intf.get("device")))
                bridge_name = network_util.get_bridge_name(settings, intf, "ipv4")
                if bridge_name != "":
                    file.write(f"\toption network '{bridge_name}'\n")
                elif intf.get("configType") == "ADDRESSED":
                    file.write(
                        "\toption network '{}'\n".format(
                            network_util.get_interface_name(settings, intf, "ipv4")
                        )
                    )
                if intf.get("wirelessMode") == "AP":
                    file.write("\toption mode 'ap'\n")
                else:
                    file.write("\toption mode 'sta'\n")
                file.write("\toption ssid '{}'\n".format(intf.get("wirelessSsid")))
                hidden = 1 if intf.get("hidden") is True else 0
                file.write(f"\toption hidden '{hidden}'\n")
                self.write_wireless_encryption(
                    file, intf.get("wirelessEncryption"), intf.get("wirelessPassword")
                )
                self.write_macaddr(file, intf.get("macaddr"))
                file.write("\n")
                devidx += 1

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))


def enabled_wifi(intf) -> bool:
    """returns true if the interface is an enabled wifi interface"""
    return bool(intf.get("enabled") and intf.get("type") == "WIFI")


registrar.register_manager(WirelessManager())
