"""network_manager manages /etc/config/network"""

import base64
import ipaddress
import os
import stat
from typing import Any

from sync import EncryptionUtil, board_util, network_util, registrar
from sync.board_util import BoardUtil
from sync.common import Logger
from sync.common.network_manager import NetworkManager
from sync.file_util import FileUtil
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

logger = Logger.getInstance()


class OpenWrtNetworkManager(NetworkManager):
    """
    This class is responsible for writing /etc/config/network
    based on the settings object passed from sync-settings for OpenWrt
    """

    network_filename = "/etc/config/network"
    network_file = None
    uid_path = FileUtil.locate_file("/etc/config/uid")

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.network_filename, "restart-networking", self)

    def sanitize_settings_pre(self, settings_file: SettingsFile) -> None:
        """sanitizes removes blank settings"""
        logger.info("Sanitizing settings pre")

    def sanitize_settings_post(self, settings_file: SettingsFile) -> None:
        # Clear "new" flag and enable the interface if it is bridged
        logger.info("Sanitizing settings post")

    def sanitize_settings(self, settings_file: SettingsFile) -> None:
        # Missing static routes settings.
        logger.info("Sanitizing settings")
        # upgrades to 6.2, if settings doesn't have usePeerDns property for WWAN interface, add it.
        if settings_file.settings.get("version") <= 5:
            interfaces = settings_file.settings.get("network", {}).get("interfaces", [])
            for intf in interfaces:
                if intf.get("type") == "WWAN":
                    intf["usePeerDns"] = intf.get("usePeerDns", False)

    def validate_settings(self, settings_file: SettingsFile) -> None:
        """validates settings"""
        logger.info("Validating settings")

    def create_settings(
        self,
        settings_file: SettingsFile,
        prefix: str,
        delete_list: list[str],
        filename: str,
    ) -> None:
        """creates settings"""
        logger.info("Creating settings")

    def sync_settings(
        self, settings_file: SettingsFile, prefix: str, _delete_list: list[str]
    ) -> None:
        """syncs settings"""
        logger.info("Syncing settings")
        self.write_network_file(settings_file, prefix)

    def write_network_file(self, settings_file: SettingsFile, prefix: str) -> None:
        """write /etc/config/network"""
        settings = settings_file.settings

        filename = prefix + self.network_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.network_file = open(filename, "w+")
        file = self.network_file
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")

        file.write("\n")
        file.write("config interface 'loopback'\n")
        file.write("\t" + "option ifname 'lo'\n")
        file.write("\t" + "option proto 'static'\n")
        file.write("\t" + "option ipaddr '127.0.0.1'\n")
        file.write("\t" + "option netmask '255.0.0.0'\n")
        file.write("\n")
        if SettingsFile.os_name != "eos":
            file.write("config globals 'globals'" + "\n")
            file.write("\t" + "option ula_prefix 'fdf1:ab86:f5ab::/48'" + "\n")

        interfaces = settings["network"]["interfaces"]

        for intf in interfaces:
            if intf.get("enabled"):
                if intf.get("type") == "OPENVPN":
                    self.write_interface_openvpn(intf, settings, prefix)
                elif intf.get("type") == "WIREGUARD":
                    self.write_interface_wireguard(intf)
                elif intf.get("type") == "IPSEC":
                    self.write_interface_ipsec(intf, settings)
                elif intf.get("type") == "WWAN":
                    self.write_interface_wwan(intf)
                elif intf.get("type") == "BRIDGE":
                    self.write_interface_type_bridge(intf, settings)
                elif intf.get("type") == "WIFI":
                    if (
                        network_util.get_bridge_name(settings, intf, "ipv4") == ""
                    ):  # Write WIFI interface only if it is not part of Bridge
                        self.write_interface_generic(intf, settings)
                else:
                    self.write_interface_generic(intf, settings)

        switches = settings["network"].get("switches")
        if switches is not None:
            for swi in switches:
                self.write_switch(swi)

        # Write out static routes
        routes = settings["routes"]
        for route in routes:
            # Write out static route entry
            if route.get("enabled"):
                route_str = self.write_static_route(settings, route)
                if route_str:
                    file.write(route_str)

        self.write_lan_route_rules(settings_file)
        self.write_vpn_rules(settings_file)
        self.write_public_wan_rules(settings_file)

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_static_route(self, settings: SettingsFile, route: dict[str, str]) -> str:
        """Create route rules for static routes to be added in /etc/config/networks"""

        if route.get("interface"):
            interfaceName = route.get("interface")
        elif route.get("interfaceId"):
            _id = route.get("interfaceId")
            intf = network_util.get_interface_by_id(settings, interfaceId=_id)
            interfaceName = network_util.get_interface_name(settings, intf, "ipv4")
        else:
            intf1 = network_util.get_interface_by_ip(settings, route.get("nextHop"))
            if intf1 is not None:
                interfaceName = network_util.get_interface_name(settings, intf1, "ipv4")
            else:
                logger.debug("NextHop address does not belong to any of MGMT or LAN interfaces")
                return ""

        static_route = "\nconfig route\n"
        static_route += "\t" + f"option interface '{interfaceName}'\n"
        static_route += "\t" + f"option target '{route.get('network').split('/')[0]}'\n"
        static_route += "\t" + "option table 'main'\n"
        static_route += "\t" + "option netmask '{}'\n".format(
            str(ipaddress.IPv4Network(route.get("network")).netmask)
        )
        static_route += "\t" + f"option gateway '{route.get('nextHop')}'\n"
        if route.get("metric"):
            static_route += "\t" + f"option metric {route.get('metric', 0)}\n"

        return static_route

    def write_interface_generic(self, intf: dict, settings: dict) -> None:
        self.write_interface_bridge(intf, settings)
        self.write_interface_v4(intf, settings)
        self.write_interface_v6(intf)

    def write_lan_route_rules(self, settings_file: SettingsFile) -> None:
        """
        Create route rules to ensure local lan to lan traffic gets
        routed correctly.  Local lans will be enabled, non-wan, statically
        addressed interfaces
        """
        settings = settings_file.settings
        priority = 3000
        file = self.network_file
        file.write("\n")

        interfaces = settings["network"]["interfaces"]
        for intf in interfaces:
            if (
                intf.get("enabled")
                and not intf.get("wan")
                and intf.get("configType") in ["ADDRESSED", "BRIDGED"]
                and intf.get("v4ConfigType") == "STATIC"
            ):
                file.write("config rule\n")
                file.write(
                    "\toption dest '%s/%d'\n"
                    % (intf.get("v4StaticAddress"), intf.get("v4StaticPrefix"))
                )
                file.write(f"\toption priority '{priority}'\n")
                file.write("\toption lookup 'main'\n")
                file.write("\n")

                priority = priority + 1

        # Write lookup rule for static route
        routes = settings["routes"]
        for route in routes:
            # We do not write rules where destination is on the management interface.
            nextHopintf = network_util.get_interface_by_ip(settings, route.get("nextHop"))
            if route.get("enabled") and not network_util.is_management_interface(nextHopintf):
                file.write("config rule\n")
                file.write(f"\toption dest '{route.get('network')}'\n")
                file.write(f"\toption priority '{priority}'\n")
                file.write("\toption lookup 'main'\n")
                file.write("\n")

                priority = priority + 1

    def write_vpn_rules(self, settings_file: SettingsFile) -> None:
        """
        Create route rules for VPNs to remote lan traffic gets
        routed correctly.
        Primary usage is for WireGuard and IPSec VPNs.
        """
        settings = settings_file.settings

        # Hack here - if Ipsec, we should set the priority to 8000 because we want the WAN rules to take over
        # This has been a regression back and forth between multiple tickets for too long.
        ipsec_priority = 8000
        wg_priority = 5000

        file = self.network_file
        file.write("\n")

        ipsec_manager = registrar.get_manager("IpsecManager")
        interfaces_settings = settings["network"]["interfaces"]
        for interface_settings in interfaces_settings:
            if interface_settings.get("enabled") is False:
                continue

            interface_id = interface_settings.get("interfaceId")
            if interface_settings.get("type") == "WIREGUARD":
                peers = interface_settings.get("wireguardPeers")
                for peer in peers:
                    ips = peer.get("allowedIps")
                    for ip in ips:
                        address = ip.get("address")
                        prefix = ip.get("prefix")

                        # Don't write out a rule for 'default'
                        if address == "0.0.0.0" and prefix == 0:
                            continue

                        file.write("config rule\n")
                        file.write(f"\toption dest '{address}/{prefix}'\n")
                        file.write(f"\toption priority '{wg_priority}'\n")
                        file.write(f"\toption lookup 'wan.{interface_id}'\n")
                        file.write("\n")

                        wg_priority = wg_priority + 1
            elif interface_settings.get("type") == "IPSEC":
                networks = ipsec_manager.get_interface_networks(settings_file, interface_settings)
                for network in networks:
                    if network.get("network") != "0.0.0.0":
                        # Only rule for non-default.  Otherwise Ipsec cannot negotiate.
                        file.write("config rule\n")
                        file.write(
                            "\toption dest '%s/%d'\n"
                            % (network.get("network"), network.get("prefix"))
                        )
                        file.write(f"\toption priority '{ipsec_priority}'\n")
                        file.write(f"\toption lookup 'wan.{interface_id}'\n")
                        file.write("\n")

                    file.write("\nconfig route\n")
                    if "interface" in network:
                        interface_name = network.get("interface")
                    else:
                        interface_name = interface_settings.get("logical_name")
                    file.write("\t" + f"option interface '{interface_name}'\n")
                    file.write("\t" + f"option target '{network.get('network')}'\n")
                    file.write("\t" + f"option table 'wan.{interface_id}'" + "\n")
                    file.write("\t" + f"option netmask '{network.get('netmask')}'\n")
                    source_address = network.get("source_address")
                    if source_address is not None:
                        file.write("\t" + f"option source '{source_address}'\n")
                    file.write("\n")

                    ipsec_priority = ipsec_priority + 1

    def write_public_wan_rules(self, settings_file: SettingsFile) -> None:
        """
        Write WAN route rules
        """
        settings = settings_file.settings
        fwmark_priority = 7000
        oif_priority = 6000
        self.network_file.write("\n")

        interfaces = settings["network"]["interfaces"]
        for intf in interfaces:
            if network_util.enabled_wan(intf):
                if intf.get("v4ConfigType") != "DISABLED":
                    self.create_wan_route_rules_ipfamily(
                        settings, intf, fwmark_priority, oif_priority, "ipv4"
                    )

                if intf.get("v6ConfigType") != "DISABLED":
                    self.create_wan_route_rules_ipfamily(
                        settings, intf, fwmark_priority, oif_priority, "ipv6"
                    )

                fwmark_priority = fwmark_priority + 1
                oif_priority = oif_priority + 1

    def create_wan_route_rules_ipfamily(
        self,
        settings: dict[str, str],
        intf: dict[str, str],
        fwmark_priority: int,
        oif_priority: int,
        family: str,
    ) -> None:
        """create_route_wan_rules_ipfamily creates route rules for a specific ip family rule type"""
        ruleType = "rule" if family == "ipv4" else "rule6"
        self.network_file.write(f"config {ruleType}\n")
        self.network_file.write(f"\toption mark '0x{intf.get('interfaceId'):x}00/0xff00'\n")
        self.network_file.write("\toption priority '%d'\n" % fwmark_priority)
        self.network_file.write("\toption lookup 'wan.%d'\n" % intf.get("interfaceId"))
        self.network_file.write("\n")

        self.network_file.write(f"config {ruleType}\n")
        self.network_file.write(
            f"\toption out '{network_util.get_interface_name(settings, intf, family)}'\n"
        )
        self.network_file.write("\toption priority '%d'\n" % oif_priority)
        self.network_file.write("\toption lookup 'wan.%d'\n" % intf.get("interfaceId"))
        self.network_file.write("\n")

    def write_switch(self, swi: dict[str, str]) -> None:
        """write the switch config"""

        self.network_file.write("\n")
        self.network_file.write("config switch\n")
        self.network_file.write(f"\toption name '{swi['name']}'\n")
        self.network_file.write("\toption reset '1'\n")
        self.network_file.write("\toption enable_vlan '1'\n")
        self.network_file.write("\n")
        vlan_list = swi["vlans"]
        for vlan in vlan_list:
            self.network_file.write("config switch_vlan\n")
            self.network_file.write(f"\toption device '{swi['name']}'\n")
            self.network_file.write(f"\toption vlan '{vlan['id']}'\n")
            vlan_ports = []
            for port in swi["ports"]:
                if port["pvid"] == vlan["id"]:
                    if port["cpu_port"] is True:
                        vlan_ports.append(f"{port['id']}t")
                    else:
                        vlan_ports.append(f"{port['id']}")
            self.network_file.write(f"\toption ports '{' '.join(vlan_ports)}'\n")
            self.network_file.write("\n")

    def write_interface_wwan(self, intf: dict[str, str]) -> None:
        """write a wwan interface"""
        file = self.network_file
        ifname = intf["ifname"]
        device = "/dev/cdc-wdm" + ifname.split("wwan")[-1]

        file.write("\n")
        file.write(f"config interface '{intf['logical_name']}'\n")
        file.write("\toption proto 'qmi'\n")
        file.write(f"\toption ifname '{ifname}'\n")
        file.write(f"\toption device '{device}'\n")
        if intf.get("mtu") and intf.get("device").startswith("et"):
            file.write("\toption mtu '%d'\n" % intf.get("mtu"))

        if intf.get("simDelay") is not None:
            file.write("\toption delay '%d'\n" % intf.get("simDelay"))

        if intf.get("simTimeout") is not None:
            file.write("\toption timeout '%d'\n" % intf.get("simTimeout"))

        if intf.get("simApn") is not None:
            file.write(f"\toption apn '{intf.get('simApn')}'\n")
        else:
            file.write("\toption apn 'any'\n")

        if intf.get("simProfile") is not None:
            file.write("\toption profile '%d'\n" % intf.get("simProfile"))

        if intf.get("simPin") is not None:
            file.write(f"\toption pincode '{intf.get('simPin')}'\n")

        auth = intf.get("simAuth")
        if auth is not None and auth != "NONE":
            if auth == "PAP":
                file.write("\toption auth 'pap'\n")
            elif auth == "CHAP":
                file.write("\toption auth 'chap'\n")
            else:
                file.write("\toption auth 'both'\n")

            file.write(f"\toption username '{intf.get('simUsername')}'\n")
            file.write(f"\toption password '{intf.get('simPassword')}'\n")

        mode = intf.get("simMode")
        if mode is None or mode == "ALL":
            file.write("\toption modes 'all'\n")
        elif mode == "LTE":
            file.write("\toption modes 'lte'\n")
        elif mode == "UMTS":
            file.write("\toption modes 'umts'\n")
        elif mode == "GSM":
            file.write("\toption modes 'gsm'\n")
        elif mode == "CDMA":
            file.write("\toption modes 'cdma'\n")
        elif mode == "TDSCDMA":
            file.write("\toption modes 'td-scdma'\n")

        pdptype = intf.get("simPdptype")
        if pdptype is None or pdptype == "IPV4":
            file.write("\toption pdptype 'ip'\n")
        elif pdptype == "IPV6":
            file.write("\toption pdptype 'ipv6'\n")
        elif pdptype == "IPV4V6":
            file.write("\toption pdptype 'ipv4v6'\n")

        plmn = intf.get("simPlmn")
        if plmn is not None:
            file.write(f"\toption plmn '{intf.get('simPlmn')}'\n")

        autoconnect = intf.get("simAutoconnect")
        if autoconnect is not None:
            if autoconnect is True:
                file.write("\toption autoconnect '1'\n")
            else:
                file.write("\toption autoconnect '0'\n")

        if intf.get("wan"):
            if intf.get("v4ConfigType") != "DISABLED":
                file.write(f"\toption ip4table 'wan.{intf.get('interfaceId')}'\n")

            if intf.get("v6ConfigType") != "DISABLED":
                file.write(f"\toption ip6table 'wan.{intf.get('interfaceId')}'\n")

            if intf.get("v6ConfigType") != "DISABLED" or intf.get("v4ConfigType") != "DISABLED":
                file.write("\toption defaultroute '1'\n")

            if intf.get("v6ConfigType") == "DHCP":
                file.write("\toption dhcpv6 '1'\n")
            if intf.get("usePeerDns") is True:
                file.write("\toption peerdns '1'\n")

    def write_bridge_interface_v4(self, intf: dict[str, str]) -> None:
        file = self.network_file
        file.write("\n")
        file.write(f"config interface '{intf['logical_name'] + '4'}'\n")
        self.write_interface_v4_config(intf)
        file.write(f"\toption device '{intf.get('device')}'\n")

    def write_interface_lan(self, intf: dict[str, str]) -> None:
        """write lan interface config"""
        self.write_bridge_interface_v4(intf)
        self.write_interface_v6(intf)

    def write_network_device(
        self,
        intf: dict[str, str],
        settings: dict[str, str],
    ) -> None:
        """write config device bridge"""
        file = self.network_file
        file.write("\nconfig device\n")
        file.write("\toption type 'bridge'\n")
        file.write(f"\toption name '{intf.get('name')}'\n")
        bridgeto = intf.get("bridgedInterfaces")

        for bridge_member in bridgeto:
            interface = network_util.get_interface_by_id(settings, bridge_member)
            if interface is None:
                continue

            file.write(f"\tlist ports '{interface.get('device')}'\n")

    def write_interface_type_bridge(
        self,
        intf: dict[str, str],
        settings: dict[str, str],
    ) -> None:
        """write interface type bridge"""

        if intf.get("configType") != "BRIDGED":
            return

        bridgeto = intf.get("bridgedInterfaces")
        if bridgeto:
            intf["is_bridge"] = True
            intf["logical_name"] = "b_" + intf["name"]
            intf["ifname"] = "br-" + intf["logical_name"]

        if not intf.get("is_bridge"):
            return

        if intf.get("wan") == "true":
            return

        self.write_network_device(intf, settings)
        self.write_interface_lan(intf)

    def write_interface_ipsec(
        self,
        intf: dict[str, str],
        settings: dict[str, str],
    ) -> None:
        """write a ipsec interface"""
        file = self.network_file

        bound_interface = network_util.get_interface_by_id(settings, intf.get("boundInterfaceId"))
        remote_gateway = intf.get("ipsec").get("remote").get("gateway")
        local_gateway = intf.get("ipsec").get("local").get("gateway")
        intf_family = intf.get("family")

        file.write("\n")
        file.write(f"config interface '{intf['logical_name']}'\n")

        proto_type = "vti"
        wan_table = "ip4table"
        unspecified_address = "0.0.0.0"
        alias_key = "v4Aliases"

        if intf_family == "ipv6":
            proto_type = "vti6"
            wan_table = "ip6table"
            unspecified_address = "::/0"
            alias_key = "v6Aliases"

        file.write(f"\toption proto '{proto_type}'\n")

        if remote_gateway == "%any":
            file.write(f"\toption peeraddr '{unspecified_address}'\n")
        else:
            file.write(f"\toption peeraddr '{remote_gateway}'\n")
            # If the interface is unbound (any wan can reply), and the local gateway is set to %any
            # OR if the bound interface has any IP aliases attached!
            #
            # then set the IP address on the VTI to 0.0.0.0
            # This is because /lib/netifd/proto/vti.sh will set the VTI interface to the first available IP
            # if this is not configured. Only run this when peeraddr is populated with something besides 0.0.0.0
            if local_gateway == "%any" and (
                bound_interface is None
                or (
                    bound_interface.get(alias_key) is not None
                    and len(bound_interface.get(alias_key)) > 0
                )
            ):
                file.write(f"\toption ipaddr '{unspecified_address}'\n")

        if local_gateway != "%any":
            file.write(f"\toption ipaddr '{local_gateway}'\n")

        file.write(f"\toption ikey '0x{intf.get('interfaceId'):x}'\n")
        file.write(f"\toption okey '0x{intf.get('interfaceId'):x}00'\n")
        if bound_interface is not None:
            file.write(
                f"\toption tunlink '{network_util.get_interface_name(settings, bound_interface, intf_family)}'\n"
            )

        file.write(f"\toption {wan_table} 'wan.{intf.get('interfaceId')}'\n")

        # Only write MTU out if routeMtu is disabled
        if not intf.get("routeMtu") and intf.get("mtu") is not None:
            mtu = intf.get("mtu")
            file.write("\toption mtu '%d'\n" % mtu)

    def write_interface_wireguard(self, intf: dict[str, str]) -> None:
        """write a wireguard interface"""
        file = self.network_file

        file.write("\n")
        file.write(f"config interface '{intf['logical_name']}'\n")
        file.write("\toption proto 'wireguard'\n")
        file.write(f"\toption private_key '{intf.get('wireguardPrivateKey')}'\n")
        addresses = intf.get("wireguardAddresses")
        for address in addresses:
            file.write(f"\tlist addresses '{address.get('address')}/{address.get('prefix')}'\n")
        if intf.get("wireguardType") == "TUNNEL" and intf.get("wireguardPort") is not None:
            file.write(f"\toption listen_port '{intf.get('wireguardPort')}'\n")
        if intf.get("mtu") and intf.get("device").startswith("et"):
            file.write("\toption mtu '%d'\n" % intf.get("mtu"))

        if intf.get("wan"):
            if intf.get("v4ConfigType") != "DISABLED":
                file.write("\toption ip4table 'wan.%d'\n" % intf.get("interfaceId"))

            if intf.get("v6ConfigType") != "DISABLED":
                file.write("\toption ip6table 'wan.%d'\n" % intf.get("interfaceId"))

            if intf.get("v6ConfigType") != "DISABLED" or intf.get("v4ConfigType") != "DISABLED":
                file.write("\toption defaultroute '1'\n")

        file.write("\n")
        peers = intf.get("wireguardPeers")
        for peer in peers:
            file.write(f"config 'wireguard_{intf['logical_name']}'\n")
            file.write(f"\toption public_key '{peer.get('publicKey')}'\n")
            if peer.get("routeAllowedIps") is not None and peer.get("routeAllowedIps"):
                file.write("\toption route_allowed_ips '1'\n")
            else:
                file.write("\toption route_allowed_ips '0'\n")
            ips = peer.get("allowedIps")
            for ip in ips:
                file.write(f"\tlist allowed_ips '{ip.get('address')}/{ip.get('prefix')}'\n")
            if peer.get("host") is not None:
                file.write(f"\toption endpoint_host '{peer.get('host')}'\n")
            if peer.get("port") is not None:
                file.write(f"\toption endpoint_port '{peer.get('port')}'\n")
            if peer.get("keepalive") is not None:
                file.write("\toption persistent_keepalive '%d'\n" % peer.get("keepalive"))
            if peer.get("presharedKey") is not None:
                file.write(f"\toption preshared_key '{peer.get('presharedKey')}'\n")

    def write_interface_openvpn(
        self, intf: dict[str, str], settings: dict[str, str], prefix: str
    ) -> None:
        """write an openvpn interface"""
        file = self.network_file

        path = "/etc/config/openvpn-" + str(intf["interfaceId"]) + ".ovpn"
        auth_path = "/etc/config/openvpn-" + str(intf["interfaceId"]) + ".auth"

        file.write("\n")
        file.write(f"config interface '{intf['logical_name']}'\n")
        file.write(f"\toption ifname '{intf['ifname']}'\n")
        file.write("\toption proto 'openvpn'\n")
        file.write(f"\toption config '{path}'\n")
        if intf.get("mtu") and intf.get("device").startswith("et"):
            file.write("\toption mtu '%d'\n" % intf.get("mtu"))

        if intf.get("wan"):
            if intf.get("v4ConfigType") != "DISABLED":
                file.write("\toption ip4table 'wan.%d'\n" % intf.get("interfaceId"))

            if intf.get("v6ConfigType") != "DISABLED":
                file.write("\toption ip6table 'wan.%d'\n" % intf.get("interfaceId"))

            if intf.get("v6ConfigType") != "DISABLED" or intf.get("v4ConfigType") != "DISABLED":
                file.write("\toption defaultroute '1'\n")

            if "openvpnPeerDns" in intf and intf.get("openvpnPeerDns") is True:
                file.write("\toption peerdns '1'\n")

        if intf.get("openvpnUsernamePasswordEnabled"):
            file.write(f"\toption authfile '{auth_path}'\n")

        wanId = intf.get("boundInterfaceId")
        if wanId is not None:
            # FIXME: This is currently defined as a string, but probably should be an int.
            # Deal with either for now
            if isinstance(wanId, str):
                wanId = int(wanId, 10)

            if wanId != 0:
                # If we have v4 or v6 configured, we can bind to both. The openvpn.sh script in openvpn-proto adds a local bind for both the IPv4 wanif and IPv6 wanif6 configurations
                if intf.get("v4ConfigType") != "DISABLED":
                    file.write(
                        "\toption wanif '{}'\n".format(
                            network_util.get_interface_name(
                                settings,
                                network_util.get_interface_by_id(settings, wanId),
                                "ipv4",
                            )
                        )
                    )
                if intf.get("v6ConfigType") != "DISABLED":
                    file.write(
                        "\toption wanif6 '{}'\n".format(
                            network_util.get_interface_name(
                                settings,
                                network_util.get_interface_by_id(settings, wanId),
                                "ipv6",
                            )
                        )
                    )

        # also write the conf file
        self.write_openvpn_conf_file(intf, path, prefix)
        if intf.get("openvpnUsernamePasswordEnabled"):
            self.write_openvpn_auth_file(intf, auth_path, prefix)

    def write_openvpn_auth_file(self, intf: dict[str, str], path: str, prefix: str) -> None:
        """write the openvpn username/password auth file"""
        username = intf.get("openvpnUsername")
        password_base64 = intf.get("openvpnPasswordBase64")
        if username is None:
            raise SettingsException(
                message_str="Missing username on openvpn interface: " + intf["interfaceId"]
            )
        if password_base64 is None:
            raise SettingsException(
                message_str="Missing password on openvpn interface: " + intf["interfaceId"]
            )
        try:
            password = base64.b64decode(password_base64).decode()
        except Exception as err:
            raise SettingsException(
                message_str="Failed to parse password on openvpn interface: " + intf["interfaceId"]
            ) from err

        filename = prefix + path
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write(f"{username}\n{password}\n")
        file.flush()
        file.close()
        os.chmod(filename, stat.S_IWRITE | stat.S_IREAD)
        logger.info("Wrote %s", str(filename))

    def write_openvpn_conf_file(self, intf: dict[str, str], path: str, prefix: str) -> None:
        """write the specified file"""

        filename = prefix + path
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        conffile = intf["openvpnConfFile"]

        file = open(filename, "wb+")
        # only base64 is currently supported
        if conffile.get("encoding") == "base64":
            contents = base64.b64decode(conffile.get("contents"))
            contents = contents.replace(b"nobind", b"#nobind")
            contents = contents.replace(b"persist-tun", b"#persist-tun")
            file.write(contents)
            file.write(b"route-nopull\n")
            file.flush()
            file.close()
            logger.info("Wrote %s", str(filename))

    def write_interface_bridge(self, intf: dict[str, str], settings: dict[str, str]) -> None:
        """write a bridge interface"""
        if intf.get("configType") != "ADDRESSED":
            return
        if not intf.get("is_bridge"):
            return
        # find interfaces bridged to this interface
        file = self.network_file

        file.write("\n")
        file.write(f"config interface '{intf['logical_name']}'\n")
        file.write("\toption type 'bridge'\n")
        file.write(f"\toption ifname '{' '.join(intf.get('bridged_interfaces_str'))}'\n")
        self.write_macaddr(intf.get("macaddr"))
        # In some cases netifd handles it better if the ipv4 config is written under the main
        # bridge interface instead of the first alias
        # To do so uncomment this line and disable writing of the first alias
        # This is commented out for now to see if treating bridges normally works
        # If so, this should be removed
        # self.write_interface_v4_config(intf, settings)

        return

    def write_interface_v4(self, intf: dict[str, str], settings: dict[str, str]) -> None:
        """
        Writes a new logical interface containing the IPv4 configuration
        """
        if intf.get("configType") != "ADDRESSED":
            return
        if intf.get("v4ConfigType") == "DISABLED":
            return
        # If this interface is a bridge-master
        # the IPv4 config would have been written in the bridge interface
        # This is commented out for now to see if treating bridges normally works
        # If so, this should be removed
        # if intf.get('is_bridge'):
        #     return

        file = self.network_file

        file.write("\n")
        if intf.get("type") == "VLAN":
            file.write(f"config interface '{intf['name'] + '4'}'\n")
        else:
            file.write(f"config interface '{intf['logical_name'] + '4'}'\n")
        file.write(f"\toption ifname '{intf['ifname']}'\n")
        self.write_macaddr(intf.get("macaddr"))
        self.write_interface_v4_config(intf)
        self.write_interface_broadcast_addr(intf)

        if intf.get("v4Aliases") is not None:
            for idx, alias in enumerate(intf.get("v4Aliases")):
                self.write_interface_v4_alias(intf, alias, (idx + 1))

        return

    def write_interface_v4_config(self, intf: dict[str, str]) -> None:
        """
        Writes the actual IPv4 configuration options for an interface
        This is a separate function because depending on the configuration this may be written in different locations
        """
        file = self.network_file

        if intf.get("v4ConfigType") == "DHCP":
            if not intf.get("wan") and not intf.get("management"):
                raise SettingsException(
                    message_str="Invalid v4ConfigType: Can not use DHCP on non-WAN or non-management interfaces"
                )

            if BoardUtil.is_platform_os_eos() and intf.get("wan") is True:
                # EOS is handling acquiring a DHCP address.
                return

            file.write("\toption proto 'dhcp'\n")
            if (
                intf.get("v4DhcpAddressOverride") is not None
                and intf.get("v4DhcpAddressOverride") != ""
            ):
                file.write(f"\toption ipaddr '{intf.get('v4DhcpAddressOverride')}'\n")
            if (
                intf.get("v4DhcpDNS1Override") is not None
                and intf.get("v4DhcpDNS1Override") != ""
                and intf.get("v4DhcpDNS2Override") is not None
                and intf.get("v4DhcpDNS2Override") != ""
            ):
                file.write(
                    "\toption dns '{} {}'\n".format(
                        intf.get("v4DhcpDNS1Override"), intf.get("v4DhcpDNS2Override")
                    )
                )
                file.write("\toption peerdns '0'\n")
            elif (
                intf.get("v4DhcpDNS1Override") is not None and intf.get("v4DhcpDNS1Override") != ""
            ):
                file.write(f"\toption dns '{intf.get('v4DhcpDNS1Override')}'\n")
                file.write("\toption peerdns '0'\n")
        elif intf.get("v4ConfigType") == "STATIC":
            file.write("\toption proto 'static'\n")
            if intf.get("wan"):
                file.write("\toption force_link '0'\n")
            file.write(f"\toption ipaddr '{intf.get('v4StaticAddress')}'\n")
            file.write(
                "\toption netmask '{}'\n".format(
                    network_util.ipv4_prefix_to_netmask(intf.get("v4StaticPrefix"))
                )
            )
            if intf.get("wan") and intf.get("v4StaticGateway") is not None:
                file.write(f"\toption gateway '{intf.get('v4StaticGateway')}'\n")
        elif intf.get("v4ConfigType") == "PPPOE":
            if not intf.get("wan"):
                raise SettingsException(
                    message_str="Invalid v4ConfigType: Can not use PPPOE on non-WAN interfaces"
                )
            file.write("\toption proto 'pppoe'\n")
            file.write(f"\toption username '{intf.get('v4PPPoEUsername')}'\n")

            decrypted_password = EncryptionUtil.execute_password_manager(
                "-d", intf.get("v4PPPoEPasswordEncrypted")
            )
            file.write(f"\toption password '{decrypted_password!s}'\n")

            if intf.get("v4PPPoEUsePeerDNS") is True:
                file.write("\toption peerdns '1'\n")
            else:
                file.write("\toption peerdns '0'\n")
                dnslist = ""
                if (
                    intf.get("v4PPPoEOverrideDNS1") is not None
                    and intf.get("v4PPPoEOverrideDNS1") != ""
                ):
                    dnslist = intf.get("v4PPPoEOverrideDNS1")
                if (
                    intf.get("v4PPPoEOverrideDNS2") is not None
                    and intf.get("v4PPPoEOverrideDNS2") != ""
                ):
                    if len(dnslist) != 0:
                        dnslist += ", "
                        dnslist += intf.get("v4PPPoEOverrideDNS2")
                    else:
                        dnslist = intf.get("v4PPPoEOverrideDNS2")
                if len(dnslist) == 0:
                    raise SettingsException(
                        message_str="Use Peer DNS is disabled and no DNS servers are configured"
                    )
                file.write(f"\toption dns '{dnslist}'\n")

            # Create the pppoe interface name here, and use it for any netfilterDev references
            # for this interface later
            pppoeName = "ppp-" + intf["logical_name"]
            file.write(f"\toption pppname '{pppoeName}'\n")
            intf["netfilterDev"] = pppoeName

        elif intf.get("v4ConfigType") == "DISABLED":
            # This needs to be written for addressless bridges
            file.write("\toption proto 'none'\n")
            file.write("\toption auto '1'\n")

        if intf.get("wan") and intf.get("v4ConfigType") != "DISABLED":
            file.write("\toption ip4table 'wan.%d'\n" % intf.get("interfaceId"))

        if intf.get("mtu") and intf.get("device").startswith("et"):
            file.write("\toption mtu '%d'\n" % intf.get("mtu"))

    def write_interface_v4_alias(
        self, intf: dict[str, str], alias: dict[str, str], count: int
    ) -> None:
        """
        Write an IPv4 alias interface
        """
        file = self.network_file

        file.write("\n")
        intf_config_name = intf["name"] if intf.get("type") == "VLAN" else intf["logical_name"]
        file.write(f"config interface '{intf_config_name + '4' + '_' + str(count)}'\n")
        file.write(f"\toption ifname '{intf['ifname']}'\n")
        file.write("\toption proto 'static'\n")
        if intf.get("wan"):
            file.write("\toption force_link '0'\n")
        file.write(f"\toption ipaddr '{alias.get('v4Address')}'\n")
        file.write(
            "\toption netmask '{}'\n".format(
                network_util.ipv4_prefix_to_netmask(alias.get("v4Prefix"))
            )
        )

    def write_interface_v6(self, intf: dict[str, str]) -> None:
        """
        Writes a new logical interface containing the IPv6 configuration
        """
        if intf.get("configType") != "ADDRESSED" and intf.get("configType") != "BRIDGED":
            return

        if intf.get("v6ConfigType") == "DISABLED":
            return
        file = self.network_file
        file.write("\n")
        file.write(f"config interface '{intf['logical_name'] + '6'}'\n")
        file.write(f"\toption ifname '{intf['ifname']}'\n")
        self.write_macaddr(intf.get("macaddr"))

        if intf.get("v6ConfigType") == "DHCP":
            file.write("\toption proto 'dhcpv6'\n")
            if (
                intf.get("v6DhcpDNS1Override") is not None
                and intf.get("v6DhcpDNS2Override") is not None
            ):
                file.write(
                    "\toption dns '{} {}'\n".format(
                        intf.get("v6DhcpDNS1Override"), intf.get("v6DhcpDNS2Override")
                    )
                )
                file.write("\toption peerdns '0'\n")
            elif intf.get("v6DhcpDNS1Override") is not None:
                file.write(f"\toption dns '{intf.get('v6DhcpDNS1Override')}'\n")
                file.write("\toption peerdns '0'\n")
        elif intf.get("v6ConfigType") == "SLAAC":
            # FIXME
            pass
        elif intf.get("v6ConfigType") == "ASSIGN":
            file.write("\toption proto 'static'\n")
            file.write(f"\toption ip6assign '{intf.get('v6AssignPrefix')}'\n")
            file.write(f"\toption ip6hint '{intf.get('v6AssignHint')}'\n")
        elif intf.get("v6ConfigType") == "STATIC":
            if intf.get("v6StaticAddress") is not None and intf.get("v6StaticPrefix") is not None:
                file.write("\toption proto 'static'\n")
                file.write(
                    "\toption ip6addr '{}/{}'\n".format(
                        intf.get("v6StaticAddress"), intf.get("v6StaticPrefix")
                    )
                )
                if intf.get("wan") and intf.get("v6StaticGateway") is not None:
                    file.write(f"\toption ip6gw '{intf.get('v6StaticGateway')}'\n")

        if intf.get("v6Aliases") is not None and intf.get("v6ConfigType") == "STATIC":
            for idx, alias in enumerate(intf.get("v6Aliases")):
                self.write_interface_v6_alias(intf, alias, (idx + 1))

        if intf.get("wan"):
            file.write("\toption ip6table 'wan.%d'\n" % intf.get("interfaceId"))
        return

    def write_interface_v6_alias(
        self, intf: dict[str, str], alias: dict[str, str], count: int
    ) -> None:
        """
        Write an IPv6 alias interface
        """
        file = self.network_file

        file.write("\n")
        file.write(f"config interface '{intf['logical_name'] + '6' + '_' + str(count)}'\n")
        file.write(f"\toption ifname '{intf['ifname']}'\n")
        file.write("\toption proto 'static'\n")
        file.write(f"\toption ip6addr '{alias.get('v6Address')}/{alias.get('v6Prefix')}'\n")

    def write_macaddr(self, macaddr: str) -> None:
        """write macaddr option"""
        if macaddr != "" and macaddr is not None:
            self.network_file.write(f"\toption macaddr '{macaddr}'\n")

    def write_interface_broadcast_addr(self, intf: dict[str, Any]) -> None:
        """
        writes broadcast address option
        """
        device: str = intf.get("device")
        if not device:
            return

        broadcast_addr: str = board_util.get_interface_broadcast_address(device)
        if not broadcast_addr:
            return

        self.network_file.write(f"\toption broadcast '{broadcast_addr}'\n")


registrar.register_manager(OpenWrtNetworkManager())
