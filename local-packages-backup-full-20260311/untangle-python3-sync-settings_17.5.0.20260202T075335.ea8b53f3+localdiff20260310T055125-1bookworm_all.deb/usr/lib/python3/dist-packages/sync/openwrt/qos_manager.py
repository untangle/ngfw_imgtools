"""qos_manager manages qos settings"""

import contextlib
import os
import stat

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


# This class is responsible for writing /etc/config/qos.d/* and
# /etc/config/nftables-rules.d/300-qos-rules-sys
# based on the settings object passed from sync-settings
class QosManager(Manager):
    """
    This class is responsible for writing all the qos-related settings files
    """

    qos_rules_sys_filename = "/etc/config/nftables-rules.d/300-qos-rules-sys"
    qos_file_path = "/etc/config/qos.d"

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.qos_rules_sys_filename, "restart-nftables-rules", self)
        registrar.register_file(self.qos_file_path + "/*", "restart-qos", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")

    def validate_settings(self, settings_file) -> None:
        """Perform validation of settings"""
        for intf in settings_file.get_settings_by_path("network/interfaces"):
            if not intf.get("qosEnabled"):
                continue

            try:
                up = float(intf.get("uploadKbps"))
                if up <= 0:
                    raise SettingsException(message="upload_kbps_out_of_range")
            except:
                raise SettingsException(message="upload_kbps_invalid_value")

            try:
                down = float(intf.get("downloadKbps"))
                if down <= 0:
                    raise SettingsException(message="download_kbps_out_of_range")
            except:
                raise SettingsException(message="download_kbps_invalid_value")

    def get_dscp_map(self, prio):
        """priority of the tc filter rule to tos value and dscp name mapping"""
        dscp_map = {
            2: (32, "cs1"),
            3: (0, "cs0"),
            4: (40, "af11"),
            5: (48, "af12"),
            6: (56, "af13"),
            7: (64, "cs2"),
            8: (72, "af21"),
            9: (80, "af22"),
            10: (88, "af23"),
            11: (96, "cs3"),
            12: (104, "af31"),
            13: (112, "af32"),
            14: (120, "af33"),
            15: (128, "cs4"),
            16: (136, "af41"),
            17: (144, "af42"),
            18: (152, "af43"),
            19: (160, "cs5"),
            20: (184, "ef"),
            21: (192, "cs6"),
            22: (224, "cs7"),
        }
        return dscp_map.get(prio, (0, "cs0"))

    def write_qos_files(self, settings, prefix, delete_list) -> None:
        """write /etc/config/qos.d files"""
        qos_interfaces = []
        interfaces = settings.get("network").get("interfaces")
        for intf in interfaces:
            if not intf.get("enabled"):
                continue
            if intf.get("wan"):
                qos_interfaces.append(intf.get("device"))
                filename_noprefix = self.qos_file_path + (
                    "/10-disable-qos-wan-{}".format(intf.get("device"))
                )
                filename = prefix + filename_noprefix
                file_dir = os.path.dirname(filename)
                if not os.path.exists(file_dir):
                    os.makedirs(file_dir)

                with contextlib.suppress(Exception):
                    delete_list.remove(filename_noprefix)

                file = open(filename, "w+")
                file.write("#!/bin/sh")
                file.write("\n\n")

                file.write("## Auto Generated\n")
                file.write("## DO NOT EDIT. Changes will be overwritten.\n")
                file.write("\n")

                if intf.get("qosEnabled"):
                    file.write(
                        "ip link set dev ifb4{} down 2> /dev/null\n".format(intf.get("device"))
                    )
                    file.write(
                        "ip link delete ifb4{} type ifb 2> /dev/null\n".format(intf.get("device"))
                    )
                    file.write("\n")
                    file.write(
                        "tc qdisc del dev {} root 2> /dev/null\n".format(intf.get("device"))
                    )
                    file.write("\n")
                    file.write(
                        "tc qdisc del dev {} handle ffff: ingress 2> /dev/null\n".format(
                            intf.get("device")
                        )
                    )
                    file.write(
                        "tc qdisc del dev ifb4{} root 2> /dev/null\n".format(intf.get("device"))
                    )
                    file.write("\n")
                    file.write("exit 0")
                    file.write("\n")
                else:
                    file.write(
                        "nft delete table inet qos-{} 2> /dev/null\n".format(intf.get("device"))
                    )
                    file.write("\n")
                    file.write("exit 0")
                    file.write("\n")

                file.flush()
                file.close()

                os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

                logger.info("Wrote %s", str(filename))

                filename_noprefix = self.qos_file_path + (
                    "/20-enable-qos-wan-{}".format(intf.get("device"))
                )
                filename = prefix + filename_noprefix

                with contextlib.suppress(Exception):
                    delete_list.remove(filename_noprefix)

                file = open(filename, "w+")
                file.write("#!/bin/sh")
                file.write("\n\n")

                file.write("## Auto Generated\n")
                file.write("## DO NOT EDIT. Changes will be overwritten.\n")
                file.write("\n")

                if intf.get("qosEnabled"):
                    file.write("DOWN={}\n".format(intf.get("downloadKbps")))
                    file.write("UP={}\n".format(intf.get("uploadKbps")))
                    file.write("\n")
                    file.write("ip link add name ifb4{} type ifb\n".format(intf.get("device")))
                    file.write("\n")
                    file.write(
                        "tc qdisc add dev {} root cake bandwidth ${{UP}}kbit diffserv4\n".format(
                            intf.get("device")
                        )
                    )
                    file.write("\n")
                    file.write(
                        "tc qdisc add dev {} handle ffff: ingress\n".format(intf.get("device"))
                    )
                    file.write(
                        "tc qdisc add dev ifb4{} root cake bandwidth ${{DOWN}}kbit diffserv4\n".format(
                            intf.get("device")
                        )
                    )
                    file.write("ip link set dev ifb4{} up\n".format(intf.get("device")))
                    file.write("\n")
                    file.write(
                        "tc filter add dev {} parent ffff: protocol ip prio 1 u32 match u32 0 0 flowid :1 action connmark action pedit munge ip tos set 0 pipe csum ip continue\n".format(
                            intf.get("device")
                        )
                    )

                    parent_filter = "ffff:"
                    tc_filter_add = "tc filter add dev {} parent {} protocol ip prio {} u32 match mark 0x{:08x} 0x00ff0000 flowid :1 "
                    tc_filter_action = "action pedit munge ip tos set {} "
                    pipe_csum = "pipe csum ip "
                    pipe_mirred = "pipe mirred egress redirect dev ifb4{}\n".format(
                        intf.get("device")
                    )
                    for i in range(21):
                        prio = i + 2
                        mark = 0x00150000 - (i * 0x10000)
                        tos, _ = self.get_dscp_map(prio)
                        if None not in (tc_filter_add, tc_filter_action, pipe_csum, pipe_mirred):
                            tc_filter_cmd = tc_filter_add.format(
                                intf.get("device"), parent_filter, prio, mark
                            )
                            tc_filter_action_str = (
                                tc_filter_action.format(tos)
                                if tc_filter_action is not None
                                else ""
                            )
                            pipe_csum_str = pipe_csum if pipe_csum is not None else ""
                            pipe_mirred_str = (
                                pipe_mirred.format(intf.get("device"))
                                if pipe_mirred is not None
                                else ""
                            )
                            command = f"{tc_filter_cmd}{tc_filter_action_str}{pipe_csum_str}{pipe_mirred_str}"
                            file.write(command)

                    file.write(
                        "tc filter add dev {} parent ffff: protocol all prio 23 u32 match u32 0 0 flowid 1:1 action mirred egress redirect dev ifb4{}\n".format(
                            intf.get("device"), intf.get("device")
                        )
                    )
                    file.write("\n")
                    file.write("exit 0")
                    file.write("\n")

                file.flush()
                file.close()

                os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

                logger.info("Wrote %s", str(filename))

        filename_noprefix = self.qos_file_path + "/15-disable-qos-all"
        filename = prefix + filename_noprefix
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        with contextlib.suppress(Exception):
            delete_list.remove(filename_noprefix)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")
        file.write(f"# qos_interfaces:{qos_interfaces}\n")
        file.write("\n")
        file.write("tc qdisc show | awk '{print $5}' | sort | uniq | while read dev ; do\n")
        file.write("\ttc qdisc del dev $dev root 2> /dev/null > /dev/null\n")
        file.write("\ttc qdisc del dev $dev ingress 2> /dev/null > /dev/null\n")
        file.write("done\n")
        file.write("\n")
        file.write(
            "find /sys/class/net -type l -name ifb* | cut -d '/' -f 5 | sort | uniq | while read dev ; do\n"
        )
        file.write("\tip link set dev $dev down 2> /dev/null > /dev/null\n")
        file.write("\tip link delete dev $dev type ifb 2> /dev/null > /dev/null\n")
        file.write("done\n")
        file.write("\n")
        file.writelines(
            f"nft delete table inet qos-{qos_intf} 2> /dev/null\n" for qos_intf in qos_interfaces
        )
        file.write("\n")
        file.write("exit 0")
        file.write("\n")

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_qos_rules_sys_file(self, settings, prefix) -> None:
        """write /etc/config/nftables-rules.d/300-qos-rules-sys"""
        filename = prefix + self.qos_rules_sys_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/usr/bin/nft_debug -f")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        try:
            add_qos_rules = False
            interfaces = settings.get("network").get("interfaces")
            for intf in interfaces:
                if not intf.get("enabled"):
                    continue
                if intf.get("wan") and intf.get("qosEnabled"):
                    add_qos_rules = True

            if add_qos_rules:
                file.write("add table inet qos\n")
                file.write("flush table inet qos\n")
                file.write("add chain inet qos restore-priority-mark\n")
                file.write("add chain inet qos log-priority\n")

                add_rule_res_pri_mark = "add rule inet qos restore-priority-mark "
                add_rule_log_qos_pri = "add rule inet qos log-priority "
                shaping_prio_mark = "meta mark and 0xff0000 == 0x{:06x} "
                ct_mark_set = "ct mark set ct mark and 0xff00ffff or 0x{:06x} "
                ip_dscp_set = "ip dscp set {} counter\n"
                available_priorities = 21
                for i in range(available_priorities):
                    prio = i + 2
                    mark = 0x150000 - (i * 0x10000)
                    _, dscp_name = self.get_dscp_map(prio)
                    # Check if any of the variables are None
                    if None not in (
                        add_rule_res_pri_mark,
                        add_rule_log_qos_pri,
                        shaping_prio_mark,
                        ct_mark_set,
                        ip_dscp_set,
                    ):
                        add_rule_str = (
                            add_rule_res_pri_mark if add_rule_res_pri_mark is not None else ""
                        )
                        res_pri_mark_str = (
                            shaping_prio_mark.format(mark) if shaping_prio_mark is not None else ""
                        )
                        ct_mark_set_str = (
                            ct_mark_set.format(mark) if ct_mark_set is not None else ""
                        )
                        ip_dscp_set_str = (
                            ip_dscp_set.format(dscp_name) if ip_dscp_set is not None else ""
                        )

                        # QoS rule string of restore-priority-mark chain
                        qos_add_rule = (
                            f"{add_rule_str}{res_pri_mark_str}{ct_mark_set_str}{ip_dscp_set_str}"
                        )

                        # Do not log at all for standard priority since standard priority is the action for the default
                        # (unconditional) shaping rule, most of the traffic matches it & floods the netlogger buffer with
                        # its logs. We have already kept the default value of priority column as 20 (standard priority),
                        # so this need not be logged again.
                        if prio != 3:
                            # Concat log prefix rule string of log-priority chain and write both rules to file
                            add_rule_str = (
                                add_rule_log_qos_pri if add_rule_log_qos_pri is not None else ""
                            )
                            log_prefix = f"log prefix \"{{'type': 'R:qos:log-priority', 'priority': '{available_priorities - i}'}}\" group 0 counter\n"
                            qos_add_rule += f"\n{add_rule_str}{res_pri_mark_str}{log_prefix}"
                        file.write(qos_add_rule)

                file.write(
                    "add chain inet qos postrouting-qos { type filter hook postrouting priority 50 ; }\n"
                )
                file.write("add rule inet qos postrouting-qos jump restore-priority-mark\n")
                # We want to jump to log-priority chain for logging only in case of request packets, not response packets,
                # hence skip that chain in case there are response packets coming into the network i.e. source interface type == WAN
                file.write(
                    "add rule inet qos postrouting-qos meta mark & 0x03000000 == 0x01000000 return\n"
                )
                file.write("add rule inet qos postrouting-qos jump log-priority\n")
        except:
            logger.exception("")
        finally:
            file.write("\n")
            file.flush()
            file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        self.write_qos_rules_sys_file(settings_file.settings, prefix)
        for dirpath, _, filenames in os.walk(self.qos_file_path + "/"):
            for filename in filenames:
                full_name = dirpath + filename
                delete_list.append(full_name)
        # Write all the /etc/config/qos.d/* files
        self.write_qos_files(settings_file.settings, prefix, delete_list)


registrar.register_manager(QosManager())
