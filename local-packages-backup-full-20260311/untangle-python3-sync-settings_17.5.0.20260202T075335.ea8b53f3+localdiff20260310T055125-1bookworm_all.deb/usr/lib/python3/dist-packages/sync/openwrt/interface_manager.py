"""This class is responsible for writing interface-marks chains."""

from sync import registrar
from sync.common import Logger
from sync.common.interface_manager import CommonInterfaceManager
from sync.openwrt.mgmt_rule_manager import MgmtRuleManager
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class InterfaceManager(CommonInterfaceManager):
    """InterfaceManager writes /etc/config/nftables-rules.d/101-interface-
    marks."""

    # Our rule manager for adding management interface block rule
    mgmt_rule_manager = None

    # For sanitization, use this MTU if none exists.
    DEFAULT_MTU = 1500

    def initialize(self) -> None:
        """initialize this module"""
        self.mgmt_rule_manager = MgmtRuleManager()
        registrar.register_settings_file("settings", self)

    def speed_check(self, filepath):
        with open(filepath) as f:
            speed = f.readline()
            try:
                speed = speed.strip()
            except Exception:
                # EOS fails because of this, not sure if it's needed by other OSs
                pass

            speed = int(speed)
            if speed < 0:
                return 1000
            return speed

    def collect_intf_speed(self, intf_name: str):
        # Get the interface speed from the kernel
        filepath = "/sys/class/net/" + intf_name + "/speed"
        try:
            return self.speed_check(filepath)
        except OSError:
            logger.exception("Could not open/read file: %s", str(filepath))
            # sensible default
            return 1000

    def sanitize_mtu(self, interface, all_interfaces) -> None:
        """sanitize the mtu -- add an MTU if it doesn't exist, special
        handling for interfaces that are bound to some parent."""
        if "boundInterfaceId" in interface:
            foundParent = [
                intf
                for intf in all_interfaces
                if intf.get("interfaceId") == interface.get("boundInterfaceId")
            ]
            if not foundParent:
                raise SettingsException(
                    message_str=f"Interface {interface.get('name')} has no matching parent "
                    f"for id: {interface.get('boundInterfaceId')}"
                )

            parentMTU = foundParent[0].get("mtu", self.DEFAULT_MTU)
            interface["mtu"] = parentMTU
        elif "mtu" not in interface:
            interface["mtu"] = self.DEFAULT_MTU

    def sanitize_settings(self, settings_file) -> None:
        # Upgrade 2 -> 3, Add speed/duplex/negotiation
        # options. Default to auto negotiation.
        if settings_file.settings["version"] < 3:
            interfaces = settings_file.settings.get("network").get("interfaces")
            for intf in interfaces:
                if intf["type"] == "NIC":
                    intf["ethSpeed"] = self.collect_intf_speed(intf["device"])
                    intf["ethDuplex"] = "full"
                    intf["ethAutoneg"] = True

        # For wireguard and PPPOE types - add routeMtu setting if it does not exist
        interfaces = settings_file.settings.get("network").get("interfaces")
        for intf in interfaces:
            # Skip call to sanitize_mtu for IPSEC, OPENVPN and WIREGUARD type
            skip_types = ["IPSEC", "OPENVPN", "WIREGUARD"]
            if intf.get("type") not in skip_types:
                self.sanitize_mtu(intf, interfaces)

            if not intf.get("enabled"):
                continue

            if intf.get("configType") == "BRIDGED":
                continue

            if intf.get("v4ConfigType") == "PPPOE" or intf.get("type") == "WIREGUARD":
                if "routeMtu" not in intf:
                    intf["routeMtu"] = True

            if intf.get("management"):
                # We create a block rule to prevent LAN traffic from reaching the management interface
                # check_create_mgt_rule() will create the rule if it does not exist. We allow use to disable rule.
                self.mgmt_rule_manager.check_create_mgmt_rule(
                    settings_file, intf.get("v4StaticAddress")
                )

            # If the interface has any V4 aliases, then add ifdown/ifup operation on the alias config interface as well
            # When we change the static IPv4, then the earlier alias do not show ip unless we manually do this step.
            # This step is not required for IPv6 aliases.
            self.update_alias_restart_commands(intf, intf.get("v4Aliases"))

    def update_alias_restart_commands(self, intf: dict, aliases: list) -> None:
        """
        This method generates `ifdown` and `ifup` commands for each alias associated
        with the given interface and appends them to the post-commands list of the
        "restart-networking" operation in the registrar.
        Args:
            intf (dict): A dictionary containing interface details. It is expected to
                have a 'name' key representing the base name of the interface. If the
                'name' key is missing, an empty string will be used as the base name.
            aliases (list): A list of aliases associated with the interface. For each
                alias, corresponding `ifdown` and `ifup` commands will be generated
                and added to the post-commands list.
        Returns:
            None
        """
        # Return in case of blank list or None.
        if not aliases:
            return
        (pre_commands, post_commands, priority, parent) = registrar.get_operation(
            "restart-networking"
        )
        for i in range(1, len(aliases) + 1):
            intf_config_name = f"{intf.get('name', '')}4_{i}"
            post_commands.append(f"ifdown {intf_config_name} ; ifup {intf_config_name}")
        registrar.register_operation(
            "restart-networking", pre_commands, post_commands, priority, parent
        )


registrar.register_manager(InterfaceManager())
