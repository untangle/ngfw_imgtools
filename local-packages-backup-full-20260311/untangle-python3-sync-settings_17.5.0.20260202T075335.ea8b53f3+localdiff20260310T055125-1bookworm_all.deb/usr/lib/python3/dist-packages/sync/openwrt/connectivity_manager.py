"""This class is responsible for managing checking connectivity with cloud services"""

from sync import registrar
from sync.common import Logger
from sync.common.connectivity_manager import ConnectivityManager

default_connectivity_settings = {"settings_rollback": True}

logger = Logger.getInstance()


class OpenWRTConnectivityManager(ConnectivityManager):
    """OpenWRTConnectivityManager manages the connectivity with cloud services"""

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["connectivity"] = default_connectivity_settings

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        if settings_file.settings.get("connectivity") is None:
            settings_file.settings["connectivity"] = default_connectivity_settings


registrar.register_manager(OpenWRTConnectivityManager())
