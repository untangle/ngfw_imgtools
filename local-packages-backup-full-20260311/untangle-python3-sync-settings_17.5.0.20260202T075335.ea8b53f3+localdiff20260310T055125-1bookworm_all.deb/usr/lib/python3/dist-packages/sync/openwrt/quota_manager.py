"""This class is responsible for managing Quota settings"""

import copy
import os
import os.path
import re
import stat

from sync import Manager, registrar
from sync.common import Logger
from sync.settings_exception import SettingsException

cond_type_dict = {
    "SOURCE_ADDRESS": "ip saddr",
    "SOURCE_ADDRESS_V6": "ip6 saddr",
    "DESTINATION_ADDRESS": "ip daddr",
    "DESTINATION_ADDRESS_V6": "ip6 daddr",
    "SOURCE_PORT": "sport",
    "DESTINATION_PORT": "dport",
    "SOURCE_INTERFACE_ZONE": "iif",
    "DESTINATION_INTERFACE_ZONE": "oif",
}

nft_base_string = "nft add rule inet shaping quota-rules "
nft_quota_string = "quota over "
nft_counter_string = " counter "
nft_quota_script_name = " /usr/bin/quota_cron.sh "
nft_shell_command = " /bin/sh"
nft_cron_file = "/etc/crontabs/root"

logger = Logger.getInstance()


class QuotaManager(Manager):
    quota_rules_sys_filename = "/etc/config/nftables-rules.d/310-quota-rules-sys"

    quota_settings = {}
    default_exceed_action_found = False

    config_id_list = []
    exceed_action_list = []

    def initialize(self) -> None:
        """initialize this module"""

        registrar.register_settings_file("settings", self)
        registrar.register_file(self.quota_rules_sys_filename, "restart-nftables-rules", self)
        registrar.register_file(nft_cron_file, "restart-cron", self)

    # This is a default config which will be inserted if there are no schema found for quota_manager
    def default_settings_quota(self):
        return {"enabled": False, "configurations": [], "exceed_actions": [], "rules": []}

    # This function creates a default quota manager scheme if its not present
    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")
        settings_file.settings["quota_manager"] = self.default_settings_quota()

    # This function validate the settings and raises exceptions for invalid data.
    # Three major block checked are configurations, exceed_actions and rules.
    def validate_settings(self, settings_file) -> None:
        """validates settings"""

        self.quota_manager = settings_file.settings.get("quota_manager")

        # Null checks and type checks for settings
        self.validate_parameter(settings_file, "enabled", bool)

        if self.quota_settings.get("configurations"):
            self.validate_configs()

        if self.quota_settings.get("exceed_actions"):
            self.validate_exceed_actions()

        # Validate rules property if exist
        if self.quota_settings.get("rules"):
            self.validate_rules()

    def validate_parameter(self, settings_file, parameter_name, parameter_type) -> None:
        """validates parameters"""
        self.quota_settings = settings_file.settings.get("quota_manager")
        parameters = self.quota_settings

        parameter_value = parameters[parameter_name]
        if parameter_value is None or not isinstance(parameter_value, parameter_type):
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["quota", parameter_name]
            )

    # method for validating the `configurations` part of the config
    # raise exception for the items that do not have the minimum required fields
    def validate_configs(self) -> None:
        required_config_fields = {"data_size", "id", "name", "period"}

        if not isinstance(self.quota_settings["configurations"], list):
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["quota", "configurations"]
            )
        valid_configs = []
        for item in self.quota_settings["configurations"]:
            cp_config_copy = copy.deepcopy(item)

            missing_fields = required_config_fields - set(cp_config_copy)
            if bool(missing_fields):
                raise SettingsException(
                    message="missing_or_invalid_config_property",
                    vars=["quota", next(iter(missing_fields))],
                )

            # Remember the ids for rules validation
            self.config_id_list.append(item["id"])

            # skip the items that do not have the minimum required fields
            valid_configs.append(cp_config_copy)

        self.quota_settings["configurations"] = valid_configs

    # method for validating the `exceed_actions` part of the config
    # raise exceptions for items that do not have the minimum required fields
    def validate_exceed_actions(self) -> None:
        required_exceed_actions_fields = {"action", "id", "name"}
        valid_exceed_actions = []
        self.default_exceed_action_found = False

        # If exceed_action is not a list, raise exception
        if not isinstance(self.quota_settings["exceed_actions"], list):
            raise SettingsException(
                message="missing_or_invalid_parameter_value", vars=["quota", "exceed_actions"]
            )

        # Lets check list element one by one to see if all of them basic required fields
        for item in self.quota_settings["exceed_actions"]:
            cp_exceed_action_copy = copy.deepcopy(item)

            missing_fields = required_exceed_actions_fields - set(cp_exceed_action_copy)
            if bool(missing_fields):
                raise SettingsException(
                    message="missing_or_invalid_exceed_action_property",
                    vars=[next(iter(missing_fields))],
                )

            # Remember the exceed_action_id for validating rules
            self.exceed_action_list.append(item["id"])

            # Make a note if default is configured.
            if "default" in cp_exceed_action_copy:
                # If default is set for multiple records then raise exception
                if self.default_exceed_action_found is True:
                    raise SettingsException(message_str="Multiple default actions found")
                self.default_exceed_action_found = True

            # skip the items that do not have the minimum required fields
            valid_exceed_actions.append(cp_exceed_action_copy)
        self.quota_settings["exceed_actions"] = valid_exceed_actions

    # method for validating the `rules` part of the config
    # raise exception for the items that do not have the minimum required fields
    def validate_rules(self) -> None:
        required_rule_fields = {"action", "conditions", "id", "name", "enabled"}
        required_rule_cond_fields = {"op", "type", "value"}
        required_rule_action_fields = {"exceed_action_id", "quota_id", "type"}

        valid_rules = []
        for item in self.quota_settings["rules"]:
            if not isinstance(item, dict):
                raise SettingsException(
                    message="missing_or_invalid_parameter_value(rule)", vars=["quota", "rules"]
                )
            cp_rule_copy = copy.deepcopy(item)

            # Validate required fields of Rule
            missing_fields = required_rule_fields - set(cp_rule_copy)
            if bool(missing_fields):
                raise SettingsException(
                    message="missing_or_invalid_rule_property",
                    vars=["quota", next(iter(missing_fields))],
                )

            # Validate required fields in Rule's action
            action_copy = item["action"]
            missing_fields = required_rule_action_fields - set(action_copy)
            if bool(missing_fields):
                raise SettingsException(
                    message="missing_or_invalid_rule_action_property",
                    vars=[next(iter(missing_fields))],
                )

            # If exceed_action_id is empty then check if default action was configured
            # If not, raise exception, If default was configured then allow this..
            if self.default_exceed_action_found is False:
                if action_copy["exceed_action_id"] == "":
                    raise SettingsException(
                        message="missing exceed_action_id in rule, no default configured"
                    )

            # If the exceed id is  not found then raise exception
            if (
                action_copy["exceed_action_id"] != ""
                and action_copy["exceed_action_id"] not in self.exceed_action_list
            ):
                raise SettingsException(
                    message="missing_exceed_action", vars=action_copy["exceed_action_id"]
                )

            # If the quota id not found raise exception
            if action_copy["quota_id"] not in self.config_id_list:
                raise SettingsException(message="missing_quota_id", vars=action_copy["quota_id"])

            cp_rule_copy["action"] = action_copy

            # Validate conditions within the Rule
            sanitized_rule_conditions = []
            if type(item["conditions"]) != list:
                raise SettingsException(
                    message="missing_or_invalid_rule_value", vars=["conditions"]
                )

            for condition in cp_rule_copy["conditions"]:
                cond_copy = copy.deepcopy(condition)
                missing_fields = required_rule_cond_fields - set(cond_copy)
                if bool(missing_fields):
                    raise SettingsException(
                        message="missing_or_invalid_conditions_property",
                        vars=[next(iter(missing_fields))],
                    )

                # If the type is L4 port then we need to specify the l4 protocol as well
                if condition["type"] == "DESTINATION_PORT" or condition["type"] == "SOURCE_PORT":
                    if (
                        "proto" not in condition
                        or condition["proto"] == ""
                        or condition["proto"] is None
                    ):
                        raise SettingsException(
                            message="missing_or_invalid_conditions_property", vars="proto"
                        )

                sanitized_rule_conditions.append(condition)
            cp_rule_copy["conditions"] = sanitized_rule_conditions
            valid_rules.append(cp_rule_copy)
            self.quota_settings["rules"] = valid_rules

    # This function is called whenever we run sync-settings an this function
    # calls write_quota_file which generates NFT rules and Cronjob rules
    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        self.write_quota_file(settings_file, prefix)

    """
        This function checks if the quota settings is empty, if so it creates
        default schema
    """

    def sanitize_settings(self, settings_file) -> None:
        """sanitizes settings"""
        self.quota_manager = settings_file.settings.get("quota_manager")
        # Missing Quota settings
        if self.quota_manager is None:
            logger.info("Empty settings, filling defaults")
            self.create_settings(settings_file, "", "", "")

    # This function is mainly used to write cronjob for now
    def write_file(self, destination, prefix, data, mode) -> None:
        """
        Reusable function to write to a file
        """
        filename = prefix + destination
        file_dir = os.path.dirname(filename)
        os.makedirs(file_dir, exist_ok=True)

        try:
            with open(filename, mode) as file:
                file.write(data)
            file.flush()
            file.close()
            os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
            logger.info("Wrote %s", str(filename))
        except Exception:
            logger.exception("Quota Manager: An error occurred:")

    """
    This function is called whenever a NFT rule is derived from the schema and
    it needs to renew the quota every ''n period. This function gets 2 strings
    as parameter. One is match string to findout the correct entry in cronjob and
    the second string is the rule which needs to be programmed in the NFT. This
    function also receives the period and based on that crontab entry is programmed.
    """

    def create_cron_job_for_rule(self, prefix, data, match_data, period_string) -> None:
        # The format would be xy (x is numeric and y is alphabet)
        # Separate them for further string generation
        number_l = re.findall(r"[0-9]+", period_string)
        span_l = re.findall(r"[a-zA-Z]+", period_string)

        cron_string = ""
        span = " ".join(span_l)
        number = " ".join(number_l)
        if span == "m":
            cron_string = "*/" + number + " * * * *"
        elif span == "h":
            cron_string = "* */" + number + " * * *"
        elif span == "d":
            cron_string = "* * */" + number + " * *"
        elif span == "M":
            cron_string = "* * * */" + number + " *"
        else:
            return
        final_string = (
            cron_string
            + nft_shell_command
            + nft_quota_script_name
            + '"'
            + match_data
            + '"'
            + ' "'
            + data
            + '"'
            + "\n"
        )
        self.write_file(nft_cron_file, prefix, final_string, "a")

    # This function generated condition string based on the config.
    # It also generates dscp string if there is priority change configured
    def quota_form_condition_string(self, conditions, action_is_dscp):
        type_string = ""
        proto = ""
        dscp_string = ""
        condition_string = ""
        for conds in range(len(conditions)):
            for cond, cval in conditions[conds].items():
                if cond == "type" and cval in cond_type_dict:
                    type_string = cond_type_dict[cval]
                if (
                    action_is_dscp
                    and cond == "type"
                    and (cval in ("DESTINATION_ADDRESS_V6", "SOURCE_ADDRESS_V6"))
                ):
                    dscp_string = "ip6 dscp set"
                elif (
                    action_is_dscp
                    and cond == "type"
                    and (cval in ("DESTINATION_ADDRESS", "SOURCE_ADDRESS"))
                ):
                    dscp_string = "ip dscp set"

                if cond == "proto":
                    proto = cval + " "

                if cond == "op":
                    op_string = " " if cval == "==" else " != "
                if cond == "value":
                    pass

            condition_string += proto + type_string + op_string + "{ " + cval + " } "
        return condition_string, dscp_string

    # This function builds mapping between guid and (quota) configuration
    def build_config_db(self, settings):
        config_dict = {}
        configs = settings["configurations"]
        for config in range(len(configs)):
            for key, value in configs[config].items():
                if key == "id":
                    config_dict[value] = configs[config]
        return config_dict

    # This function builds mapping between guid and action.
    def build_action_db(self, settings):
        exceed_act_dict = {}
        default_action = {}
        actions = settings["exceed_actions"]
        for action in range(len(actions)):
            for key, value in actions[action].items():
                if key == "default" and value is True:
                    default_action = actions[action]
                if key == "id":
                    exceed_act_dict[value] = actions[action]
        return exceed_act_dict, default_action

    # This function generates quota string, action string and flag to indicate if dscp was mentioned in action
    # It also generates period string which will be used for  cronjob task generation.
    def quota_form_action_string(self, value, config_dict, exceed_act_dict, default_action):
        action_is_dscp = False
        if value["quota_id"] in config_dict:
            quota = config_dict[value["quota_id"]]
            quota_string = quota["data_size"]
            period_string = quota["period"]

        if value["exceed_action_id"] in exceed_act_dict or value["exceed_action_id"] == "":
            if value["exceed_action_id"] != "":
                action = exceed_act_dict[value["exceed_action_id"]]
            else:
                action = default_action
            if action["action"] == "drop":
                action_string = "drop"
            elif action["action"] == "SET_PRIORITY":
                action_string = action["priority"]
                action_is_dscp = True
        return quota_string, action_string, action_is_dscp, period_string

    # This function generates NFT rules and Cronjob rules from the config
    def write_quota_file(self, settings_file, prefix) -> None:
        filename_noprefix = self.quota_rules_sys_filename
        filename = prefix + filename_noprefix
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")
        file.write("nft add chain inet shaping quota-rules\n")
        file.write("nft flush chain inet shaping quota-rules\n")
        settings = {}
        settings = settings_file.settings.get("quota_manager")

        if "enabled" in settings:
            if settings["enabled"] is True:
                logger.info("Quota Manager enabled")
            else:
                logger.info("Quota Manager disabled")
                return
        else:
            return

        # Build a dict of quota-config , keyed with ID
        config_dict = self.build_config_db(settings)

        # Build a dict of exceed-action, keyed with ID
        # Also set the default config if found
        exceed_act_dict, default_action = self.build_action_db(settings)

        rules = settings["rules"]
        for rule in range(len(rules)):
            # nothing to do if the rule is disabled then skip
            if rules[rule]["enabled"] is not True:
                logger.info("rule disabled")
                continue

            action_string = ""
            conditions_string = ""
            dscp_string = ""
            period_string = ""
            action_is_dscp = False

            for key, value in rules[rule].items():
                if key == "action":
                    quota_string, action_string, action_is_dscp, period_string = (
                        self.quota_form_action_string(
                            value, config_dict, exceed_act_dict, default_action
                        )
                    )
                elif key == "conditions":
                    condition_string, dscp_string = self.quota_form_condition_string(
                        value, action_is_dscp
                    )
                    conditions_string += condition_string

            match_data = conditions_string + nft_quota_string
            data = (
                nft_base_string
                + conditions_string
                + nft_quota_string
                + quota_string
                + nft_counter_string
                + dscp_string
                + " "
                + action_string
            )

            # Program the cronjob for the NFT rule
            self.create_cron_job_for_rule(prefix, data, match_data, period_string)

            # Write the NFT rule to file
            file.write(data + "\n")
        file.flush()
        file.close()
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(QuotaManager())
