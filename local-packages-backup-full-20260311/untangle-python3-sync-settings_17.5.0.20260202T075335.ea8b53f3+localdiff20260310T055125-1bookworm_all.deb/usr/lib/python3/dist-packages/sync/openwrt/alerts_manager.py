"""This class is responsible for managing alert settings"""

import json
import os

from sync import registrar
from sync.common import Logger
from sync.common.alerts_manager import AlertsManager
from sync.file_util import FileUtil

ALERT_SETTINGS_FILE_PATH = "/etc/config/alert/alert_settings"

logger = Logger.getInstance()


class OpenwrtAlertManager(AlertsManager):
    def __init__(self) -> None:
        """Alerts configuration definition file"""
        self.alert_settings_file_path = FileUtil.locate_file(ALERT_SETTINGS_FILE_PATH)

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)

        # Registers the alerts configuration file with alertd SIGHUP operation
        registrar.register_file(self.alert_settings_file_path, "restart-reportd-alerts", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        self.write_settings_file(settings_file, prefix)

    def write_settings_file(self, settings_file, prefix) -> None:
        """writes the settings to specified filepath"""
        settings_data = {}
        filename = prefix + self.alert_settings_file_path
        settings_data["alerts"] = settings_file.settings.get("alerts")
        self.write_file(filename, json.dumps(settings_data).encode("utf-8"))

    def write_file(self, filename, data) -> None:
        """writes data to specified file"""
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        with open(filename, "wb+") as file:
            file.write(data)
        logger.info("Wrote %s", str(filename))


registrar.register_manager(OpenwrtAlertManager())
