import os

from sync import Manager, registrar
from sync.common import Logger

logger = Logger.getInstance()


class LldpManager(Manager):
    """
    Manage LLDP under OpenWrt
    """

    initalized = False
    #
    # OpenWrt Configuration
    #

    # Paths for files
    config_path = "/etc/config/"

    @classmethod
    def static_init(cls) -> None:
        """
        Create static variables when class file is loaded.
        """
        LldpManager.initialized = True
        LldpManager.lldpd_config_filename = f"{LldpManager.config_path}lldpd"

    def initialize(self) -> None:
        """
        Initialize
        """
        registrar.register_settings_file("settings", self)
        registrar.register_file(LldpManager.lldpd_config_filename, "restart-lldpd", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Sync settings
        """
        self.write_lldpd_config(settings_file, prefix)

    def write_lldpd_config(self, settings_file, prefix) -> None:
        """
        Create lldpd configuration
        The file /etc/config/lldpd format is:

        config lldpd config
            option enable_cdp 1
            option enable_fdp 1
            option enable_sonmp 1
            option enable_edp 1

            option lldp_class 4

            # if empty, the distribution description is sent
            #option lldp_description "OpenWrt System"
            #option lldp_hostname "Modified Hostname"

            # interfaces to listen on
            list interface "lo"
            list interface "lan"

        """
        filename = prefix + LldpManager.lldpd_config_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        self.write_lldpd_config_lldpd_section(settings_file, prefix, file)

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_lldpd_config_lldpd_section(self, settings_file, prefix, file) -> None:
        """
        Write lldp section block
        """
        file.write("config lldpd" + "\n")
        file.write(" option enable_cdp 1" + "\n")
        file.write(" option enable_fdp 1" + "\n")
        file.write(" option enable_sonmp 1" + "\n")
        file.write(" option enable_edp 1" + "\n")
        file.write(" option readonly_mode 1" + "\n")
        file.write("\n")

        file.write(" option lldp_class 4" + "\n")
        file.write("\n")

        pretty_name = ""
        with open("/etc/os-release") as os_release_file:
            for line in os_release_file:
                key, value = line.strip().split("=", 1)
                if key == "PRETTY_NAME":
                    pretty_name = value.strip('"')
        file.write(f" option lldp_description '{pretty_name}'" + "\n")

        hostname = settings_file.get_settings_by_path("system/hostName")
        file.write(f" option lldp_hostname '{hostname}'" + "\n")
        file.write("\n")

        listen_interfaces_devices = ["lo"]
        for interface_type in ["NIC", "WIFI"]:
            interfaces_settings = settings_file.find_settings_list(
                "network/interfaces", {"wan": False, "enabled": True, "type": f"{interface_type}"}
            )
            for interface_setting in interfaces_settings:
                device_name = interface_setting.get("device")
                if device_name not in listen_interfaces_devices:
                    listen_interfaces_devices.append(device_name)

        for device in listen_interfaces_devices:
            file.write(f' list interface "{device}"' + "\n")

        file.write("\n")


if LldpManager.initalized is False:
    LldpManager.static_init()

registrar.register_manager(LldpManager())
