"""Dynamic lists manager for OpenWrt with crontab style cron support"""

from sync import registrar
from sync.common.dynamic_lists_manager import CrontabDynamicListsManager

registrar.register_manager(CrontabDynamicListsManager())
