# Rule Managers
import collections
import copy
import ipaddress
import json

from sync import network_util, nftables_util, registrar
from sync.rule_manager import RuleManager
from sync.variables import Variables


class IpsecWanRuleManager(RuleManager):
    """
    Wan Rule manager for tunnels
    """

    settings_path = "wan/policy_chains/name=user-wan-rules/rules"

    # UDP port for encapsulated ESP when in nat-traversal mode.
    IPSEC_ESP_UDP_PORT = 4500

    # UDP port for IKE.
    IPSEC_IKE_UDP_PORT = 500

    # ESP protocol number, set as string because IP_PROTOCOL condition
    # can have multiple values for other rules e.g. ('6,17') = 'TCP,UDP'
    IPSEC_ESP_IP_PROTOCOL = "50"

    # UDP port protocol
    IPSEC_UDP_PORT_PROTOCOL = 17

    # Wan rule template
    settings_rule_template = {
        "description": "",
        "enabled": True,
        "readOnly": True,
        "ruleId": "__rule_id__",
        "action": {"policy": "__policy_id__", "type": "WAN_POLICY"},
        "conditions": [
            {"op": "==", "type": "SOURCE_ADDRESS", "value": ""},
            {"op": "==", "type": "DESTINATION_ADDRESS", "value": ""},
        ],
        "logs": [
            {
                "type": "NFLOG",
                "prefix": "{'type':'R:wan-routing:user-wan-rules','ruleId':'__nft_rule_id__','action':'WAN_POLICY','policy':'__nft_policy_id__'} ",
            },
            {
                "type": "DICT",
                "field": "wan_rule_id",
                "field_type": "long_string",
                "value": "__nft_rule_id__",
            },
        ],
    }

    FAMILY_V4 = "ip"
    FAMILY_V6 = "ip6"

    bound_intf_template = {
        "description": "",
        "enabled": True,
        "readOnly": True,
        "ruleId": "__rule_id__",
        "action": {"chain": "", "type": "JUMP"},
        "conditions": [],
    }

    def is_managed(self, rule_settings, settings_file):
        """ """
        # Get class match
        match = super().is_managed(rule_settings, settings_file)

        need_confirm = False
        route_manager = registrar.get_manager("RouteManager")
        try:
            route_manager.validate_settings(settings_file)
        except:
            need_confirm = True

        if need_confirm is True and (
            Variables.get("force") is None or Variables.get("force").lower() != "true"
        ):
            match = False

        return match

    def get_addr_family(self, string_addr):
        addr = ipaddress.ip_address(string_addr)
        if isinstance(addr, ipaddress.IPv4Address):
            return self.FAMILY_V4
        return self.FAMILY_V6

    def get_remote_family(self, intf):
        remote = intf["ipsec"]["remote"]["gateway"]
        return self.get_addr_family(remote)

    def get_system_interface_by_name(self, intfname):
        intfs = network_util.get_system_interfaces()
        for intf in intfs:
            if intf.get("name") == intfname:
                return intf
        return None

    def get_ip_addresses_of_iface(self, iface, family):
        naming_map = {
            self.FAMILY_V4: "ipv4",
            self.FAMILY_V6: "ipv6",
        }
        ip_addrs = iface.get("networks", {}).get(naming_map[family], [])
        return [i.get("address") for i in ip_addrs if i]

    def set_bound_intf_chain(self, intf, rule) -> None:
        intfID = str(intf["boundInterfaceId"])
        rule["action"]["chain"] = "mark-for-wan-" + intfID

    def create_saddr_daddr_conds(self, saddr, daddr):
        fam = self.get_addr_family(saddr)
        add_string = ""
        if fam == self.FAMILY_V6:
            add_string = "_V6"
        return [
            {
                "op": "==",
                "type": "SOURCE_ADDRESS" + add_string,
                "value": saddr,
            },
            {
                "op": "==",
                "type": "DESTINATION_ADDRESS" + add_string,
                "value": daddr,
            },
        ]

    def create_any_remote_conds(self, local_wan_addr):
        fam = self.get_addr_family(local_wan_addr)
        add_string = ""
        if fam == self.FAMILY_V6:
            add_string = "_V6"
        return [
            {"op": "==", "type": "CT_STATE", "value": "new"},
            {
                "op": "==",
                "type": "DESTINATION_ADDRESS" + add_string,
                "value": local_wan_addr,
            },
        ]

    def create_bound_intf_ipsec_esp_conditions(self):
        return [{"op": "==", "type": "IP_PROTOCOL", "value": self.IPSEC_ESP_IP_PROTOCOL}]

    def create_bound_intf_ipsec_udp_esp_conditions(self):
        return [
            {
                "port_protocol": self.IPSEC_UDP_PORT_PROTOCOL,
                "op": "==",
                "type": "SOURCE_PORT",
                "value": self.IPSEC_ESP_UDP_PORT,
            },
            {
                "port_protocol": self.IPSEC_UDP_PORT_PROTOCOL,
                "op": "==",
                "type": "DESTINATION_PORT",
                "value": self.IPSEC_ESP_UDP_PORT,
            },
        ]

    def create_bound_intf_ipsec_udp_ike_conditions(self):
        return [
            {
                "port_protocol": self.IPSEC_UDP_PORT_PROTOCOL,
                "op": "==",
                "type": "SOURCE_PORT",
                "value": self.IPSEC_IKE_UDP_PORT,
            },
            {
                "port_protocol": self.IPSEC_UDP_PORT_PROTOCOL,
                "op": "==",
                "type": "DESTINATION_PORT",
                "value": self.IPSEC_IKE_UDP_PORT,
            },
        ]

    def handle_any_remote_gateway(self, intf, local_addresses, wan_policy):
        """
        For an %any remote gateway, we don't know the remote tunnel
        endpoint in advance and will bind traffic that comes into this
        WAN on IPSEC ports/protos immediately just basedon its dest
        addr (the WANs) and its proto (ESP) or udp ports (ESP, IKE).
        """
        rules = []
        for addr in local_addresses:
            for condition in [
                self.create_bound_intf_ipsec_esp_conditions,
                self.create_bound_intf_ipsec_udp_esp_conditions,
                self.create_bound_intf_ipsec_udp_ike_conditions,
            ]:
                rule = copy.deepcopy(IpsecWanRuleManager.bound_intf_template)
                conditions = [*condition(), *self.create_any_remote_conds(addr)]
                self.set_bound_intf_chain(intf, rule)
                rule["conditions"] = conditions
                rule["enabled"] = intf.get("enabled")
                rule["description"] = (
                    f"Bind ipsec traffic from %any gateway to interface {intf['boundInterfaceId']}"
                )
                rule["isHidden"] = True
                self.set_manager(rule)
                rules.append(rule)
        return rules

    def handle_static_remote_gateway(self, intf, endpoints, wan_policy):
        """
        For a static remote gateway, we bind traffic going between the
        endpoints based on both saddr/daddr.
        returns -- rules to bind traffic on these endpoints.
        """
        conditions = []
        rules = []
        for endpoint_a, endpoint_b in endpoints:
            for condition in [
                self.create_bound_intf_ipsec_esp_conditions,
                self.create_bound_intf_ipsec_udp_esp_conditions,
                self.create_bound_intf_ipsec_udp_ike_conditions,
            ]:
                rule = copy.deepcopy(IpsecWanRuleManager.bound_intf_template)
                conditions = [*self.create_saddr_daddr_conds(endpoint_a, endpoint_b), *condition()]
                self.set_bound_intf_chain(intf, rule)
                rule["conditions"] = conditions
                rule["enabled"] = intf.get("enabled")
                rule["description"] = f"Bind ipsec traffic to interface {intf['boundInterfaceId']}"
                rule["isHidden"] = True
                self.set_manager(rule)
                rules.append(rule)
        return rules

    def generate_wan_binding_rules(self, settings_file, interfaces):
        """
        generate rules to bind ipsec traffic to this WAN for this
        ipsec connection. We generate rules based on tunnel endpoints.
        settings_file -- settings file object
        interfaces -- list of IPSEC interfaces that may or may not
        have a bound interface.
        returns -- list of rules in the json/dict format used by nftables_utils
        """
        global_settings = settings_file.settings
        rules = []
        for intf in interfaces:
            bound_interface = intf.get("boundInterfaceId", None)
            if not bound_interface:
                continue
            interface_id = intf["interfaceId"]

            wan_policy = None
            for policy in settings_file.settings["wan"]["policies"]:
                if json.dumps(policy.get("interfaces")) == json.dumps(
                    [{"interfaceId": interface_id}]
                ):
                    wan_policy = policy
                    break

            if wan_policy is None:
                # No policy to attach.  This isn't neccessarily an error to stop processing on.
                continue

            remote_gateway = intf["ipsec"]["remote"]["gateway"]
            intf_parent = network_util.get_interface_by_id(
                global_settings, intf["boundInterfaceId"]
            )
            intf_system_details = self.get_system_interface_by_name(intf_parent["device"])
            if remote_gateway == "%any":
                # Currently we can't set both local and remote to
                # %any.
                local_endpoint = intf["ipsec"]["local"]["gateway"]
                rules.extend(self.handle_any_remote_gateway(intf, [local_endpoint], wan_policy))
            else:
                family = self.get_remote_family(intf)
                local_endpoints = self.get_ip_addresses_of_iface(intf_system_details, family)
                endpoints = [
                    ((local, remote_gateway), (remote_gateway, local)) for local in local_endpoints
                ]
                endpoints_flattened = [i for endpoint in endpoints for i in endpoint]
                rules.extend(
                    self.handle_static_remote_gateway(intf, endpoints_flattened, wan_policy)
                )
        return rules

    def get_required_rules_list(self, settings_file):
        """
        Build all wan-rules neccessary for ipsec tunnels
        """
        ipsec_manager = registrar.get_manager("IpsecManager")
        ipsec_interface_settings = ipsec_manager.get_interfaces_settings(
            settings_file, enabled_check=False
        )
        rules = self.generate_wan_binding_rules(settings_file, ipsec_interface_settings)
        for interface_settings in ipsec_interface_settings:
            interface_name = interface_settings.get("name")
            interface_id = interface_settings.get("interfaceId")

            wan_policy = None
            for policy in settings_file.settings["wan"]["policies"]:
                if json.dumps(policy.get("interfaces")) == json.dumps(
                    [{"interfaceId": interface_id}]
                ):
                    wan_policy = policy
                    break

            if wan_policy is None:
                # No policy to attach.  This isn't neccessarily an error to stop processing on.
                continue

            policy_id = wan_policy.get("policyId")
            nft_policy_id = nftables_util.format_guid_for_nft(policy_id)

            for local_network in interface_settings.get("ipsec").get("local").get("networks"):
                if local_network.get("network") == "0.0.0.0":
                    continue
                local_network_address = local_network.get("network")
                local_network_prefix = local_network.get("prefix")
                for remote_network in (
                    interface_settings.get("ipsec").get("remote").get("networks")
                ):
                    remote_network_address = remote_network.get("network")
                    remote_network_prefix = remote_network.get("prefix")
                    rule = collections.OrderedDict(
                        copy.deepcopy(IpsecWanRuleManager.settings_rule_template)
                    )
                    rule["description"] = (
                        f"Send {remote_network_address}/{remote_network_prefix} via {interface_name}"
                    )
                    # Rule enabled must follow interface enable/disable controlled by rule manager.
                    rule["enabled"] = interface_settings.get("enabled")
                    self.set_manager(rule)
                    rule.get("action")["policy"] = policy_id
                    rule.get("conditions")[0]["value"] = (
                        f"{local_network_address}/{local_network_prefix}"
                    )
                    rule.get("conditions")[1]["value"] = (
                        f"{remote_network_address}/{remote_network_prefix}"
                    )
                    rule.get("logs")[0]["prefix"] = (
                        rule.get("logs")[0]
                        .get("prefix")
                        .replace("__nft_policy_id__", nft_policy_id)
                    )

                    rules.append(rule)

        return rules
