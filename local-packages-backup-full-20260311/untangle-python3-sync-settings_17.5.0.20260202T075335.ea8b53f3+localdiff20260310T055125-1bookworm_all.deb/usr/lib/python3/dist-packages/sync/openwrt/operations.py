import sync.registrar

sync.registrar.register_operation(
    "restart-nftables-rules", [""], ["/etc/init.d/nftables-rules restart"], 9, None
)
sync.registrar.register_operation(
    "restart-networking", [""], ["/etc/init.d/network reload"], 10, None
)
sync.registrar.register_operation("restart-qos", [""], ["/etc/init.d/qos restart"], 11, None)
sync.registrar.register_operation(
    "restart-wan-routing",
    [""],
    [
        "/etc/config/nft-wan-routing/102-wan-routing; "
        "/etc/init.d/wan-manager restart; "
        "/etc/init.d/pyconnector restart; "
        "/usr/sbin/conntrack -F"
    ],
    12,
    None,
)

sync.registrar.register_operation(
    "restart-ipsec", [""], ["/etc/init.d/ipsec restart ; ipsec restart"], 13, None
)
sync.registrar.register_operation(
    "restart-default-route",
    [""],
    ["/etc/config/ifdown.d/10-default-route"],
    14,
    "restart-networking",
)
sync.registrar.register_operation(
    "restart-uid",
    [""],
    ["/etc/init.d/client-license-service restart", "/etc/init.d/pyconnector restart"],
    15,
    None,
)

sync.registrar.register_operation("restart-wireless", [""], ["/sbin/wifi"], 20, None)

sync.registrar.register_operation(
    "restart-dhcp", [""], ["/etc/init.d/dnsmasq restart ; /etc/init.d/odhcpd restart"], 30, None
)

sync.registrar.register_operation(
    "restart-cron",
    [""],
    ["/etc/init.d/cron stop ; /etc/init.d/cron enable ; /etc/init.d/cron start "],
    35,
    None,
)

sync.registrar.register_operation(
    "startup-scripts", [""], ["/etc/init.d/startup boot ; /etc/init.d/setup boot"], 40, None
)

# /etc/sysctl.d/9* being lower prio, our configs
sync.registrar.register_operation("run-sysctl", [""], ["sysctl -p /etc/sysctl.d/9*"], 50, None)

sync.registrar.register_operation("setup-scripts", [""], ["/etc/init.d/setup boot"], 45, None)

sync.registrar.register_operation(
    "restart-nic-setting", [""], ["/etc/config/startup.d/060-nic-settings"], 30, "startup-scripts"
)
sync.registrar.register_operation(
    "restart-nic-intr-setting",
    [""],
    ["/etc/config/ifup.d/20-nic-intr-settings"],
    30,
    "startup-scripts",
)
sync.registrar.register_operation("restart-bctid", [""], ["/etc/init.d/bctid restart"], 30, None)

sync.registrar.register_operation("restart-lldpd", [""], ["/etc/init.d/lldpd restart"], 30, None)
sync.registrar.register_operation(
    "restart-dpdk", [""], ["/etc/config/startup.d/050-dpdk-bindings"], 30, None
)
sync.registrar.register_operation(
    "restart-restd-gind", [""], ["kill -s SIGUSR1 `pidof /usr/bin/restd`"], 30, None
)
sync.registrar.register_operation(
    "restart-restd-captive-portal", [""], ["kill -s SIGHUP `pidof /usr/bin/restd`"], 30, None
)
sync.registrar.register_operation(
    "sync-dos-active-session", [""], ["kill -s SIGHUP `pidof  /usr/bin/packetd`"], 30, None
)
sync.registrar.register_operation(
    "SIGHUP-packetd", [""], ["kill -s SIGHUP `pidof  /usr/bin/packetd`"], 30, None
)
sync.registrar.register_operation(
    "sync-dos-limit-values", [""], ["/usr/sbin/nft -f /etc/config/dos/nft-rules"], 30, None
)
sync.registrar.register_operation(
    "restart-restd-access",
    [""],
    ["kill -s SIGHUP `pidof /usr/bin/restd`", "/etc/config/nftables-rules.d/200-access"],
    30,
    None,
)
sync.registrar.register_operation(
    "system-scripts",
    [""],
    [
        "/etc/init.d/startup boot ; /etc/init.d/setup boot ; /etc/init.d/system restart ; /etc/init.d/log restart"
    ],
    30,
    None,
)
sync.registrar.register_operation(
    "restart-reportd-alerts", [""], ["kill -s HUP `pidof /usr/bin/reportd`"], 30, None
)
