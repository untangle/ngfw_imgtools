"""route_manager manages wan based routing decisions"""

import copy
import json
import os
import stat

from sync import MiscUtil, interface_util, network_util, nftables_util, registrar
from sync.common import Logger
from sync.common.const import MFW_CONFIG_WANPOLICY
from sync.common.route_manager import CommonRouteManager

# This class is responsible for writing /etc/iproute2/rt_tables and /etc/hotplug.d/iface/*
# based on the settings object passed from sync-settings

logger = Logger.getInstance()


class RouteManager(CommonRouteManager):
    """
    Manages files responsible for wan routing
    """

    static_initialized = False

    SRC_INTERFACE_MASK_INVERSE = 0xFFFFFF00
    SRC_INTERFACE_SHIFT = 0
    CLIENT_INTERFACE_MASK = 0x000000FF
    CLIENT_INTERFACE_MASK_INVERSE = 0xFFFFFF00
    CLIENT_INTERFACE_SHIFT = 0
    SERVER_INTERFACE_MASK = 0x0000FF00
    SERVER_INTERFACE_MASK_INVERSE = 0xFFFF00FF
    SERVER_INTERFACE_SHIFT = 8
    SRC_TYPE_MASK = 0x03000000
    SRC_TYPE_MASK_INVERSE = 0xFCFFFFFF
    SRC_TYPE_SHIFT = 24
    CLIENT_TYPE_MASK = 0x03000000
    CLIENT_TYPE_MASK_INVERSE = 0xFCFFFFFF
    CLIENT_TYPE_SHIFT = 24
    SERVER_TYPE_MASK_INVERSE = 0xF3FFFFFF
    SERVER_TYPE_SHIFT = 26
    ALL_MASK = 0x0FFFFFFF
    LOCAL_INTERFACE_ID = 0xFF  # 255

    rt_tables_filename = "/etc/iproute2/rt_tables"
    rt_tables_file = None
    ifup_routes_filename = "/etc/config/ifup.d/10-default-route"
    ifup_route_file = None
    ifdown_routes_filename = "/etc/config/ifdown.d/10-default-route"
    ifdown_route_file = None
    wan_routing_filename = "/etc/config/nft-wan-routing/102-wan-routing"
    wan_routing_file = None
    wan_manager_filename = "/etc/config/wan_manager"
    wan_manager_file = None
    udhcpc_user_filename = "/etc/udhcpc.user"
    udhcpc_user_file = None

    wan_manager_metric_settings_stat = {
        "LATENCY": "latency",
        "AVAILABLE_BANDWIDTH": "available_bandwidth",
        "JITTER": "jitter",
        "PACKET_LOSS": "packet_loss",
    }
    wan_manager_metric_settings_name = {
        "LATENCY": "1_minute",
        "AVAILABLE_BANDWIDTH": "1_minute",
        "JITTER": "1_minute",
        "PACKET_LOSS": "1_minute",
    }
    wan_manager_metric_settings_op = {"<": "lt", "<=": "le", ">": "gt", ">=": "ge"}
    wan_manager_metric_settings_test = {"PING": "ping", "HTTP": "http", "ARP": "arp", "DNS": "dns"}

    ##
    ## On-demand speedtest policy/rule that is added when policy_file is defined from speedtest.sh
    ##
    speedtest = {
        "enabled": False,
        "policy_file": "/tmp/sync-settings-route-manager-speedtest",  # noqa: S108
        "settings": {},
        "policy_id": "00000001-0000-0000-0000-000000000001",
        "rule_id": "00000002-0000-0000-0000-000000000002",
        "nft_policy_id": None,
        "nft_rule_id": None,
        "policy": {
            "description": "speedtest",
            "enabled": True,
            "interfaces": [{"interfaceId": -1}],
            "policyId": "__policy_id__",
            "type": "SPECIFIC_WAN",
        },
        "rule": {
            "action": {"policy": "__policy_id__", "type": "WAN_POLICY"},
            "conditions": [{"op": "==", "type": "SOURCE_ADDRESS", "value": "__address__/32"}],
            "description": "Route everything regardless of source throug",
            "enabled": True,
            "logs": [
                {
                    "type": "NFLOG",
                    "prefix": "{'type':'R:wan-routing:user-wan-rules','ruleId':'__nft_rule_id__','action':'WAN_POLICY','policy':'__nft_policy_id__'}",
                },
                {
                    "type": "DICT",
                    "field": "wan_rule_id",
                    "field_type": "long_string",
                    "value": "__nft_rule_id__",
                },
            ],
            "ruleId": "__rule_id__",
        },
    }

    @classmethod
    def static_initialize(cls) -> None:
        """
        Create static variables when class file is loaded.
        """
        RouteManager.static_initialized = True

        RouteManager.static_initialize_speedtest()

    @classmethod
    def static_initialize_speedtest(cls) -> None:
        """ """
        RouteManager.speedtest["enabled"] = os.path.exists(RouteManager.speedtest["policy_file"])
        if RouteManager.speedtest["enabled"] is False:
            return

        # Read json settings.
        try:
            file = open(RouteManager.speedtest["policy_file"])
            data = file.read()
            file.close()
            RouteManager.speedtest["settings"] = json.loads(data)
        except OSError:
            logger.exception("Unable to read settings file.")

        # Update policy and rules with the full ids, nft ids, and settings keypair.
        RouteManager.speedtest["nft_policy_id"] = nftables_util.format_guid_for_nft(
            RouteManager.speedtest["policy_id"]
        )
        RouteManager.speedtest["nft_rule_id"] = nftables_util.format_guid_for_nft(
            RouteManager.speedtest["rule_id"]
        )
        parameters = {
            "__policy_id__": RouteManager.speedtest["policy_id"],
            "__rule_id__": RouteManager.speedtest["rule_id"],
            "__nft_policy_id__": RouteManager.speedtest["nft_policy_id"],
            "__nft_rule_id__": RouteManager.speedtest["nft_rule_id"],
        }

        # NOTE: Since settings isn't loaded, the policy interfaceId will be filled in at class instantiation when
        #       writing the policy.
        for k in RouteManager.speedtest["settings"]:
            parameters[f"__{k}__"] = RouteManager.speedtest["settings"][k]

        RouteManager.speedtest["policy"] = MiscUtil.replace_parameters(
            RouteManager.speedtest["policy"], parameters
        )
        RouteManager.speedtest["rule"] = MiscUtil.replace_parameters(
            RouteManager.speedtest["rule"], parameters
        )

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.ifup_routes_filename, "restart-default-route", self)
        registrar.register_file(self.ifdown_routes_filename, "restart-default-route", self)
        registrar.register_file(self.rt_tables_filename, "restart-networking", self)

        registrar.register_file(self.wan_routing_filename, "restart-wan-routing", self)
        registrar.register_file(self.wan_manager_filename, "restart-wan-routing", self)
        registrar.register_file(self.udhcpc_user_filename, "restart-networking", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Syncing settings")
        super().delete_wan_routing_config_file(self.wan_routing_filename)
        self.write_rt_tables_file(settings_file.settings, prefix)
        self.write_ifup_routes_file(settings_file.settings, prefix)
        self.write_ifdown_routes_file(settings_file.settings, prefix)

        self.write_wan_routing_file(settings_file, prefix)
        self.write_wan_manager_file(settings_file.settings, prefix)
        self.write_dhcp_user_file(settings_file.settings, prefix)

    def get_policymanager_wan_policies(self, settings: dict) -> list:
        """get_policymanager_wan_policies:

        gets all wan policies that policy manager has, by looking
        under policy_manager/configurations in settings

        settings: the settings part of sync-settings
        returns: a list of WAN policy configurations, as dicts."""
        polman_configs = settings.get("policy_manager", {}).get("configurations", [])
        return [config for config in polman_configs if config.get("type") == MFW_CONFIG_WANPOLICY]

    def get_all_wan_policies(self, settings: dict) -> list:
        """get_all_wan_policies:

        gets all WAN policies from both policy manager, and the
        regular/legacy place.

        This also massages the WAN policies from policy manager into
        the old-style format for backward compatibility by pulling in
        fields from the upper layer into the regular settings field
        layer, see policy manager WAN policy examples.

        settings: the top-level settings, as a dict.
        returns -- list of dicts, for both legacy and policy manager
        WAN policies.

        """
        wan = settings["wan"]
        legacy_policies = copy.deepcopy(wan.get("policies", []))
        return legacy_policies + [
            # We have to re-inject ID since the policy manager schema
            # doesn't have it, it is in the above object.
            {
                "policyId": policy.get("id"),
                "name": policy.get("name", ""),
                "description": policy.get("description", ""),
                "enabled": True,
                **policy.get("settings", {}),
            }
            for policy in self.get_policymanager_wan_policies(settings)
        ]

    def get_policymanager_wan_policy_ids(self, settings: dict) -> set:
        """get_policymanager_wan_policy_ids:

        get a set of all policy manager-managed WAN policy IDs
        formatted for nft, so we get the first part of the GUID. This
        will not include legacy IDs under "wan".

        settings: top-level settings as dict.
        returns: set of strings, which are all policy IDs.

        """
        cfgs = self.get_policymanager_wan_policies(settings)

        return {nftables_util.format_guid_for_nft(cfg.get("id")) for cfg in cfgs}

    def write_wan_manager_file(self, settings, prefix="") -> None:
        """
        write_wan_manager_file writes /etc/config/wan_manager
        """
        filename = prefix + self.wan_manager_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.wan_manager_file = open(filename, "w+")
        file = self.wan_manager_file

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten." + "\n")
        file.write("\n")
        file.write("# Make sure default route is up to date" + "\n")
        file.write("/etc/config/ifdown.d/10-default-route" + "\n")
        file.write("\n")

        if "wan_manager" in settings.get("wan"):
            # Add wan-manager specific attributes
            wan_manager = settings.get("wan").get("wan_manager")
            if "debug" in wan_manager:
                # Specify persistent debug flag
                if "debug" in wan_manager:
                    debug_value = "true" if wan_manager.get("debug") is True else "false"
                    file.write(f"DEBUG={debug_value}\n")
                    file.write("\n")

        # Enable/Disable router advertisements for IPv6
        interfaces_settings = settings.get("network").get("interfaces")
        file.write("# Ipv6 router advertisements" + "\n")
        for interface_setting in interfaces_settings:
            if (
                interface_setting.get("enabled")
                and interface_setting.get("v6ConfigType") is not None
                and interface_setting.get("v6ConfigType") != "DISABLED"
            ):
                router_advertisements = 1 if interface_setting.get("routerAdvertisements") else 0
                device = interface_setting.get("device")
                file.write(
                    f"echo {router_advertisements} > /proc/sys/net/ipv6/conf/{device}/accept_ra || true"
                    "\n"
                )

        # Build list of policies to only if they are associated by wan rules.
        wan = settings["wan"]
        active_policy_ids = set()
        if RouteManager.speedtest["enabled"]:
            active_policy_ids.add(RouteManager.speedtest["nft_policy_id"])
        policy_chains = wan.get("policy_chains", [])

        for policy_chain in policy_chains:
            for rule in policy_chain.get("rules"):
                if rule.get("enabled"):
                    action = rule.get("action")
                    if action.get("type") == "WAN_POLICY":
                        policy = nftables_util.format_guid_for_nft(action.get("policy"))
                        active_policy_ids.add(policy)

        policies = self.get_all_wan_policies(settings)
        active_policy_ids.update(self.get_policymanager_wan_policy_ids(settings))

        if RouteManager.speedtest["enabled"]:
            policies.insert(0, RouteManager.speedtest["policy"])
        for policy in policies:
            policyId = nftables_util.format_guid_for_nft(policy.get("policyId"))
            if policyId not in active_policy_ids:
                continue

            # Comment for policy
            policy_name = policy.get("description")
            policy_id = policy.get("policyId")
            policy_criteria = policy.get("criteria")

            file.write("\n" + f"# {policy_name} - {policy_id}" + "\n")
            # Separate types is logic to indicate we should intellegently distinguish
            # between VPN and non-VPN interfaces.  For example, in best_of without criteria,
            # treat the non-VPNs as up criteria while treating the VPN as a possible post best_of
            # policy switch.
            separate_types = False
            interfaces = policy.get("interfaces")
            if len(interfaces) == 1:
                if interfaces[0].get("interfaceId") == 0:
                    # "All WANs" specified, get list of all WAN interfaces in policy interface format
                    interfaces = interface_util.get_all_wan_list(settings)
                    if policy_criteria is None or len(policy_criteria) == 0:
                        separate_types = True
                elif interfaces[0].get("interfaceId") == -1:
                    if RouteManager.speedtest["enabled"]:
                        # Speedtest uses special -1 value to indicate we should fill with the actual interface id.
                        intfs = [
                            network_util.get_interface_by_device(
                                settings, RouteManager.speedtest["settings"]["device"]
                            )
                        ]
                        interfaces[0]["interfaceId"] = intfs[0].get("interfaceId")

            # Build lists of public and VPN interface ids.
            wan_interface_ids = []
            vpn_interface_ids = []
            for interface in interfaces:
                for interface_setting in interfaces_settings:
                    if interface_setting.get("interfaceId") != interface.get("interfaceId"):
                        continue
                    if (
                        interface_setting.get("type") == "OPENVPN"
                        or interface_setting.get("type") == "WIREGUARD"
                        or interface_setting.get("type") == "IPSEC"
                    ):
                        vpn_interface_ids.append(interface.get("interfaceId"))
                    else:
                        wan_interface_ids.append(interface.get("interfaceId"))

            # Interface-based criteria
            for intf in interfaces:
                interfaceId = intf.get("interfaceId")
                if (
                    separate_types
                    and (len(wan_interface_ids) > 0)
                    and (len(vpn_interface_ids) > 0)
                    and (interfaceId in vpn_interface_ids)
                ):
                    # In a default mix of WAN and VPN, ignore VPN for criteria
                    continue

                # Pull values from settings
                interfaceEnabled = False
                interfaceType = None
                interface_family_name = []
                for interface_setting in interfaces_settings:
                    if interface_setting.get("interfaceId") != interfaceId:
                        continue
                    interfaceEnabled = interface_setting.get("enabled")
                    interfaceType = interface_setting.get("type")
                    if interfaceType in ("OPENVPN", "WIREGUARD", "IPSEC"):
                        (type, family, name) = network_util.get_vpn_interface_family_and_name(
                            settings, interface_setting
                        )
                        interface_family_name.append((family, name))
                    else:
                        if "v4ConfigType" in interface_setting and (
                            interface_setting.get("v4ConfigType") != "DISABLED"
                        ):
                            interface_family_name.append(
                                (
                                    "ipv4",
                                    network_util.get_interface_name(
                                        settings,
                                        network_util.get_interface_by_id(settings, interfaceId),
                                        "ipv4",
                                    ),
                                )
                            )
                        if "v6ConfigType" in interface_setting and (
                            interface_setting.get("v6ConfigType") != "DISABLED"
                        ):
                            interface_family_name.append(
                                (
                                    "ipv6",
                                    network_util.get_interface_name(
                                        settings,
                                        network_util.get_interface_by_id(settings, interfaceId),
                                        "ipv6",
                                    ),
                                )
                            )

                if interfaceEnabled is False or interfaceType is None:
                    continue

                for interfaceFamily, interfaceName in interface_family_name:
                    # Implcit  criteria  for  all  polices  unless
                    # overriden by ALWAYS_UP. An interface must be
                    # up, unless we overrode that with always_up.
                    if not self.policy_has_always_up(policy):
                        file.write(
                            f"criteria_up policy-{policyId} {interfaceId} {interfaceName} {interfaceFamily}"
                            "\n"
                        )

                if policy_criteria is not None:
                    for criterion in policy_criteria:
                        if criterion.get("type") == "ATTRIBUTE":
                            # Attribute matches are calculated here instead of WAN manager.
                            attribute_key = criterion.get("attribute")
                            attribute_value = criterion.get("name_contains")

                            for interfaceFamily, interfaceName in interface_family_name:
                                # Assume down
                                wan_result = "down"
                                if attribute_key == "NAME":
                                    if attribute_value.lower() in interfaceName.lower():
                                        # Case insensitive interface name substring match
                                        wan_result = "up"
                                elif attribute_key == "VPN":
                                    attribute_value = "true"
                                    if interfaceType in ("OPENVPN", "WIREGUARD", "IPSEC"):
                                        # This is a VPN type
                                        wan_result = "up"

                                file.write(
                                    f"criteria_attribute policy-{policyId} {interfaceId} {interfaceName} {interfaceFamily} {attribute_key} {attribute_value} {wan_result}"
                                    "\n"
                                )

                        elif criterion.get("type") == "METRIC":
                            for interfaceFamily, interfaceName in interface_family_name:
                                metric_key = criterion.get("metric")
                                metric_value = criterion.get("metric_value")
                                metric_op = criterion.get("metric_op")

                                if metric_key not in RouteManager.wan_manager_metric_settings_stat:
                                    continue
                                if metric_key not in RouteManager.wan_manager_metric_settings_name:
                                    continue
                                if metric_op not in RouteManager.wan_manager_metric_settings_op:
                                    continue

                                stat = RouteManager.wan_manager_metric_settings_stat[metric_key]
                                name = RouteManager.wan_manager_metric_settings_name[metric_key]
                                op = RouteManager.wan_manager_metric_settings_op[metric_op]

                                file.write(
                                    f"criteria_metric policy-{policyId} {interfaceId} {interfaceName} {interfaceFamily} {stat} {name} {op} {metric_value}"
                                    "\n"
                                )

                        elif criterion.get("type") == "CONNECTIVITY":
                            for interfaceFamily, interfaceName in interface_family_name:
                                test_type = criterion.get("connectivityTestType")
                                interval = criterion.get("connectivityTestInterval")
                                timeout = criterion.get("connectivityTestTimeout")
                                threshold = criterion.get("connectivityTestFailureThreshold")
                                target = criterion.get("connectivityTestTarget")

                                if test_type not in RouteManager.wan_manager_metric_settings_test:
                                    continue
                                test = RouteManager.wan_manager_metric_settings_test[test_type]

                                file.write(
                                    f"criteria_connectivity "
                                    f"policy-{policyId} {interfaceId} "
                                    f"{interfaceName} {interfaceFamily} "
                                    f"{test} {interval} {timeout} "
                                    f"{threshold} {target}" + "\n"
                                )

                        elif criterion.get("type") == "ALWAYS_UP":
                            for interfaceFamily, interfaceName in interface_family_name:
                                file.write(
                                    f"criteria_always_up "
                                    f"policy-{policyId} "
                                    f"{interfaceId} {interfaceFamily}\n"
                                )

            # Policy
            if policy.get("type") == "SPECIFIC_WAN":
                file.write(f"policy_specific_wan policy-{policyId} {interfaceId}" + "\n")
            elif policy.get("type") == "BALANCE":
                algorithm = policy.get("balance_algorithm")
                file.write(f"policy_balance policy-{policyId} {algorithm}" + "\n")
            elif policy.get("type") == "BEST_OF":
                best_of_metric = policy.get("best_of_metric")
                if best_of_metric == "LOWEST_LATENCY":
                    metric_key = "LATENCY"
                    op_key = "<="
                elif best_of_metric == "LOWEST_JITTER":
                    metric_key = "JITTER"
                    op_key = "<="
                elif best_of_metric == "HIGHEST_AVAILABLE_BANDWIDTH":
                    metric_key = "AVAILABLE_BANDWIDTH"
                    op_key = ">="
                elif best_of_metric == "LOWEST_PACKET_LOSS":
                    metric_key = "PACKET_LOSS"
                    op_key = "<="

                stat = RouteManager.wan_manager_metric_settings_stat[metric_key]
                name = RouteManager.wan_manager_metric_settings_name[metric_key]
                op = RouteManager.wan_manager_metric_settings_op[op_key]
                file.write(f"policy_best_of policy-{policyId} {stat} {name} {op}" + "\n")

                if len(wan_interface_ids) > 0 and len(vpn_interface_ids) > 0:
                    # We have one or more VPNs that should attempt to switch to best WAN
                    for interface in interfaces:
                        interface_id = interface.get("interfaceId")
                        if interface_id not in vpn_interface_ids:
                            continue

                        interface_enabled = False
                        bound_interface_id = None
                        local_gateway = None
                        for interface_setting in interfaces_settings:
                            if interface_setting.get("interfaceId") != interface_id:
                                continue
                            if interface_setting.get("type") != "IPSEC":
                                # Only consider ISPEC interfaces
                                continue
                            interface_enabled = interface_setting.get("enabled")
                            bound_interface_id = interface_setting.get("boundInterfaceId")
                            local_gateway = (
                                interface_setting.get("ipsec").get("local").get("gateway")
                            )
                            break

                        if interface_enabled is False:
                            # Do not balance disabled devices
                            continue

                        if bound_interface_id != 0:
                            # Do not balance if bound to explicit interface
                            continue

                        if local_gateway != "%any":
                            # Don't balance for explicitly defined gateway
                            continue

                        (type, family, interface_device) = (
                            network_util.get_vpn_interface_family_and_name(
                                settings, interface_setting
                            )
                        )

                        if type == "IPSEC":
                            file.write(
                                f"policy_best_of_ipsec_vpn policy-{policyId} {interface_id} {interface_device} {family}"
                                "\n"
                            )

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def policy_has_always_up(self, policy):
        return any(
            criterion.get("type") == "ALWAYS_UP" for criterion in policy.get("criteria", [])
        )

    def write_wan_routing_file(self, settings_file, prefix="") -> None:
        """write_wan_routing_file writes /etc/config/nft-wan-routing/102-wan-routing"""
        filename = prefix + self.wan_routing_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.wan_routing_file = open(filename, "w+")
        file = self.wan_routing_file

        file.write("#!/usr/bin/nft_debug -f")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")
        interfaces = settings_file.settings.get("network").get("interfaces")

        self.write_wan_routing_tables(settings_file, file, interfaces, "ip")

        # Only write the ip6 wan-routing tables if any interfaces have ipv6 enabled

        self.write_wan_routing_tables(settings_file, file, interfaces, "ip6")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

    def write_wan_routing_tables(self, settings_file, file, interfaces, family) -> None:
        """write_wan_routing_tables writes the specific ip family type rules and tables"""
        # This is used for rules that reference the ipvX_addr type
        settings = settings_file.settings
        if family == "ip6":
            pass

        file.write("\n")
        file.write(f"## {family} family rules. ##\n")
        file.write("\n")

        file.write(f"add table {family} wan-routing\n")
        file.write(f"flush table {family} wan-routing\n")
        file.write(f"add table {family} wan-routing\n")
        file.write("\n")

        # this map will be used by policy manager to route things.
        file.write(
            f"add map {family} wan-routing policy-manager-routing {{type ct_id : verdict; }}\n"
        )
        file.write(f"flush map {family} wan-routing policy-manager-routing\n")

        file.write(f"add chain {family} wan-routing restore-interface-marks\n")
        file.write(f"add chain {family} wan-routing restore-interface-marks-original\n")
        file.write(f"add chain {family} wan-routing restore-interface-marks-reply\n")
        file.write(
            f"add rule {family} wan-routing restore-interface-marks ct direction original jump restore-interface-marks-original\n"
        )
        file.write(
            f"add rule {family} wan-routing restore-interface-marks ct direction reply jump restore-interface-marks-reply\n"
        )
        file.write(
            f"add rule {family} wan-routing restore-interface-marks-original mark set ct mark and 0x{self.ALL_MASK:x}\n"
        )

        for intf in interfaces:
            if network_util.enabled_wan(intf) or network_util.enabled_management(intf):
                file.write(
                    "add chain %s wan-routing mark-for-wan-%d\n"
                    % (family, intf.get("interfaceId"))
                )
                file.write(
                    "add rule %s wan-routing mark-for-wan-%d mark set mark and 0xffff00ff or 0x%x\n"
                    % (family, intf.get("interfaceId"), ((intf.get("interfaceId") << 8) & 0xFF00))
                )
                file.write(
                    "add rule %s wan-routing mark-for-wan-%d accept\n"
                    % (family, intf.get("interfaceId"))
                )
                file.write("\n")

            if not intf.get("enabled"):
                continue
            if intf.get("configType") == "BRIDGED":
                continue

            # just use the normal interface name
            # unless its a bridge and then use the bridge zone interface name
            intf.get("netfilterDev")
            interface_type = 2  # lan
            if intf.get("wan"):
                interface_type = 1  # wan
            interface_id = intf.get("interfaceId")

            file.write(
                f"# if ct mark server interface is {interface_id} then set the mark client interface to {interface_id}\n"
            )
            file.write(
                f"add rule {family} wan-routing restore-interface-marks-reply ct mark and 0x{self.SERVER_INTERFACE_MASK:x} == 0x{interface_id << self.SERVER_INTERFACE_SHIFT:x} mark set mark and 0x{self.CLIENT_INTERFACE_MASK_INVERSE:x} or 0x{interface_id << self.CLIENT_INTERFACE_SHIFT:x}\n"
            )
            file.write(
                f"# if ct mark server interface is {interface_id} then set the mark client type to {interface_type}s type\n"
            )
            file.write(
                f"add rule {family} wan-routing restore-interface-marks-reply ct mark and 0x{self.SERVER_INTERFACE_MASK:x} == 0x{interface_id << self.SERVER_INTERFACE_SHIFT:x} mark set mark and 0x{self.CLIENT_TYPE_MASK_INVERSE:x} or 0x{interface_type << self.CLIENT_TYPE_SHIFT:x}\n"
            )
            file.write(
                f"# if ct mark client interface is {interface_id} then set the mark server interface to {interface_id}\n"
            )
            file.write(
                f"add rule {family} wan-routing restore-interface-marks-reply ct mark and 0x{self.CLIENT_INTERFACE_MASK:x} == 0x{interface_id << self.CLIENT_INTERFACE_SHIFT:x} mark set mark and 0x{self.SERVER_INTERFACE_MASK_INVERSE:x} or 0x{interface_id << self.SERVER_INTERFACE_SHIFT:x}\n"
            )
            file.write(
                f"# if ct mark client interface is {interface_id} then set the mark server type to {interface_type}s type\n"
            )
            file.write(
                f"add rule {family} wan-routing restore-interface-marks-reply ct mark and 0x{self.CLIENT_INTERFACE_MASK:x} == 0x{interface_id << self.CLIENT_INTERFACE_SHIFT:x} mark set mark and 0x{self.SERVER_TYPE_MASK_INVERSE:x} or 0x{interface_type << self.SERVER_TYPE_SHIFT:x}\n"
            )

        file.write("# restore reply direction interface marks for local output traffic\n")
        file.write(
            f"add rule {family} wan-routing restore-interface-marks-reply ct mark and 0x{self.SERVER_INTERFACE_MASK:x} == 0x{255 << self.SERVER_INTERFACE_SHIFT:x} mark set mark and 0x{self.CLIENT_INTERFACE_MASK_INVERSE:x} or 0x{255 << self.CLIENT_INTERFACE_SHIFT:x}\n"
        )
        file.write(
            f"add rule {family} wan-routing restore-interface-marks-reply ct mark and 0x{self.CLIENT_INTERFACE_MASK:x} == 0x{255 << self.CLIENT_INTERFACE_SHIFT:x} mark set mark and 0x{self.SERVER_INTERFACE_MASK_INVERSE:x} or 0x{255 << self.SERVER_INTERFACE_SHIFT:x}\n"
        )

        default_wan = 0
        for intf in interfaces:
            if network_util.enabled_wan(intf):
                default_wan = intf.get("interfaceId")
                break

        file.write(f"add chain {family} wan-routing route-to-default-wan\n")
        file.write(
            f"add rule {family} wan-routing route-to-default-wan dict sessions ct id wan_policy long_string set system-default\n"
        )
        file.write(
            "add rule %s wan-routing route-to-default-wan jump mark-for-wan-%d\n"
            % (family, default_wan)
        )
        file.write("\n")

        wan = settings["wan"]
        policies = self.get_all_wan_policies(settings)
        if RouteManager.speedtest["enabled"]:
            policies.insert(0, RouteManager.speedtest["policy"])
        for policy in policies:
            policyId = nftables_util.format_guid_for_nft(policy.get("policyId"))
            file.write(f"add chain {family} wan-routing route-to-policy-{policyId}\n")
            file.write(
                f'add rule {family} wan-routing route-to-policy-{policyId} return comment "policy disabled"\n'
            )
            file.write("\n")

        has_cc_rules = False
        policy_chains = copy.deepcopy(wan.get("policy_chains", []))
        if RouteManager.speedtest["enabled"]:
            policy_chains[0]["rules"].insert(0, RouteManager.speedtest["rule"])
        for chain in policy_chains:
            chain_name = chain.get("name")
            if chain_name == "command-center-rules":
                has_cc_rules = True
            chain.get("rules")

            file.write(nftables_util.chain_create_cmd(chain, family, None, "wan-routing") + "\n")
            file.write(nftables_util.chain_rules_cmds(chain, family, None, "wan-routing") + "\n")
            file.write("\n")

        file.write(f"add chain {family} wan-routing wan-routing-entry\n")
        if has_cc_rules:
            file.write(
                f"add rule {family} wan-routing wan-routing-entry jump command-center-rules\n"
            )

        # first, see if policy manager already has decided a policy,
        # use that if it has.
        file.write(
            f"add rule {family} wan-routing wan-routing-entry ct id vmap @policy-manager-routing counter\n"
        )

        file.write(f"add rule {family} wan-routing wan-routing-entry jump user-wan-rules\n")
        file.write(f"add rule {family} wan-routing wan-routing-entry counter\n")
        file.write(
            f"add rule {family} wan-routing wan-routing-entry log prefix \"{{'type':'R:wan-routing:wan-routing-entry','ruleId':'-2','action':'WAN_POLICY','policy':'-2'}}\" group 0 jump route-to-default-wan\n"
        )
        file.write(f"add rule {family} wan-routing wan-routing-entry counter\n")

        file.write("\n")
        file.write(
            f"add chain {family} wan-routing wan-routing-prerouting {{ type filter hook prerouting priority -25 ; }}\n"
        )

        # Build nft NOT matches to add conditionals to avoid leaving prerouting too soon.
        # For example with a full tunnel ipsec, we want traffic from remote side to be treated like LAN.
        # If treated like normal WAN traffic, we won't NAT out our WAN.
        ignore_interfaces = []
        ipsec_manager = registrar.get_manager("IpsecManager")
        ipsec_interfaces = ipsec_manager.get_full_tunnel_interfaces(settings_file)
        for ipsec_interface in ipsec_interfaces:
            # Build negative mark matches based on interface ids
            ignore_interfaces.append(
                f"mark and 0x{RouteManager.LOCAL_INTERFACE_ID:2x} != 0x{ipsec_interface:x}"
            )
        # MFW-948: Check if the packet SRC_TYPE mark is a WAN type, then just return from wan-routing-prerouting
        file.write(
            "add rule {} wan-routing wan-routing-prerouting mark and 0x{:08x} == 0x01000000 {} return\n".format(
                family, RouteManager.SRC_TYPE_MASK, " ".join(ignore_interfaces)
            )
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-prerouting mark and 0x{RouteManager.SERVER_INTERFACE_MASK:08x} != 0 return\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-prerouting fib daddr type local return\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-prerouting ct state new jump wan-routing-entry\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-prerouting ct state invalid counter\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-prerouting ct state established counter\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-prerouting ct state related counter\n"
        )

        file.write("\n")
        file.write(
            f"add chain {family} wan-routing wan-routing-output {{ type route hook output priority -150 ; }}\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-output jump restore-interface-marks\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-output ct state new ct mark set ct mark and 0x{self.CLIENT_INTERFACE_MASK_INVERSE:x} or 0x{self.LOCAL_INTERFACE_ID << self.CLIENT_INTERFACE_SHIFT:x}\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-output ct state new ct mark set ct mark and 0x{self.CLIENT_TYPE_MASK_INVERSE:x} or 0x{(2 << self.CLIENT_TYPE_SHIFT) & self.CLIENT_TYPE_MASK:x}\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-output mark set mark and 0x{self.SRC_INTERFACE_MASK_INVERSE:x} or 0x{self.LOCAL_INTERFACE_ID << self.SRC_INTERFACE_SHIFT:x}\n"
        )
        file.write(
            f"add rule {family} wan-routing wan-routing-output mark set mark and 0x{self.SRC_TYPE_MASK_INVERSE:x} or 0x{(2 << self.SRC_TYPE_SHIFT) & self.SRC_TYPE_MASK:x}\n"
        )
        for intf in interfaces:
            if not intf.get("enabled"):
                continue
            if intf.get("wan"):
                continue
            file.write(
                "add rule {} wan-routing wan-routing-output oifname {} return\n".format(
                    family, intf.get("netfilterDev")
                )
            )
        file.write(
            f"add rule {family} wan-routing wan-routing-output mark and 0x0000ff00 != 0 return\n"
        )
        file.write(f"add rule {family} wan-routing wan-routing-output oif lo return\n")
        file.write(
            f"add rule {family} wan-routing wan-routing-output ct state new jump wan-routing-entry\n"
        )
        file.write(f"add rule {family} wan-routing wan-routing-output ct state invalid counter\n")
        file.write(
            f"add rule {family} wan-routing wan-routing-output ct state established counter\n"
        )
        file.write(f"add rule {family} wan-routing wan-routing-output ct state related counter\n")

    def write_rt_tables_file(self, settings, prefix="") -> None:
        """write_rt_tables_file writes /etc/iproute2/rt_tables"""
        filename = prefix + self.rt_tables_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.rt_tables_file = open(filename, "w+")
        file = self.rt_tables_file

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write("#\n")
        file.write("# reserved values\n")
        file.write("#\n")
        file.write("128\tprelocal\n")
        file.write("255\tlocal\n")
        file.write("254\tmain\n")
        file.write("253\tdefault\n")
        file.write("0\tunspec\n")
        file.write("#\n")
        file.write("# local\n")
        file.write("#\n")
        file.write("#1\tinr.ruhep\n")
        file.write("\n\n")
        file.write("#\n")
        file.write("# WAN tables\n")
        file.write("#\n")

        interfaces = settings.get("network").get("interfaces")
        for intf in interfaces:
            if network_util.enabled_wan(intf):
                interface_id = intf.get("interfaceId")
                # WAN rules
                file.write("%d\twan.%d\n" % (interface_id, interface_id))

        file.write("\n\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_ifup_routes_file(self, settings, prefix="") -> None:
        """write_ifup_routes_file writes /etc/config/ifup.d/10-default-route"""
        filename = prefix + self.ifup_routes_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.ifup_route_file = open(filename, "w+")
        file = self.ifup_route_file
        file.write("#!/bin/sh")
        file.write("\n\n")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")
        file.write(". /lib/functions/network.sh\n")
        file.write("\n")
        file.write("INTERFACE=$1\n")
        file.write("DEVICE=$2\n")
        file.write("\n")

        if interface_util.get_number_of_wans(settings) == 1:
            file.write("\n# Only one wan, do nothing\n\n")
        else:
            file.write("write_rules()\n")
            file.write("{\n")
            file.write("\tnft -f $TMPFILE\n")
            file.write("\tretval=$?\n")
            file.write("\twhile [ $retval -ne 0 ] ; do\n")
            file.write("\t\tnft -f $TMPFILE\n")
            file.write("\t\tretval=$?\n")
            file.write("\tdone\n")
            file.write("\trm $TMPFILE\n")
            file.write("\texit 0\n")
            file.write("}\n\n")

            interfaces = settings.get("network").get("interfaces")
            for intf in interfaces:
                if network_util.enabled_wan(intf):
                    if intf.get("v4ConfigType") != "DISABLED":
                        self.create_ifup_default_route(
                            file,
                            intf.get("interfaceId"),
                            network_util.get_interface_name(settings, intf, "ipv4"),
                            "ip",
                        )

                    if intf.get("v6ConfigType") != "DISABLED":
                        self.create_ifup_default_route(
                            file,
                            intf.get("interfaceId"),
                            network_util.get_interface_name(settings, intf, "ipv6"),
                            "ip6",
                        )

        file.flush()
        file.close()
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(filename))

    def create_ifup_default_route(self, file, interfaceId, interfaceName, tablefamily) -> None:
        """create_ifup_default_route creates a validation for checking if the route-to-default-wan chains are updated"""
        file.write(f'[ {interfaceName} = "$INTERFACE" ] && {{\n')
        file.write(
            f"\tnft list chain {tablefamily} wan-routing route-to-default-wan | grep -q mark-for-wan- || {{\n"
        )
        file.write("\t\tTMPFILE=`mktemp -t default-route.XXXXXX`\n")
        file.write(
            f"\t\techo flush chain {tablefamily} wan-routing route-to-default-wan >> $TMPFILE\n"
        )
        file.write(
            f"\t\techo add rule {tablefamily} wan-routing route-to-default-wan dict sessions ct id wan_policy long_string set system-default >> $TMPFILE\n"
        )
        file.write(
            "\t\techo add rule %s wan-routing route-to-default-wan jump mark-for-wan-%d >> $TMPFILE\n"
            % (tablefamily, interfaceId)
        )
        file.write("\t\twrite_rules\n")
        file.write("\t}\n")
        file.write("\texit 0\n")
        file.write("}\n\n")

    def write_ifdown_routes_file(self, settings, prefix="") -> None:
        """write_ifdown_routes_file writes /etc/config/ifdown.d/10-default-route"""
        filename = prefix + self.ifdown_routes_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.ifdown_route_file = open(filename, "w+")
        file = self.ifdown_route_file
        file.write("#!/bin/sh")
        file.write("\n\n")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")
        file.write(". /lib/functions/network.sh\n")
        file.write("\n")
        file.write("INTERFACE=$1\n")

        if interface_util.get_number_of_wans(settings) == 1:
            file.write("\n# Only one wan, do nothing\n\n")
        else:
            file.write("write_rules()\n")
            file.write("{\n")
            file.write("\tnft -f $TMPFILE\n")
            file.write("\tretval=$?\n")
            file.write("\twhile [ $retval -ne 0 ] ; do\n")
            file.write("\t\tnft -f $TMPFILE\n")
            file.write("\t\tretval=$?\n")
            file.write("\tdone\n")
            file.write("\trm $TMPFILE\n")
            file.write("\texit 0\n")
            file.write("}\n\n")
            file.write("update_default_route()\n")
            file.write("{\n")
            file.write("\n")

            interfaces = settings.get("network").get("interfaces")
            for intf in interfaces:
                if network_util.enabled_wan(intf):
                    if intf.get("v4ConfigType") != "DISABLED":
                        self.create_ifdown_default_route(
                            file,
                            intf.get("interfaceId"),
                            network_util.get_interface_name(settings, intf, "ipv4"),
                            "ip",
                        )

                    if intf.get("v6ConfigType") != "DISABLED":
                        self.create_ifdown_default_route(
                            file,
                            intf.get("interfaceId"),
                            network_util.get_interface_name(settings, intf, "ipv6"),
                            "ip6",
                        )

            file.write("}\n\n")

            for intf in interfaces:
                if network_util.enabled_wan(intf):
                    if intf.get("v4ConfigType") != "DISABLED":
                        self.create_ifdown_call_update_route(
                            file,
                            intf.get("interfaceId"),
                            network_util.get_interface_name(settings, intf, "ipv4"),
                            "ip",
                        )

                    if intf.get("v6ConfigType") != "DISABLED":
                        self.create_ifdown_call_update_route(
                            file,
                            intf.get("interfaceId"),
                            network_util.get_interface_name(settings, intf, "ipv6"),
                            "ip6",
                        )

            file.write('[ -z "$INTERFACE" ] && {\n')
            file.write("\tupdate_default_route\n")
            file.write("}\n\n")

        file.flush()
        file.close()
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(filename))

    def create_ifdown_default_route(self, file, interfaceId, interfaceName, tablefamily) -> None:
        """create_ifdown_default_route will create the default route rules for specific ip table families into a file"""
        file.write(f"\tnetwork_is_up {interfaceName} && {{\n")
        file.write("\t\tTMPFILE=`mktemp -t default-route.XXXXXX`\n")
        file.write("\t\techo flush chain ip wan-routing route-to-default-wan >> $TMPFILE\n")
        file.write("\t\techo flush chain ip6 wan-routing route-to-default-wan >> $TMPFILE\n")
        file.write(
            f"\t\techo add rule {tablefamily} wan-routing route-to-default-wan dict sessions ct id wan_policy long_string set system-default >> $TMPFILE\n"
        )
        file.write(
            "\t\techo add rule %s wan-routing route-to-default-wan jump mark-for-wan-%d >> $TMPFILE\n"
            % (tablefamily, interfaceId)
        )
        file.write("\t\twrite_rules\n")
        file.write("\t}\n\n")

    def create_ifdown_call_update_route(
        self, file, interfaceId, interfaceName, tablefamily
    ) -> None:
        """create_ifdown_call_update_route will write the rules that check the interface that called ifdown, and then call update_def_route if rules exist"""
        file.write(f'[ {interfaceName} = "$INTERFACE" ] && {{\n')
        file.write(
            "\tnft list chain %s wan-routing route-to-default-wan | grep -q mark-for-wan-%d && {\n"
            % (tablefamily, interfaceId)
        )
        file.write("\t\tupdate_default_route\n")
        file.write("\t}\n")
        file.write("}\n\n")

    def write_dhcp_user_file(self, settings, prefix="") -> None:
        """write_dhcp_user_file writes /etc/udhcpc.user"""
        filename = prefix + self.udhcpc_user_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        self.udhcpc_user_file = open(filename, "w+")
        file = self.udhcpc_user_file

        file.write("#!/bin/sh\n")
        file.write("\n\n")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("## $1 - DHCP event being passed in\n")
        file.write("## $interface - the device the event is attached to (IE: wwan0)\n")
        file.write("## $INTERFACE - the interface appended with IP Family (IE: LTE_4)\n")
        file.write("\n\n")
        file.write(". /lib/functions/network.sh\n")

        interfaces = settings.get("network").get("interfaces")
        for intf in interfaces:
            if network_util.enabled_wan(intf):
                if intf.get("type") == "WWAN":
                    # This fix adjusts the LTE WWAN route MTU to 1420 - which fixes routing from LTE devices to command center (VZW)
                    # After 21.xx we can probably remove this fix, and use a route MTU fix instead
                    # The issue is that adjusting the MTU directly on qmi_wwan driver devices crashes
                    # the driver - but setting MTU to something in the route does not break the same device
                    # we are doing this as a DHCP renew script because we can't guarantee the route is available
                    # during the ifup.d scripts
                    file.write("[ {} = $interface ] && {{ \n".format(intf.get("device")))
                    file.write(
                        "\techo applying MTU fix to device $interface | logger -t user-dhcp-script\n"
                    )
                    file.write("\t# Get the default route out of the WAN routing table\n")
                    file.write(
                        f"\tEXISTING_ROUTE=$(ip route show table wan.{intf.get('interfaceId')} | head -n 1)\n"
                    )
                    file.write(
                        f"\tip route replace table wan.{intf.get('interfaceId')} $EXISTING_ROUTE mtu 1420\n"
                    )
                    file.write("}\n\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))


if RouteManager.static_initialized is False:
    RouteManager.static_initialize()

registrar.register_manager(RouteManager())
