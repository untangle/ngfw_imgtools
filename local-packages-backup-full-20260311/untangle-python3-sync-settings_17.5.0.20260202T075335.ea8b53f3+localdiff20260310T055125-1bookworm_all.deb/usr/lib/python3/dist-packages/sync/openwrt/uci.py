import subprocess
from typing import NoReturn, Union

from sync.perms_util import regain_permissions


class UCI:
    """
    UCI is a simple interface to the uci command line tool.
    """

    def _handle_err(self, cmdline, proc) -> NoReturn:
        errtext = ""
        try:
            errtext = proc.stderr.read()
            errtext = errtext.decode()
            stdout_text = proc.stdout.read()
            stdout_value = stdout_text.decode()
            errtext += " stdout: " + stdout_value
        except Exception:
            errtext = "<unable to read errtext>"

        msg = f'uci: failed to run "{" ".join(cmdline)}", error text: {errtext}'
        raise RuntimeError(msg)

    def _write_path(self, path, value) -> None:
        command = ["/sbin/uci", "set", (".".join(path) + f"={value}")]
        proc = subprocess.Popen(command, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        result = proc.wait()

        if result != 0:
            self._handle_err(command, proc)

        command = ["/sbin/uci", "commit"]
        proc = subprocess.Popen(command, stderr=subprocess.PIPE, stdout=subprocess.PIPE)
        result = proc.wait()
        if result != 0:
            self._handle_err(command, proc)

    def write_path(self, path: list, value: Union[str, int]) -> None:
        """write_path writes value to path. This simply means we join the
        values of path together, quote value, and pass these to uci
        set.

        For an example write_path(['system', '@system[0]',
        'hostname'], 'mfw') results in these two calls:
        $ uci set system.@system[0].hostname='mfw'
        $ uci commit

        path -- list of path elements that would be separated by dots
        in uci show.

        value -- value to set. May be a string or number.

        returns -- None. We raise a RuntimeError if the command does
        not succeed.
        """
        with regain_permissions():
            self._write_path(path, value)
