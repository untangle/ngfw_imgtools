import sys

if getattr(sys, "os_name", "openwrt") == "openwrt":
    from . import system_manager

    # NOTE: network_manager makes settings modifications in its sync-settings (so not written back to settings like sanitize)
    #       that are used in subsequent manager calls so keeping this early in the import list is important.
    from . import network_manager
    from . import wireless_manager
    from . import interface_manager
    from . import dhcp_manager
    from . import nat_manager
    from . import accounts_manager
    from . import connectivity_manager
    from sync.common import reports_manager
    from . import qos_manager
    from . import route_manager
    from sync.common import application_control_manager
    from sync.common import stats_manager
    from sync.common import policy_manager
    from sync.openwrt import dos_manager

    # Table manager has dependencies on the above so it needs to be here.
    from . import table_manager

    from sync.common import dnsfilter_manager
    from . import ipsec_manager
    from . import lldp_manager
    from . import threat_prevention_manager
    from . import web_filter_manager
    from sync.common import geoip_manager

    from sync.common import discovery_manager
    from sync.common import uri_manager
    from . import bess_dpdk_manager
    from sync.common import captive_portal_manager
    from sync.common import webroot_manager
    from sync.common import bypass_manager

    from . import operations
    from . import dynamic_lists_manager
    from . import quota_manager
    from sync.common import databases_manager
    from sync.common import settings_manager
    from sync.openwrt import alerts_manager
    from . import uid_manager
