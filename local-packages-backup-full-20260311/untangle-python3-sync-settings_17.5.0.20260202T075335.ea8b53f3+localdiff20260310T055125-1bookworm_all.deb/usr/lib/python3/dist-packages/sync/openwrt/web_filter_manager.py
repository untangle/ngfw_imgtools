"""This class is responsible for managing web filter settings"""

import os
import stat

from sync import registrar
from sync.common import Logger
from sync.common.web_filter_manager import WebFilterManager

logger = Logger.getInstance()


class OpenWrtWebFilterManager(WebFilterManager):
    """WebFilterManager manages the web filter settings"""

    wf_rules_sys_filename = "/etc/config/nftables-rules.d/207-wf-rules"

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.wf_rules_sys_filename, "restart-nftables-rules", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")
        self.write_wf_net_rules(settings_file.settings, prefix)

    def write_wf_net_rules(self, settings, prefix) -> None:
        "write the tp rules file"
        filename = prefix + self.wf_rules_sys_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")
        file.write(r"""
nft flush chain inet filter web-filter-rules
nft delete set inet filter wf_block
nft add set inet filter wf_block "{ type ct_id; flags timeout; timeout 3m; gc-interval 10m; }"
nft add chain inet filter web-filter-rules "{ type filter hook prerouting priority 0; }"
nft add rule inet filter web-filter-rules ct id @wf_block ip protocol {icmp, udp} drop
""")

        interfaces = settings.get("network").get("interfaces")
        for interface in interfaces:
            if interface.get("type") == "NIC" and not interface.get("wan"):
                interface.get("v4StaticAddress")
                break

        file.write("nft add rule inet filter web-filter-rules ct id @wf_block counter drop\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(filename))


registrar.register_manager(OpenWrtWebFilterManager())
