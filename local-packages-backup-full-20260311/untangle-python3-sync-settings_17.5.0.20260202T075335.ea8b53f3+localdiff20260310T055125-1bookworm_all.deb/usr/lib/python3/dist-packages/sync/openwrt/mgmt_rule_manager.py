# Rule Managers
from sync.rule_manager import RuleManager, nftables_util


class MgmtRuleManager(RuleManager):
    """
    Used by interface manager to generate rules for managetment interfaces
    """

    settings_path = "firewall/tables/filter/chains/name=filter-rules/rules"
    ruleID_mgmt_access = "453a9ca3-b124-4561-b9e1-28cfaf95fe6f"
    ruleID_mgmt_net_access = "453a9ca4-b124-4561-b9e1-28cfaf95fe6f"

    block_lan_mgmt_traffic_template = {
        "description": "Block LAN clients from Management access",
        "enabled": True,
        "readOnly": True,
        "ruleId": ruleID_mgmt_access,
        "action": {"type": "DROP"},
        "conditions": [
            {
                "op": "==",
                "type": "SOURCE_INTERFACE_TYPE",
                "value": nftables_util.INTERFACE_TYPES["lan"],
            },
            {"op": "==", "type": "SERVER_ADDRESS", "value": "__MGMT_IP__"},
        ],
        "logs": [
            {
                "type": "NFLOG",
                "prefix": "{'type': 'R:filter:filter-rules', 'ruleId': '453a9ca3',  'action': 'DROP'}",
            }
        ],
    }

    block_mgmt_from_lan_traffic_template = {
        "description": "Block Management network access from LAN devices",
        "enabled": True,
        "readOnly": True,
        "ruleId": ruleID_mgmt_net_access,
        "action": {"type": "DROP"},
        "conditions": [
            {
                "op": "==",
                "type": "SOURCE_INTERFACE_TYPE",
                "value": nftables_util.INTERFACE_TYPES["lan"],
            },
            {
                "op": "==",
                "type": "DESTINATION_INTERFACE_TYPE",
                "value": nftables_util.INTERFACE_TYPES["management"],
            },
        ],
        "logs": [
            {
                "type": "NFLOG",
                "prefix": "{'type': 'R:filter:filter-rules', 'ruleId': '453a9ca4',  'action': 'DROP'}",
            }
        ],
    }

    def __init__(self) -> None:
        super().__init__()

    def check_create_mgmt_rule(self, settings_file, mgmt_ip) -> None:
        """
        Creates the management rule in the settings file
        First we remove the rule if it exists, then we add it.
        """

        deleteRule = []
        filterrules = settings_file.get_settings_by_path(self.settings_path)

        for rule in filterrules.copy():
            ruleid = rule.get("ruleId")
            if ruleid in (self.ruleID_mgmt_access, self.ruleID_mgmt_net_access):
                deleteRule.append(rule)

        for rule in deleteRule:
            filterrules.remove(rule)

        # Didn't find the rule, create it
        self.block_lan_mgmt_traffic_template["conditions"][1]["value"] = mgmt_ip
        filterrules.insert(0, self.block_mgmt_from_lan_traffic_template)
        filterrules.insert(0, self.block_lan_mgmt_traffic_template)
