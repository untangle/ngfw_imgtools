import collections
import copy
import ipaddress
import os
import stat
import textwrap
from uuid import uuid4

from sync import Manager, network_util, nftables_util, registrar
from sync.common import Logger
from sync.common.sanitizers.ipsec_sanitizer import IpsecSanitizer
from sync.openwrt.ipsec_wan_rule_manager import IpsecWanRuleManager
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class IpsecManager(Manager):
    """
    Manage Ipsec under OpenWrt
    """

    initalized = False
    #
    # OpenWrt Configuration
    #

    # Paths for files
    config_path = "/etc/config/"

    # OpenWrt configuration cannot have any interface named "ipsec" on its own as it will break nftables.
    # Prefix for all ipsec interfaces (and service).
    config_name_prefix = "ipsec_"

    #
    # MFW Settings
    #
    settings_access_rule_accept_rules = [
        {
            # AH/ESP protocol access rule
            "ruleId": "1953c304-94db-4a43-853a-a480a56b7b6d",
            "description": "Accept IPsec Authentication Header, Encap Security Payload (AH, ESP)",
            "action": {"type": "ACCEPT"},
            "conditions": [
                {
                    "type": "SOURCE_INTERFACE_TYPE",
                    "op": "==",
                    "value": nftables_util.INTERFACE_TYPES["wan"],
                },
                {"type": "IP_PROTOCOL", "op": "==", "value": "50,51"},
            ],
            "enabled": False,
            "readOnly": True,
            "log": False,
        },
        {
            # UDP/500 IKE access rule template
            "ruleId": "1953c74b-1cc4-4b1d-8895-21ddf662061f",
            "description": "Accept IPsec IKE (UDP/500)",
            "action": {"type": "ACCEPT"},
            "conditions": [
                {
                    "type": "SOURCE_INTERFACE_TYPE",
                    "op": "==",
                    "value": nftables_util.INTERFACE_TYPES["wan"],
                },
                {"type": "DESTINATION_PORT", "op": "==", "port_protocol": 17, "value": "500"},
            ],
            "enabled": False,
            "readOnly": True,
            "log": False,
        },
        {
            # UDP/4500 NAT-T access rule template
            "ruleId": "1953ce84-9dcd-48b6-a80c-b56543492d41",
            "description": "Accept IPsec NAT-T (UDP/4500)",
            "action": {"type": "ACCEPT"},
            "conditions": [
                {
                    "type": "SOURCE_INTERFACE_TYPE",
                    "op": "==",
                    "value": nftables_util.INTERFACE_TYPES["wan"],
                },
                {"type": "DESTINATION_PORT", "op": "==", "port_protocol": 17, "value": "4500"},
            ],
            "enabled": False,
            "readOnly": True,
            "log": False,
        },
    ]

    # Service template.
    settings_service_key = "ipsec"
    settings_service_template = {
        "enabled": False,
        "debug": 0,
        "keyexchange": "ikev2",
        "authentication": {"type": "shared_secret", "shared_secret": "shared_secret"},
        "local": {"gateway": "%any", "networks": [{"network": "0.0.0.0", "prefix": 0}]},
        "remote": {"gateway": "%any", "networks": [{"network": "172.16.6.0", "prefix": 24}]},
    }

    # Default cipher suite for tunnels
    settings_default_interface_crypto_proposals = [
        {"encryption": "aes256gcm128", "hash": "sha1", "group": "modp2048"}
    ]

    # Default cipher suite designed to connect wide range of other systems
    settings_default_service_crypto_proposals = [
        {"encryption": "3des", "hash": "sha1", "group": "modp2048"},
        {"encryption": "3des", "hash": "sha1", "group": "modp1536"},
        {"encryption": "3des", "hash": "sha1", "group": "modp1024"},
        {"encryption": "aes128", "hash": "sha1", "group": "modp2048"},
        {"encryption": "aes128", "hash": "sha1", "group": "modp1536"},
        {"encryption": "aes128", "hash": "sha1", "group": "modp1024"},
        {"encryption": "aes256", "hash": "sha1", "group": "modp2048"},
        {"encryption": "aes256", "hash": "sha1", "group": "modp1536"},
        {"encryption": "aes256", "hash": "sha1", "group": "modp1024"},
    ]

    # Any network configuration settings template
    any_network = {"network": "any", "prefix": 0}

    all_network = {"network": "0.0.0.0", "prefix": 0}

    dhcp_user_script = "/etc/udhcpc.user.d/100-sync-settings-for-dhcp-ipsec"

    @classmethod
    def static_init(cls) -> None:
        """
        Create static variables when class file is loaded.
        """
        IpsecManager.initialized = True
        IpsecManager.ipsec_config_filename = f"{IpsecManager.config_path}ipsec"
        IpsecManager.ipsec_nftables_filename = (
            f"{IpsecManager.config_path}nftables-rules.d/400-ipsec-rules"
        )

        # Make all proposals ordered dictionaries
        proposals = []
        for crypto_proposal in IpsecManager.settings_default_service_crypto_proposals:
            proposals.append(collections.OrderedDict(crypto_proposal))
        IpsecManager.settings_default_service_crypto_proposals = proposals

        proposals = []
        for crypto_proposal in IpsecManager.settings_default_interface_crypto_proposals:
            proposals.append(collections.OrderedDict(crypto_proposal))
        IpsecManager.settings_default_interface_crypto_proposals = proposals

        # Build service template
        IpsecManager.settings_service_template = collections.OrderedDict(
            IpsecManager.settings_service_template
        )
        IpsecManager.settings_service_template["phase1"] = copy.deepcopy(
            IpsecManager.settings_default_service_crypto_proposals
        )
        IpsecManager.settings_service_template["phase2"] = copy.deepcopy(
            IpsecManager.settings_default_service_crypto_proposals
        )

        # Make rules be ordered dictionaries
        rules = []
        for settings_access_rule_accept_rule in IpsecManager.settings_access_rule_accept_rules:
            rules.append(collections.OrderedDict(settings_access_rule_accept_rule))
        IpsecManager.settings_access_rule_accept_rules = rules

    def initialize(self) -> None:
        """
        Initialize
        """
        registrar.register_settings_file("settings", self)

        registrar.register_file(IpsecManager.ipsec_config_filename, "restart-ipsec", self)
        registrar.register_file(
            IpsecManager.ipsec_nftables_filename, "restart-nftables-rules", self
        )
        registrar.register_file(IpsecManager.ipsec_nftables_filename, "restart-networking", self)

        # Build rule managers
        self.rule_managers.append(IpsecWanRuleManager())

    def sanitize_settings(self, settings_file) -> None:
        """
        Manage MFW ipsec settings
        """
        # Load interfaces and services.
        # These are needed here and will be available in the object during sync_settings
        self.interfaces_settings = self.get_interfaces_settings(settings_file)
        self.service_settings = self.get_service_settings(settings_file)

        # Add IPsec access rules.
        # If found, replace with current value (in case the rules were modified).  Otherwise add to add list.
        access_rules = settings_file.get_settings_by_path(
            "firewall/tables/access/chains/name=access-rules/rules"
        )
        add_rules = []

        for rule_template in IpsecManager.settings_access_rule_accept_rules:
            rule = copy.deepcopy(rule_template)
            rule_id = rule.get("ruleId")
            rules = settings_file.find_settings_list(
                "firewall/tables/access/chains/name=access-rules/rules", {"ruleId": rule_id}
            )
            if len(rules) > 0:
                # Set to template value
                rules[0] = rule
            else:
                add_rules.append(rule)

        if len(add_rules) > 0:
            # Add rules to top of access list in reverse order (So AH/ESP is first)
            add_rules.reverse()
            for rule in add_rules:
                access_rules.insert(0, collections.OrderedDict(rule))

        # Add ipsec service if not found
        settingsService = settings_file.settings.get(IpsecManager.settings_service_key)
        if settingsService is None:
            settings_file.settings[IpsecManager.settings_service_key] = copy.deepcopy(
                IpsecManager.settings_service_template
            )
            self.service_settings = settings_file.settings[IpsecManager.settings_service_key]

        # Add default cipher suite to interfaces if not found.
        for interface in self.get_interfaces_settings(settings_file):
            phase1 = interface.get("ipsec").get("phase1")
            if phase1 is None:
                interface["ipsec"]["phase1"] = copy.deepcopy(
                    IpsecManager.settings_default_interface_crypto_proposals
                )
            phase2 = interface.get("ipsec").get("phase2")
            if phase2 is None:
                interface["ipsec"]["phase2"] = copy.deepcopy(
                    IpsecManager.settings_default_interface_crypto_proposals
                )

            # Encrypt pre-shared keys using common sanitizer
            IpsecSanitizer.sanitize_ipsec_interface(interface)

        # Enable or disable access rules.
        # NOTE: Must be done here since sanitize_settings is where settings are saved
        if len(self.interfaces_settings) > 0 or self.service_settings.get("enabled") is True:
            self.set_access_rules(settings_file, True)
        else:
            self.set_access_rules(settings_file, False)

        # check if we need to create or update any policies or rules
        # policies first since rules depend on them
        self.create_or_update_policies(settings_file)
        for rule_manager in self.get_rule_managers():
            rule_manager.create_or_update_rules(settings_file)

    def get_networks(self, subnet_side, intf):
        return [
            (net.get("network"), int(net.get("prefix")))
            for net in intf["ipsec"][subnet_side]["networks"]
        ]

    def is_interface_full_tunnel(self, intf):
        return ("0.0.0.0", 0) in self.get_networks("local", intf) or (
            "0.0.0.0",
            0,
        ) in self.get_networks("remote", intf)

    def find_tunnel_with_identical_subnet(self, subnet_side, intf):
        nets_set = set(self.get_networks(subnet_side, intf))
        for other_intf in self.interfaces_settings:
            if other_intf == intf:
                continue
            if nets_set & set(self.get_networks(subnet_side, other_intf)):
                return other_intf
        return None

    def create_or_update_policies(self, settings_file) -> None:
        """
        If this is a non-full tunnel, set this interface to always up
        so we don't send traffic destined for this subnet out to the public.
        """
        for interface_settings in self.get_interfaces_settings(settings_file, False):
            interface_id = interface_settings.get("interfaceId")
            policy = None

            # Match the specific_wan policy with this interfaceId - if it exists at least at this level, don't recreate
            wan_policies = settings_file.find_settings_list(
                "wan/policies",
                {"interfaces": {"interfaceId": interface_id}, "type": "SPECIFIC_WAN"},
            )
            if not wan_policies:
                policy = {
                    "interfaces": [{"interfaceId": interface_id}],
                    "type": "SPECIFIC_WAN",
                    "policyId": uuid4().__str__(),
                }
                policy["readOnly"] = True
                policy["criteria"] = self.get_criteria_for_interface(interface_settings)
                policy["description"] = "Send traffic to " + interface_settings["name"]
                settings_file.settings["wan"].get("policies").append(policy)

    # returns the `criteria` value a policy should have for a given interface
    def get_criteria_for_interface(self, interface_settings):
        if (
            self.is_interface_full_tunnel(interface_settings)
            or self.find_tunnel_with_identical_subnet("local", interface_settings)
            or self.find_tunnel_with_identical_subnet("remote", interface_settings)
        ):
            # The interface is full tunnel, and we do not want to
            # always_up a full tunnel, OR it has an identical
            # subnet to some other subnet, and we want failover
            # between subnets.
            #
            # These conditions are for MFW-2718.
            return []
        return [{"type": "ALWAYS_UP"}]

    def do_bound_ipsec_intfs_exist_with_dhcp(self, settings_file) -> bool:
        for intf in self.interfaces_settings:
            if intf.get("boundInterfaceId", 0) != 0 and intf.get("enabled"):
                intf_parent = network_util.get_interface_by_id(
                    settings_file.settings, intf["boundInterfaceId"]
                )

                if (
                    intf_parent.get("v4ConfigType") == "DHCP"
                    or intf_parent.get("v6ConfigType") == "DHCP"
                ):
                    return True

        return False

    def write_dhcp_listener(self, settings_file, prefix) -> None:
        path = os.path.normpath(prefix + "/" + self.dhcp_user_script)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            if self.do_bound_ipsec_intfs_exist_with_dhcp(settings_file):
                f.write(
                    textwrap.dedent(
                        """\
                    #!/bin/sh
                    # Automatically generated by sync-settings
                    # DO NOT EDIT
                    # This kicks sync-settings when DHCP changes.
                    # Currently needed so we can generate IPSEC
                    # binding rules for bound WANS.

                    # Getting and setting a trivial item will run
                    # sync-settings. This hack is necessary because:
                    # 1.) there is currently no way to just run
                    #     sync-settings from the REST api.
                    # 2.) We need to run sync-settings from the REST
                    #     api to avoid race conditions, for example if
                    #     the user happened to change config right
                    #     when we get a new lease.
                    version=$(curl -X GET http://localhost/api/settings/version -H 'Content-Type: application/json')
                    curl -X POST http://localhost/api/settings/version -H 'Content-Type: application/json'  -d "$version"
                    """
                    )
                )
        os.chmod(path, os.stat(path).st_mode | stat.S_IEXEC)

    def set_access_rules(self, settings_file, enabled) -> None:
        """
        Set enabled flag to true or false on access rules
        Set readOnly flag to true (For Upgrade Cases)
        """
        for rule_template in IpsecManager.settings_access_rule_accept_rules:
            rule_id = rule_template.get("ruleId")
            rule = settings_file.get_settings_by_path(
                f"firewall/tables/access/chains/name=access-rules/rules/ruleId={rule_id}"
            )
            if rule is not None:
                rule["readOnly"] = True
                rule["enabled"] = enabled

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """
        Sync settings
        """
        self.write_ipsec_config(settings_file, prefix)
        self.write_nftables_rules(settings_file, prefix)
        self.write_dhcp_listener(settings_file, prefix)

    def write_ipsec_config(self, settings_file, prefix) -> None:
        """
        Create Ipsec configuration
        The file /etc/config/ipsec format is:

        config ipsec
            list interface 'WAN04'
            ...

        config remote 'ipsec_set1'
            option enabled '1'
            ..

        config crypto_proposal 'ipsec_set1_phase1_3des_md5_modp2048'
            option encryption_algorithm '3des'
            ...

        config tunnel 'ipsec_set1_1'
            option local_subnet '192.168.251.0/24'
            ...

        config crypto_proposal 'ipsec_ipse_set1_phase2_3des_md5_modp2048'
            option encryption_algorithm '3des'

        The file is consumed by /etc/init.d/ipsec which generates the files under /var/ipsec.

        Each tunnel or service is a "set" which consists the following sections:
        -   Remote                      Single
        -   Phase 1 crypto proposals    Multiple
        -   Tunnels                     Multiple
        -   Phase 2 crypto proposals    Multiple

        The remote section needs named references to both 1) phase1 crypto proposal names and 2) tunnel names.
        Each tunnel section needs named references to 1) phase 2 crypto proposals

        For a lot of interfaces/services this can result in a lot of duplicate crypto proposals where
        the only difference is the name.  But it does seem to slow down processing from the ipsec script.
        """
        filename = prefix + IpsecManager.ipsec_config_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        service_enabled = self.service_settings.get("enabled")
        if len(self.interfaces_settings) > 0 or service_enabled is True:
            # At least one tunnel interface or the service is enabled.
            self.write_ipsec_config_ipsec_section(settings_file, prefix, file)

            for interface_settings in self.interfaces_settings:
                self.write_ipsec_config_ipsec_set(settings_file, prefix, file, interface_settings)

            if service_enabled is True:
                self.write_ipsec_config_ipsec_set(
                    settings_file, prefix, file, self.service_settings
                )

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))

    def write_ipsec_config_ipsec_section(self, settings_file, prefix, file) -> None:
        """
        Write ipsec section block
        """
        file.write("config ipsec" + "\n")

        listen_interfaces_settings = []
        if self.service_settings.get("enabled"):
            # Service is enabled; listen on all WAN interfaces
            for interface_type in ["NIC", "WIFI"]:
                interfaces_settings = settings_file.find_settings_list(
                    "network/interfaces",
                    {"wan": True, "enabled": True, "type": f"{interface_type}"},
                )
                for interface in interfaces_settings:
                    if interface not in listen_interfaces_settings:
                        listen_interfaces_settings.append(interface)
        else:
            # Just listen on bound WAN interfaces
            for interface in self.interfaces_settings:
                if interface.get("boundInterfaceId") == 0:
                    for interface_type in ["NIC", "WIFI"]:
                        interfaces_settings = settings_file.find_settings_list(
                            "network/interfaces",
                            {"wan": True, "enabled": True, "type": f"{interface_type}"},
                        )
                        for interface in interfaces_settings:
                            if interface not in listen_interfaces_settings:
                                listen_interfaces_settings.append(interface)
                else:
                    bound_interfaces = settings_file.find_settings_list(
                        "network/interfaces", {"interfaceId": interface.get("boundInterfaceId")}
                    )
                    for bound_interface in bound_interfaces:
                        if bound_interface not in listen_interfaces_settings:
                            listen_interfaces_settings.append(bound_interface)

        if len(listen_interfaces_settings) > 0:
            for listen_interface_settings in listen_interfaces_settings:
                name = listen_interface_settings.get("name")
                file.write(f" list interface '{name}4'" + "\n")
                file.write(f" list interface '{name}6'" + "\n")

        debug = self.service_settings.get("debug")
        if debug is not None and debug > 0:
            file.write(f" option debug '{debug}'" + "\n")

        # Don't install policy-based routes.
        file.write(" option rtinstall_enabled '0'" + "\n")

        file.write("\n")

    def write_ipsec_config_ipsec_set(self, settings_file, prefix, file, settings) -> None:
        """
        Write config sections for this set
        """
        if "ipsec" in settings:
            ipsec_settings = settings.get("ipsec")
            interface_settings = settings
            set_name = interface_settings.get("name")
        else:
            ipsec_settings = settings
            interface_settings = None
            set_name = "service"
        set_name = f"{IpsecManager.config_name_prefix}{set_name}"

        file.write(f"config remote '{set_name}'" + "\n")
        file.write(" option enabled '1'" + "\n")

        if interface_settings is not None:
            # Use same marks as on interface
            interface_id = interface_settings.get("interfaceId")
            file.write(f" option ikey '0x{interface_id:x}'" + "\n")
            file.write(f" option okey '0x{interface_id:x}00'" + "\n")

        if ipsec_settings.get("local") is not None:
            local_gateway = ipsec_settings.get("local").get("gateway")
            if local_gateway is not None:
                file.write(f" option local_gateway '{local_gateway}'" + "\n")

        if ipsec_settings.get("remote") is not None:
            remote_gateway = ipsec_settings.get("remote").get("gateway")
            if remote_gateway is not None:
                file.write(f" option gateway '{remote_gateway}'" + "\n")

        if ipsec_settings.get("authentication") is not None:
            type = ipsec_settings.get("authentication").get("type")
            method = "pubkey" if type == "certificate" else "psk"
            file.write(f" option authentication_method '{method}'" + "\n")

            if type == "shared_secret":
                # Decrypt the encrypted shared secret to get plain text for OpenWRT config.
                # The shared_secret is encrypted and stored as shared_secret_encrypted in settings.json.
                # Here, we decrypt it to use the plain text in the config file.
                auth_config = ipsec_settings.get("authentication", {})
                shared_secret = IpsecSanitizer.decrypt_shared_secret(auth_config, default="secret")
                file.write(f" option pre_shared_key '{shared_secret}'" + "\n")
            # elif type =="certificate":

        # Phase 1 crypto proposal references
        crypto_proposal_names = self.get_crypto_proposal_names(ipsec_settings, set_name, 1)
        for crypto_proposal_name in crypto_proposal_names:
            file.write(f" list crypto_proposal '{crypto_proposal_name}'" + "\n")

        # Tunnel references
        tunnel_names = self.get_tunnel_names(ipsec_settings, set_name)
        for tunnel_name in tunnel_names:
            file.write(f" list tunnel '{tunnel_name}'" + "\n")

        file.write("\n")

        ## Write phase 1 crypto proposals
        self.write_ipsec_config_ipsec_crypto_proposal(
            settings_file, prefix, file, settings, ipsec_settings, set_name, 1
        )

        ## Write tunnels
        self.write_ipsec_config_ipsec_tunnels(
            settings_file, prefix, file, settings, ipsec_settings, set_name
        )

        ## Write phase 2 crypto proposals
        self.write_ipsec_config_ipsec_crypto_proposal(
            settings_file, prefix, file, settings, ipsec_settings, set_name, 2
        )

        file.write("\n")

    def get_tunnel_names(self, ipsec_settings, set_name):
        """
        Get tunnel names
        Iterate local and remote networks and use count as tunnel name such as ipsec_name_1, ipsec_name_2,...
        """
        tunnel_names = []
        local_networks = ipsec_settings.get("local").get("networks")
        remote_networks = ipsec_settings.get("remote").get("networks")
        local_full_tunnel = self.contains_full_tunnel(local_networks)
        remote_full_tunnel = self.contains_full_tunnel(remote_networks)
        single_subnet_negotiation = ipsec_settings.get("singleSubnetNegotiation")
        if single_subnet_negotiation is None:
            single_subnet_negotiation = False

        network_count = 0
        for local_network in local_networks:
            if local_full_tunnel is True and local_network.get("network") != "0.0.0.0":
                continue
            for remote_network in remote_networks:
                if remote_full_tunnel is True and remote_network.get("network") != "0.0.0.0":
                    continue
                network_count += 1
                tunnel_names.append(f"{set_name}_{network_count}")
                if single_subnet_negotiation is True:
                    break

            if single_subnet_negotiation is True:
                break

        return tunnel_names

    def validate_settings(self, settings_file) -> None:
        """
        Validate local and remote network for ipsec settings
        """
        for ipsec_settings in self.get_interfaces_settings(settings_file):
            for local_network in ipsec_settings.get("ipsec").get("local").get("networks"):
                for remote_network in ipsec_settings.get("ipsec").get("remote").get("networks"):
                    if remote_network["network"] == local_network["network"]:
                        raise SettingsException(
                            message_str="Local and Remote network cannot be same {}".format(
                                remote_network["network"]
                            )
                        )

    def write_ipsec_config_ipsec_tunnels(
        self, settings_file, prefix, file, settings, ipsec_settings, set_name
    ) -> None:
        """
        Write tunnel sections for ipsec set
        """
        single_subnet_negotiation = ipsec_settings.get("singleSubnetNegotiation")
        if single_subnet_negotiation is None or single_subnet_negotiation is False:
            # Use individual tunnels
            local_networks = ipsec_settings.get("local").get("networks")
            if local_networks is None or len(local_networks) == 0:
                local_networks = [IpsecManager.any_network]

            remote_networks = ipsec_settings.get("remote").get("networks")
            if remote_networks is None or len(remote_networks) == 0:
                remote_networks = [IpsecManager.any_network]
        else:
            # Use single tunnel 0.0.0.0/0 for negotiation.
            local_networks = [IpsecManager.all_network]
            remote_networks = [IpsecManager.all_network]

        # All tunnels use same phase2 names
        crypto_proposal_names = self.get_crypto_proposal_names(ipsec_settings, set_name, 2)

        local_full_tunnel = self.contains_full_tunnel(local_networks)
        remote_full_tunnel = self.contains_full_tunnel(remote_networks)

        network_count = 0
        for local_network in local_networks:
            local_subnet = self.get_network_value(local_network)
            if local_full_tunnel is True and local_network.get("network") != "0.0.0.0":
                continue
            for remote_network in remote_networks:
                network_count += 1
                remote_subnet = self.get_network_value(remote_network)
                if remote_full_tunnel is True and remote_network.get("network") != "0.0.0.0":
                    continue
                tunnel_name = f"{set_name}_{network_count}"
                phase1_lifetime = ipsec_settings.get("phase1Lifetime")
                phase2_lifetime = ipsec_settings.get("phase2Lifetime")
                file.write(f"config tunnel '{tunnel_name}'" + "\n")
                file.write(" option mode 'start'" + "\n")
                file.write(f" option local_subnet '{local_subnet}'" + "\n")
                file.write(f" option remote_subnet '{remote_subnet}'" + "\n")
                file.write(f" option ikelifetime '{phase1_lifetime}'" + "\n")
                file.write(f" option lifetime '{phase2_lifetime}'" + "\n")
                file.write(" option dpdaction 'restart'" + "\n")
                for crypto_proposal_name in crypto_proposal_names:
                    file.write(f" list crypto_proposal '{crypto_proposal_name}'" + "\n")
                file.write("\n")

    def contains_full_tunnel(self, networks) -> bool:
        """
        Determine if network list contains a full tunnel.
        If so, return True, otherwise False.
        """
        for network in networks:
            if network.get("network") == "0.0.0.0" and network.get("prefix") == 0:
                return True
        return False

    def get_network_value(self, network_setting):
        """
        Create config network value which is usally a CIDR like "192.168.1.0/24".
        It can also be a value like '%any'.
        """
        if network_setting.get("network") == "any":
            value = "%any"
        else:
            network_address = network_setting.get("network")
            prefix = network_setting.get("prefix")
            value = f"{network_address}/{prefix}"

        return value

    def write_ipsec_config_ipsec_crypto_proposal(
        self, settings_file, prefix, file, settings, ipsec_settings, set_name, phase
    ) -> None:
        """
        Write phase configuration
        """
        phase_key = f"phase{phase}"
        crypto_proposals = ipsec_settings.get(phase_key)

        last_crypto_index = len(crypto_proposals) - 1
        for index, crypto_proposal in enumerate(crypto_proposals):
            phase_name = self.get_crypto_proposal_name(crypto_proposal, set_name, phase)
            file.write(f"config crypto_proposal '{phase_name}'" + "\n")

            encryption = crypto_proposal.get("encryption")
            file.write(f" option encryption_algorithm '{encryption}'" + "\n")

            algorithm = crypto_proposal.get("hash")
            file.write(f" option hash_algorithm '{algorithm}'" + "\n")

            group = crypto_proposal.get("group")
            strict_flag = "!" if index == last_crypto_index else ""
            file.write(f" option dh_group '{group}{strict_flag}'" + "\n")
            file.write("\n")

    def get_crypto_proposal_name(self, crypto_proposal, set_name, phase) -> str:
        """
        Determine crypto proposal name from settings
        """
        phase_key = f"phase{phase}"
        encryption = crypto_proposal.get("encryption")
        algorithm = crypto_proposal.get("hash")
        group = crypto_proposal.get("group")
        return f"{set_name}_{phase_key}_{encryption}_{algorithm}_{group}"

    def get_crypto_proposal_names(self, ipsec_settings, set_name, phase):
        """
        Based on settings phase values, determine phase names
        """
        phase_key = f"phase{phase}"
        crypto_proposals = ipsec_settings.get(phase_key)

        names = []
        for crypto_proposal in crypto_proposals:
            names.append(self.get_crypto_proposal_name(crypto_proposal, set_name, phase))

        return names

    def write_nftables_rules(self, settings_file, prefix) -> None:
        """
        Create nftables rules.

        Insert into nat postrouting rules to AVOID natting.

        IMPORTANT: We "should" be using ipsec expressions like:
        oif eth1 ipsec out reqid 1 accept
        However, the current version of OpenWrt (the kernel specifically. See https://serverfault.com/questions/971735/how-to-match-reqid-in-nftables) does not support these.
        In a future version we should revisit to clean up this code and do something more in like with the simpler iptables "--pol ipsec" expressions.
        """
        filename = prefix + IpsecManager.ipsec_nftables_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/usr/bin/nft_debug -f" + "\n")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")

        service_enabled = self.service_settings.get("enabled")
        if len(self.interfaces_settings) > 0 or service_enabled is True:
            for interface_settings in self.interfaces_settings:
                self.write_nftables_rules_nat(settings_file, file, interface_settings)

            if service_enabled is True:
                self.write_nftables_rules_nat(settings_file, file, self.service_settings)

        file.flush()
        file.close()
        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)

        logger.info("Wrote %s", str(filename))

    def write_nftables_rules_nat(self, settings_file, file, settings) -> None:
        """
        Insert postrouting nat rules to avoid natting.
        """
        if "ipsec" in settings:
            ipsec_settings = settings.get("ipsec")
            interface_settings = settings
        else:
            ipsec_settings = settings
            interface_settings = None

        if interface_settings is not None and interface_settings.get("natEgress") is False:
            return

        # Collect all interfaces and remote networks
        for remote_network in ipsec_settings.get("remote").get("networks"):
            if remote_network.get("network") == "any":
                continue

            # Determine IP type
            ip_network = ipaddress.ip_address(remote_network.get("network"))
            if isinstance(ip_network, ipaddress.IPv4Address):
                ip_target = "ip"
            elif isinstance(ip_network, ipaddress.IPv6Address):
                ip_target = "ip6"
            else:
                continue

            network = self.get_network_value(remote_network)
            if network == "0.0.0.0/0":
                # Do not add for full tunnel.
                continue

            if interface_settings is None:
                file.write(
                    f"insert rule {ip_target} nat-sys postrouting-nat ip daddr {network} accept\n"
                )
            else:
                netfilter_device = interface_settings.get("netfilterDev")
                file.write(
                    f"insert rule {ip_target} nat-sys postrouting-nat oifname {netfilter_device} ip daddr {network} accept"
                    "\n"
                )

    def get_interfaces_settings(self, settings_file, enabled_check=True):
        """
        Return enabled ipsec interfaces.

        We generally want all enabled interfaces, but for wan rule management, we need to
        preserve oder so with this flag set to false, we'll get disabled interfaces so
        the rules won't go away.
        """
        interfaces_settings = []
        interfaces = settings_file.get_settings_by_path("network/interfaces")
        for interface in interfaces:
            if interface.get("type") != "IPSEC":
                continue
            if enabled_check is False or interface.get("enabled") is True:
                interfaces_settings.append(interface)
        return interfaces_settings

    def get_service_settings(self, settings_file):
        """
        Return configuration for remote service.
        """
        return settings_file.get_settings_by_path("ipsec")

    def get_interface_remote_gateway_network(self, settings_file, interface_settings):
        """
        Build remote gateway network for non-dynamic remote gateways.
        @param settings_file reference.
        @param interface_settings of ipsec interface
        returns OrderedDict of network infromation.
        """
        network = None
        local_gateway_address = interface_settings.get("ipsec").get("local").get("gateway")
        remote_gateway_address = interface_settings.get("ipsec").get("remote").get("gateway")
        if remote_gateway_address == "%any":
            # Ignore dynamic connections
            return network

        address_version = network_util.get_ip_address_version(remote_gateway_address)
        if address_version is None:
            # Otherwise unparsable address
            return network

        bound_interface_index = 0
        if interface_settings.get("boundInterfaceId") == 0:
            # Any WAN, get any enabled WAN type to get first.
            bound_interfaces = settings_file.find_settings_list(
                "network/interfaces", {"wan": True, "enabled": True}
            )
            if len(bound_interfaces) == 0:
                # No bound interfaces found
                return network

            # Match our left side.  May not be the first interface.
            for index, bound_interface in enumerate(bound_interfaces):
                if bound_interface.get("v4StaticAddress") == local_gateway_address:
                    bound_interface_index = index
                    break
        else:
            # Get explicitly bound interface
            bound_interfaces = settings_file.find_settings_list(
                "network/interfaces", {"interfaceId": interface_settings.get("boundInterfaceId")}
            )
            if len(bound_interfaces) == 0:
                # No bound interfaces found
                return network

        bound_interface = bound_interfaces[bound_interface_index]

        return collections.OrderedDict(
            {
                "bound_interface": bound_interface.get("logical_name"),
                "bound_interface_id": bound_interface.get("interfaceId"),
                "network": remote_gateway_address,
                "netmask": "255.255.255.255",
                "prefix": 32,
                "version": address_version,
            }
        )

    def get_interface_networks(self, settings_file, interface_settings):
        """
        For the specified interface, walk ipsec remote networks and collect information for rule and routes
        """
        networks = []

        static4_interfaces_settings = settings_file.find_settings_list(
            "network/interfaces", {"enabled": True, "v4ConfigType": "STATIC"}
        )
        static6_interfaces_settings = settings_file.find_settings_list(
            "network/interfaces", {"enabled": True, "v6ConfigType": "STATIC"}
        )
        source_address = {4: None, 6: None}

        # Detemine local source IP address to route remote networks through
        # Walk locally define networks and look for static IP addresses defined on enabled interfaces.
        for local_network in interface_settings.get("ipsec").get("local").get("networks"):
            local_network_address = local_network.get("network")
            local_network_prefix = local_network.get("prefix")

            address_version = network_util.get_ip_address_version(
                f"{local_network_address}/{local_network_prefix}"
            )
            if address_version is None:
                # Otherwise unparsable network
                continue

            if address_version == 4:
                interfaces_settings = static4_interfaces_settings
            elif address_version == 6:
                interfaces_settings = static6_interfaces_settings
            else:
                # Unknown version
                continue

            if source_address[address_version] is None:
                for local_interface_settings in interfaces_settings:
                    interface_address = local_interface_settings.get(
                        f"v{address_version}StaticAddress"
                    )
                    interface_prefix = local_interface_settings.get(
                        f"v{address_version}StaticPrefix"
                    )
                    interface_ip_interface = ipaddress.ip_interface(
                        f"{interface_address}/{interface_prefix}"
                    )
                    local_ip_compare_interface = ipaddress.ip_interface(
                        f"{local_network_address}/{interface_prefix}"
                    )
                    if (
                        interface_ip_interface.network.network_address
                        == local_ip_compare_interface.network.network_address
                    ):
                        # Local network and interface network match so use this IP address for this family.
                        source_address[address_version] = interface_address

        for address_version in source_address:
            # Fill in with our first best LAN addresses.
            # The "source" address is not neccessary for proper routing but we use it in split mode
            # to make sure outgoing traffic is coming from a tunnel-routable address.
            # HOWEVER if you switch between full tunnel (which doesn't need it) and split, then
            # the new route with the source will never be added without a network restart.
            # This is some kind of openwrt networking issue.
            if source_address[address_version] is None:
                if address_version == 4:
                    interfaces_settings = static4_interfaces_settings
                elif address_version == 6:
                    interfaces_settings = static6_interfaces_settings
                else:
                    # Unknown version
                    continue

                for local_interface_settings in interfaces_settings:
                    if (
                        local_interface_settings.get("wan", False)
                        and local_interface_settings.get("configType") == "ADDRESSED"
                    ):
                        source_address[address_version] = local_interface_settings.get(
                            f"v{address_version}StaticAddress"
                        )

        # Build network list from remote networks
        remote_networks = interface_settings.get("ipsec").get("remote").get("networks")
        if interface_settings.get("ipsec").get("singleSubnetNegotiation") is True:
            # We're negotiating with 0.0.0.0/0 so make sure we have default if not already there.
            for remote_network in remote_networks:
                if (
                    remote_network.get("network") == "0.0.0.0"
                    and remote_network.get("prefix") == 0
                ):
                    # Already have default so let it be added via processing remote networks.
                    break
            else:
                # Default is not not in remote networks
                remote_networks.append(
                    collections.OrderedDict({"network": "0.0.0.0", "prefix": 0})
                )

        for remote_network in remote_networks:
            remote_network_address = remote_network.get("network")
            remote_network_prefix = remote_network.get("prefix")

            try:
                remote_ip_interface = ipaddress.ip_interface(
                    f"{remote_network_address}/{remote_network_prefix}"
                )
            except:
                ## Unable to parse network
                continue

            address_version = network_util.get_ip_address_version(
                f"{remote_network_address}/{remote_network_prefix}"
            )
            if address_version is None:
                # Otherwise unparsable address
                continue

            network = {
                "version": address_version,
                "source_address": source_address[address_version],
                "network": str(remote_ip_interface.network.network_address),
                "netmask": str(remote_ip_interface.network.netmask),
                "prefix": remote_network_prefix,
            }

            networks.append(collections.OrderedDict(network))

        return networks

    def get_full_tunnel_interfaces(self, settings_file):
        """
        Return interface ids of any full tunnel interfaces, left or right.
        """
        interfaces = []
        for interface_settings in self.get_interfaces_settings(settings_file):
            for local_network in interface_settings.get("ipsec").get("local").get("networks"):
                if local_network.get("network") == "0.0.0.0" and local_network.get("prefix") == 0:
                    interfaces.append(interface_settings.get("interfaceId"))

        return interfaces


if IpsecManager.initalized is False:
    IpsecManager.static_init()

registrar.register_manager(IpsecManager())
