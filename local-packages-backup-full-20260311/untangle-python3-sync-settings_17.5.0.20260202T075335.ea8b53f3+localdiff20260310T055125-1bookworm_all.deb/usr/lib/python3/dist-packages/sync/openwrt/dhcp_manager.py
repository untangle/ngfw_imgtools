"""dhcp_manager manages dhcp & dnsmasq settings"""

import ipaddress
import os

from sync import Manager, network_util, registrar
from sync.common import Logger
from sync.openwrt.creators.dhcp_creator import DHCPCreator
from sync.openwrt.sanitizers.dhcp_sanitizer import DHCPSanitizer
from sync.openwrt.validators.dhcp_validator import DHCPValidator

logger = Logger.getInstance()


class DhcpManager(Manager):
    """
    This class is responsible for writing /etc/config/dhcp
    based on the settings object passed from sync-settings
    """

    dhcp_filename = "/etc/config/dhcp"
    dnsmasq_dns_server_template = "\tlist server '{dns_resolver_address}@{device}'\n"

    def __init__(self) -> None:
        super().__init__(DHCPCreator(), DHCPValidator(), DHCPSanitizer())

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.dhcp_filename, "restart-dhcp", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Syncing settings")
        self.write_dhcp_file(settings_file.settings, prefix)

    def write_dhcp_file(self, settings, prefix="") -> None:
        """writes prefix/etc/config/dhcp"""
        filename = prefix + self.dhcp_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        system = settings.get("system")
        dns = settings.get("dns")
        dhcp = settings.get("dhcp")

        file = open(filename, "w+")
        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n")
        file.write("config dnsmasq\n")

        interfaces = settings["network"]["interfaces"]

        ## Only enable dns reserver for static Ethernet or PPPoE interfaces,
        ## if those interfaces are enabled.
        for intf in interfaces:
            if (
                intf.get("enabled") is True
                and intf.get("configType") == "ADDRESSED"
                and intf.get("wan") is True
                and intf.get("v4ConfigType") == "STATIC"
            ):
                if intf.get("v4StaticDNS1") is not None:
                    file.write(
                        DhcpManager.dnsmasq_dns_server_template.format(
                            dns_resolver_address=intf.get("v4StaticDNS1"),
                            device=intf.get("device"),
                        )
                    )
                if intf.get("v4StaticDNS2") is not None:
                    file.write(
                        DhcpManager.dnsmasq_dns_server_template.format(
                            dns_resolver_address=intf.get("v4StaticDNS2"),
                            device=intf.get("device"),
                        )
                    )

            if (
                intf.get("enabled") is True
                and intf.get("configType") == "ADDRESSED"
                and intf.get("wan") is True
                and intf.get("v4ConfigType") == "PPPOE"
                and intf.get("v4PPPoEUsePeerDNS") is False
            ):
                if intf.get("v4PPPoEDNS1") is not None:
                    file.write(
                        DhcpManager.dnsmasq_dns_server_template.format(
                            dns_resolver_address=intf.get("v4PPPoEDNS1"),
                            device=intf.get("device"),
                        )
                    )
                if intf.get("v4PPPoEDNS2") is not None:
                    file.write(
                        DhcpManager.dnsmasq_dns_server_template.format(
                            dns_resolver_address=intf.get("v4PPPoEDNS2"),
                            device=intf.get("device"),
                        )
                    )

        if dns.get("localServers") is not None:
            for local_server in dns.get("localServers"):
                local_str = "\tlist server '"
                # allow a local_server without a domain (can't be done through the UI)
                if local_server.get("domain"):
                    local_str += "/{}/".format(local_server.get("domain"))
                local_str += "{}'\n".format(local_server.get("localServer"))
                file.write(local_str)

        if system.get("domainName") is not None:
            file.write("\toption domain '{}'\n".format(system.get("domainName")))

        file.write("\toption expandhosts '1'\n")
        file.write("\toption nonegcache '0'\n")
        if dhcp.get("dhcpAuthoritative") is True:
            file.write("\toption authoritative '1'\n")
        else:
            file.write("\toption authoritative '0'\n")

        file.write("\tlist interface '*'\n")
        file.write("\toption localise_queries '1'\n")
        file.write("\toption nohosts '1'\n")
        file.write("\toption domainneeded '0'\n")
        file.write("\toption boguspriv '0'\n")
        file.write("\toption filterwin2k '0'\n")
        file.write("\toption readethers '0'\n")
        file.write("\toption rebind_protection '0'\n")
        file.write("\toption rebind_localhost '0'\n")
        file.write("\toption nonwildcard '0'\n")
        file.write("\toption localservice '0'\n")
        file.write("\toption dhcpleasemax '5000'\n")
        file.write("\toption dnsforwardmax '512'\n")
        file.write("\toption leasefile '/tmp/dhcp.leases'\n")
        # comment out using /tmp/hosts.untangle until it's populated
        file.write("\t#list addnhosts '/tmp/hosts.untangle'\n")

        file.write("\n")

        dhcpv6_in_use = False

        # If relay is enabled on a WAN intf. then we need to adjust LAN intf config appropriately
        dhcpv6_relay_enabled = False
        for intf in interfaces:
            if intf.get("v6RelayEnabled"):
                dhcpv6_relay_enabled = True

        for intf in interfaces:
            if intf.get("enabled") is True and (
                intf.get("configType") == "ADDRESSED" or intf.get("type") == "BRIDGE"
            ):
                interface_name = network_util.get_interface_name(settings, intf, "ipv4")
                if intf.get("dhcpRelayEnabled") is False:
                    if intf.get("type") == "BRIDGE":
                        brname = "b_" + interface_name
                        file.write(f"config dhcp '{brname}'\n")
                    else:
                        file.write(f"config dhcp '{interface_name}'\n")
                    if intf.get("dhcpEnabled") is True:
                        write_dhcp4_server_options(file, intf, interface_name)

                        if intf.get("v6ConfigType") != "DISABLED":
                            dhcpv6_in_use = True
                            if dhcpv6_relay_enabled:
                                write_dhcp6_relay_options(file, intf.get("wan"))
                            else:
                                file.write("\toption dhcpv6 'server'\n")
                                file.write("\toption ra 'server'\n")

                        file.write("\n")
                if intf.get("dhcpRelayEnabled") is True:
                    if intf.get("v4ConfigType") != "DISABLED":
                        file.write(f"config relay '{interface_name}'\n")
                        file.write(
                            "\toption local_addr '{}'\n".format(intf.get("v4StaticAddress"))
                        )
                        file.write(
                            "\toption server_addr '{}'\n".format(intf.get("dhcpRelayAddress"))
                        )
                        file.write("\n")
                if intf.get("dhcpEnabled") is False and intf.get("dhcpRelayEnabled") is False:
                    file.write(f"\toption interface '{interface_name}'\n")
                    # Only add relay options to interfaces that have IPv6 enabled, or if they are a WAN with relay enabled
                    if (
                        intf.get("wan") is False
                        and intf.get("v6ConfigType") is not None
                        and intf.get("v6ConfigType") != "DISABLED"
                        and dhcpv6_relay_enabled
                    ) or intf.get("v6RelayEnabled"):
                        write_dhcp6_relay_options(file, intf.get("wan"))
                    else:
                        file.write("\toption ignore '1'\n")
                    file.write("\n")

        if dhcpv6_in_use is True:
            file.write("config odhcpd 'odhcpd'\n")
            file.write("\toption maindhcp '0'\n")
            file.write("\toption leasefile '/tmp/hosts/odhcpd'\n")
            file.write("\toption leasetrigger '/usr/sbin/odhcpd-update'\n")
            file.write("\toption loglevel '4'\n")
            file.write("\n")

        if dns.get("staticEntries") is not None:
            for entry in dns.get("staticEntries"):
                if entry.get("name") is not None and entry.get("address") is not None:
                    file.write("config 'domain'\n")
                    file.write("\toption name '{}'\n".format(entry.get("name")))
                    file.write("\toption ip '{}'\n".format(entry.get("address")))
                    file.write("\n")

        if dhcp.get("staticDhcpEntries") is not None:
            for entry in dhcp.get("staticDhcpEntries"):
                if entry.get("macAddress") is not None and entry.get("address") is not None:
                    file.write("config 'host'\n")
                    file.write("\toption ip '{}'\n".format(entry.get("address")))
                    file.write("\toption mac '{}'\n".format(entry.get("macAddress")))
                    file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s", str(filename))


def write_dhcp4_server_options(file, intf, interface_name) -> None:
    if intf.get("v4ConfigType") != "DISABLED":
        if intf.get("type") == "BRIDGE":
            brname = "b_" + interface_name
            file.write(f"\toption interface '{brname}'\n")
        else:
            file.write(f"\toption interface '{interface_name}'\n")
        file.write("\toption force 1\n")
        file.write(
            "\toption start '%d'\n"
            % calc_dhcp_range_start(
                intf.get("v4StaticAddress"),
                intf.get("v4StaticPrefix"),
                intf.get("dhcpRangeStart"),
            )
        )
        file.write(
            "\toption limit '%d'\n"
            % calc_dhcp_range_limit(intf.get("dhcpRangeStart"), intf.get("dhcpRangeEnd"))
        )

        if intf.get("dhcpLeaseDuration") is not None and intf.get("dhcpLeaseDuration") != 0:
            file.write("\toption leasetime '%d'\n" % intf.get("dhcpLeaseDuration"))
        else:
            file.write("\toption leasetime '3600'\n")

        if (
            intf.get("dhcpGatewayOverride") is not None
            and intf.get("dhcpGatewayOverride") != ""
            and intf.get("dhcpGatewayOverride") != 0
        ):
            file.write("\tlist dhcp_option '3,{}'\n".format(intf.get("dhcpGatewayOverride")))
        else:
            file.write("\tlist dhcp_option '3,{}'\n".format(intf.get("v4StaticAddress")))

        if (
            intf.get("dhcpPrefixOverride") is not None
            and intf.get("dhcpPrefixOverride") != ""
            and intf.get("dhcpPrefixOverride") != 0
        ):
            file.write(
                "\tlist dhcp_option '1,{}'\n".format(
                    network_util.ipv4_prefix_to_netmask(intf.get("dhcpPrefixOverride"))
                )
            )
        else:
            file.write(
                "\tlist dhcp_option '1,{}'\n".format(
                    network_util.ipv4_prefix_to_netmask(intf.get("v4StaticPrefix"))
                )
            )

        if intf.get("dhcpDNSOverride") is not None and intf.get("dhcpDNSOverride") != "":
            dns_servers = intf.get("dhcpDNSOverride")
        else:
            dns_servers = intf.get("v4StaticAddress")

        file.write(f"\tlist dhcp_option '6,{dns_servers}'\n")

        if intf.get("dhcpOptions") is not None:
            for dhcp_option in intf.get("dhcpOptions"):
                if dhcp_option.get("enabled") is None or not dhcp_option.get("enabled"):
                    continue
                file.write("\tlist dhcp_option '{}'\n".format(dhcp_option.get("value")))


def write_dhcp6_relay_options(file, isWan) -> None:
    file.write("\toption dhcpv6 'relay'\n")
    file.write("\toption ra 'relay'\n")
    file.write("\toption ndp 'relay'\n")
    if isWan:
        file.write("\toption master '1'\n")


def calc_dhcp_range_start(ip, prefix, start):
    """calucale a good dhcp range start"""
    ip_int = int(ipaddress.IPv4Address(ip))
    netmask_int = int(ipaddress.IPv4Address(network_util.ipv4_prefix_to_netmask(prefix)))
    start_int = int(ipaddress.IPv4Address(start))
    return start_int - (ip_int & netmask_int)


def calc_dhcp_range_limit(start, end):
    """calucale a good dhcp range limit"""
    start_int = int(ipaddress.IPv4Address(start))
    end_int = int(ipaddress.IPv4Address(end))
    return end_int - start_int + 1


registrar.register_manager(DhcpManager())
