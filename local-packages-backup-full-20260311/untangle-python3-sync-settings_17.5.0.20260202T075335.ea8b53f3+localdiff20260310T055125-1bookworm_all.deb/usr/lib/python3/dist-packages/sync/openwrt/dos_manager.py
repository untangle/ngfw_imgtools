# Copyright (c) 2023 Arista Networks, Inc.  All rights reserved.
# Arista Networks, Inc. Confidential and Proprietary.


"""This class is responsible for managing dos filter settings"""

import json
import os
import subprocess
import sys

from sync import registrar
from sync.common import Logger
from sync.common.dos_manager import DENIAL_OF_SERVICE, DosManager
from sync.perms_util import regain_permissions

DELETE_ACTIVE_SESSIONS_SETTINGS_PATH = "/tmp/dos/active_session"
LIMIT_VALUES_SETTINGS_PATH = "/tmp/dos/dos_settings"

logger = Logger.getInstance()


class OpenWrtDosManager(DosManager):
    """OpenWrtDosManager manages the dos settings for mfw on openwrt platform"""

    def __init__(self) -> None:
        # TODO: MFW-5806: Check if these files can be stored under /var/ or something without changing the behavior for the nft dos rules that get created between reboots.
        self.delete_active_sessions_settings_path = DELETE_ACTIVE_SESSIONS_SETTINGS_PATH
        self.limit_values_settings_path = LIMIT_VALUES_SETTINGS_PATH
        self.previous_delete_active_sessions, self.previous_limit_values = (
            self.load_current_settings_values()
        )

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(
            self.delete_active_sessions_settings_path, "sync-dos-active-session", self
        )
        registrar.register_file(self.limit_values_settings_path, "sync-dos-limit-values", self)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""
        logger.info("Sync settings")

        # Irrespective of whether dos settings are enabled or disabled,
        # Always check whether the dos limit values have been updated and does the limit values file need a new write again.
        self.write_limit_values_settings(settings_file, prefix)
        if not self.manage_dos_settings_files(settings_file, prefix):
            return

        self.write_active_sessions_settings(settings_file, prefix)

    def delete_dos_config_file(self, file_path) -> None:
        """It regains the permissions and deletes the configuration files"""
        try:
            with regain_permissions():
                os.unlink(file_path)
        except Exception:
            logger.exception("Failed to delete dos configuration file:")

    def manage_dos_settings_files(self, settings_file, prefix) -> bool:
        """check whether dos is enabled. if no, unregister and unlink `delete_active_sessions_file`"""
        delete_active_sessions_filename = prefix + self.delete_active_sessions_settings_path

        is_dos_enabled = settings_file.settings.get(DENIAL_OF_SERVICE, {}).get("enabled")

        # If dos settings are not enabled, delete the settings and
        # unregister any operations related to dos

        # We don't unregister the limit values file, as we always want to run the restart dos nftable operation.
        # Whenever dos_settings are disabled, tableManager would just remove this table
        # and not create it again during the sync_settings flow. So do not unregister limit values file.
        if not is_dos_enabled:
            # Case OpenWrt - if DOS disabled unregister files and delete dos related settings file
            if getattr(sys, "os_name", "openwrt") == "openwrt":
                registrar.unregister_file(delete_active_sessions_filename)
                registrar.unregister_file(self.delete_active_sessions_settings_path + "*")

                if os.path.exists(self.delete_active_sessions_settings_path):
                    self.delete_dos_config_file(self.delete_active_sessions_settings_path)

                return False
            # TODO: MFW-5881 Handle EOS related cases here if DOS is disable
        return True

    def write_active_sessions_settings(self, settings_file, prefix) -> None:
        """Handles the 'remove_active_sessions' setting."""
        current_delete_active_sessions = settings_file.settings[DENIAL_OF_SERVICE].get(
            "remove_active_sessions"
        )

        # Check if the value has changed
        if self.previous_delete_active_sessions != current_delete_active_sessions:
            self.write_file(
                (prefix + self.delete_active_sessions_settings_path),
                json.dumps(
                    {
                        "remove_active_sessions": settings_file.settings[DENIAL_OF_SERVICE][
                            "remove_active_sessions"
                        ]
                    }
                ).encode("utf-8"),
            )

        # Store the current value for future comparisons
        self.previous_delete_active_sessions = current_delete_active_sessions

    def write_limit_values_settings(self, settings_file, prefix) -> None:
        """writes the settings to specified filepath"""

        # Get the current limit values (excluding 'remove_active_sessions')
        current_limit_values = {
            k: v
            for k, v in settings_file.settings[DENIAL_OF_SERVICE].items()
            if k != "remove_active_sessions"
        }

        dos_settings = settings_file.settings.get(DENIAL_OF_SERVICE, {}).get("enabled")
        result = subprocess.run(
            ["nft", "list", "table", "ip", "dos"], shell=True, capture_output=True, check=False
        )
        if (
            dos_settings
            and result.returncode != 0
            and os.path.exists(self.limit_values_settings_path)
        ):
            self.delete_dos_config_file(self.limit_values_settings_path)

        self.write_file(
            prefix + self.limit_values_settings_path,
            json.dumps(current_limit_values).encode("utf-8"),
        )

        self.previous_limit_values = current_limit_values

    def write_file(self, filename, data) -> None:
        """writes data to specified file"""
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        with open(filename, "wb+") as file:
            file.write(data)

        logger.info("dosManager: Wrote %s", str(filename))

    def load_current_settings_values(self):
        """Loads the current settings values from the respective files."""
        current_values = {"remove_active_sessions": None, "limit_values": {}}

        # Load remove_active_sessions value
        try:
            with open(self.delete_active_sessions_settings_path, encoding="utf-8") as file:
                data = json.load(file)
                current_values["remove_active_sessions"] = data.get("remove_active_sessions")
        except (FileNotFoundError, json.JSONDecodeError):
            pass  # Keep the default value if file not found or invalid

        # Load limit values
        try:
            with open(self.limit_values_settings_path, encoding="utf-8") as file:
                data = json.load(file)
                current_values["limit_values"] = dict(data.items())
        except (FileNotFoundError, json.JSONDecodeError):
            pass  # Keep it as an empty dict if file not found or invalid

        return current_values["remove_active_sessions"], current_values["limit_values"]


registrar.register_manager(OpenWrtDosManager())
