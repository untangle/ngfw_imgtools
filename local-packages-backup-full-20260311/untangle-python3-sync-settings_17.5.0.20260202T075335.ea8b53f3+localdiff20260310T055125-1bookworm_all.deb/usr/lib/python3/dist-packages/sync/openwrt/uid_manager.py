"""
OpenWRT UID Manager - Platform-specific implementation for OpenWRT.

Manages the UID file at /etc/config/uid for OpenWRT platforms.
"""

from sync import registrar
from sync.common.uid_manager import UIDManager


class OpenWRTUIDManager(UIDManager):
    """
    OpenWRT-specific UID Manager implementation.

    Stores the UID file at /etc/config/uid
    """

    def get_config_dir(self) -> str:
        """
        Get the OpenWRT-specific configuration directory for the UID file.

        Returns:
            str: "/etc/config" - the OpenWRT configuration directory
        """
        return "/etc/config"


registrar.register_manager(OpenWRTUIDManager())
