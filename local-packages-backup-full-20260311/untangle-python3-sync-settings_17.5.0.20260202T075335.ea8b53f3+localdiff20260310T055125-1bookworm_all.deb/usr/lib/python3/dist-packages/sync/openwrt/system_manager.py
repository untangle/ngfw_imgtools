"""This class is responsible for writing the system settings."""

import os
import random
import socket
import stat
import sys

from sync import board_util, registrar
from sync.board_util import BoardUtil
from sync.common import Logger
from sync.common.system_manager import CommonSystemManager
from sync.openwrt.uci import UCI
from sync.settings_exception import SettingsException

logger = Logger.getInstance()


class SystemManager(CommonSystemManager):
    """SystemManager manages the system settings."""

    timezone_setter_filename = "/etc/config/setup.d/010-timezone"
    watchdog_disabler_filename = "/etc/config/startup.d/030-disable-watchdog"
    rpfilter_disabler_filename = "/etc/config/startup.d/040-disable-rpfilter"
    hostname_setter_filename = "/etc/config/startup.d/050-hostname"
    reload_system_filename = "/etc/config/zzz-reload-system"
    nic_setter_filename = "/etc/config/startup.d/060-nic-settings"
    sysctl_conntrack_lim_filename = "/etc/sysctl.d/90-eos-nf-conntrack.conf"
    nic_intr_setter_filename = "/etc/config/ifup.d/20-nic-intr-settings"
    dpdk_filename = "/etc/config/startup.d/050-dpdk-bindings"
    bess_filename = "/etc/config/bess/bindings.bess"
    cron_filename = "/etc/crontabs/root"
    system_logging_setter_filename = "/etc/config/setup.d/070-system-logging"

    def initialize(self) -> None:
        """Initialize this module."""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.timezone_setter_filename, "setup-scripts", self)
        registrar.register_file(self.watchdog_disabler_filename, "startup-scripts", self)
        registrar.register_file(self.rpfilter_disabler_filename, "startup-scripts", self)
        registrar.register_file(self.sysctl_conntrack_lim_filename, "run-sysctl", self)
        registrar.register_file(self.hostname_setter_filename, "startup-scripts", self)
        registrar.register_file(self.reload_system_filename, "startup-scripts", self)
        registrar.register_file(self.system_logging_setter_filename, "system-scripts", self)
        registrar.register_file(self.cron_filename, "restart-cron", self)
        registrar.register_file(self.nic_setter_filename, "restart-nic-setting", self)
        registrar.register_file(self.nic_intr_setter_filename, "restart-nic-intr-setting", self)
        registrar.register_file(self.dpdk_filename, "restart-dpdk", self)
        registrar.register_file(self.bess_filename, "restart-dpdk", self)

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        super().create_settings(settings_file, prefix, delete_list, filename)
        if board_util.is_docker():
            settings_file.settings["system"]["setupWizard"] = {"completed": True}

    def create_logging_settings(self, platform_os_is_EOS=False):
        if platform_os_is_EOS:
            return {
                "type": "circular",
                "size": 64,
                "remote": True,
                "ip": "127.0.0.1",
                "port": 514,
                "protocol": "tcp",
            }

        return {"type": "circular", "size": 64, "remote": False}

    def write_system_logging_setter(self, prefix, settings_system_logging) -> None:
        """Write the script to set system logging and restart system
        service."""
        if not settings_system_logging:
            return

        filename = prefix + self.system_logging_setter_filename

        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(
            "uci set system.@system[0].log_size='{}'\n".format(settings_system_logging["size"])
        )
        file.write(
            "uci set system.@system[0].log_type='{}'\n".format(settings_system_logging["type"])
        )

        if settings_system_logging["remote"]:
            file.write(
                "uci set system.@system[0].log_ip='{}'\n".format(settings_system_logging["ip"])
            )
            file.write(
                "uci set system.@system[0].log_port='{}'\n".format(settings_system_logging["port"])
            )
            file.write(
                "uci set system.@system[0].log_proto='{}'\n".format(
                    settings_system_logging["protocol"]
                )
            )
        else:
            # Remote is set as false, Clean existing entries(If any)
            # for log_ip, log_port and log_proto
            file.write("uci -q delete system.@system[0].log_ip\n")
            file.write("uci -q delete system.@system[0].log_port\n")
            file.write("uci -q delete system.@system[0].log_proto\n")

        if settings_system_logging.get("file", False):
            file.write(
                "uci set system.@system[0].log_file='{}'\n".format(settings_system_logging["file"])
            )

        if settings_system_logging.get("prefix", False):
            file.write(
                "uci set system.@system[0].log_prefix='{}'\n".format(
                    settings_system_logging["prefix"]
                )
            )

        file.write("uci commit system\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def check_port(self, port) -> bool:
        """Checks whether a port is already being used by some other process or
        not.

        Returns zero if the port is already in use.
        """
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            # MFW-3040 has code that redirects these to the current port to support
            # upgrades. So we can't check.
            if port in ("80", "443"):
                return True
            inuse = s.connect_ex(("127.0.0.1", int(port)))
            return inuse != 0

    def validate_settings(self, settings_file) -> None:
        """Validate system settings."""
        system_settings = settings_file.settings.get("system")

        if not self.check_port(system_settings["httpPort"]):
            raise SettingsException(
                message="port_is_already_in_use", vars=[system_settings["httpPort"]]
            )
        if not self.check_port(system_settings["httpsPort"]):
            raise SettingsException(
                message="port_is_already_in_use", vars=[system_settings["httpsPort"]]
            )

        if system_settings.get("logging", False):
            # Validate Required keys in settings_file.system.logging
            required_system_logging_keys = ["type", "remote", "size"]
            missing_keys = [
                key
                for key in required_system_logging_keys
                if key not in system_settings["logging"]
            ]
            if missing_keys:
                raise SettingsException(
                    message="system_logging_missing_required_keys", vars=[missing_keys]
                )

            if system_settings["logging"]["type"] not in ["circular", "file"]:
                raise SettingsException(
                    message="system_logging_invalid_type",
                    vars=[system_settings["logging"]["type"]],
                )

            if not (
                isinstance(system_settings["logging"]["size"], int)
                and system_settings["logging"]["size"] >= 0
            ):
                raise SettingsException(
                    message="system_logging_invalid_size",
                    vars=[system_settings["logging"]["size"]],
                )

            if system_settings["logging"]["remote"]:
                required_system_logging_remote_keys = ["ip", "port", "protocol"]
                missing_keys = [
                    key
                    for key in required_system_logging_remote_keys
                    if key not in system_settings["logging"]
                ]
                if missing_keys:
                    raise SettingsException(
                        message="system_logging_missing_required_keys", vars=[missing_keys]
                    )

                if not (
                    isinstance(system_settings["logging"]["port"], int)
                    and system_settings["logging"]["port"] > 0
                ):
                    raise SettingsException(
                        message="system_logging_invalid_port_number",
                        vars=[system_settings["logging"]["port"]],
                    )

                if system_settings["logging"]["protocol"] not in ["tcp", "udp"]:
                    raise SettingsException(
                        message="system_logging_invalid_protocol",
                        vars=[system_settings["logging"]["protocol"]],
                    )

    def sanitize_settings(self, settings_file) -> None:
        """Sanitize system settings."""
        super().sanitize_settings(settings_file)
        self.sanitize_auto_settings(settings_file, "autoUpgrade")
        self.sanitize_auto_settings(settings_file, "autoBackup")
        self.sanitize_auto_settings(settings_file, "logging")

    def set_time_zone(self, settings_file, prefix) -> None:
        time_zone = settings_file.settings.get("system", {}).get("timeZone")
        if not time_zone:
            return

        # If the timezone is just a string, use that
        # In old settings.json, time_zone was just a string
        if isinstance(time_zone, str):
            self.write_timezone_setter(time_zone, prefix)
        elif isinstance(time_zone, dict):
            time_zone_value = time_zone.get("value")
            if time_zone_value is not None:
                self.write_timezone_setter(time_zone_value, prefix)

    def set_host_name(self, settings_file, prefix) -> None:
        hostname = settings_file.settings.get("system", {}).get("hostName", {})
        if hostname:
            self.write_hostname_setter(hostname, prefix)

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """Syncs settings."""
        super().sync_settings(settings_file, prefix, delete_list)

        if board_util.is_docker():
            self.write_watchdog_disabler(prefix)
            self.write_rpfilter_disabler(prefix)

        self.write_conntrack_lim_setter(prefix)

        self.require_console_password()

        self.write_cron_file(settings_file.settings, prefix)

        self.write_system_reloader(prefix)

        network = settings_file.settings.get("network")
        self.write_nic_setter(network["interfaces"], prefix)

        self.write_system_logging_setter(
            prefix, settings_file.settings["system"].get("logging", False)
        )

    def require_console_password(self) -> None:
        """Require the user to use a password on the console by settings
        system.@system[0].enabled='1' in UCI."""
        try:
            uci = UCI()
            uci.write_path(["system", "@system[0]", "ttylogin"], 1)
            logger.info("wrote ttylogin.")
        except Exception:
            logger.exception("unable to set ttylogin, caught exception:")

    def sanitize_auto_settings(self, settings_file, setting) -> None:
        system_settings = settings_file.settings.get("system")
        if system_settings is None:
            raise SettingsException(message="api_missing_system_settings")

        # Sanitize system logging
        if setting == "logging":
            if not system_settings.get("logging", False):
                settings_file.settings["system"]["logging"] = self.create_logging_settings(
                    BoardUtil.is_platform_os_eos()
                )
            return

        # Sanitize settings
        auto_settings = system_settings.get(setting)
        if setting not in settings_file.settings["system"]:
            settings_file.settings["system"][setting] = {
                "dayOfWeek": -1,  # -1 is every day for autobackup or a random day for auto upgrade
                "hourOfDay": -1,  # randomized hour between 6 am and 12 am
                "minuteOfHour": -1,  # randomized hour between 6 am and 12 am
                "enabled": True,
            }
        elif auto_settings is not None and auto_settings.get("enabled") is None:
            auto_settings["enabled"] = True
            settings_file.settings["system"][setting] = auto_settings

        # set auto backup randomized time if necessary
        auto = settings_file.settings["system"][setting]

        if auto["hourOfDay"] == -1:
            auto["hourOfDay"] = random.randint(0, 5)
        if auto["minuteOfHour"] == -1:
            auto["minuteOfHour"] = random.randint(0, 59)
            if setting == "autoUpgrade":
                auto["minuteOfHour"] = int(5 * round(auto["minuteOfHour"] / 5))
        if setting == "autoUpgrade" and auto["dayOfWeek"] == -1:
            auto["dayOfWeek"] = random.randint(0, 6)

        settings_file.settings["system"][setting] = auto

    def write_hostname_setter(self, hostname, prefix) -> None:
        """Write the script to set the hostname in /etc/config/system."""
        filename = prefix + self.hostname_setter_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(f"uci set system.@system[0].hostname='{hostname}'\n")
        file.write("uci commit system")
        file.write("\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_cron_file(self, settings, prefix) -> None:
        """Write the cron file."""
        filename = prefix + self.cron_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")

        if os.path.getsize(filename) == 0:
            file.write("SHELL=/bin/sh")
            file.write("\n\n")

        autoupgrade_enabled, autoupgrade_str = self.create_auto_text(
            settings, "autoUpgrade", "/usr/bin/upgrade.sh"
        )
        if autoupgrade_enabled:
            file.write(autoupgrade_str)

        autobackup_enabled, autobackup_str = self.create_auto_text(
            settings, "autoBackup", "/usr/bin/upload-backup.sh"
        )
        if autobackup_enabled:
            file.write(autobackup_str)

        # Add in CMD cron entries
        if os.path.exists("/etc/config/cron"):
            with open("/etc/config/cron") as f:
                file.writelines(f)
            f.close()

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def create_auto_text(self, settings, setting, executable):
        """Determine if auto upgrade/backup is enabled, if it is return the
        cron string for upgrading/backing up."""
        auto_enabled = True
        upgrade_cron_string = ""
        day = 6
        hour = 0
        minute = 0
        auto_settings = settings.get("system").get(setting)
        if auto_settings is None:
            auto_enabled = False
        else:
            if auto_settings.get("enabled") is None or auto_settings.get("enabled") is False:
                auto_enabled = False
            if auto_settings.get("dayOfWeek") is not None:
                day = auto_settings.get("dayOfWeek")
                if setting == "autoBackup" and day == -1:
                    day = "*"
            if auto_settings.get("hourOfDay") is not None:
                hour = auto_settings.get("hourOfDay")
            if auto_settings.get("minuteOfHour") is not None:
                minute = auto_settings.get("minuteOfHour")

        if auto_enabled:
            upgrade_cron_string = "%i %i * * %s %s >/dev/null 2>&1\n" % (
                minute,
                hour,
                str(day),
                executable,
            )

        return auto_enabled, upgrade_cron_string

    def write_timezone_setter(self, time_zone, prefix) -> None:
        """Write the script to set the timezone in /etc/config/system."""
        filename = prefix + self.timezone_setter_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(f"uci set system.@system[0].timezone='{time_zone}'\n")
        file.write("uci commit system")
        file.write("\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_watchdog_disabler(self, prefix) -> None:
        """Write the script to disable watchdog in docker containers."""
        filename = prefix + self.watchdog_disabler_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write('ubus call system watchdog \'{"magicclose": true,"stop": true}\'\n')
        file.write("\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_rpfilter_disabler(self, prefix) -> None:
        """Write the script to disable rpfilter in docker containers."""
        filename = prefix + self.rpfilter_disabler_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write("find /proc/sys/net/ipv4/conf/*/rp_filter | while read conf ; do\n")
        file.write("\techo 0 > $conf\n")
        file.write("done\n")
        file.write("\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_system_reloader(self, prefix) -> None:
        """Write the script to reload system service."""
        filename = prefix + self.reload_system_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write("/etc/init.d/system reload\n")
        file.write("/etc/init.d/log reload\n")
        file.write("\n")

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    def write_nic_setter(self, interfaces, prefix) -> None:
        """Write the NIC speed/duplex and autoneg settings.

        :param interfaces: list of interface objects
        :param prefix: filename prefix
        """
        filename = prefix + self.nic_setter_filename
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/bin/sh")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        for intf in interfaces:
            if "ethAutoneg" in intf and "ethSpeed" in intf and "ethDuplex" in intf:
                autoneg = "on" if intf["ethAutoneg"] else "off"
                if autoneg == "off":
                    file.write(
                        "/usr/sbin/ethtool -s {} speed {} duplex {} autoneg {}\n".format(
                            intf["device"], intf["ethSpeed"], intf["ethDuplex"], autoneg
                        )
                    )
                else:
                    file.write(
                        "/usr/sbin/ethtool -s {} autoneg {}\n".format(intf["device"], autoneg)
                    )
            if intf["type"] == "NIC":
                # Attempt to unconditionally disable energy efficient Ethernet
                # which can be problematic in certain environments and can result
                # in preventing critical operations like WAN link negotiation
                file.write(
                    f"/usr/sbin/ethtool --show-eee {intf['device']} 2>/dev/null && /usr/sbin/ethtool --set-eee {intf['device']} eee off\n"
                )

        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)
        logger.info("Wrote %s", str(filename))

    @staticmethod
    def calculate_conntrack_limits(physical_mem_size: int):
        """Calculate the suggested conntrack limit.

        formula is CONNTRACK_MAX = RAMSIZE (in bytes) / 16384 / (x / 32)
        where x is the number of bits in a pointer (for example, 32 or
        64 bits) HASHSIZE = CONNTRACK_MAX / 8
        """
        is_64bits = sys.maxsize > 2**32
        pointer_size = 64

        if not is_64bits:
            pointer_size = 32

        magic_number = 16384

        conntrack_max = int(physical_mem_size / magic_number / (pointer_size / 32))
        conntrack_bucket = int(conntrack_max / 8)
        return [conntrack_max, conntrack_bucket]

    def write_conntrack_lim_setter(self, prefix) -> None:
        """Write the conntrack limits."""

        max_physical_mem = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")

        con_max, con_buck = self.calculate_conntrack_limits(max_physical_mem)
        filename = prefix + self.sysctl_conntrack_lim_filename

        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+", encoding="ascii")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(f"net.netfilter.nf_conntrack_max={con_max}")
        file.write("\n")
        file.write(f"net.netfilter.nf_conntrack_buckets={con_buck}")
        file.write("\n")

        file.flush()
        file.close()

        logger.info("Wrote %s to %s", str(con_max), str(self.sysctl_conntrack_lim_filename))


registrar.register_manager(SystemManager())
