import contextlib
import copy
import json
import os
import re
import stat
import subprocess
from collections import OrderedDict
from typing import Any
from uuid import uuid4

from sync import Manager, board_util, nftables_util, registrar
from sync.board_util import BoardUtil
from sync.common import Logger, captive_portal_manager
from sync.common.nft_types import Action, AddToSet, Condition, Log, Rule, RuleChain, Set, Table
from sync.common.table_manager import (
    default_filter_rules_table,
    default_nat_rules_table,
)
from sync.file_util import FileUtil
from sync.interface_util import INTERFACE_CONDITIONS, sanitize_interface_name_conditions
from sync.perms_util import regain_permissions
from sync.settings_exception import SettingsException
from sync.settings_file import SettingsFile

CAPTIVE_PORTAL_CT_MARK = "0x20000000"
SHAPING_PRIORITY_MASK = "0X001F0000"

logger = Logger.getInstance()


class TableManager(Manager):
    """TableManager manages the all the firewall tables"""

    dos_filename_prefix = FileUtil.locate_file("/etc/config/dos/nft-rules")
    filename_prefix = FileUtil.locate_file("/etc/config/nftables-rules.d/2")
    access_filename_prefix = FileUtil.locate_file("/etc/config/nftables-rules.d/200-access")

    wireguard_access_rule_template = {
        "action": {"type": "ACCEPT"},
        "conditions": [
            {"type": "SOURCE_INTERFACE_ZONE", "op": "=="},
            {"type": "DESTINATION_PORT", "port_protocol": "17", "op": "=="},
        ],
        "enabled": True,
        "log": False,
    }

    blockPageRuleId = uuid4().__str__()
    defaultCaptivePortalRuleId = uuid4().__str__()

    defaultCaptivePortalrules = {
        "8487": {
            "enabled": False,
            "description": "Accept HTTP 8487 captive portal on LANs (TCP/8487)",
            "ruleId": defaultCaptivePortalRuleId,
            "conditions": [
                {"type": "DESTINATION_PORT", "op": "==", "value": "8487", "port_protocol": 6},
                {
                    "type": "SOURCE_INTERFACE_TYPE",
                    "op": "==",
                    "value": nftables_util.INTERFACE_TYPES["lan"],
                },
            ],
            "action": {"type": "ACCEPT"},
            "logs": [],
            "log": False,
        },
        "8488": {
            "enabled": False,
            "description": "Accept HTTPS 8488 captive portal on LANs (TCP/8488)",
            "ruleId": defaultCaptivePortalRuleId,
            "conditions": [
                {"type": "DESTINATION_PORT", "op": "==", "value": "8488", "port_protocol": 6},
                {
                    "type": "SOURCE_INTERFACE_TYPE",
                    "op": "==",
                    "value": nftables_util.INTERFACE_TYPES["lan"],
                },
            ],
            "action": {"type": "ACCEPT"},
            "logs": [],
            "log": False,
        },
    }

    wireguard_description_template = "Allow WireGuard tunnel to {name}[{id}]"
    wireguard_description_template_regex = None

    dict_int_value_types = ["SERVER_PORT", "CLIENT_PORT", "LOCAL_PORT", "REMOTE_PORT"]
    dict_value_int_re = re.compile("^([0-9-, ]+)$")

    def initialize(self) -> None:
        """initialize this module"""
        registrar.register_settings_file("settings", self)
        registrar.register_file(self.filename_prefix + ".*", "restart-nftables-rules", self)
        registrar.register_file(self.access_filename_prefix, "restart-restd-access", self)

        # Update WireGuard defaults
        self.wireguard_access_rule_template["description"] = re.search(
            r"^([^{]+)", self.wireguard_description_template
        ).group(1)
        # Escape brackets for WireGuard description searches.
        self.wireguard_description_template_regex = self.wireguard_description_template.translate(
            str.maketrans(
                {
                    "[": r"\[",
                    "]": r"\]",
                }
            )
        )

    def strip_settings(self, rules):
        """removes settings which are not to be matched"""
        for rule in rules:
            rule.pop("ruleId")
            rule.pop("enabled")
            rule.pop("description")
            if "logs" in rule:
                rule.pop("logs")
        return rules

    def delete_nft_table(self, addr_family, table_name) -> None:
        """Deletes the specified nft table"""
        list_command = "nft list tables | grep " + table_name
        list_result = subprocess.run(list_command, shell=True, check=False)

        if list_result.returncode == 0:
            delete_command = "nft delete table " + addr_family + " " + table_name
            delete_result = subprocess.run(delete_command, shell=True, check=False)
            if delete_result.returncode == 0:
                logger.info("Table %s %s deleted successfully.", str(addr_family), str(table_name))
        else:
            logger.info("Table %s does not exist", str(table_name))

    def is_limit_rate_rule(self, rule):
        """
        We consider a rule as limit rate rule in following scenarios:
        action.type == "LIMIT_EXCEED_ACTION"
        OR
        action.type == "SET_PRIORITY" and one of the conditions is for LIMIT_RATE.
        Return True if any of the above 2 conditions meet.
        """
        action = rule.get("action", {})
        action_type = action.get("type", "")
        limit_rate_in_conditions = False
        if action_type == "LIMIT_EXCEED_ACTION":
            limit_rate_in_conditions = True
        elif action_type == "SET_PRIORITY":
            for condition in rule["conditions"]:
                if condition.get("type") == "LIMIT_RATE":
                    limit_rate_in_conditions = True
                    break
        return limit_rate_in_conditions

    def sanitize_settings_shaping(self, settings_file) -> None:
        """
        Sanitizes shaping rules. It moves all limit rate shaping rules to the limiting-rules chain.
        """
        if "shaping" not in settings_file.settings["firewall"]["tables"]:
            settings_file.settings["firewall"]["tables"]["shaping"] = default_shaping_rules_table()
        # Iterate shaping table's prioritization-rules chain's rules and identify any limit rate
        # rules that are there and add them to the limiting-rules chain in the same sequence as this.
        prioritization_rules = settings_file.settings["firewall"]["tables"]["shaping"]["chains"][
            1
        ]["rules"]
        limiting_rules = settings_file.settings["firewall"]["tables"]["shaping"]["chains"][2][
            "rules"
        ]
        index = 0
        while index < len(prioritization_rules):
            rule = prioritization_rules[index]
            if self.is_limit_rate_rule(rule):
                # This is a limit rate rule, so add it to the limiting-rules chain,
                limiting_rules.append(rule)
                # Also, remove it from the prioritization-rules chain.
                prioritization_rules.pop(index)
                continue
            index += 1

    def sanitize_settings_captive_portal(self, access_rules, settings_file):
        """sanitizes captive portal settings"""

        enabled = captive_portal_manager.do_captive_portal_settings_exist(settings_file.settings)
        if enabled:
            logger.info("Enabling captive portal rules")
        else:
            logger.info("Disabling captive portal rules")

        self.delete_nft_table("ip", "captive-portal")
        self.delete_nft_table("ip6", "captive-portal")

        if "captive-portal" in settings_file.settings["firewall"]["tables"]:
            del settings_file.settings["firewall"]["tables"]["captive-portal"]

        # Update access rules table for captive portal ports
        expected_rules = copy.deepcopy(list(self.defaultCaptivePortalrules.values()))
        expected_rules = self.strip_settings(expected_rules)
        current_rules = []
        update_rules = []
        for rule in access_rules:
            conditions = rule.get("conditions", [])
            for condition in conditions:
                if condition["type"] == "DESTINATION_PORT" and (
                    condition["value"] == "8487" or condition["value"] == "8488"
                ):
                    current_rule = copy.deepcopy(rule)
                    current_rules.extend(self.strip_settings([current_rule]))
                    update_rules.append(rule)
        if json.dumps(current_rules, sort_keys=True) == json.dumps(expected_rules, sort_keys=True):
            for rule in update_rules:
                rule["enabled"] = enabled
        else:
            temp_list = []
            # Initialize an empty list to store the values for "DESTINATION_PORT"
            destination_ports = []

            # Iterate through the access list
            for entry in access_rules:
                # Iterate through the conditions list of each access item
                for condition in entry.get("conditions", []):
                    # Check if the condition type is "DESTINATION_PORT" and only target the ports for 8487 and 8488
                    if condition.get("type") == "DESTINATION_PORT" and (
                        condition.get("value") == "8487" or condition.get("value") == "8488"
                    ):
                        # Add the value to the destination_ports list
                        destination_ports.append(condition.get("value"))

            # Iterate through the default Captive Portal rules to check if all default rules are still present on the access_rules list
            for d in self.defaultCaptivePortalrules:
                if d not in destination_ports:
                    temp_list.append(self.defaultCaptivePortalrules[d])
            # Push the default rules which are not present on access_rules list
            if len(temp_list) > 0:
                access_rules[-1:-1] = temp_list
        return access_rules

    def sanitize_settings_dos(self, settings_file: dict[str, Any]) -> dict[str, Any]:
        """sanitizes dos settings"""
        # sanitize_settings of dos_manager would always add 'denial_of_service' key
        # with its default settings at least, if 'denial_of_service' key was not present.
        dos_settings = settings_file.settings.get("denial_of_service", {})

        dos_rules = settings_file.settings["firewall"]["tables"].get("dos", {})

        # default_dos_rules_table will generate DOS `config`, `rules` and `sets`
        dos_rules = default_dos_rules_table(settings_file)
        if dos_settings.get("enabled"):
            logger.info("Enabling Denial of service rules")
        else:
            logger.info("Disabling Denial of service rules")
            # delete nft dos table
            self.delete_nft_table("ip", "dos")
        return dos_rules

    def sanitize_settings(self, settings_file: dict[str, Any]) -> None:
        """sanitizes settings"""

        # Walk interfaces looking for new or modified WireGuard interfaces.
        access_rules = settings_file.get_settings_by_path(
            "firewall/tables/access/chains/name=access-rules/rules"
        )
        # Add web admin port access rules if required
        access_rules = sanitize_settings_web_admin_ports(settings_file)

        interfaces = settings_file.settings.get("network").get("interfaces")
        wireguard_delete_rules = []
        for interface in interfaces:
            rule = None
            add_rule = False
            if interface.get("type") == "WIREGUARD" and interface.get("wireguardType") == "TUNNEL":
                if interface.get("new") is not None:
                    # Build new rule from template.
                    rule = copy.deepcopy(self.wireguard_access_rule_template)
                    add_rule = True
                else:
                    # Look for existing rule.
                    find_rule = copy.deepcopy(self.wireguard_access_rule_template)
                    # Only value that can't change is interfaceId in descripton
                    find_rule["description"] = self.wireguard_description_template.format(
                        name=".*", id=interface.get("interfaceId")
                    )
                    rules = settings_file.find_settings_list(access_rules, find_rule)
                    if len(rules) == 0:
                        # Could be coming from roaming
                        rule = copy.deepcopy(self.wireguard_access_rule_template)
                        add_rule = True
                    else:
                        # Delete all matching rules except first; we will modify it.
                        wireguard_delete_rules = rules
                        rule = wireguard_delete_rules.pop(0)

                if rule is not None:
                    ## Populate rule from interface.
                    rule["description"] = self.wireguard_description_template.format(
                        name=interface.get("name"), id=interface.get("interfaceId")
                    )
                    for condition in rule.get("conditions"):
                        if condition.get("type") == "SOURCE_INTERFACE_ZONE":
                            condition["value"] = interface.get("boundInterfaceId")
                        elif condition.get("type") == "DESTINATION_PORT":
                            condition["value"] = interface.get("wireguardPort")

                    if add_rule is True:
                        access_rules.insert(0, rule)

        # Look for rules to delete
        find_delete_rule = copy.deepcopy(self.wireguard_access_rule_template)
        wg_access_rules = settings_file.find_settings_list(access_rules, find_delete_rule)
        if len(wg_access_rules) > 0:
            wg_description_re = re.compile(
                self.wireguard_description_template_regex.format(name=".*", id=r"(\d+)")
            )
            for rule in wg_access_rules:
                matches = wg_description_re.match(rule.get("description"))
                if matches is not None and matches.lastindex > 0:
                    interface_found = False
                    interface_id = int(matches.group(1))
                    for interface in interfaces:
                        if interface.get("interfaceId") == interface_id:
                            interface_found = True
                            if (
                                interface.get("type") == "WIREGUARD"
                                and interface.get("wireguardType") == "ROAMING"
                            ):
                                # Found rule but we're now ROAMING.
                                wireguard_delete_rules.append(rule)

                    if interface_found is False:
                        # Interface not found.
                        wireguard_delete_rules.append(rule)

            for rule in wireguard_delete_rules:
                access_rules.remove(rule)

        # Enable/Disable captive portal rules
        access_rules = self.sanitize_settings_captive_portal(access_rules, settings_file)
        # Enable/Disable dos settings
        settings_file.settings["firewall"]["tables"]["dos"] = self.sanitize_settings_dos(
            settings_file
        )

        if settings_file.settings.get("version") <= 4:
            # Move all limit rate shaping rules from the prioritization-rules chain to the limiting-rules chain
            self.sanitize_settings_shaping(settings_file)

        # Set the rule_id to unique values of every chain
        # Disable rules that don't match valid dict value expressions
        for table in ["filter", "port-forward", "nat", "access", "shaping", "dos"]:
            for chain in settings_file.settings["firewall"]["tables"][table]["chains"]:
                # Use MFW version to add logged field with default False to the filter and access rules for upgrades to 6.1
                if table in ["filter", "access"] and settings_file.settings["version"] <= 4:
                    for rule in chain.get("rules"):
                        rule["log"] = False
                nftables_util.verify_guid(chain.get("rules"), "ruleId", relatedChains=None)
                nftables_util.clean_rule_actions(chain, chain.get("rules"), table)

                # Version check, use MFW version for the version bump
                if settings_file.settings["version"] < 3:
                    nftables_util.fix_MFW_1082_rules(table, chain.get("rules"))
                    nftables_util.fix_port_proto_rules(chain.get("rules"))

                for rule in chain.get("rules"):
                    if rule.get("conditions"):
                        for condition in rule.get("conditions"):
                            type = condition.get("type")
                            val = condition.get("value")
                            if type in INTERFACE_CONDITIONS:
                                # Change into <source_or_dest>_interface_zone == <interface _id> condition
                                condition = sanitize_interface_name_conditions(
                                    settings_file, condition
                                )
                            if type in TableManager.dict_int_value_types:
                                matches = TableManager.dict_value_int_re.match(
                                    condition.get("value")
                                )
                                if matches is None:
                                    rule["enabled"] = False
                if table == "access" and settings_file.settings["version"] <= 5:
                    chain["rules"] = [
                        rule
                        for rule in chain.get("rules")
                        if not any(
                            cond.get("value") == "8485" or cond.get("value") == "8486"
                            for cond in rule["conditions"]
                        )
                    ]

    def validate_settings(self, settings_file) -> None:
        """
        Validates table settings
        """
        errors = []
        # Generally this failure will occur when a user is attempting to add a single rule.
        for table in ["filter", "port-forward", "nat", "access", "shaping"]:
            for chain in settings_file.settings["firewall"]["tables"][table]["chains"]:
                for rule in chain.get("rules"):
                    if rule.get("enabled") is True:
                        self.validate_settings_rule(settings_file, errors, table, chain, rule)

        if len(errors) > 0:
            raise SettingsException(message_str="\n".join(errors))

    def validate_settings_rule(self, settings_file, errors, table, chain, rule) -> bool:
        """
        Do nft run check for table/chain with single rule.

        We use "nft --check" and check the return code.
        Unfortunately, "nft_debug --check" always returns 0.

        IMPORTANT: If we find a failure here, it's really on us.  It means we have
        allowed the user to define an illegal rule.
        The critical purpose of validation is to prevent this illegal rule from
        being added to an nft script because it will fail the entire chain with
        pretty severe consequences.
        For example, if the access table/chain fails, ALL services are open to the WAN!

        By findng an error here, the very best we can do is to provide the nft
        error back.  If the user can figure it out that's great, but if not they
        can reach out to support who will pass this information to us and we
        can better prevent this in the future.
        """
        if (
            rule.get("action") is not None
            and rule.get("action").get("type") is not None
            and rule.get("action").get("type") == "JUMP"
        ):
            # Cannot validate JUMP operations in this context
            # (we don't allow users to create JUMP rules anyway)
            return False
        test_table_settings = copy.deepcopy(
            settings_file.settings.get("firewall").get("tables").get(table)
        )
        # Change table to "test"
        test_table_settings["name"] = "test"
        test_table_settings["chains"] = []
        test_chain = copy.deepcopy(chain)
        test_chain["rules"] = []
        test_chain["rules"].append(copy.deepcopy(rule))

        test_table_settings["chains"].append(test_chain)

        test_file_name = "/tmp/nft_test"
        write_file(test_file_name, test_table_settings, None)
        test_command = None
        test_command_output = None
        try:
            test_command = subprocess.Popen(
                ["/usr/sbin/nft", "--check", "--file", test_file_name],
                stderr=subprocess.STDOUT,
                stdout=subprocess.PIPE,
                text=True,
            )
            test_command_output = test_command.communicate()[0]
        except Exception:
            error_message = f"Command /usr/sbin/nft --check --file {test_file_name} failed"
            if test_command is not None:
                error_message += f" -- returncode = {test_command.returncode}"
            if test_command_output:
                error_message += f" -- output: {test_command_output}"
            if error_message not in errors:
                errors.append(error_message)
            os.remove(test_file_name)
            return False
        os.remove(test_file_name)

        # Attempt to parse out "most-meaningful" error messages.
        #
        # Standard error response looks like:
        #
        # /tmp/nft_test:11:91-99: Error: conflicting protocols specified: tcp vs. udp
        # add rule inet test access-rules fib daddr type "local" ip saddr 1.2.3.4 tcp sport 459-460 udp sport 461 accept
        #                                                                                           ^^^^^^^^^
        # 1. Remove file name, line, and colunn/characters.
        # 2. Remove the nft rule itself
        # 3. Remove the column pointers
        #
        # In this example, we only want to return the single line "Error: conflicting protocols specified: tcp vs. udp"
        feedback = []
        for output in test_command_output.split("\n"):
            # Filename + line, numbers, etc.
            output = re.sub(rf"{test_file_name}:\d+:[\d+\-]*:", "", output)
            # nft rule
            output = re.sub(r"add rule .*", "", output)
            # Column pointers
            output = re.sub(r"\^*", "", output)
            output = output.strip()
            if output == "":
                continue
            feedback.append(output)

        # Run script and look at result code
        if test_command.returncode == 0:
            return True
        if len(feedback) > 0:
            errors.extend(feedback)
        return False

    def create_settings(self, settings_file, prefix, delete_list, filename) -> None:
        """creates settings"""
        logger.info("Initializing settings")

        tables = {}
        tables["filter"] = default_filter_rules_table()
        tables["port-forward"] = default_port_forward_table()
        tables["nat"] = default_nat_rules_table()
        tables["shaping"] = default_shaping_rules_table()
        tables["dos"] = default_dos_rules_table(settings_file)

        tables["access"] = default_access_rules_table()

        settings_file.settings["firewall"] = {}
        settings_file.settings["firewall"]["tables"] = tables

    def write_files(self, settings, prefix, delete_list) -> None:
        """writes the rule files"""
        if settings.get("firewall") is None or settings.get("firewall").get("tables") is None:
            return

        http_port = settings["system"]["httpPort"]
        https_port = settings["system"]["httpsPort"]
        i = 0
        for _, table in sorted(settings.get("firewall").get("tables").items()):
            if table.get("name") is None:
                raise SettingsException(message_str="Invalid table: Missing name")
            if table.get("family") is None:
                raise SettingsException(
                    message_str="Invalid table {}: Missing family".format(table.get("name"))
                )
            if table.get("chains") is None:
                raise SettingsException(
                    message_str="Invalid table {}: Missing chains".format(table.get("name"))
                )

            # XXX
            # docker runs in the same kernel as the host, most hosts kernel do not yet support multiple NAT hooks
            # docker needs the iptables NAT hooks so we can't insert nft nat rules or it will break iptables NAT
            if board_util.is_docker() and (
                table.get("name") == "nat" or table.get("name") == "port-forward"
            ):
                continue
            filename_noprefix = self.filename_prefix + ("%02d-%s" % (i, table.get("name")))
            filename = prefix + filename_noprefix
            with contextlib.suppress(Exception):
                delete_list.remove(filename_noprefix)

            if table["name"] == "dos":
                write_file(self.dos_filename_prefix, table, prefix)
                continue

            if table["name"] == "access":
                insert_captive_portal_access_rule(table, http_port, https_port)
            # Write only access table rules for eos native
            if not BoardUtil.is_platform_os_eos() or table["name"] == "access":
                write_file(filename, table, prefix)
            i = i + 1
        return

    def sync_settings(self, settings_file, prefix, delete_list) -> None:
        """syncs settings"""

        # Add all /etc/config/nftables-rules.d/2.* files to the delete_list
        # Remove all the files that we write later
        # This ensures that all the existing /etc/config/nftables-rules.d/2* that we don't
        # write get removed
        for dirpath, _, filenames in os.walk(
            FileUtil.locate_file("/etc/config/nftables-rules.d/")
        ):
            for filename in filenames:
                if filename.startswith("2"):
                    full_name = dirpath + filename
                    delete_list.append(full_name)
        # Write all the /etc/config/nftables-rules.d/2.* files
        self.write_files(settings_file.settings, prefix, delete_list)


def insert_captive_portal_access_rule(table, http_port, https_port) -> None:
    """Adds new access rule- `fib daddr type local meta mark & 0x03000000 == 0x02000000 tcp dport { 80, 443 } accept`"""
    insert_at_position = -1
    for chain in table["chains"]:
        if chain["name"] == "access-rules":
            insert_at_position = find_index_new_access_rule(chain["rules"], http_port, https_port)
            break
    if insert_at_position == -1:
        logger.warning(
            "Couldn't find access rules for either http: %s or https: %s web admin ports. Unexpected.",
            str(http_port),
            str(https_port),
        )
        return

    # Split into two separate rules due to the limitations of our acl_manager's limitations.
    # When nftables rules are converted to EOS rules -- controlled by the acl_manager -- port
    # groups cause issues. Port groups are not supported by our acl_manager or acl in EOS at
    # this time.
    new_access_rule_http = OrderedDict(
        [
            ("enabled", True),
            ("description", "Accept captive portal redirected traffic on LANs TCP/80 "),
            ("ruleId", uuid4().__str__()),
            (
                "conditions",
                [
                    {"type": "DESTINED_LOCAL", "op": "==", "value": True},
                    {
                        "type": "SOURCE_INTERFACE_TYPE",
                        "op": "==",
                        "value": nftables_util.INTERFACE_TYPES["lan"],
                    },
                    {
                        "type": "DESTINATION_PORT",
                        "op": "==",
                        "value": f"{http_port}",
                        "port_protocol": 6,
                    },
                ],
            ),
            ("action", {"type": "ACCEPT"}),
        ]
    )
    new_access_rule_https = OrderedDict(
        [
            ("enabled", True),
            ("description", "Accept captive portal redirected traffic on LANs TCP/443"),
            ("ruleId", uuid4().__str__()),
            (
                "conditions",
                [
                    {"type": "DESTINED_LOCAL", "op": "==", "value": True},
                    {
                        "type": "SOURCE_INTERFACE_TYPE",
                        "op": "==",
                        "value": nftables_util.INTERFACE_TYPES["lan"],
                    },
                    {
                        "type": "DESTINATION_PORT",
                        "op": "==",
                        "value": f"{https_port}",
                        "port_protocol": 6,
                    },
                ],
            ),
            ("action", {"type": "ACCEPT"}),
        ]
    )
    chain["rules"] = (
        chain["rules"][:insert_at_position]
        + [new_access_rule_http]
        + [new_access_rule_https]
        + chain["rules"][insert_at_position:]
    )


def matches_dport_condition(condition, port):
    """Matches whether the condition at index is 'destination port == port'"""
    return (
        condition["op"] == "=="
        and condition["type"] == "DESTINATION_PORT"
        and condition["value"] == port
    )


def matches_intf_lan_condition(condition):
    """Matches whether the condition at index is 'source interface type == 2 (LAN)'"""
    return (
        condition["op"] == "=="
        and condition["type"] == "SOURCE_INTERFACE_TYPE"
        and condition["value"] == nftables_util.INTERFACE_TYPES["lan"]
    )


def matches_lan_admin_port_conditions(conditions, port):
    """
    Matches whether the conditions array has a condition for destination interface type == LAN & another condition
    for TCP destination port == port. The conditions can be in any sequence.
    """
    return (
        matches_dport_condition(conditions[0], port) and matches_intf_lan_condition(conditions[1])
    ) or (
        matches_dport_condition(conditions[1], port) and matches_intf_lan_condition(conditions[0])
    )


def find_index_new_access_rule(rules, http_port, https_port):
    """
    Finds index for new access rule- `fib daddr type local meta mark & 0x03000000 == 0x02000000 tcp dport { 80, 443 } accept`
    This rule needs to be inserted at some index before both the web admin port access-rules since those are drop
    rules and we want this new accept rule to be prioritized over those two.
    So this function finds the index of the first occurring web admin port access-rule & returns it.
    param: rules (OrderedDict) has all the access-rules.
    param: http_port (str) is the web admin http port.
    param: https_port (str) is the web admin https port.
    """
    for index, rule in enumerate(rules):
        if len(rule["conditions"]) >= 2 and (
            matches_lan_admin_port_conditions(rule["conditions"], http_port)
            or matches_lan_admin_port_conditions(rule["conditions"], https_port)
        ):
            return index
    return -1


def write_file(filename, table_settings, prefix) -> None:
    """write_file writes the specified file"""
    #  we require "regain_permissions" as sync-setting is failing with
    #  PermissionError when creating the /etc/config/dos directory
    with regain_permissions():
        file_dir = os.path.dirname(filename)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)

        file = open(filename, "w+")
        file.write("#!/usr/bin/nft_debug -f")
        file.write("\n\n")

        file.write("## Auto Generated\n")
        file.write("## DO NOT EDIT. Changes will be overwritten.\n")
        file.write("\n\n")

        file.write(nftables_util.table_all_cmds(table_settings) + "\n")

        file.write("\n")
        file.flush()
        file.close()

        os.chmod(filename, os.stat(filename).st_mode | stat.S_IEXEC)


def default_port_forward_table() -> dict[str, Any]:
    """default port forward table"""
    default_port_forward_table = Table(
        name="port-forward",
        family="ip,ip6",
        chain_type="nat",
        chains=[
            RuleChain(
                name="port-forward-rules",
                description="The base port-forwards chain",
                base=False,
                default=True,
                rules=[],
            ),
            # The port-forward-rules chain is intended for user-editable port forwarding rules
            # from WAN to LAN. To prevent users from creating rules forwarding traffic
            # in the opposite direction, a separate chain is created here. This chain checks
            # the interface type before jumping to the port-forward-rules chain, ensuring
            # that only uneditable rules are established for traffic in this direction.
            # If users need to forward traffic in the other direction, they can use a DNAT rule.
            RuleChain(
                name="port-forward-validation",
                description="Chain used to validate traffic being port forwarded",
                hook="prerouting",
                priority=100,
                default=True,
                base=True,
                rules=[
                    Rule(
                        enabled=True,
                        description="Jump to port-forward rule chain if traffic originated from a WAN",
                        rule_id=uuid4().__str__(),
                        conditions=[Condition(type="SOURCE_INTERFACE_TYPE", op="==", value=1)],
                        action=Action(type="JUMP", chain="port-forward-rules"),
                    )
                ],
            ),
        ],
    )

    return default_port_forward_table.get_json()


def default_access_rules_table() -> dict[str, Any]:
    """default access rules table"""
    """Moved default access rule table back to input chain with priority 0
    to work DNAT policies irrespective access rules allow/block"""
    default_access_rules_table = Table(
        name="access", family="inet", chain_type="filter", chains=[]
    )

    default_rule_chain = RuleChain(
        name="access-rules",
        description="The base access-rules chain",
        base=True,
        hook="input",
        priority=0,
        rules=[],
    )
    default_access_rules_table.chains.append(default_rule_chain)

    default_rule_chain.rules = [
        Rule(
            enabled=True,
            description="Accept established",
            rule_id=uuid4().__str__(),
            conditions=[Condition(type="CT_STATE", op="==", value="established")],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept related",
            rule_id=uuid4().__str__(),
            conditions=[Condition(type="CT_STATE", op="==", value="related")],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Drop invalid",
            rule_id=uuid4().__str__(),
            conditions=[Condition(type="CT_STATE", op="==", value="invalid")],
            action=Action(type="DROP"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept loopback",
            rule_id=uuid4().__str__(),
            conditions=[Condition(type="SOURCE_INTERFACE_NAME", op="==", value="lo")],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept HTTP on LANs",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="80", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=False,
            description="Accept HTTP on WANs",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="80", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["wan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept HTTPS on LANs",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="443", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=False,
            description="Accept HTTPS on WANs",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="443", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["wan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept SSH on LANs (TCP/22)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="22", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=False,
            description="Accept SSH on WANs (TCP/22)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="22", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["wan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept DNS on LANs (TCP/53)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="53", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept DNS on LANs (UDP/53)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="53", port_protocol=17),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept ICMP",
            rule_id=uuid4().__str__(),
            conditions=[Condition(type="IP_PROTOCOL", op="==", value="1")],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept ICMPv6",
            rule_id=uuid4().__str__(),
            conditions=[Condition(type="IP_PROTOCOL", op="==", value="58")],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept DHCP on LANs (UDP/67)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="67", port_protocol=17),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept DHCPv6 on LANs (UDP/547)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="547", port_protocol=17),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Accept DHCPv6 Replies (UDP/546)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="546", port_protocol=17)
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=False,
            description="Accept HTTP 8487 captive portal on LANs (TCP/8487)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="8487", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=False,
            description="Accept HTTPS 8488 captive portal on LANs (TCP/8488)",
            rule_id=uuid4().__str__(),
            conditions=[
                Condition(type="DESTINATION_PORT", op="==", value="8488", port_protocol=6),
                Condition(
                    type="SOURCE_INTERFACE_TYPE",
                    op="==",
                    value=nftables_util.INTERFACE_TYPES["lan"],
                ),
            ],
            action=Action(type="ACCEPT"),
            log=False,
        ),
        Rule(
            enabled=True,
            description="Drop All",
            rule_id=uuid4().__str__(),
            conditions=[],
            action=Action(type="DROP"),
            log=False,
        ),
    ]
    return default_access_rules_table.get_json()


def default_dos_rules_table(settings_file) -> dict[str, Any]:
    """default dos rules table function generates the dos configuration, rules and sets from settings_file provided"""
    set_size = "65535"
    default_dos_rules_table = Table(
        name="dos", family="ip", chains=[], sets=[], chain_type="filter"
    )
    if settings_file.settings.get("denial_of_service", {}).get("enabled"):
        dos_setting = settings_file.settings["denial_of_service"]

        default_dos_rules_table.sets = [
            Set(
                name="blocklist_all_sessions_saddr_timeout",
                type="ipv4_addr",
                size=set_size,
                timeout=str(dos_setting["block_duration"]) + "s",
            ),
            Set(
                name="blocklist_all_sessions_saddr_ct_count",
                type="ipv4_addr",
                dynamic=True,
                size=set_size,
            ),
            Set(
                name="blocklist_all_sessions_daddr_timeout",
                type="ipv4_addr",
                timeout=str(dos_setting["block_duration"]) + "s",
                size=set_size,
            ),
            Set(
                name="blocklist_all_sessions_daddr_ct_count",
                type="ipv4_addr",
                dynamic=True,
                size=set_size,
            ),
            Set(
                name="blocklist_protocol_saddr_timeout",
                type="inet_proto . ipv4_addr",
                timeout=str(dos_setting["block_duration"]) + "s",
                size=set_size,
            ),
            Set(
                name="blocklist_protocol_saddr_ct_count",
                type="inet_proto . ipv4_addr",
                dynamic=True,
                size=set_size,
            ),
            Set(
                name="blocklist_protocol_daddr_timeout",
                type="inet_proto . ipv4_addr",
                timeout=str(dos_setting["block_duration"]) + "s",
                size=set_size,
            ),
            Set(
                name="blocklist_protocol_daddr_ct_count",
                type="inet_proto . ipv4_addr",
                dynamic=True,
                size=set_size,
            ),
        ]

        default_chain_dos = RuleChain(
            name="dos-rules",
            description="The base DOS chain",
            hook="prerouting",
            # Current earliest chain in the prerouting hook has priority mangle (i.e. 150), so we
            # want to keep this chain just before that i.e. at the earliest stage in the nft flow.
            priority="mangle - 1",
            base=True,
            rules=[
                Rule(
                    rule_id=uuid4().__str__(),
                    enabled=True,
                    description="Don't process dos rules for packets coming from MFW",
                    conditions=[
                        Condition(
                            type="SOURCE_ADDRESS_TYPE",
                            op="==",
                            value="local",
                        )
                    ],
                    action=Action(type="RETURN"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    description="drop if source address in set",
                    enabled=True,
                    conditions=[
                        Condition(
                            type="SOURCE_ADDRESS",
                            membership_check_for_set="blocklist_all_sessions_saddr_timeout",
                            op="",
                            value="",
                        )
                    ],
                    logs=[
                        Log(
                            type="COUNTER",
                        )
                    ],
                    action=Action(type="DROP"),
                ),
                Rule(
                    enabled=dos_setting["source_sessions_max_all"] > 0,
                    rule_id=uuid4().__str__(),
                    description="Max IP sessions from one host - 5000",
                    conditions=[
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_all_sessions_saddr_ct_count",
                            elements=["SOURCE_ADDRESS"],
                            ct_count=dos_setting["source_sessions_max_all"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_all_sessions_saddr_timeout",
                            elements=["SOURCE_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="all:src",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    description="drop if destination address in set",
                    enabled=True,
                    conditions=[
                        Condition(
                            type="DESTINATION_ADDRESS_TYPE",
                            op="!=",
                            value="local",
                        ),
                        Condition(
                            type="DESTINATION_ADDRESS",
                            membership_check_for_set="blocklist_all_sessions_daddr_timeout",
                            op="",
                            value="",
                        ),
                    ],
                    logs=[
                        Log(
                            type="COUNTER",
                        )
                    ],
                    action=Action(type="DROP"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    description="Max IP sessions to one host - 5000",
                    enabled=dos_setting["dest_sessions_max_all"] > 0,
                    conditions=[
                        Condition(
                            type="DESTINATION_ADDRESS_TYPE",
                            op="!=",
                            value="local",
                        ),
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_all_sessions_daddr_ct_count",
                            elements=["DESTINATION_ADDRESS"],
                            ct_count=dos_setting["dest_sessions_max_all"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_all_sessions_daddr_timeout",
                            elements=["DESTINATION_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="all:dst",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    description="Single drop rule for all protocols' from one host scenarios",
                    enabled=True,
                    conditions=[
                        Condition(
                            type="IP_PROTOCOL . SOURCE_ADDRESS",
                            membership_check_for_set="blocklist_protocol_saddr_timeout",
                            op="",
                            value="",
                        )
                    ],
                    logs=[
                        Log(
                            type="COUNTER",
                        )
                    ],
                    action=Action(type="DROP"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    description="Max TCP sessions from one host - 5000",
                    enabled=dos_setting["source_sessions_max_tcp"] > 0,
                    conditions=[
                        Condition(
                            type="IP_PROTOCOL",
                            op="==",
                            value="6",
                        ),
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_protocol_saddr_ct_count",
                            elements=["IP_PROTOCOL", "SOURCE_ADDRESS"],
                            ct_count=dos_setting["source_sessions_max_tcp"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_protocol_saddr_timeout",
                            elements=["IP_PROTOCOL", "SOURCE_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="tcp:src",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    description="Max UDP sessions from one host - 5000",
                    enabled=dos_setting["source_sessions_max_udp"] > 0,
                    conditions=[
                        Condition(type="IP_PROTOCOL", op="==", value="17"),
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_protocol_saddr_ct_count",
                            elements=["IP_PROTOCOL", "SOURCE_ADDRESS"],
                            ct_count=dos_setting["source_sessions_max_udp"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_protocol_saddr_timeout",
                            elements=["IP_PROTOCOL", "SOURCE_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="udp:src",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    description="Max ICMP sessions from one host - 5000",
                    enabled=dos_setting["source_sessions_max_icmp"] > 0,
                    conditions=[
                        Condition(type="IP_PROTOCOL", op="==", value="1"),
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_protocol_saddr_ct_count",
                            elements=["IP_PROTOCOL", "SOURCE_ADDRESS"],
                            ct_count=dos_setting["source_sessions_max_icmp"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_protocol_saddr_timeout",
                            elements=["IP_PROTOCOL", "SOURCE_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="icmp:src",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    enabled=True,
                    description="Single drop rule for all to one host scenarios ",
                    conditions=[
                        Condition(
                            type="DESTINATION_ADDRESS_TYPE",
                            op="!=",
                            value="local",
                        ),
                        Condition(
                            type="IP_PROTOCOL . DESTINATION_ADDRESS",
                            membership_check_for_set="blocklist_protocol_daddr_timeout",
                            op="",
                            value="",
                        ),
                    ],
                    logs=[
                        Log(
                            type="COUNTER",
                        )
                    ],
                    action=Action(type="DROP"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    enabled=dos_setting["dest_sessions_max_tcp"] > 0,
                    description="Max TCP sessions to one host - 5000 ",
                    conditions=[
                        Condition(type="IP_PROTOCOL", op="==", value="6"),
                        Condition(
                            type="DESTINATION_ADDRESS_TYPE",
                            op="!=",
                            value="local",
                        ),
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_protocol_daddr_ct_count",
                            elements=["IP_PROTOCOL", "DESTINATION_ADDRESS"],
                            ct_count=dos_setting["dest_sessions_max_tcp"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_protocol_daddr_timeout",
                            elements=["IP_PROTOCOL", "DESTINATION_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="tcp:dst",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
                Rule(
                    rule_id=uuid4().__str__(),
                    enabled=dos_setting["dest_sessions_max_udp"] > 0,
                    description="Max UDP sessions to one host - 5000 ",
                    conditions=[
                        Condition(type="IP_PROTOCOL", op="==", value="17"),
                        Condition(
                            type="DESTINATION_ADDRESS_TYPE",
                            op="!=",
                            value="local",
                        ),
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_protocol_daddr_ct_count",
                            elements=["IP_PROTOCOL", "DESTINATION_ADDRESS"],
                            ct_count=dos_setting["dest_sessions_max_udp"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_protocol_daddr_timeout",
                            elements=["IP_PROTOCOL", "DESTINATION_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="udp:dst",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
                Rule(
                    enabled=dos_setting["dest_sessions_max_icmp"] > 0,
                    rule_id=uuid4().__str__(),
                    description="Max ICMP sessions to one host - 5000 ",
                    conditions=[
                        Condition(type="IP_PROTOCOL", op="==", value="1"),
                        Condition(
                            type="DESTINATION_ADDRESS_TYPE",
                            op="!=",
                            value="local",
                        ),
                        Condition(type="CT_STATE", op="==", value="new"),
                    ],
                    add_to_set=[
                        AddToSet(
                            set_name="blocklist_protocol_daddr_ct_count",
                            elements=["IP_PROTOCOL", "DESTINATION_ADDRESS"],
                            ct_count=dos_setting["dest_sessions_max_icmp"],
                            ct_count_operator=">",
                        ),
                        AddToSet(
                            set_name="blocklist_protocol_daddr_timeout",
                            elements=["IP_PROTOCOL", "DESTINATION_ADDRESS"],
                        ),
                    ],
                    logs=[
                        Log(
                            type="NFLOG",
                            prefix="icmp:dst",
                        ),
                        Log(
                            type="COUNTER",
                        ),
                    ],
                    action=Action(type="DOS-BLOCK"),
                ),
            ],
        )
        default_dos_rules_table.chains.append(default_chain_dos)
    return default_dos_rules_table.get_json()


def default_shaping_rules_table() -> dict[str, Any]:
    """default shaping rules table"""
    default_shaping_rules_table = Table(
        name="shaping",
        family="inet",
        chain_type="filter",
        chains=[
            RuleChain(
                name="shaping-rules",
                description="The base shaping-rules chain",
                base=True,
                hook="postrouting",
                priority=5,
                rules=[
                    Rule(
                        enabled=True,
                        description="Call prioritization-rules",
                        rule_id=uuid4().__str__(),
                        conditions=[],
                        action=Action(type="JUMP", chain="prioritization-rules"),
                    ),
                    Rule(
                        enabled=True,
                        description="Call limiting-rules",
                        rule_id=2,
                        conditions=[],
                        action=Action(type="JUMP", chain="limiting-rules"),
                    ),
                    Rule(
                        enabled=True,
                        description="Call quota-rules",
                        rule_id=2,
                        conditions=[],
                        action=Action(type="JUMP", chain="quota-rules"),
                    ),
                ],
            ),
            RuleChain(
                name="prioritization-rules",
                description="The main prioritization rules chain",
                default=True,
                rules=[
                    Rule(
                        enabled=True,
                        description="Ignore priority rules if priority set by Policy Manager",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(
                                type="META_MARK",
                                op="!=",
                                mask_value=SHAPING_PRIORITY_MASK,
                                value="0",
                            )
                        ],
                        action=Action(type="RETURN"),
                    ),
                    Rule(
                        enabled=False,
                        description="VoIP (IAX) Traffic",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="6"),
                            Condition(type="SERVER_PORT", op="==", value="4569"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=11, return_action=True),
                    ),
                    Rule(
                        enabled=True,
                        description="Ping Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[Condition(type="IP_PROTOCOL", op="==", value="1")],
                        action=Action(type="SET_PRIORITY", priority=1, return_action=True),
                    ),
                    Rule(
                        enabled=True,
                        description="DNS Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="17"),
                            Condition(type="SERVER_PORT", op="==", value="53"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=19, return_action=True),
                    ),
                    Rule(
                        enabled=True,
                        description="SSH Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="6"),
                            Condition(type="SERVER_PORT", op="==", value="22"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=16, return_action=True),
                    ),
                    Rule(
                        enabled=True,
                        description="Openvpn Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="6"),
                            Condition(type="SERVER_PORT", op="==", value="1194"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=15, return_action=True),
                    ),
                    Rule(
                        enabled=False,
                        description="Telnet Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="6"),
                            Condition(type="SERVER_PORT", op="==", value="23"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=2, return_action=True),
                    ),
                    Rule(
                        enabled=False,
                        description="PTP Event messages Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="17"),
                            Condition(type="SERVER_PORT", op="==", value="319"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=3, return_action=True),
                    ),
                    Rule(
                        enabled=False,
                        description="SIP over TLS (secure traffic) Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="17"),
                            Condition(type="SERVER_PORT", op="==", value="5061"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=4, return_action=True),
                    ),
                    Rule(
                        enabled=False,
                        description="Non-real-time video streaming Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="6"),
                            Condition(type="SERVER_PORT", op="==", value="443"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=6, return_action=True),
                    ),
                    Rule(
                        enabled=False,
                        description="RTSP control messages Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="6"),
                            Condition(type="SERVER_PORT", op="==", value="554"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=8, return_action=True),
                    ),
                    Rule(
                        enabled=False,
                        description="RAS signaling Priority",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="17"),
                            Condition(type="SERVER_PORT", op="==", value="1719"),
                        ],
                        action=Action(type="SET_PRIORITY", priority=12, return_action=True),
                    ),
                    Rule(
                        enabled=True,
                        description="Default priority",
                        rule_id=uuid4().__str__(),
                        conditions=[],
                        action=Action(type="SET_PRIORITY", priority=20, return_action=True),
                    ),
                ],
            ),
            RuleChain(
                name="limiting-rules",
                description="The main limiting rules chain",
                default=True,
                rules=[
                    Rule(
                        enabled=False,
                        description="Rate limit ICMP traffic accept",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="1"),
                            Condition(
                                type="LIMIT_RATE",
                                op="<",
                                value="1000",
                                rate_unit="PACKETS_PER_SECOND",
                            ),
                            Condition(
                                type="BURST_SIZE", op="==", value="10", burst_unit="PACKETS"
                            ),
                        ],
                        action=Action(type="SET_PRIORITY", priority=20, return_action=True),
                    ),
                    Rule(
                        enabled=False,
                        description="Rate limit ICMP traffic drop",
                        rule_id=uuid4().__str__(),
                        conditions=[
                            Condition(type="IP_PROTOCOL", op="==", value="1"),
                            Condition(
                                type="LIMIT_RATE",
                                op=">",
                                value="1000",
                                rate_unit="PACKETS_PER_SECOND",
                            ),
                            Condition(
                                type="BURST_SIZE", op="==", value="10", burst_unit="PACKETS"
                            ),
                        ],
                        action=Action(
                            type="LIMIT_EXCEED_ACTION",
                            limit_exceed_action="DROP",
                            return_action=True,
                        ),
                    ),
                ],
            ),
            RuleChain(
                name="quota-rules",
                description="The main quota rules chain",
                default=True,
                rules=[],
            ),
        ],
    )

    return default_shaping_rules_table.get_json()


def sanitize_settings_web_admin_ports(settings_file: SettingsFile) -> list[dict[str, Any]]:
    """sanitizes admin port settings"""
    access_rules = settings_file.get_settings_by_path(
        "firewall/tables/access/chains/name=access-rules/rules"
    )

    http_port = settings_file.get_settings_by_path("system/httpPort")

    https_port = settings_file.get_settings_by_path("system/httpsPort")

    access_rules = update_web_admin_port_setting(access_rules, "Accept HTTP on LANs", http_port)
    access_rules = update_web_admin_port_setting(access_rules, "Accept HTTP on WANs", http_port)
    access_rules = update_web_admin_port_setting(access_rules, "Accept HTTPS on LANs", https_port)
    access_rules = update_web_admin_port_setting(access_rules, "Accept HTTPS on WANs", https_port)

    # Update nat output rule for port redirect for ETM connectivity
    update_web_admin_port_redirect(http_port, settings_file)

    return access_rules


def update_web_admin_port_setting(
    rules: list[dict[str, Any]], description: str, port: int
) -> dict[str, Any]:
    """update port access rule if it port is updated"""

    for access_rule in rules:
        if description in access_rule.get("description"):
            # Update the description if it does not fully match
            if description != access_rule.get("description"):
                access_rule["description"] = description
            # Update the access rule to allow the new admin port
            for condition in access_rule.get("conditions"):
                if condition.get("type") == "DESTINATION_PORT":
                    if str(condition.get("value")) != str(port):
                        logger.info(
                            "Updating access rule for web admin port to %s",
                            str(port),
                        )
                        condition["value"] = str(port)
                    break
    return rules


def update_web_admin_port_redirect(http_port: int, settings_file: SettingsFile) -> None:
    """enables admin port redirect rule for non-default admin port"""

    nat_output_rules = settings_file.get_settings_by_path(
        "firewall/tables/nat/chains/name=output/rules"
    )
    # Removing "if not nat_output_rules" part of code as output chains are created using default rules and MFW-5462 removes default rule generation
    if nat_output_rules:
        for rule in nat_output_rules:
            if rule.get("description", "").startswith("Redirect http port to admin port"):
                if str(http_port) == "80":
                    rule["enabled"] = False
                else:
                    logger.info(
                        "Adding http redirect from port 80 to %s",
                        str(http_port),
                    )
                    rule["enabled"] = True
                rule["action"]["dnat_port"] = str(http_port)


registrar.register_manager(TableManager())
