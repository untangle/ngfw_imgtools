"""variables"""


class Variables:
    variables = {}

    def set(name, value) -> None:
        """
        Set the variable by name and value.
        """
        if name in Variables.variables:
            msg = "Duplicate variable name"
            raise ValueError(msg)
        Variables.variables[name] = value

    def get(name):
        """
        Return variable value using name
        """
        if name in Variables.variables:
            return Variables.variables[name]
        return None
