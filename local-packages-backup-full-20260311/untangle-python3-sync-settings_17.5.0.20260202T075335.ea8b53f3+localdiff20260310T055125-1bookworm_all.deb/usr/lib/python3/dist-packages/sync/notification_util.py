"""notification_util provides utility functions to send settings notifications to command center when settings change"""

import json

import requests

from sync.common import Logger
from sync.file_util import FileUtil
from sync.uri_util import UriUtil

SETTINGS_CHANGE_NOTIFICATION_URL = "https://edge.arista.com/api/v1/appliance/OnSettingsUpdate"
SETTINGS_CHANGE_NOTIFICATION_PARAMETERS = "?uid={uid}&token={token}"
STORE_APPLIANCE_API_KEY = "2da30367-a1de-4154-a409-fca6addecd68"

logger = Logger.getInstance()


def get_uid() -> str:
    """
    Get the system's uid
    """
    try:
        with open(FileUtil.locate_file("/etc/config/uid")) as f:
            uid = f.read()
    except FileNotFoundError:
        logger.exception("Could not locate UID file")
        return ""
    return uid


def get_settings_change_uri(settings_file) -> str:
    """Get the URI translation for update settings url"""
    for uri in settings_file.settings["uris"]["uriTranslations"]:
        if uri["uri"] == SETTINGS_CHANGE_NOTIFICATION_URL:
            return str(UriUtil.build_uri(SETTINGS_CHANGE_NOTIFICATION_URL, uri))
    return SETTINGS_CHANGE_NOTIFICATION_URL


def get_settings_change_api_key():
    """Get the api key for updating settings url"""
    cloud_tokens_filename = FileUtil.locate_file("/etc/config/cloud-tokens.json")
    with open(cloud_tokens_filename) as json_file:
        cloud_tokens = json.load(json_file)
        return cloud_tokens.get("storeApplianceApiKey") or STORE_APPLIANCE_API_KEY


def notify_store_of_settings_change(settings_file):
    """Notify command center about the settings change for this appliance
    Returns operation status: success -> true, fail -> false
    """
    appliance_uid = get_uid()
    settings_change_uri = get_settings_change_uri(settings_file)
    settings_change_api_key = get_settings_change_api_key()
    parameters = SETTINGS_CHANGE_NOTIFICATION_PARAMETERS.replace("{uid}", appliance_uid).replace(
        "{token}", settings_change_api_key
    )
    try:
        r = requests.get(settings_change_uri + parameters, verify=True, timeout=1)
        if r.status_code == 200:
            logger.info("Successfully notified store of appliance settings changes.")
            return True, ""
        return False, f"Error: HTTP status code: {r.status_code}. Response body: {r.json()}"
    except requests.exceptions.ConnectionError as errc:
        return False, f"Connection Error: {errc!s}"
    except requests.exceptions.Timeout as errt:
        return False, f"Timeout Error: {errt!s}"
    except Exception as err:
        return False, f"Exception: {err!s}"
